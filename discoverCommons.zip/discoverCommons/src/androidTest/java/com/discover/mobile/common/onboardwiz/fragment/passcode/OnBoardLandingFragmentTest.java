package com.discover.mobile.common.onboardwiz.fragment.passcode;

import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.shared.utils.CommonUtils;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isClickable;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

/**
 * Created by 409992 on 4/27/2016.
 */
@RunWith(AndroidJUnit4.class)
@LargeTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OnBoardLandingFragmentTest {

    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }
    @Rule
    public ActivityTestRule<OnBoardActivity> mActivityTestRule =
            new ActivityTestRule<OnBoardActivity>(OnBoardActivity.class);
    private String mValidateString;

    @Before
    public void initString() {
        mValidateString = "Follow these easy steps to set up your account with the Discover app.";
    }

    /**
     * tests verbiage at the landing view top.
     */
    @Test
    public void test1loadVerbageTest() {
        onView(withText(mValidateString));
    }

    /**
     * checks the getStarted button's visiblity
     **/
    @Test
    public void test2ButtonVisibility() {
        onView(withId(com.discover.mobile.common.R.id.btnGetStarted)).check(matches(isDisplayed()));
    }

    /**
     * checks if exit setup button is clickable
     */
    @Test
    public void test3ExitSetupClick() {
        onView(withId(com.discover.mobile.common.R.id.btn_exit)).check(matches(isClickable()));
    }

    /**
     * validates the navigation from getStarted button click to enable passcode view
     */
    @Test
    public void test4GetStartedBtn() {
        onView(withId(com.discover.mobile.common.R.id.btnGetStarted)).perform(click());
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        onView(withId(com.discover.mobile.common.R.id.buttonEnable)).check(matches(isDisplayed()));
    }

}
