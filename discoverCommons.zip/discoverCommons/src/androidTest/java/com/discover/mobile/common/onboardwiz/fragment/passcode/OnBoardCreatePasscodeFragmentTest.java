package com.discover.mobile.common.onboardwiz.fragment.passcode;

import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.shared.utils.CommonUtils;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

/**
 * Created by 409992 on 4/29/2016.
 */
@RunWith(AndroidJUnit4.class)
@LargeTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OnBoardCreatePasscodeFragmentTest {

    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }
    @Rule
    public ActivityTestRule<OnBoardActivity> mActivityTestRule =
            new ActivityTestRule<OnBoardActivity>(OnBoardActivity.class);
    private String mCreatePasscode, mVerifyPasscode;

    @Before
    public void setUp() {

        onView(withId(com.discover.mobile.common.R.id.btnGetStarted)).perform(click());
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        onView(withId(com.discover.mobile.common.R.id.buttonEnable)).perform(click());
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        mCreatePasscode = "Please create a passcode";
        mVerifyPasscode = "Verify your Passcode";
    }

//    @Test
//    public void checkPasscodePageIsDisplayed() throws Exception{
//
////        onView(allOf(withId(R.id.btnEnable), withParent(withId(R.id.btnGetStarted))))
////                .check(matches(isDisplayed()))
////                .perform(click());
////        onView(withText("Get Started")).perform(click());
////        try {
////            Thread.sleep(10000);
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////        onView(withText("Enable")).perform(click());
////        try {
////            Thread.sleep(10000);
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
//
//    }

    @Test
    public void checkCreatePasscodeMsg() {
        onView(withText(mCreatePasscode));
    }

    @Test
    public void checkCreatePasscodeInfo() {
        onView(withText(mVerifyPasscode));
    }

//    @Test
//    public void checkPasscodeBubbleVisibility() {
//        onView(withId(com.discover.mobile.common.R.id.passcodeFields)).check(matches(isDisplayed()));
//    }
}
