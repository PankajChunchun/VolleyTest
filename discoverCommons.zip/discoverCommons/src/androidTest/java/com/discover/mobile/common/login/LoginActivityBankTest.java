package com.discover.mobile.common.login;

import com.discover.mobile.common.shared.utils.CommonUtils;

import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.support.test.espresso.Espresso;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

@RunWith(AndroidJUnit4.class)
@LargeTest
public class LoginActivityBankTest {

    @Rule
    public ActivityTestRule<LoginActivity> mLoginActivityTestRule =
            new ActivityTestRule<LoginActivity>(LoginActivity.class);

    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }

    @Test
    public void clickBankTab_bankTabHighlighted_test() {
        clickOnBankTab();
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //////onView(withId(com.discover.mobile.card.R.id.FontAwesomeCheckMarkBank)).check(matches(isDisplayed()));
    }

    @Test
    public void clickForgetPassword_openForgetPage_test() {
        navigateToForgetPasswordPage();
        // Check if the add notecscreen is displayed
        //////onView(withId(R.id.bank_forgot_personal_sercurity_label)).check(matches(isDisplayed()));
    }

    @Test
    public void clickQuickView_bankFlow_test() {
        openQuickViewPage();
        // Check if the add note screen is displayed
        //////onView(withId(R.id.credit_title)).check(matches(isDisplayed()));
        //////onView(withId(R.id.discover_logo)).perform(click());

    }

    @Test
    public void quickView_clickLogin_openLogin_test() {
        openQuickViewPage();
        // Check if the add note screen is displayed
        ////onView(withId(R.id.loginButton)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.bankToggle)).check(matches(isDisplayed()));
    }


    @Test
    public void forgetPage_clickContinue_DOB_error() {
        navigateToForgetPasswordPage();
        // ((DatePickerEditText)(////onView(withId(R.id.bank_forgot_personal_sercurity_dob_field))));
        ////onView(withId(R.id.account_security_continue_button)).perform(click());

        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the add note screen is displayed
        ////onView(withId(R.id.bank_forgot_personal_sercurity_dob_error)).check(matches(isDisplayed()));
        Espresso.pressBack();
    }

    @Test
    public void forgetPage_clickContinue_SSN_error_test() {
        navigateToForgetPasswordPage();
        String ssnNumber = "";
        ////onView(withId(R.id.bank_forgot_personal_sercurity_ssn_field)).perform(typeText(ssnNumber));
        ////onView(withId(R.id.account_security_continue_button)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //ssn error view check
        ////onView(withId(R.id.bank_forgot_personal_sercurity_ssn_error)).check(matches(isDisplayed()));
        //global error view check
        ////onView(withId(R.id.bank_forgot_personal_sercurity_error)).check(matches(isDisplayed()));
        Espresso.pressBack();
    }

    @Test
    public void forgetPage_clickContinue_maidenName_error_test() {
        navigateToForgetPasswordPage();
        ////onView(withId(R.id.bank_forgot_personal_sercurity_mother_field)).perform(typeText(""));
        ////onView(withId(R.id.account_security_continue_button)).perform(click());
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the add note screen is displayed
        ////onView(withId(R.id.bank_forgot_personal_sercurity_label)).check(matches(isDisplayed()));
        Espresso.pressBack();
    }

    @Test
    public void forgetPage_clickContinue_validEntry_test() {
        navigateToForgetPasswordPage();
        String ssnNumber = "123456789";
        String dob = "05/06/1985";
        String motherMaidenName = "Maiden Name";
        ////onView(withId(R.id.bank_forgot_personal_sercurity_dob_field)).perform(typeText(dob));
        ////onView(withId(R.id.bank_forgot_personal_sercurity_ssn_field)).perform(typeText(ssnNumber));
        ////onView(withId(R.id.bank_forgot_personal_sercurity_mother_field)).perform(typeText(motherMaidenName));
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the add note screen is displayed
        ////onView(withId(R.id.bank_forgot_personal_sercurity_label)).check(doesNotExist());
        Espresso.pressBack();
    }

    @Test
    public void forgetPage_clickPrivacySetting_openPrivacyPage_test() {
        clickOnBankTab();
        Espresso.closeSoftKeyboard();
        ////onView(withId(R.id.privacy_and_terms)).perform(click());

        try {
            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the add note screen is displayed
        ////onView(withId(R.id.terms_layout)).check(matches(isDisplayed()));
    }

    @Test
    public void clickVersion_openVersionInfo_test() {

        clickOnBankTab();
        Espresso.closeSoftKeyboard();
        ////onView(withId(R.id.version_number)).perform(click());

        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the add note screen is displayed
        ////onView(withId(R.id.img_update_available)).check(matches(isDisplayed()));
    }

    @Test
    public void clickFeedback_openFeedBackPage_test() {
        clickOnBankTab();
        Espresso.closeSoftKeyboard();
        ////onView(withId(R.id.feedbackButton)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.agreement_web_view)).check(matches(isDisplayed()));
        Espresso.pressBack();
    }

    @Test
    public void clickATM_openFindAtm_test() {
        clickOnBankTab();
        Espresso.closeSoftKeyboard();
        //////onView(withId(R.id.atmButton)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //////onView(withId(R.id.search_box)).check(matches(isDisplayed()));
        Espresso.pressBack();

    }

    @Test
    public void clickHelp_openHelpPage_test() {
        navigateToHelpPage();
        ////onView(withId(R.id.customer_service_menu_contact)).check(matches(isDisplayed()));
        Espresso.pressBack();

    }

    @Test
    public void helpPage_clickContactUs_openContactUsPage_test() {
        navigateToHelpPage();
        ////onView(withId(R.id.customer_service_menu_contact)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.phone_title_label)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Espresso.pressBack();

    }

    @Test
    public void helpPage_clickRegisterNow_openRegisterPage_test() {
        navigateToHelpPage();
        ////onView(withId(R.id.customer_service_register_now)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.forgot_User_id_title)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Espresso.pressBack();

    }

    @Test
    public void helpPage_registerPage_error() {
        navigateToHelpPage();
        ////onView(withId(R.id.customer_service_register_now)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.account_info_continue_button)).perform(click());
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //////onView(withId(R.id.account_info_main_input_field)).check(matches())

    }

    @Test
    public void helpPage_clickPrivacy_openPrivacyPage_test() {
        navigateToHelpPage();
        ////onView(withId(R.id.privacy_terms)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.terms_layout)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Espresso.pressBack();

    }

    @Test
    public void helpPage_clickFeedback_openFeedbackPage_test() {
        navigateToHelpPage();
        ////onView(withId(R.id.provide_feedback_button)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.agreement_web_view)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Espresso.pressBack();

    }

    @Test
    public void clickProducts_openProductPage_test() {
        clickOnBankTab();
        Espresso.closeSoftKeyboard();
        ////onView(withId(R.id.productsButton)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.product_list_view)).check(matches(isDisplayed()));

    }

    @Test
    public void clickPasscode_test() {
        clickOnBankTab();
        Espresso.closeSoftKeyboard();
        ////onView(withId(R.id.productsButton)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.product_list_view)).check(matches(isDisplayed()));

    }

    @Test
    public void help_register_valid_test() {
        navigateToHelpPage();
        ////onView(withId(R.id.customer_service_register_now)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void navigateToHelpPage() {
        clickOnBankTab();
        Espresso.closeSoftKeyboard();
        ////onView(withId(R.id.helpButton)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clickOnBankTab() {
        ////onView(withId(R.id.username_field)).perform(click());
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.bankToggle)).perform(click());
    }

    private void navigateToForgetPasswordPage() {
        clickOnBankTab();
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ////onView(withId(R.id.tv_forgot_password_lable)).perform(click());
        try {
            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openQuickViewPage() {
        clickOnBankTab();
        ////onView(withId(R.id.quickView)).perform(click());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
