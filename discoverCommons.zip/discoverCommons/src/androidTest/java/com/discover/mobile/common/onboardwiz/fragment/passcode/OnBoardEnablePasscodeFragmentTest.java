package com.discover.mobile.common.onboardwiz.fragment.passcode;

import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.shared.utils.CommonUtils;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

/**
 * Created by 409992 on 4/29/2016.
 */
@RunWith(AndroidJUnit4.class)
@LargeTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OnBoardEnablePasscodeFragmentTest {
    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }

    @Rule
    public ActivityTestRule<OnBoardActivity> mActivityTestRule =
            new ActivityTestRule<OnBoardActivity>(OnBoardActivity.class);
    private String mEnablePasscode;

    @Before
    public void initString() {
        OnBoardHelper.disposeVehicles();
        onView(withId(com.discover.mobile.common.R.id.btnGetStarted)).perform(click());
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//@After
//public void goBack(){
//    Espresso.pressBack();
//}

    /**
     * checks enable message at enable passcode view
     */
    @Test
    public void test0checkEnableMsg() {
        mEnablePasscode = "Login with a numerical 4-digit code.";
        onView(withText(mEnablePasscode));
    }

    /**
     * validates Enable button visibility at enable passcode view
     */
    @Test
    public void test1isEnableButtonVisible() {
        onView(withId(com.discover.mobile.common.R.id.buttonEnable)).check(matches(isDisplayed()));
    }

}
