package com.discover.mobile.common.login;

/**
 * Created by 364986 on 3/11/2016.
 */

import com.discover.mobile.common.shared.utils.CommonUtils;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.support.test.espresso.Espresso;
import android.support.test.espresso.matcher.BoundedMatcher;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.widget.ImageView;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;


/**
 * Tests for the Login screen.
 */
@RunWith(AndroidJUnit4.class)
@LargeTest
public class LoginActivityScreenTest {

    /**
     * {@link ActivityTestRule} is a JUnit {@link Rule @Rule} to launch your activity under test.
     *
     * <p>
     * Rules are interceptors which are executed for each test method and are important building
     * blocks of Junit tests.
     */
    @Rule
    public ActivityTestRule<LoginActivity> mLoginActivityTestRule =
            new ActivityTestRule<LoginActivity>(LoginActivity.class);

    private static Matcher<View> checkText(final String expected) {


        return new TypeSafeMatcher<View>() {

            @Override
            public void describeTo(Description description) {

            }

            @Override
            public boolean matchesSafely(View view) {

                return allOf(withText(expected)).matches(view);
            }

        };
    }

    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }

    public static BoundedMatcher<View, ImageView> hasDrawable() {
        return new BoundedMatcher<View, ImageView>(ImageView.class) {
            @Override
            public void describeTo(Description description) {
                description.appendText("has drawable");
            }

            @Override
            public boolean matchesSafely(ImageView imageView) {
                return imageView.getDrawable() != null;
            }
        };
    }

    @Test
    public void clickPrivacyTermsText_opensPrivacyTermsUI() throws Exception {

        // Click on the privacy & terms button

        Espresso.closeSoftKeyboard();

        onView(withId(com.discover.mobile.common.R.id.privacy_and_terms)).perform(click());

        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the privacy terms screen is displayed
        onView(withId(com.discover.mobile.common.R.id.general_list_item_separator_line_start)).check(matches(isDisplayed()));
    }

    @Test
    public void clickForgotPasswordText_opensForgotFlowUi() throws Exception {

        // Click on the add note button
        onView(withId(com.discover.mobile.common.R.id.tv_forgot_password_lable)).perform(click());

        try {
            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the add note screen is displayed
        onView(withId(com.discover.mobile.common.R.id.privacy_and_terms)).check(matches(isDisplayed()));

    }

    @Test
    public void clickVersionText_opensVersionInfoPage() throws Exception {

        Espresso.closeSoftKeyboard();

        // Click on the add note button
        onView(withId(com.discover.mobile.common.R.id.version_number)).perform(click());

        try {
            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the add note screen is displayed
        onView(withId(com.discover.mobile.common.R.id.img_update_available)).check(matches(allOf(
                hasDrawable(), // Check ImageView has a drawable set with a custom matcher
                isDisplayed())));


        //onView(withId(com.discover.mobile.common.R.id.no_update_available_view)).check(matches(isDisplayed()));
    }

    @Test
    public void clickLoginButton_opensHomeUi() throws Exception {

        String userId = "uid@4918";
        String password = "ccccc";

        // Add note title and description
        onView(withId(com.discover.mobile.common.R.id.username_field)).perform(typeText(userId)); // Type new note title
        onView(withId(com.discover.mobile.common.R.id.password_field)).perform(typeText(password),
                closeSoftKeyboard()); // Type new note description and close the keyboard

        // Click on Login
        onView(withId(com.discover.mobile.common.R.id.tv_login_lable)).perform(click());

        // After this call Login service and check if Home page is displayed.
    }

}

