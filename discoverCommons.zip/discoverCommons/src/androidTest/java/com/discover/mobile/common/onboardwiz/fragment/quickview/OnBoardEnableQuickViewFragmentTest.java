package com.discover.mobile.common.onboardwiz.fragment.quickview;

import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.shared.utils.CommonUtils;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import android.support.test.espresso.ViewAction;
import android.support.test.espresso.action.GeneralLocation;
import android.support.test.espresso.action.GeneralSwipeAction;
import android.support.test.espresso.action.Press;
import android.support.test.espresso.action.Swipe;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

/**
 * Created by 494005 on 5/9/2016.
 */
@RunWith(AndroidJUnit4.class)
@LargeTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OnBoardEnableQuickViewFragmentTest {

    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }

    @Rule
    public ActivityTestRule<OnBoardActivity> mActivityTestRule =
            new ActivityTestRule<OnBoardActivity>(OnBoardActivity.class);

    public static ViewAction swipeRight() {
        return new GeneralSwipeAction(Swipe.FAST, GeneralLocation.CENTER_RIGHT,
                GeneralLocation.CENTER_LEFT, Press.FINGER);
    }

    public static ViewAction swipeLeft() {
        return new GeneralSwipeAction(Swipe.FAST, GeneralLocation.CENTER_LEFT,
                GeneralLocation.CENTER_RIGHT, Press.FINGER);
    }

    @Before
    public void setUp() {
        OnBoardHelper.disposeVehicles();
        onView(withId(com.discover.mobile.common.R.id.btnGetStarted)).perform(click());
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        onView(withId(com.discover.mobile.common.R.id.root_enable_passcode_view)).perform(swipeRight());
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Tests if application gets navigated to QV page.
     */
    @Test
    public void test0isNavigatedToQV() {
//        mActivityTestRule.getActivity()
    }

    /**
     * checks if swiping is enabled at this QV page i.e. user should be able to swipe to/from left
     * to /from right.
     **/
    @Test
    public void test1isSwippableRightLeft() {
        onView(withId(com.discover.mobile.common.R.id.qv_main_view)).perform(swipeLeft());
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        onView(withId(com.discover.mobile.common.R.id.root_enable_passcode_view)).perform(swipeRight());
    }

    /**
     * Checks the enablement message dipsplayed at top of screen is correct of not.
     */
    @Test
    public void test2hasEnablementMessage() {

        String enablementMessage = mActivityTestRule.getActivity().getResources().getText(com.discover.mobile.common.R.string.onboard_quickview_landing_text).toString();//"Use Quick View to check your\\n account balance without logging in";//

        onView(withId(com.discover.mobile.common.R.id.setup_qv_text)).check(matches(isDisplayed()));
        onView(withText(enablementMessage));
    }

    /**
     * validates the enablement info message that appeares at bottom of screen.
     */
    @Test
    public void test3hasEnablementInfo() {

        String infoMessage = mActivityTestRule.getActivity().getResources().getText(com.discover.mobile.common.R.string.onboard_quickview_bottom_copy).toString();//"On your login screen, you can quickly check your balance.";
        ;//getText(R.id.onboard_quickview_bottom_copy);

        onView(withId(com.discover.mobile.common.R.id.text_quickview)).check(matches(isDisplayed()));
        onView(withText(infoMessage));
    }

    /**
     * checks if enable button is getting displayed at screen.
     */
    @Test
    public void test4hasEnableButton() {

        onView(withId(com.discover.mobile.common.R.id.qvEnable)).check(matches(isDisplayed()));

    }

    /**
     * validates enablment top message color.
     */
    @Test
    public void test5enablementMessageColor() {

        onView(withId(com.discover.mobile.common.R.id.setup_qv_text)).check(matches(isDisplayed()));
        //TODO get the color code and asset it to expected
    }

    /**
     * validates enable button color.
     */
    @Test
    public void test6enableButtonColor() {

        onView(withId(com.discover.mobile.common.R.id.qvEnable)).check(matches(isDisplayed()));
        //TODO get the color code and asset it to expected
    }

    /**
     * validates enablment info bottom message color.
     */
    @Test
    public void test7enablementInfoColor() {

        onView(withId(com.discover.mobile.common.R.id.text_quickview)).check(matches(isDisplayed()));
        //TODO get the color code and asset it to expected
    }
}
