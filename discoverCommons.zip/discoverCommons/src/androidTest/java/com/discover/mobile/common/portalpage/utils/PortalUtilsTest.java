package com.discover.mobile.common.portalpage.utils;

import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.utils.CommonUtils;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Context;
import android.os.Looper;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;


@RunWith(AndroidJUnit4.class)
public class PortalUtilsTest {

    private static Context testContext = null;

    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }

    @Rule
    public ActivityTestRule<LoginActivity> loginActivity =
            new ActivityTestRule<LoginActivity>(LoginActivity.class);
    /*@Override
    protected void setUp() throws Exception {
        super.setUp();
        if (testContext == null) {
            testContext = getInstrumentation().getContext();
        }
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }*/
    private LoginActivity mReceiptCaptureActivity;

    @Before
    public void setUp() throws Exception {
        mReceiptCaptureActivity = loginActivity.getActivity();
    }

    @After
    public void tearDown() throws Exception {
        // Call finish() on all activities in @After to avoid exceptions in
        // later calls to getActivity() in subsequent tests
        mReceiptCaptureActivity.finish();
    }

    @Test
    public void testPreconditions() {
        assertNotNull(mReceiptCaptureActivity);
    }

    @Test
    public void testGetPortalAccountDetails() {


        NetworkRequestListener nrl = new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                //TODO need to call oob
                assertNotNull(data);
            }

            @Override
            public void onError(Object data) {
                //TODO need to call oob
                FacadeFactory.getPortalPageFacade().handleErrorScenario(
                        loginActivity.getActivity().getContext(), data);
            }
        };
        //LoginActivity mMainActivity = getActivity();

        Looper.prepare();

        PortalUtils.getPortalAccountDetails(loginActivity.getActivity(), "karunkumar8447", "sai-sai1", nrl, false);
    }

    @Test
    public void testGetBaseURL() {
        String url = PortalUtils.getBaseUrl();
        assertEquals("https://mapi.discovercard.com", url);
    }
}
