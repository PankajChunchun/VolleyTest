package com.discover.mobile.common.onboardwiz.fragment.passcode;

import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.shared.utils.CommonUtils;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

/**
 * Created by 409992 on 5/3/2016.
 */
@RunWith(AndroidJUnit4.class)
@LargeTest
public class OnBoardSuccessFragmentTest {

    @BeforeClass
    public static void initialize() {
        CommonUtils.isOfflinemode = true;
    }

    @Rule
    public ActivityTestRule<OnBoardActivity> mActivityTestRule =
            new ActivityTestRule<OnBoardActivity>(OnBoardActivity.class);
    private String mValidateString1, mValidateString2, mValidateString3;

    @Before
    public void initString() {
        mValidateString1 = "Your Passcode has been enabled on this device. The next time you open the Discover app, you'll be asked to log in with Passcode.";
        mValidateString2 = "Remember, you can edit your app settings at any time through the Profile & Settings option in the menu.";
        mValidateString3 = "Passcode is now enabled";
    }

    @Test
    public void testFragmentViewStrings() throws Exception {
        onView(withText(mValidateString1));

        try {
            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        onView(withText(mValidateString2));
        onView(withText(mValidateString3));
    }

}
