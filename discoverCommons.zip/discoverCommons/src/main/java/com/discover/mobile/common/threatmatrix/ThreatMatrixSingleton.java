package com.discover.mobile.common.threatmatrix;

import com.discover.mobile.common.R;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.threatmetrix.TrustDefenderMobile.Config;
import com.threatmetrix.TrustDefenderMobile.ProfilingOptions;
import com.threatmetrix.TrustDefenderMobile.ProfilingResult;
import com.threatmetrix.TrustDefenderMobile.THMStatusCode;
import com.threatmetrix.TrustDefenderMobile.TrustDefenderMobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * ThreatMatrixSingleton is created to have Threat Matrix API integrated to application.
 * Singleton is chosen in order to:
 * a) Keep all Threat Matrix related API calls in single class.
 * b) As it does some resource consuming process tried to have only once instance for easy
 * maintenance.
 */
public class ThreatMatrixSingleton implements ProfilingResultListener {

    /** Singleton Section Starts **/
    private static ThreatMatrixSingleton mInstance = null;
    private static Object mLock = new Object();
    private static ArrayList<String> mEndPoints = null;
    /** Threat Matrix Specific Implementation **/
    private final String TAG = ThreatMatrixSingleton.class.getSimpleName();
    private final String THREAT_MATRIX_LOCATION_TAG = "THREAT_MATRIX_LOCATION";
    /** Singleton Section Ends **/
    private final int TIME_OUT_DURATION = 10;
    private final String THREAT_MATRIX_KILL_SWITCH_SHARED_PREF_NAME = "THREAT_METRIX_KILL_SWITCHES";
    private final String IGNORE_DO_PACKAGE_SCAN = "IgnoreDoPackageScan";
    private final String IGNORE_GET_SESSION_ID = "IgnoreGetSessionID";
    private String TRUST_DEFENDER_ORG_ID = null;
    private TrustDefenderMobile profile = null;
    private Config configObj = null;
    private ProfilingOptions profilingOptions = null;
    private Context mContext;
    private THMStatusCode status = null;
    /*TEMP CHANGES :: Starts	*/
    //Change this flag to false if the pop up should be displayed.
    private boolean isShown = true;
    /* Share Preference Implementation:: Start*/
    private boolean mIgnoreDoPackageScan = false;
    private boolean mIgnoreGetSessionID = false;

    /**
     * The private map to store the singleton objects
     */

    private ThreatMatrixSingleton() {

    }

    public static ThreatMatrixSingleton Instance() {

        synchronized (mLock) {
            if (mInstance == null) {
                mInstance = new ThreatMatrixSingleton();
            }
            return mInstance;
        }
    }

    public void init(Context context) {
        this.mContext = context;
        fetchTMXKillsSwitchFromSharedPref();
        TRUST_DEFENDER_ORG_ID = context.getString(R.string.tmx_orgid);
        initProfiling();
        addEndPoints();
    }

    public void initProfiling() {
        initObjects();


        // These things all only need to happen once in the lifetime of the
        // TrustDefenderMobile object,
        // so ideally once per the lifetime of the application.
        // Note that the only required Config setting is the context. Everything
        // else is optional.
        // In the following example, we set a timeout, register for location
        // services, pass the context,
        // configure the profiling server URL and register a callback for when
        // the profile completes
        // It is mandatory to call init() and pass a context.
        this.profile.init(configObj);
    }

    private void initObjects() {
        if (this.profile == null) {
            this.profile = new TrustDefenderMobile(TRUST_DEFENDER_ORG_ID);
        }

        if (configObj == null) {
            configObj = new Config()
                    .setTimeout(TIME_OUT_DURATION)
                    .setContext(mContext)
                    .setEndNotifier(this);
        }

        initProfilingOptionWithLocation();
    }

/* TEMP CHANGES :: Ends*/

    private void initProfilingOptionWithLocation() {

        profilingOptions = null;
        boolean isLocationEnabled = FacadeFactory.getLocationFacade().getLocationServicesPreference(mContext);
        if (isLocationEnabled) {
            Location myLocation = new Location(THREAT_MATRIX_LOCATION_TAG);
            profilingOptions = new ProfilingOptions().setLocation(myLocation);
        }
    }

    public void doProfile() {

        if (mIgnoreGetSessionID == false) {
            if (profilingOptions == null) {
                status = this.profile.doProfileRequest();
            } else {
                status = this.profile.doProfileRequest(profilingOptions);
            }
        }
    }

    public String getSessionID() {
        Log.d(TAG, "Using: " + TrustDefenderMobile.version);

        String strSessionID = null;
        if (mIgnoreGetSessionID == false) {
            if (status == THMStatusCode.THM_OK) {
                strSessionID = this.profile.getResult().getSessionID();
            }
        }
        Log.d(TAG, "Inside getSessionID() getSessionID: " + strSessionID);
        return strSessionID;
    }

    public String getSessionID(boolean showDialog, final String url, Context context) {
        final String strSessionID = getSessionID();
        this.mContext = context;
        if (showDialog) {
            if (isShown == false) {
                DiscoverActivityManager.getActiveActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        showDialogMessage(strSessionID, url);
                    }
                });
            }
        }
        return strSessionID;
    }

    private void showDialogMessage(final String strSessionID, String url) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("For testing purpose\n");
        stringBuilder.append(url + "\n\n" + strSessionID);
        Toast.makeText(mContext, stringBuilder.toString(), Toast.LENGTH_LONG).show();

		/*AlertDialog dialog = null;
		AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
		builder.setTitle("For testing purpose")
		.setMessage(url+"\n\n"+strSessionID)
		.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.dismiss();
			}
		});
		dialog = builder.create();
		dialog.show();*/
    }

    @Override
    public void complete(ProfilingResult result) {
        if (mIgnoreDoPackageScan == false) {
            if (profile != null) {
                // Regardless of profiling state, fire off a package scan
                profile.doPackageScan(0);
            }
        }
    }

    public void onDispose() {
        Log.d(TAG, "onDispose() called");

        if (profile != null) {
            profile.tidyUp();
        }

        configObj = null;
        profilingOptions = null;

    }

    private void addEndPoints() {
        mEndPoints = new ArrayList<String>();
        mEndPoints.add(mContext.getString(R.string.forgot_both_url));
        mEndPoints.add(mContext.getString(R.string.forgot_password));
        mEndPoints.add(mContext.getString(R.string.forgot_userid));
        mEndPoints.add(mContext.getString(R.string.loginurl));
        mEndPoints.add(mContext.getString(R.string.loginV4url));
        mEndPoints.add(mContext.getString(R.string.sso_authentication));
    }

    public boolean hasEndPointAvailable(String stringUrl) {
        boolean hasEndPoint = false;
        char endPointEndsWith = ' ';
        String strDotCom = ".com/";
        for (String endPoint : mEndPoints) {
            //if(stringUrl !=null && stringUrl.contains(endPoint))
            int indexOfCom = stringUrl.indexOf(strDotCom);
            int expectedIndexOfEndPoint = stringUrl.indexOf(endPoint);

            int indexDotCom = indexOfCom + strDotCom.length() - 1;
            int indexEndPoint = expectedIndexOfEndPoint;


            if (indexDotCom == indexEndPoint) {

                int actualEndOfEndPoint = expectedIndexOfEndPoint + endPoint.length();
                if (stringUrl.length() > actualEndOfEndPoint)
                    endPointEndsWith = stringUrl.charAt(actualEndOfEndPoint);
                if (endPointEndsWith == ' ' || endPointEndsWith == '?') {
                    hasEndPoint = true;
                }
            }
        }
        return hasEndPoint;
    }

    public void setDoPackageScanKillSwitch(boolean ignoreDoPackageScan) {
        mIgnoreDoPackageScan = ignoreDoPackageScan;
        SharedPreferences prefs = mContext.getSharedPreferences(THREAT_MATRIX_KILL_SWITCH_SHARED_PREF_NAME, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(IGNORE_DO_PACKAGE_SCAN, mIgnoreDoPackageScan);
        editor.commit();
    }

    public boolean getGetSessionIDKillSwitch() {
        SharedPreferences prefs = mContext.getSharedPreferences(THREAT_MATRIX_KILL_SWITCH_SHARED_PREF_NAME, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        mIgnoreGetSessionID = prefs.getBoolean(IGNORE_GET_SESSION_ID, false);
        editor.commit();
        return mIgnoreGetSessionID;
    }

    public void setGetSessionIDKillSwitch(boolean ignoreGetSessionID) {
        mIgnoreGetSessionID = ignoreGetSessionID;

        SharedPreferences prefs = mContext.getSharedPreferences(THREAT_MATRIX_KILL_SWITCH_SHARED_PREF_NAME, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(IGNORE_GET_SESSION_ID, mIgnoreGetSessionID);
        editor.commit();
    }

    public void fetchTMXKillsSwitchFromSharedPref() {

        SharedPreferences prefs = mContext.getSharedPreferences(THREAT_MATRIX_KILL_SWITCH_SHARED_PREF_NAME, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        mIgnoreDoPackageScan = prefs.getBoolean(IGNORE_DO_PACKAGE_SCAN, false);
        mIgnoreGetSessionID = prefs.getBoolean(IGNORE_GET_SESSION_ID, false);
    }
	/* Share Preference Implementation:: End*/
}
