package com.discover.mobile.common.shared.net.json;

import com.discover.mobile.common.R;
import com.discover.mobile.common.shared.facade.SharedFacadeFactory;
import com.discover.mobile.common.shared.net.error.ErrorResponseParser;
import com.discover.mobile.common.shared.utils.image.Utils;

import org.json.JSONObject;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;

public class JsonMessageErrorResponseParser implements ErrorResponseParser<JsonMessageErrorResponse> {

    private static final String MIME_JSON = "application/json";
    public JSONObject errorJsonObject;

    private static boolean isParseableContentType(final HttpURLConnection conn) {
        return MIME_JSON.equalsIgnoreCase(conn.getContentType());
    }

    private static boolean doesntHaveDeclaredContent(final HttpURLConnection conn) {
        return conn.getContentLength() == 0;
    }

    private static boolean inputStreamHasContent(final InputStream in) throws IOException {
        if (!in.markSupported()) {
            throw new UnsupportedOperationException("Not able to handle non-markable InputStreams");
        }

        in.mark(2);
        final int result = in.read();
        in.reset();

        return result >= 0;
    }

    /**
     * convert the input stream in to string
     *
     * @param in is InputStream
     * @return converted String
     */
    private static String fromStream(final InputStream in) throws IOException {
        final BufferedReader reader = new BufferedReader(new InputStreamReader(
                in));
        final StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            out.append(line);
        }
        return out.toString();
    }

    private static String fromRawResource(Context context, int rawResourceId) {
        String json = null;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        byte bufferByte[] = new byte[1024];
        int length;
        try {
            InputStream inputStream = context.getResources()
                    .openRawResource(rawResourceId);
            while ((length = inputStream.read(bufferByte)) != -1) {
                outputStream.write(bufferByte, 0, length);
            }
            json = outputStream.toString();
            outputStream.close();
            inputStream.close();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return json;
    }

    public JSONObject getResult() {
        return errorJsonObject;
    }

    public void setResult(JSONObject result) {
        this.errorJsonObject = result;
    }

    @Override
    public JsonMessageErrorResponse parseErrorResponse(final int httpStatusCode, final InputStream errorStream,
                                                       final HttpURLConnection conn) throws IOException {

        if (!isParseableContentType(conn) || doesntHaveDeclaredContent(conn) || !inputStreamHasContent(errorStream)) {
            return null;
        }

        String data = fromStream(errorStream);
        return (JsonMessageErrorResponse) Utils.getObjectFromJSONString(data, JsonMessageErrorResponse.class);

    }

    /**
     * @param json outputStream
     */
    public void parseErrorResponse(Context context, OutputStream errorStream) throws IOException {
        try {
            errorJsonObject = new JSONObject(errorStream.toString());
        } catch (Exception e) {
            Log.v("JsonMessageErrorResponseParser", "error in parsing json output stream ", e);
            try {
                errorJsonObject = new JSONObject(fromRawResource(context, R.raw.error));
            } catch (Exception e1) {
                Log.v("JsonMessageErrorResponseParser", "error in parsing raw-resource/null to json object ", e);
                e1.printStackTrace();
            }
        } finally {
            SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(context, errorJsonObject);
        }
    }

    /**
     * @param json   outputStream
     * @param String key
     */
    public void parseResponse(Context context, final OutputStream errorStream, String key) throws IOException {
        if (errorStream != null) {
            try {
                if (key.equalsIgnoreCase(context.getResources().getString(R.string.android_pay_file_key))) {
                    SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(context, errorStream.toString(), key);
                } else {
                    errorJsonObject = new JSONObject(errorStream.toString());
                    SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(context, errorJsonObject, key);
                }
            } catch (Exception e) {
                Log.v("JsonMessageErrorResponseParser", "error in parsing json output stream ", e);
            }
        }
    }

}
