package com.discover.mobile.common.appupdate.ui;

import com.discover.mobile.common.DiscoverModalManager;
import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.appupdate.beans.AppVersionNumber;
import com.discover.mobile.common.appupdate.service.AppVersionService;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.nav.DrawerBaseActivity;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.ui.modals.EnhancedContentModal;
import com.discover.mobile.network.error.bean.ErrorBean;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

/**
 * Get application version from server. This class uses its own
 * {@link com.discover.mobile.common.shared.net.NetworkRequestListener} to handle
 * {@link com.discover.mobile.common.shared.net.NetworkRequestListener#onSuccess(Object)} and
 * {@link com.discover.mobile.common.shared.net.NetworkRequestListener#onError(Object)}  for
 * prelogin and postlogin calls.
 *
 * @author pkuma13
 */
public class AppVersionRequest {
    private static final String TAG = AppVersionRequest.class
            .getSimpleName();
    private Context mContext;
    private NetworkRequestListener mListener;
    private boolean isCard;
    private boolean isPreLogin;

    /**
     * Constructor to set {@link Context} and {@link NetworkRequestListener}.
     *
     * @param context - {@link Context}k
     */
    public AppVersionRequest(Context context, boolean isPreLogin) {
        this.mContext = context;
        this.isPreLogin = isPreLogin;
        this.mListener = new VersonNameRequestListener(context);
    }

    /**
     * Do service call to get application version. Caller will get result into
     * callback methods of {@link NetworkRequestListener}.
     */
    public void sendRequest() {
        AppVersionService appVersionService = new AppVersionService(mContext);
        appVersionService.getAppVersionRequest(mListener);


    }

    public void showCustomAlert(final AlertDialog alert) {
        DiscoverModalManager.setActiveModal(alert);
        DiscoverModalManager.setAlertShowing(true);
        alert.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alert.show();
        alert.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    /**
     * A {@link NetworkRequestListener} class which listens for service request call
     * back for version number. This {@link NetworkRequestListener} handles pre-login
     * and post-login calls with calling {@link Context}.
     *
     * @author pkuma13
     */
    private final class VersonNameRequestListener implements NetworkRequestListener {

        private Context mContext;

        public VersonNameRequestListener(Context context) {
            mContext = context;
        }

        @Override
        public void onSuccess(Object data) {
            if (data != null) {
                boolean isUpdateAvailable = isUpdateAvailable(((AppVersionNumber) data)
                        .getVersion_number());
                // Show UI depends on update available status

                showUpdateStatusScreen(isUpdateAvailable);
            } else {
                onError(data);
            }
        }

        @Override
        public void onError(Object data) {
            if (data == null) {

            } else {
                // Check if service was called from pre or post login to show
                // error message to user.
                if (mContext instanceof DrawerBaseActivity) {
//                    CardErrorHandlerImpl genericErrorHandler = new CardErrorHandlerImpl(
//                            null);
//                    genericErrorHandler
//                            .handleError(mContext, (ErrorBean) data);

                    FacadeFactory.getPortalPageFacade().handleErrorScenario(
                            mContext, data);

                } else {
                    handlePreLoginError(data);
                }
            }
        }

        /**
         * Compares application version with the version which get from service
         * call.
         *
         * @param latestVersion - Version name from server.
         * @return <code>true</code> if latestVersion is greater than the
         * application version, otherwise it returns <code>false</code>.
         */
        private boolean isUpdateAvailable(String latestVersion) {
            boolean isUpdateAvailable = false;
            // Get current version name form device
            String version = null;

            try {
                version = mContext.getPackageManager().getPackageInfo(
                        mContext.getPackageName(), 0).versionName;
            } catch (NameNotFoundException e) {

            }

            AppVersionNumber versionOnDevice = new AppVersionNumber();
            versionOnDevice.setVersion_number(version);
            AppVersionNumber versionFromServer = null;
            if (latestVersion != null) {
                versionFromServer = new AppVersionNumber();
                versionFromServer.setVersion_number(latestVersion);
                int status = versionFromServer.compareTo(versionOnDevice);
                if (status == 1) {
                    // Update available on server
                    isUpdateAvailable = true;
                }
            }
            return isUpdateAvailable;
        }

        /**
         * Show update available or update not available screen. This method
         * starts {@link UpdateAppActivity} if {@link AppVersionRequest} is
         * called from pre-login. In case of post login it starts
         * {@link UpdateAppFragment}.
         *
         * @param isUpdateAvailable - tells that application update available or not.
         */
        private void showUpdateStatusScreen(boolean isUpdateAvailable) {
            if (Utils.isRunningOnHandset(mContext)) {
                isCard = LoginActivity.isCardChecked;
                Bundle args = new Bundle();
                args.putBoolean(UpdateAppFragment.KEY_UPDATE_AVAILABLE,
                        isUpdateAvailable);

                if (mContext instanceof DrawerBaseActivity) {
                    UpdateAppFragment appFragment = new UpdateAppFragment();
                    args.putBoolean(UpdateAppFragment.KEY_ISCARD, true);
                    args.putBoolean(UpdateAppFragment.KEY_ISPRELOGIN, isPreLogin);
                    appFragment.setArguments(args);
                    ((DrawerBaseActivity) mContext).makeFragmentVisible(appFragment);
                } else {
                    Intent intent = new Intent(mContext, UpdateAppActivity.class);
                    args.putBoolean(UpdateAppFragment.KEY_ISCARD,
                            isCard);
                    args.putBoolean(UpdateAppFragment.KEY_ISPRELOGIN, isPreLogin);
                    intent.putExtras(args);

                    //Changes done as part of Login migration we are getting exception as we have changed super class to NotLoggedInRoboActivity from NavigationRootActivity.
                    //Changes start
                    mContext.startActivity(intent);
                    //Changes ends
                }
            } else {

                if (isUpdateAvailable) {
                    UpdateAppAvailableModal modal = new UpdateAppAvailableModal(mContext);
                    // TODO Need to be clear about below used attributes
                    DiscoverModalManager.setActiveModal(modal);
                    DiscoverModalManager.setAlertShowing(true);
                    modal.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    modal.show();
                } else {
                    FragmentManager fm = null;
                    if (mContext instanceof LoginActivity) {
                        fm = ((LoginActivity) mContext).getFragmentManager();
                    } else {
                        fm = ((Activity) mContext).getFragmentManager();
                    }

                    NoUpdateAppAvailableModal dialogFragment = new NoUpdateAppAvailableModal();
                    dialogFragment.show(fm, "passcode_info_dialog");
//                    NoUpdateAppAvailableModal modal = new NoUpdateAppAvailableModal(mContext);
//                    // TODO Need to be clear about below used attributes
//                    DiscoverModalManager.setActiveModal(modal);
//                    DiscoverModalManager.setAlertShowing(true);
//                    modal.requestWindowFeature(Window.FEATURE_NO_TITLE);
//                    modal.show();

                }
            }
        }

        /**
         * Handles error if {@link AppVersionRequest} called from pre-login
         * and service call gets failed.
         */
        private void handlePreLoginError(Object data) {
            int statusInt = -1;
           /* commented for implementing ErrorBeans by 471532*/

           /* CardErrorBean cardError = (CardErrorBean) data;*/
            if (null == data)
            {
                showSystemErrorMessage();
                PortalUtils.hideSpinner(mContext);
                return;
            }
            ErrorBean appUpdateErrorBean = (ErrorBean) data;
            ErrorResponseDetails appUpdateErrorResp = (ErrorResponseDetails) ((ErrorBean) appUpdateErrorBean).getErrorResponseHolder();
            if (null == appUpdateErrorResp || null == appUpdateErrorResp.status)
            {
                showSystemErrorMessage();
                PortalUtils.hideSpinner(mContext);
                return;
            }

            String status = appUpdateErrorResp.status;

            try {
                statusInt = Integer.parseInt(status);
            }catch(NumberFormatException ne){
                statusInt = -1;
            }


            if (null != appUpdateErrorBean && statusInt == UpdateAppConstants.Error.INTERNET_OFFLINE_ERROR
                    || status.startsWith("503")) {

                if (Integer.parseInt(status) == UpdateAppConstants.Error.INTERNET_OFFLINE_ERROR) {
                    final EnhancedContentModal modal1 = new EnhancedContentModal(mContext, R.string.E_T_4242, R.string.E_4242, R.string.close_text, null);
                    //Changes done as part of Login migration we are getting exception as we have changed super class to NotLoggedInRoboActivity from NavigationRootActivity.
                    //changes start
                    showCustomAlert(modal1);
                    //changes ends

                } else if (status.contains(
                        UpdateAppConstants.Error.SCHEDULED_MAINTANANCE_ERROR)) {
//                    final EnhancedContentModal modal1 = new EnhancedContentModal(
//                            mContext,
//                            R.layout.dialog_scheduled_maintanace_view,
//                            R.string.ok, null, null);
                    //Changes done as part of Login migration we are getting exception as we have changed super class to NotLoggedInRoboActivity from NavigationRootActivity.
                    //Changes start
                    final EnhancedContentModal modal1 = new EnhancedContentModal(mContext, R.string.E_T_5031006, R.string.mop_scheduled_maintainace_text, R.string.close_text, null);
                    showCustomAlert(modal1);
                    //Changes ends
                } else if (status
                        .contains(
                                UpdateAppConstants.Error.UN_SCHEDULED_MAINTANANCE_ERROR)) {
//                    final EnhancedContentModal modal1 = new EnhancedContentModal(
//                            mContext,
//                            R.layout.dialog_unscheduled_maintainace_view,
//                            R.string.ok, null, null);
//                    //Changes done as part of Login migration we are getting exception as we have changed super class to NotLoggedInRoboActivity from NavigationRootActivity.
//                    //Changes start
                    final EnhancedContentModal modal1 = new EnhancedContentModal(mContext, R.string.E_T_5031007, R.string.mop_un_scheduled_maintainace_text, R.string.close_text, null);
                    showCustomAlert(modal1);
                    //Changes ends
                } else {
                    showSystemErrorMessage();
                }
            } else {
                showSystemErrorMessage();
            }
            PortalUtils.hideSpinner(mContext);
        }

        /**
         * This method is responsible to show system error message to screen
         */
        private void showSystemErrorMessage() {
            // TODO Set generic error message here.
//            Utils.log(TAG, "got error while requesting for version number");
        }
    }
}