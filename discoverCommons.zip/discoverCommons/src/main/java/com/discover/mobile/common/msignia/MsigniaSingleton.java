package com.discover.mobile.common.msignia;

import android.content.Context;
import android.content.SharedPreferences;


import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.net.ServiceCallSessionManager;
import com.discover.mobile.common.shared.utils.DeviceUtils;
/*import com.msignia.core.IDNAAuth;
import com.msignia.core.Environment;
import com.msignia.core.ServerUrl;*/

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by asharm4 on 1/20/2017.
 */
public class MsigniaSingleton {
    private static MsigniaSingleton mInstance = null;
    private Context mContext;
    private boolean msigniaEnrolled;
    //private IDNAAuth indaAuthObj = null;
    private String msigniaAppKey = "";
    private boolean msigniaKillSwitchVal = false;

    private MsigniaSingleton() {

    }

    public static MsigniaSingleton Instance() {
        if (mInstance == null) {
            mInstance = new MsigniaSingleton();
        }
        return mInstance;
    }

    public void init(Context context) {
        this.mContext = DiscoverActivityManager.getDiscoverApplicationContext();
        if(!getMsigniaKillSwitchVal()) {
            msigniaAppKey = mContext.getResources().getString(R.string.msignia_app_key);
            /*if (indaAuthObj == null) {
                indaAuthObj = new IDNAAuth(mContext, msigniaAppKey, Environment.production);

                msigniaEnrolled = indaAuthObj.isEnrolled(mContext);
            }*/
/*            String accountID = DeviceUtils.getDeviceId(mContext);
            List<ServerUrl> serverUrls = indaAuthObj.getPossibleServerUrls();

            for (ServerUrl serverUrl : serverUrls) {
                if (serverUrl.getServerType() == ServerUrl.ServerType.api && serverUrl.getEnvironment().equals(mContext.getResources().getString(R.string.msignia_env_string))) {
                    indaAuthObj.setServerUrl(serverUrl);
                }
            }*/
        }

        /*MSignia POC End*/
    }

    /*public IDNAAuth getIDNAAuthObject(Context context){
        if(indaAuthObj == null){
            indaAuthObj = new IDNAAuth(mContext, msigniaAppKey, Environment.production);
        }
        return indaAuthObj;
    }*/

    public boolean isMsigniaEnrolled(Context context){
        /*if(indaAuthObj != null){
            msigniaEnrolled = indaAuthObj.isEnrolled(context);
        }*/
        return msigniaEnrolled;
    }


    public void sendMSigniaDataSuccess(Context context){
        if(!msigniaKillSwitchVal){
            final String accountID =  DeviceUtils.getDeviceId(context);
            Utils.log("MSIGNIA", "- Device ID--" + accountID);
            String dfskeyDis = ServiceCallSessionManager.getEDSKey();
            Map<String, String> extras = new HashMap<>();
            extras.put("dfsedskey", dfskeyDis);
            /*getIDNAAuthObject(context).sendData(context, accountID, extras);
            String mdid =  MsigniaSingleton.Instance().getIDNAAuthObject(context).getMDID(context);*/
        }
    }

    public void sendMSigniaDataFail(Context context){
        sendMSigniaDataFail(context,null);
    }

    public void sendMSigniaDataFail(Context context,String edskey){
        if(!msigniaKillSwitchVal){
            final String accountID =  DeviceUtils.getDeviceId(context);
            Utils.log("MSIGNA", "- Device ID--" + accountID);
            Map<String, String> extras = new HashMap<>();
            extras.put("dfsedskey", edskey);
            /*getIDNAAuthObject(context).sendData(context, accountID, extras);
            String mdid =  getIDNAAuthObject(context).getMDID(context);*/
        }
    }

    public boolean getMsigniaKillSwitchVal() {
        return true;
    }

    public void setMsigniaKillSwitchVal(boolean killswitchEnabled) {
        this.msigniaKillSwitchVal = killswitchEnabled;
    }

}
