package com.discover.mobile.common;

public class Constants {

    public static final String APP_MSG_INTERACTION_VIEW = "view";
    public static final String APP_MSG_INTERACTION_TAP = "tap";

    ;
    public static String PROFILE_SETTINGS_SHARED_PREF = "profileSettingsPref";
    public static String PROFILE_SETTINGS_PASSCODE = "profile_settings_passcode";
    public static String PROFILE_SETTINGS_QUICKVIEW = "profile_settings_quickview";
    public static String PROFILE_SETTINGS_QUICKVIEW_WIDGET = "profile_settings_quickview_widget";
    public static String PROFILE_SETTINGS_ANROID_WEAR = "profile_settings_wear";
    public static String PROFILE_SETTINGS_LOCATION_SERVICES = "profile_settings_location_service";
    public static String PROFILE_SETTINGS_CURRENT_USER_ID = "profile_settings_current_user_id";
    public static String PROFILE_SETTINGS_INVALID_USER_ID = "ACCOUNT_NUMBER";
    public static String CURRENT_MASTER_FRAGMENT = "currentMasterFragment";
    public static String BB_REDIRECT_ANALYTICS = "SCMobileOrigin=AndroidMobile";
    /*Adding string for fingerprint U70151*/
    public static String PROFILE_SETTINGS_FINGERPRINT = "profile_settings_fingerprint";

    public static String  STATUS_E_401= "E_401";
    public static String  STATUS_401= "401";

    /*App Message Contstants*/
    public static String APP_MSG_LEVEL_TWO = "level2";
    public static String APP_MSG_LEVEL_THREE = "level3";
    //Adding Fingerprint enum for US71615
    public static enum PROFILE_SETTINGS_KEY {PASSCODE, QUICKVIEW, QUICKVIEW_WIDGET, ANDROID_WEAR, LOCATION_SERVICES, FINGER_PRINT}
    public static enum MASTER_LAYOUT_TYPE {WITH_HEADER, WITHOUT_HEADER}

    /* START VOC-53603- Force upgrade prefrence value */

    public static String ACTION_NETWORK_CHANGE = "INTERNET_DATA_CONNECTED";

    public static String FORCE_UPGRADE_SHARED_PREF = "FORCE_UPGRADE_PREF";
    public static String IS_FORCE_UPGRADE = "isforceUpGrade";
    public static String FORCE_UPGRADE_HEADER = "header";
    public static String FORCE_UPGRADE_MESSAGE = "message";
    public static String FORCE_UPGRADE_REDIRECT_TITLE = "redirectTitle";
    public static String FORCE_UPGRADE_REDIRECT_URL = "redirectUrl";
    /* END VOC-53603- Force upgrade prefrence value */
}
