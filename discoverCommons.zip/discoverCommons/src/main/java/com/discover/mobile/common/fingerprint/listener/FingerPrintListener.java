package com.discover.mobile.common.fingerprint.listener;

/**
 * Created by 548022 on 8/31/2016.
 * Interface to listen to Fingerprint callback events.
 */
public interface FingerPrintListener {


    /**
     * Calls when fingerprint is authenticated.
     */
    void onAuthenticated();


    /**
     * Calls to guide user for good quality fingerprint.
     * @param helpString
     */
    void onAuthenticationHelp(String helpString);


    /**
     * Calls when there is error authenticating fingerprint.
     * @param errMessage
     */
    void onError(String errMessage);
}
