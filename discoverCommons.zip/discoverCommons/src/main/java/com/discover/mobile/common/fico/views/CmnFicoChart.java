package com.discover.mobile.common.fico.views;


import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.fico.interfaces.GraphClickListner;
import com.discover.mobile.common.portalpage.utils.PortalUtils;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

import java.util.HashMap;


/**
 * Custom component for FICO-Graph
 */
public class CmnFicoChart extends View implements OnTouchListener {

    private int SIDEBAR_RIGHT_MARGIN = 15;
    private int SIDEBAR_TOP_MARGIN = 10;
    private int XAXIS_LABEL_TOP_MARGIN = 50;
    private int PLOT_VALUE_BOTTOM_MARGIN = 25;

    public static final int NO_ANIM = 1;

    RectF rectBubble, rectPopUp;
    Rect rectImageArea;
    Bitmap bmpSideBar;

    Point chartPoints[];

    Paint paint, mPaint;
    Paint paintC1 = null; // Paint for X -axis value, Y-axis value & Plot number
    Paint paintPlot = null;
    Paint paintFillPlot = null;
    Paint paintConnectDots = null;

    Point curPoint = new Point(-1, -1), lastPoint = new Point(-1, -1);
    int iMaxHeight = 550;

    int iAnimatedHeight[];
    int iAnimSpeed = 1;
    float fLastXposition = -10001;
    float fClickPosX = 200, fClickPosY = 200;
    int fXTranform = 0;
    int fViewWidth = 0, fMaxTransform = 1000;

    private int graphFillColor = Color.GRAY;
    boolean isGraphScrolled = false;
    private int iScrollRate = 20;
    private int fMarginTopBottom = 80;
    private int fMarginLeft = 150;
    private int iPillarGap = 80;
    private int fMarginRight = iPillarGap;
    private int iGraphLineColor = Color.BLUE;
    private int iBGColor = Color.WHITE;
    private int iLineColor = Color.GRAY;
    private int yAxisTextColor = Color.BLACK;
    private int iTopBottomLineColor = Color.DKGRAY;
    private int iFontSizeAxis = 20;
    private int cliclePlotColor = Color.BLACK;

    private int emptyCircleOffset = 1;
    private Paint paintPlotW;

    private int iStrokeValue = 2;
    private int circlePlotStroke = 2;
    private Typeface typeFace = null;
    private Path mPath;

    private int RADIUS = 10;
    private int HALF_RADIUS = RADIUS / 2;
    private int DIAMETER = RADIUS * 2;
    private int iClickedIndex = -1;
    private int latestMonthIndex = -1; // Index to highlight latest month to right side of Graph irrespective of its score value
    private int[] iSections = {300, 580, 670, 740, 850};
    private int[] iSectionHeights = {40, 28, 24, 32};
    private String[][] data = null;
    private Context mContext;
    private GraphClickListner clickListner = null;

    public CmnFicoChart(Context context) {
        super(context);
        initPaintAndPath(context);
    }

    public CmnFicoChart(Context context, AttributeSet attrs) {
        super(context, attrs);
        initPaintAndPath(context);
    }

    public CmnFicoChart(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initPaintAndPath(context);
    }

    /**
     * Returns paint for X, Y &Plot values Color & Font size
     */
    private Paint getC1Paint(Paint.Align align) {
        if (null == paintC1) {
            paintC1 = new Paint();
            paintC1.setColor(yAxisTextColor);
            paintC1.setStrokeWidth(4f);
            paintC1.setAntiAlias(true);
            paintC1.setTextSize(getFontSize());
        }
        paintC1.setTextAlign(align);
        return paintC1;
    }

    /**
     * Returns paint Circle plot on graph
     */
    private Paint getPlotPaint() {
        if (null == paintPlot) {
            paintPlot = new Paint();
            paintPlot.setColor(cliclePlotColor);
            paintPlot.setStrokeWidth(10f);
            paintPlot.setAntiAlias(true);
            paintPlot.setStyle(Paint.Style.STROKE);//without fill. Only stroke
        }
        return paintPlot;
    }

    /**
     * Returns paint Circle plot on graph
     */
    private Paint getPlotFillPaint() {
        if (null == paintFillPlot) {
            paintFillPlot = new Paint();
            paintFillPlot.setColor(cliclePlotColor);
            paintFillPlot.setStrokeWidth(10f);
            paintFillPlot.setAntiAlias(true);
            paintFillPlot.setStyle(Paint.Style.FILL_AND_STROKE);
        }
        return paintFillPlot;
    }

    /**
     * Returns paint Circle plot on graph for making empty circle
     * Added for Defect# 13639
     */
    private Paint getPlotPaintWhite() {
        if (null == paintPlotW) {
            paintPlotW = new Paint();
            paintPlotW.setColor(iBGColor);
            paintPlotW.setStrokeWidth(7f);
            paintPlotW.setAntiAlias(true);
            paintPlotW.setStyle(Paint.Style.FILL_AND_STROKE);//fill this with white color
        }
        return paintPlotW;
    }

    /**
     * Returns paint to connect dots on graph
     */
    private Paint getConnectDotsPaint() {
        if (null == paintConnectDots) {
            paintConnectDots = new Paint();
            paintConnectDots.setColor(iGraphLineColor);
            paintConnectDots.setStrokeWidth(2f);
            paintConnectDots.setAntiAlias(true);
        }
        return paintConnectDots;
    }

    private void initPaintAndPath(Context context) {
        mContext = context;
        iSectionHeights = getSectionHeights(context);
        paint = new Paint();
        setOnTouchListener(this);
        rectBubble = new RectF(-1, -1, -1, -1);
        rectImageArea = new Rect(-1, -1, -1, -1);
        rectPopUp = new RectF(-1, -1, -1, -1);
        bmpSideBar = BitmapFactory.decodeResource(context.getResources(), R.drawable.fico_graph_gradient);
    }


    /**
     * It converts sub-sections heights from DP to PX
     */
    private int[] getSectionHeights(Context context) {

        TypedArray ar = context.getResources().obtainTypedArray(R.array.cmn_graph_horizsec_heights);
        int len = ar.length();
        int[] dimensInPx = new int[len];

        for (int i = 0; i < len; i++) {
            dimensInPx[i] = ar.getDimensionPixelSize(i, 0);
        }
        ar.recycle();
        return dimensInPx;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        paint.reset();
        paint = new Paint();

        paint.setTextSize(getFontSize());
        paint.setStrokeWidth(iStrokeValue);
        canvas.drawColor(iBGColor);
        if (null != typeFace)
            paint.setTypeface(typeFace);

        final int iBottom = fMarginTopBottom + iMaxHeight;

        /** Draw Horizontal lines for Graph ; Y points */
        int i850Val = getPointAgainstValue(850, iBottom);
        int i740Val = getPointAgainstValue(740, iBottom);
        int i670Val = getPointAgainstValue(670, iBottom);
        int i580Val = getPointAgainstValue(580, iBottom);
        int i300Val = getPointAgainstValue(300, iBottom);
        int iBarWidth = bmpSideBar.getWidth();
        int horLineStartX = fMarginLeft - iBarWidth + SIDEBAR_RIGHT_MARGIN;
        paint.setColor(iLineColor);
        canvas.drawLine(horLineStartX, i850Val, fViewWidth, i850Val, paint);
        canvas.drawLine(horLineStartX, i740Val, fViewWidth, i740Val, paint);
        canvas.drawLine(horLineStartX, i670Val, fViewWidth, i670Val, paint);
        canvas.drawLine(horLineStartX, i580Val, fViewWidth, i580Val, paint);
        canvas.drawLine(horLineStartX, i300Val, fViewWidth, i300Val, paint);

        /**Draw points, connected lines on graph */
        paint.setColor(iLineColor);
        boolean shouldInvalidate = false;
        if (null != data)
            shouldInvalidate = drawChart(canvas, iBottom);

        /**Fill selected plot */
        setSelectedPlot(canvas);

        /** Mark white background to Y-axis, including labels, sidebar & it's right margin */
        paint.setColor(iBGColor);
        canvas.drawRect(0, 0, horLineStartX, iBottom + fMarginTopBottom, paint);

        /** Draw vertical line next to sidebar image*/
        paint.setColor(iLineColor);
        canvas.drawLine(horLineStartX, i300Val + SIDEBAR_TOP_MARGIN, horLineStartX, i850Val - SIDEBAR_TOP_MARGIN, paint);

        /** Draw vertical side bar image */
        paint.setColor(iLineColor);
        rectBubble.set(fMarginLeft - iBarWidth, i850Val - SIDEBAR_TOP_MARGIN, fMarginLeft, iBottom + SIDEBAR_TOP_MARGIN);
        rectImageArea.set(0, 0, bmpSideBar.getWidth(), bmpSideBar.getHeight());
        canvas.drawBitmap(bmpSideBar, rectImageArea, rectBubble, paint);

        /** Draw Y-axis labels*/
        int verLableStartX = fMarginLeft - (SIDEBAR_RIGHT_MARGIN / 2) - iBarWidth;
        paint.setColor(yAxisTextColor);
        paint.setTextAlign(Align.RIGHT);
        paint.setTextSize(getFontSize());
        canvas.drawText("300", verLableStartX, i300Val + 5, getC1Paint(Align.RIGHT));
        canvas.drawText("580", verLableStartX, i580Val + 5, getC1Paint(Align.RIGHT));
        canvas.drawText("670", verLableStartX, i670Val + 5, getC1Paint(Align.RIGHT));
        canvas.drawText("740", verLableStartX, i740Val + 5, getC1Paint(Align.RIGHT));
        canvas.drawText("850", verLableStartX, i850Val + 5, getC1Paint(Align.RIGHT));

        if (fMaxTransform >= 0) {
            paint.setColor(iLineColor);
            paint.setStrokeWidth(iStrokeValue * 2);
            paint.setColor(iTopBottomLineColor);
            paint.setStrokeWidth(iStrokeValue);
        }
        paint.setTextSize(getFontSize());

        if (shouldInvalidate)
            invalidate();
    }

    /**
     * Method to fill selected plot on graph
     */
    private void setSelectedPlot(Canvas canvas) {
        if (iClickedIndex != -1 && (iAnimSpeed == NO_ANIM || iAnimatedHeight[iClickedIndex] == iMaxHeight)) {
            int iClickPosX = chartPoints[iClickedIndex].x;
            int iClickPosY = chartPoints[iClickedIndex].y;
            canvas.drawCircle(iClickPosX, iClickPosY, RADIUS, getPlotFillPaint());
        }
    }

    int lastScoreInt;
    int lastScoreCounter;
    boolean isDrawDottedLine;

    public boolean drawChart(Canvas canvas, int fBase) {

        int iCounter = 0;
        curPoint.set(-1, -1);
        boolean shouldInvalidate = false;
        String xAxisDate;
        for (String[] strings : data) {

            int fLeft = fXTranform + fMarginLeft + SIDEBAR_RIGHT_MARGIN + (iPillarGap / 2) + iCounter * (iPillarGap);

            paint.setStrokeWidth(iStrokeValue);
            paint.setTextAlign(Align.CENTER);
            paint.setTextSize(getFontSize());

            int iVal = 0;
            if (strings[1].length() > 0) {
                iVal = Integer.parseInt(strings[1]);
            }
            paint.setColor(yAxisTextColor);

            /**Draw X-axis point here */
            if (fLeft > fMarginLeft) {
                xAxisDate = strings[0];
                if (!PortalUtils.isStrFieldEmpty(xAxisDate)) {

                    if (xAxisDate.contains(",")) {
                        drawMutilineText(canvas, xAxisDate, fLeft, fBase + XAXIS_LABEL_TOP_MARGIN, getC1Paint(Align.CENTER));
                    } else {
                        canvas.drawText(xAxisDate, fLeft, fBase + XAXIS_LABEL_TOP_MARGIN, getC1Paint(Align.CENTER));
                    }
                }
            }

            paint.setColor(iGraphLineColor);
            int fTop = getPointAgainstValue(iVal, fBase);

            if (fBase - fTop > iAnimatedHeight[iCounter])
                fTop = fBase - iAnimatedHeight[iCounter];

            if (iAnimatedHeight[iCounter] < iMaxHeight) {
                iAnimatedHeight[iCounter] += iMaxHeight / iAnimSpeed;
                if (iAnimatedHeight[iCounter] > iMaxHeight)
                    iAnimatedHeight[iCounter] = iMaxHeight;
                shouldInvalidate = true;
            }

            if (iVal == 0) {
                if (iCounter == (data.length - 1)) {
                    lastPoint.set(curPoint.x, curPoint.y);
                    fTop = getPointAgainstValue(lastScoreInt, fBase);
                    curPoint.set(fLeft, fTop);
                    drawDottedLine(canvas, lastPoint.x, lastPoint.y, curPoint.x, curPoint.y);
                    canvas.drawCircle(lastPoint.x, lastPoint.y, RADIUS - emptyCircleOffset, getPlotPaintWhite());
                }
                isDrawDottedLine = true;
                iCounter++;
                continue;
            } else {
                lastPoint.set(curPoint.x, curPoint.y);
                curPoint.set(fLeft, fTop);

                if (lastScoreInt != 0 && isDrawDottedLine && lastPoint.x != -1 && lastPoint.y != -1) {
                    /**Draw Dotted Line & make empty circle*/
                    drawDottedLine(canvas, lastPoint.x, lastPoint.y, curPoint.x, curPoint.y);
                    canvas.drawCircle(lastPoint.x, lastPoint.y, RADIUS - emptyCircleOffset, getPlotPaintWhite());
                    canvas.drawCircle(curPoint.x, curPoint.y, RADIUS - emptyCircleOffset, getPlotPaintWhite());
                    if (iCounter == (data.length - 1)) {
                        drawPointOnChart(canvas, false, true, strings[1], "");
                        updatePlotLocation(iCounter, curPoint.x, curPoint.y);
                    }
                } else if (lastScoreInt != 0 && lastPoint.x != -1 && lastPoint.y != -1) {
                    /**Draw Solid Line & fill with blue shading*/
                    canvas.drawLine(lastPoint.x, lastPoint.y, curPoint.x, curPoint.y, getConnectDotsPaint());
                    //to highlight the graph coverage area -mpalan1 6/1/2017
                    Path wallpath = new Path();
                    wallpath.reset(); // only needed when reusing this path for a new build
                    wallpath.moveTo(lastPoint.x, lastPoint.y); // used for first point
                    wallpath.lineTo(curPoint.x, curPoint.y);
                    wallpath.lineTo(curPoint.x, fBase);
                    wallpath.lineTo(lastPoint.x, fBase);
                    paint.setColor(graphFillColor);
                    canvas.drawPath(wallpath, paint);
                    paint.setColor(iGraphLineColor);
                    canvas.drawLine(lastPoint.x, lastPoint.y, curPoint.x, curPoint.y, getConnectDotsPaint());
                    drawPointOnChart(canvas, true, true, strings[1], "" + lastScoreInt);
                    updatePlotLocation(iCounter, curPoint.x, curPoint.y);
                    updatePlotLocation(lastScoreCounter, lastPoint.x, lastPoint.y);
                } else {
                    drawPointOnChart(canvas, false, true, strings[1], "");
                    updatePlotLocation(iCounter, curPoint.x, curPoint.y);
                }
                lastScoreInt = iVal;
                lastScoreCounter = iCounter;
                isDrawDottedLine = false;

            }

            if (fLeft < fMarginLeft || fLeft > fViewWidth) {
                if (iAnimSpeed == NO_ANIM)
                    iAnimatedHeight[iCounter] = iMaxHeight;
                else
                    iAnimatedHeight[iCounter] = 0;
            }
            iCounter++;
        }
        return shouldInvalidate;
    }

    /**
     * Method to store / update plot X, Y locations, used for handling click / touch on plot
     */
    public void updatePlotLocation(int index, int x, int y) {
        if (null == chartPoints[index]) {
            chartPoints[index] = new Point(x, y);
        } else {
            chartPoints[index].set(x, y);
        }
    }

    /**
     * Method to draw multi-line test on X-axis
     */
    public void drawMutilineText(Canvas canvas, String dateStr, int x, int y, Paint paint) {
        if (dateStr.contains(",")) {
            for (String xAxisDate : dateStr.split(",")) {
                canvas.drawText(xAxisDate, x, y, paint);
                y += -paint.ascent() + paint.descent();
            }
        }
    }

    public void drawPointOnChart(Canvas canvas, boolean shouldDrawLastPoint, boolean shouldDrawCurPoint, String currentScore, String lastScore) {

        paint.setColor(cliclePlotColor);

        if (shouldDrawCurPoint) {
            canvas.drawCircle(curPoint.x, curPoint.y, RADIUS, getPlotPaint());
            canvas.drawText(currentScore, curPoint.x + RADIUS + (RADIUS / 2), curPoint.y - PLOT_VALUE_BOTTOM_MARGIN, getC1Paint(Align.RIGHT));
        }
        if (shouldDrawLastPoint) {
            canvas.drawCircle(lastPoint.x, lastPoint.y, RADIUS, getPlotPaint());
            canvas.drawText(lastScore, lastPoint.x + RADIUS + (RADIUS / 2), lastPoint.y - PLOT_VALUE_BOTTOM_MARGIN, getC1Paint(Align.RIGHT));
        }

        /**start Code to to make empty circle */
        paint.setColor(iBGColor);
        if (shouldDrawCurPoint) {
            canvas.drawCircle(curPoint.x, curPoint.y, RADIUS - emptyCircleOffset, getPlotPaintWhite());
        }
        if (lastPoint.x > 0 && shouldDrawLastPoint) {
            canvas.drawCircle(lastPoint.x, lastPoint.y, RADIUS - emptyCircleOffset, getPlotPaintWhite());
        }
        /**end Code to to make empty circle */
    }

    public void drawDottedLine(Canvas canvas, int fLeft, int fTop, int fRight, int fBottom) {
        mPath = new Path();
        mPaint = new Paint();
        mPaint.setColor(iGraphLineColor);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setPathEffect(new DashPathEffect(new float[]{4, 4, 4, 4}, 0));
        mPaint.setStrokeWidth(iStrokeValue);
        mPath.moveTo(fLeft, fTop);
        mPath.quadTo(fLeft, fTop, fRight, fBottom);
        canvas.drawPath(mPath, mPaint);
    }

    private int getPointAgainstValue(int iValue, int iBottom) {
        int iReturnVal = 0;

        int iTotalHeight = 0;
        for (int i : iSectionHeights) {
            iTotalHeight += i;
        }

        int[] iSectionBases = new int[iSections.length];
        iSectionBases[0] = iBottom;
        for (int i = 0; i < iSectionHeights.length; i++) {
            int base = 0;
            if (i == 0)
                base = iBottom;
            else
                base = iSectionBases[i];

            iSectionBases[i + 1] = base - ((iMaxHeight * iSectionHeights[i]) / iTotalHeight);
        }

        iReturnVal = iSectionBases[iSectionBases.length - 1];

        for (int i = 1; i < iSections.length; i++) {
            if (iValue < iSections[i]) {
                int iPlotVal = ((iValue - iSections[i - 1]) * iSectionHeights[i - 1]) / (iSections[i] - iSections[i - 1]);
                iReturnVal = iSectionBases[i - 1] + ((iPlotVal * (iSectionBases[i] - iSectionBases[i - 1])) / iSectionHeights[i - 1]);
                break;
            }
        }

        if (iReturnVal > iSectionBases[0])
            iReturnVal = iSectionBases[0];
        return iReturnVal;
    }

    public void setData(String[][] info) {
        if (null != info) {
            data = info.clone();
        }

        boolean isRunningOnHandset = com.discover.mobile.common.Utils.isRunningOnHandset(mContext);

        iClickedIndex = -1;
        chartPoints = new Point[data.length];
        for (int i = 0; i < data.length; i++) {
            /**start changes for US153380 Dot Fill Behavior*/
            if (data[i][2].length() > 0 && data[i][1].length() > 0) {
                iClickedIndex = i;
            }
            /**end changes for US153380 Dot Fill Behavior*/
            chartPoints[i] = new Point(-1, -1);
        }
        if (null != data) {
            initScrollVariables();
        }
        refresh();

        if (isRunningOnHandset) {
            DIAMETER = RADIUS * 3;
        } else {
            DIAMETER = RADIUS * 2;
        }
    }

    private void initScrollVariables() {
        if (null != data) {
            fMaxTransform = fMarginLeft + (data.length * iPillarGap) - fViewWidth + fMarginRight;
            latestMonthIndex = data.length;
        }
        fXTranform = fMaxTransform * -1;
        if (latestMonthIndex != -1) {
            fXTranform = fMarginLeft + (latestMonthIndex * iPillarGap) - fViewWidth + fMarginRight;
            fXTranform *= -1;
        }

        if (fXTranform > 0)
            fXTranform = 0;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        float fCurX = event.getX();

        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            fLastXposition = fCurX;
            fClickPosX = fCurX;
            return true;
        } else if (event.getAction() == MotionEvent.ACTION_UP) {
            if (fLastXposition >= fCurX - HALF_RADIUS && fLastXposition <= fCurX + HALF_RADIUS) {
                /**start  US135901 - Remove "pop-up bubble"*/
                if (fClickPosX != -1) {
                    if (checkPointClicked(event.getX(), event.getY())) {
                        if (null != clickListner) {
                            setTag("Bubble Click " + data[iClickedIndex][1] + " on " + data[iClickedIndex][2]);
                            clickListner.onItemClicked(iClickedIndex);

                        }
                    }
                } else {
                    iClickedIndex = -1;
                }
                /**end  US135901 - Remove "pop-up bubble"*/
            }
            fLastXposition = -10001;
            invalidate();
            return true;
        } else if (event.getAction() == MotionEvent.ACTION_MOVE) {

            if (!isGraphScrolled) {

                HashMap<String, Object> extrasGraphScroll = new HashMap<String, Object>();
                extrasGraphScroll.put("my.prop1", AnalyticsPage.FICO_CREDIT_SCORE_HISTORY_SCROLL_GRAPH);
                extrasGraphScroll.put("pe", AnalyticsPage.FICO_CREDIT_SCORE_LNKO_PE);
                extrasGraphScroll.put("pev1", AnalyticsPage.FICO_CREDIT_SCORE_HISTORY_SCROLL_GRAPH);
                TrackingHelper.trackCardPage(null, extrasGraphScroll);
                isGraphScrolled = true;
            }

            if (fLastXposition <= fCurX - HALF_RADIUS || fLastXposition >= fCurX + HALF_RADIUS) {
                v.getParent().getParent().requestDisallowInterceptTouchEvent(true);

                fClickPosX = -1;
                fClickPosY = -1;

                setTalkBackText();
                if (fLastXposition != -10001 && fLastXposition != fCurX) {
                    if (fLastXposition < fCurX)
                        fXTranform += iScrollRate;
                    else if (fMaxTransform > (fXTranform * -1))
                        fXTranform -= iScrollRate;

                    if (fXTranform > 0)
                        fXTranform = 0;
                }
                fLastXposition = fCurX;
                invalidate();

            } else {
                v.getParent().getParent().requestDisallowInterceptTouchEvent(false);
            }
            return true;
        }

        return false;

    }

    private boolean checkPointClicked(float fClickedX, float fClickedY) {
        int iCounter = 0;

        for (Point point : chartPoints) {
            if (null != point &&
                    fClickedX >= point.x - DIAMETER
                    && fClickedY >= point.y - DIAMETER
                    && fClickedX <= point.x + DIAMETER
                    && fClickedY <= point.y + DIAMETER) {
                iClickedIndex = iCounter;
                return true;
            } else
                iCounter++;

        }
        iClickedIndex = -1;
        setTalkBackText();
        return false;
    }

    private boolean setTalkBackText() {
        String strMassage = "";
        if (iClickedIndex < 0 || iClickedIndex >= data.length)
            strMassage = "FICO Chart";
        else
            strMassage = "Your FICO score is " + data[iClickedIndex][1] + " on " + data[iClickedIndex][2];
        setContentDescription(strMassage);
        return true;
    }


    @Override
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        iMaxHeight = (int) (h - fMarginTopBottom - fMarginTopBottom);
        fViewWidth = w;
        initScrollVariables();
        setTalkBackText();
    }

    public void refresh() {
        iAnimatedHeight = new int[data.length];
        for (int i = 0; i < iAnimatedHeight.length; i++) {
            if (iAnimSpeed == NO_ANIM)
                iAnimatedHeight[i] = iMaxHeight;
            else
                iAnimatedHeight[i] = 0;
        }
        invalidate();
    }

    public void setMarginTopBottom(int fMarginTopBottom) {
        this.fMarginTopBottom = fMarginTopBottom;
    }

    public int getMarginLeft() {
        return fMarginLeft;
    }

    public void setMarginLeft(int fMarginLeft) {
        this.fMarginLeft = fMarginLeft;
    }

    public void setFontColor(int iFontColor) {
        this.iGraphLineColor = iFontColor;
    }

    public void setPillarGap(int iPillarGap) {
        this.iPillarGap = iPillarGap;
    }

    public int getFontSize() {
        return iFontSizeAxis;
    }

    public void setFontSize(int iFontSize) {
        this.iFontSizeAxis = iFontSize;
    }

    public void setLineColor(int iLineColor) {
        this.iLineColor = iLineColor;
    }

    public void setiTopBottomLineColor(int iTopBottomLineColor) {
        this.iTopBottomLineColor = iTopBottomLineColor;
    }

    public void setyAxisTextColor(int yAxisTextColor) {
        this.yAxisTextColor = yAxisTextColor;
    }

    public void setiStrokeValue(int iStrokeValue) {
        this.iStrokeValue = iStrokeValue;
    }

    public void setfMarginRight(int fMarginRight) {
        this.fMarginRight = fMarginRight;
    }

    public void setfMarginLeft(int fMarginLeft) {
        this.fMarginLeft = fMarginLeft;
    }

    public void setRADIUS(int radius) {
        this.RADIUS = radius;
    }

    public void setCliclePlotColor(int cliclePlotColor) {
        this.cliclePlotColor = cliclePlotColor;
    }

    public void setCirclePlotStroke(int circlePlotStroke) {
        this.circlePlotStroke = circlePlotStroke;
    }

    public void setXaxisLabelTopMargin(int topMargin) {
        this.XAXIS_LABEL_TOP_MARGIN = topMargin;
    }

    public void setPlotValueBottomMargin(int bottomMargin) {
        this.PLOT_VALUE_BOTTOM_MARGIN = bottomMargin;
    }

    public void setGraphFillColor(int fillColor) {
        this.graphFillColor = fillColor;
    }

    public void setEmptyCircleOffset(int emptyCircleOffset) {
        this.emptyCircleOffset = emptyCircleOffset;
    }

    public void setSidebarRightMargin(int margin) {
        this.SIDEBAR_RIGHT_MARGIN = margin;
    }

    public void setSidebarTopMargin(int margin) {
        this.SIDEBAR_TOP_MARGIN = margin;
    }

    public void setClickListner(GraphClickListner clickListner) {
        this.clickListner = clickListner;
    }
}
