package com.discover.mobile.common.shared.utils.image;

import com.discover.mobile.network.error.bean.ErrorResponseDetails;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import com.discover.mobile.common.login.beans.PreAuthbean;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Modifier;

public class Utils {

    private static PreAuthbean mDynamicProperties;

    public static void CopyStream(InputStream is, OutputStream os) {
        final int buffer_size = 1024;
        try {
            byte[] bytes = new byte[buffer_size];
            for (; ; ) {
                int count = is.read(bytes, 0, buffer_size);
                if (count == -1)
                    break;
                os.write(bytes, 0, count);
            }
        } catch (Exception ex) {
        }
    }

    /*US22064 Conversion of jackson to gson*/
    public static byte[] getByteArrayFromObject(Object data) throws UnsupportedEncodingException {
        String dataStr = getJSONStringFromObject(data);
        byte[] bytes = dataStr.getBytes("UTF_8");
        return bytes;
    }

    public static String getJSONStringFromObject(Object data) {
        Gson gson = new Gson();
        String dataStr = gson.toJson(data);
        return dataStr;
    }

    public static Serializable getObjectFromJSONString(String jsonStr, Class<?> modalClass) throws JsonSyntaxException {
        Gson gson = new Gson();
        if(!modalClass.getName().equals(ErrorResponseDetails.class.getName())){
            gson = new GsonBuilder().excludeFieldsWithModifiers(Modifier.VOLATILE).create();
        }
        Serializable pojoObject = (Serializable) gson.fromJson(jsonStr, modalClass);
        return pojoObject;
    }

    //US22064 Conversion of jackson to gson
    public static void setDynamicProperties(PreAuthbean mBean) {
        mDynamicProperties = mBean;
    }

    public static Object getDynamicProperties(String mKey) {
        if (mDynamicProperties != null)
            return mDynamicProperties.getDynamicProperties(mKey);
        else
            return null;
    }

    public static void cleanDynamicProperty() {
        if (mDynamicProperties != null) {
            mDynamicProperties.getDynamicPropertiesMap().clear();
            mDynamicProperties = null;
        }
    }
}