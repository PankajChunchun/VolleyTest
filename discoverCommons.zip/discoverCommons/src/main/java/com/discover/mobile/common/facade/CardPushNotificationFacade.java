package com.discover.mobile.common.facade;


import com.discover.mobile.common.BaseFragmentActivity;

import org.json.JSONObject;

import android.content.Context;
import android.os.Bundle;

/**
 * A facade for assisting with general card push notification activities
 *
 * @author CTS
 */
public interface CardPushNotificationFacade {

    //Function is useful to navigateToPageWear
    public void navigateToPageWear(BaseFragmentActivity callingActivity);

    //Function is useful to display the push notification
    public void sendCardNotification(String title, String contentText,
                                     String payload, int notificationId, Context context);

    //Useful to navigate to various screens based on the received push notification
    public void cardPushNavigations(JSONObject data, int notificationId, Context context);

    //Display the card push notification icon
    public void processCardNotificationExtras(final Context context, final Bundle extras);

    //Function is useful to Card navigation based on deep link values
    public void handleCardPayloadNavigations(Context context,
                                             String[] reqIdKeyValue, String[] pageCodeKeyValue);


}
