package com.discover.mobile.common.ui;

import com.discover.mobile.common.R;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

/**
 * WebViewDialog
 * Handles Loading Url in Dialog
 *
 * @author gherrma
 */
public class WebViewDialog extends Dialog {

    private WebView mWebView;
    private Button mCloseButton;

    /**
     * Default Constructor
     * loads https://www.discover.com/privacy-statement/index.html
     *
     * @param context Reference to Activity
     */
    public WebViewDialog(Context context) {
        super(context, android.R.style.Theme_Translucent_NoTitleBar);

        // No Title Bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        requestWindowFeature(Window.FEATURE_PROGRESS);

        this.setContentView(R.layout.web_view_dialog);
        initUI();
        initWebView("https://www.discover.com/privacy-statement/index.html");

        setCancelable(true);
    }

    /**
     * Constructor
     * Allows Custom URL To be passed
     *
     * @param context Reference to Activity
     * @param url     Url to load in WebView
     */
    public WebViewDialog(Context context, String url) {
        super(context, android.R.style.Theme_Translucent_NoTitleBar);

        // No Title Bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        requestWindowFeature(Window.FEATURE_PROGRESS);

        this.setContentView(R.layout.web_view_dialog);
        initUI();
        initWebView(url);

        setCancelable(true);
    }

    /**
     * Initialize Views
     */
    private void initUI() {

        mWebView = (WebView) findViewById(R.id.web_view);
        mWebView.setBackgroundColor(Color.WHITE);
        mCloseButton = (Button) findViewById(R.id.web_dialog_close_button);

        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                WebViewDialog.this.dismiss();
            }
        });
    }

    /**
     * Initialize WebView, and handle settings
     */
    @SuppressLint("SetJavaScriptEnabled")
    public void initWebView(String url) {

        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setBuiltInZoomControls(true);
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.loadUrl(url);

        mWebView.setId(3);
        mWebView.setInitialScale(90);
        mWebView.requestFocus();
        mWebView.requestFocusFromTouch();

        mWebView.setWebViewClient(new WebViewClient() {

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
            }

            @Override
            public void onPageStarted(WebView view, String url,
                                      final Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }
        });
    }

}
