package com.discover.mobile.common.shared.net.error;

import java.io.Serializable;
import java.net.HttpURLConnection;

public interface ErrorResponse<E extends ErrorResponse<E>> extends Serializable {

    int getHttpStatusCode();

    ErrorMessageMapper<E> getMessageMapper();

    /**
     * @return Interface defined to Return a reference to the HttpURLConnection object used to
     * receive error response
     */
    public HttpURLConnection getConnection();

    /**
     * @param connection Interface to set a Reference to the HttpURLConnection object used to
     *                   receive error response
     */
    void setConnection(HttpURLConnection connection);

}
