package com.discover.mobile.common.highlightedfeatures.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * SharedPrefrences for HighlightedFeature and WhatsNew.
 * <p/>
 * It stores flag for Bank/ Card and SSO login to handle visibility of What's-new and
 * Highlighted-feature.
 * Highlighted feature or What's-new JSON coming from server or reading from Asset or service
 * failure,
 * is stored into this preferences, and this json will be overridden on each service call.
 *
 * @author pkuma13
 */
public class HFPref {
    private static final String PREFERENCE_NAME = "HighlightedFeaturesSharedPrefs";
    private static final String HF_JSON = "hf_json";
    private static final String CARD_USER_LOGIN_COUNT = "user_num_of_login_card";
    private static final String BANK_USER_LOGIN_COUNT = "user_num_of_login_bank";
    private static final String SSO_USER_LOGIN_COUNT = "user_num_of_login_sso";
    private static final String WHATS_NEW_JSON_VERSION = "whats_new_json_version";
    private static final String ONBOARD_WIZARD = "wizard_shown";

    /**
     * This key is being used to store status of whats-new for CARD/BANK/SSO user. Value of this key
     * will be
     * <code>false</code> by default and will be <code>true</code> only if whats-new has been shown
     * to very first user.
     */
    private static final String WHATS_NEW_FLAG = "is_whats_new_shown_to_";
    private static final int DEFAULT_COUNT = 0;
    private final SharedPreferences preferences;
    private Context mContext;

    public HFPref(Context context) {
        this.preferences = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
        this.mContext = context;
    }

    public String getWhatsNewJsonVersion() {
        return this.preferences.getString(WHATS_NEW_JSON_VERSION, "");
    }

    public void setWhatsNewJsonVersion(String whatsNewJsonVersion) {
        this.preferences.edit().putString(WHATS_NEW_JSON_VERSION, whatsNewJsonVersion).commit();
    }

    public String getJsonString() {
        return this.preferences.getString(HF_JSON, null);
    }

    public void setJsonString(String highlightedFeatureJson) {
        this.preferences.edit().putString(HF_JSON, highlightedFeatureJson).commit();
    }

    public int getCardUserLoginCount() {
        return this.preferences.getInt(CARD_USER_LOGIN_COUNT, DEFAULT_COUNT);
    }

    public void setCardUserLoginCount(int loginCount) {
        this.preferences.edit().putInt(CARD_USER_LOGIN_COUNT, loginCount).commit();
    }

    public int getBankUserLoginCount() {
        return this.preferences.getInt(BANK_USER_LOGIN_COUNT, DEFAULT_COUNT);
    }

    public void setBankUserLoginCount(int loginCount) {
        this.preferences.edit().putInt(BANK_USER_LOGIN_COUNT, loginCount).commit();
    }

    public int getSSOUserLoginCount() {
        return this.preferences.getInt(SSO_USER_LOGIN_COUNT, DEFAULT_COUNT);
    }

    public void setSSOUserLoginCount(int loginCount) {
        this.preferences.edit().putInt(SSO_USER_LOGIN_COUNT, loginCount).commit();
    }

    public int incrementSSOLoginCount() {
        // Deeplinking enablement status has been check at caller of
        // this method. No need to check again here.
        int ssoLoginCount = getSSOUserLoginCount();
        ssoLoginCount += 1;
        setSSOUserLoginCount(ssoLoginCount);
        return ssoLoginCount;
    }

    /**
     * Get {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     * dependent flag
     * which tells if Whats has been shown.
     *
     * @param loginType - {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     * @return - <code>true</code> if whats new has been shown, otherwise <code>false</code>.
     */
    public boolean isWhatsNewShown(HFConstants.LoginType loginType) {
        String prefKey = WHATS_NEW_FLAG + loginType.name();
        return this.preferences.getBoolean(prefKey, false);
    }

    /**
     * Set {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     * dependent flag.
     *
     * @param loginType - {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     * @param shown     -<code>true</code> if whats new has been shown, otherwise
     *                  <code>false</code>.
     */
    public void setWhatsNewShown(HFConstants.LoginType loginType, boolean shown) {
        String prefKey = WHATS_NEW_FLAG + loginType.name();
        this.preferences.edit().putBoolean(prefKey, shown).commit();
    }

    /**
     * Reset Login count when new whatsnew is updated.
     **/
    public void resetLoginCount() {
        setWhatsNewShown(HFConstants.LoginType.BANK, false);
        setWhatsNewShown(HFConstants.LoginType.SSO, false);
        setWhatsNewShown(HFConstants.LoginType.CARD, false);
        setSSOUserLoginCount(0);
        setCardUserLoginCount(0);
        setBankUserLoginCount(0);
    }

    public void setWizardShown(boolean visibility) {
        this.preferences.edit().putBoolean(ONBOARD_WIZARD, visibility).commit();
    }

    public boolean getIsWizardShownAlready() {
        return this.preferences.getBoolean(ONBOARD_WIZARD, false);
    }
}
