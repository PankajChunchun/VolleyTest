package com.discover.mobile.common.navigation;

public interface NoSwipeOpenMenu {

}
