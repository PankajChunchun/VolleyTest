package com.discover.mobile.common.fico.interfaces;

/**
 * Interface to make collection of different types of objects for FICO-List
 *
 * @author slende
 */
public interface CmnFicoListItemInterface {

}
