package com.discover.mobile.common.facade;

import com.discover.mobile.common.shared.net.NetworkRequestListener;

import android.app.Activity;
import android.os.Bundle;

public interface HighlightedFeaturesFacade {

    /// public void getPreloginHighlightedFeaturesActivity(Activity activity,Bundle lastOriBundle, final NetworkRequestListener listener);
    // public void getPreloginHighlightedFeaturesFragment(Activity activity,Bundle lastOriBundle, final NetworkRequestListener listener);
    public void checkPreloginHightlightedFeaturesAvailable(Activity activity, final NetworkRequestListener listener);

    public void checkWhatsNewFeaturesAvailable(Activity activity, final NetworkRequestListener listener, final String cardType);

     /*1. Removed as per US60514 */
  /*  public void executeActionCodeDeeplinkHelper(Activity activity, String code);*/

    /*2. Removed as per US60514 */
   /* public void executeActionCodePreLoginDeeplinkHelper(Context activity, String code);*/
    public void navigateToCardHome(Activity context, Bundle extras);

    public void navigateToCardHomeFromOnBoard(Activity context, Bundle extras);

}
