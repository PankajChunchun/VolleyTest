package com.discover.mobile.common.androidwear;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.data.FreezableUtils;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;

import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by vijay on 1/31/15.
 */
public class MessageListenerService extends WearableListenerService {
    private static final String TAG = AndroidWearConnectivity.class.getName();
    private GoogleApiClient mGoogleApiClient;

    @Override
    public void onCreate() {
        super.onCreate();
        mGoogleApiClient = new GoogleApiClient.Builder(this).addApi(
                Wearable.API).build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onDataChanged(DataEventBuffer dataEvents) {
        final List<DataEvent> events = FreezableUtils
                .freezeIterable(dataEvents);
        dataEvents.close();

        if (!mGoogleApiClient.isConnected()) {
            ConnectionResult connectionResult = mGoogleApiClient
                    .blockingConnect(30, TimeUnit.SECONDS);
            if (!connectionResult.isSuccess()) {
                Log.e(TAG,
                        "MOBILE:: Service failed to connect to GoogleApiClient.");
                return;
            }
        }

        for (DataEvent event : events) {
            if (event.getType() == DataEvent.TYPE_CHANGED) {
                String path = event.getDataItem().getUri().getPath();
                Log.d(TAG, "MOBILE:: path: " + path);
                if (path.equals("")) {

                } else {
                    Log.d(TAG, "MOBILE:: Unrecognized path: " + path);
                }
            }
        }
    }

    private void clearNotification() {

        NotificationManager notificationManager = (NotificationManager) getApplicationContext()
                .getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

    }

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {
        Log.d(TAG, "MOBILE:: onMessageReceived messageEvent path: "
                + messageEvent.getPath());
        Intent i = new Intent();
        if (messageEvent.getPath()
                .equals(WearRequestTypes.PATH_CARD_QV_REQUEST)) {

            i.setAction("com.discover.mobile.card.WearQuickView");
            getApplicationContext().sendBroadcast(i);

        } else if (messageEvent.getPath().equals(
                WearRequestTypes.PATH_WEAR_SETTINGS_REQUEST)) {

            i.setAction("com.discover.mobile.card.WearQuickView");
            i.putExtra("isWearSettingRequest", true);
            getApplicationContext().sendBroadcast(i);

        } else if (messageEvent.getPath().equals(WearRequestTypes.OPEN_PHONE)) {

            i.setAction("com.discover.mobile.androidwear.NAV_DEEPLINK");
            String data = new String(messageEvent.getData());
            i.putExtra("NAV_DEEPLINK", data);
            getApplicationContext().sendBroadcast(i);
        } else if (messageEvent.getPath().equals(
                WearRequestTypes.PATH_WEAR_SETTINGS_TURNON_REQUEST)) {
            BankAndroidWearUtils androidWearUtils = new BankAndroidWearUtils(
                    getApplicationContext());
            if (DiscoverActivityManager.getActiveActivity() == null) {
                String bankToken = null;
                try {
                    bankToken = BankAndroidWearUtils
                            .getWearToken(getApplicationContext());

                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                if (bankToken == null) {
                    BankAndroidWearUtils.setBankLoginSelected(
                            getApplicationContext(), false);
                } else {
                    BankAndroidWearUtils.setBankLoginSelected(
                            getApplicationContext(), true);
                }
                // Globals.setCurrentAccount(AccountType.CARD_ACCOUNT);
            }
            if (androidWearUtils.getBankLoginSelected())
                i.setAction("com.discover.mobile.bank.wear.DeepLink");
            else
                i.setAction("com.discover.mobile.card.WearSettings");
            getApplicationContext().sendBroadcast(i);

        } else if (messageEvent.getPath().equals(
                WearRequestTypes.PATH_DISMISS_NOTIFICATION_MOBILE)) {
            clearNotification();

        } else if (messageEvent.getPath().equals(WearRequestTypes.APP_LAUNCH)) {
            // analytics1
            String screenDimension = null;
            screenDimension = new String(messageEvent.getData());
            String[] parts = screenDimension.split("&");
            String screenWidth = parts[0]; // 004
            String screenHeight = parts[1];
            System.out.println("screenWidth = " + screenWidth
                    + " and screenHeight = " + screenHeight);
            i.setAction("com.discover.mobile.card.analytics.appLaunch");
            i.putExtra("analytics_screenDimension", screenDimension);
            getApplicationContext().sendBroadcast(i);

        } else if (messageEvent.getPath().equals(
                WearRequestTypes.TURN_ON_SETTINGS_PAGE)) {
            // analytics2
            System.out.println(new String(messageEvent.getData()));
            i.setAction("com.discover.mobile.card.analytics.turnOnSettingsPage");
            i.putExtra("analytics_turnOnSettingsPage",
                    new String(messageEvent.getData()));
            getApplicationContext().sendBroadcast(i);

        } else if (messageEvent.getPath().equals(
                WearRequestTypes.SSO_ACCOUNT_SUMMARY)) {
            // analytics3
            System.out.println(new String(messageEvent.getData()));
            i.setAction("com.discover.mobile.card.analytics.ssoUserAccountSummary");
            i.putExtra("analytics_ssoUserAccountSummary", new String(
                    messageEvent.getData()));
            getApplicationContext().sendBroadcast(i);

        } else if (messageEvent.getPath().equals(
                WearRequestTypes.USER_ACCOUNT_SUMMARY)) {
            // analytics4
            System.out.println("account viewed by user in wear "
                    + new String(messageEvent.getData()));
            i.setAction("com.discover.mobile.card.analytics.normalUserAccountSummary");
            i.putExtra("analytics_normalUserAccountSummary", new String(
                    messageEvent.getData()));
            getApplicationContext().sendBroadcast(i);
        } else if (messageEvent.getPath().equals(
                WearRequestTypes.PATH_NOTIFICATION_CALL_DIALER)) {
            String data = new String(messageEvent.getData());
            Log.d("MessageListnerService", " Phone No :  " + data);
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + data));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }

    }
}
