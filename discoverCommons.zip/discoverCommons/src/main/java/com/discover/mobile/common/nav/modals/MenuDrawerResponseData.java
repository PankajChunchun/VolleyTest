package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class MenuDrawerResponseData implements Serializable {

    @SerializedName("MenuDetails")
    public CardDetailsData menuDetailData;
    @SerializedName("BankTypeDetails")
    public BankDetailData bankDetailData;

    public CardDetailsData getMenuDetails() {
        return menuDetailData;
    }

    public void setMenuDetails(CardDetailsData cardDetailData) {
        this.menuDetailData = cardDetailData;
    }

    public BankDetailData getBankDetailData() {
        return bankDetailData;
    }

    public void setBankDetailData(BankDetailData bankDetailData) {
        this.bankDetailData = bankDetailData;
    }
}
