package com.discover.mobile.common.productpage.adapters;

import com.discover.mobile.common.R;
import com.discover.mobile.common.productpage.beans.ProductsCategory;
import com.discover.mobile.common.productpage.beans.ProductsContent;
import com.discover.mobile.common.productpage.beans.ProductsLink;
import com.discover.mobile.common.ui.widgets.FontAwesomeTextView;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

/**
 * A {@link BaseExpandableListAdapter} which is being used to show products list
 * using {@link ProductsContent} model.
 *
 * @author pkuma13
 */
public class ProductListAdapter extends BaseExpandableListAdapter {

    private Context mContext;
    private ProductsContent mProductsContent;

    public ProductListAdapter(Context context, ProductsContent productsContent) {
        this.mContext = context;
        this.mProductsContent = productsContent;
    }

    @Override
    public ProductsLink getChild(int listPosition, int expandedListPosition) {
        return this.mProductsContent.getCategories().get(listPosition).getLinks().get(expandedListPosition);
    }

    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }

    @Override
    public View getChildView(int listPosition, final int expandedListPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final ProductsLink link = (ProductsLink) getChild(listPosition, expandedListPosition);
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.product_page_list_item, null);

        }
        TextView expandedListTextView = (TextView) convertView.findViewById(R.id.product_page_row);
        expandedListTextView.setText(link.getName());
        View childHeader = (View) convertView.findViewById(R.id.product_child_devider);
        if (isLastChild) {
            childHeader.setVisibility(View.VISIBLE);
        } else {
            childHeader.setVisibility(View.GONE);
        }
        return convertView;
    }

    @Override
    public int getChildrenCount(int listPosition) {
        return this.mProductsContent.getCategories().get(listPosition).getLinks().size();
    }

    @Override
    public ProductsCategory getGroup(int listPosition) {
        return this.mProductsContent.getCategories().get(listPosition);
    }

    @Override
    public int getGroupCount() {
        return this.mProductsContent.getCategories().size();
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }

    @Override
    public View getGroupView(int listPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String listTitle = (String) getGroup(listPosition).getName();
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.product_page_list_group, null);
        }
        TextView listTitleTextView = (TextView) convertView.findViewById(R.id.product_page_title);

        listTitleTextView.setText(listTitle);
        listTitleTextView.setContentDescription(listTitle + " " + mContext.getResources().getString(R.string.tb_expandable_keyword));
        FontAwesomeTextView textIndicator = (FontAwesomeTextView) convertView.findViewById(R.id.product_page_indicator);
        if (isExpanded) {
            textIndicator.setText(mContext.getResources().getString(R.string.fa_minus));
        } else {
            textIndicator.setText(mContext.getResources().getString(R.string.fa_plus));
        }
        textIndicator.setTypeface(textIndicator.getTypeface(), Typeface.NORMAL);
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }
}