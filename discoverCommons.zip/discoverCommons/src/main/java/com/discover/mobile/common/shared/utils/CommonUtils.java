package com.discover.mobile.common.shared.utils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import com.discover.mobile.common.BuildConfig;
import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.nav.modals.MenuDrawerResponseData;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.image.FileDownloader;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.uiwidget.CmnTextView;
import com.discover.mobile.network.infomessage.InfoMessageUtils;
import com.discover.mobile.network.infomessage.JsonDownloader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.CheckForNull;
import javax.annotation.Nullable;


/**
 * A common place to put utilities that can and will be used across the app on both phone and
 * tablet
 *
 * @author jthornton
 */
public final class CommonUtils {

    /**
     * CLI - Hard kill switch
     */
    public static final boolean isCLIFeatureEnabled = true;
    /** Tag for logging in the common utils */
    private static final String TAG = CommonUtils.class.getSimpleName();
    /** Static int for the minimum length of a phone number */
    private static final int PHONE_NUMBER_MIN = 10;
    /** Index of the first dash "-" in a phone number. */
    private static final int PHONE_DASH_FIRST = 3;
    /** Index of the second dash "-" in a phone number. */
    private static final int PHONE_DASH_SECOND = 6;
    /** Number of characters between spaces in an account number */
    private static final int ACCOUNT_BLOCK_LENGTH = 4;
    /** Number of cents in a dollar */
    private static final int CENTS_IN_DOLLAR = 100;
    private static final boolean isGingerbread = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.HONEYCOMB;
    public static boolean isOfflinemode = false;
    public static boolean isSuccessFlow = true;

    public static String cardIPAddress = "";

    private static long lastRestCallTime;

    //below gets card LHN menu from server or locally
    private static String json;

    /**start added for 7.8 regression defect fixing */
    public static final String JSON_FILE_EXTENSION = ".json";
    public static final String CARD_MENU = "/json/lhn/";
    /**end added for 7.8 regression defect fixing */
    private static int numberPositionStart =0;
    private static int numberPositionEnd =0;

    static PhoneNumClickCallback callback;

    private CommonUtils() {
    }

    //called in CardDrawerActivity and fetches json either from server or locally
    public static MenuDrawerResponseData getCardMenu() {
        MenuDrawerResponseData responseData = null;

        if (!TextUtils.isEmpty(json)) {
            responseData = (MenuDrawerResponseData) Utils.getObjectFromJSONString(json, MenuDrawerResponseData.class);
        } else {
            /**added version specific fine name to LHN menu json file name */
            String jsonFilename = getLHNMenuFileNameOnServer();
            json = loadJSONFromAsset("card_lhn_menu_items.json");
            responseData = (MenuDrawerResponseData) Utils.getObjectFromJSONString(json, MenuDrawerResponseData.class);
        }
        return responseData;
    }

    private static String loadJSONFromAsset(String JSONFile) {
        String json = null;
        try {
            InputStream is = DiscoverApplication.getGlobalContext().getAssets().open(JSONFile);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    //called in LoginActivity to set the json file as soon as app opens and if URL doesn't work it will use fall back
    public static void fetchCardMenuFromServer() {
        String cardMenuUrl = FacadeFactory.getCardFacade().getCardBaseUrl() + CARD_MENU;
        cardMenuUrl += getLHNMenuFileNameOnServer();
        DownloadCardMenu cardMenuTask = new DownloadCardMenu();
        cardMenuTask.execute(cardMenuUrl);
    }


    /**
     * @return Card Lhn Menu json file name, which will be post-fixed by current version number of
     * application.
     * e.g. card_lhn_menu_items_780.json for 7.8 release
     * added for 7.8 regression defect fixing
     */
    public static String getLHNMenuFileNameOnServer() {

        String version = null;
        Context context = DiscoverApplication.getGlobalContext();
        String jsonFilename = context.getString(R.string.card_lhn_json);

        if (jsonFilename.contains(JSON_FILE_EXTENSION)) {
            jsonFilename = jsonFilename.replace(JSON_FILE_EXTENSION, "");
        }
        /*//If offline mode is true then take json as card_lhn_menu_items.json
        if(isOfflinemode)
            return jsonFilename + JSON_FILE_EXTENSION;
        try {
            version = context.getPackageManager().getPackageInfo(context.getApplicationContext().getPackageName(), 0).versionName;
            version = version.replace(".", "");
        } catch (PackageManager.NameNotFoundException e) {

        }*/
        if(!Globals.getAppVersion().isEmpty()&&Globals.getAppVersion()!=null)
        {
            version = Globals.getAppVersion();
        }
        else
        version = BuildConfig.VERSION_NAME; // This BuildConfig is of com.discover.mobile.common.BuildConfig
        version = version.replace(".", "");
        return jsonFilename + "_" + version + JSON_FILE_EXTENSION;
//        return jsonFilename;
    }

    /**
     * Convert the simple number into a phone number string
     *
     * If the number is not at least 10 digits in length or it is null this will return an empty
     * string
     *
     * @param number - number to be changed
     * @return the formatted phone number
     */
    public static String toPhoneNumber(final String number) {
        if (number == null || number.length() < PHONE_NUMBER_MIN) {
            return "";
        }
        return String.format("%s-%s-%s", number.substring(0, PHONE_DASH_FIRST),
                number.substring(PHONE_DASH_FIRST, PHONE_DASH_SECOND),
                number.substring(PHONE_DASH_SECOND, PHONE_NUMBER_MIN));
    }

    /**
     * Return a formatted date for given month day and year integer values. The formatted date is in
     * the form
     * mm/dd/yy
     *
     * @param month an integer representation of the month
     * @param day   an integer representation of the day of the month
     * @param year  an integer representation of the year
     * @return a string representation of the formatted month day and year as mm/dd/yy
     */
    public static String getFormattedDate(final int month, final int day, final int year) {
        return getFormattedDate("MM/dd/yy", month, day, year);
    }

    /**
     * Return a formatted date for given month day and year integer values. The formatted date is in
     * the form
     * the given template.
     *
     * @param template to use for the date formatter (eg. "MM/dd/yyyy")
     * @param month    an integer representation of the month
     * @param day      an integer representation of the day of the month
     * @param year     an integer representation of the year
     * @return a string representation of the formatted month day and year as specified by provided
     * template
     */
    public static String getFormattedDate(String template, final int month, final int day, final int year) {
        final Calendar calendarValue = Calendar.getInstance();
        calendarValue.set(Calendar.YEAR, year);
        calendarValue.set(Calendar.MONTH, month);
        calendarValue.set(Calendar.DAY_OF_MONTH, day);

        return new SimpleDateFormat(template, Locale.getDefault()).format(calendarValue.getTime());
    }

    /**
     * Returns a date formatted as {@code YYYY-MM-ddTHH:MM:ss.000Z}, (e.g.
     * 2012-10-06T00:00:00.000-0600). This is required for some Bank services.
     *
     * @see {@link CommonUtils#getServiceFormattedISO8601Date} for {@code YYYY-MM-ddTHH:MM:ssZ}
     */
    public static String getLongServiceFormattedISO8601Date(final int month,
                                                            final int day, final int year) {
        final String easternTime = "America/New_York";
        final String sb;
        final Calendar calendarValue = Calendar.getInstance();
        calendarValue.set(Calendar.YEAR, year);
        calendarValue.set(Calendar.MONTH, month);
        calendarValue.set(Calendar.DAY_OF_MONTH, day);

        SimpleDateFormat submissionDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.getDefault());
        submissionDateFormat.setTimeZone(TimeZone.getTimeZone(easternTime));
        sb = submissionDateFormat.format(calendarValue.getTime());
        //sb.append(new SimpleDateFormat("yyyy-MM-dd'T'00:00:00.000Z", Locale.getDefault()).format(calendarValue.getTime()));
        return sb;
    }

    /**
     * Returns a date formatted as {@code YYYY-MM-ddTHH:MM:ssZ}, (e.g.
     * 2012-10-06T00:00:00Z). This is required for some Bank services.
     */
    public static String getServiceFormattedISO8601Date(final int month,
                                                        final int day, final int year) {
        final Calendar calendarValue = Calendar.getInstance();
        calendarValue.set(Calendar.YEAR, year);
        calendarValue.set(Calendar.MONTH, month);
        calendarValue.set(Calendar.DAY_OF_MONTH, day);

        final StringBuilder sb = new StringBuilder();
        sb.append(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendarValue.getTime()));
        sb.append("T00:00:00Z");

        return sb.toString();
    }

    /**
     * Return a formatted date for given month and year integer values. The formatted date is in the
     * form
     * mm/yy
     *
     * @param month an integer representation of the month
     * @param year  an integer representation of the year
     * @return a string representation of the formatted month day and year as mm/yy
     */
    public static String getFormattedDate(final int month, final int year) {
        final Calendar calendarValue = Calendar.getInstance();
        calendarValue.set(Calendar.YEAR, year);
        calendarValue.set(Calendar.MONTH, month);
        //Defect id 97729 by Cognizant
        calendarValue.set(Calendar.DAY_OF_MONTH, 1);
        //Defect id 97729
        return new SimpleDateFormat("MM/yy", Locale.getDefault()).format(calendarValue.getTime());
    }

    /*Start changes for US92562*/
    /* This method return value is month Year  For Ex: Jan 2017 */
    public static String getFormattedMonthForCollegeGrad(final int month, final int year) {
        final Calendar calendarValue = Calendar.getInstance();
        calendarValue.set(Calendar.YEAR, year);
        calendarValue.set(Calendar.MONTH, month);
        calendarValue.set(Calendar.DAY_OF_MONTH, 1);
        return new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendarValue.getTime());
    }

    /* This method return value is month. For Ex: Jan */
    public static String getMonthFormat(String monthValue) {

        Calendar cal = Calendar.getInstance();
        int tempmonth = Integer.parseInt(monthValue);

        SimpleDateFormat newformat = new SimpleDateFormat("MMMM");
        SimpleDateFormat oldformat = new SimpleDateFormat("MM");

        String monthName = null;
        Date myDate;
        try {
            myDate = oldformat.parse(String.valueOf(tempmonth));
            monthName = newformat.format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return monthName;
    }


    /* This method return value is month. For Ex: 01 */
    public static String getMonthFormatForCollegeGradField(String monthValue) {

        Calendar cal = Calendar.getInstance();

        SimpleDateFormat newformat = new SimpleDateFormat("MM");
        SimpleDateFormat oldformat = new SimpleDateFormat("MMMM");

        String monthName = null;
        Date myDate;
        try {
            myDate = oldformat.parse(String.valueOf(monthValue));
            monthName = newformat.format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return monthName;
    }
 /*End changes for US92562*/
    /**
     * Sets a given EditText's input to all lowercase characters. Useful when
     * restricting the input of a field.
     */
    public static void setInputToLowerCase(final CharSequence input,
                                           final EditText field) {
        final String inputString = input.toString();
        final String lowerCaseInput = inputString.toLowerCase(Locale
                .getDefault());

        if (!inputString.equals(lowerCaseInput)) {
            field.setText(lowerCaseInput);
            field.setSelection(lowerCaseInput.length());
        }
    }

    /**
     * Insert a space after every 4 characters in a String. Warning!
     * Recursion!!! This method takes the first four characters of some string,
     * adds a space to the end of those 4 characters and then appends it to the
     * rest of the input string, minus those 4 beginning characters and the
     * space.
     */
    public final static String getStringWithSpacesEvery4Characters(final String stringWithoutSpaces) {
        if (stringWithoutSpaces != null && stringWithoutSpaces.length() >= ACCOUNT_BLOCK_LENGTH) {
            return stringWithoutSpaces.substring(0, ACCOUNT_BLOCK_LENGTH)
                    + StringUtility.SPACE
                    + getStringWithSpacesEvery4Characters(stringWithoutSpaces
                    .substring(ACCOUNT_BLOCK_LENGTH));
        }

        return stringWithoutSpaces;
    }

    /**
     * Search through a String and remove any spaces
     */
    public final static String getSpacelessString(final String stringWithSpaces) {
        String stringWithNoSpaces = stringWithSpaces;

        if (stringWithSpaces != null) {
            stringWithNoSpaces = stringWithSpaces.replace(StringUtility.SPACE, StringUtility.EMPTY);
        }

        return stringWithNoSpaces;
    }

    public final static String getDashlessString(final String stringWithDash) {
        String stringWithNoDashes = stringWithDash;

        if (stringWithDash != null) {
            stringWithNoDashes = stringWithDash.replace(StringUtility.DASH, StringUtility.EMPTY);
        }

        return stringWithNoDashes;
    }

    /**
     * Launches the android native phone dialer with a given telephone number,
     * and awaits user's action to initiate the call.
     *
     * @param number         - a String representation of a phone number to dial.
     * @param callingContext - When calling this method, pass it the context/activity that
     *                       called this method.
     */
    public final static void dialNumber(final String number,
                                        final Context callingContext) {
        if (number != null && callingContext != null) {
            final Intent dialNumber = new Intent(Intent.ACTION_DIAL);

            dialNumber.setData(Uri.parse("tel:" + number));

            callingContext.startActivity(dialNumber);
        }
        return;
    }

    public final static void setViewGone(final View v) {
        if (v != null) {
            v.setVisibility(View.GONE);
        }
    }

    public final static void setViewVisible(final View v) {
        if (v != null) {
            v.setVisibility(View.VISIBLE);
        }
    }

    public final static void setViewInvisible(final View v) {
        if (v != null) {
            v.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * Set a text label visible and assign its text value to the given string.
     *
     * @param label - A TextView to set visible and change the text of.
     * @param text  - The String to present.
     */
    public final static void showLabelWithText(final TextView label,
                                               final String text) {
        label.setText(text);
        setViewVisible(label);
    }

    /**
     * Set a text label visible and assign its text value to the given string
     * resource.
     *
     * @param label   - A TextView to set visible and change the text of.
     * @param text    - The String resource to resolve and present.
     * @param context - the context that is using this method.
     */
    public final static void showLabelWithStringResource(final TextView label,
                                                         final int text, final Activity callingActivity) {
        label.setText(callingActivity.getResources().getString(text));
        setViewVisible(label);
    }

    /**
     * This takes a String that is formatted as a form of currency (e.g.
     * 1244.500, $1244.50, $1,244.5) and returns an int formatted as Bank
     * services use it (e.g. 124450).
     *
     * @return Integer representation of a currency amount
     */
    public final static int formatCurrencyStringAsBankInt(final String amount) {

        String newAmount = formatCurrencyAsStringWithoutSign(amount);
        newAmount = newAmount.replaceAll(StringUtility.COMMA, "");

        double d;
        try {
            d = Double.parseDouble(newAmount);
        } catch (final Exception e) {
            d = 0.0f;
        }

        return (int) (d * CENTS_IN_DOLLAR);
    }

    /**
     * This takes a String that is formatted as a form of currency (e.g.
     * 1244.500, $1244.50, $1,244.5) and returns a String formatted without '$' (e.g. 1,244.50).
     *
     * @return String representation of a currency amount without '$'. Returns
     * "0.00" if an errors occurs.
     */
    public final static String formatCurrencyAsStringWithoutSign(final String amount) {
        // Remove special characters before parsing
        String newAmount = amount.replaceAll("\\$", "");
        newAmount = newAmount.replaceAll(StringUtility.COMMA, "");

        double d;
        try {
            d = Double.parseDouble(newAmount);
        } catch (final Exception e) {
            d = 0.0f;
        }

        String outAmount = NumberFormat.getCurrencyInstance(Locale.US).format(d);
        outAmount = outAmount.replaceAll("\\$", "");

        return outAmount;
    }

    /**
     * This method can be used to reset the tiling of a background image if it is not getting tiled
     * correctly.
     *
     * @param view a view which contains a tiled background image.
     */
    public final static void fixBackgroundRepeat(final View view) {
        if (isGingerbread && view != null) {
            final Drawable bg = view.getBackground();
            if (bg instanceof BitmapDrawable) {
                final BitmapDrawable bmp = (BitmapDrawable) bg;
                bmp.mutate(); // make sure that we aren't sharing state anymore
                bmp.setTileModeXY(TileMode.REPEAT, TileMode.REPEAT);
            }
        }
    }

    /**
     * Method used to get the application version number for the application.
     * This method will gather the version name from the manifest.
     *
     * @return the version number from the manifest, empty string if it cannot be found
     */
    public final static String getApplicationVersionNumber() {
        String versionName = "";

        if(!Globals.getAppVersion().isEmpty()&&Globals.getAppVersion()!=null)
        {
            versionName = Globals.getAppVersion();
        }else
        {
            try {
                final WeakReference<Activity> activity = new WeakReference<Activity>(DiscoverActivityManager.getActiveActivity());
                //production crash resolved 17-Oct-2014
                if (activity != null && activity.get() != null)
                    versionName = activity.get().getPackageManager().getPackageInfo(activity.get().getPackageName(), 0).versionName;
                //production crash resolved 17-Oct-2014
            } catch (final NameNotFoundException e) {
                if (Log.isLoggable(TAG, Log.ERROR)) {
                    Log.e(TAG, "No Version available.");
                }

            }
        }

        return versionName;
    }

    /**
     * Convert an input stream to a string
     *
     * @param is - input to convert to string
     * @return the string
     */
    public final static String convertStreamToString(final InputStream is) throws IOException {
        final BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        final StringBuilder sb = new StringBuilder();
        String line = null;

        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        is.close();

        return sb.toString();
    }

    public static String nullToEmpty(@Nullable String string) {
        return string == null ? "" : string;
    }

    //********************************************** Gauva Related Code ********************************************

    public static boolean isNullOrEmpty(@Nullable String string) {
        return (string == null) || (string.length() == 0);
    }

    @CheckForNull
    public static Integer tryParse(String string) {
        int radix = 10;
        checkNotNull(string);
        checkArgument(radix >= 2, "Invalid radix %s, min radix is %s", new Object[]{Integer.valueOf(radix), Integer.valueOf(2)});

        checkArgument(radix <= 36, "Invalid radix %s, max radix is %s", new Object[]{Integer.valueOf(radix), Integer.valueOf(36)});

        int length = string.length();
        int i = 0;
        if (length == 0) {
            return null;
        }
        boolean negative = string.charAt(i) == '-';
        if (negative) {
            i++;
            if (i == length) {
                return null;
            }
        }
        return tryParse(string, i, radix, negative);
    }

    public static <T> T checkNotNull(T reference) {
        if (reference == null) {
            throw new NullPointerException();
        }
        return reference;
    }

    public static void checkArgument(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs) {
        if (!expression) {
            throw new IllegalArgumentException(format(errorMessageTemplate, errorMessageArgs));
        }
    }

    static String format(String template, @Nullable Object... args) {
        template = String.valueOf(template);


        StringBuilder builder = new StringBuilder(template.length() + 16 * args.length);

        int templateStart = 0;
        int i = 0;
        while (i < args.length) {
            int placeholderStart = template.indexOf("%s", templateStart);
            if (placeholderStart == -1) {
                break;
            }
            builder.append(template.substring(templateStart, placeholderStart));
            builder.append(args[(i++)]);
            templateStart = placeholderStart + 2;
        }
        builder.append(template.substring(templateStart));
        if (i < args.length) {
            builder.append(" [");
            builder.append(args[(i++)]);
            while (i < args.length) {
                builder.append(", ");
                builder.append(args[(i++)]);
            }
            builder.append(']');
        }
        return builder.toString();
    }

    @CheckForNull
    private static Integer tryParse(String string, int offset, int radix, boolean negative) {
        int max = -2147483648 / radix;
        int result = 0;
        int length = string.length();
        while (offset < length) {
            int digit = Character.digit(string.charAt(offset++), radix);
            if (digit == -1) {
                return null;
            }
            if (max > result) {
                return null;
            }
            int next = result * radix - digit;
            if (next > result) {
                return null;
            }
            result = next;
        }
        if (!negative) {
            result = -result;
            if (result < 0) {
                return null;
            }
        }
        if ((result > 2147483647) || (result < -2147483648)) {
            return null;
        }
        return Integer.valueOf(result);
    }

    public static <T> T checkNotNull(T reference, @Nullable Object errorMessage) {
        if (reference == null) {
            throw new NullPointerException(String.valueOf(errorMessage));
        }
        return reference;
    }

    public static void checkState(boolean expression, @Nullable Object errorMessage) {
        if (!expression) {
            throw new IllegalStateException(String.valueOf(errorMessage));
        }
    }

    //Throwables
    public static RuntimeException propagate(Throwable throwable) throws Throwable {
        propagateIfPossible((Throwable) checkNotNull(throwable));
        throw new RuntimeException(throwable);
    }

    public static <X extends Throwable> void propagateIfInstanceOf(@Nullable Throwable throwable, Class<X> declaredType) throws Throwable {
        if ((throwable != null) && (declaredType.isInstance(throwable))) {
            throw ((Throwable) declaredType.cast(throwable));
        }
    }

    public static void propagateIfPossible(@Nullable Throwable throwable) throws Throwable {
        propagateIfInstanceOf(throwable, Error.class);
        propagateIfInstanceOf(throwable, RuntimeException.class);
    }

    public static boolean isRunningOnHandset(Context context) {
        boolean isHandset = false;
        if(context!=null){
            isHandset= (context.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK)
                < Configuration.SCREENLAYOUT_SIZE_LARGE;}
        return isHandset;
    }

    //Remove Landscape Orientation in Handset.
    //Added for the User Story-US45678
    public static void lockOrientationInPortrait(Activity activity) {

        if(null != activity && !activity.getClass().getSimpleName().equalsIgnoreCase("CheckDepositCaptureActivityTablet")) {
            if (isRunningOnHandset(activity.getBaseContext())) {
                activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            } else {
                //activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
                //INC7602189 Fix change
                activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
            }
        }
    }
    /*

     */
    public static void linkifyNumber(Context context, TextView tv, boolean isLinkRequired,TrackingEventListener eventListener) {
        linkifyNumber(context, tv, Patterns.PHONE, isLinkRequired,eventListener);
    }
    //Defect fix 221590
    //US50433
    public static void linkifyNumber(Context context, TextView tv, boolean isLinkRequired) {
        linkifyNumber(context, tv, Patterns.PHONE, isLinkRequired,null);
    }
    public static void linkifyNumber(Context context, TextView tv, Pattern customPatterns, boolean isLinkRequired) {
         linkifyNumber( context,  tv,  customPatterns,  isLinkRequired,null);
    }

    public static void linkifyNumber(Context context, TextView tv, Pattern customPatterns, boolean isLinkRequired,TrackingEventListener eventListener) {
        if (isRunningOnHandset(context)) {
            Linkify.addLinks(tv, customPatterns, "tel:", new Linkify.MatchFilter() {
                public final boolean acceptMatch(CharSequence s, int start, int end) {
                    int digitCount = 0;

                    for (int i = start; i < end; i++) {
                        if (Character.isDigit(s.charAt(i))) {
                            digitCount++;
                            if (digitCount > 5) {
                                return true;
                            }
                        }
                    }
                    return false;
                }
            }, Linkify.sPhoneNumberTransformFilter);

            if (isLinkRequired) {
                tv.setMovementMethod(LinkMovementMethod.getInstance());
            }
            stripUnderlines(tv,eventListener);

        }
    }

    public static void stripUnderlines(TextView textView, TrackingEventListener eventListener) {
        if (!(textView.getText() instanceof Spannable)) {
            return;
        }
        Spannable s = (Spannable) textView.getText();
        URLSpan[] spans = s.getSpans(0, s.length(), URLSpan.class);
        for (URLSpan span : spans) {
            int start = s.getSpanStart(span);
            int end = s.getSpanEnd(span);
            s.removeSpan(span);
            span = new URLSpanNoUnderlineWithLinkTracking(span.getURL(),eventListener);
            s.setSpan(span, start, end, 0);
        }
        textView.setText(s);
    }

    public static String loadJSONFromAsset(Context context, String jsonName) {
        String json = null;
        try {
            InputStream is = context.getAssets().open(jsonName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public static String loadJSONFromRaw(Context context, String jsonName) {
        String json = null;
        try {
            InputStream is;
            /**Added condition for US57426*/
            if (jsonName.equalsIgnoreCase("infomessage.json"))
                is = context.getResources().openRawResource(R.raw.infomessage);
                // backlog US57795 fix start adeshm2
            else if (jsonName.equalsIgnoreCase("randomvalues.json"))
                is = context.getResources().openRawResource(R.raw.randomvalues);
                // backlog US57795 fix end adeshm2
            else
                is = context.getResources().openRawResource(R.raw.error);

            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public static Serializable getObjectFromJSONString(String jsonStr,
                                                       Class<?> modalClass) throws JsonSyntaxException {
        Gson gson = new Gson();
        Serializable pojoObject = (Serializable) gson.fromJson(jsonStr,
                modalClass);
        return pojoObject;
    }

    public static void setDisplayText(TextView view, String infoJsonKey, String localString) {
        String displayText = InfoMessageUtils.Instance().getErrorMessage(infoJsonKey);
        if (CommonUtils.isNullOrEmpty(displayText)) {
            view.setText(localString);
            view.setContentDescription(localString);
        } else {
            view.setText(displayText);
            view.setContentDescription(displayText);
        }


    }

    public static void setBitmapImage(ImageView imageView, ImageDir.DIR_ENUM dirName, String fileName, Bitmap defaultImage) {
        Bitmap bitmap = FileDownloader.getInstance().getBitmap(dirName, fileName);
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
        } else
            imageView.setImageBitmap(defaultImage);
    }

    public static void setLastRestCallTime() {
        final Calendar mCalendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        lastRestCallTime = mCalendar.getTimeInMillis();
    }

    /*
     * mgupta4 : Defect 202646 This methods are moved from WsProxy so to sync
     * the time update between Retrofit calls and WsAsyncTask calls
     */
    public static long getLastRestCallTime() {
        return lastRestCallTime;
    }
    public static boolean isXXXHDPIDevice(){
        DisplayMetrics metrics = new DisplayMetrics();
        DiscoverActivityManager.getActiveActivity().getWindowManager().getDefaultDisplay()
                .getMetrics(metrics);
        if(metrics.densityDpi >= DisplayMetrics.DENSITY_560){
            return true;
        }
        return false;
    }
    public static String getAbsoluteImageUrl(Context context, ImageDir.DIR_ENUM moduleEnum) {
        DisplayMetrics metrics = new DisplayMetrics();
        DiscoverActivityManager.getActiveActivity().getWindowManager().getDefaultDisplay()
                .getMetrics(metrics);

        String strDPIValue = "hdpi";
        switch (metrics.densityDpi) {
            case DisplayMetrics.DENSITY_MEDIUM:
                strDPIValue = "mdpi";
                break;
            case DisplayMetrics.DENSITY_XHIGH:
                strDPIValue = "xhdpi";
                break;
            case DisplayMetrics.DENSITY_XXHIGH:
                strDPIValue = "xxhdpi";
                break;
            case DisplayMetrics.DENSITY_XXXHIGH:
                strDPIValue = "xxxhdpi";
                break;
            case DisplayMetrics.DENSITY_HIGH:
            default:
                strDPIValue = "hdpi";
        }

        String deviceType = isRunningOnHandset(context) ? "handset"
                : "tablet";

        int orientation = context.getResources().getConfiguration().orientation;

        String currentOrienation = null;
        switch (orientation) {
            case Configuration.ORIENTATION_LANDSCAPE:
                currentOrienation = "land";
                break;

            case Configuration.ORIENTATION_PORTRAIT:
                currentOrienation = "port";
                break;
        }

        String imgURL = context.getResources()
                .getString(R.string.image_url_wildcard);

        String imgURLString = String.format(imgURL, moduleEnum.toString(),
                deviceType, currentOrienation, strDPIValue);

        Log.e("Sundeep", "base url: " + PortalUtils.getBaseUrl());
        return PortalUtils.getBaseUrl() + imgURLString;
    }

    public static String getAbsoluteMediaUrl(Context context, ImageDir.DIR_ENUM moduleEnum) {

        String deviceType = isRunningOnHandset(context) ? "handset"
                : "tablet";

        int orientation = context.getResources().getConfiguration().orientation;

        String currentOrienation = null;
        switch (orientation) {
            case Configuration.ORIENTATION_LANDSCAPE:
                currentOrienation = "land";
                break;

            case Configuration.ORIENTATION_PORTRAIT:
                currentOrienation = "port";
                break;
        }

        String mediaURL = context.getResources()
                .getString(R.string.media_url_wildcard);
        String mediaURLString = String.format(mediaURL, moduleEnum.toString(), deviceType, currentOrienation);

        Log.e("Sundeep", "base url: " + PortalUtils.getBaseUrl());
        return PortalUtils.getBaseUrl() + mediaURLString;
    }

    private static class DownloadCardMenu extends AsyncTask<String, Void, Void> {
        private static final String TAG = DownloadCardMenu.class.getSimpleName();

        @Override
        protected Void doInBackground(String... params) {
            try {
                OutputStream os = JsonDownloader.getInstance().getJsonFile(
                        params[0]);
                json = os.toString();
            } catch (Exception e) {
                // This means there is no json from server
                Log.e(TAG, e.toString());
                json = null;
            }
            return null;
        }
    }

    public static void handlePhoneNumberClick(Context context, CmnTextView phoneText,TextView phoneTextView, String contactMsg, PhoneNumClickCallback cb) {
        handlePhoneNumberClick(context,phoneText,phoneTextView,contactMsg);
        callback = cb;
    }

    // Handle generic Phone number tap event along with Analytics tag & Web url tap events

    public static void handlePhoneNumberClick(Context context, CmnTextView phoneText,TextView phoneTextView, String contactMsg) {
        SpannableString spanSpannableContactLink = new SpannableString(contactMsg);
        String extractedPhone="";
        Pattern pattern = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
        Pattern pattern1 = Pattern.compile("\\d{1}-\\d{3}-\\d{3}-\\d{4}");
        Matcher matcher = pattern.matcher(contactMsg);
        Matcher matcher1 = pattern1.matcher(contactMsg);
        Pattern patterWebUrl = Patterns.WEB_URL;
        Matcher matcherWebUrl = patterWebUrl.matcher(contactMsg.toLowerCase());

        while(matcher1.find()) {
            numberPositionStart = matcher1.start();
            numberPositionEnd = matcher1.end();
            extractedPhone = matcher1.group();
            char numberChar = contactMsg.charAt(numberPositionStart);
            spanSpannableContactLink.setSpan(new ForegroundColorSpan(context.getResources().getColor(R.color.blue_link)), numberPositionStart, numberPositionEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spanSpannableContactLink.setSpan(new HandleContactClick(context,extractedPhone,numberPositionStart,numberPositionEnd), numberPositionStart, numberPositionEnd, 0);
            System.out.println("Number " + numberChar + " found at position: " + numberPositionStart +"end position:"+ numberPositionEnd);
        }
        while(matcher.find()) {
            numberPositionStart = matcher.start();
            numberPositionEnd = matcher.end();
            extractedPhone = matcher.group();
            char numberChar = contactMsg.charAt(numberPositionStart);
            spanSpannableContactLink.setSpan(new ForegroundColorSpan(context.getResources().getColor(R.color.blue_link)), numberPositionStart, numberPositionEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spanSpannableContactLink.setSpan(new HandleContactClick(context,extractedPhone,numberPositionStart,numberPositionEnd), numberPositionStart, numberPositionEnd, 0);
            System.out.println("Number " + numberChar + " found at position: " + numberPositionStart +"end position:"+ numberPositionEnd);
        }

        while(matcherWebUrl.find()) {
            numberPositionStart = matcherWebUrl.start();
            numberPositionEnd = matcherWebUrl.end();
            char numberChar = contactMsg.charAt(numberPositionStart);
            spanSpannableContactLink.setSpan(new ForegroundColorSpan(context.getResources().getColor(R.color.blue_link)), numberPositionStart, numberPositionEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            Linkify.addLinks(spanSpannableContactLink, Linkify.WEB_URLS);
            System.out.println("Number " + numberChar + " found at position: " + numberPositionStart +"end position:"+ numberPositionEnd);
        }

        if(phoneText!=null)
        {
            phoneText.setText(spanSpannableContactLink);
            phoneText.setMovementMethod(LinkMovementMethod.getInstance());
        }
        if(phoneTextView!=null)
        {
            phoneTextView.setText(spanSpannableContactLink);
            phoneTextView.setMovementMethod(LinkMovementMethod.getInstance());
        }

    }

    private static class HandleContactClick extends ClickableSpan {
        private Context _context;
        private String message;
        private int startIndex;
        private int endIndex;

        public HandleContactClick(Context c, String msg,int start,int end) {
            _context = c;
            message = msg;
            startIndex=start;
            endIndex=end;
        }


        @Override
        public void onClick(View view) {
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put(_context.getApplicationContext().getString(R.string.prop1), AnalyticsPage.BT_PHONE_TXT+":"+message);
            if(callback!=null) {
                callback.onPhoneNumClicked();
                callback = null;//As this is a static reference reset to null.
            }
            else {
                TrackingHelper.trackClickEvents(AnalyticsPage.BT_PHONE_TXT, null, AnalyticsPage.LINK_TYPE_O, extras);
            }

            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + message));
            _context.startActivity(intent);
        }

        public void updateDrawState(TextPaint ds) {
            ds.setUnderlineText(false);
        }

    }



    private static class URLSpanNoUnderlineWithLinkTracking extends URLSpan {
        private TrackingEventListener eventListener;
        public URLSpanNoUnderlineWithLinkTracking(String url,TrackingEventListener eventListener) {
            super(url);
            this.eventListener = eventListener;
        }
        @Override
        public void onClick(View widget)
        {
            super.onClick(widget);
            if(eventListener!=null)
                eventListener.onClickEventTracking();
        }
        @Override
        public void updateDrawState(TextPaint ds) {
            super.updateDrawState(ds);
            ds.setUnderlineText(false);
        }

    }

    public static String toTitleCase(String input) {
        StringBuilder titleCase = new StringBuilder();

        boolean nextTitleCase = true;

        for (char c : input.toCharArray()) {
            if (Character.isSpaceChar(c)) {
                nextTitleCase = true;
            } else if (nextTitleCase) {
                c = Character.toTitleCase(c);
                nextTitleCase = false;
            }

            titleCase.append(c);
        }
        return titleCase.toString();
    }

    public static void forceSoftKeyboardHidden() {
        Activity activity = DiscoverActivityManager.getActiveActivity();
        if (activity == null) {
            return;
        }
        View currentFocus = activity.getCurrentFocus();
        if (currentFocus != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    /**
     * Get HTML formatted string
     */
    public static Spanned getHtmlFormattedText(String html) {
        Spanned result;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            result = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            result = Html.fromHtml(html);
        }
        return result;
    }

    public interface PhoneNumClickCallback{
        void onPhoneNumClicked();
    }

    /**
     * Method to return year from string date
     * Date should be in form: MM/dd/yyyy
     */
    public static String getYearFromDate(String inDateStr) {
        String SPLIT_REGEX = "/";
        int YEAR_INDEX = 2;
        String year = null;
        if (!TextUtils.isEmpty(inDateStr) && inDateStr.contains(SPLIT_REGEX)) {
            String[] dataArray = inDateStr.split(SPLIT_REGEX);
            year = dataArray[YEAR_INDEX];
        }
        return year;
    }
}