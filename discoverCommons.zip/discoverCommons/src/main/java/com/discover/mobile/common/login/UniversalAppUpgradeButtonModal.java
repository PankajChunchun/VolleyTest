package com.discover.mobile.common.login;

import com.discover.mobile.common.R;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

/**
 * A headless {@link DialogFragment} which shows one button modal or two button modal.
 */
public class UniversalAppUpgradeButtonModal extends DialogFragment {

    private ButtonDialogListener mButtonDialogListener;
    private Button mButtonOk;
    private Button mButtonCancel;
    private boolean isCancelable = false;
    private View mContentView;
    private TextView mTitleText;
    private TextView mContentText;
    private String mTitleString;
    private String mContentString;
    private String mOkButtonText;
    private String mCancelButtonText;

    public UniversalAppUpgradeButtonModal() {
    }

    /**
     * Creates two button modal.
     *
     * @param title                - Title text
     * @param content              - Content text.
     * @param okButton             - Possitive button text.
     * @param cancelButton         - Negative button text.
     * @param buttonDialogListener - {@link ButtonDialogListener}.
     */
    // We must not declaire constructor for fragment. But this modal is being used as headless fragment, so it will not cause any issue on orientation change.
    public UniversalAppUpgradeButtonModal(String title, String content, String okButton, String cancelButton, ButtonDialogListener buttonDialogListener) {
        this.mTitleString = title;
        this.mContentString = content;
        this.mOkButtonText = okButton;
        this.mCancelButtonText = cancelButton;
        this.mButtonDialogListener = buttonDialogListener;
    }

    /**
     * Creates one button modal.
     *
     * @param title                - Title text
     * @param content              - Content text.
     * @param okButton             - Possitive button text.
     * @param buttonDialogListener - {@link ButtonDialogListener}.
     */
    /*// We must not declaire constructor for fragment. But this modal is being used as headless fragment, so it will not cause any issue on orientation change.
    public UniversalAppUpgradeButtonModal(String title, String content, String okButton, ButtonDialogListener buttonDialogListener) {
        this.mTitleString = title;
        this.mContentString = content;
        this.mOkButtonText = okButton;
        this.mCancelButtonText = null;
        this.mButtonDialogListener = buttonDialogListener;
    }*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContentView = inflater.inflate(R.layout.universal_app_upgrade_modal, container);
        mButtonOk = (Button) mContentView.findViewById(R.id.modal_ok_button);
        mButtonCancel = (Button) mContentView.findViewById(R.id.modal_alert_cancel);
        mTitleText = (TextView) mContentView.findViewById(R.id.modal_title);
        mContentText = (TextView) mContentView.findViewById(R.id.modal_content);
        if (TextUtils.isEmpty(mCancelButtonText)) {
            setupOneButtonModal();
            mButtonCancel.setVisibility(View.GONE);

        } else {
            setupTwoButtonModal();
            mButtonCancel.setVisibility(View.VISIBLE);

        }
        //getDialog().setCancelable(isCancelable);
        return mContentView;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
//       mButtonDialogListener = (ButtonDialogListener) activity;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        return dialog;
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        ((TwoButtonDialogListener) mButtonDialogListener).doNegativeClick();
    }

    public void setButtonDialogListener(ButtonDialogListener buttonDialogListener) {
        mButtonDialogListener = buttonDialogListener;
    }

    private void setupTwoButtonModal() {
        setupOneButtonModal();
        mButtonCancel.setText(mCancelButtonText);
        mButtonCancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ((TwoButtonDialogListener) mButtonDialogListener).doNegativeClick();
                dismiss();
            }
        });
    }

    private void setupOneButtonModal() {
        mButtonOk.setText(mOkButtonText);
        mTitleText.setText(mTitleString);
        mContentText.setText(mContentString);
        mButtonOk.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mButtonDialogListener.doPositiveClick();

            }
        });
    }

    private interface ButtonDialogListener {
        void doPositiveClick();
    }

    public static interface TwoButtonDialogListener extends ButtonDialogListener {
        void doNegativeClick();
    }

    public static interface OneButtonDialogListener extends ButtonDialogListener {
    }
}