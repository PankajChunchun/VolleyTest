package com.discover.mobile.common.fico.presenter;

/**
 * Created by slende on 5/5/2017.
 * Presenter for FicoCreditScorecardMasterFrag
 */

public interface FicoCreditScoreMasterFragPresenter {
    void getFicoCreditScoreData();
}
