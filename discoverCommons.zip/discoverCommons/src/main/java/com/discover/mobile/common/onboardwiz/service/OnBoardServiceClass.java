package com.discover.mobile.common.onboardwiz.service;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.ui.FingerPrintSetupFragment;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.onboardwiz.fragment.paperless.OnBoardPaperlessFragment;
import com.discover.mobile.common.onboardwiz.fragment.passcode.OnBoardBasePasscodeFragment;
import com.discover.mobile.common.onboardwiz.fragment.passcode.OnBoardEnablePasscodeFragment;
import com.discover.mobile.common.onboardwiz.utils.BankOnBoardingCallBack;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.shared.utils.TokenUtil;
import com.discover.mobile.network.error.bean.ErrorBean;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.util.Log;

import java.util.HashMap;

import static com.discover.mobile.common.onboardwiz.utils.OnBoardConstant.PASSCODE_PAGE_STATE.VERIFY_PAGE;

/**
 * Created by 409992 on 5/18/2016.
 */

public class OnBoardServiceClass {
    Context context = null;
    private FingerPrintUtils fingerPrintUtils;

    public OnBoardServiceClass(Context context) {
        this.context = context;
    }

    public void getPasscodeStatusCard(final Context context, String deviceToken, final Fragment fragment) {
        FacadeFactory.getCardOnBoardFacadeImpl().getPasscodeStatusService(context, deviceToken, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                Boolean isEnable = (Boolean) data;
                if (fragment != null && fragment instanceof OnBoardEnablePasscodeFragment) {
                    if (isEnable) {
                        ((OnBoardEnablePasscodeFragment) fragment).navTo(OnBoardConstant.PASSCODE_PAGE_STATE.EXISTING_PAGE);
                    } else {
                        ((OnBoardEnablePasscodeFragment) fragment).navTo(OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE);
                    }
                }
            }

            @Override
            public void onError(Object data) {
//                listener.onError(data);

            }
        });
    }

    public void matchPasscodeCard(final Context context, final String mPasscode, final Fragment fragment) {
        if (fragment != null && fragment instanceof FingerPrintSetupFragment) {
            fingerPrintUtils = new FingerPrintUtils(context);
        }
        FacadeFactory.getCardOnBoardFacadeImpl().getMatchPasscodeService(context, mPasscode, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    ((OnBoardBasePasscodeFragment) fragment).bindDeviceRequest();
//                    ((OnBoardBasePasscodeFragment) fragment).changeStateTo(VERIFY_PAGE);
                }
            }

            @Override
            public void onError(Object data) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    ((OnBoardBasePasscodeFragment) fragment).handleError(data);
                }

            }
        });

    }

    public void bindRequestCard(final Context context, final String mPasscode, final String deviceToken, final Fragment fragment) {
        FacadeFactory.getCardOnBoardFacadeImpl().getPasscodeBindService(context, deviceToken, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    saveTokenDetailsAfterEnablingPasscode(context, deviceToken, mPasscode);
                    ((OnBoardBasePasscodeFragment) fragment).navToPasscodeSuccess();
                }
            }

            @Override
            public void onError(Object data) {
                ((OnBoardBasePasscodeFragment) fragment).handleError(data);
            }
        });
    }

    public void validatePasscodeCard(final Context context, final String mPasscode, final Fragment fragment) {
        FacadeFactory.getCardOnBoardFacadeImpl().getValidatePasscodeSyntax(context, mPasscode, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
//                    ((OnBoardBasePasscodeFragment) fragment).changeStateTo(VERIFY_PAGE);
//                        matchPasscode();
                    ((OnBoardBasePasscodeFragment) fragment).changeStateTo(VERIFY_PAGE, mPasscode);
                }
            }

            @Override
            public void onError(Object data) {
                ((OnBoardBasePasscodeFragment) fragment).handleError(data);
            }
        });
    }

    /**
     * This method is to enable the QuickView service call once accept button clicked for both card
     * and bank
     * service calls getting initiated through facade method
     */

    public void enableQuickView(final NetworkRequestListener listener) {
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankOnBoardActivityFacade().callQuickViewBindServiceCallRetro(context, TokenUtil.genClientBindingToken(), new BankOnBoardingCallBack() {
                @Override
                public void success(Context mContext) {
                    Intent quickViewIntent = new Intent();
                    quickViewIntent.setAction("com.discover.mobile.bank.QuickViewEnabled");
                    DiscoverActivityManager.getActiveActivity().sendBroadcast(quickViewIntent);
                    listener.onSuccess(null);
                }

                @Override
                public void failure(Context mContext) {
                    //This failure scenario will be used to shown the Inline error.
                }

                @Override
                public void deviceAlreadyBinded(Context mContext) {
                    //This override method will be used for passcode.
                }

                @Override
                public boolean showErrorModal() {
                    return true;
                }
            });
        } else {
            FacadeFactory.getCardOnBoardFacadeImpl().getQuickViewUpdateService(context, false, new NetworkRequestListener() {
                @Override
                public void onSuccess(Object data) {
                    Log.v("OnBoard", "QV success");
                    listener.onSuccess(data);
                }

                @Override
                public void onError(Object data) {
                    Log.v("OnBoard", "QV error");
                    ErrorBean bean = (ErrorBean) data;
                    String errorCode = OnBoardHelper.getHttpAndErrorStatus(bean);
                    listener.onError(errorCode);
                }
            });
        }
    }

    public void createPasscodeCard(final Context context, final String deviceToken, final String mPasscode, final Fragment fragment) {
        FacadeFactory.getCardOnBoardFacadeImpl().getCreatePasscodeService(context, deviceToken, mPasscode, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    saveTokenDetailsAfterEnablingPasscode(context, deviceToken, mPasscode);
                    ((OnBoardBasePasscodeFragment) fragment).navToPasscodeSuccess();
//                    ((OnBoardBasePasscodeFragment) fragment).bindDeviceRequest();
                }
            }

            @Override
            public void onError(Object data) {
                ((OnBoardBasePasscodeFragment) fragment).handleError(data);
            }
        });
    }

    public void resetPasscodeCard(final Context context, final String deviceToken, final String mPasscode, final Fragment fragment) {
        FacadeFactory.getCardOnBoardFacadeImpl().getResetPasscodeService(context, deviceToken, mPasscode, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                saveTokenDetailsAfterEnablingPasscode(context, deviceToken, mPasscode);
                ((OnBoardBasePasscodeFragment) fragment).navToPasscodeSuccess();
            }

            @Override
            public void onError(Object data) {
                ((OnBoardBasePasscodeFragment) fragment).handleError(data);
            }
        });
    }

    /**
     * This method is to enable the Get Passcode service call once accept button clicked for bank
     * service calls getting initiated through facade method
     */
    public void getPasscodeStatusBank(final Context mContext, final Fragment fragment) {
        FacadeFactory.getBankOnBoardActivityFacade().callGetPasscodeStatusServiceCallRetro(mContext, null, new BankOnBoardingCallBack() {
            @Override
            public void success(Context mContext) {
                //Call the fadeout animation on success of Passcode Status service call
                ((OnBoardEnablePasscodeFragment) fragment).PasscodeFadeOutAnimation();
                // ((OnBoardEnablePasscodeFragment) fragment).navTo(OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE);
            }

            @Override
            public void failure(Context mContext) {

            }

            @Override
            public void deviceAlreadyBinded(Context mContext) {
                ((OnBoardEnablePasscodeFragment) fragment).navTo(OnBoardConstant.PASSCODE_PAGE_STATE.EXISTING_PAGE);
            }

            @Override
            public boolean showErrorModal() {
                return true;
            }
        }, null);
    }

    /**
     * This method is to initiate the Validate Passcode service call through facade method for bank
     * OnSuccess will be navigated to verification screen
     * OnFailure will show the inline error message
     */

    public void validatePasscodeBank(final Context mContext, final String passcodeString, String deviceToken, final Fragment fragment) {

        FacadeFactory.getBankOnBoardActivityFacade().callValidateCandidatePasscodeServicecallRetro(mContext, passcodeString, deviceToken, new BankOnBoardingCallBack() {
            @Override
            public void success(Context mContext) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    ((OnBoardBasePasscodeFragment) fragment).changeStateTo(OnBoardConstant.PASSCODE_PAGE_STATE.VERIFY_PAGE, passcodeString);
                }
            }

            @Override
            public void failure(Context mContext) {
                ((OnBoardBasePasscodeFragment) fragment).showErrorMessage(R.string.create_passcode_ribbon_error);
                //US53334 Start-OnBoarding analytics
                if (Globals.isBankLoginSelected()) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_10, DiscoverActivityManager.getActiveActivity()
                                    .getResources().getString(R.string.create_passcode_ribbon_error));
                    TrackingHelper.trackBankPage(null, extras);
                }
                //US53334 End
            }

            @Override
            public void deviceAlreadyBinded(Context mContext) {
                //this method will be used only in get passcode service call to bind the device.
            }

            @Override
            public boolean showErrorModal() {
                return false;
            }
        });
    }

    /**
     * This method is to initiate the Verify Passcode service call through facade method for bank
     * OnSuccess will be navigated to the Bind service call
     * OnFailure will show the inline error message
     */


    public void verifyPasscodeBank(final Context mContext, final String passcodeString, final Fragment fragment) {

        FacadeFactory.getBankOnBoardActivityFacade().callVerifyCurrentPasscodeServiceCallRetro(mContext, passcodeString, new BankOnBoardingCallBack() {

            @Override
            public void success(Context mContext) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    ((OnBoardBasePasscodeFragment) fragment).bindDeviceRequest();
                }
            }


            @Override
            public void failure(Context mContext) {
                ((OnBoardBasePasscodeFragment) fragment).showErrorMessage(R.string.verify_passcode_ribbon_message);
                //US53334 Start-OnBoarding analytics
                if (Globals.isBankLoginSelected()) {
                    ((OnBoardBasePasscodeFragment) fragment).showErrorMessage(R.string.verify_passcode_ribbon_message);
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_10, DiscoverActivityManager.getActiveActivity()
                                    .getResources().getString(R.string.verify_passcode_ribbon_message));
                    TrackingHelper.trackBankPage(null, extras);
                }//US53334 End
            }

            @Override
            public void deviceAlreadyBinded(Context mContext) {
                //this method will be used only in get passcode service call to bind the device.
            }

            @Override
            public boolean showErrorModal() {
                return false;
            }
        }, null);
    }

    /**
     * This method is to initiate the BindDevice Passcode service call through facade method for
     * bank
     * OnSuccess will be navigated to success screen
     * OnFailure will show the inline error message
     */

    public void bindRequestBank(final Context mContext, String deviceToken, boolean isUnbind, final Fragment fragment) {

        FacadeFactory.getBankOnBoardActivityFacade().callBindDeviceServicecallRetro(mContext, deviceToken, false, new BankOnBoardingCallBack() {

            @Override
            public void success(Context mContext) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    ((OnBoardBasePasscodeFragment) fragment).navToPasscodeSuccess();
                }
            }

            @Override
            public void failure(Context mContext) {
                ((OnBoardBasePasscodeFragment) fragment).showErrorMessage(R.string.verify_passcode_ribbon_message);
            }

            @Override
            public void deviceAlreadyBinded(Context mContext) {
                //this method will be used only in get passcode service call to bind the device.
            }

            @Override
            public boolean showErrorModal() {
                return false;
            }
        });
    }

    /**
     * This method is to initiate the Create Passcode service call through facade method for bank
     * OnSuccess will be navigated to passcode success screen
     * OnFailure will show the inline error message
     */


    public void createPasscodeBank(final Context mContext, final String passcodeString, String deviceToken, final Fragment fragment) {

        FacadeFactory.getBankOnBoardActivityFacade().callCreatePasscodeServiceCallRetro(mContext, passcodeString, deviceToken, new BankOnBoardingCallBack() {

            @Override
            public void success(Context mContext) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    ((OnBoardBasePasscodeFragment) fragment).navToPasscodeSuccess();
                }
            }


            @Override
            public void failure(Context mContext) {
                ((OnBoardBasePasscodeFragment) fragment).showErrorMessage(R.string.verify_passcode_ribbon_message);
                //US53334 Start-OnBoarding analytics
                if (Globals.isBankLoginSelected()) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_10, DiscoverActivityManager.getActiveActivity()
                                    .getResources().getString((R.string.bank_analytics_onboard_passcode_err_msg), R.string.verify_passcode_ribbon_message));
                    TrackingHelper.trackBankPage(null, extras);
                }
                //US53334 End
            }

            @Override
            public void deviceAlreadyBinded(Context mContext) {
                //this method will be used only in get passcode service call to bind the device.
            }

            @Override
            public boolean showErrorModal() {
                return false;
            }
        });
    }

    /**
     * This method is to initiate the Reset Passcode service call through facade method for bank
     * OnSuccess will be navigated to Bind service call
     * OnFailure will show the inline error message
     */

    public void resetPasscodeBank(final Context mContext, final String passcodeString, final String deviceToken, final Fragment fragment) {

        FacadeFactory.getBankOnBoardActivityFacade().callResetPasscodeServicecallRetro(mContext, passcodeString, deviceToken, new BankOnBoardingCallBack() {

            @Override
            public void success(Context mContext) {
                if (fragment != null && fragment instanceof OnBoardBasePasscodeFragment) {
                    bindRequestBank(mContext, deviceToken, false, fragment);
                }
            }


            @Override
            public void failure(Context mContext) {
                ((OnBoardBasePasscodeFragment) fragment).showErrorMessage(R.string.verify_passcode_ribbon_message);
                //US53334 Start-OnBoarding analytics
                if (Globals.isBankLoginSelected()) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_10, DiscoverActivityManager.getActiveActivity()
                                    .getResources().getString((R.string.bank_analytics_onboard_passcode_err_msg), R.string.verify_passcode_ribbon_message));
                    TrackingHelper.trackBankPage(null, extras);
                }
                //US53334 End
            }

            @Override
            public void deviceAlreadyBinded(Context mContext) {
                //this method will be used only in get passcode service call to bind the device.
            }

            @Override
            public boolean showErrorModal() {
                return false;
            }
        });
    }


    private void saveTokenDetailsAfterEnablingPasscode(Context context, String deviceToken, String passcode) {
        PasscodeUtils pUtils = new PasscodeUtils(context, true);
        try {
            pUtils.createPasscodeToken(deviceToken);
        } catch (Exception e) {
            e.printStackTrace();
        }
        pUtils.storePasscodeUserID(passcode);
    }

    /**
     * Make a Paperless status service call
     *
     * @param fragment       Reference to the Fragment
     * @param accountId      Reference to the account id
     * @param paperlessState Reference to the paperless state
     */
    public void getPapperlessStatus(final Fragment fragment, String accountId, final boolean paperlessState) {

        FacadeFactory.getBankOnBoardActivityFacade().callGetPaperlessServiceCallRetro(fragment.getActivity(), accountId, paperlessState, new BankOnBoardingCallBack() {
                    @Override
                    public void success(Context mContext) {
                        ((OnBoardPaperlessFragment) fragment).handleSuccess(context, paperlessState);

                    }

                    @Override
                    public void failure(Context mContext) {
                        ((OnBoardPaperlessFragment) fragment).handleError();
                    }

                    @Override
                    public void deviceAlreadyBinded(Context mContext) {

                    }

                    @Override
                    public boolean showErrorModal() {
                        return true;
                    }
                }

        );
    }

    /*Start Changes US139848*/
    public void getEwalletEligiblityService(final Context context, final NetworkRequestListener networkRequestListener) {
        FacadeFactory.getCardOnBoardFacadeImpl().getEwalletProvisioningEligibilityService(context, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                networkRequestListener.onSuccess(data);
            }

            @Override
            public void onError(Object data) {
                networkRequestListener.onError(data);
            }
        });
    }

    /*End Changes US139848*/
}