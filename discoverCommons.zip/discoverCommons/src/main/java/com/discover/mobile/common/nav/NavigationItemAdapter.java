package com.discover.mobile.common.nav;

//import roboguice.inject.ContextSingleton;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

//import com.google.inject.Inject;

//@ContextSingleton
public class NavigationItemAdapter extends ArrayAdapter<NavigationItem> {

    static final int TYPE_SECTION = 0;
    static final int TYPE_SUB_SECTION = TYPE_SECTION + 1;
    static final int TYPE_COUNT = TYPE_SUB_SECTION + 1;

    //@Inject
    private static LayoutInflater layoutInflater;
    private static NavigationItemAdapter instance;
    private NavigationItem selectedItem;
    private int pushCount = 0;

    /**
     * Uses a singleton design pattern
     */
    //@Inject
    private NavigationItemAdapter(final Context context) {
        super(context, 0);
    }

    public static NavigationItemAdapter getInstance(final Context context) {
        if (instance == null) {
            instance = new NavigationItemAdapter(context);
        }
        layoutInflater = ((Activity) context).getLayoutInflater();
        return instance;
    }

    public static void resetInstance() {
        instance = null;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getItemViewType(final int position) {
        return getItem(position).view.getViewType();
    }

    @Override
    public View getView(final int position, final View convertView, final ViewGroup parent) {
        getItem(position).view.setPushCount(pushCount);
        return getItem(position).view.getView(convertView, layoutInflater, position);
    }

    NavigationItem getSelectedItem() {
        return selectedItem;
    }

    void setSelectedItem(final NavigationItem selectedItem) {
        this.selectedItem = selectedItem;
    }

    NavigationRoot getNavigationRoot() {
        return (NavigationRoot) getContext();
    }

    public void setPushCount(final int pushCount) {
        this.pushCount = pushCount;
    }
}
