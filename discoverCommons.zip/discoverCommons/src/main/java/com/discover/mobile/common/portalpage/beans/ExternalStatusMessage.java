package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ExternalStatusMessage implements Serializable {

    private static final long serialVersionUID = 425585194383645235L;

    @SerializedName("title")
    private String title;

    @SerializedName("body")
    private String body;

    /**
     * @return The title
     */
    public String getExternalStatusTitle() {
        return title;
    }

    /**
     * @param title The title
     */
    public void setExternalStatusTitle(String title) {
        this.title = title;
    }

    /**
     * @return The body
     */
    public String getExternalStatusBody() {
        return body;
    }

    /**
     * @param body The body
     */
    public void setExternalStatusBody(String body) {
        this.body = body;
    }

}
