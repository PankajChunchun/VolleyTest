package com.discover.mobile.common.fico.service;

import com.discover.mobile.common.fico.bean.FicoCreditScore;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Headers;

/**
 * Created by slende on 5/4/2017.
 * Fico credit score service interface
 */
public interface FicoCreditScoreServiceInterface {

    @Headers("Content-Type: application/json")
    @GET("/cardsvcs/acs/ems/v3/ficoscore")
    void getFicoCreditDetails(Callback<FicoCreditScore> ficoScoreDetails);


}
