package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Bean class for DynamicBannerMessage data which will be shown on AC-Home Page
 */
public class DynamicBannerMessages implements Serializable {



    @SerializedName("TIER_ONE")
    private ArrayList<TierOne> TIER_ONE;

    @SerializedName("MISCELLANEOUS")
    private ArrayList<Miscellaneous> MISCELLANEOUS;

    public ArrayList<Miscellaneous> getMISCELLANEOUS() {
        return MISCELLANEOUS;
    }

    public void setMISCELLANEOUS(ArrayList<Miscellaneous> MISCELLANEOUS) {
        this.MISCELLANEOUS = MISCELLANEOUS;
    }

    public ArrayList<TierOne> getTIER_ONE() {
        return TIER_ONE;
    }

    public void setTIER_ONE(ArrayList<TierOne> TIER_ONE) {
        this.TIER_ONE = TIER_ONE;
    }

}
