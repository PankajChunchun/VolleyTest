package com.discover.mobile.common.fingerprint.utils;

/**
 * Fingerprint constant on 11/11/2016.
 */
public class FingerPrintConstants {

    public static final int TYPE_PRIVACY_AND_TERMS = 0;
    public static final int TYPE_PROVIDE_FEEDBACK = 1;
    public static final int DIALOG_SETUP_FINGERPRINT = 2;
    public static final int DIALOG_ENABLE_FINGERPRINT = 3;
    public static final int DIALOG_DISABLE_FINGERPRINT = 4;
}
