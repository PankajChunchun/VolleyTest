package com.discover.mobile.common.facade;

import java.util.HashMap;

/**
 * Deeplink facade for Highlighted-features and WhatsNew, which handles BANK deeplinks
 * for prelogin or postlogin.
 *
 * @author pkuma13
 */

public interface HighlightedFeatureDeeplinkBankFacade extends HighlightedFeatureDeeplinkFacade {

    // US59004 : User sees Passcode page of Onboarding Wizard; delay Passcode Reminder as if "Remind Me Later" was tapped on Passcode Reminder upon first login.
    public void updateReminderLogic();

    //End: US72282: FingerPrint Analytics
    public HashMap getHashMap();
    //End: US72282: FingerPrint Analytics

}
