package com.discover.mobile.common.shared.net;


import com.discover.mobile.common.shared.callback.AsyncCallback;
import com.discover.mobile.common.shared.utils.CommonUtils;

public class StrongReferenceHandler<V> extends TypedReferenceHandler<V> {

    private final AsyncCallback<V> callback;

    public StrongReferenceHandler(final AsyncCallback<V> callback) {
        CommonUtils.checkNotNull(callback, "callback cannot be null");

        this.callback = callback;
    }

    @Override
    protected AsyncCallback<V> getCallback() {
        return callback;
    }

}
