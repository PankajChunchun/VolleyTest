package com.discover.mobile.common.appmessaging.helper;

import com.google.gson.annotations.SerializedName;

/**
 * This is used for tracking Appmessage information provided in a JSON
 * response to a Bank web-service API invocation.
 */
public class TrackAppMessage {

    @SerializedName("id")
    public String id;

    @SerializedName("interaction")
    public String interaction;

    @SerializedName("menu")
    public boolean menu;

}
