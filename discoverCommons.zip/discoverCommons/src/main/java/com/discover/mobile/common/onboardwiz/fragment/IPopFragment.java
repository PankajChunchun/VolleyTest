package com.discover.mobile.common.onboardwiz.fragment;

/**
 * Created by 482127 on 4/26/2016.
 * This interface implements callback related to
 */
public interface IPopFragment {
    public boolean popBackStack();

    public void updateCurrentPage();
}
