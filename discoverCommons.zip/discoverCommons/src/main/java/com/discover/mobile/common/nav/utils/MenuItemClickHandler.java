package com.discover.mobile.common.nav.utils;

import com.discover.mobile.common.BaseFragment;
import com.discover.mobile.common.nav.DiscoverBaseActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.text.Html;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Handler class to manage the click events from the item in LHN
 */
public class MenuItemClickHandler {

    private Context mContext;


    public MenuItemClickHandler(Context context) {

        mContext = context;


    }

    public void handleClickEvents(Toolbar toolbar, Launcher launcher) throws ClassNotFoundException, InstantiationException, IllegalAccessException

    {
        //check if the incoming menu has method invocation
        if (launcher.getmMethodName() != null && launcher.getmObject() != null) {
            //since we have method incocation we also have the object set to the launcher instance
            if (launcher.getmObject() instanceof Fragment) {
                //since we are here it means that the method invocation is by passing method as parameter to the fragment
                Fragment fragToInvoke = (Fragment) launcher.getmObject();
                Bundle dataToPass = new Bundle();
                dataToPass.putString("Method name", launcher.getmMethodName());
                fragToInvoke.setArguments(dataToPass);
                DiscoverBaseActivity activity = (DiscoverBaseActivity) mContext;
                activity.makeFragmentVisible(fragToInvoke, true, true);
            } else if (launcher.getmObject() instanceof Intent)

            {
                //pass the method to the activity as a parameter
                Intent intent = (Intent) launcher.getmObject();
                intent.putExtra("Sample_Parameter", launcher.getmMethodName());
                mContext.startActivity(intent);


            } else {
                //invoke the method on the object given ,so this is java class with some method
                //getInstanceOfFunction(launcher.getmObject(),launcher.getmMethodName());
            }
        } else

        {
            //Now since we dont have the method ,that means the invocation is for the fragment or activity only

            if (launcher.getmObject() instanceof Intent) {
                //check if the incoming object if to load the ativity and we launch the activity
                mContext.startActivity((Intent) launcher.getmObject());
            } else if (launcher.getmObject() instanceof Fragment) {

                //object id instance of the fragment ,we do the fragment transaction
                DiscoverBaseActivity activity = (DiscoverBaseActivity) mContext;
                BaseFragment fragmentToInvoke = (BaseFragment) launcher.getmObject();

                //set default title as blank
                String fragmentTitle = "";
                //check if the title is not required and if title is -1 that means the page is required but not a LHN page
                if (fragmentToInvoke.getActionBarTitle() != -1) {
                    //since title is present and the page is an LHN page we can load the page with highlighting
                    fragmentTitle = mContext.getString(fragmentToInvoke.getActionBarTitle());
                }

                String actionBarTitle = toolbar.getTitle().toString();
              /*Checking the title of the Action bar and the title of the fragment to
              check whether the fragment transaction should be done or not*/

                if (!Html.fromHtml(actionBarTitle).toString().equalsIgnoreCase(Html.fromHtml(fragmentTitle).toString())) {
                    activity.makeFragmentVisible((Fragment) launcher.getmObject(), true, true);
                } else {
                /*if the title are same we are checking whether the fragment on top of the
                 stack is same as the on that is invoked*/
                    if (null == activity.getCurrentFragment() || !fragmentToInvoke.getClass().getSimpleName().equals(activity.getCurrentFragment().getTag())) {
                        activity.makeFragmentVisible((Fragment) launcher.getmObject(), true, true);
                    }

                }
            }


        }


    }


    /**
     * This method wil invoke the method using reflection on the object
     *
     * @param obj        instance of activity,class or Fragment
     * @param methodName method name to be invoked.
     */
    private void getInstanceOfFunction(Object obj, String methodName) {
        Method method = null;
        //no paramater
        Class noparams[] = {};
        try {
            method = obj.getClass().getDeclaredMethod(methodName, noparams);
            method.invoke(obj, null);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

    }


}
