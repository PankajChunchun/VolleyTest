package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by slende on 2/24/2017.
 * Added this class for US89215 - Messaging App SDK Integration
 */

public class OAuthClientDetails implements Serializable {

    @SerializedName("clientID")
    private String clientID;

    @SerializedName("scope")
    private String scope;

    @SerializedName("state")
    private String state;

    @SerializedName("returnURI")
    private String returnURI;

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getReturnURI() {
        return returnURI;
    }

    public void setReturnURI(String returnURI) {
        this.returnURI = returnURI;
    }
}
