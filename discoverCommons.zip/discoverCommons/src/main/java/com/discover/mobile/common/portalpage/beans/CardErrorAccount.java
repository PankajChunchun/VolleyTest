package com.discover.mobile.common.portalpage.beans;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.utils.PortalConstants;

import java.io.Serializable;

public class CardErrorAccount implements PortalBoxInterface, Serializable {
    private static final long serialVersionUID = 2803421668447076588L;

    @Override
    public String getSortId() {
        return PortalConstants.CARD_ERROR_BOX_ID;
    }
}
