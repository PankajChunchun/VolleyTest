package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class NavigationMenuItem {

    @SerializedName("GroupLabel")
    private String GroupTitle;
    @SerializedName("Subitems")
    private List<NavigationMenuSubItem> navigationMenuSubItems;
    private String ItemToBeRemoved;
    @SerializedName("LaunchClass")
    private String launchClassName;
    @SerializedName("Type")
    private String type;
    @SerializedName("KillSwitchConstants")
    private String killSwitchConstants;
    @SerializedName("ExcludedCardType")
    private String ExcludedCardType;
    @SerializedName("LaunchKey")
    private String LaunchKey;
    @SerializedName("PageTitle")
    private String PageTitle;
    @SerializedName("MethodName")
    private String methodName;
    @SerializedName("Analytics")
    private String analyticsValue;

    private String selectedGroupItemTitle;
    private String selectedchildItemTitle;

    public String getPageTitle() {
        return PageTitle;
    }

    public void setPageTitle(String pageTitle) {
        PageTitle = pageTitle;
    }

    public String getComponentkey() {
        return LaunchKey;
    }

    public void setComponentkey(String componentkey) {
        LaunchKey = componentkey;
    }

    public String getExcludedCardType() {
        return ExcludedCardType;
    }

    public void setExcludedCardType(String excludedCardType) {
        ExcludedCardType = excludedCardType;
    }

    public String getKillSwitchConstants() {
        return killSwitchConstants;
    }

    public void setKillSwitchConstants(String killSwitchConstants) {
        this.killSwitchConstants = killSwitchConstants;
    }

    public String getRemovedItem() {
        return ItemToBeRemoved;
    }

    public void setRemovedItem(String removedItem) {
        this.ItemToBeRemoved = removedItem;
    }

    public String getSelectedGroupItemTitle() {
        return selectedGroupItemTitle;
    }

    public void setSelectedGroupItemTitle(String selectedGroupItemTitle) {
        this.selectedGroupItemTitle = selectedGroupItemTitle;
    }

    public String getSelectedchildItemTitle() {
        return selectedchildItemTitle;
    }

    public void setSelectedchildItemTitle(String selectedchildItemTitle) {
        this.selectedchildItemTitle = selectedchildItemTitle;
    }

    public String getSelectedchildItem() {
        return selectedchildItemTitle;
    }

    public void setSelectedchildItem(String selectedchildItemTitle) {
        this.selectedchildItemTitle = selectedchildItemTitle;
    }

    public String isSelectedGroupItem() {
        return selectedGroupItemTitle;
    }

    public void setSelectedGroupItem(String selectedGroupItemTitle) {
        this.selectedGroupItemTitle = selectedGroupItemTitle;
    }

    public String getGroupTitle() {
        return GroupTitle;
    }

    public void setGroupTitle(String groupTitle) {
        this.GroupTitle = groupTitle;
    }

    public List<NavigationMenuSubItem> getNavigationMenuSubItems() {
        return navigationMenuSubItems;
    }

    public void setNavigationMenuSubItems(
            List<NavigationMenuSubItem> navigationMenuSubItems) {
        this.navigationMenuSubItems = navigationMenuSubItems;
    }


    public String getLaunchClassName() {
        return launchClassName;
    }

    public void setLaunchClassName(String launchClassName) {
        this.launchClassName = launchClassName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getAnalyticsValue() {
        return analyticsValue;
    }

    public void setAnalyticsValue(String analyticsValue) {
        this.analyticsValue = analyticsValue;
    }
}
