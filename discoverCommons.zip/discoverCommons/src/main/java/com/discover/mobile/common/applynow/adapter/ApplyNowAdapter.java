package com.discover.mobile.common.applynow.adapter;

/**
 * Created by 467649 on 9/13/2017.
 */


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.View;

import com.discover.mobile.common.applynow.ui.ApplyNowContentFragment;

import java.util.ArrayList;
import java.util.List;

public class ApplyNowAdapter extends FragmentPagerAdapter {
    private List<ApplyNowContentFragment> applyNowContentFragments;
    private View.OnClickListener mCloseBtnListener;

    public ApplyNowAdapter(FragmentManager fm) {
        super(fm);
        applyNowContentFragments = getApplyNowPages();
    }

    @Override
    public int getCount() {
        return applyNowContentFragments.size();
    }

    @Override
    public Fragment getItem(int position) {
        return applyNowContentFragments.get(position);
    }

    private List<ApplyNowContentFragment> getApplyNowPages() {
        List<ApplyNowContentFragment> pages = new ArrayList<ApplyNowContentFragment>();

        ApplyNowContentFragment page1 = ApplyNowContentFragment.newInstance(0);
        page1.setCloseButtonClickListener(mCloseBtnClickListener);
        pages.add(page1);

        ApplyNowContentFragment page2 = ApplyNowContentFragment.newInstance(1);
        page2.setCloseButtonClickListener(mCloseBtnClickListener);
        pages.add(page2);

        ApplyNowContentFragment page3 = ApplyNowContentFragment.newInstance(2);
        page3.setCloseButtonClickListener(mCloseBtnClickListener);
        pages.add(page3);

        return pages;
    }

    public void setCloseButtonListener(View.OnClickListener closeBtnListener) {
        this.mCloseBtnListener = closeBtnListener;
    }

    private final View.OnClickListener mCloseBtnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (mCloseBtnListener != null) {
                mCloseBtnListener.onClick(v);
            }
        }
    };
}