package com.discover.mobile.common.appupdate.service;

import com.discover.mobile.common.appupdate.beans.AppVersionNumber;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Headers;

/**
 * Created by 471532 on 2/4/2016.
 */
public interface AppVersionRequestInterface {

    @Headers("Content-Type: application/json")
    @GET("/json/UpdatedVersion.json")
    void getAppVersionRequestCall(Callback<AppVersionNumber> getAppVersionRequest);
}