package com.discover.mobile.common.appupdate.service;

import com.discover.mobile.common.appupdate.beans.AppVersionNumber;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.network.AdapterProvider;
import com.discover.mobile.network.CommonAdapterProvider;
import com.discover.mobile.network.CommonRequestInterceptor;
import com.discover.mobile.network.ServiceGenerator;
import com.discover.mobile.network.error.GenericErrorResponseParser;
import com.discover.mobile.network.error.bean.ErrorBean;

import android.content.Context;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by 471532 on 2/4/2016.
 */
public class AppVersionService {

    private Context mContext;

    public AppVersionService(Context context) {
        this.mContext = context;
    }

    public void getAppVersionRequest(final NetworkRequestListener listener) {
        PortalUtils.showSpinner(mContext);

        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext,
                null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        AppVersionRequestInterface appVersionData = ServiceGenerator
                .createService(AppVersionRequestInterface.class,
                        adapterProvider);
        appVersionData.getAppVersionRequestCall(new Callback<AppVersionNumber>() {
            @Override
            public void success(AppVersionNumber appVersionNumber, Response response) {
                listener.onSuccess(appVersionNumber);
                PortalUtils.hideSpinner(mContext);
            }

            @Override
            public void failure(RetrofitError retrofitError) {


                GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(
                        mContext, retrofitError, null);
                ErrorBean errorbean = genericErrorResponseParser
                        .handleCardErrorforResponse();
                listener.onError(errorbean);
                PortalUtils.hideSpinner(mContext);

            }
        });
    }
}
