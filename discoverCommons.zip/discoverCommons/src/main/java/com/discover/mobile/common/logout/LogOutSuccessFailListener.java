package com.discover.mobile.common.logout;

import com.discover.mobile.common.IntentExtraKey;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.callback.GenericCallbackListener.ErrorResponseHandler;
import com.discover.mobile.common.shared.callback.GenericCallbackListener.SuccessListener;
import com.discover.mobile.common.shared.net.NetworkServiceCall;
import com.discover.mobile.common.shared.net.error.ErrorResponse;

import android.app.Activity;
import android.os.Bundle;

/**
 * Success listener for the log out call.
 *
 * @author jthornton
 */
public class LogOutSuccessFailListener implements SuccessListener<Object>, ErrorResponseHandler {

    /** Activity running */
    private final Activity activity;

    /**
     * Constructor for the class
     *
     * @param activity - the current activity running
     */
    public LogOutSuccessFailListener(final Activity activity) {
        this.activity = activity;
    }

    /**
     * Get the priority of the call
     *
     * @ return the priority of the call
     */
    @Override
    public CallbackPriority getCallbackPriority() {
        return CallbackPriority.MIDDLE;
    }

    /**
     * Handle the success of the call.  In this case send the user to the login screen with a
     * special intent to the logout message is shown.
     *
     * @param successObject - object retrieved from the success call
     */
    @Override
    public void success(final NetworkServiceCall<?> sender, final Object successObject) {
        final Bundle bundle = new Bundle();
        if (!Globals.isSessionTimedout) {
            bundle.putBoolean(IntentExtraKey.SHOW_SUCESSFUL_LOGOUT_MESSAGE, true);
            bundle.putBoolean(IntentExtraKey.SESSION_EXPIRED, false);
        } else {
            bundle.putBoolean(IntentExtraKey.SHOW_SUCESSFUL_LOGOUT_MESSAGE, false);
            bundle.putBoolean(IntentExtraKey.SESSION_EXPIRED, true);
        }

        //This condition check has been added to avoid calling the login activity twice when the logout is called from Card Side.
        if(!Globals.fromCardSide) {
            FacadeFactory.getLoginFacade().navToLoginWithMessage(activity, bundle);
        }
        Globals.isSessionTimedout = false;
    }

    @Override
    public boolean handleFailure(final NetworkServiceCall<?> sender, final ErrorResponse<?> arg0) {
        final Bundle bundle = new Bundle();
        if (!Globals.isSessionTimedout) {
            bundle.putBoolean(IntentExtraKey.SHOW_SUCESSFUL_LOGOUT_MESSAGE, true);
            bundle.putBoolean(IntentExtraKey.SESSION_EXPIRED, false);
        } else {
            bundle.putBoolean(IntentExtraKey.SHOW_SUCESSFUL_LOGOUT_MESSAGE, false);
            bundle.putBoolean(IntentExtraKey.SESSION_EXPIRED, true);
        }
        //This condition check has been added to avoid calling the login activity twice when the logout is called from Card Side.
        if(!Globals.fromCardSide) {
            FacadeFactory.getLoginFacade().navToLoginWithMessage(activity, bundle);
        }
        Globals.isSessionTimedout = false;
        return false;
    }
}
