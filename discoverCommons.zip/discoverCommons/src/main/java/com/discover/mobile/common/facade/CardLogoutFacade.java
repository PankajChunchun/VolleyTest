/**
 * Copyright Solstice-Mobile 2013
 */
package com.discover.mobile.common.facade;

import com.discover.mobile.common.error.ErrorHandlerUi;

import android.app.Activity;

/**
 * A facade to support common shared logout code
 *
 * @author ekaram
 */
public interface CardLogoutFacade {// US26238 Start

    /**
     * A common interface for logout since we are sharing the components
     *
     * @param fromActivity - the calling activity
     * @param errorUi      - the errorUI to use for callback
     * @param accountType  - card or bank
     * @deprecated Use instead {@link CardLogoutFacade#logout(Activity, Boolean,
     * NetworkRequestListener)}
     */
    @Deprecated
    public void logout(Activity fromActivity, ErrorHandlerUi errorUi);

    /**
     * Shared API between card and bank to logout from card from card or bank.
     *
     * @param isLogoutTriggeredFromBank - Bank should pass this as null.
     */
    public void logout(final Activity cur_Activity, final Boolean isTimeOut, final Boolean isLogoutTriggeredFromBank);
    // US26238 End

    /**
     * call to do logout when user selects Go To Register on join account modal
     * fix for defect# 240408
     */
    public void logout(final Activity cur_Activity, final Boolean isLogoutFromJointAcctModal);
}
