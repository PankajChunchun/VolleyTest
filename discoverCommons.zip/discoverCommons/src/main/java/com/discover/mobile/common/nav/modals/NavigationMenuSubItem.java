package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class NavigationMenuSubItem {

    @SerializedName("SubItemLabel")
    private String SubItemTitle;

    @SerializedName("LaunchClass")
    private String launchClassName;
    @SerializedName("Type")
    private String type;
    @SerializedName("LaunchKey")
    private String LaunchKey;

    @SerializedName("PageTitle")
    private String PageTitle;
    @SerializedName("MethodName")

    private String methodName;
    @SerializedName("KillSwitchConstants")
    private String killSwitchConstants;
    @SerializedName("ExcludedCardType")
    private String ExcludedCardType;

    @SerializedName("Analytics")
    private String analyticsValue;

    public String getPageTitle() {
        return PageTitle;
    }

    public void setPageTitle(String pageTitle) {
        PageTitle = pageTitle;
    }

    public String getComponentkey() {
        return LaunchKey;
    }

    public void setComponentkey(String componentkey) {
        LaunchKey = componentkey;
    }

    public String getSubItemTitle() {
        return SubItemTitle;
    }

    public void setSubItemTitle(String subItemTitle) {
        SubItemTitle = subItemTitle;
    }

    public String getExcludedCardType() {
        return ExcludedCardType;
    }

    public void setExcludedCardType(String excludedCardType) {
        ExcludedCardType = excludedCardType;
    }

    public String getKillSwitchConstants() {
        return killSwitchConstants;
    }

    public void setKillSwitchConstants(String killSwitchConstants) {
        this.killSwitchConstants = killSwitchConstants;
    }

    public String getChildTitle() {
        return SubItemTitle;
    }

    public void setChildTitle(String childTitle) {
        this.SubItemTitle = childTitle;
    }

    public String getLaunchClassName() {
        return launchClassName;
    }

    public void setLaunchClassName(String launchClassName) {
        this.launchClassName = launchClassName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getAnalyticsValue() {
        return analyticsValue;
    }

    public void setAnalyticsValue(String analyticsValue) {
        this.analyticsValue = analyticsValue;
    }
}
