package com.discover.mobile.common.onboardwiz.fragment.passcode;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.discover.mobile.common.R;
import com.discover.mobile.common.onboardwiz.fragment.IPopFragment;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;

/**
 * Created by 482127 on 4/25/2016.
 */
public class OnBoardPasscodeContainerFragment extends Fragment implements IPopFragment {
    public static OnBoardConstant.PASSCODE_PAGE_STATE passcode_state = OnBoardConstant.PASSCODE_PAGE_STATE.ENABLE_PAGE;
    public boolean isPasscodeEnabled = false;
    //this ensure animation is perfomed or not
    public boolean mAnim = true;
    private View mView;
    private Context mContext;

    /*
    Updates the current state for Passcode
     */
    public static void updateState(OnBoardConstant.PASSCODE_PAGE_STATE passcode_stat) {
        passcode_state = passcode_stat;
    }

    public void setIsPasscodeEnabled(boolean isPasscodeEnabled) {
        this.isPasscodeEnabled = isPasscodeEnabled;
    }

    public boolean isPasscodeEnabled() {
        return isPasscodeEnabled;
    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        mContext = activity;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        pushFragment(new OnBoardEnablePasscodeFragment(), true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = LayoutInflater.from(mContext).inflate(R.layout.onboarding_passcode_container, null);

        return mView;
    }

    /*
        This methods pushes the fragment onto passcode container stack
    */
    public void pushFragment(Fragment fragment, boolean addToHistory) {
        FragmentTransaction fragmentTransaction = getChildFragmentManager()
                .beginTransaction().replace(R.id.container_view, fragment,
                        fragment.getClass().getSimpleName());
        if (addToHistory)
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        fragmentTransaction.commitAllowingStateLoss();
    }

    /*
    This methods handles the onback press behaviour for passcode
     */
    @Override
    public boolean popBackStack() {
        int childCount = getChildFragmentManager().getBackStackEntryCount();
        if (childCount == 0) {
            // it has no child Fragment
            // can not handle the onBackPressed task by itself
            return true;
        }
        // get the child Fragment
        return controlPageNavigation();
    }

    /*
    This methods gets called whenever user performs a swipe operation
     */
    @Override
    public void updateCurrentPage() {

        //Crash fix.
        try {
            if (passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.CONFIRMATION_PAGE
                    ) {

                OnBoardPasscodeSuccessFragment onBoardPasscodeSuccessFragment = new OnBoardPasscodeSuccessFragment();
                onBoardPasscodeSuccessFragment.updateSuccessView();
                pushFragment(onBoardPasscodeSuccessFragment, false);
            } else if (passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.PASSCODE_DONE_PAGE
                    ) {


                return;
            } else {
                // removing the child Fragment from stack
                getChildFragmentManager().popBackStackImmediate(OnBoardEnablePasscodeFragment.class.getSimpleName(), 0);
            }
        } catch (Exception e) {
            Log.e("updateCurrentPage", "Exception");
        }
    }

    /*
       This methods handles the onback press behaviour for passcode
        */
    private boolean controlPageNavigation() {
        if (passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE
                || passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.EXISTING_PAGE) {
            // removing the child Fragment from stack
            getChildFragmentManager().popBackStackImmediate();

        } else if (passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.VERIFY_PAGE) {
            getChildFragmentManager().popBackStackImmediate(OnBoardEnablePasscodeFragment.class.getSimpleName(), 0);
        } else if (passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.ENABLE_PAGE) {
            return true;
        } else if (passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.CONFIRMATION_PAGE) {
            return true;
        } else if (passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.PASSCODE_DONE_PAGE) {
            return true;
        }
        return true;

    }


}
