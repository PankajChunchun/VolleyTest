package com.discover.mobile.common.fico.utils;

public class FicoCreditScoreConstants {
    public final static String FICOCREDITSCOREMASTERFRAG = "ficoCreditScoreMasterFragment";

    public final static String FICO_SCORE_BUNDLE = "ficoscorebundle";

    public final static String FICO_CREDIT_SCORE = "ficoCreditScore";

    public final static String FICO_SELECTED_LIST_ITEM = "ficoSelectedListItem";

    public final static String IS_FICO_SCORE_AVAILABLE = "isFicoScoreAvailable";

    public final static String IS_NO_SCORE_AVAILABLE_FOR_90_DAYS = "isNoScoreAvailableFor90Days";
    public final static String FICO_GRAPH_SELECTED = "ficograph";
    public final static String US_NUMBER = "1-800-DISCOVER";
    public final static String US_NUMBER_URI = "tel:1-800-347-2683";
    public static class ErrorCodes {

        /**
         * Error codes for No Fico Score Available
         */
        public final static String[] NO_FICO_SCORE =
                {"4033001", "4033002", "4033003", "4033004", "4033005", "4033006", "4033007", "4033008"};
    }

    public class FicoScoreList {
        public static final int VIEW_TYPE_LIST_HEADER = 0x101;
        public static final int VIEW_TYPE_LIST_ITEM = 0x102;
    }

    public class FicoInfoMsg {
        /** start Strength Description modal */
        public static final String STDES_MODAL_TITLE_EXCEPTIONAL_RATING = "cmn_fico_stdes_modal_title_exceptional_rating";
        public static final String STDES_MODAL_TITLE_VERY_GOOD_RATING = "cmn_fico_stdes_modal_title_very_good_rating";
        public static final String STDES_MODAL_TITLE_GOOD_RATING = "cmn_fico_stdes_modal_title_good_rating";
        public static final String STDES_MODAL_TITLE_FAIR_RATING = "cmn_fico_stdes_modal_title_fair_rating";
        public static final String STDES_MODAL_TITLE_POOR_RATING = "cmn_fico_stdes_modal_title_poor_rating";

        public static final String STDES_MODAL_DESC_EXCEPTIONAL_RATING = "cmn_fico_stdes_modal_desc_exceptional_rating";
        public static final String STDES_MODAL_DESC_VERY_GOOD_RATING = "cmn_fico_stdes_modal_desc_very_good_rating";
        public static final String STDES_MODAL_DESC_GOOD_RATING = "cmn_fico_stdes_modal_desc_good_rating";
        public static final String STDES_MODAL_DESC_FAIR_RATING = "cmn_fico_stdes_modal_desc_fair_rating";
        public static final String STDES_MODAL_DESC_POOR_RATING = "cmn_fico_stdes_modal_desc_poor_rating";
        /**end Strength Description modal */

        /*Fico Score Terms & Condition */
        public static final String CMN_CREDIT_SCORECARD_TERMS_CONDITION_DESP_MSG = "cmn_credit_scorecard_terms_condition_desp_msg";
        public static final String CMN_FICO_lIMITED_AUTHOR_USER_ERROR = "cmn_fico_limited_author_user_error";
        public static final String CMN_FICO_NO_REVOLVING_TRADE_ERROR = "cmn_fico_no_revolving_trade_error";
        public static final String CMN_FICO_TOTAL_ERROR = "cmn_fico_total_error";


    }

    public class FicoKeyfactors {
        public static final int POSITIVE_KEY_INDEX = 0;
        public static final int NAGATIVE_KEY_INDEX = 1;
    }
}
