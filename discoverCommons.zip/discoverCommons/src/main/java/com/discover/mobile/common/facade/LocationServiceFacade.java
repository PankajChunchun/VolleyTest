package com.discover.mobile.common.facade;

import android.content.Context;

public interface LocationServiceFacade {

    public boolean getLocationServicesPreference(Context ctx);

}
