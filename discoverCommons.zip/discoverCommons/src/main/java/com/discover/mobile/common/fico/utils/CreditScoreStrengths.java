package com.discover.mobile.common.fico.utils;

/**
 * Created by slende on 6/6/2017.
 * Enum to identify credit score strength based on credit score
 */

public enum CreditScoreStrengths {
    EXCEPTIONAL_RATING,
    VERY_GOOD_RATING,
    GOOD_RATING,
    FAIR_RATING,
    POOR_RATING
}
