package com.discover.mobile.common.login.beans;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by 407898 on 2/2/2016.
 */
public class InfoJsonUniversalData

{

    @SerializedName("uniAppPackage")
    @Expose
    private String uniAppPackage;
    @SerializedName("softUpgradeVersionList")
    @Expose
    private ArrayList<String> softUpgradeVersionList;
    @SerializedName("softUpgradeNotifyPeriod")
    @Expose
    private String softUpgradeNotifyPeriod;
    @SerializedName("softUpgradeMessage")
    @Expose
    private String softUpgradeMessage;
    @SerializedName("softUpgradeMessage_T")
    @Expose
    private String softUpgradeMessage_T;
    @SerializedName("hardUpgradeVersionList")
    @Expose
    private ArrayList<String> hardUpgradeVersionList;
    @SerializedName("hardUpgradeMessage")
    @Expose
    private String hardUpgradeMessage;
    @SerializedName("hardUpgradeMessage_T")
    @Expose
    private String hardUpgradeMessage_T;
    @SerializedName("uninstallMessage")
    @Expose
    private String uninstallMessage;
    @SerializedName("uninstallMessage_T")
    @Expose
    private String uninstallMessage_T;
    @SerializedName("cancelBtnLable")
    @Expose
    private String cancelBtnLable;
    @SerializedName("upgradeBtnLable")
    @Expose
    private String upgradeBtnLable;
    @SerializedName("uninstallBtnLable")
    @Expose
    private String uninstallBtnLable;

    public ArrayList<String> getSoftUpgradeVersion() {
        return softUpgradeVersionList;
    }

    public void setSoftUpgradeVersion(ArrayList<String> softUpgradeVersion) {
        this.softUpgradeVersionList = softUpgradeVersion;
    }

    public String getSoftUpgradeNotifyPeriod() {
        return softUpgradeNotifyPeriod;
    }

    public void setSoftUpgradeNotifyPeriod(String softUpgradeNotifyPeriod) {
        this.softUpgradeNotifyPeriod = softUpgradeNotifyPeriod;
    }

    public String getSoftUpgradeMessage() {
        return softUpgradeMessage;
    }

    public void setSoftUpgradeMessage(String softUpgradeMessage) {
        this.softUpgradeMessage = softUpgradeMessage;
    }

    public String getSoftUpgradeMessage_T() {
        return softUpgradeMessage_T;
    }

    public void setSoftUpgradeMessage_T(String softUpgradeMessage_T) {
        this.softUpgradeMessage_T = softUpgradeMessage_T;
    }

    public ArrayList<String> getHardUpgradeVersion() {
        return hardUpgradeVersionList;
    }

    public void setHardUpgradeVersion(ArrayList<String> hardUpgradeVersionList) {
        this.hardUpgradeVersionList = hardUpgradeVersionList;
    }

    public String getHardUpgradeMessage() {
        return hardUpgradeMessage;
    }

    public void setHardUpgradeMessage(String hardUpgradeMessage) {
        this.hardUpgradeMessage = hardUpgradeMessage;
    }

    public String getHardUpgradeMessage_T() {
        return hardUpgradeMessage_T;
    }

    public void setHardUpgradeMessage_T(String hardUpgradeMessage_T) {
        this.hardUpgradeMessage_T = hardUpgradeMessage_T;
    }

    public String getUninstallMessage() {
        return uninstallMessage;
    }

    public void setUninstallMessage(String uninstallMessage) {
        this.uninstallMessage = uninstallMessage;
    }

    public String getUninstallMessage_T() {
        return uninstallMessage_T;
    }

    public void setUninstallMessage_T(String uninstallMessage_T) {
        this.uninstallMessage_T = uninstallMessage_T;
    }

    public String getCancelBtnLable() {
        return cancelBtnLable;
    }

    public void setCancelBtnLable(String cancelBtnLable) {
        this.cancelBtnLable = cancelBtnLable;
    }

    public String getUpgradeBtnLable() {
        return upgradeBtnLable;
    }

    public void setUpgradeBtnLable(String upgradeBtnLable) {
        this.upgradeBtnLable = upgradeBtnLable;
    }

    public String getUninstallBtnLable() {
        return uninstallBtnLable;
    }

    public void setUninstallBtnLable(String uninstallBtnLable) {
        this.uninstallBtnLable = uninstallBtnLable;
    }


    public String getUniAppPackage() {
        return uniAppPackage;
    }

    public void setUniAppPackage(String uniAppPackage) {
        this.uniAppPackage = uniAppPackage;
    }


}


