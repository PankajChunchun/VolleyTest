package com.discover.mobile.common.nav;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.text.Html;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ExpandableListView;
import android.widget.RelativeLayout;

import com.discover.mobile.common.BaseFragment;
import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.nav.adapters.AnimatedExpandableListView;
import com.discover.mobile.common.nav.adapters.DrawerExpandableAdapter;
import com.discover.mobile.common.nav.configuration.DrawerMenuConfiguration;
import com.discover.mobile.common.nav.listener.LHNHighlightingListener;
import com.discover.mobile.common.nav.modals.NavigationMenuItem;
import com.discover.mobile.common.nav.modals.NavigationMenuSubItem;
import com.discover.mobile.common.nav.utils.Launcher;
import com.discover.mobile.common.nav.utils.MenuItemClickHandler;
import com.discover.mobile.common.nav.utils.MenuPopulationHandler;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.widget.FragmentTransactions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;

/**
 * Base activity which implements the drawer(LHN Menu) population logic.
 * All the modules which need to have
 * the LHN functionality  should have the respective Container activities derived from this class.
 */
public abstract class DrawerBaseActivity extends ActionBarBaseActivity implements LHNHighlightingListener {
    private DrawerMenuConfiguration mDrawerMenuConfiguration;
    private ArrayList<NavigationMenuItem> mMenuItemList;
    private AnimatedExpandableListView mDrawerListView;
    private RelativeLayout mLogoutlayout;
    private DrawerExpandableAdapter mDrawerExpandableAdapter;

    /*
    * US133355: Android: LHN Analytics
    * For storing the last selected position
    */
    private int lastSelectedPosition=-1;

    private enum DRAWER_STATE {OPEN, CLOSED};

    public DRAWER_STATE LHN_STATE = DRAWER_STATE.CLOSED;
    /**
     * Reference variable for holding ActionBarDrawerToggleCustom
     */
    public ActionBarDrawerToggleCustom mActionBarDrawerToggle;

    public void lockAndHideLHN() {
        if (mActionBarDrawerToggle != null && mDrawer != null) {
            mActionBarDrawerToggle.setDrawerIndicatorEnabled(false);
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        }
    }

    public void unlockAndShowLHN() {
        if (mActionBarDrawerToggle != null && mDrawer != null) {
            mActionBarDrawerToggle.setDrawerIndicatorEnabled(true);
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        }
    }

    public int selectedGroupPosition = -1;
    private int lastSelectedGroupPosition = -1;

    public static final int ANIMATION_DURATION = 300;
    private Runnable[] runnables = new Runnable[ANIMATION_DURATION + 1];

    /* Changes to handle Fragment Transactions from Service response after onSaveIntance()
        This was causing Crash of IllegalStateException
        by hkakadi
        Other places will be having comments as "Fix for IllegalStateException - Fabric"
     */
    // Fix for IllegalStateException - Fabric START
    public PriorityQueue operationQue = new PriorityQueue(1, new FragmentTransactions());
    public boolean isActivityPaused = false;
    // Fix for IllegalStateException - Fabric END
    @Override
    protected void onCreate(Bundle savedInstanceState)

    {
        super.onCreate(savedInstanceState);
        setHighlightingListener(this);

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        LHN_STATE = DRAWER_STATE.CLOSED;


    }

    // Fix for IllegalStateException - Fabric START
    public void addOperation(FragmentTransactions ft)
    {
        operationQue.add(ft);
    }

    public void clearOperations()
    {
        FragmentTransactions.iCount = 0;
        operationQue.clear();
    }
    // Fix for IllegalStateException - Fabric END
    /**
     * initialize the UI components and Handler classes
     * that are used furthur down
     */
    private void initializeDrawerComponents() {

        enableDrawer();
        mDrawerListView = (AnimatedExpandableListView) findViewById(R.id.drawerListView);
        mLogoutlayout = (RelativeLayout) findViewById(R.id.logoutLayout);

        mActionBarDrawerToggle = new ActionBarDrawerToggleCustom(this, getDrawerLayout(),
                getToolBar(), R.string.drawer_opened,
                R.string.drawer_closed) {


            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                LHN_STATE = DRAWER_STATE.CLOSED;
                if (selectedGroupPosition != -1) {
                    NavigationMenuItem navMenuItem = mMenuItemList
                            .get(selectedGroupPosition);
                    navMenuItem.setSelectedGroupItem(navMenuItem
                            .getGroupTitle());
                    if (lastSelectedGroupPosition != -1) {
                        mDrawerListView
                                .collapseGroup(lastSelectedGroupPosition);
                    }
                    mDrawerListView.expandGroup(selectedGroupPosition);
                }
                // invalidateOptionsMenu();

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                LHN_STATE = DRAWER_STATE.OPEN;
                // invalidateOptionsMenu();

                //app level message tracking
                if (mDrawerMenuConfiguration.getAppLevelTrackerListener() != null) {
                    mDrawerMenuConfiguration.getAppLevelTrackerListener().trackAppLevelMessageForMainItem();
                }

                InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                if(!Globals.isBankLoginSelected())
                TrackingHelper.trackPageView(AnalyticsPage.LHN_OPEN_PAGE_TRACK);
                super.onDrawerSlide(drawerView, 0);
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, 0);
            }
        };

        for (int i = 0; i < runnables.length; i++) {
            final float position = i / (float) ANIMATION_DURATION;
            runnables[i] = new Runnable() {
                @Override
                public void run() {
                    mActionBarDrawerToggle.getSlider().setPosition(position);
                }
            };
        }

        mDrawer.post(new Runnable() {
            @Override
            public void run() {
                mActionBarDrawerToggle.syncState();
            }
        });
    }

    /**
     * Set the basic properties of Drawer layout so that it is ready when the container activity is
     * loaded.
     */
    private void setDrawerProperties() {

        setSupportActionBar(getToolBar());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setHomeButtonEnabled(true);
        mDrawer.setDrawerListener(mActionBarDrawerToggle);
        mActionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        mActionBarDrawerToggle.syncState();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mActionBarDrawerToggle.syncState();
    }

    /**
     * Setting the listeners i.e. Group Expand, Group Collapse etc.
     */
    private void setListeners() {
        mDrawerListView.setOnGroupExpandListener(new DrawerItemExpandClickListener());
        mDrawerListView.setOnGroupCollapseListener(new DrawerItemCollapseClickListener());
        mDrawerListView.setOnChildClickListener(new DrawerSubitemClickListener());
    }

    /**
     * populate the drawer by attaching the adapter
     * to the expandable list view
     */
    private void populateDrawerMenu() {
        mDrawerExpandableAdapter = new DrawerExpandableAdapter(this);
        mDrawerExpandableAdapter.setData(mMenuItemList);
        //Set wink list to display Level one message in LHN
        mDrawerExpandableAdapter.setWinkDetailList(mDrawerMenuConfiguration.getWinkList());
        mDrawerListView.addHeaderView(getLayoutInflater().inflate(R.layout.drawer_header_layout, null), null, false);
        mDrawerListView.addFooterView(getLayoutInflater().inflate(R.layout.divider, null));
        mDrawerListView.setAdapter(mDrawerExpandableAdapter);

        mDrawerListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                if (mDrawerListView.isGroupExpanded(groupPosition)) {
                    if (mMenuItemList.get(groupPosition).getNavigationMenuSubItems().size() == 0)
                        mDrawerListView.expandGroupWithAnimation(groupPosition);
                    else
                        mDrawerListView.collapseGroupWithAnimation(groupPosition);
                } else {
                    mDrawerListView.expandGroupWithAnimation(groupPosition);
                }
                return true;
            }
        });


      /*Opening first item here on launch - start*/
        invokeModuleonLaunch();
        /*Opening first item here on launch - start*/
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            mDrawerListView.setSelector(R.drawable.lhn_selector);
        }
    }

    /**
     * Function that will be overridden by each child
     * activity to give the JSON file name to its parent
     * which will in turn populate the drawer.
     *
     * @return JSON file name
     */
    protected abstract DrawerMenuConfiguration getDrawerMenuConfigurationData();

    /**
     * Function which will provide the final consolidates and filtered list of menu items
     * which the drawer can use to inflate in the view.
     */
    private void getMenuItems() {
        MenuPopulationHandler menuHandler = new MenuPopulationHandler();
        mMenuItemList = mDrawerMenuConfiguration.getMenuItemList();
        //pchand2 - Null check added - to avoid the crash in Bank LHN population
        /*Filtering the items depending on the card type*/
        if (mDrawerMenuConfiguration.getCardType() != null) {
            mMenuItemList = menuHandler.applyCardTypeFilter(mMenuItemList, mDrawerMenuConfiguration.getCardType());
        }
        /*Filtering the list with kill-switched items */
        if (null != mDrawerMenuConfiguration.getFilteredList()) {
            mMenuItemList = menuHandler.applyKillSwitchFilter(mMenuItemList, mDrawerMenuConfiguration.getFilteredList());
        }

    }

    public boolean backPressed() {
        if (LHN_STATE == DRAWER_STATE.OPEN) {
            getDrawerLayout().closeDrawer(Gravity.LEFT);
            return true;
        }
        return false;
    }

    /**
     * Invokes the related fragment of the module.
     */
    private void selectItem(int groupPosition, int childPosition)
            throws ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        NavigationMenuItem groupItem = mMenuItemList.get(groupPosition);
        List<NavigationMenuSubItem> childItems = groupItem
                .getNavigationMenuSubItems();
        String title = null;
        onLHNItemClick();
        LHN_STATE = DRAWER_STATE.CLOSED;
        MenuItemClickHandler mCLickHandler = new MenuItemClickHandler(this);

        if (childItems != null && childItems.size() > 0) {
            //we handle the child loading here as the item clicked has subitems in the list
            Launcher launcher = mDrawerMenuConfiguration.getLhnHelper().getLHNItemLauncher(childItems.get(childPosition).getComponentkey());
            //Added null check to avoid bank side null pointer exception on launcher object.
            if (launcher != null) {
                mCLickHandler.handleClickEvents(getToolBar(), launcher);
            }
            /*
            As part of US76102, getting tags from JSON itself.
             */
            if (null != childItems.get(childPosition).getAnalyticsValue()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(AnalyticsPage.KEY_MY_PROPR1, childItems.get(childPosition).getAnalyticsValue());
                TrackingHelper.trackClickEvents(childItems.get(childPosition).getAnalyticsValue(), null, AnalyticsPage.KEY_PE_VAL, extras);
            }

        } else {
            //since we dont have child menus we consider this click for the parent menu
            Launcher launcher = mDrawerMenuConfiguration.getLhnHelper().getLHNItemLauncher(groupItem.getComponentkey());
            //Added null check to avoid bank side null pointer exception on launcher object.
            if (launcher != null) {
                mCLickHandler.handleClickEvents(getToolBar(), launcher);
            }
            /*
            As part of US76102, getting tags from JSON itself.
             */
            if (null != groupItem.getAnalyticsValue()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(AnalyticsPage.KEY_MY_PROPR1, childItems.get(childPosition).getAnalyticsValue());
                TrackingHelper.trackClickEvents(childItems.get(childPosition).getAnalyticsValue(), null, AnalyticsPage.KEY_PE_VAL, extras);
            }
        }

    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {

        super.setContentView(layoutResID);
        initializeDrawerComponents();
        setDrawerProperties();
        mDrawerMenuConfiguration = getDrawerMenuConfigurationData();
        setListeners();
        getMenuItems();
        populateDrawerMenu();

    }

    /**
     * Clear the back button and show the hamburger icon. Also resets the back button click action.
     */
    protected void clearBackNavigation() {
        if (null != mDrawer && DrawerLayout.LOCK_MODE_UNLOCKED != mDrawer.getDrawerLockMode(GravityCompat.START)) {
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            mActionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        }
    }

    /**
     * Changes the hamburger icon to a back arrow. There will be no button animation. Sets the click event for the back arrow.
     * @param backNavigationAction back navigation action,If passed as Null finish will be called on the running activity
     */
    protected void setActionbarBackNavigation(final Runnable backNavigationAction) {
        if (null != mDrawer && DrawerLayout.LOCK_MODE_LOCKED_CLOSED != mDrawer.getDrawerLockMode(GravityCompat.START)) {
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            mActionBarDrawerToggle.setDrawerIndicatorEnabled(false);
            super.setActionbarBackNavigation(backNavigationAction);
        }
    }

    /**
     * Clear the back button and show the hamburger icon with spin animation. Also resets the back button click action.
     */
    protected void clearBackNavigationAnimation() {
        //Crashlyics--321--adding null check for drawer
        if (null != mDrawer && DrawerLayout.LOCK_MODE_UNLOCKED != mDrawer.getDrawerLockMode(GravityCompat.START)) { //DrawerLayout.LOCK_MODE_UNLOCKED != mDrawer.getDrawerLockMode(GravityCompat.START))
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            mActionBarDrawerToggle.setDrawerIndicatorEnabled(true);
            for (int i = 0; i < runnables.length; i++)
                mDrawer.postDelayed(runnables[runnables.length - i - 1], i);
        }
    }

    /**
     * Changes the hamburger icon to a back arrow with back arrow spin animation. Sets the click event for the back arrow.
     * @param backNavigationAction back navigation action,If passed as Null finish will be called on the running activity
     */
    protected void setActionbarBackNavigationAnimation(final Runnable backNavigationAction) {
        //Crashlyics--321--adding null check for drawer
        if (null != mDrawer && DrawerLayout.LOCK_MODE_LOCKED_CLOSED != mDrawer.getDrawerLockMode(GravityCompat.START)) {
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);

            for (int i = 0; i < runnables.length; i++)
                mDrawer.postDelayed(runnables[i], i);
            mDrawer.postDelayed(new Runnable() {
                @Override
                public void run() {
                    getSupportActionBar().setDisplayShowHomeEnabled(true);
                }
            }, ANIMATION_DURATION);

            super.setActionbarBackNavigation(backNavigationAction);
         /*Callback Listener to listen to the events of Back navigation when
        Drawer Indicator is disabled and Back Icon is shown in the action bar*/
            mActionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    handleBackNavigation(backNavigationAction);
                }
            });
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mActionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    /*Empty implementation to invoke any function that needs to be invoked in Child Activities.*/
    public void onLHNItemClick() {
         /*Empty implementation to invoke any function that needs to be invoked in Child Activities.*/

    }

    /**
     * Function to implement reverse highlighting
     *
     * @param actionbarTitle title of the fragmet(String resource)
     */
    public void changeLHNMenuHighlighting(int actionbarTitle) {

       /* BaseFragment currentFrag = (BaseFragment) fragName;*/

        if (!isLHNOption(actionbarTitle))
            return;
        int currentActionBarRes = actionbarTitle;
        //Fix for crashLytics #348
        if (null != mMenuItemList) {
            for (NavigationMenuItem menuItem : mMenuItemList) {
                List<NavigationMenuSubItem> subItemList = menuItem.getNavigationMenuSubItems();
                /*first checking whether the action bar string is invalid or blank then we have to highlight Home*/
                if (isActionBarTitleEmpty(currentActionBarRes)) {
                    highlightHome(menuItem);
                    break;

                } else if (Html.fromHtml(getResources().getString(currentActionBarRes)).toString().equalsIgnoreCase(Html.fromHtml(menuItem.getPageTitle()).toString())) {
                    highLightMenuItems(menuItem);
                    break;
                }

                for (NavigationMenuSubItem subItem : subItemList) {
                    if (Html.fromHtml(getResources().getString(currentActionBarRes)).toString().equalsIgnoreCase(Html.fromHtml(subItem.getPageTitle()).toString())) {
                        highlightSubItems(menuItem, subItem);
                        break;

                    }

                }


            }
        }
    }

    /**
     * Function to highlight the sub-item if any module against it is opened
     */
    private void highlightSubItems(NavigationMenuItem menuItem, NavigationMenuSubItem subItem) {
        mMenuItemList.get(lastSelectedGroupPosition).setSelectedchildItem(null);
        menuItem.setSelectedchildItem(subItem.getChildTitle());
        mDrawerListView.collapseGroup(lastSelectedGroupPosition);
        mDrawerListView.expandGroup(mMenuItemList.indexOf(menuItem));
        selectedGroupPosition = mMenuItemList.indexOf(menuItem);


    }

    /**
     * Function to highlight the main menu item if the module against it is opened
     */
    private void highLightMenuItems(NavigationMenuItem menuItem) {

        mMenuItemList.get(lastSelectedGroupPosition).setSelectedchildItem(null);
        menuItem.setSelectedGroupItem(menuItem.getGroupTitle());
        menuItem.setSelectedchildItem(null);
        mDrawerListView.collapseGroup(lastSelectedGroupPosition);
        selectedGroupPosition = mMenuItemList.indexOf(menuItem);
        mDrawerExpandableAdapter.notifyDataSetChanged();
        mDrawerListView.expandGroup(mMenuItemList.indexOf(menuItem));
    }

    /*8
     Function to highlight home when a module with no title is opened.
     */
    private void highlightHome(NavigationMenuItem menuItem) {
        mMenuItemList.get(lastSelectedGroupPosition).setSelectedchildItem(null);
        menuItem.setSelectedGroupItem(mMenuItemList.get(0).getGroupTitle());
        menuItem.setSelectedchildItem(null);
        mDrawerListView.collapseGroup(lastSelectedGroupPosition);
        mDrawerListView.expandGroup(0);
        mDrawerExpandableAdapter.notifyDataSetChanged();
    }

    /**
     * Function retrieve whther the module has a title or not.
     */
    private boolean isActionBarTitleEmpty(int actionBarTitleString) {
        return isLHNOption(actionBarTitleString) && (actionBarTitleString == 0 || getResources().getString(actionBarTitleString).equalsIgnoreCase(""));

    }

    @Override
    public void onHighlightingChanged(Fragment fragment) {
        /*resetting the selectedGroupPosition ,if during reverse highlighting the module is opened from LHN then selectedGroupPosition will be set to
        that item's position. Moreover if we are opening any master fragment from another fragment(ie not from the LHN), then this function will be called and value
         will be erset to save the state of the LHN*/
        selectedGroupPosition = -1;
        BaseFragment baseFragment = (BaseFragment) fragment;
        int actionBarTitle = baseFragment.getActionBarTitle();
        changeLHNMenuHighlighting(actionBarTitle);
    }

    /*Function to get the Logout view in com.discover.mobile.card.navigation.CardDrawerActivity*/
    protected RelativeLayout getLogoutView() {
        return this.mLogoutlayout;
    }


    // Inner classes for Listeners - Start

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDrawerMenuConfiguration = null;
        mMenuItemList = null;
        mDrawerListView = null;
        mLogoutlayout = null;
        mDrawerExpandableAdapter = null;
    }

    /**
     * Thhe fragment should return -1 as the title only when we need to load the page without title
     * and this means that the page is
     * not present in the LHN
     *
     * @param actionBarTitle title of the page to load.
     * @return TRUE if the title value is valid, FALSE if the title is not a valid title but the
     * page should be loaded without LHN highlight
     */
    private boolean isLHNOption(int actionBarTitle) {
        return actionBarTitle != -1;
    }

    private void invokeModuleonLaunch() {
        // Code written here to cal expand so that Home is highlightes  - will not open the fragment in OnGroupExpandListener as enum is set to CLOSED
        mDrawerListView.expandGroup(0);
        onLHNItemClick();
        NavigationMenuItem groupItem = mMenuItemList.get(0);
        Launcher launcher = mDrawerMenuConfiguration.getLhnHelper().getLHNItemLauncher(groupItem.getComponentkey());
        MenuItemClickHandler mCLickHandler = new MenuItemClickHandler(this);
        //Added null check to avoid bank side null pointer exception on launcher object.
        if (launcher != null) {
            try {
                mCLickHandler.handleClickEvents(getToolBar(), launcher);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Method to return LHN Adapter
     */
    protected DrawerExpandableAdapter getLHNAdapter() {
        return mDrawerExpandableAdapter;
    }

    /**
     * Inner class to implement the Listener for Sun-Menu item
     */
    private class DrawerSubitemClickListener implements ExpandableListView.OnChildClickListener {

        @Override
        public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
            if (selectedGroupPosition != -1) {
                mMenuItemList.get(selectedGroupPosition).setSelectedchildItem(
                        null);
            }
            selectedGroupPosition = groupPosition;
            NavigationMenuItem navmenuItem = mMenuItemList.get(groupPosition);
            NavigationMenuSubItem navMenuSubItem = navmenuItem.getNavigationMenuSubItems().get(childPosition);
            navmenuItem.setSelectedchildItem(navMenuSubItem.getChildTitle());
            try {
                selectItem(groupPosition, childPosition);

            } catch (Exception e) {

                e.printStackTrace();
            }
            getDrawerLayout().closeDrawers();
            // mDrawerExpandableAdapter.notifyDataSetChanged();
            return false;
        }
    }

    /**
     * Inner class to implement the Listener for the expansion of Menu Item
     */
    private class DrawerItemExpandClickListener implements ExpandableListView.OnGroupExpandListener {

        @Override
        public void onGroupExpand(int groupPosition) {
            if (lastSelectedGroupPosition != -1) {
                mMenuItemList.get(lastSelectedGroupPosition).setSelectedGroupItem(null);
            }

            NavigationMenuItem groupItem = mMenuItemList.get(groupPosition);
            groupItem.setSelectedGroupItem(groupItem.getGroupTitle());
            List<NavigationMenuSubItem> navChildSubItems = groupItem.getNavigationMenuSubItems();

            /*Condition to collapse the previous group and expand the new group*/
            if (lastSelectedGroupPosition != -1 && groupPosition != lastSelectedGroupPosition) {
                mDrawerListView.collapseGroup(lastSelectedGroupPosition);
                //Start: US133355: Android LHN: Align Drawer Analytics with iOS
                if (Globals.isBankLoginSelected()) {
                        if (navChildSubItems.size() > 0 || (navChildSubItems.size() == 0 && lastSelectedPosition != groupPosition))
                            forceTrackNavDrawerItem(groupItem.getGroupTitle());
                             lastSelectedPosition = groupPosition;
                    }
                //End: US133355: Android LHN: Align Drawer Analytics with iOS
            }

            //app level message tracking
            if (mDrawerMenuConfiguration.getAppLevelTrackerListener() != null) {
                mDrawerMenuConfiguration.getAppLevelTrackerListener().trackAppLevelMessageForSubItem(groupItem.getComponentkey());
            }


            if (navChildSubItems.size() == 0) {
                groupItem.setSelectedGroupItem(groupItem.getGroupTitle());
                groupItem.setSelectedchildItem(null);
               /* clear the highlighting of any sub menu item which was selected before*/
                if (selectedGroupPosition != -1) {
                    mMenuItemList.get(selectedGroupPosition).setSelectedchildItem(null);

                }
                /*assigininh the selected poition to the current group position*/
                selectedGroupPosition = groupPosition;
                switch (LHN_STATE) {
                    case CLOSED:
                        /* Nothing will happen as the darwer is closed and no action should  take place*/
                        break;

                    case OPEN:
                        try {
                            selectItem(groupPosition, 0);
                        } catch (Exception e) {

                            e.printStackTrace();
                        }
                        break;
                }
                getDrawerLayout().closeDrawers();

            }
            /*assigning the last selected group position to this group so that when any other group is selected , */
            lastSelectedGroupPosition = groupPosition;
        }
    }

    /*
    * Start: US133355: Android LHN: Drawer Analytics
    * Method to fire analytics tags on LHN main group item click
    */
    private void forceTrackNavDrawerItem(String groupTitle) {
        String navigationItem = DiscoverActivityManager.getActiveActivity()
                .getResources()
                .getString(R.string.nav_drawer_item) + groupTitle;
        HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
        extras.put(
                DiscoverActivityManager.getActiveActivity()
                        .getResources()
                        .getString(R.string.context_Property_1),
                navigationItem);
        TrackingHelper.trackBankClickEvents(navigationItem, null, AnalyticsPage.LINK_TYPE_O, extras);
    }

    private class DrawerItemCollapseClickListener implements ExpandableListView.OnGroupCollapseListener {

        @Override
        public void onGroupCollapse(int groupPosition) {

        }
    }

    /**
     * State of Drawer State
     *
     * @return
     */
    public boolean getLHNState() {
        if (LHN_STATE == DRAWER_STATE.OPEN) {
            return true;
        }
        return false;
    }

}
