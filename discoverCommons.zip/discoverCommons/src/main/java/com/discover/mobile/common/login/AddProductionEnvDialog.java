package com.discover.mobile.common.login;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.R;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.utils.StringUtility;
import com.discover.mobile.common.uiwidget.CmnButton;
import com.discover.mobile.common.widget.BankUrlChangerPreferences;
import com.discover.mobile.common.widget.BankUrlSite;
import com.discover.mobile.common.widget.SelectEnvironmentAdaptor;

import java.util.ArrayList;

/**
 *
 * US146280- Andriod env selection
 * Dialog with fields for production  environment.
 *
 */

public class AddProductionEnvDialog extends DialogFragment implements View.OnClickListener {
    private EditText mBankEditText, mCardEditText;
    private ScrollView mRootEnvLayout;
    private ListView mListView;
    private ArrayList<BankUrlSite> bankUrlSites = null;
    private SelectEnvironmentAdaptor adapter = null;
    private CmnButton mAddButton;
    private BankUrlSite selectedEnv;
    private RelativeLayout customIPAddressLayout;



    /**
     * Inflating the custom view in this method
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.prod_environment_root, container, false);
        bankUrlSites = BankUrlChangerPreferences.initProductionURLs();
        return rootView;
    }

    /**
     * To load all url in the arraylist at initial stage
     * @return
     */


    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        return dialog;
    }


    /**
     * loading all the value when onStart() called
     */
    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        mRootEnvLayout = (ScrollView) getDialog().findViewById(R.id.environ_add_coordinate);
        mListView = (ListView) getDialog().findViewById(R.id.prod_listview);
        customIPAddressLayout=(RelativeLayout)getDialog().findViewById(R.id.custom_ip_address_view) ;
        mBankEditText= (EditText) getDialog().findViewById(R.id.bank_edit_text);
        mCardEditText= (EditText) getDialog().findViewById(R.id.card_edit_text);
        adapter = new SelectEnvironmentAdaptor(DiscoverApplication.getGlobalContext(), R.layout.prod_environment_root, bankUrlSites, true, this);
        mListView.setAdapter(adapter);
        enableAndDisabledViews(false);
        mAddButton= (CmnButton) getDialog().findViewById(R.id.add_env);
        mAddButton.setOnClickListener(this);


    }

    /**
     * The following method used to load the corresponding radio item selection
     * @param selectedItem selected item
     *
     */
    public void setSelectedProdEnviornment(BankUrlSite selectedItem) {
        this.selectedEnv = selectedItem;
    }

    /**
     * Enable and disable the views based on boolean changes
     * @param isEnable
     */
   public void enableAndDisabledViews(boolean isEnable) {
        if(isEnable){
            customIPAddressLayout.setVisibility(View.VISIBLE);
        }else{
            customIPAddressLayout.setVisibility(View.GONE);
        }
    }


    @Override
    public void onDismiss(final DialogInterface dialog) {
        super.onDismiss(dialog);
        final Activity activity = DiscoverActivityManager.getActiveActivity();
        if (activity instanceof DialogInterface.OnDismissListener) {
            ((DialogInterface.OnDismissListener) activity).onDismiss(dialog);
        }
    }


    //Empty validation
    public boolean checker() {
        Boolean check = true;
        if (mBankEditText.getText().toString().isEmpty() || mBankEditText.getText() == null) {
            check = false;
        } else if (mCardEditText.getText().toString().isEmpty() || mCardEditText.getText() == null) {
            check = false;
        }

        return check;
    }

    /**
     * The method is used to lunch LoginActivity page
     */
    public void navigaeToLoginPage() {
        if (selectedEnv != null && selectedEnv.title != null && selectedEnv.bankLink != null
                && selectedEnv.cardLink != null && customIPAddressLayout.getVisibility()==View.GONE) {
               navigaeToLoginPage(selectedEnv.bankLink,selectedEnv.cardLink);
        } else if (selectedEnv.title != null && selectedEnv.title.equalsIgnoreCase(BankUrlChangerPreferences.CUSTOM_IP) && customIPAddressLayout.getVisibility()==View.VISIBLE) {
            if (checker()) {
                navigaeToLoginPage(mBankEditText.getText().toString(), mCardEditText.getText().toString());
            } else {
                Toast.makeText(DiscoverApplication.getGlobalContext(), "please enter all mandatory fields", Toast.LENGTH_SHORT).show();
            }
        }
    }


    /**
     * Navigate to the corresponding login page
     */
    private void navigaeToLoginPage(String bankUrl,String cardUrl) {
        dismiss();
        DiscoverActivityManager.getActiveActivity().finish();
        FacadeFactory.getBankFacade().setBankBaseUrl(bankUrl, StringUtility.EMPTY);
        FacadeFactory.getCardFacade().setCardBaseUrl(cardUrl, StringUtility.EMPTY);
        Intent intent = new Intent(DiscoverActivityManager.getActiveActivity(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("fromWidget", true);
        startActivity(intent);
    }



    /**
     * Onclick listener handling
     */
    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.add_env){
            navigaeToLoginPage();
        }
    }
}
