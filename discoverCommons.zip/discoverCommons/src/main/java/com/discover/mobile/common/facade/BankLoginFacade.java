/**
 * Copyright Solstice-Mobile 2013
 */
package com.discover.mobile.common.facade;

import android.app.Activity;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.shared.callback.GenericCallbackListener.ExceptionFailureHandler;

import java.util.List;
import java.util.Map;

/**
 * A facade to support common shared logout code
 *
 * @author ssmith
 */
public interface BankLoginFacade {

    /**
     * Authorizes a bank login using the Bank Payload returned from Card's
     * Authentication flow.
     */
    public void authorizeWithBankPayload(String payload);

    /**
     * Authorizes a bank login for users that receive a Bad Card Status, A/L/U.
     */
    public void authDueToALUStatus();

    /**
     * Authorizes a bank login with credentials for users that receive a Bad
     * Card Status, A/L/U.
     */
    public void authDueToALUStatus(String username, String password);

    /**
     * Handle password reset flow when bad Card status
     */
    public void handleBadCard();

    public void showOptionalUpgradeAlertDialog(ErrorHandlerUi errorHandlerUi,
                                               String message);

    public void showForcedUpgradeAlertDialog(ErrorHandlerUi errorHandlerUi,
                                             String message);

    /** clearing the data of paperless statements */


    /** set the deeplink values on quickview login */

    public void setDeepLinkDetails(Bundle bundle, TextView deepLink,
                                   RelativeLayout goToBankButton);

    /** To reset deeplink data from BankUser Instance */
    //Changed as part of Log in migration
    //Change started
    public void resetDeepLinkValues();

    //Change ends
    public void setDeeplinkValue(String deepLinkValue);

    /** Initialize the bank login details in BankLoginDetails object class */
    public void initializeBankLoginDetails(String userid, String password);

    /** to show the ALUStatus Modal during login */
    public void showALUStatusModal(String username, String password);

    /** To get the Banklogin URL from env.xml - Bank side */
    public String getBankLoginString();

    public String getDeepLinkValue();

    public double getMaxIdleTime();

    /** setting all the bank urls here */

    public void seturlLinksBankURLManager();

    /** To start Bank API service call from Login Screen */
    public void startBankApiServiceCall();

    /** navigate to Forgot Password */

    public void navigateToForgotPassword();

    /** navigate to Customer Service Menu */

    public void navigateToCustomerServiceMenu(boolean isCard);

    /** This will flag for checking bank Deeplink **/
    public String getBankDeeplink();


    /** navigate to contact us */

    public void navigateToContactUs(boolean isCard);

    /** navigate to feedback screen */

    public void navigateToFeedback();

    /** reset the error handler during login */
    public void resetErrorHandler();

    /** set bank login credentials */
    public void bankLogin(String username, String password,
                          boolean isPasscodeLogin);

    public void navigateToNativeATM();

    public void navigateToHybridATM();

    public void openPrivacyAndTerms();

    public void openPrivacyAndTermsPortalPage();

    public ErrorHandler getBankErrorHandler();

    public void createPasscodeLogin(String bankpasscodeTokenClear,
                                    String passcodeString);

    /** Track the page forceably */
    public void forceTrackPage(final int trackingString);

    /** Track the page forceably */
    public void forceTrackPage(final String className);
    //Start: US113465: Whatsnew Sitecat Defect fix
    public void forceTrackPage(final String className,boolean isSsoUser);

    /** setup page wise tracking */
    public void trackPage(String className);

    public ExceptionFailureHandler returnBankExceptionHandler();

    public String getEnhancedAccountSecurityActivity();

    public void sendKeyEvent();

    /** to get threatmetrix session id */
    public String getTMXSessionId();

    /** to set threatmetrix session id */
    public void setTMXSessionId(String tmxSessionId);

    /** to check the killswitch for threatmetrix */
    public boolean isThreatMetrixKillSwitchDisabled();

    /** to check whether the end point is available for current service call */
    public boolean isOOBServiceCalled(String paramsURL);

    /** To display toast when navigating to login screen from deeplinks */
    public void setDeepLinkToast(Bundle bundle, Activity context);

    /** To hide quickview */
    public void hideQuickView(Activity context);

    /** Initial login time **/
    public void initialLoginTime();

    /**
     * Navigating to homepage from portal Deeplink when the Banksession id is
     * exists
     **/
    public void navigateToBankHomePage();


    /** This is to put cookies of Bank App **/
    public void putCookiesList(Map<String, List<String>> headers);

    /** This is to get base url of Bank App **/
    public String getBankBaseURL();

    public String getTokenfromBank();

    /** This will start bank flow without OOB Call **/
    public void initiateBankflow();

    /**
     * This will call give customer first name from login call
     **/
    public String getFirstName();

}
