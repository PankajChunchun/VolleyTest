package com.discover.mobile.common.facade;

import com.discover.mobile.common.nav.DiscoverBaseActivity;

import android.content.Context;
import android.os.Bundle;

/**
 * A facade for assisting with general bank push notification activities
 *
 * @author CTS
 */
public interface BankPushNotificationFacade {

    //Function is useful to LoginActivity
    public void navigateToLoginActivity(DiscoverBaseActivity callingActivity, Bundle extras);

    //Display the bank push notification icon
    public void processBankNotificationExtras(final Context context, final Bundle extras);

    //Function is useful to Bank navigation based on deep link values
    public void handleBankPayloadNavigations(Context context,
                                             String[] reqIdKeyValue, String[] pageCodeKeyValue, String title);

    //Function is useful to display the push notification
    public void sendBankNotification(String title, String contentText,
                                     String payload, int notificationId, String notificationIdentifier, Context context);
}
