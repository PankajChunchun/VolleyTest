package com.discover.mobile.common.productpage.facade;

import com.discover.mobile.common.facade.CardProductFacade;
import com.discover.mobile.common.productpage.ui.ProductPageActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

public class CardProductFacadeImpl implements CardProductFacade {


   /* @Override
    public void showLeavingAppModal(NavigationRootActivity callingActivity, String targetUrl) {

    }

    @Override
    public void getProductsContent(Context callingActivity, boolean isCardSelected, NetworkRequestListener listener) {

    }*/

     /*1. Removed as per US60514 */
   /* @Override
    public void showLeavingAppModal(AppCompatActivity callingActivity, String targetUrl) {

    }*/

    @Override
    public void showProductsPage(Context callingActivity, boolean isCardSelected) {
        Intent productIntent = new Intent(callingActivity, ProductPageActivity.class);
        productIntent.putExtra("Card_SELECTED", isCardSelected);
        callingActivity.startActivity(productIntent);
    }

    @Override
    public boolean isInstanceOfProductActivity(Activity currentActivity) {
        if (currentActivity instanceof ProductPageActivity) {
            return true;
        }
        return false;
    }

     /*2. Removed as per US60514 */
  /*  @Override
    public void getProductsContent(Context callingActivity, boolean isCardSelected, NetworkRequestListener listener) {

    }*/

     /*3. Removed as per US60514 */
   /* @Override
    public void showLeavingAppModal(DrawerBaseActivity callingActivity, String targetUrl) {

    }*/

}
