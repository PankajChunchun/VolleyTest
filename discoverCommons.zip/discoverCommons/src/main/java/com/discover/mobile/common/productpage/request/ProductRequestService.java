package com.discover.mobile.common.productpage.request;

import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.productpage.beans.ProductsContent;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.network.AdapterProvider;
import com.discover.mobile.network.CommonAdapterProvider;
import com.discover.mobile.network.CommonRequestInterceptor;
import com.discover.mobile.network.ServiceGenerator;
import com.discover.mobile.network.error.GenericErrorResponseParser;
import com.discover.mobile.network.error.bean.ErrorBean;

import android.content.Context;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by 388402 on 2/19/2016.
 */
public class ProductRequestService {
    private Context mContext;

    public ProductRequestService(Context mContext) {
        this.mContext = mContext;
    }


    public void getProductRequestCall(final NetworkRequestListener listener) {
        PortalUtils.showSpinner(mContext);

        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext,
                null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        ProductRequestInterface productRequestInterface = ServiceGenerator
                .createService(ProductRequestInterface.class,
                        adapterProvider);
        productRequestInterface.getProductRequest(new Callback<ProductsContent>() {
            @Override
            public void success(ProductsContent productsContent, Response response) {
                listener.onSuccess(productsContent);
                PortalUtils.hideSpinner(mContext);
            }

            @Override
            public void failure(RetrofitError retrofitError) {
                GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(
                        mContext, retrofitError, null);
                ErrorBean errorbean = genericErrorResponseParser
                        .handleCardErrorforResponse();
                listener.onError(errorbean);
                PortalUtils.hideSpinner(mContext);
            }
        });
    }
}
