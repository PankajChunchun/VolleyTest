package com.discover.mobile.common.nav.configuration;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.appmessaging.helper.AppLevelMessageTracker;
import com.discover.mobile.common.appmessaging.helper.WinkDetail;
import com.discover.mobile.common.nav.listener.ILHNHelper;
import com.discover.mobile.common.nav.modals.MenuDrawerResponseData;
import com.discover.mobile.common.nav.modals.NavigationMenuItem;
import com.discover.mobile.common.shared.utils.image.Utils;

import android.text.TextUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;

/**
 * Configuration class for storing info related to Drawer items
 */
public class DrawerMenuConfiguration

{

    private ArrayList<String> filteredList;
    private String cardType;
    private ILHNHelper lhnHelper;
    private ArrayList<NavigationMenuItem> menuItemList;
    private Map<String, WinkDetail> winkList;


    private AppLevelMessageTracker appLevelTrackerListener;

    public ILHNHelper getLhnHelper() {
        return lhnHelper;
    }

    public void setLhnHelper(ILHNHelper lhnHelper) {
        this.lhnHelper = lhnHelper;
    }

    public ArrayList<NavigationMenuItem> getMenuItemList() {
        return menuItemList;
    }

    /**
     * gets the JSON file and retrieves the POJO
     * out of it
     *
     * @param jsonName - The JSON passed by the child activity
     */
    public void setMenuItemList(String jsonName) {

        MenuDrawerResponseData resposneData = null;
        if (!TextUtils.isEmpty(jsonName)) {
            String JSONString = loadJSONFromAsset(jsonName);

            resposneData = (MenuDrawerResponseData) Utils.getObjectFromJSONString(JSONString, MenuDrawerResponseData.class);
        }
       /* if(Globals.isBankLoginSelected){
            //MenuList of Bank Project - pchand2
            menuItemList = resposneData.getBankDetailData().getBankMenuItems();
        }else{
            //MenuList of Card Project - Pchnad2*/
        menuItemList = resposneData.getMenuDetails().getMenuItems();
        /*}*/


    }

    public void setMenuItemList(ArrayList<NavigationMenuItem> menuItemList) {
        this.menuItemList = menuItemList;
    }

    public AppLevelMessageTracker getAppLevelTrackerListener() {
        return appLevelTrackerListener;
    }

    public void setAppLevelTrackerListener(AppLevelMessageTracker appLevelTrackerListener) {
        this.appLevelTrackerListener = appLevelTrackerListener;
    }
  /*  *//**
 * get the POJO which was retrieved from JSON
 * @return menu POJO class
 *//*
    public ArrayList<NavigationMenuItem> getPojoFromJSON() {
        return menuItemList;
    }*/

    public void setMenuItemList(MenuDrawerResponseData responseData) {
        menuItemList = responseData.getMenuDetails().getMenuItems();
    }

    public ArrayList<String> getFilteredList() {
        return filteredList;
    }

    public void setFilteredList(ArrayList<String> filteredList) {
        this.filteredList = filteredList;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String loadJSONFromAsset(String JSONFile) {
        String json = null;
        try {
            InputStream is = DiscoverApplication.getGlobalContext().getAssets().open(JSONFile);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    /**
     * Method to get wink list
     */
    public Map<String, WinkDetail> getWinkList() {
        return winkList;
    }

    /**
     * Method to set wink list
     */
    public void setWinkList(Map<String, WinkDetail> winkList) {
        this.winkList = winkList;
    }

}



