package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CardAccount implements Serializable, PortalBoxInterface {

    private static final long serialVersionUID = 3555231180002697453L;
    private final static String ACC_CREDIT_CARD = "ACC_CREDIT_CARD | ";

    @SerializedName("anrConversionForward")
    private boolean anrConversionForward;

    @SerializedName("lastFourAcctNbr")
    private String lastFourAcctNbr;

    @SerializedName("availableCredit")
    private String availableCredit;

    @SerializedName("creditLimit")
    private String creditLimit;

    @SerializedName("currentBalance")
    private String currentBalance;

    @SerializedName("lastPaymentAmount")
    private String lastPaymentAmount;

    @SerializedName("lastPaymentDate")
    private String lastPaymentDate;

    @SerializedName("minimumPaymentDue")
    private String minimumPaymentDue;

    @SerializedName("paymentDueDate")
    private String paymentDueDate;

    @SerializedName("primaryCardmember")
    private PrimaryCardmember primaryCardmember;

    @SerializedName("statementBalance")
    private String statementBalance;

    @SerializedName("earnRewardAmount")
    private String earnRewardAmount;

    @SerializedName("rewardType")
    private String rewardType;

    @SerializedName("incentiveCode")
    private String incentiveCode;

    @SerializedName("incentiveTypeCode")
    private String incentiveTypeCode;

    @SerializedName("cardProductGroupCode")
    private String cardProductGroupCode;

    @SerializedName("cardType")
    private String cardType;

    @SerializedName("optionCode")
    private String optionCode;

    @SerializedName("newlyEarnedRewards")
    private String newlyEarnedRewards;

    @SerializedName("cardImage")
    private String cardImage;

    @SerializedName("mailingAddress")
    private MailingAddress mailingAddress;

    @SerializedName("cardTypeIndicator")
    private String cardTypeIndicator;

    @SerializedName("statementsTransaction")
    private StatementsTransaction statementsTransaction;

    @SerializedName("freezeFlag")
    private Boolean freezeFlag;

    @SerializedName("freezeChangeDate")
    private String freezeChangeDate;

    @SerializedName("internalStatus")
    private String internalStatus;

    @SerializedName("externalStatus")
    private String externalStatus;

    @SerializedName("acctKey")
    private String acctKey;

    @SerializedName("cardTypeName")
    private String cardTypeName;

    @SerializedName("phoneNumber")
    private String phoneNumber;

    @SerializedName("isAccountReplaced")
    private String isAccountReplaced;

    @SerializedName("targetMarketing")
    private TargetMarketing targetMarketing;
    /** start newly added field for US48093 changes */

    @SerializedName("externalStatusMessage")
    private ExternalStatusMessage externalStatusMessage;

    @SerializedName("isVerified")
    private Boolean isVerified;

    @SerializedName("outageModeVal")
    private String outageModeVal;

    @SerializedName("acLiteOutageMode")
    private Boolean acLiteOutageMode;

    @SerializedName("cardProductGroupOutageMode")
    private Boolean cardProductGroupOutageMode;

    @SerializedName("paperlessOutageMode")
    private Boolean paperlessOutageMode;

    @SerializedName("rewardOutage")
    private Boolean rewardOutage;

    @SerializedName("smcOutageMode")
    private Boolean smcOutageMode;
    @SerializedName("hideScreens")
    private List<String> hideScreens = new ArrayList<String>();

    /** start Added for US89215 - Messaging App SDK Integration */
    @SerializedName("oAuthClientDetails")
    private OAuthClientDetails oAuthClientDetails;

    @SerializedName("messagingFlags")
    private MessagingFlags messagingFlags;
    /**end Added for US89215 - Messaging App SDK Integration */


    /** end newly added field for US48093 changes */

    public String getCardTypeName() {
        return cardTypeName;
    }

    public void setCardTypeName(String cardTypeName) {
        this.cardTypeName = cardTypeName;
    }

    /**
     * @return The lastFourAcctNbr
     */
    public String getLastFourAcctNbr() {
        return lastFourAcctNbr;
    }

    /**
     * @param lastFourAcctNbr The lastFourAcctNbr
     */
    public void setLastFourAcctNbr(String lastFourAcctNbr) {
        this.lastFourAcctNbr = lastFourAcctNbr;
    }

    /**
     * @return The availableCredit
     */
    public String getAvailableCredit() {
        return availableCredit;
    }

    /**
     * @param availableCredit The availableCredit
     */
    public void setAvailableCredit(String availableCredit) {
        this.availableCredit = availableCredit;
    }

    /**
     * @return The currentBalance
     */
    public String getCurrentBalance() {
        return currentBalance;
    }

    /**
     * @param currentBalance The currentBalance
     */
    public void setCurrentBalance(String currentBalance) {
        this.currentBalance = currentBalance;
    }

    /**
     * @return The lastPaymentAmount
     */
    public String getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    /**
     * @param lastPaymentAmount The lastPaymentAmount
     */
    public void setLastPaymentAmount(String lastPaymentAmount) {
        this.lastPaymentAmount = lastPaymentAmount;
    }

    /**
     * @return The lastPaymentDate
     */
    public String getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * @param lastPaymentDate The lastPaymentDate
     */
    public void setLastPaymentDate(String lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    /**
     * @return The minimumPaymentDue
     */
    public String getMinimumPaymentDue() {
        return minimumPaymentDue;
    }

    /**
     * @param minimumPaymentDue The minimumPaymentDue
     */
    public void setMinimumPaymentDue(String minimumPaymentDue) {
        this.minimumPaymentDue = minimumPaymentDue;
    }

    /**
     * @return The paymentDueDate
     */
    public String getPaymentDueDate() {
        return paymentDueDate;
    }

    /**
     * @param paymentDueDate The paymentDueDate
     */
    public void setPaymentDueDate(String paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    /**
     * @return The primaryCardmember
     */
    public PrimaryCardmember getPrimaryCardmember() {
        return primaryCardmember;
    }

    /**
     * @param primaryCardmember The primaryCardmember
     */
    public void setPrimaryCardmember(PrimaryCardmember primaryCardmember) {
        this.primaryCardmember = primaryCardmember;
    }

    /**
     * @return The statementBalance
     */
    public String getStatementBalance() {
        return statementBalance;
    }

    /**
     * @param statementBalance The statementBalance
     */
    public void setStatementBalance(String statementBalance) {
        this.statementBalance = statementBalance;
    }

    /**
     * @return The earnRewardAmount
     */
    public String getEarnRewardAmount() {
        return earnRewardAmount;
    }

    /**
     * @param earnRewardAmount The earnRewardAmount
     */
    public void setEarnRewardAmount(String earnRewardAmount) {
        this.earnRewardAmount = earnRewardAmount;
    }

    /**
     * @return The rewardType
     */
    public String getRewardType() {
        return rewardType;
    }

    /**
     * @param rewardType The rewardType
     */
    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    /**
     * @return The incentiveCode
     */
    public String getIncentiveCode() {
        return incentiveCode;
    }

    /**
     * @param incentiveCode The incentiveCode
     */
    public void setIncentiveCode(String incentiveCode) {
        this.incentiveCode = incentiveCode;
    }

    /**
     * @return The incentiveTypeCode
     */
    public String getIncentiveTypeCode() {
        return incentiveTypeCode;
    }

    /**
     * @param incentiveTypeCode The incentiveTypeCode
     */
    public void setIncentiveTypeCode(String incentiveTypeCode) {
        this.incentiveTypeCode = incentiveTypeCode;
    }

    /**
     * @return The cardProductGroupCode
     */
    public String getCardProductGroupCode() {
        return cardProductGroupCode;
    }

    /**
     * @param cardProductGroupCode The cardProductGroupCode
     */
    public void setCardProductGroupCode(String cardProductGroupCode) {
        this.cardProductGroupCode = cardProductGroupCode;
    }

    /**
     * @return The cardType
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * @param cardType The cardType
     */
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    /**
     * @return The optionCode
     */
    public String getOptionCode() {
        return optionCode;
    }

    /**
     * @param optionCode The optionCode
     */
    public void setOptionCode(String optionCode) {
        this.optionCode = optionCode;
    }

    /**
     * @return The newlyEarnedRewards
     */
    public String getNewlyEarnedRewards() {
        return newlyEarnedRewards;
    }

    /**
     * @param newlyEarnedRewards The newlyEarnedRewards
     */
    public void setNewlyEarnedRewards(String newlyEarnedRewards) {
        this.newlyEarnedRewards = newlyEarnedRewards;
    }

    /**
     * @return The cardImage
     */
    public String getCardImage() {
        return cardImage;
    }

    /**
     * @param cardImage The cardImage
     */
    public void setCardImage(String cardImage) {
        this.cardImage = cardImage;
    }

    /**
     * @return The mailingAddress
     */
    public MailingAddress getMailingAddress() {
        return mailingAddress;
    }

    /**
     * @param mailingAddress The mailingAddress
     */
    public void setMailingAddress(MailingAddress mailingAddress) {
        this.mailingAddress = mailingAddress;
    }

    /**
     * @return The cardTypeIndicator
     */
    public String getCardTypeIndicator() {
        return cardTypeIndicator;
    }

    /**
     * @param cardTypeIndicator The cardTypeIndicator
     */
    public void setCardTypeIndicator(String cardTypeIndicator) {
        this.cardTypeIndicator = cardTypeIndicator;
    }

    /**
     * @return The statementsTransaction
     */
    public StatementsTransaction getStatementsTransaction() {
        return statementsTransaction;
    }

    /**
     * @param statementsTransaction The statementsTransaction
     */
    public void setStatementsTransaction(StatementsTransaction statementsTransaction) {
        this.statementsTransaction = statementsTransaction;
    }

    /**
     * @return The freezeFlag
     */
    public Boolean getFreezeFlag() {
        return freezeFlag;
    }

    /**
     * @param freezeFlag The freezeFlag
     */
    public void setFreezeFlag(Boolean freezeFlag) {
        this.freezeFlag = freezeFlag;
    }

    /**
     * @return The freezeChangeDate
     */
    public String getFreezeChangeDate() {
        return freezeChangeDate;
    }

    /**
     * @param freezeChangeDate The freezeChangeDate
     */
    public void setFreezeChangeDate(String freezeChangeDate) {
        this.freezeChangeDate = freezeChangeDate;
    }

    /**
     * @return The internalStatus
     */
    public String getInternalStatus() {
        return internalStatus;
    }

    /**
     * @param internalStatus The internalStatus
     */
    public void setInternalStatus(String internalStatus) {
        this.internalStatus = internalStatus;
    }

    /**
     * @return The externalStatus
     */
    public String getExternalStatus() {
        return externalStatus;
    }

    /**
     * @param externalStatus The externalStatus
     */
    public void setExternalStatus(String externalStatus) {
        this.externalStatus = externalStatus;
    }

    /**
     * @return The acctKey
     */
    public String getAcctKey() {
        return acctKey;
    }

    /**
     * @param acctKey The acctKey
     */
    public void setAcctKey(String acctKey) {
        this.acctKey = acctKey;
    }

    /**
     * @return The hideScreens
     */
    public List<String> getHideScreens() {
        return hideScreens;
    }

    /**
     * @param hideScreens The hideScreens
     */
    public void setHideScreens(List<String> hideScreens) {
        this.hideScreens = hideScreens;
    }

    /**
     * @return phoneNumber
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return
     */
    public String getIsAccountReplaced() {
        return isAccountReplaced;
    }

    /**
     * @param isAccountReplaced
     */
    public void setIsAccountReplaced(String isAccountReplaced) {
        this.isAccountReplaced = isAccountReplaced;
    }


    /** start newly added field for US48093 changes */

    public ExternalStatusMessage getExternalStatusMessage() {
        return externalStatusMessage;
    }

    public void setExternalStatusMessage(ExternalStatusMessage externalStatusMessage) {
        this.externalStatusMessage = externalStatusMessage;
    }

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    public Boolean getCardProductGroupOutageMode() {
        return cardProductGroupOutageMode;
    }

    public void setCardProductGroupOutageMode(Boolean cardProductGroupOutageMode) {
        this.cardProductGroupOutageMode = cardProductGroupOutageMode;
    }

    public Boolean getPaperlessOutageMode() {
        return paperlessOutageMode;
    }

    public void setPaperlessOutageMode(Boolean paperlessOutageMode) {
        this.paperlessOutageMode = paperlessOutageMode;
    }

    public Boolean getRewardOutage() {
        return rewardOutage;
    }

    public void setRewardOutage(Boolean rewardOutage) {
        this.rewardOutage = rewardOutage;
    }

    public Boolean getSmcOutageMode() {
        return smcOutageMode;
    }

    public void setSmcOutageMode(Boolean smcOutageMode) {
        this.smcOutageMode = smcOutageMode;
    }

    public String getOutageModeVal() {
        return outageModeVal;
    }

    public void setOutageModeVal(String outageModeVal) {
        this.outageModeVal = outageModeVal;
    }

    public Boolean getAcLiteOutageMode() {
        return acLiteOutageMode;
    }

    public void setAcLiteOutageMode(Boolean acLiteOutageMode) {
        this.acLiteOutageMode = acLiteOutageMode;
    }

    /** end newly added field for US48093 changes */
    public TargetMarketing getTargetMarketing() {
        return targetMarketing;
    }

    public void setTargetMarketing(TargetMarketing targetMarketing) {
        this.targetMarketing = targetMarketing;
    }



    public String getCreditLimit() {
        return creditLimit;
    }

    @Override
    public String getSortId() {
        return this.acctKey != null ? this.ACC_CREDIT_CARD.concat(this.acctKey) : null;
    }

    /** start Added for US89215 - Messaging App SDK Integration */
    public OAuthClientDetails getoAuthClientDetails() {
        return oAuthClientDetails;
    }

    public void setoAuthClientDetails(OAuthClientDetails oAuthClientDetails) {
        this.oAuthClientDetails = oAuthClientDetails;
    }

    public MessagingFlags getMessagingFlags() {
        return messagingFlags;
    }

    public void setMessagingFlags(MessagingFlags messagingFlags) {
        this.messagingFlags = messagingFlags;
    }
    /** end Added for US89215 - Messaging App SDK Integration */

    public boolean getAnrConversionForward(){
        return anrConversionForward;
    }
}
