/*
 *  Copyright Solstice Mobile 2013
 */
package com.discover.mobile.common.help;

import com.discover.mobile.common.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * Help menu widget that can be utilized to show menu the menu drop down and
 * give the items the ability to be clicked on.
 *
 * To use the widget place the following xml at the end of a relative layout.
 * <com.discover.mobile.common.help.HelpWidget
 * android:id="@+id/help"
 * android:layout_width="match_parent"
 * android:layout_height="wrap_content" />
 *
 * By placing this at the end of a relative layout this will allow the dropdown
 * to be displayed over all of the other views.
 *
 * Then to add items to the menu, create a list of items that need to be shown
 * and then call the showHelpItems method.
 *
 * @author jthornton
 */
public class HelpWidget extends RelativeLayout {
    private static Animation fadeOutAnimation = null;
    private static Animation fadeInAnimation = null;

    /** Image of the help button */
    private final ImageButton help;

    /** View holding everything that can be expanded */
    private final RelativeLayout expandableView;

    /** List containing the help icons */
    private final ListView list;

    /** Adapter attached to the list */
    private final HelpAdapter adapter;
    /**
     * Animates the HelpWidget to open.
     * Fade in Runnable. Should be used with a View.post(Runnable) method, to queue the animation
     * onto the UI thread.
     */
    private final Runnable fadeInAnimationRunnable = new Runnable() {
        @Override
        public void run() {
            expandableView.startAnimation(fadeInAnimation);
            expandableView.setVisibility(View.VISIBLE);
        }
    };
    /**
     * Animates the HelpWidget to close.
     * Fade out Runnable. Should be used with a View.post(Runnable) method, to queue the animation
     * onto the UI thread.
     */
    private final Runnable fadeOutAnimationRunnable = new Runnable() {
        @Override
        public void run() {
            expandableView.startAnimation(fadeOutAnimation);
            expandableView.setVisibility(View.INVISIBLE);
        }
    };

    /**
     * Constructor for the help widget
     *
     * @param context - activity context
     * @param attrs   - attributes to be applied to the layout
     */
    public HelpWidget(final Context context, final AttributeSet attrs) {
        super(context, attrs);
        final View view = LayoutInflater.from(context).inflate(R.layout.common_help_widget, null);
        loadAnimations();
        help = (ImageButton) view.findViewById(R.id.help);
        expandableView = (RelativeLayout) view.findViewById(R.id.help_list);
        list = (ListView) view.findViewById(R.id.help_list_view);

        adapter = new HelpAdapter(context, R.layout.common_help_list_item, new ArrayList<HelpItemGenerator>());
        list.setAdapter(adapter);

        help.setImageDrawable(context.getResources().getDrawable(R.drawable.common_question_mark_icon));
        help.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View v) {
                if (expandableView.getVisibility() == View.INVISIBLE) {
                    help.setImageDrawable(context.getResources().getDrawable(R.drawable.help_icon_gray_no_glow));
                    expandableView.post(fadeInAnimationRunnable);
                } else {
                    help.setImageDrawable(context.getResources().getDrawable(R.drawable.common_question_mark_icon));
                    expandableView.post(fadeOutAnimationRunnable);
                }
            }
        });

        addView(view);
    }

    /**
     * Load the animations that are used during opening and closing the menu
     */
    private void loadAnimations() {
        if (fadeInAnimation == null) {
            fadeInAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.fade_in_animation);
        }

        if (fadeOutAnimation == null) {
            fadeOutAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.fade_out_animation);
        }
    }

    /**
     * Show the help items in the menu so that they can be clicked on.
     * This will show all the items in the list in the order that the
     * items are in the list.
     *
     * @param items - list of items to be shown in the menu
     */
    public void showHelpItems(final List<HelpItemGenerator> items) {
        if (null == items || items.isEmpty()) {
            return;
        }
        adapter.setData(items);
        adapter.notifyDataSetChanged();
    }

}
