package com.discover.mobile.common.shared.net.json;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.common.shared.net.error.AbstractErrorResponse;
import com.discover.mobile.common.shared.net.error.ErrorMessageMapper;
import com.discover.mobile.common.shared.utils.Objects;

import java.io.Serializable;
import java.util.List;

public class JsonMessageErrorResponse extends AbstractErrorResponse<JsonMessageErrorResponse> {

    private static final long serialVersionUID = 5979837443360856714L;

    @SerializedName("status")
    private int messageStatusCode;

    @SerializedName("message")
    private String message;

    // TODO move to another subclass to make triage easier
    @SerializedName("data")
    private List<Data> data;

    public int getMessageStatusCode() {
        return messageStatusCode;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("httpStatusCode", getHttpStatusCode())
                .add("messageStatusCode", messageStatusCode)
                .add("message", message).toString();
    }

    @Override
    public ErrorMessageMapper<JsonMessageErrorResponse> getMessageMapper() {
        // TODO Auto-generated method stub
        return null;
    }

    public static class Data implements Serializable {
        private static final long serialVersionUID = 6370942047530497928L;
        public String status;
        public String saStatus;

    }

}
