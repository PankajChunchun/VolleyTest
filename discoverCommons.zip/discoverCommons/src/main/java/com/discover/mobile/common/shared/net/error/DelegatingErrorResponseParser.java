package com.discover.mobile.common.shared.net.error;

import com.discover.mobile.common.shared.net.json.JsonMessageErrorResponseParser;
import com.discover.mobile.common.shared.utils.CommonUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

import static com.discover.mobile.common.shared.ThreadUtility.assertNonMainThreadExecution;


public class DelegatingErrorResponseParser implements ErrorResponseParser<ErrorResponse<?>> {

    public static final List<ErrorResponseParser<?>> DEFAULT_PARSER_DELEGATES = createDefaultDelegates();
    private static final Object SHARED_INSTANCE_LOCK = new Object();
    private static final int HTTP_ERROR_STATUS_MINIMUM = 400;
    private static DelegatingErrorResponseParser sharedInstance;
    private List<ErrorResponseParser<?>> parserDelegates;

    public DelegatingErrorResponseParser(final List<ErrorResponseParser<?>> parserDelegates) {
        CommonUtils.checkNotNull(parserDelegates, "parserDelegates cannot be null");
        CommonUtils.checkArgument(!parserDelegates.isEmpty(), "parserDelegates cannot be empty");

        if (DEFAULT_PARSER_DELEGATES.equals(parserDelegates)) {
            this.parserDelegates = DEFAULT_PARSER_DELEGATES;  // since its immutable already
        } else {
            this.parserDelegates = new ArrayList<ErrorResponseParser<?>>();
            for (ErrorResponseParser<?> errorResponseParser : parserDelegates) {
                this.parserDelegates.add(errorResponseParser);
            }
        }
    }

    public static DelegatingErrorResponseParser getSharedInstance() {
        assertNonMainThreadExecution(); // using synchronization, don't want to block on UI thread

        return getOrCreateSharedInstance();
    }

    private static DelegatingErrorResponseParser getOrCreateSharedInstance() {
        synchronized (SHARED_INSTANCE_LOCK) {
            if (sharedInstance == null) {
                sharedInstance = new DelegatingErrorResponseParser(DEFAULT_PARSER_DELEGATES);
            }

            return sharedInstance;
        }
    }

    //Can add to this list if we want to add defaults (Error Handling)
    private static List<ErrorResponseParser<?>> createDefaultDelegates() {
        ArrayList<ErrorResponseParser<?>> temp = new ArrayList<ErrorResponseParser<?>>();
        temp.add(new JsonMessageErrorResponseParser());
        temp.add(new EmptyErrorResponseParser());
        return temp;
    }

    public static boolean isErrorStatus(final int httpStatusCode) {
        return httpStatusCode >= HTTP_ERROR_STATUS_MINIMUM;
    }

    private static ErrorResponse<?> tryDelegateParse(final ErrorResponseParser<?> parser,
                                                     final int httpStatusCode, final InputStream in, final HttpURLConnection conn) throws IOException {

        final ErrorResponse<?> response = parser.parseErrorResponse(httpStatusCode, in, conn);
        if (response instanceof AbstractErrorResponse) {
            setProtectedFields((AbstractErrorResponse<?>) response, httpStatusCode, conn);
        }
        return response;
    }

    private static void setProtectedFields(final AbstractErrorResponse<?> response, final int httpStatusCode, final HttpURLConnection connection) {
        response.setHttpStatusCode(httpStatusCode);
        response.setConnection(connection);
    }

    @Override
    public ErrorResponse<?> parseErrorResponse(final int httpStatusCode, final InputStream in,
                                               final HttpURLConnection conn) throws IOException {

        for (final ErrorResponseParser<?> parser : parserDelegates) {
            final ErrorResponse<?> response = tryDelegateParse(parser, httpStatusCode, in, conn);
            if (response != null) {
                return response;
            }
        }

        throw new UnsupportedOperationException("Unable to parse error response, no compatible parser found");
    }

}
