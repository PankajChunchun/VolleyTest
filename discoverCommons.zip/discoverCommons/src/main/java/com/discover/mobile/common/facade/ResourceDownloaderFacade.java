package com.discover.mobile.common.facade;

import java.io.OutputStream;

public interface ResourceDownloaderFacade {
    /**
     * @return output stram
     */
    OutputStream getErrorJsonFile(String url);
}
