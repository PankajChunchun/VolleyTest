/**
 *
 */

package com.discover.mobile.common.push.receive;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.discover.mobile.common.facade.FacadeFactory;

/**
 * @author CTS
 */
public class XtifyEventReceiver extends BroadcastReceiver {

    //PUSH_Notification Bank/Card identifier
    public static final String PUSH_BANK = "BANK";

    // bank or card identifier
    String notificationIdentifier = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        String payload = null, title = null;
        final String action = intent.getAction();

        /*intent action received for simply dismissing the notification without any action*/
        if(action.equalsIgnoreCase("com.discover.mobile.notificationdismiss")){
            return;
        }

        payload = intent.getExtras().getString("data.customKey");
        title = intent.getExtras().getString("com.xtify.sdk.NOTIFICATION_TITLE");
        // bank or card identifier - commented and hard coded for now
        notificationIdentifier = intent.getExtras().getString("data.assignFor");

        if (payload != null && payload.contains("bank")) {
            notificationIdentifier = PUSH_BANK;
        } else {
            notificationIdentifier = "";
        }


        //Temporarily added since identifier is null
        if (notificationIdentifier == null) {
            notificationIdentifier = "BANK";
        }
        String[] keyValuePayload = null;
        String[] reqIdKeyValue = null;
        String[] pageCodeKeyValue = null;


        if (payload != null) {
            keyValuePayload = payload.split(",");
            reqIdKeyValue = keyValuePayload[0].split("=");
            pageCodeKeyValue = keyValuePayload[1].split("=");
        }

        if (intent.getAction().equalsIgnoreCase("com.xtify.sdk.EVENT_NCK")) {

            if (notificationIdentifier.equalsIgnoreCase(PUSH_BANK)) {
                // Bank notification
                // Bank pay load navigations
                FacadeFactory.getBankPushNotificationFacade()
                        .handleBankPayloadNavigations(context, reqIdKeyValue,
                                pageCodeKeyValue, title);
            } else {
                // Card notification
                // Card pay load navigations
                FacadeFactory.getCardPushNotificationFacade()
                        .handleCardPayloadNavigations(context, reqIdKeyValue,
                                pageCodeKeyValue);
            }

        }

    }
}

