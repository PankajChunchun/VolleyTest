package com.discover.mobile.common.fingerprint.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.fingerprint.adapter.FingerPrintAdapter;
import com.discover.mobile.common.fingerprint.listener.FingerPrintDialogActionListener;
import com.discover.mobile.common.fingerprint.listener.FingerPrintListener;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;

import android.app.Activity;
import android.app.DialogFragment;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * A dialog which uses fingerprint APIs to authenticate the user.
 * Device should have fingerprint sensor to use this dialog
 * Added for US71513 - fingerprint login modal
 */
public class FingerPrintDialog extends DialogFragment implements FingerPrintListener {


    final long SUCCESS_DELAY_MILLIS = 1300;

    private FingerPrintAdapter fingerPrintAdapter;
    private FingerPrintListener fingerPrintListenerActivity = null;

    private Button btnCancel;
    private Context mContext;

    /** ImageView to show default fingerprint thumb icon or Error icon */
    private ImageView dialogContentIcon;

    /** TextView to show different error messages while scanning thumb */
    private TextView dialogErrorTextView;
    private FingerPrintDialogActionListener mFingerPrintDialogActionListener;
    private boolean isActivitysOnSaveInstanceStateCalled = false;
    private String TAG = FingerPrintDialog.class.getSimpleName();

    public FingerPrintDialog() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getActivity();
        // Do not create a new Fragment when the Activity is re-created such as orientation changes.
        setRetainInstance(true);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Material_Light_Dialog);

        setCancelable(true);

        if (null != FingerPrintUtils.getAvailableFPApiType())
            fingerPrintAdapter = new FingerPrintAdapter(getActivity(), FingerPrintUtils.getAvailableFPApiType(), this);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        getDialog().setTitle(mContext.getResources().getString(R.string.fingerprint_login_modal_title));
        getDialog().setCanceledOnTouchOutside(false);

        View view = inflater.inflate(R.layout.fingerprint_dialog_container, container, false);

        dialogContentIcon = (ImageView) view.findViewById(R.id.fingerprint_icon);
        dialogErrorTextView = (TextView) view.findViewById(R.id.fingerprint_status);

        btnCancel = (Button) view.findViewById(R.id.fingerprint_login_modal_cancel_button);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mFingerPrintDialogActionListener != null) {
                    mFingerPrintDialogActionListener.handleCancelAction();
                }
            }
        });


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        isActivitysOnSaveInstanceStateCalled = false;
        if (null != fingerPrintAdapter) {
            /**
             * Added if condition to handle scenario - FP Login dialog is visible on Login screen & user kept Discover app in stack & went to
             * Devices Settings page & removed all registered FP from device then in this case it should dismiss the modal & otherwise its crashes.
             */
            if (FingerPrintUtils.isFingerprintRegistered(mContext)) {
                fingerPrintAdapter.startListening();
                //fix for defect #1193
            } else if (isAdded() && !isActivitysOnSaveInstanceStateCalled) {
                dismiss();
            }
        }
    }


    @Override
    public void onPause() {
        super.onPause();
        if (null != fingerPrintAdapter)
            fingerPrintAdapter.stopListening();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        //Crashlytics--303-- Adding check for instanceof FingerPrintListener
        if(activity instanceof FingerPrintListener)
                fingerPrintListenerActivity = (FingerPrintListener) activity;
        else
            Log.e(TAG,"Exception : Activity must implement FingerPrintListener");

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //fix for defect #1193
        isActivitysOnSaveInstanceStateCalled = true;

    }

    @Override
    public void onViewStateRestored(Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        //fix for defect #1193
        isActivitysOnSaveInstanceStateCalled = false;
    }

    @Override
    public void onAuthenticated() {
        if (fingerPrintListenerActivity != null) {
            fingerPrintListenerActivity.onAuthenticated();
        }
        //fix for defect crashlytics 401 and #1193
        if(mContext!=null && isAdded() && !isActivitysOnSaveInstanceStateCalled) {
            dismiss();
        }
    }

    @Override
    public void onAuthenticationHelp(String helpString) {
        showAuthenticationError(helpString);
    }

    @Override
    public void onError(String errMessage) {
        showAuthenticationError(errMessage);
    }

    public void setCancelAction(FingerPrintDialogActionListener fingerPrintDialogActionListener) {
        this.mFingerPrintDialogActionListener = fingerPrintDialogActionListener;
    }

    /**
     * Method to show fingerprint authentication failure scenarios on dialog for few seconds
     */
    private void showAuthenticationError(String error) {
        dialogContentIcon.setImageResource(R.drawable.fingerprint_error_icon);
        dialogErrorTextView.setText(mContext.getResources().getString(R.string.fingerprint_scanning_warning_message));
        dialogErrorTextView.setTextColor(ContextCompat.getColor(mContext, R.color.fingerprint_warning_color));
        if (fingerPrintListenerActivity != null) {
            fingerPrintListenerActivity.onError(error);
        }
    }

    /**
     * Method to show success fingerprint authentication message on dialog for few seconds
     * & return authentication success callback to parent screen
     */
    public void showAuthenticationSuccess() {
        dialogContentIcon.setImageResource(R.drawable.fingerprint_success_icon);
        dialogErrorTextView.setTextColor(ContextCompat.getColor(mContext, R.color.fingerprint_success_color));
        dialogErrorTextView.setText(mContext.getResources().getString(R.string.fingerprint_scanning_successful_message));
        dialogContentIcon.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (fingerPrintListenerActivity != null) {
                    fingerPrintListenerActivity.onAuthenticated();
                }
                if(!isActivitysOnSaveInstanceStateCalled){
                dismiss();}
            }
        }, SUCCESS_DELAY_MILLIS);
    }

    @Override
    public void onDestroyView() {
        // There is an open defect (https://code.google.com/p/android/issues/detail?id=17423) into compatibility library
        // which makes dialog disappear if setRetainInstance(true) has been used to DialogFragment.

        // Below is fix for that.
        if (getDialog() != null && getRetainInstance()) {
            getDialog().setDismissMessage(null);
        }
        super.onDestroyView();
    }
}

