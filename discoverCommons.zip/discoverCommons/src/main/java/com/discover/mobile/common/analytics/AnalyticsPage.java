package com.discover.mobile.common.analytics;

import com.discover.mobile.common.R;
import com.discover.mobile.common.shared.DiscoverActivityManager;


/**
 * @author 407898
 */
public interface AnalyticsPage {

    // used
    static final String STARTING = "login-pg";

    // keys

    public static final String CONTEXT_PROPERTY_10 = DiscoverActivityManager.getString(R.string.context_Property_10);
    public static final String CONTEXT_PROPERTY_1 = DiscoverActivityManager.getString(R.string.context_Property_1);
    public static final String CONTEXT_PROPERTY_18 = DiscoverActivityManager.getString(R.string.context_Property_18);
    public static final String CONTEXT_PROPERTY_13 = DiscoverActivityManager.getString(R.string.context_Property_13);
    public static final String CONTEXT_PROPERTY_22 = DiscoverActivityManager.getString(R.string.context_page_name);

    // static final String CARD_LOGIN = "cardLogin-pg";
    static final String PASSCODE_LOGIN = "Login_Passcode-pg";
    static final String LOGIN_ERROR = "loginErrorPage-Pg";
    static final String FORGOT_PASSWORD_MENU = "forgot-uid-or-password-menu-pg";
    static final String FORGOT_BOTH_STEP1 = "forgot-both-step1-pg";
    static final String FORGOT_BOTH_STEP2 = "forgot-both-step2-pg";
    static final String FORGOT_BOTH_CONFIRMATION = "forgot-both-confirmation-pg";
    static final String FORGOT_PASSWORD_STEP1 = "forgot-password-step1-pg";
    static final String FORGOT_PASSWORD_STEP2 = "forgot-password-step2-pg";
    static final String FORGOT_PASSWORD_CONFIRMATION = "forgot-password-confirmation-pg";
    static final String FORGOT_UID = "forgot-uid-pg";
    static final String FOROGT_UID_CONFIRMATION = "forgot-uid-confirmation-pg";
    static final String FORGOT_PASSCODE = "Forgot_passcode-pg";
    static final String LOG_OFF = "logout-pg";
    static final String REGISTER_NOW = "register_now-pg";
    public static final String REGISTER_CARD_ERROR_PAGE = "Card_Registration_Error-pg";
    public static final String REGISTER_CARD_ERROR_PROP = "Card Registration:Invalid info";
    static final String REQUEST_OOB_CODE = "login_OOB_request-pg";
    static final String OOB_SUCCESS = "OOB_successful";
    static final String PRIVACY_TERMS = "Privacy_Terms_loggedout-pg";
    static final String PRIVACY_STATEMENT = "Privacy_Statement_loggedout-pg";
    static final String MOBILE_TERMS = "Mobile_Terms_loggedout-pg";
    static final String CUSTOMER_SERVICE = "customer_service_loggedout-pg";

    static final String OOB_SUCCESS_prop5 = "my.prop5";
    static final String OOB_SUCCESS_evar5 = "my.eVar5";

    static final String FAILED_LOGIN = "FailedLogin";

    static final String LOGOUT_BUTTON_prop1 = "LOGOUT_TAPPED";
    static final String LOGOUT_BUTTON_pe = "lnk_o";
    static final String LOGOUT_TAPPED_pev1 = "LOGOUT_TAPPED";

    static final String APP_LAUNCHED_prop1 = "APP_LAUNCHED";
    static final String APP_LAUNCHED_pe = "lnk_o";
    static final String APP_LAUNCHED_pev1 = "APP_LAUNCHED";
    static final String APP_LAUNCHED_EVENT11 = "event11";

    static final String CARD_LOGIN_TOGGLE_prop1 = "CARD_LOGIN_TOGGLE_BTN";
    static final String CARD_LOGIN_TOGGLE_pe = "lnk_o";
    static final String CARD_LOGIN_TOGGLE_pev1 = "CARD_LOGIN_TOGGLE_BTN";

    static final String BANK_LOGIN_TOGGLE_prop1 = " BANK_LOGIN_TOGGLE_BTN ";
    static final String BANK_LOGIN_TOGGLE_pe = "lnk_o";
    static final String BANK_LOGIN_TOGGLE_pev1 = "BANK_LOGIN_TOGGLE_BTN ";

    static final String LOGIN_BTN_REMEMBER_USERID_YES_prop1 = "LOGIN_BTN_REMEMBER_USERID_YES ";
    static final String LOGIN_BTN_REMEMBER_USERID_YES_pe = "lnk_o";
    static final String LOGIN_BTN_REMEMBER_USERID_YES_pev1 = "LOGIN_BTN_REMEMBER_USERID_YES ";

    static final String LOGIN_BTN_REMEMBER_USERID_NO_prop1 = "LOGIN_BTN_REMEMBER_USERID_NO ";
    static final String LOGIN_BTN_REMEMBER_USERID_NO_pe = "lnk_o";
    static final String LOGIN_BTN_REMEMBER_USERID_NO_pev1 = "LOGIN_BTN_REMEMBER_USERID_NO ";

    // Account Unlock
    static final String LOCKOUT_TEMP = "Login_TempLock-pg-Overlay";
    static final String LOCKOUT_PERM = "Login_PermLock-pg-Overlay";
    static final String ACCOUNT_UNLOCK_STEP1 = "AccountUnlock_EnterInfo-pg";
    static final String ACCOUNT_UNLOCK_STEP1_ERROR = "AccountUnlock_EnterInfo";
    static final String ACCOUNT_UNLOCK_STEP2 = "AccountUnlock_CreatePassword-pg";
    static final String ACCOUNT_UNLOCK_CONFIRMATION = "AccountUnlock_Unlocked_Success-pg-Overlay";
    static final String ACCOUNT_UNLOCK_TEMP_LOCK_OK_BUTTON_prop1 = "ACCT_UNLOCK_TEMP_LOCK_UNLOCK_ACCOUNT_BTN";
    static final String ACCOUNT_UNLOCK_TEMP_LOCK_OK_BUTTON_pe = "lnk_o";
    static final String ACCOUNT_UNLOCK_TEMP_LOCK_OK_BUTTON_pev1 = "Account Unlock-Temp Lock-UnlockAcc Button";
    static final String ACCOUNT_UNLOCK_PERM_LOCK_OK_BUTTON_prop1 = "ACCT_UNLOCK_PERM_LOCK_CALL_NOW_BTN";
    static final String ACCOUNT_UNLOCK_PERM_LOCK_OK_BUTTON_pe = "lnk_o";
    static final String ACCOUNT_UNLOCK_PERM_LOCK_OK_BUTTON_pev1 = "Account Unlock-Perm Lock-CallNow Button";
    static final String ACCOUNT_UNLOCK_FORGOT_PASS_SUBMIT_BUTTON = "ACCT_UNLOCK_FORGOT_PASS_SUBMIT_BTN";
    static final String ACCOUNT_UNLOCK_FORGOT_PASS_SUBMIT_pe = "lnk_o";
    static final String ACCOUNT_UNLOCK_FORGOT_PASS_SUBMIT_pev1 = "Account Unlock-Forgot Pass-Submit Button";

    static final String ACCOUNT_UNLOCK_CREATE_PASSWORD = "AccountUnlock_Login_CreatePassword-pg";
    static final String ACCOUNT_UNLOCKED_MODAL = "AccountUnlock_Unlocked_Success-pg-Overlay";

    static final String PASSWORD_STRENGTH_HELP = "password-strength-meter-pg";
    static final String UID_STRENGTH_HELP = "uid-strength-meter-pg";

    static final String ACCOUNT_LANDING = "accountLanding-pg";
    static final String ACCOUNT_LOCKED = "logInAccLocked-pg";

    static final String FORCED_UPGRADE = "forceUpgrade-pg";
    static final String OPTIONAL_UPGRADE = "optionalUpgrade-pg";
    static final String STATEMENT_IMAGES = "statement-images-pg";
    static final String STRONG_AUTH_FIRST_QUESTION = "strongAuthFirstQues-pg";

    /** Analytic for going to the push alert history */
    static final String PUSH_ALERT_HISTORY = "alertHistory-pg";

    /** Analytic for going to the external email alert */
    static final String PUSH_EXTERNAL_EMAIL_ALERTS = "externalEmailAlerts-pg";

    /** Analytic for going to the push FAQ page */
    static final String PUSH_FAQ = "faqDeviceAlerts-pg";

    /** Analytic for going to the push manage alerts page */
    static final String PUSH_MANAGE_ALERTS = "manageAlerts-pg";

    /** Analytic for going to the push manage alert override */
    static final String PUSH_MANAGE_ALERTS_OVERRIDE = "manageAlertsOverride-pg";

    /** Analytic for going to the push what now page */
    static final String PUSH_NOW_AVAILABLE = "manageAlertsTermsAndConditions-pg";

    /** Analytic for going to the push diagnostic page */
    static final String PUSH_DIAGONSTIC = "pushDiagonstic-pg";

    /** Analytic for going to the push terms and conditions page */
    static final String PUSH_TERMS_AND_CONDITIONS = "pushTermsAndConditions-pg";

    /** Analytic for going to the enroll profile screen */
    static final String PROFILE_ENROLL = "profileEnroll-pg";

    /** Analytic for viewing quickview */
    static final String QUICKVIEW_VIEW = "loginscreenQuickView-pg";

    static final String LOGIN_QUICKVIEW = "Login_Quickview";

    static final String ENHANCED_SECURITY_ALL_INFO_HIDDEN = "AndroidHS_EnhancedSecurityAllInfoHidden-pg";

    /** Analytic for viewing Quick View Stup */
    static final String QUICKVIEW_SETUP_ON = "QuickView-SetUp_ON-pg";
    static final String QUICKVIEW_SETUP_OFF = "QuickView-SetUp_OFF-pg";

    // QuickView Widget

    static final String QUICKVIEW_OVERLAY = "Android_QuickView_WidgetOverlay-pg";
    public static final String QUICKVIEW_VIEW_ACCT_SPECIFIC = "QuickView_Acct_Specific_Error:";

    static final String WIDGET_HS_OVERFLOW_MENU_prop1 = "WIDGET_HS_OVERFLOW_MENU";
    static final String WIDGET_HS_OVERFLOW_MENU_pe = "lnk_o";
    static final String WIDGET_HS_OVERFLOW_MENU_pev1 = "WIDGET_HS_OVERFLOW_MENU";

    // not used yet
    static final String ACCOUNT_CREDIT_LINE_AVAILABLE = "accountCreditLineAvail-pg";
    static final String ACCOUNT_SUMMARY = "accountSummary-pg";
    static final String CARD_HOME = "cardHome-pg";
    static final String CARD_HOME_ESSENTIAL_CARD = "cardHomeEssencialCard-pg";
    static final String CORPORATE_DBC_L = "corporateDBC_L-pg";
    static final String CORPORATE_DBCL = "corporateDBCL-pg";

    // US158631 A/C Home Redesign tags

    static final String CARD_HOME_CBB_VIEW_5PERCENT_CALENDAR_PROP1= "CARD_HOME_CBB_VIEW_5PERCENT_CALENDAR_LNK";
    static final String CARD_HOME_CBB_VIEW_5PERCENT_CALENDAR_PEV1= "CARD_HOME_CBB_VIEW_5PERCENT_CALENDAR_LNK";

    static final String CARD_HOME_FICO_VIEW_BTN_PROP1= "CARD_HOME_FICO_VIEW_BTN";
    static final String CARD_HOME_FICO_VIEW_BTN_PEV1= "CARD_HOME_FICO_VIEW_BTN";

    static final String CARD_HOME_SSN_AND_NEW_ACCOUNT_ALERTS_LNK_PROP1= "CARD_HOME_SSN_AND_NEW_ACCOUNT_ALERTS_LNK";
    static final String CARD_HOME_SSN_AND_NEW_ACCOUNT_ALERTS_LNK_PEV1= "CARD_HOME_SSN_AND_NEW_ACCOUNT_ALERTS_LNK";

    // passcode pages
    static final String PASSCODE_MENU = "passcode_menu-pg";
    static final String PASSCODE_SETUP_STEP1 = "passcode_setup_step1-pg";
    static final String PASSCODE_SETUP_STEP2 = "passcode_setup_step2-pg";
    static final String PASSCODE_SETUP_OVERLAY = "Passcode_Setup_Confirmation-pg-Overlay";

    static final String PASSCODE_UPDATE_STEP1 = "passcode_update_step1-pg";
    static final String PASSCODE_UPDATE_STEP2 = "passcode_update_step2-pg";
    static final String PASSCODE_UPDATE_STEP3 = "passcode_update_step3-pg";
    static final String PASSCODE_UPDATE_OVERLAY = "Passcode_Updated_Confirmation-pg-Overlay";

    static final String PASSCODE_REMOVE = "passcode_remove-pg";
    static final String PASSCODE_DISABLE_OVERLAY = "Passcode_Disabled-pg-Overlay";

    static final String PASSCODE_ENABLE_STEP1 = "passcode_enable_step1-pg";
    static final String PASSCODE_ENABLE_STEP2 = "passcode_enable_step2-pg";
    static final String PASSCODE_ENABLE_OVERLAY = "Passcode_Enabled_Confirmation-pg-Overlay";

    static final String PASSCODE_FORGOT_STEP1 = "passcode_forgot_step1-pg";
    static final String PASSCODE_FORGOT_STEP2 = "passcode_forgot_step2-pg";
    static final String PASSCODE_FORGOT_OVERLAY = "Passcode_Forgot_Confirmation-pg-Overlay";

    static final String PASSCODE_RED_X = "passcode_RedCheck-pg";
    static final String PASSCODE_GREEN_CHECK = "passcode_GreenCheck-pg";
    static final String PASSCODE_OVERLAY = "passcode_guidelines-pg-overlay";

    // Strong Auth Enroll pages

    static final String SETUP_ENHANCED_AUTH = "SetUp_enhanced_auth-Populated-pg";
    static final String SETUP_ENHANCED_AUTH_NOT_POPULATED = "SetUp_enhanced_auth-Not_populated-pg";
    static final String SETUP_ENHANCED_AUTH_CHECKPOINT = "SetUp_enhanced_auth-Checkpoint-pg";
    static final String SETUP_ENHANCED_SELECT_QUESTION = "SetUp_enhanced_auth_SelectAQuestion-pg";
    static final String SETUP_ENHANCED_AUTH_CONFIRMATION = "SetUp_enhanced_auth_Confirmation-pg";

     /*Fraud Verification -Analytics- start*/

    /*Fraud -Unusual Acc Activity Modal  */
    static final String FRAUDVERIFICATION_UNUSUAL_ACTIVITY_MODAL_PAGENAME = "Unusual_Account_Activity_Overlay-pg";

    /*Fraud -Unusual Acc Activity Modal -SSO */
    static final String FRAUDVERIFICATION_UNUSUAL_ACTIVITY_MODAL_SSO_PAGENAME = "Unusual_SSO_Account_Activity_Overlay-pg";

    /*Fraud - Unusual Account Activiy Modal - Review Click*/
    static final String FRAUDVERIFICATION_INTERCEPT_MODAL_REVIEW_BUTTON_prop1 = "UNUSUAL_ACCT_ACTIVITY_REVIEW_BTN";
    static final String FRAUDVERIFICATION_INTERCEPT_MODAL_REVIEW_BUTTON_pe = "lnk_o";
    static final String FRAUDVERIFICATION_INTERCEPT_MODAL_REVIEW_BUTTON_pev1 = "UNUSUAL_ACCT_ACTIVITY_REVIEW_BTN";

    /*Fraid - Unusual Account Activity Modal - Close Click*/
    static final String FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_prop1 = "UNUSUAL_ACCT_ACTIVITY_CLOSE_BTN";
    static final String FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_pe = "lnk_o";
    static final String FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_pev1 = "UNUSUAL_ACCT_ACTIVITY_CLOSE_BTN";

    /*Fraud Verify Page*/
    static final String FRAUDVERIFICATION_VERIFY_PAGE_NAME = "Unusual_Account_Activity_Verify_Fraud_Transaction-pg";

    /*Tracking Verification Page -Yes Button Click*/
    static final String FRAUDVERIFICATION_REVIEW_YES_BUTTON_prop1 = "UNUSUAL_ACCT_ACTIVITY_VERIFY_YES_BTN";
    static final String FRAUDVERIFICATION_REVIEW_YES_BUTTON_pe = "lnk_o";
    static final String FRAUDVERIFICATION_REVIEW_YES_BUTTON_pev1 = "UNUSUAL_ACCT_ACTIVITY_VERIFY_YES_BTN";

    /*Tracking Verification Page -No Button Click*/
    static final String FRAUDVERIFICATION_REVIEW_NO_BUTTON_prop1 = "UNUSUAL_ACCT_ACTIVITY_VERIFY_NO_BTN";
    static final String FRAUDVERIFICATION_REVIEW_NO_BUTTON_pe = "lnk_o";
    static final String FRAUDVERIFICATION_REVIEW_NO_BUTTON_pev1 = "UNUSUAL_ACCT_ACTIVITY_VERIFY_NO_BTN";

    /*Fraud Transaction COnfirmation Page*/
    static final String FRAUDVERIFICATION_CONFIRM_PAGE_NAME = "Unusual_Account_Activity_Transaction_Not_Valid-pg";

    /*Fraud Confirmation - Save tp Photos Click*/
    static final String FRAUD_VERIFICATION__SAVE_TO_PHOTOS_prop1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_SAVE_TO_PHOTOS_LNK";
    static final String FRAUD_VERIFICATION__SAVE_TO_PHOTOS_pe1 = "lnk_o";
    static final String FRAUD_VERIFICATION__SAVE_TO_PHOTOS_pev1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_SAVE_TO_PHOTOS_LNK";

    /*Fraud System Error Call Button Click*/
    static final String FRAUDVERIFICATION_CALL_prop1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_CALL_BTN";
    static final String FRAUDVERIFICATION_CALL_pe = "lnk_o";
    static final String FRAUDVERIFICATION_CALL_pev1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_CALL_BTN";

    static final String FRAUDVERIFICATION_SYSTEM_APP_ERROR_LINK_prop1 = "UNUSUAL_ACCT_ACTIVITY_FRAUD_VERIFICATION_SYSTEM_ERROR_LNK";
    static final String FRAUDVERIFICATION_SYSTEM_APP_ERROR_LINK_pe = "lnk_o";
    static final String FRAUDVERIFICATION_SYSTEM_APP_ERROR_LINK_pev1 = "UNUSUAL_ACCT_ACTIVITY_FRAUD_VERIFICATION_SYSTEM_ERROR_LNK";

    /*Fraud Confirmation Helpline Num Click*/
    static final String FRAUDVERIFICATION_CALL_LINK_prop1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_PHONE_NUM_LNK";
    static final String FRAUDVERIFICATION_CALL_LINK_pe = "lnk_o";
    static final String FRAUDVERIFICATION_CALL_LINK_pev1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_PHONE_NUM_LNK";

    /*Fraud System error Page*/
    static final String FRAUD_VERIFICATION__SYSTEM_ERROR_PAGE_NAME = "Unusual_Account_Activity_Fraud_Verification_System_Error-pg";

    /*No Fraud Confirmation Modal*/
    static final String FRAUDVERIFICATION_NO_FRAUD_CONFIRMATION_MODAL_PAGENAME = "Unusual_Account_Activity_Transaction_Confirmation_Modal-pg";

    /* No Fraud Confirmation Modal CLose Button Click*/
    static final String FRAUDVERIFICATION_CONFIRMATION_MODAL_CLOSE_BUTTON_prop1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_CONFIRMATION_CLOSE_BTN";
    static final String FRAUDVERIFICATION_CONFIRMATION_MODAL_CLOSE_BUTTON_pe = "lnk_o";
    static final String FRAUDVERIFICATION_CONFIRMATION_MODAL_CLOSE_BUTTON_pev1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_CONFIRMATION_CLOSE_BTN";

    /*Fraud Save to Photos Tracking*/
    static final String FRAUD_VERIFICATION__SAVE_TO_PHOTOS_SUCCESS_PAGE_NAME = "Unusual_Account_Activity_Transaction_Save_to_Photos_Confirmation-pg";

    /*Tracking Portal Drawer Click for Fraud*/
    static final String FRAUD_VERIFICATION_PORTAL_DRAWER_CLICK_prop1 = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_PORTAL_DRAWER_BTN";
    static final String FRAUD_VERIFICATION_PORTAL_DRAWER_CLICK_pe = "lnk_o";
    static final String FRAUD_VERIFICATION_PORTAL_DRAWER_CLICK_pev = "UNUSUAL_ACCT_ACTIVITY_TRAN_NOT_VALID_PORTAL_DRAWER_BTN";
    static final String FRAUD_VERIFICATION_PORTAL_DRAWER_CLICK_Verify_PAGE_prop1 = "UNUSUAL_ACCT_ACTIVITY_VERIFY_PORTAL_DRAWER_BTN";
    static final String FRAUD_VERIFICATION_PORTAL_DRAWER_CLICK_VERIFY_PAGE_pev = "UNUSUAL_ACCT_ACTIVITY_VERIFY_PORTAL_DRAWER_BTN";
   /*Fraud Verification -Analytics- end*/

    /*// MOP
    static final String MOP_EXTRAS_OVERLAY = "MOP_Extras-pg-Overlay";
    static final String MOP_SUMMARY_PAGE = "MOP_Extras_DefaultView-pg";
    static final String MOP_DEFAULT_SEARCH_EXPANDED = "Mop_Extras_DefaultView_SearchExpanded";
    static final String MOP_SEARCH_KEYWORD = "search keywords";
    static final String MOP_DETAIL_LEAVING_APP = "Mop_DetailView_LeavingApp_Pg-Overlay";
    static final String MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_PROP1 = "ANDROID_MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_TXT";
    static final String MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_PE = "lnk_o";
    static final String MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_PEV1 = "Android_mop_details_part_tap_here_to_redeem_txt";
    static final String MOP_DETAILS_PART_2222_TXT_PREV1 = "ANDROID_MOP_DETAILS_PART_2222_TXT";
    static final String MOP_DETAILS_PART_2222_TXT_PE = "lnk_o";
    static final String MOP_DETAILS_PART_2222_TXT_PEV1 = "Android_mop_details_part_2222_txt";
    static final String MOP_LEAVING_APP_CONTINUE_BTN_PREV1 = "ANDROID_MOP_LEAVING_APP_CONTINUE_BTN";
    static final String MOP_LEAVING_APP_CONTINUE_BTN_PE = "lnk_o";
    static final String MOP_LEAVING_APP_CONTINUE_BTN_PEV1 = "Android_mop_leaving_app_continue_btn";
    static final String ANDROIDHS_MOP_SAVE_TAB_PG_OVERLAY = "AndroidHS_MOP_SaveTab-pg-Overlay";
    // MOP1C
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_OFFERS_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_ALL_OFFERS_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_OFFERS_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_OFFERS_PEV1 = "AndroidHS_MOP_all_offers_all_offers_btn";

    static final String ANDROIDHS_MOP_ALL_OFFERS_SEARCH_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_SEARCH_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SEARCH_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SEARCH_PEV1 = "AndroidHS_MOP_all_offers_search_btn";

    static final String ANDROIDHS_MOP_ALL_OFFERS_EXPLORE_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_EXPLORE_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_EXPLORE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_EXPLORE_PEV1 = "AndroidHS_MOP_all_offers_explore_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SAVED_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_SAVED_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SAVED_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SAVED_PEV1 = "AndroidHS_MOP_all_offers_saved_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_ALL_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_PEV1 = "AndroidHS_MOP_all_offers_all_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_IN_STORE_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_IN_STORE_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_IN_STORE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_IN_STORE_PEV1 = "AndroidHS_MOP_all_offers_in_store_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ONLINE_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_ONLINE_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ONLINE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ONLINE_PEV1 = "AndroidHS_MOP_all_offers_online_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SORT_PROP1 = "ANDROIDHS_MOP_ALL_OFFERS_SORT_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SORT_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SORT_PEV1 = "AndroidHS_MOP_all_offers_sort_btn";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_PROP1 = "ANDROIDHS_MOP_EXTRAS_SAVE_BADGE";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_MOP = "MOP:";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_PEV1 = "AndroidHS_MOP_Extras_Save Badge";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_NEARBY_LOC_PROP1 = "ANDROIDHS_MOP_DETAILS_COUPON_NEARBY_LOC_BTN";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_NEARBY_LOC_PE = "lnk_o";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_NEARBY_LOC_PEV1 = "AndroidHS_MOP_details_coupon_nearby_loc_btn";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_ADD_TO_CAL_PROP1 = "ANDROIDHS_MOP_DETAILS_COUPON_ADD_TO_CAL_BTN";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_ADD_TO_CAL_PE = "lnk_o";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_ADD_TO_CAL_PEV1 = "AndroidHS_MOP_details_coupon_nearby_loc_btn";

    static final String ANDROIDHS_MOP_DETAILS_COUPON_SAVE_PROP1 = "ANDROIDHS_MOP_DETAILS_COUPON_SAVE_BTN";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_SAVE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_SAVE_PEV1 = "AndroidHS_MOP_details_coupon_nearby_loc_btn";

    // MOP1D

    *//* Pagenames *//*
    static final String ANDROIDHS_DEALS_HOME = "ANDROIDHS_Deals_Home_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_NAVFEATURED = "ANDROIDHS_Deals_Home_NavFeatured_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_INSTORE = "ANDROIDHS_Deals_Home_InStore_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_ONLINE = "ANDROIDHS_Deals_Home_Online_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_SEARCH = "ANDROIDHS_Deals_Home_Search_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_EXPLORE = "ANDROIDHS_Deals_Explore_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_EXPLOREALL = "ANDROIDHS_Deals_Explore_All_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_EXPLORECATEGORY = "ANDROIDHS_Deals_Explore_Category_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_THEME = "ANDROIDHS_Deals_Explore_Theme_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_SAVED = "ANDROIDHS_Deals_Explore_Saved_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_SAVEDUNSAVE = "ANDROIDHS_Deals_Explore_Saved_Unsave_Pre-login-pg";
    static final String ANDROIDHS_PRIVACYTERMS = "ANDROIDHS_PrivacyTerms-pg";
    static final String ANDROIDHS_PROVIDEFEEDBACK = "ANDROIDHS_ProvideFeedback-pg";
    static final String ANDROIDHS_DEALS_HOME_DETAIL = "ANDROIDHS_Deals_Detail_Pre-login-pg";

    *//**
     * start :slende : 14.7 MOP Tibco / UI Updates - Deal Detail View
     * Enhancements
     *//*
    static final String ANDROIDHS_DEALS_DETAIL_REDEEMSWIPE_PAGE = "ANDROIDHS_Deals_Detail_RedeemSwipe_";
    static final String EVAR35_DEALS_DETAIL_REDEEMSWIPE = "DealsDetail:RedeemSwipe";
    */
    /**
     * end :slende : 14.7 MOP Tibco / UI Updates - Deal Detail View Enhancements
     *//*

    static final String EVAR65_DEALSHOME_DEFAULT_ALL = "Pre-login:DealsHome:Default:All";
    static final String EVAR65_DEALSHOME_DEFAULT_ALL_SORT = "Pre-login:DealsHome:Default:All:Sort-";
    static final String EVAR65_DEALSHOME_DEFAULT_NAVIGATEFEATURED = "Pre-login:DealsHome:Default:NavigateFeatured";
    static final String EVAR65_DEALSHOME_INSTORE = "Pre-login:DealsHome:In-Store";
    static final String EVAR65_DEALSHOME_INSTORE_SORT = "Pre-login:DealsHome:In-Store:Sort-";
    static final String EVAR65_DEALSHOME_ONLINE = "Pre-login:DealsHome:Online";
    static final String EVAR65_DEALSHOME_ONLINE_SORT = "Pre-login:DealsHome:Online:Sort-";
    static final String EVAR65_DEALSHOME_SEARCH = "Pre-login:DealsHome:Search:";
    static final String EVAR65_DEALSEXPLORE_ALL = "Pre-login:DealsExplore:All";
    static final String EVAR65_DEALSEXPLORE_CATEGORY = "Pre-login:DealsExplore:Category:";
    static final String EVAR65_DEALSEXPLORE_THEME = "Pre-login:DealsExplore:Theme:";
    static final String EVAR65_DEALSEXPLORE_SAVED = "Pre-login:DealsExplore:Saved";

    static final String EVENT79 = "event79";

    *//*
     * static final String EVAR35_DISCOVERDEALS_PRIVACYTERMS=
     * "Pre-login:DiscoverDeals:PrivacyTerms"; static final String
     * EVAR35_DISCOVERDEALS_PROVIDEFEEDBACK=
     * "Pre-login:DiscoverDeals:ProvideFeedback";
     *//*

    // MOP1D*/

    // OOB
    static final String ANDROID_OOB_TECH_DIFF_18003472683_TXT_PROP1 = "ANDROID_OOB_TECH_DIFF_18003472683_TXT";
    static final String ANDROID_OOB_PE = "lnk_o";
    static final String ANDROID_OOB_TECH_DIFF_18003472683_TXT_PEV1 = "ANDROID_OOB_TECH_DIFF_18003472683_TXT";

    // Whats new reminder
    static final String WHATS_NEW_REMINDER_PASSCODE_OVERLAY = "Passcode_WhatsNew-pg-Overlay";
    static final String WHATS_NEW_REMINDER_QUICKVIEW_OVERLAY = "Quickview_WhatsNew-pg-Overlay";
    static final String WHATS_NEW_REMINDER_CLI = "AndroidHS_CLI_Reminder-pg";
    static final String WHATS_NEW_REMINDER_FINGERPRINT = "Fingerprint_Reminder-pg";


    /** start : slende : 14.7 What's New Reminder CLI changes */
    static final String WHATS_NEW_REMINDER_CLI_REQUEST_PROP1 = "ANDROIDHS_REMINDER_CLI_REQUEST_BTN";
    static final String WHATS_NEW_REMINDER_CLI_REQUEST_PEV1 = "ANDROIDHS_REMINDER_CLI_REQUEST_BTN";

    static final String WHATS_NEW_REMINDER_NO_THANKS_CLI_PROP1 = "ANDROIDHS_REMINDER_CLI_NOTHANKS_BTN";
    static final String WHATS_NEW_REMINDER_NO_THANKS_CLI_PEV1 = "ANDROIDHS_REMINDER_CLI_NOTHANKS_BTN";

    static final String WHATS_NEW_REMINDER_REMINDER_ME_LATER_CLI_PROP1 = "ANDROIDHS_REMINDER_CLI_LATER_BTN";
    static final String WHATS_NEW_REMINDER_REMINDER_ME_LATER_CLI_PEV1 = "ANDROIDHS_REMINDER_CLI_LATER_BTN";
    /** end : slende : 14.7 What's New Reminder CLI changes */

    static final String WHATS_NEW_REMINDER_SET_UP_PASSCODE_PROP1 = "PASSCODE_WHATS_NEW_SETUP_PASC_BTN";
    static final String WHATS_NEW_REMINDER_PE = "lnk_o";
    static final String WHATS_NEW_REMINDER_SET_UP_PASSCODE_PEV1 = "passcode_whats_new_setup_pasc_btn";
    static final String WHATS_NEW_REMINDER_NO_THANKS_PASSCODE_PROP1 = "PASSCODE_WHATS_NEW_NO_THANKS_TXT";
    static final String WHATS_NEW_REMINDER_NO_THANKS_PASSCODE_PEV1 = "passcode_whats_new_no_thanks_txt";
    static final String WHATS_NEW_REMINDER_REMINDER_ME_LATER_PASSCODE_PROP1 = "PASSCODE_WHATS_NEW_REMIND_LATER_TXT";
    static final String WHATS_NEW_REMINDER_REMINDER_ME_LATER_PASSCODE_PEV1 = "passcode_whats_new_remind_later_txt";

    static final String WHATS_NEW_REMINDER_SET_UP_QUICKVIEW_PROP1 = "QUICKVIEW_WHATS_NEW_ENABLE_QUICKVIEW_BTN";
    static final String WHATS_NEW_REMINDER_SET_UP_QUICKVIEW_PEV1 = "quickview_whats_new_enable_quickview_btn";
    static final String WHATS_NEW_REMINDER_NO_THANKS_QUICKVIEW_PROP1 = "QUICKVIEW_WHATS_NEW_NO_THANKS_TXT";
    static final String WHATS_NEW_REMINDER_NO_THANKS_QUICKVIEW_PEV1 = "quickview_whats_new_no_thanks_txt";
    static final String WHATS_NEW_REMINDER_REMINDER_ME_LATER_QUICKVIEW_PROP1 = "QUICKVIEW_WHATS_NEW_REMIND_LATER_TXT";
    static final String WHATS_NEW_REMINDER_REMINDER_ME_LATER_QUICKVIEW_PEV1 = "quickview_whats_new_remind_later_txt";
    static final String WHATS_NEW_FICO = "AndroidHS_FICOCreditScore_WhatsNew";

    static final String TEMP_PASS_SUCCESSFUL_PASSWORD_RESET = "Successful_Password_Reset_Pg-Overlay";
    static final String TEMP_PASS_ERROR = "Temp_Password_Error_Pg-Overlay";
    static final String TEMP_PASS_RESET_BUTTON = "ANDROID_TEMP_PASS_RESET_SUBMIT_BTN";
    static final String TEMP_PASS_RESET_BUTTON_pev1 = "Android_temp_pass_reset_submit_btn";

    // E-Sign Page

    static final String ESIGN_TERMS_AND_COND_PAGE = "AndroidHS_TermsConditions_Esign-pg";
    static final String TERMS_AND_COND_PAGE = "AndroidHS_TermsConditions-pg";
    static final String ESIGN_ERROR_PAGE = "AndroidHS_Terms_Conditions_We're_Sorry-pg-Overlay";
    static final String ANDROIDHS_TERMS_CONDS_ESIGN_DECLINE_TXT_prop1 = "ANDROIDHS_TERMS_CONDS_ESIGN_DECLINE_TXT";
    static final String ANDROIDHS_TERMS_CONDS_ESIGN_DECLINE_TXT_pe = "lnk_o";
    static final String ANDROIDHS_TERMS_CONDS_ESIGN_DECLINE_TXT_pev1 = "ANDROIDHS_TERMS_CONDS_ESIGN_DECLINE_TXT";

    // Alert Badge Overlay

    static final String VIEW_ALERTS_OVERLAY_PAGE = "ViewAlerts_NewAlertsPendingView_Overlay";

    static final String ALERTS_OVERLAY_COUNT_OF_CLICKS_ON_ALERTSBELL_prop1 = "NoUnreadAlerts_AlertBell_Btn";
    static final String ALERTS_OVERLAY_COUNT_OF_CLICKS_ON_ALERTSBELL_pe = "lnk_o";
    static final String ALERTS_OVERLAY_COUNT_OF_CLICKS_ON_ALERTSBELL_pev1 = "NoUnreadAlerts AlertBell Button";

    static final String ALERTS_OVERLAY_COUNT_OF_UNREAD_ALERTS_ON_ALERTSBELL_prop1 = "UnreadAlerts_AlertBell_Btn";
    static final String ALERTS_OVERLAY_COUNT_OF_UNREAD_ALERTS_ON_ALERTSBELL_pe = "lnk_o";
    static final String ALERTS_OVERLAY_COUNT_OF_UNREAD_ALERTS_ON_ALERTSBELL_pev1 = "UnreadAlerts AlertBell Button";

    static final String ALERTS_OVERLAY_COUNT_OF_UNOPENED_ALERTS_ONOVERLAY_prop1 = "UnOpenedAlerts_OrangeDot_Btn";
    static final String ALERTS_OVERLAY_COUNT_OF_UNOPENED_ALERTS_ONOVERLAY_pe = "lnk_o";
    static final String ALERTS_OVERLAY_COUNT_OF_UNOPENED_ALERTS_ONOVERLAY_pev1 = "UnOpenedAlerts Orangedot Button";

    static final String ALERTS_OVERLAY_COUNT_OF_OPENED_ALERTS_ONOVERLAY_prop1 = "OpenedAlerts_NoOrangeDot_Btn";
    static final String ALERTS_OVERLAY_COUNT_OF_OPENED_ALERTS_ONOVERLAY_pe = "lnk_o";
    static final String ALERTS_OVERLAY_COUNT_OF_OPENED_ALERTS_ONOVERLAY_pev1 = "OpenedAlerts NoOrgangeDots Button";

    // Highlighted features
    static final String HF_CUSTOMER_SERVICE_CLICK = "ANDROIDHS_LOGIN_FTR_CUST_SER_BTN";
    static final String HF_CS_MENU_CLICK = "ANDROIDHS_CUST_SER_LOGOUT_HIGHLIGHT_TXT";
    static final String HF_PRELOGIN = "ANDROIDHS_Pre-login";
    static final String HF_POSTLOGIN = "ANDROIDHS_Post-login";
    static final String HF_ERROR = "AndroidHS_HighlightFeature_ErrorOverlay-pg";

    // Transactions Map Page
    static final String TRANSACTION_MAP_VIEW = "AndroidHS_MerchantMapView";

    // FICO Credit Score

    static final String FICO_CREDIT_SCORE_prop1 = "AndroidHS_ACCT_SUMM_FICO_CREDIT_SCORE_BTN";
    static final String FICO_CREDIT_SCORE_pe = "lnk_o";
    static final String FICO_CREDIT_SCORE_pev1 = "AndroidHS_ACCT_SUMM_FICO_CREDIT_SCORE_BTN";

    // SMC

    static final String SMC_LIST_OF_MESSAGES = "Message_List_View-pg";
    static final String SMC_INBOX = "Secure_Message_Center_Inbox-pg";
    static final String SMC_SENT = "Secure_Message_Center_Sent-pg";
    static final String SMC_MESSAGE_DELETED = "Secure_Message_Center_Message_Deleted-pg";
    static final String SMC_NO_MESSAGES = "Secure_Message_Center_Inbox_No_Messages-pg";
    static final String SMC_READ_MESSAGE = "Message_Detail_View-pg";
    static final String SMC_REPLY_TO_MESSAGE = "Reply_To_Message-pg";
    static final String SMC_NEW_MESSAGE_1 = "New_Message_Step1-pg";
    static final String SMC_NEW_MESSAGE_1_ERROR_CONTENT = "New_Message_Step1-pg";
    static final String SMC_NEW_MESSAGE_2 = "New_Message_Step2-pg";
    static final String SMC_NEW_MESSAGE_1_ERROR = "New_Message_Step1-pg";
    static final String SMC_SENT_MODAL = "Your_Message_Has_Been_Sent_Modal-pg-Overlay";
    static final String SMC_DELETE_MODAL = "Delete_Your_Message?_Modal-pg-Overlay";
    static final String SMC_BILLING_RIGHTS_MODAL = "Your_Billing_Rights_modal-pg-Overlay";
    static final String SMC_PDF_MESSAGE_HERE_TXT = "SMC_PDF_MESSAGE_HERE_TXT";
    static final String SMC_PDF_MESSAGE_HERE_TXT_pe = "lnk_o";

    static final String TAKEATOUR_HELLOPAGE = "MakePayment_Hello-pg";
    static final String TAKEATOUR_STEP1 = "MakePayment_Step1_SelectAmount-pg";
    static final String TAKEATOUR_STEP2 = "MakePayment_Step2_SelectBankDate-pg";
    static final String TAKEATOUR_STEP3 = "MakePayment_Step3_VerifyPayment-pg";
    static final String TAKEATOUR_STEP4 = "MakePayment_Step4_AllDone-pg";

    static final String SMC_ALERTS_SMC_LINK_prop1 = "ALERTS_BOX_SMC_TXT";
    static final String SMC_ALERTS_SMC_LINK_pe = "lnk_o";
    static final String SMC_ALERTS_SMC_LINK_pev1 = "ALERTS_BOX_SMC_TXT";

    static final String SMC_CONTACT_US_SMC_LINK_prop1 = "CONTACTUS_ONLINE_SMC_TXT";
    static final String SMC_CONTACT_US_SMC_LINK_pe = "lnk_o";
    static final String SMC_CONTACT_US_SMC_LINK_pev1 = "CONTACTUS_ONLINE_SMC_TXT";

    static final String SMC_INBOX_DELETE_prop1 = "SMC_INBOX_DELETE_TXT";
    static final String SMC_INBOX_DELETE_pe = "lnk_o";
    static final String SMC_INBOX_DELETE_pev1 = "SMC_INBOX_DELETE_TXT";

    static final String SMC_DETAIL_DELETE_prop1 = "SMC_DETAIL_DELETE_TXT";
    static final String SMC_DETAIL_DELETE_pe = "lnk_o";
    static final String SMC_DETAIL_DELETE_pev1 = "SMC_DETAIL_DELETE_TXT";

    public static final String SMC_DETAIL_DELETE_BTN_prop1 = "SMC_DELETE_DETAIL_BTN";
    public static final String SMC_DETAIL_DELETE_BTN_pe = "lnk_o";
    public static final String SMC_DETAIL_DELETE_BTN_pev1 = "SMC_DELETE_DETAIL_BTN";

    public static final String SMC_DETAIL_REPLY_BTN_prop1 = "SMC_DETAIL_REPLY_BTN";
    public static final String SMC_DETAIL_REPLY_BTN_pe = "lnk_o";
    public static final String SMC_DETAIL_REPLY_BTN_pev1 = "SMC_DETAIL_REPLY_BTN";

    public static final String SMC_DETAIL_LEFT_BTN_prop1 = "SMC_DETAIL_LEFT_BTN";
    public static final String SMC_DETAIL_LEFT_BTN_pe = "lnk_o";
    public static final String SMC_DETAIL_LEFT_BTN_pev1 = "SMC_DETAIL_LEFT_BTN";

    public static final String SMC_DETAIL_RIGHT_BTN_prop1 = "SMC_DETAIL_RIGHT_BTN";
    public static final String SMC_DETAIL_RIGHT_BTN_pe = "lnk_o";
    public static final String SMC_DETAIL_RIGHT_BTN_pev1 = "SMC_DETAIL_RIGHT_BTN";

    public static final String SMC_REPLY_SENT_BTN_prop1 = "SMC_REPLY_SENT_BTN";
    public static final String SMC_REPLY_SENT_BTN_pe = "lnk_o";
    public static final String SMC_REPLY_SENT_BTN_pev1 = "SMC_REPLY_SENT_BTN";

    public static final String SMC_REPLY_CANCEL_BTN_prop1 = "SMC_REPLY_CANCEL_BTN";
    public static final String SMC_REPLY_CANCEL_BTN_pe = "lnk_o";
    public static final String SMC_REPLY_CANCEL_BTN_pev1 = "SMC_REPLY_CANCEL_BTN";

    public static final String SMC_NEW1_FAQ_TXT_prop1 = "SMC_NEW1_FAQ_TXT";
    public static final String SMC_NEW1_FAQ_TXT_pe = "lnk_o";
    public static final String SMC_NEW1_FAQ_TXT_pev1 = "SMC_NEW1_FAQ_TXT";

    public static final String SMC_NEW1_CONTINUE_TXT_prop1 = "SMC_NEW1_CONTINUE_TXT";
    public static final String SMC_NEW1_CONTINUE_TXT_pe = "lnk_o";
    public static final String SMC_NEW1_CONTINUE_TXT_pev1 = "SMC_NEW1_CONTINUE_TXT";

    public static final String SMC_NEW1_CANCEL_TXT_prop1 = "SMC_NEW1_CANCEL_TXT";
    public static final String SMC_NEW1_CANCEL_TXT_pe = "lnk_o";
    public static final String SMC_NEW1_CANCEL_TXT_pev1 = "SMC_NEW1_CANCEL_TXT";

    public static final String SMC_NEW2_SEND_TXT_prop1 = "SMC_NEW2_SEND_TXT";
    public static final String SMC_NEW2_SEND_TXT_pe = "lnk_o";
    public static final String SMC_NEW2_SEND_TXT_pev1 = "SMC_NEW2_SEND_TXT";

    public static final String SMC_NEW2_CANCEL_TXT_prop1 = "SMC_NEW2_CANCEL_TXT";
    public static final String SMC_NEW2_CANCEL_TXT_pe = "lnk_o";
    public static final String SMC_NEW2_CANCEL_TXT_pev1 = "SMC_NEW2_CANCEL_TXT";

    public static final String SMC_SENT_INBOX_BTN_prop1 = "SMC_SENT_INBOX_BTN";
    public static final String SMC_SENT_INBOX_BTN_pe = "lnk_o";
    public static final String SMC_SENT_INBOX_BTN_pev1 = "SMC_SENT_INBOX_BTN";

    public static final String SMC_SENT_NEWMSG_BTN_prop1 = "SMC_SENT_NEWMSG_BTN";
    public static final String SMC_SENT_NEWMSG_BTN_pe = "lnk_o";
    public static final String SMC_SENT_NEWMSG_BTN_pev1 = "SMC_SENT_NEWMSG_BTN";

    public static final String SMC_DELETE_YES_BTN_prop1 = "SMC_DELETE_YES_BTN";
    public static final String SMC_DELETE_YES_BTN_pe = "lnk_o";
    public static final String SMC_DELETE_YES_BTN_pev1 = "SMC_DELETE_YES_BTN";

    // start 15.1 Balance Transfer

    public static final String BT_ADD_ACCOUNT_MODAL = "BT_Add_Account_Modal-pg-Overlay";
    public static final String BT_INTEREST_MODAL_VERSION_A = "BT_And_Interest_Modal_VersionA-pg-Overlay";
    public static final String BT_INTEREST_MODAL_VERSION_B = "BT_And_Interest_Modal_VersionB-pg-Overlay";
    public static final String BT_NO_OFFERS_AVAILABLE = "BT_No_Offers_Available-pg";

    public static final String BT_CALCULATE_SAVINGS_prop1 = "BT_OFFER_LIST_CALCULATE_SAVINGS_BTN";
    public static final String BT_CALCULATE_SAVINGS_pe = "lnk_o";
    public static final String BT_CALCULATE_SAVINGS_pev1 = "BT_OFFER_LIST_CALCULATE_SAVINGS_BTN";

    public static final String BT_NORMAL_OFFER_prop1 = "BT_OFFER_LIST_NORMAL_OFFER_TXT";
    public static final String BT_NORMAL_OFFER_pe = "lnk_o";
    public static final String BT_NORMAL_OFFER_pev1 = "BT_OFFER_LIST_NORMAL_OFFER_TXT";

    // Learn more
    public static final String BT_OFFER_DETAILS_LEARN_MORE_prop1 = "BT_OFFER_DETAILS_LEARN_MORE_TXT";
    public static final String BT_OFFER_DETAILS_LEARN_MORE_pev1 = "BT_OFFER_DETAILS_LEARN_MORE_TXT";

    // CLI Model


//    BT Redesign Analytics Tags:

//    Page Tags:

    public static final String BT_Intro_Popup_page_Overlay = "BT_Intro_Popup-pg-Overlay";
    public static final String BT_No_Offers_Available_page = "BT_No_Offers_Available-pg";
    public static final String BT_NoElig_Offers_page = "BT_NoElig_Offers-pg";
    public static final String BT_Offer = "BT_Offer_List_View-pg";
    public static final String BT_Calculator_page = "BT_Calculator-pg";
    public static final String BT_Calculator_Refresh_page = "BT_Calculator_Refresh-pg";
    public static final String BT_Step1_Enter_Account_Information_page = "BT_Step1_Enter_Account_Information-pg";

    public static final String BT_Step1a_PayCreditor_page = "BT_Step1a_PayCreditor-pg";
    public static final String BT_Step1a_ScanCardStart_page = "BT_Step1a_ScanCardStart-pg";
    public static final String BT_Step1a_ScanCardStart_AllowCamera_page = "BT_Step1a_ScanCardStart_AllowCamera-pg";
    public static final String BT_Step1a_ScanCardComplete_page = "BT_Step1a_ScanCardComplete-pg";
    public static final String BT_Step1a_CreditorNotRecognized_page = "BT_Step1a_CreditorNotRecognized-pg";
    public static final String BT_Step1a_CreditorMultiMatch_page = "BT_Step1a_CreditorMultiMatch-pg";
    public static final String BT_Step1a_TransferChk_page = "BT_Step1a_TransferChk-pg";
    public static final String BT_Step1a_TransferChk_Modal_page = "BT_Step1a_TransferChk_Modal-pg";
    public static final String BT_Step2_Review_Transfer_Information_page = "BT_Step2_Review_Transfer_Information-pg";
    public static final String BT_Remove_PayCreditor_Multiple_Modal_page = "BT_Remove_PayCreditor_Multiple_Modal-pg";
    public static final String BT_Step3_Esign_page = "BT_Step3_Esign-pg";
    public static final String BT_Step3_Terms_page = "BT_Step3_Terms-pg";
    public static final String BT_Cancel_Confirmation_OL_page = "BT_Cancel_Confirmation_OL-pg";
    public static final String BT_Confirmation_ViewOffer_OL_page = "BT_Confirmation_ViewOffer_OL-pg";
    public static final String BT_Confirmation_AnotherTransfer_OL_page = "BT_Confirmation_AnotherTransfer_OL-pg";
    public static final String BT_Step4_Transfer_Request_Confirmation_page = "BT_Step4_Transfer_Request_Confirmation-pg";

    // Link Tags:
    public static final String BT_INTRO_VIEWOFFERS_BTN = "BT_INTRO_VIEWOFFERS_BTN";
    public static final String BT_INTRO_LEARNMORE_BTN = "BT_INTRO_LEARNMORE_BTN";
    public static final String BT_OFFER_LIST_SEEHOW_TXT = "BT_OFFER_LIST_SEEHOW_TXT";
    public static final String BT_OFFER_LIST_CALCULATOR_TXT = "BT_OFFER_LIST_CALCULATOR_TXT";
    public static final String BT_OFFER_LIST_FAQ_TXT = "BT_OFFER_LIST_FAQ_TXT";
    public static final String BT_OFFER_LIST_SELECTOFFER_BTN = "BT_OFFER_LIST_SELECTOFFER_BTN";
    public static final String BT_NOOFFER_DWEB_TXT = "BT_NOOFFER_DWEB_TXT";
    public static final String BT_NOOFFER_PHONE_TXT = "BT_NOOFFER_PHONE_TXT";
    public static final String BT_PHONE_TXT = "PHONE_TXT";
    public static final String BT_CALCULATOR_ESTSAV_EXPAND_TXT = "BT_CALCULATOR_ESTSAV_EXPAND_TXT";
    public static final String BT_CALCULATOR_ESTSAV_COLLAPSE_TXT = "BT_CALCULATOR_ESTSAV_COLLAPSE_TXT";
    public static final String BT_CALCULATOR_SELECTOFFER_TXT = "BT_CALCULATOR_SELECTOFFER_TXT";
    public static final String BT_OFFERDETAIL_LEARNMORE_TXT = "BT_OFFERDETAIL_LEARNMORE_TXT";
    public static final String BT_OFFERDETAIL_PAYCREDITOR_TXT = "BT_OFFERDETAIL_PAYCREDITOR_TXT";
    public static final String BT_OFFERDETAIL_CHECKING_TXT = "BT_OFFERDETAIL_CHECKING_TXT";
    public static final String BT_PAYCREDITOR_SCANCC_TXT = "BT_PAYCREDITOR_SCANCC_TXT";
    public static final String BT_PAYCREDITOR_CONTINUE_TXT = "BT_PAYCREDITOR_CONTINUE_TXT";
    public static final String BT_PAYCREDITOR_ADDANOTHER_TXT = "BT_PAYCREDITOR_ADDANOTHER_TXT";
    public static final String BT_SCANCARDSTART_CANCEL_TXT = "BT_SCANCARDSTART_CANCEL_TXT";
    public static final String BT_SCANCARDSTART_ALLOWCAMERA_YES_BTN = "BT_SCANCARDSTART_ALLOWCAMERA_YES_BTN";
    public static final String BT_SCANCARDSTART_ALLOWCAMERA_CLOSE_TXT = "BT_SCANCARDSTART_ALLOWCAMERA_CLOSE_TXT";
    public static final String BT_SCANCARDCOMPLETE_DONE_BTN = "BT_SCANCARDCOMPLETE_DONE_BTN";
    public static final String BT_PAYCREDITOR_RESCANCC_TXT = "BT_PAYCREDITOR_RESCANCC_TXT";
    public static final String BT_CREDITORUNREG_CLOSE_BTN = "BT_CREDITORUNREG_CLOSE_BTN";
    public static final String BT_CREDITORMULTIMATCH_SELECTMANUAL_BTN = "BT_CREDITORMULTIMATCH_SELECTMANUAL_BTN";
    public static final String BT_CREDITORMULTIMATCH_SELECTLIST_BTN = "BT_CREDITORMULTIMATCH_SELECTLIST_BTN";
    public static final String BT_TRANSFERTOCHK_CONTINUE_TXT = "BT_TRANSFERTOCHK_CONTINUE_TXT";
    public static final String BT_REVIEW_EDIT_TXT = "BT_REVIEW_EDIT_TXT";
    public static final String BT_REVIEW_CONTINUE_BTN = "BT_REVIEW_CONTINUE_BTN";
    public static final String BT_REVIEW_CANCEL_TXT = "BT_REVIEW_CANCEL_TXT";
    public static final String BT_REMOVEPAYCREDITOR_MULTIPLE_YES_BTN = "BT_REMOVEPAYCREDITOR_MULTIPLE_YES_BTN";
    public static final String BT_REMOVEPAYCREDITOR_MULTIPLE_NO_BTN = "BT_REMOVEPAYCREDITOR_MULTIPLE_NO_BTN";
    public static final String BT_ESIGN_AGREE_BTN = "BT_ESIGN_AGREE_BTN";
    public static final String BT_ESIGN_CANCEL_TXT = "BT_ESIGN_CANCEL_TXT";
    public static final String BT_ESIGN_PHONE_TXT = "BT_ESIGN_PHONE_TXT";
    public static final String BT_TERMS_SUBMIT_BTN = "BT_TERMS_SUBMIT_BTN";
    public static final String BT_TERMS_CANCEL_TXT = "BT_TERMS_CANCEL_TXT";
    public static final String BT_CANCELCONFIRM_CANCEL_BTN = "BT_CANCELCONFIRM_CANCEL_BTN";
    public static final String BT_CANCELCONFIRM_DONOTCANCEL_BTN = "BT_CANCELCONFIRM_DONOTCANCEL_BTN";
    public static final String BT_CONFIRMATION_ALERTS_TXT = "BT_CONFIRMATION_ALERTS_TXT";
    public static final String BT_CONFIRMATION_VIEWOFFER_TXT = "BT_CONFIRMATION_VIEWOFFER_TXT";
    public static final String BT_CONFIRMATION_TRANSFERANOTHER_BTN = "BT_CONFIRMATION_TRANSFERANOTHER_BTN";
    public static final String BT_CONFIRMATION_TRANSFERANOTHER_SAMEOFFER_BTN = "BT_CONFIRMATION_TRANSFERANOTHER_SAMEOFFER_BTN";
    public static final String BT_CONFIRMATION_TRANSFERANOTHER_VIEWOFFERS_BTN = "BT_CONFIRMATION_TRANSFERANOTHER_VIEWOFFERS_BTN";
    public static final String BT_CONFIRMATION_PHONE_TXT = "BT_CONFIRMATION_PHONE_TXT";


    // ELF Offer link
    public static final String BT_ELF_OFFER_prop1 = "BT_OFFER_LIST_ELF_OFFER_TXT";
    public static final String BT_ELF_OFFER_pe = "lnk_o";
    public static final String BT_ELF_OFFER_pev1 = "BT_OFFER_LIST_ELF_OFFER_TXT";

    public static final String BT_ADD_ACCOUNT_MODAL_CALCULATE_BUTTON_prop1 = "BT_ADD_ACCOUNT_MODAL_CALCULATE_BTN";
    public static final String BT_ADD_ACCOUNT_MODAL_CALCULATE_BUTTON_pe = "lnk_o";
    public static final String BT_ADD_ACCOUNT_MODAL_CALCULATE_BUTTON_pev1 = "BT_ADD_ACCOUNT_MODAL_CALCULATE_BTN";

    public static final String BT_ADD_ACCOUNT_MODAL_CANCEL_BUTTON_prop1 = "BT_ADD_ACCOUNT_MODAL_CANCEL_BTN";
    public static final String BT_ADD_ACCOUNT_MODAL_CANCEL_BUTTON_pe = "lnk_o";
    public static final String BT_ADD_ACCOUNT_MODAL_CANCEL_BUTTON_pev1 = "BT_ADD_ACCOUNT_MODAL_CANCEL_BTN";

    public static final String BT_OFFER_DETAIL_VIEW_SELECT_OFFER_BUTTON_prop1 = "BT_OFFER_DETAILS_SELECT_OFFER_BTN";
    public static final String BT_OFFER_DETAIL_VIEW_SELECT_OFFER_BUTTON_pe = "lnk_o";
    public static final String BT_OFFER_DETAIL_VIEW_SELECT_OFFER_BUTTON_pev1 = "BT_OFFER_DETAILS_SELECT_OFFER_BTN";

    public static final String BT_OFFER_LIST_PAGE_LOAD = "BT_Offer_List_View-pg";
    public static final String BT_OFFER_LIST_PAGE_WITH_ACCOUNT_INFO_APPLIED = "BT_Offers_Account_Info_Applied-pg";
    public static final String BT_EVENT66 = "event66";

    public static final String BT_OFFER_DETAILS_PAGE_WITH_ACCOUNT_INFO_APPLIED = "BT_Offer_Details_Account_Info_Applied-pg";
    public static final String BT_EVENT22 = "event22";
    public static final String BT_EVENT63 = "event63";
    public static final String BT_EVAR5 = "DiscoverCard:BalanceTransfer";

    public static final String BT_ENTER_ACCOUNT_STEP1 = "BT_Step1_Enter_Account_Information-pg";
    public static final String BT_TERMS_AND_CONDITIONS_EDisclosures = "BT_Step2_Terms_And_Conditions_eDisclosures-pg";
    public static final String BT_TERMS_AND_CONDITIONS_IMPORTANT_INFORMATION = "BT_Step2_Terms_And_Conditions_Imp_Info-pg";
    public static final String BT_VERIFY_REVIEW_TRANSFER_INFORMATION = "BT_Step3_Review_Transfer_Information-pg";

    public static final String BT_ENTER_ACCOUNT_CONTINUE_BUTTON_prop1 = "BT_ENTER_ACC_INF_CONTINUE_BTN";
    public static final String BT_ENTER_ACCOUNT_CONTINUE_BUTTON_pe = "lnk_o";
    public static final String BT_ENTER_ACCOUNT_CONTINUE_BUTTON_pev1 = "BT_ENTER_ACC_INF_CONTINUE_BTN";

    public static final String BT_ENTER_ACCOUNT_ADD_ANOTHER_ACCOUNT_BUTTON_prop1 = "BT_ENTER_ACC_INF_ADD_ANOTHER_ACCOUNT_BTN";
    public static final String BT_ENTER_ACCOUNT_ADD_ANOTHER_ACCOUNT_BUTTON_pe = "lnk_o";
    public static final String BT_ENTER_ACCOUNT_ADD_ANOTHER_ACCOUNT_BUTTON_pev1 = "BT_ENTER_ACC_INF_ADD_ANOTHER_ACCOUNT_BTN";

    public static final String BT_ENTER_ACCOUNT_REMOVE_ACCOUNT_BUTTON_prop1 = "BT_EDIT_ACCOUNT_INFO_REMOVE_ACCOUNT_BTN";
    public static final String BT_ENTER_ACCOUNT_REMOVE_ACCOUNT_BUTTON_pe = "lnk_o";
    public static final String BT_ENTER_ACCOUNT_REMOVE_ACCOUNT_BUTTON_pev1 = "BT_EDIT_ACCOUNT_INFO_REMOVE_ACCOUNT_BTN";

    public static final String BT_TERMS_AND_CONDITION_AGREE_BUTTON_prop1 = "BT_TERMS_AND_CONDITIONS_AGREE_BTN";
    public static final String BT_TERMS_AND_CONDITION_AGREE_BUTTON_pe = "lnk_o";
    public static final String BT_TERMS_AND_CONDITION_AGREE_BUTTON_pev1 = "BT_TERMS_AND_CONDITIONS_AGREE_BTN";

    public static final String BT_VERIFY_CONFIRM_BUTTON_prop1 = "BT_REVIEW_TRANSFER_INFO_CONFIRM_BTN";
    public static final String BT_VERIFY_CONFIRM_BUTTON_pe = "lnk_o";
    public static final String BT_VERIFY_CONFIRM_BUTTON_pev1 = "BT_REVIEW_TRANSFER_INFO_CONFIRM_BTN";

    public static final String BT_CONFIRMATION_MANAGE_ALERTS_BUTTON_prop1 = "BT_TRANSFER_REQ_CONFIRM_MANAGE_ALERTS_BTN";
    public static final String BT_CONFIRMATION_MANAGE_ALERTS_BUTTON_pe = "lnk_o";
    public static final String BT_CONFIRMATION_MANAGE_ALERTS_BUTTON_pev1 = "BT_TRANSFER_REQ_CONFIRM_MANAGE_ALERTS_BTN";

    // end 15.1 Balance Transfer

    // Start 15.2 Balance Transfer
    public static final String BT_MONTHLY_PAYMENT_ESTIMATOR = "BT_Monthly_Payment_Estimator-pg";
    public static final String BT_PAYDOWN_SCHEDULE_OVERLAY = "BT_Pay_Down_Schedule_Modal-pg-Overlay";
    public static final String BT_DETAILS_MODAL_OVERLAY = "BT_Details_Modal-pg-Overlay";
    public static final String BT_ABOUT_SCREEN_1 = "BT_About_BT_Can_Help_You-pg";
    public static final String BT_ABOUT_SCREEN_2 = "BT_About_Step1_View_Offers-pg";
    public static final String BT_ABOUT_SCREEN_3 = "BT_About_Step2_Submit_Your_Transfer-pg";
    public static final String BT_ABOUT_SCREEN_4 = "BT_About_Step3_Enjoy_Your_Savings-pg";
    public static final String BT_TRANSFER_LIST = "BT_Transfer_List_View-pg";
    public static final String BT_TRANSFER_DETAIL = "BT_Transfer_Detail_View-pg";

    public static final String BT_TAB_OFFER_BUTTON_prop1 = "BT_TAB_BAR_OFFERS_BTN";
    public static final String BT_TAB_OFFER_BUTTON_pe = "lnk_o";
    public static final String BT_TAB_OFFER_BUTTON_pev1 = "BT_TAB_BAR_OFFERS_BTN";

    public static final String BT_TAB_ABOUT_BUTTON_prop1 = "BT_TAB_BAR_ABOUT_BTN";
    public static final String BT_TAB_ABOUT_BUTTON_pe = "lnk_o";
    public static final String BT_TAB_ABOUT_BUTTON_pev1 = "BT_TAB_BAR_ABOUT_BTN";

    public static final String BT_TAB_TRANSFER_BUTTON_prop1 = "BT_TAB_BAR_TRANSFERS_BTN";
    public static final String BT_TAB_TRANSFER_BUTTON_pe = "lnk_o";
    public static final String BT_TAB_TRANSFER_BUTTON_pev1 = "BT_TAB_BAR_TRANSFERS_BTN";

    public static final String BT_OFFER_DETAIL_X_BUTTON_prop1 = "BT_OFFER_DETAILS_X_BTN";
    public static final String BT_OFFER_DETAIL_X_BUTTON_pe = "lnk_o";
    public static final String BT_OFFER_DETAIL_X_BUTTON_pev1 = "BT_OFFER_DETAILS_X_BTN";

    public static final String BT_OFFER_DETAIL_MONTHLY_PAYMENT_LINK_TXT_prop1 = "BT_OFFER_DETAILS_MONTHLY_PAYMENT_EST_TXT";
    public static final String BT_OFFER_DETAIL_MONTHLY_PAYMENT_LINK_TXT_pe = "lnk_o";
    public static final String BT_OFFER_DETAIL_MONTHLY_PAYMENT_LINK_TXT_pev1 = "BT_OFFER_DETAILS_MONTHLY_PAYMENT_EST_TXT";

    public static final String BT_MONTHLY_PAYMENT_LEARN_MORE_TXT_prop1 = "BT_MNTHY_PAYMENT_EST_LEARN_MORE_TXT";
    public static final String BT_MONTHLY_PAYMENT_LEARN_MORE_TXT_pe = "lnk_o";
    public static final String BT_MONTHLY_PAYMENT_LEARN_MORE_TXT_pev1 = "BT_MNTHY_PAYMENT_EST_LEARN_MORE_TXT";

    public static final String BT_MONTHLY_PAYMENT_XX_MONTH_TXT_prop1 = "BT_MNTHY_PAYMENT_EST_XX_MONTHS_TXT";
    public static final String BT_MONTHLY_PAYMENT_XX_MONTH_TXT_pe = "lnk_o";
    public static final String BT_MONTHLY_PAYMENT_XX_MONTH_TXT_pev1 = "BT_MNTHY_PAYMENT_EST_XX_MONTHS_TXT";

    public static final String BT_MONTHLY_PAYMENT_MOVING_SLIDER_prop1 = "BT_MNTHY_PAYMENT_EST_MOVING_SLIDER";
    public static final String BT_MONTHLY_PAYMENT_MOVING_SLIDER_pe = "lnk_o";
    public static final String BT_MONTHLY_PAYMENT_MOVING_SLIDER_pev1 = "BT_MNTHY_PAYMENT_EST_MOVING_SLIDER";

    public static final String BT_MONTHLY_PAYMENT_MOVING_GRAPH_prop1 = "BT_MNTHY_PAYMENT_EST_MOVING_GRAPH";
    public static final String BT_MONTHLY_PAYMENT_MOVING_GRAPH_pe = "lnk_o";
    public static final String BT_MONTHLY_PAYMENT_MOVING_GRAPH_pev1 = "BT_MNTHY_PAYMENT_EST_MOVING_GRAPH";

    public static final String BT_TRANSFER_DETAIL_ADD_CALENDER_TXT_prop1 = "BT_TRANSFER_DETAIL_ADD_TO_CALENDAR_TXT";
    public static final String BT_TRANSFER_DETAIL_ADD_CALENDER_TXT_pe = "lnk_o";
    public static final String BT_TRANSFER_DETAIL_ADD_CALENDER_TXT_pev1 = "BT_TRANSFER_DETAIL_ADD_TO_CALENDAR_TXT";

    // end 15.2 15.2 Balance Transfer

    // start 15.2 Site Cat Tags Discover Reporter

    public static final String REPORTER_REFER_MERCHANT = "Reporter_Refer_Merchant-pg";
    public static final String REPORTER_PHYSICAL_LOCATION_MAP_VIEW = "Reporter_Physical_Location_Map_View-pg";
    public static final String REPORTER_PHYSICAL_LOCATION_LIST_VIEW = "Reporter_Physical_Location_List_View-pg";
    public static final String REPORTER_PHYSICAL_DETAILS_PREPOPULATED = "Reporter_Physical_Details_Prepopulated-pg";
    public static final String REPORTER_MERCHANT_SUCCESS_MODAL_OVERLAY = "Reporter_Merchant_Success_Modal-pg-Overlay";
    public static final String REPORTER_ONLINE_MERCHANT_DETAILS = "Reporter_Online_Merchant_Details-pg";
    public static final String REPORTER_PHYSICAL_MERCHANT_DETAILS = "Reporter_Physical_Merchant_Details-pg";

    public static final String REPORTER_REFER_PHYSICAL_LOCATION_prop1 = "REPORTER_REFER_PHYSICAL_LOCATION_TXT";
    public static final String REPORTER_REFER_PHYSICAL_LOCATION_pe = "lnk_o";
    public static final String REPORTER_REFER_PHYSICAL_LOCATION_pev1 = "REPORTER_REFER_PHYSICAL_LOCATION_TXT";

    public static final String REPORTER_REFER_ONLINE_MERCHANT_prop1 = "REPORTER_REFER_ONLINE_MERCHANT_TXT";
    public static final String REPORTER_REFER_ONLINE_MERCHANT_pe = "lnk_o";
    public static final String REPORTER_REFER_ONLINE_MERCHANT_pev1 = "REPORTER_REFER_ONLINE_MERCHANT_TXT";

    public static final String REPORTER_MERCHANT_NOT_FOUND_prop1 = "REPORTER_MERCHANT_NOT_FOUND_TXT";
    public static final String REPORTER_MERCHANT_NOT_FOUND_pe = "lnk_o";
    public static final String REPORTER_MERCHANT_NOT_FOUND_pev1 = "REPORTER_MERCHANT_NOT_FOUND_TXT";
    // end 15.2 Site Cat Tags Discover Reporter

    // start 15.2 Freeze Account Tags
    //  public static final String ACCOUNT_FROZEN_MESSAGE_MODAL = "AndroidHS_Account_Frozen_Message_Modal-pg-Overlay";

    // Android Wear Analytics Usage Tag
    public static final String ANDROID_WEAR_QUICKVIEW_SUCCESS = "AndroidWEAR_QUICKVIEW_SUCCESS";
    public static final String ANDROID_WEAR_QUICKVIEW_FAIL = "AndroidWEAR_QUICKVIEW_FAIL";

    // CLI Modal
    public static final String CLI_MODEL = "BT_About_Temporay_CLI_Offers-pg-Overlay";

    // Live Chat Analytics
    public static final String LIVE_CHAT_OVERLAY = "Live_Chat_Overlay-pg";
    public static final String LIVE_CHAT_NOW = "LIVE_CHAT_NOW_LINK";

    // US20350 : sshar13 :- version number analytics
    public static final String VERSION_CLICKED_LOGIN_SCREEN_prop1 = "LOGIN_VERSION_NBR_TXT";
    public static final String VERSION_CLICKED_LOGIN_SCREEN_pe = "lnk_o";
    public static final String VERSION_CLICKED_LOGIN_SCREEN_pev1 = "LOGIN_VERSION_NBR_TXT";

    public static final String VERSION_CLICKED_NAVIGATION_DRAWER_prop1 = "LHN_VERSION_NBR_TXT";
    public static final String VERSION_CLICKED_NAVIGATION_DRAWER_pe = "lnk_o";
    public static final String VERSION_CLICKED_NAVIGATION_DRAWER_pev1 = "LHN_VERSION_NBR_TXT";

    public static final String VERSION_UPDATE_CLICKED_prop1 = "VERSION_INFO_UPDATE_APP_BTN";
    public static final String VERSION_UPDATE_CLICKED_pe = "lnk_o";
    public static final String VERSION_UPDATE_CLICKED_pev1 = "VERSION_INFO_UPDATE_APP_BTN";

    public static final String VERSION_NOUPDATE_HIGHLIGHT_FEATURE_CLICKED_prop1 = "VERSION_INFO_NOUPDATE_HL_TXT";
    public static final String VERSION_NOUPDATE_HIGHLIGHT_FEATURE_pe = "lnk_o";
    public static final String VERSION_NOUPDATE_HIGHLIGHT_FEATURE_pev1 = "VERSION_INFO_NOUPDATE_HL_TXT";

    public static final String VERSION_INFORMATION_UPDATE_AVAILABLE_PAGE = "Version_Info_Update_Avail-pg";
    public static final String VERSION_INFORMATION_NO_UPDATE_AVAILABLE_PAGE = "Version_Info_NoUpdate_Avail-pg";

    // Profile & Settings Analytics
    public static final String PROFILE_SETTINGS_TAB = "null";

    public static final String QUICK_VIEW_WIDGET_MENU_ITEM_prop1 = "LHN_PROFILE_SETTING_QVIEW_WIDGET_BTN";
    public static final String QUICK_VIEW_WIDGET_MENU_ITEM_pe = "lnk_o";
    public static final String QUICK_VIEW_WIDGET_MENU_ITEM_pev1 = "LHN_PROFILE_SETTING_QVIEW_WIDGET_BTN";

    public static final String LOCATION_SERVICES_MENU_ITEM_prop1 = "LHN_PROFILE_SETTING_LOC_SERVICES_BTN";
    public static final String LOCATION_SERVICES_MENU_ITEM_pe = "lnk_o";
    public static final String LOCATION_SERVICES_MENU_ITEM_pev1 = "LHN_PROFILE_SETTING_LOC_SERVICES_BTN";

    public static final String PUSH_AND_TEXT_MENU_ITEM_prop1 = "LHN_PROFILE_SETTING_PUSH_TEXT_BTN";
    public static final String PUSH_AND_TEXT_MENU_ITEM_pe = "lnk_o";
    public static final String PUSH_AND_TEXT_MENU_ITEM_pev1 = "LHN_PROFILE_SETTING_PUSH_TEXT_BTN";

    public static final String PASSCODE_MENU_ITEM_prop1 = "LHN_PROFILE_SETTING_PASSCODE_BTN";
    public static final String PASSCODE_MENU_ITEM_pe = "lnk_o";
    public static final String PASSCODE_MENU_ITEM_pev1 = "LHN_PROFILE_SETTING_PASSCODE_BTN";

    public static final String CARD_STATUS_MENU_ITEM_prop1 = "LHN_PROFILE_SETTING_CARD_STATUS_BTN";
    public static final String CARD_STATUS_MENU_ITEM_pe = "lnk_o";
    public static final String CARD_STATUS_MENU_ITEM_pev1 = "LHN_PROFILE_SETTING_CARD_STATUS_BTN";

    public static final String CHANGE_PASSWORD_MENU_ITEM_prop1 = "LHN_PROFILE_SETTING_CHANGE_PASSWORD_BTN";
    public static final String CHANGE_PASSWORD_MENU_ITEM_pe = "lnk_o";
    public static final String CHANGE_PASSWORD_MENU_ITEM_pev1 = "LHN_PROFILE_SETTING_CHANGE_PASSWORD_BTN";

    public static final String LOCATION_SERVICE_LANDING = "null";
    public static final String LOCATION_SERVICE_LANDING_PAGE_PAGENAME = "Location_Service-pg";
    public static final String LOCATION_SERVICE_LANDING_PAGE_ON_PROP5 = "Location Service:State:On";
    public static final String LOCATION_SERVICE_LANDING_PAGE_OFF_PROP5 = "Location Service:State:Off";

    public static final String LOCATION_SERVICE_LANDING_TOGGLE_ON = "Location_Service_ToggleOn-pg";

    public static final String LOCATION_SERVICE_LANDING_TOGGLE_OFF = "Location_Service_ToggleOff-pg";

    public static final String QUICKVIEW_WIDGET_LANDING = "null";
    public static final String QUICKVIEW_WIDGET_LANDING_PAGE_PAGENAME = "Quickview_Widget-pg";
    public static final String QUICKVIEW_WIDGET_LANDING_PAGE_ON_PROP5 = "Quickview Widget:State:On";
    public static final String QUICKVIEW_WIDGET_LANDING_PAGE_OFF_PROP5 = "Quickview Widget:State:Off";

    public static final String QUICKVIEW_WIDGET_LANDING_TOGGLE_ON = "Quickview_Widget_ToggleOn-pg";

    public static final String QUICKVIEW_WIDGET_LANDING_TOGGLE_OFF = "Quickview_Widget_ToggleOff-pg";

    // start 15.3 Travel Notification
    public static final String TRAVEL_FLAG_LANDING_PAGE = "TravelNotifiCationDashboard-pg";
    public static final String TRAVEL_FLAG_ADD_TRIPS_PAGE = "TravelAddTrips-pg";
    public static final String TRAVEL_FLAG_SUCCESS_MODAl = "TravelSuccessModal-pg";
    public static final String TRAVEL_FLAG_TRIP_DETAILS_PAGE = "TravelTripDetails-pg";
    public static final String TRAVEL_FLAG_EDIT_TRIP_DEATILS_PAGE = "TravelEditDetails-pg";
    public static final String TRAVEL_FLAG_DELETE_CONFIRMATION_MODAL = "TravelNotificationDashboardDeleteConfirmation-pg";

    // Manage Cards Analytics
    public static final String MANAGE_CARD_ACTIVATE_CARD_PAGE = "ActivateCard_CardActiveModel_pg-overlay";
    public static final String MANAGE_CARD_REPLACE_CARD_STEP_ONE_PROP1 = "REPLACE_CARD_STEP1_BTN";
    public static final String MANAGE_CARD_REPLACE_CARD_STEP_ONE_PEV1 = "REPLACE_CARD_STEP1_BTN";
    public static final String MANAGE_CARD_REPLACE_CARD_LANDING_PAGE = "Replace_Card_Landing-pg";
    public static final String MANAGE_CARD_REPLACE_CARD_STEP_TWO_PROP1 = "REPLACE_CARD_STEP2_BTN";
    public static final String MANAGE_CARD_REPLACE_CARD_STEP_TWO_PEV1 = "REPLACE_CARD_STEP2_BTN";
    public static final String MANAGE_CARD_REPLACE_CARD_SUCCESS_MODAL_PAGE = "Replace_Card_Success_Modal-pg-overlay";
    public static final String MANAGE_CARD_REPLACE_CARD_SUCCESS_MODAL_CLOSE_BTN_PROP1 = "REPLACE_CARD_SUCCESS_MODAL_CLOSE_BTN";
    public static final String MANAGE_CARD_REPLACE_CARD_SUCCESS_MODAL_CLOSE_BTN_PEV1 = "REPLACE_CARD_SUCCESS_MODAL_CLOSE_BTN";
    public static final String MANAGE_CARD_REPLACE_CARD_ERROR = "Replace CardError";

    // Chip And Pin Analytics
    public static final String CHIP_CARD_CREATE_PIN_START_PAGE = "ChipCard_CreatePIN_Start-pg";
    public static final String CHIP_CARD_CREATE_PIN_START_PROP5_EVAR5 = "Chip Card:PIN";
    public static final String CHIP_CARD_CREATE_PIN_EVENT22 = "event22";
    public static final String CHIP_CARD_CREATE_PIN_EVENT9 = "event9";

    public static final String CHIP_CARD_CREATE_PIN_COMPLETE_PAGE = "ChipCard_CreatePIN_Complete-pg";
    public static final String CHIP_CARD_CHANGE_PIN_MODAL_PAGE = "ChipCard_ChangePIN_Modal-pg";

    public static final String CHIP_CARD_CREATE_PIN_ERROR_PAGE = "ChipCard_CreatePIN_Error-pg";
    public static final String CHIP_CARD_CREATE_PIN_ERROR_PROP10_LESS_THAN_4_DIGITS = "Chip PIN: Less than 4 digits";
    public static final String CHIP_CARD_CREATE_PIN_ERROR_PROP10_INVALID_PIN = "Chip PIN: Invalid PIN";
    public static final String CHIP_CARD_CREATE_PIN_ERROR_PROP10_MISMATCHED_PIN = "Chip PIN: Mismatched PIN";

    public static final String CHIP_CARD_ACTIVATE_CARD = "Cards:Activate Card";
    public static final String CHIP_CARD_ADVANCE_INFO = "Chip Card:Cash Advance Info";
    public static final String CHIP_CARD_CREATE_CHANGE_PIN = "Cards:Create/Change PIN";

    public static final String CHIP_CARD_PIN_GUIDELINES_MODAL_PAGE = "ChipCard_PINGuidelines_Modal-pg";

    // Start - Fico score analytics - 15.4 - US24255
    public static final String FICO_CREDIT_SCORE_WHY_MIGHT_MY_SCORE_BE_UNAVAILABLE_LNK = "FICO_CREDIT_SCORE_WHY_MIGHT_MY_SCORE_BE_UNAVAILABLE_LNK";
    public static final String FICO_CREDIT_SCORE_KEY_FACTORS_LNK = "FICO_CREDIT_SCORE_KEY_FACTORS_LNK";
    public static final String FICO_CREDIT_SCORE_WHAT_DO_THESE_SCORE_MEAN_LNK = "FICO_CREDIT_SCORE_WHAT_DO_THESE_SCORE_MEAN_LNK";
    public static final String FICO_CREDIT_SCORE_HISTORY_SCROLL_GRAPH = "FICO_CREDIT_SCORE_HISTORY_SCROLL_GRAPH";
    public static final String FICO_CREDIT_SCORE_HISTORY_LIST_TAB = "FICO_CREDIT_SCORE_HISTORY_LIST_TAB";
    public static final String FICO_CREDIT_SCORE_HISTORY_GRAPH_TAB = "FICO_CREDIT_SCORE_HISTORY_GRAPH_TAB";
    public static final String FICO_CREDITSCORE = "FICO_CreditScore-pg";
    public static final String FICO_CREDITSCORE_SCORE_UNAVAILABLE_OVER90DAYS_OVERLAY = "FICO_CreditScore_ScoreUnavailable_Over90Days_Overlay-pg";
    public static final String FICO_CREDITSCORE_KEYFACTORS = "FICO_CreditScore_KeyFactors-pg";
    public static final String FICO_CREDITSCORE_DETAILS = "FICO_CreditScore_Details-pg";
    public static final String FICO_CREDITSCORE_SCOREMEANING = "FICO_CreditScore_ScoreMeaning_Overlay-pg";
    public static final String FICO_CREDIT_SCORE_LNKO_PE = "lnk_o";

    public static final String FICO_CREDIT_SCORE_HISTORY_GRAPH_SCORE_CELL_TAP_LNK = "FICO_CREDIT_SCORE_HISTORY_GRAPH_SCORE_CELL_";
    public static final String FICO_CREDIT_SCORE_HISTORY_GRAPH_MONTHLY_CIRCLES_LNK = "FICO_CREDIT_SCORE_HISTORY_GRAPH_MONTHLY_CIRCLES_";
    // End - Fico score analytics - 15.4 - US24255

    public static final String PGC_HANDSET_REDEEM_PGC_BTN = "HANDSET_REDEEM_PGC_BTN";
    public static final String PGC_ECRT_LESS_THAN_20 = "MobileRedemption|PGC-Ecert-LessThan$20ToRedeem";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_BROWSE_ALL_BTN = "HANDSET_REDEEM_PGC_ECERT_BROWSE_ALL_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_ECERT_BTN = "HANDSET_REDEEM_PGC_ECERT_ECERT_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_GIFT_CARD_BTN = "HANDSET_REDEEM_PGC_ECERT_GIFT_CARD_BTN";
    public static final String PGC_HANDSET_BEST_VALUE_PAGE_NAME = "Partner Gift Cards Landing Page";

    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_BEST_VALUE_BTN = "HANDSET_REDEEM_PGC_ECERT_BEST_VALUE_BTN";
    //changed below BTN to LNK in 7.2
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_REST_BTN = "HANDSET_REDEEM_PGC_REST_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_HOME_BTN = "HANDSET_REDEEM_PGC_HOME_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_DEPT_STORE_BTN = "HANDSET_REDEEM_PGC_ECERT_DEPT_STORE_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_ENTERTAIN_BTN = "HANDSET_REDEEM_PGC_ENTERTAIN_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_HLTH_BEAU_BTN = "HANDSET_REDEEM_PGC_HLTH_BEAU_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_SPRTS_REC_BTN = "HANDSET_REDEEM_PGC_SPRTS_REC_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_GIFTS_BTN = "HANDSET_REDEEM_PGC_GIFTS_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_TRAVEL_BTN = "HANDSET_REDEEM_PGC_TRAVEL_LNK";
    public static final String PGC_HANDSET_GC_REVIEW_EDIT_CONTINUE_BTN_EVENT = "event3";
    public static final String PGC_HANDSET_ECT_REDEEM_BTN_EVENT = "HANDSET_REDEEM_PGC_ECERT_ECERT_REDEEM_BTN";
    public static final String PGC_HANDSET_ECT_CANCEL_BTN_EVENT = "HANDSET_REDEEM_PGC_ECERT_CANCEL_BTN";
    public static final String PGC_HANDSET_GC_REDEEM_BTN_EVENT = "HANDSET_REDEEM_PGC_MAIL_MAIL_REDEEM_BTN";
    public static final String PGC_HANDSET_GC_CANCEL_BTN_EVENT = "HANDSET_REDEEM_PGC_MAIL_MAIL_CANCEL_BTN";

    public static final String REDEEM_EVENTS = "event3";

    public static final String PGC_HANDSET_REDEEM_STATE_CREDIT_BTN = "HANDSET_REDEEM_STATE_CREDIT_BTN";
    public static final String PGC_HANDSET_REDEEM_DIRECT_DEP_BTN = "HANDSET_REDEEM_DIRECT_DEP_BTN";
    public static final String PGC_HANDSET_REDEEM_PAY_CBB_BTN = "HANDSET_REDEEM_PAY_CBB_BTN";
    public static final String PGC_HANDSET_REDEEM_HIST_BTN = "REDEEM_HIST_BTN";

    // Statement Credit
    public static final String REWARDS_HANDSET_REDEEM_STATE_CREDIT_BTN_PROP1 = "HANDSET_REDEEM_STATE_CREDIT_BTN";
    public static final String REWARDS_HANDSET_REDEEM_STATE_CREDIT_BTN_PE = "lnk_o";
    public static final String REWARDS_HANDSET_REDEEM_STATE_CREDIT_BTN_PEV1 = "HANDSET_REDEEM_STATE_CREDIT_BTN";

    public static final String REWARDS_HANDSET_REDEEM_STATE_CREDIT_BTN_EVENT3 = "event3";
    public static final String REWARDS_PRODUCTS_STMT = "CashbackBonus;CBB:CRD1";

    // Direct Credit
    public static final String REWARDS_HANDSET_REDEEM_DIRECT_DEP_BTN_PROP1 = "HANDSET_REDEEM_DIRECT_DEP_BTN";
    public static final String REWARDS_HANDSET_REDEEM_DIRECT_DEP_BTN_PE = "lnk_o";
    public static final String REWARDS_HANDSET_REDEEM_DIRECT_DEP_BTN_PEV1 = "HANDSET_REDEEM_DIRECT_DEP_BTN";

    public static final String REWARDS_HANDSET_REDEEM_DIRECT_DEP_BTN_EVENT3 = "event3";
    public static final String REWARDS_PRODUCTS = "CashbackBonus;CBB:EFT1";

    // CBB Promos
    public static final String REWARDS_HANDSET_REDEEM_CBB_PROMOS_BTN_PROP1 = "HANDSET_CBB_SIGNUP_BTN";
    public static final String REWARDS_HANDSET_REDEEM_CBB_PROMOS_BTN_PE = "lnk_o";
    public static final String REWARDS_HANDSET_REDEEM_CBB_PROMOS_BTN_PEV1 = "HANDSET-CBB-SIGNUP-BTN";


    //Feedback click events

    static final String LOGIN_TOOLBAR_FEEDBACK_BTN_QV_ON = "LOGIN_TOOLBAR_FEEDBACK_BTN_QV_ON";
    static final String LOGIN_TOOLBAR_FEEDBACK_BTN_QV_OFF = "LOGIN_TOOLBAR_FEEDBACK_BTN_QV_OFF";


    //ATM click events

    static final String LOGIN_TOOLBAR_ATM_BTN_QV_OFF = "LOGIN_TOOLBAR_ATM_BTN_QV_OFF";
    static final String LOGIN_TOOLBAR_ATM_BTN_QV_ON = "LOGIN_TOOLBAR_ATM_BTN_QV_ON";

    //Login click events

    static final String LOGIN_TOOLBAR_LOGIN_BTN_QV_OFF = "LOGIN_TOOLBAR_LOGIN_BTN_QV_OFF";
    static final String LOGIN_TOOLBAR_LOGIN_BTN_QV_ON = "LOGIN_TOOLBAR_LOGIN_BTN_QV_ON";

    //Help click events

    static final String LOGIN_TOOLBAR_HELP_BTN_QV_ON = "LOGIN_TOOLBAR_HELP_BTN_QV_ON";
    static final String LOGIN_TOOLBAR_HELP_BTN_QV_OFF = "LOGIN_TOOLBAR_HELP_BTN_QV_OFF";

    // Privacy & terms click events

    static final String LOGIN_PRIVACY_AND_TERMS_LNK = "LOGIN_PRIVACY_AND_TERMS_LNK";

    // Products page click events

    static final String LOGIN_TOOLBAR_PRODUCTS_BTN_QV_ON = "LOGIN_TOOLBAR_PRODUCTS_BTN_QV_ON";
    static final String LOGIN_TOOLBAR_PRODUCTS_BTN_QV_OFF = "LOGIN_TOOLBAR_PRODUCTS_BTN_QV_OFF";

    // Register page click events

    static final String REGISTER_LOGIN_PG_LNK = "REGISTER_LOGIN_PG_LNK";

    // Forgot password  click events

    static final String FORGOT_PWD_LOGIN_PG_LNK = "FORGOT_PWD_LOGIN_PG_LNK";

    // Forgot passcode  click events

    static final String FORGOT_PASSCODE_LNK = "FORGOT_PASSCODE_LNK";

    // Forgot password  link click events

    static final String FORGOT_PWD_LNK = "FORGOT_PWD_LNK";

    // Forgot both link click events

    static final String FORGOT_BOTH_LNK = "FORGOT_BOTH_LNK";

    // Forgot User id link click events

    static final String FORGOT_USERID_LNK = "FORGOT_USERID_LNK";

    // Credit card expand /collapse User id link click events

    static final String PRODUCTS_PG_CREDIT_CARD_EXPAND = "PRODUCTS_PG_CREDIT_CARD_EXPAND";

    static final String PRODUCTS_PG_CREDIT_CARD_COLLAPSE = "PRODUCTS_PG_CREDIT_CARD_COLLAPSE";

    // Banking  expand /collapse User id link click events

    static final String PRODUCTS_PG_BANKING_EXPAND = "PRODUCTS_PG_BANKING_EXPAND";

    static final String PRODUCTS_PG_BANKING_COLLAPSE = "PRODUCTS_PG_BANKING_COLLAPSE";

    // Loans expand /collapse User id link click events

    static final String PRODUCTS_PG_LOANS_EXPAND = "PRODUCTS_PG_LOANS_EXPAND";

    static final String PRODUCTS_PG_LOANS_COLLAPSE = "PRODUCTS_PG_LOANS_COLLAPSE";

    //Payments  step1 tags
    public static final String PAYMENTS_STEP_ONE_POST_SC = "paymentStep1-pg";
    public static final String PAYMENTS_STEP_ONE_POST_SC_EVENTS = "event62";
    public static final String PAYMENTS_STEP_ONE_POST_SC_EVAR5 = "DiscoverCard:Payments";

    //Payments  step2 tags
    public static final String PAYMENTS_STEP_TWO_POST_SC = "paymentStep2-pg";

    //Payments  step3 tags
    public static final String PAYMENTS_STEP_THREE_POST_SC = "paymentStep3-pg";
    public static final String PAYMENTS_STEP_THREE_POST_SC_EVENTS = "event17,event18";
    //added in 7.2 US43500 -START
    public static final String PAYMENTS_STEP_THREE_POST_SC_EVENTS_WITH_CBB = "event17,event18,event32,event33";
    //added in 7.2 US43500 -END
    public static final String PAYMENTS_STEP_THREE_POST_SC_PRODUCTS = ";;;;event17";
    public static final String PAYMENTS_STEP_THREE_POST_SC_PRODUCTS_CBB = "event32";
    public static final String PAYMENTS_STEP_THREE_POST_SC_EVAR19 = "eVar19";

    //Payments  Confirm cancel tags
    public static final String CONFIRM_PAYMENT_CANCEL_EVAR5 = "DiscoverCard:Payments:CancelPayment";

    //Manage bank accounts (MBA) tags
    public static final String MBA_NO_ACCOUNT_SETUP_BTN = "MBA_NO_ACCT_SETUP_ADD_ACCOUNT_BTN";
    public static final String MBA_NO_ACCOUNT_SETUP_BTN_PE = "lnk_o";
    public static final String MBA_NO_ACCOUNT_SETUP_BTN_PEV1 = "Manage Bank Account - NoAcSetUp-Add Account Btn";

    //Manage bank accounts (MBA) HA Mode tags
    public static final String PAYMENTS_HAMODE_MBA = "/ManageBankAccount/FeaturesUnavailable";

    //Manage bank accounts (MBA) in line error tags
    public static final String MBA_INLINE_ERROR_PEV1 = "Inline Errors";
    public static final String MBA_INLINE_ERROR_PE = "lnk_o";

    //Manage bank accounts (MBA) manage payments tags
    public static final String MBA_MANAGE_PAYMENTS_PROP1 = "MBA_FEATURES_UNAVAIL_MANAGE_PAYMENTS_BTN";
    public static final String MBA_MANAGE_PAYMENTS_PEV1 = "Inline Errors";
    public static final String MBA_MANAGE_PAYMENTS_PE = "lnk_o";

    //Manage bank accounts (MBA) manage payments tags
    public static final String MBA_MAX_ACCT_LIMIT = "/ManageBankAccount/Accounts/Sorry";

    //Manage bank accounts (MBA) button tags
    public static final String MBA_BTN = "MBA_WERE_SORRY_MBA_BANK_ACCOUNTS_BTN";
    public static final String MBA_BTN_PE = "lnk_o";
    public static final String MBA_BTN_PEV1 = "Manage Bank Account - Sorry_MBA Bank Accounts Btn";

    //Manage bank accounts (MBA) add bank account button tags
    public static final String MBA_ADD_BANK_ACCOUNT_BTN_PROP1 = "MBA_ACCOUNTS_ADD_ACCOUNT_BTN";
    public static final String MBA_ADD_BANK_ACCOUNT_BTN_PE = "lnk_o";
    public static final String MBA_ADD_BANK_ACCOUNT_BTN_PEV1 = "Manage Bank Account - Accounts_Add Account Btn";

    //Manage bank accounts (MBA) step1 confirm tags
    public static final String MBA_STEP1_ADD_ACCOUNT_BTN_PROP1 = "MBA_STEP1_ADD_ACCOUNT_BTN";
    public static final String MBA_STEP1_ADD_ACCOUNT_BTN_PE = "lnk_o";
    public static final String MBA_STEP1_ADD_ACCOUNT_BTN_PEV1 = "Manage Bank Account - Step1 Add Account Btn";

    //Manage bank accounts (MBA) step2 confirm tags
    public static final String MBA_STEP2_ADD_ACCOUNT_BTN_PROP1 = "MBA_STEP3_ADD_ACCOUNT_BTN";
    public static final String MBA_STEP2_ADD_ACCOUNT_BTN_PE = "lnk_o";
    public static final String MBA_STEP2_ADD_ACCOUNT_BTN_PEV1 = "Manage Bank Account - Step3 Add Account Btn";

    //Manage bank accounts (MBA) account edit confirm tags
    public static final String MBA_EDIT_ACCT_CONFIRM_BTN_PROP1 = "MBA_EDIT_ACCT_CONFIRM_ADD_ACCOUNT_BTN";
    public static final String MBA_EDIT_ACCT_CONFIRM_BTN_PE = "lnk_o";
    public static final String MBA_EDIT_ACCT_CONFIRM_BTN_PEV1 = "Manage Bank Account - Edit_Ac - Confirm Account Btn";

    //Manage bank accounts (MBA) account edit details tags
    public static final String MBA_EDIT_ACCT_DETAILS_BTN_PROP1 = "MBA_ACCOUNT_DETAILS_EDIT_BTN";
    public static final String MBA_EDIT_ACCT_DETAILS_BTN_PE = "lnk_o";
    public static final String MBA_EDIT_ACCT_DETAILS_BTN_PEV1 = "Manage Bank Account - Accounts_Add Account Btn";

    //Manage bank accounts (MBA) account edit update tags
    public static final String MBA_EDIT_ACCT_UPDATE_BTN_PROP1 = "MBA_EDIT_ACCT_UPDATE_ACCOUNT_BTN";
    public static final String MBA_EDIT_ACCT_UPDATE_BTN_PE = "lnk_o";
    public static final String MBA_EDIT_ACCT_UPDATE_BTN_PEV1 = "Manage Bank Account - Edit_Ac - Update Account Btn";

    //Manage bank accounts (MBA) account details remove tags
    public static final String MBA_ACCOUNT_DETAILS_REMOVE_ACCOUNT_PROP1 = "MBA_ACCOUNT_DETAILS_REMOVE_ACCOUNT_TXT";
    public static final String MBA_ACCOUNT_DETAILS_REMOVE_ACCOUNT_PE = "lnk_o";
    public static final String MBA_ACCOUNT_DETAILS_REMOVE_ACCOUNT_PEV1 = "Manage Bank Account - AcDetails-Remove Account Txt";

    //Manage bank accounts (MBA) pend payment remove account tags
    public static final String MBA_PEND_PYMTS_REMOVE_ACCOUNT_BTN_PROP1 = "MBA_PEND_PYMTS_REMOVE_ACCOUNT_BTN";
    public static final String MBA_PEND_PYMTS_REMOVE_ACCOUNT_BTN_PE = "lnk_o";
    public static final String MBA_PEND_PYMTS_REMOVE_ACCOUNT_BTN_PEV1 = "Manage Bank Account - Pend_Payments-Remove Ac Btn";

    //Manage bank accounts (MBA) pend payment do not remove account tags
    public static final String MBA_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_PROP1 = "MBA_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_TXT";
    public static final String MBA_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_PE = "lnk_o";
    public static final String MBA_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_PEV1 = "Manage Bank Account - Pend_Payments-Do Not Remove Ac Txt";

    //Manage bank accounts (MBA) no pend payment remove account tags
    public static final String MBA_NO_PEND_PYMTS_REMOVE_ACCOUNT_BTN_PROP1 = "MBA_NO_PEND_PYMTS_REMOVE_ACCOUNT_BTN";
    public static final String MBA_NO_PEND_PYMTS_REMOVE_ACCOUNT_BTN_PE = "lnk_o";
    public static final String MBA_NO_PEND_PYMTS_REMOVE_ACCOUNT_BTN_PEV1 = "Manage Bank Account - NoPend_Payments-Remove Ac Btn";

    //Manage bank accounts (MBA) no pend payment do not remove account tags
    public static final String MBA_NO_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_PROP1 = "MBA_NO_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_TXT";
    public static final String MBA_NO_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_PE = "lnk_o";
    public static final String MBA_NO_PEND_PYMTS_DO_NOT_REMOVE_ACCOUNT_PEV1 = "Manage Bank Account - NoPend_Payments-Do Not Remove Ac Txt";

    //Manage bank accounts (MBA) no pend payment do not remove account tags
    public static final String MBA_PYMTS_SUMMARY_MAP_BTN_PROP1 = "MANAGE_PYMTS_SUMMARY_MAP_BTN";
    public static final String MBA_PYMTS_SUMMARY_MAP_BTN_PE = "lnk_o";
    public static final String MBA_PYMTS_SUMMARY_MAP_BTN_PEV1 = "Manage Bank Account - Accounts_Add Account Btn";

    //Manage bank accounts (MBA) Edit button click from Payments Eligible page which will direct the user to edit payment page
    public static final String MBA_PYMTS_SUMMARY_MAP_BTN_PROP1_EDIT = "MANAGE_PYMTS_SUMMARY_MAP_BTN";
    public static final String MBA_PYMTS_SUMMARY_MAP_BTN_PE_EDIT = "lnk_o";
    public static final String MBA_PYMTS_SUMMARY_MAP_BTN_PEV1_EDIT = "Manage Payments - Edit Btn";

    //Manage bank accounts (MBA) Cancel Payment Button click from Payments eligible Page
    public static final String MBA_PYMTS_EDIT_CANCEL_PYMT_PROP1 = "MANAGE_PYMTS_EDIT_CANCEL_PYMT_TXT";
    public static final String MBA_PYMTS_EDIT_CANCEL_PYMT_PE = "lnk_o";
    public static final String MBA_PYMTS_EDIT_CANCEL_PYMT_PEV1 = "Manage Payments - Edit-Cancel Pymnt txt";

    //Manage bank accounts (MBA) Click of Confirm edit payment button
    public static final String MBA_PYMTS_EDIT_VERIFY_CONFIRM_BTN_PROP1 = "MANAGE_PYMTS_VERIFY_CONFIRM_BTN";
    public static final String MBA_PYMTS_EDIT_VERIFY_CONFIRM_BTN_PE = "lnk_o";
    public static final String MBA_PYMTS_EDIT_VERIFY_CONFIRM_BTN_PEV1 = "Manage Payments - Verify Confirm Btn";

    //Manage bank accounts (MBA) on click of Do not cancel button from Edit Flow
    public static final String MBA_PYMTS_VERIFY_DO_NOT_CANCEL_TXT_PROP1 = "MANAGE_PYMTS_VERIFY_DO_NOT_CANCEL_TXT";
    public static final String MBA_PYMTS_VERIFY_DO_NOT_CANCEL_TXT_PE = "lnk_o";
    public static final String MBA_PYMTS_VERIFY_DO_NOT_CANCEL_TXT_PEV1 = "Manage Payments - Verify Do Not Cancel Txt";

    public static final String PRODUCTS_PAGE = "products-pg";

    public static final String INVALID_PASSCODE = "Invalid Passcode";

    public static final String INVALID_PASSWORD = "Invalid Password";

    public static final String ACCOUNT_LOCKED_PERMANENT = "Account permanent locked";

    public static final String ACCOUNT_LOCKED_TEMPORARY = "Account temp locked";

    public static final String ACCOUNT_LOCKED_LAST_ATTEMPT = "Account lock - last attempt";

    public static final String INCORRECTUSERIDORPASSWORD = "Incorrect User Id/Password";

    public static final String LHN_MENU_FRAGMENT = "LHN-pg";

    //Portal Page
    public static final String PORTAL_CHECKING_DEPOSIT_A_CHECK_TXT = "PORTAL_CHECKING_DEPOSIT_A_CHECK_TXT";

    public static final String PORTAL_LNK_O_PE = "lnk_o";

    public static final String PORTAL_CHECKING_PAY_BILLS_TXT = "PORTAL_CHECKING_PAY_BILLS_TXT";

    public static final String PORTAL_SAVINGS_DEPOSIT_A_CHECK_TXT = "PORTAL_SAVINGS_DEPOSIT_A_CHECK_TXT";

    public static final String PORTAL_SAVINGS_TRANSFER_MONEY_TXT = "PORTAL_SAVINGS_TRANSFER_MONEY_TXT";

    public static final String PORTAL_CARD_FICO_CREDIT_SCORE_TXT = "PORTAL_CARD_FICO_CREDIT_SCORE_TXT";

    public static final String PORTAL_CARD_MAKE_A_PAYMENT_TXT = "PORTAL_CARD_MAKE_A_PAYMENT_TXT";

    public static final String PORTAL_LOGOUT_BTN = "PORTAL_LOGOUT_BTN";

    public static final String PORTAL_LOGOUT_BTN_events = "event73";

    public static final String PORTAL_PAGE = "Portal-pg";
    String PORTAL_SSO_FICO_CREDIT_SCORE_LNK = "PORTAL_SSO_FICO_CREDIT_SCORE_LNK";
    String PORTAL_CLOSED_ACCT_STMT_TAX_DOC_LNK= "PORTAL_CLOSED_ACCT_STMT_TAX_DOC_LNK";
    String PORTAL_CLOSED_ACCT_LOG_OUT_BTN= "PORTAL_CLOSED_ACCT_LOG_OUT_BTN";
    String PORTAL_CLOSED_ACCOUNTS_PG= "Portal_Closed_Accounts-pg";
    String PORTAL_ACCT_ = "PORTAL_ACCT_";
    String PORTAL_ACCT_DRAG_DROP_ = "PORTAL_ACCT_DRAG_DROP_";


    //rewards - 16.7 REGRESSION - start

    //    public static final String REWARDS_CASHBACKBONUS_SIGNUP_PG = "cashbackbonussignup-pg";
    public static final String REWARDS_CASHBACKSIGNUP1_PG = "cashbacksignup1-pg";
    public static final String REWARDS_REDEMPTION_LANDING = "redemption-landing";
    public static final String REWARDS_CASHBACKSIGNUP2_PG = "cashbacksignup2-pg";
    public static final String REWARDS_CASHBACKSIGNUP3_PG = "cashbackbonussignup3-pg";
    public static final String REWARDS_STATEMENT_CREDIT_1 = "statementcredit1-pg";
    public static final String REWARDS_STATEMENT_CREDIT_2 = "statementcredit2-pg";
    public static final String REWARDS_STATEMENT_CREDIT_3 = "statementcredit3-pg";
    public static final String REWARDS_REDEEM_DETAILS_VIEW = "redeem-dtlview";
    public static final String REWARDS_REDEEM_BEST_VALUE = "redeembestvalue";
    public static final String REWARDS_REDEEM_HISTORY = "redeemHistory-pg";
    public static final String REWARDS_DIRECT_DEPOSIT_PG = "directdeposit1-pg";
    public static final String REWARDS_DIRECT_DEPOSIT2_PG = "directdeposit2-pg";
    public static final String REWARDS_DIRECT_DEPOSIT3_PG = "directdeposit3-pg";
    public static final String REWARDS_BROWSE_ALL_PARTNERS = "browse-all-partners";
    public static final String REWARDS_REDEM_CB = "redm-cb";
    //    public static final String REWARDS_PARTNER_CATEGORY = "partner-category";
    public static final String REWARDS_BROWSE_ALL_GIFT_CARDS = "browse-all-giftcards";
    public static final String REWARDS_BEST_VALUE = "redeembestvalue";
    public static final String REWARDS_REDEM_ERROR_PG = "redm-error-pg";
    public static final String REWARDS_MILES_REDEEM = "milesredeem-pg";
    public static final String REWARDS_BANK_ACCOUNT_DIRECT_DEPOSIT = "bankaccountfordirectdeposit_pg";

    public static final String REWARDS_VERIFY_GIFT_CARD = "gift-card-verify-partner";

    //    public static final String REWARDS_REDEEM_LANDING_PAGE = "redeemlandingpage";
    public static final String REWARDS_CONFIRM_GIFT_CARD = "cofirm-gift-card-partner";
    public static final String REWARDS_REDEEM_INSUFFICIENT_FUND_PAGE = "redeeminsufficientfundpage";

    //rewards - 16.7 REGRESSION -end


    public static final String PAYMENTS_SUMMARY_PAGE = "paymentssummary-pg";
    public static final String PAYMENTS_HISTORY_PAGE = "paymentshistory-pg";
    public static final String PAYMENTS_SAVE_TO_PHOTOS_PAGE = "paymentsavetophotos-pg";
    public static final String PAYMENTS_SDELECT_BANK_PAGE = "paymentselectbank-pg";
    public static final String PAYMENTS_PENDING_PAGE = "pendingpayments-pg";
    //    public static final String PAYMENTS_LATEPAYMENTWARN_PAGE ="lateminpaywarn1-pg";
    public static final String PAYMENTS_CANCEL_PAYMENT_PAGE = "cancelpayment-pg";
    public static final String PAYMENTS_CANCEL_PAYMENT_CONFIRM_PAGE = "confirmcancelpayment-1-pg";
    public static final String PAYMENTS_ADDIONAL_OPTION_SELECT_PICKER = "additional_payment_options_picker-pg";
    public static final String PAYMENTS_ADDIONAL_OPTION_AMOUNT_PAGE = "addtionalamount-pg";
    public static final String PAYMENTS_PENDING_PAYMENTS_MESSAGE_OVERLAY = "pending_payment_details_model-pg-overlay";
    public static final String PAYMENTS_SELECT_BANK_ACCOUNT_PAGE = "make_payment_select_bank_account-pg";
    public static final String PAYMENTS_ADDIONAL_OPTION_AMOUNT_PAGE_PAYOFF = "payoff_quote_model-pg-overlay";

    //    public static final String MANAGE_BANK_ACCOUNTS_ENTER_DETAILS_PAGE ="managebankaccenterdetails-pg";
    public static final String MANAGE_BANK_ACCOUNTS_PAGE = "managebankaccounts-pg";
    public static final String MANAGE_BANK_NO_ACCOUNTS_PAGE = "managebankaccnoacc-pg";
    public static final String MANAGE_BANK_ACCOUNTS_DETAILS_PAGE = "managebankaccdetails-pg";
    public static final String MANAGE_BANK_ACCOUNTS_UPDATE_DETAILS_PAGE = "managebankaccupdatedetails-pg";


    // START - Freeze account analytics site cat
    public static final String FREEZE_ACCOUNT_FROZEN_MESSAGE = "AccountHome_Account_Frozen_Message-pg";
    public static final String FREEZE_ACCOUNT_FROZEN_MESSAGE_MODEL = "Account_Frozen_Message_Modal-pg-Overlay";
    public static final String FREEZE_ACCOUNT_FREEZE_ACCOUNT_LOAD = "Freeze_Account-pg";
    public static final String FREEZE_ACCOUNT_FROZEN_SUCCESS_MODEL = "Account_Frozen_Success_Modal-pg-Overlay";
    public static final String FREEZE_ACCOUNT_UNFREEZE_ACCOUNT_CONFIRMATION = "Unfreeze_Account_Confirmation-pg";
    public static final String FREEZE_ACCOUNT_UNFROZEN_SUCCESS_MODEL = "Account_Unfrozen_Modal-pg-Overlay";
    public static final String FREEZE_ACCOUNT_REPORT_LOSTORSTOLEN_SUCCESS_MODEL = "Report_LostorStolen_Success_Modal-pg-Overlay";
    public static final String FREEZE_ACCOUNT_CARDS_LANDING = "Cards_Landing-pg";
    public static final String FREEZE_ACCOUNT_REPLACE_CARD_SUCCESS_MODEL = "Replace_Card_Success_Modal-pg-Overlay";
    // END - Freeze account analytics site cat

    //Start - Change password
    public static final String CHANGE_PASSWORD_SELECT_CHANGE_PASSWORD = "LOGIN_CRED_MAN_LOGIN_CHG_PASSWD_BTN";
    public static final String CHANGE_PASSWORD_CANCEL_BUTTON = "LOGIN_CRED_CHG_PASSWD_CANCEL_TXT";
    public static final String CHANGE_PASSWORD_SUBMIT_BUTTON = "LOGIN_CRED_CHG_PASSWD_SUBMIT_BTN";
    public static final String CHANGE_PASSWORD_ERROR = "ChangePasswordStep1|<";
    public static final String CHANGE_PASSWORD_SUCCESS = "ChangePasswordSuccessModal";
    public static final String CHANGE_PASSWORD_LANDING_PAGE = "ChangePasswordStep1";

    public static final String CHANGE_PASSWORD_PE = "lnk_o";
    //End - Change password

    //Start - Contact Us
    public static final String CONTACT_US_SOCIAL_FACEBOOK_BTN = "CONTACT_SOCIAL_FACEBOOK_BTN";
    public static final String CONTACT_US_SOCIAL_TWITTER_BTN = "CONTACT_SOCIAL_TWITTER_BTN";


    //End - Contact Us

    //Start - Account Profile
    public static final String ACCOUNT_PROFILE_FAQ = "IncomeCapture_AcctPrfl_TotalAnnualIncome_FAQToolTip_Overlay";
    public static final String ACCOUNT_PROFILE_HELP_OVERLAY = "IncomeCapture_AcctPrfl_TotalAnnualIncome_Help_Overlay";
    public static final String SELECTED_HOUSING_TYPE = ";IncomeCapture:Housing:";
    public static final String SELECTED_TELEPHONE_TYPE = ";IncomeCapture:Telephone:";
    public static final String ERROR_SCENARIO_INCOME_CAPTURE = "IncomeCapture_AcctPrfl|";
    public static final String ACCOUNT_PROFILE_EDIT_CANCEL_BUTTON_CLICK = "IncomeCapture_AcctPrfl_Edit_YourChangeswillbe Lost_Overlay";
    public static final String ACCOUNT_PROFILE_EDIT_BUTTON_CLICK_PROP1 = "INCOME_CAPTURE_ACCT_PROF_EDIT_TXT";
    public static final String ACCOUNT_PROFILE_EDIT_BUTTON_CLICK_PEV1 = "INCOME_CAPTURE_ACCT_PROF_EDIT_TXT";
    public static final String ACCOUNT_PROFILE_SAVE_BUTTON_PROP1 = "INCOME_CAPTURE_ACCT_PROF_SAVE_BTN";
    public static final String ACCOUNT_PROFILE_SAVE_BUTTON_PEV1 = "INCOME_CAPTURE_ACCT_PROF_SAVE_BTN";

    //End - Account Profile

    //start - Statement preferences

    public static final String STMT_PREFERENCES_PAGE = "Statement_Preferences-pg";
    public static final String STMT_PREFERENCES_FAQ = "Statement_Preferences_FAQ-pg";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS = "Terms_And_Conditions_Modal-pg-Overlay";
    public static final String STMT_PREFERENCES_CHANGES_SAVED_CONFIRMATION = "Changes_Saved_Confirmation-pg";
    public static final String STMT_PREFERENCES_CHANGES_SAVED_CONFIRMATION_MY_EVENTS = "event9";
    public static final String STMT_PREFERENCES_CHANGES_SAVED_CONFIRMATION_MY_EVAR5 = "Mail";
    public static final String STMT_PREFERENCES_CHANGES_SAVED_CONFIRMATION_MY_PROP5 = "Mail";
    public static final String STMT_PREFERENCES_CHANGES_SAVED_CONFIRMATION_PE = "lnk_o";
    public static final String STMT_PREFERENCES_NO_EMAIL = "No_Email_On_File_Modal-pg-Overlay";
    public static final String STMT_PREFERENCES_CONTINUE_WITHOUT_SAVING = "Continue_Without_Saving_Modal-pg-Overla";
    public static final String STMT_PREFERENCES_LHN_LANDING_PROP1 = "PROFILE_SETTING_STMT_PREF_BTN";
    public static final String STMT_PREFERENCES_LHN_LANDING_PEV1 = "PROFILE_SETTING_STMT_PREF_BTN";

    public static final String STMT_PREFERENCES_EDIT_PROP1 = "STMT_PREF_EDIT_SAVE_BTN";
    public static final String STMT_PREFERENCES_EDIT_PEV11 = "STMT_PREF_EDIT_SAVE_BTN";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_PROP1 = "STMT_PREF_TC_MODAL_ACCEPT_BTN";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_PEV1 = "STMT_PREF_TC_MODAL_ACCEPT_BTN";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_CANCEL_PROP1 = "STMT_PREF_TC_MODAL_CANCEL_BTN";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_CANCEL_PE = "lnk_o";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_CANCEL_MY_EVENTS = "event9";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_CANCEL_MY_EVAR5 = "Internet";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_CANCEL_MY_PROP5 = "Internet";
    public static final String STMT_PREFERENCES_TERMS_N_CONDITIONS_CANCEL_PEV1 = "STMT_PREF_TC_MODAL_CANCEL_BTN";
    public static final String STMT_PREFERENCES_NO_EMAIL_PROP1 = "STMT_PREF_NO_EMAIL_PROFILE_BTN";
    public static final String STMT_PREFERENCES_NO_EMAIL_PEV1 = "STMT_PREF_NO_EMAIL_PROFILE_BTN";
    public static final String STMT_PREFERENCES_NO_EMAIL_CLOSE_PROP1 = "STMT_PREF_NO_EMAIL_CLOSE_BTN";
    public static final String STMT_PREFERENCES_NO_EMAIL__CLOSE_PEV1 = "STMT_PREF_NO_EMAIL_CLOSE_BTN";
    public static final String STMT_PREFERENCES_NO_EMAIL_PE = "lnk_o";

    //END - Statement preferences


    //start - Recent Activity/Search Transactions

    public static final String PENDING_TRANSACTION_DETAILS = "PendingTransactionDetails";
    public static final String POSTED_TRANSACTION_DETAILS = "PostedTransactionDetails";
    public static final String MERCHANT_MAP_VIEW = "MerchantMapView";

    public static final String RECENT_ACTIVITY_PENDING_TRANSACTION_DETAILS_PROP1 = "PENDING_TRANSACTION_DETAILS_EXPAND";
    public static final String RECENT_ACTIVITY_PENDING_TRANSACTION_DETAILS_PEV1 = "PENDING_TRANSACTION_DETAILS_EXPAND";

    public static final String RECENT_ACTIVITY_PERIOD_DROPDOWN_BTN_PROP1 = "RECENT_ACTIVITY_PERIOD_DROPDOWN_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_DROPDOWN_BTN_PEV1 = "RECENT_ACTIVITY_PERIOD_DROPDOWN_BTN";

    public static final String RECENT_ACTIVITY_SEARCH_TRANSACTION_PROP1 = "RECENT_ACTIVITY_SEARCH_TRANS_BTN";
    public static final String RECENT_ACTIVITY_SEARCH_TRANSACTION_PEV1 = "RECENT_ACTIVITY_SEARCH_TRANS_BTN";

    public static final String RECENT_ACTIVITY_PERIOD_SINCE_DATE_PROP1 = "RECENT_ACTIVITY_PERIOD_SINCE_DATE_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_SINCE_DATE_PEV1 = "RECENT_ACTIVITY_PERIOD_SINCE_DATE_BTN";

    public static final String RECENT_ACTIVITY_PERIOD_CURRENT_STMT_PROP1 = "RECENT_ACTIVITY_PERIOD_CURRENT_STMT_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_CURRENT_STMT_PEV1 = "RECENT_ACTIVITY_PERIOD_CURRENT_STMT_BTN";

    public static final String RECENT_ACTIVITY_PERIOD_LAST_12_PROP1 = "RECENT_ACTIVITY_PERIOD_LAST_12_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_LAST_12__PEV1 = "RECENT_ACTIVITY_PERIOD_LAST_12_BTN";

    public static final String RECENT_ACTIVITY_PERIOD_YTD_BTN_PROP1 = "RECENT_ACTIVITY_PERIOD_YTD_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_YTD_BTN__PEV1 = "RECENT_ACTIVITY_PERIOD_YTD_BTN";

    public static final String RECENT_ACTIVITY_PERIOD_2013_BTN_PROP1 = "RECENT_ACTIVITY_PERIOD_2013_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_2013_BTN__PEV1 = "RECENT_ACTIVITY_PERIOD_2013_BTN";

    public static final String RECENT_ACTIVITY_PERIOD_LOAD_MORE_TRANSACTIONS_PROP1 = "RECENT_ACTIVITY_LOAD_MORE_TRANS_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_LOAD_MORE_TRANSACTIONS_PEV1 = "RECENT_ACTIVITY_LOAD_MORE_TRANS_BTN";

    public static final String SEARCH_TRANSACTION_PERIOD_LOAD_MORE_TRANSACTIONS_PROP1 = "SEARCH_TRANS_LOAD_MORE_TRANS_BTN";
    public static final String SEARCH_TRANSACTION_PERIOD_LOAD_MORE_TRANSACTIONS_PEV1 = "SEARCH_TRANS_LOAD_MORE_TRANS_BTN";

    public static final String RECENT_ACTIVITY_PERIOD_SEARCH_TRANSACTIONS_PROP1 = "SEARCH_TRAN_SEARCH_BTN";
    public static final String RECENT_ACTIVITY_PERIOD_SEARCH_TRANSACTIONS_PEV1 = "SEARCH_TRAN_SEARCH_BTN";

    //END - Recent Activity/Search Transactions

    // Tagging related stuff begins
    public static final String SEARCHTRAN_TRANTAG_APPLY_TXT_PROP1 = "SEARCHTRAN_TRANTAG_APPLY_TXT";
    public static final String SEARCHTRAN_TRANTAG_APPLY_TXT_PEV1 = "SEARCHTRAN_TRANTAG_APPLY_TXT";

    public static final String TAGTRAN_APPLY_TXT_PROP1 = "TAGTRAN_APPLY_TXT";
    public static final String TAGTRAN_APPLY_TXT_PEV1 = "TAGTRAN_APPLY_TXT";

    public static final String TAGMODULE_CREATE_TXT_PROP1 = "TAGMODULE_CREATE_TXT";
    public static final String TAGMODULE_CREATE_TXT_PEV1 = "TAGMODULE_CREATE_TXT";

    public static final String TAG_ADD_CREATE_TXT_PROP1 = "TAG_ADD_CREATE_TXT";
    public static final String TAG_ADD_CREATE_TXT_PEV1 = "TAG_ADD_CREATE_TXT";

    public static final String TAGMODULE_EDITTAGUPDATE_TXT_PROP1 = "TAGMODULE_EDITTAGUPDATE_TXT";
    public static final String TAGMODULE_EDITTAGUPDATE_TXT_PEV1 = "TAGMODULE_EDITTAGUPDATE_TXT";

    public static final String TAGMODULE_EDIT_TXT_PROP1 = "TAGMODULE_EDIT_TXT";
    public static final String TAGMODULE_EDIT_TXT_PEV1 = "TAGMODULE_EDIT_TXT";

    public static final String TAGMODULE_EDITTAG_TXT_PROP1 = "TAGMODULE_EDITTAG_TXT";
    public static final String TAGMODULE_EDITTAG_TXT_PEV1 = "TAGMODULE_EDITTAG_TXT";

    public static final String TAGTRAN_CREATE_TXT_PROP1 = "TAGTRAN_CREATE_TXT";
    public static final String TAGTRAN_CREATE_TXT_PEV1 = "TAGTRAN_CREATE_TXT";

    public static final String TAGMODULE_DELETE_CONFIRM_TXT_PROP1 = "TAGMODULE_DELETE_CONFIRM_TXT";
    public static final String TAGMODULE_DELETE_CONFIRM_TXT_PEV1 = "TAGMODULE_DELETE_CONFIRM_TXT";

    public static final String ACCOUNT_ACTIVITY_TRANTAG_TXT_PROP1 = "ACCOUNT_ACTIVITY_TRANTAG_TXT";
    public static final String ACCOUNT_ACTIVITY_TRANTAG_TXT_PEV1 = "ACCOUNT_ACTIVITY_TRANTAG_TXT";

    public static final String SEARCHTRAN_RESULTS_TRANTAG_TXT_PROP1 = "SEARCHTRAN_RESULTS_TRANTAG_TXT";
    public static final String SEARCHTRAN_RESULTS_TRANTAG_TXT_PEV1 = "SEARCHTRAN_RESULTS_TRANTAG_TXT";

    public static final String TRANDETAIL_TRANTAG_TXT_PROP1 = "TRANDETAIL_TRANTAG_TXT";
    public static final String TRANDETAIL_TRANTAG_TXT_PEV1 = "TRANDETAIL_TRANTAG_TXT";

    public static final String TRANDETAIL_TAGTRAN_TXT_PROP1 = "TRANDETAIL_TAGTRAN_TXT";
    public static final String TRANDETAIL_TAGTRAN_TXT_PEV1 = "TRANDETAIL_TAGTRAN_TXT";

    public static final String TAGMODULE_TRANTAG_TXT_PROP1 = "TAGMODULE_TRANTAG_TXT";
    public static final String TAGMODULE_TRANTAG_TXT_PEV1 = "TAGMODULE_TRANTAG_TXT";

    public static final String TAGMODULE_EDITDONE_TXT_PROP1 = "TAGMODULE_EDITDONE_TXT";
    public static final String TAGMODULE_EDITDONE_TXT_PEV1 = "TAGMODULE_EDITDONE_TXT";

    public static final String SEARCH_TRANSACTIONS_LANDING_PAGE = "searchtransaction-pg";
    public static final String SEARCH_TRANSACTIONS_MULTI_SELECTION = "tag-searchtransaction-selection-pg";
    public static final String SEARCH_TRANSACTIONS_RESULT_PAGE = "searchtransaction-results-pg";

    public static final String TAG_TRANSACTION_PAGE = "tag-transaction-pg";
    public static final String TAG_TRANSACTION_ADDTAGNAME_PAGE = "tag-addtagname-pg";
    public static final String TAG_POSTED_TRANSACTION_DETAILS_PAGE = "PostedTransactionDetails-pg";
    public static final String TAG_MODULE_PAGE = "tag-module-pg";
    public static final String TAG_MODULE_EDIT_PAGE = "tag-module-edittags-pg";
    public static final String TAG_MODULE_EDIT_NAME_PAGE = "tag-module-editname-pg";
    public static final String TAG_MODULE_DELETE_VERIFY_PAGE = "tag-module-deleteverify-pg";
    public static final String TAG_MODULE_TAG_SELECTED_PAGE = "tag-selected-tag-pg";
    public static final String TAG_MODULE_CREATENAME_ERROR_PAGE = "tag-module-createname-error-pg";
    public static final String TAG_SELECTEDTAG_TRANTAG_TXT = "SELECTEDTAG_TRANTAG_TXT";


    // Tagging related stuff end


    //Start-CLI

    public static final String CLI_ENTER_INFORM_CANCEL_BTN = "ANDROIDHS_CLI_ENTER_INFORM_CANCEL_BTN";
    public static final String CLI_PE = "lnk_o";

    public static final String ANDROID_HS_CLI_TOTALANNUALGROSSINCOMEMODAL = "CLI_TotalAnnualGrossIncomeModal-pg";

    public static final String ANDROID_HS_CLI_ZERO_DOLLAR_TAKEN_MODAL = "CLI_ZeroDollarTakenMotagtradal-pg";

    public static final String ANDROID_HS_CLI_ZERO_DOLLAR_TAKEN_CONFIRM = "CLI_ZeroDollarTakenConfirm-pg";

    public static final String ANDROID_HS_CLI_AMOUNT_APPROVED = "CLI_AmountApproved-pg";

    public static final String ANDROID_HS_CLI_ENTER_INFORMATION = "CLI_EnterInformation-pg";

    public static final String ANDROID_HS_CLI_CHOOSE_AMOUNT = "CLI_Chooseamount-pg";

    public static final String ANDROID_HS_CLI_CHOOSE_AMOUNT_CANCEL_BUTTON = "CLI_CHOOSE_AMT_CANCEL_LNK";

    public static final String ANDROID_HS_CLI_NO_INCREASE_THIS_TIME_MESSAGE = "CLI_NoIncreaseAtThisTimeMessage-pg";

    public static final String ANDROIDHSCLIENTERINFORMATION = "CLIEnterInformation";

    public static final String CLI_ZERO_DOLLAR_TAKEN_MODAL_CANCEL = "CLI_ZERO_DOLLAR_TAKEN_MODAL_CANCEL_BTN";

    /*
     * osawant - added in regression phase - 13oct - start
     */
    public static final String PAYMENTS_ELIGIBLE = "paymentseligible-pg";
    public static final String PAYMENTS_NOT_ELIGIBLE = "paymentsnoteligible";
    public static final String LATE_MINIMUM_PAYMENT_WARNING = "lateminpaywarnnominpay-pg";
    public static final String CANCEL_PAYMENTS = "cancelpayments1-pg";
    public static final String CONFIRM_CANCEL_PAYMENT = "confirmcancelpayment-pg";
    public static final String REMOVE_ACCOUNT_CONFIRM_PENDING = "removeaccountconfirmnopending-pg";
    public static final String REMOVE_COMPLETE_PG = "removecomplete-pg";
    public static final String PAYMENT_INFO_PG = "paymentinfo-pg";
    public static final String STATEMENT_BALANCE_OVERLAY_PG = "statementbalanceoverlay-pg";
    public static final String PAY_OFF_QUOTE_OVERLAY_PG = "payoffquoteoverlay-pg";
    public static final String CALENDAR_PG = "calendar-pg";
    //    public static final String PAYMENT_SAVE_TO_PHOTO = "payment_save_photo-pg";
    public static final String PAYMENTS_ADDIONAL_OPTION_AMOUNT_PAGE_OUTSTANDING = "outstanding_statement_balance_model-pg-overlay";
    public static final String MAKE_PAYMENT_VERIFY_STEP = "make_payment_verify_step3-pg";
    public static final String PAYMENTS_ADDIONAL_OPTION_AMOUNT_PAGE_OUTSTANDING_CURRENT = "outstanding_current_balance_model-pg-overlay";
    public static final String MANAGE_BANK_ENTER_DETAILS = "manage_bank_acc_enter_details-pg";
    public static final String EDIT_PAYMENT_STEP1 = "payment_step1_edit-pg";
    public static final String EDIT_PAYMENT_STEP2 = "payment_step2_edit-pg";
    public static final String EDIT_PAYMENT_STEP3 = "payment_step3_edit-pg";
    public static final String PENDING_PAYMENTS_DETAILS = "pendingpaymentsdetailoverlay-pg";
    public static final String BROWSE_ALL_ECERTIFICATES = "browse-all-ecertificates";
    public static final String DD_CANCEL = "directdepositcanceltrans-pg";
    public static final String DD_CONFIRM_CANCEL = "directdepositconfirmcanceltrans-pg";
    public static final String ECART_SAVE_PIN = "ecart-save-pin";
    public static final String REDM_MERCHANT_TCN = "redm-merchant-tnc";
    //changed in 7.2 - START
    public static final String RDHISTORY_VIEW_ECERT_DETAILS = "redeemECertDetails-pg";
    //END
    public static final String STATEMENT_CREDIT_CANCEL_TRANS = "statementcreditcanceltrans-pg";
    public static final String STATEMENT_CREDIT_CONFIRM_CANCEL_TRANS = "statementcreditconfirmcanceltrans-pg";
    public static final String LOGINSUCCESSFUL = "login_successful";
    static final String USERIDLOGIN_prop1 = "USER_ID_LOGIN_LNK";

    static final String USERIDLOGIN_pev1 = "USER_ID_LOGIN_LNK";

    /*
     * osawant - added in regression phase - 13oct - end
     */


    //Payment Enhancements Analytics - Start
    public static final String PAYMENT_AUTHORIZATION_DETAIL_OVERLAY = "Payment_Authorization_Details_Overlay-pg";

    public static final String PAYMENT_AUTHORIZE_INFORMATION_PROP1 = "PAYMENT_AUTHORIZE_INFORMATION_BTN";
    public static final String PAYMENT_AUTHORIZE_INFORMATION_EVAR = "PAYMENT_AUTHORIZE_INFORMATION_BTN";
    public static final String PAYMENT_AUTHORIZE_INFORMATION_LNK = "lnk_o";
    public static final String PAYMENT_AUTHORIZE_INFORMATION_PEV1 = "PAYMENT_AUTHORIZE_INFORMATION_BTN";

    //Payment Enhancements Analytics - End

    //CBB payment tags start
    public static final String CBB_PAYMENT_STEP_2 = "MAP_TYPE:%1$s:%2$s";

    public static final String PAYMENT_OPTION_CBB = "CBB";
    public static final String PAYMENT_OPTION_NO_CBB = "NoCBB";
    public static final String PAYMENT_OPTION_CBB_UNAVAILABLE = "CBBUnavailable";

    public static final String PAYMENT_VERIFY_OPTION_CBB = "CBBOnly";
    public static final String PAYMENT_VERIFY_OPTION_CBB_BANK = "BankAcct plus CBB";
    public static final String PAYMENT_VERIFY_OPTION_BANK = "BankAcctOnly";

    public static final String PAYMENT_SOURCE_CBB_INFO_EVAR35 = "SOURCE_DATE_CBB_INFORMATION_LNK";
    public static final String PAYMENT_SOURCE_CBB_INFO_PROP1 = "SOURCE_DATE_CBB_INFORMATION_LNK";
    public static final String PAYMENT_SOURCE_CBB_INFO_PE = "lnk_o";
    public static final String PAYMENT_SOURCE_CBB_INFO_PEV1 = "SOURCE_DATE_CBB_INFORMATION_LNK";

    public static final String PAYMENT_SOURCE_CBB_ERROR_PROP10 = "Source/Date:%1$s";
    public static final String PAYMENT_SOURCE_CBB_OVERLAY_IT_CARD = "CBB_Modal_IT_Card_Overlay-pg";
    public static final String PAYMENT_SOURCE_CBB_OVERLAY_NON_IT_CARD = "CBB_Modal_Non_IT_Card_Overlay-pg";

    //CBB payment tags end

    /* MOP Universal Tags - After removing _HS and _TAB - Start
     */

    //Payments LHN analytics - Start
    public static final String PAYMENT_AUTO_PAYMENT_PROP1 = "NavDrawerItem_Automatic Payments";
    public static final String PAYMENT_AUTO_PAYMENT_EVAR35 = "NavDrawerItem_Automatic Payments";
    public static final String PAYMENT_AUTO_PAYMENT_LINK = "lnk_o";
    public static final String PAYMENT_AUTO_PAYMENT_PEV1 = "NavDrawerItem_Automatic Payments";

    public static final String PAYMENT_CHANGE_DATE_PROP1 = "NavDrawerItem_Change Payment Due Date";
    public static final String PAYMENT_CHANGE_DATE_EVAR35 = "NavDrawerItem_Change Payment Due Date";
    public static final String PAYMENT_CHANGE_DATE_LINK = "lnk_o";
    public static final String PAYMENT_CHANGE_DATE_PEV1 = "NavDrawerItem_Change Payment Due Date";
    //Payments LHN analytics - end
    // MOP
    static final String MOP_EXTRAS_OVERLAY = "MOP_Extras-pg-Overlay";
    static final String MOP_SUMMARY_PAGE = "MOP_Extras_DefaultView-pg";
    static final String MOP_DEFAULT_SEARCH_EXPANDED = "Mop_Extras_DefaultView_SearchExpanded";
    static final String MOP_SEARCH_KEYWORD = "search keywords";
    static final String MOP_DETAIL_LEAVING_APP = "Mop_DetailView_LeavingApp_Pg-Overlay";
    static final String MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_PROP1 = "ANDROID_MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_TXT";
    static final String MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_PE = "lnk_o";
    static final String MOP_DETAILS_PART_TAP_HERE_TO_REDEEM_PEV1 = "Android_mop_details_part_tap_here_to_redeem_txt";
    static final String MOP_DETAILS_PART_2222_TXT_PREV1 = "ANDROID_MOP_DETAILS_PART_2222_TXT";
    static final String MOP_DETAILS_PART_2222_TXT_PE = "lnk_o";
    static final String MOP_DETAILS_PART_2222_TXT_PEV1 = "Android_mop_details_part_2222_txt";
    static final String MOP_LEAVING_APP_CONTINUE_BTN_PREV1 = "ANDROID_MOP_LEAVING_APP_CONTINUE_BTN";
    static final String MOP_LEAVING_APP_CONTINUE_BTN_PE = "lnk_o";
    static final String MOP_LEAVING_APP_CONTINUE_BTN_PEV1 = "Android_mop_leaving_app_continue_btn";
    static final String ANDROIDHS_MOP_SAVE_TAB_PG_OVERLAY = "Android_MOP_SaveTab-pg-Overlay";
    // MOP1C
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_OFFERS_PROP1 = "ANDROID_MOP_ALL_OFFERS_ALL_OFFERS_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_OFFERS_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_OFFERS_PEV1 = "Android_MOP_all_offers_all_offers_btn";

    static final String ANDROIDHS_MOP_ALL_OFFERS_SEARCH_PROP1 = "ANDROID_MOP_ALL_OFFERS_SEARCH_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SEARCH_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SEARCH_PEV1 = "Android_MOP_all_offers_search_btn";

    static final String ANDROIDHS_MOP_ALL_OFFERS_EXPLORE_PROP1 = "ANDROID_MOP_ALL_OFFERS_EXPLORE_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_EXPLORE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_EXPLORE_PEV1 = "Android_MOP_all_offers_explore_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SAVED_PROP1 = "ANDROID_MOP_ALL_OFFERS_SAVED_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SAVED_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SAVED_PEV1 = "Android_MOP_all_offers_saved_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_PROP1 = "ANDROID_MOP_ALL_OFFERS_ALL_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ALL_PEV1 = "Android_MOP_all_offers_all_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_IN_STORE_PROP1 = "ANDROID_MOP_ALL_OFFERS_IN_STORE_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_IN_STORE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_IN_STORE_PEV1 = "Android_MOP_all_offers_in_store_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ONLINE_PROP1 = "ANDROID_MOP_ALL_OFFERS_ONLINE_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ONLINE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_ONLINE_PEV1 = "Android_MOP_all_offers_online_btn";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SORT_PROP1 = "ANDROID_MOP_ALL_OFFERS_SORT_BTN";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SORT_PE = "lnk_o";
    static final String ANDROIDHS_MOP_ALL_OFFERS_SORT_PEV1 = "Android_MOP_all_offers_sort_btn";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_PROP1 = "ANDROID_MOP_EXTRAS_SAVE_BADGE";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_MOP = "MOP:";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_EXTRAS_SAVE_BADGE_PEV1 = "Android_MOP_Extras_Save Badge";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_NEARBY_LOC_PROP1 = "ANDROID_MOP_DETAILS_COUPON_NEARBY_LOC_BTN";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_NEARBY_LOC_PE = "lnk_o";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_NEARBY_LOC_PEV1 = "Android_MOP_details_coupon_nearby_loc_btn";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_ADD_TO_CAL_PROP1 = "ANDROID_MOP_DETAILS_COUPON_ADD_TO_CAL_BTN";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_ADD_TO_CAL_PE = "lnk_o";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_ADD_TO_CAL_PEV1 = "Android_MOP_details_coupon_nearby_loc_btn";

    static final String ANDROIDHS_MOP_DETAILS_COUPON_SAVE_PROP1 = "ANDROID_MOP_DETAILS_COUPON_SAVE_BTN";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_SAVE_PE = "lnk_o";
    static final String ANDROIDHS_MOP_DETAILS_COUPON_SAVE_PEV1 = "Android_MOP_details_coupon_nearby_loc_btn";

    // MOP1D

    /* Pagenames */
    static final String ANDROIDHS_DEALS_HOME = "ANDROID_Deals_Home_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_NAVFEATURED = "ANDROID_Deals_Home_NavFeatured_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_INSTORE = "ANDROID_Deals_Home_InStore_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_ONLINE = "ANDROID_Deals_Home_Online_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_SEARCH = "ANDROID_Deals_Home_Search_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_EXPLORE = "ANDROID_Deals_Explore_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_EXPLOREALL = "ANDROID_Deals_Explore_All_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_EXPLORECATEGORY = "ANDROID_Deals_Explore_Category_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_THEME = "ANDROID_Deals_Explore_Theme_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_SAVED = "ANDROID_Deals_Explore_Saved_Pre-login-pg";
    static final String ANDROIDHS_DEALS_HOME_SAVEDUNSAVE = "ANDROID_Deals_Explore_Saved_Unsave_Pre-login-pg";
    static final String ANDROIDHS_PRIVACYTERMS = "ANDROID_PrivacyTerms-pg";
    static final String ANDROIDHS_PROVIDEFEEDBACK = "ANDROID_ProvideFeedback-pg";
    static final String ANDROIDHS_DEALS_HOME_DETAIL = "ANDROID_Deals_Detail_Pre-login-pg";

    /**
     * start :slende : 14.7 MOP Tibco / UI Updates - Deal Detail View
     * Enhancements
     */
    static final String ANDROIDHS_DEALS_DETAIL_REDEEMSWIPE_PAGE = "ANDROID_Deals_Detail_RedeemSwipe_";
    static final String EVAR35_DEALS_DETAIL_REDEEMSWIPE = "DealsDetail:RedeemSwipe";
    /**
     * end :slende : 14.7 MOP Tibco / UI Updates - Deal Detail View Enhancements
     */

    static final String EVAR65_DEALSHOME_DEFAULT_ALL = "Pre-login:DealsHome:Default:All";
    static final String EVAR65_DEALSHOME_DEFAULT_ALL_SORT = "Pre-login:DealsHome:Default:All:Sort-";
    static final String EVAR65_DEALSHOME_DEFAULT_NAVIGATEFEATURED = "Pre-login:DealsHome:Default:NavigateFeatured";
    static final String EVAR65_DEALSHOME_INSTORE = "Pre-login:DealsHome:In-Store";
    static final String EVAR65_DEALSHOME_INSTORE_SORT = "Pre-login:DealsHome:In-Store:Sort-";
    static final String EVAR65_DEALSHOME_ONLINE = "Pre-login:DealsHome:Online";
    static final String EVAR65_DEALSHOME_ONLINE_SORT = "Pre-login:DealsHome:Online:Sort-";
    static final String EVAR65_DEALSHOME_SEARCH = "Pre-login:DealsHome:Search:";
    static final String EVAR65_DEALSEXPLORE_ALL = "Pre-login:DealsExplore:All";
    static final String EVAR65_DEALSEXPLORE_CATEGORY = "Pre-login:DealsExplore:Category:";
    static final String EVAR65_DEALSEXPLORE_THEME = "Pre-login:DealsExplore:Theme:";
    static final String EVAR65_DEALSEXPLORE_SAVED = "Pre-login:DealsExplore:Saved";

    static final String EVENT79 = "event79";

    //Added in 7.2 START
    public static final String REDEMPTION_HISTORY_LHN_prop1 = "NavDrawerItem_Redemption History";
    public static final String REDEMPTION_HISTORY_LHN_pev1 = "NavDrawerItem_Redemption History";
    public static final String REDEMPTION_HISTORY_ECert_Page = "redeem_ecertificates_history-pg";
    // 7.2 END

    /*
     * static final String EVAR35_DISCOVERDEALS_PRIVACYTERMS=
     * "Pre-login:DiscoverDeals:PrivacyTerms"; static final String
     * EVAR35_DISCOVERDEALS_PROVIDEFEEDBACK=
     * "Pre-login:DiscoverDeals:ProvideFeedback";
     */

    // MOP1D
    /* MOP Universal Tags - After removing _HS and _TAB - end
     */
    public static final String NAV_DRAWER_ITEM_STATMET_CREDIT = "NavDrawerItem_Statement Credit";
    public static final String GET_STATEMENT_CREDIT_STEP1 = "Get_a_Statement_Credit_Step1-pg";
    public static final String GET_STATEMENT_CREDIT_STEP2 = "statementCredit2-pg";
    public static final String STATEMENT_CREDIT_STEP_CANCEL = "statementCreditConfirmCancelTrans-pg";
    public static final String REDEEM_STATEMENT_CREDIT_CANCEL_BTN = "REDEEM_STATEMENT_CREDIT_CANCEL_BTN";
    public static final String REDEEM_STATEMENT_CREDIT_CONTINUE_BTN = "REDEEM_STATEMENT_CREDIT_CONTINUE_BTN";
    public static final String REDEEM_STATEMENT_CREDIT_CONFIRM_BTN = "REDEEM_STATEMENT_CREDIT_CONFIRM_BTN";
    public static final String REDEEM_STATEMENT_CREDIT_CONFIRM_CANCEL_BTN = "REDEEM_STATEMENT_CREDIT_CONFIRM_CANCEL_BTN";
    public static final String REDEEM_STATEMENT_CREDIT_SAVE_PHOTO_BTN = "REDEEM_STATEMENT_CREDIT_SAVE_TO_PHOTOS_BTN";
    public static final String REDEEM_STATEMENT_CREDIT_SAVE_PHOTO = "redeem_statement_credit_save_photos-pg";
    public static final String LNK_O = "lnk_o";
    public static final String STATEMENT_CREDIT_CANCEL = "statementCreditCancelTrans-pg";
    public static final String STATEMENT_CREDIT_STEP3 = "statementCredit3-pg";
    public static final String MOBILE_REDEMPTION = "MobileRedemption|%1s";
    public static final String CBB_AMT = "CashbackBonus;CBB:";
    public static final String EVENT3 = "event3";
    public static final String EVENT53 = "event53";
    public static final String EVENT3N53 = EVENT3 + "," + EVENT53;
    public static final String CBB_AMT_EVENT_AMT = "CashbackBonus;CBB:%1$s;;;" + EVENT53 + "=%2$s";
    public static final String NAV_DRAWER_ITEM_REDEEM_CBB = "NavDrawerSection_NavDrawerItem_Cashback Bonus";

    //For US42160 - Direct Deposit - START
    public static final String DIRECT_DEPOSIT_LHN_prop1 = "NavDrawerItem_Electronic Deposit";
    public static final String DIRECT_DEPOSIT_LHN_pe = "lnk_o";
    public static final String DIRECT_DEPOSIT_LHN_pev1 = "NavDrawerItem_Electronic Deposit";
    public static final String DIRECT_DEPOSIT_REVIEW_LANDING_pageName = "Make_a_Direct_Deposit_Step1-pg";
    public static final String DIRECT_DEPOSIT_REVIEW_CONTINUE_BTN_ERROR_prop10 = "MobileRedemption|%1$s";
    public static final String DIRECT_DEPOSIT_REVIEW_CONTINUE_BTN_prop1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CONTINUE_BTN";
    public static final String DIRECT_DEPOSIT_REVIEW_CONTINUE_BTN_pe = "lnk_o";
    public static final String DIRECT_DEPOSIT_REVIEW_CONTINUE_BTN_pev1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CONTINUE_BTN";
    public static final String DIRECT_DEPOSIT_VERIFY_PAGELOAD_events = "event3";
    public static final String DIRECT_DEPOSIT_VERIFY_products = "CashbackBonus;CBB:%1$s";
    public static final String DIRECT_DEPOSIT_VERIFY_pageName = "directDeposit2-pg";
    public static final String DIRECT_DEPOSIT_VERIFY_CONFIRM_BTN_prop1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CONFIRM_BTN";
    public static final String DIRECT_DEPOSIT_VERIFY_CONFIRM_BTN_pe = "lnk_o";
    public static final String DIRECT_DEPOSIT_VERIFY_CONFIRM_BTN_pev1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CONFIRM_BTN";
    public static final String DIRECT_DEPOSIT_VERIFY_CANCEL_BTN_prop1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CANCEL_BTN";
    public static final String DIRECT_DEPOSIT_VERIFY_CANCEL_BTN_pe = "lnk_o";
    public static final String DIRECT_DEPOSIT_VERIFY_CANCEL_BTN_pev1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CANCEL_BTN";
    public static final String DIRECT_DEPOSIT_VERIFY_CANCEL_BTN_pageName = "directDepositCancelTrans-pg";
    public static final String DIRECT_DEPOSIT_VERIFY_CONFIRM_CANCEL_BTN_prop1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CONFIRM_CANCEL_BTN";
    public static final String DIRECT_DEPOSIT_VERIFY_CONFIRM_CANCEL_BTN_pe = "lnk_o";
    public static final String DIRECT_DEPOSIT_VERIFY_CONFIRM_CANCEL_BTN_pev1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_CONFIRM_CANCEL_BTN";
    public static final String DIRECT_DEPOSIT_VERIFY_CONFIRM_CANCEL_BTN_pageName = "directDepositConfirmCancelTrans-pg";
    public static final String DIRECT_DEPOSIT_CONFIRMATION_PAGELOAD_events = "event3,event53";
    public static final String DIRECT_DEPOSIT_CONFIRMATION_PAGELOAD_products = "CashbackBonus;CBB:%1$s;;;event53=%2$s";
    public static final String DIRECT_DEPOSIT_CONFIRMATION_PAGELOAD_pageName = "directDeposit3-pg";
    public static final String DIRECT_DEPOSIT_CONFIRMATION_SAVETOPHOTOS_BTN_prop1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_SAVE_TO_PHOTOS_BTN";
    public static final String DIRECT_DEPOSIT_CONFIRMATION_SAVETOPHOTOS_BTN_pe = "lnk_o";
    public static final String DIRECT_DEPOSIT_CONFIRMATION_SAVETOPHOTOS_BTN_pev1 = "HANDSET_REDEEM_DIRECT_DEPOSIT_SAVE_TO_PHOTOS_BTN";
    public static final String DIRECT_DEPOSIT_SAVETOPHOTOS_PAGELOAD_pageName = "redeem_direct_deposit_save_photos-pg";
    //For US42160 - Direct Deposit - END

    //added in 7.2
    //partner gift card
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_REST_PEV1 = "HANDSET_REDEEM_PGC_REST_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_HOME_PEV1 = "HANDSET_REDEEM_PGC_HOME_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_ENTERTAIN_PEV1 = "HANDSET_REDEEM_PGC_ENTERTAIN_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_HEALTH_PEV1 = "HANDSET_REDEEM_PGC_HLTH_BEAU_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_SPORTS_PEV1 = "HANDSET_REDEEM_PGC_SPRTS_REC_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_GIFTS_PEV1 = "HANDSET_REDEEM_PGC_GIFTS_LNK";
    public static final String PGC_HANDSET_REDEEM_PGC_ECERT_TRAVEL_PEV1 = "HANDSET_REDEEM_PGC_TRAVEL_LNK";

    public static final String LHN_PARTNER_GIFTCARD_PROP1 = "NavDrawerItem_Partner Gift Cards & eCerts";
    public static final String LHN_PARTNER_GIFTCARD_PEV1 = "NavDrawerItem_Partner Gift Cards & eCerts";
    public static final String PARTNER_GIFTCARD_DROPDOWN = "redeem_passbook_modal-pg";
    public static final String PARTNER_GIFTCARD_BROWSEALL_PEV1 = "HANDSET_REDEEM_PGC_ECERT_BROWSE_ALL_LNK";
    public static final String PARTNER_GIFTCARD_ECERT_PEV1 = "HANDSET_REDEEM_PGC_ECERT_ECERT_LNK";
    public static final String PARTNER_GIFTCARD_BESTVALUE_PEV1 = "HANDSET_REDEEM_PGC_BEST_VALUE_LNK";
    public static final String HANDSET_REDEEM_PGC_BEST_VALUE_LNK = "HANDSET_REDEEM_PGC_BEST_VALUE_LNK";
    public static final String HANDSET_REDEEM_PGC_BEST_VALUE_PAGENAME = "best-value";
    public static final String HANDSET_REDEEM_PGC_DEPT_PEV1 = "HANDSET_REDEEM_PGC_ECERT_DEPT_STORE_LNK";
    public static final String PARTNER_GIFTCARD_REST_PAGENAME = "redeem-partner-cat-restaurants-pg";
    public static final String PARTNER_GIFTCARD_HOMEAUTO_PAGENAME = "redeem-partner-cat-home_auto-pg";
    public static final String PARTNER_GIFTCARD_FASHION_PAGENAME = "redeem-partner-cat-fashion-pg";
    public static final String PARTNER_GIFTCARD_DEPT_PAGENAME = "redeem-partner-cat-department_stores-pg";
    public static final String PARTNER_GIFTCARD_ENTERTAIN_PAGENAME = "redeem-partner-cat-entertainment-pg";
    public static final String PARTNER_GIFTCARD_HEALTH_PAGENAME = "redeem-partner-cat-health_beauty-pg";
    public static final String PARTNER_GIFTCARD_SPORTS_PAGENAME = "redeem-partner-cat-sports_recreation-pg";
    public static final String PARTNER_GIFTCARD_GIFT_PAGENAME = "redeem-partner-cat-gifts-pg";
    public static final String PARTNER_GIFTCARD_TRAVEL_PAGENAME = "redeem-partner-cat-travel-pg";
    public static final String PARTNER_GIFTCARRD_ECERTS_EDIT_CONTINUTE_BTN_PROP1 = "HANDSET_REDEEM_PGC_ECERT_CONTINUE_BTN";
    public static final String PARTNER_GIFTCARRD_ECERTS_EDIT_CONTINUTE_BTN_PEV1 = "HANDSET_REDEEM_PGC_ECERT_CONTINUE_BTN";
    public static final String PARTNER_GIFTCARD_ECERTS_PAGENAME = "redeemECert2-pg";
    public static final String PARTNER_ECERTS_REDEEM_BTN_PROP1 = "HANDSET_REDEEM_PGC_ECERT_REDEEM_BTN";
    public static final String PARTNER_ECERTS_REDEEM_BTN_PEV1 = "HANDSET_REDEEM_PGC_ECERT_REDEEM_BTN";
    public static final String PARTNER_ECERTS_REVIEW_PG_EVENT = "event3";
    public static final String PARTNER_ECERTS_REVIEW_PG_NAME = "redeemECert3-pg";
    public static final String ECERTS_CONFIRMATION_PAGENAME = "redeemECert4-pg";
    public static final String ECERTS_SAVETO_PHOTOS_BTN_PROP1 = "HANDSET_REDEEM_PGC_ECERT_SAVE_TO_PHOTOS_BTN";
    public static final String ECERTS_SAVETO_PHOTOS_PEV1 = "HANDSET_REDEEM_PGC_ECERT_SAVE_TO_PHOTOS_BTN";
    public static final String ECERTS_VERIFY_CANCEL_BUTTON = "HANDSET_REDEEM_PGC_ECERT_CANCEL_BTN";
    public static final String ECERTS_SAVE_PHOTOS_PAGENAME = "ecart-save-pin";
    public static final String ECERTS_TERMS_CONDITIONS_PAGENAME = "redm-merchant-tnc";
    public static final String GIFTCARDS_CONTINUE_BTN_PROP1 = "HANDSET_REDEEM_PGC_GIFT_CONTINUE_BTN";
    public static final String GIFTCARDS_CONTINUE_BTN_PEV1 = "HANDSET_REDEEM_PGC_GIFT_CONTINUE_BTN";
    public static final String GIFTCARDS_REDEEM_BTN_VERIFY_PROP1 = "HANDSET_REDEEM_PGC_GIFT_REDEEM_BTN";
    public static final String GIFTCARDS_REDEEM_BTN_VERIFY_PEV1 = "HANDSET_REDEEM_PGC_GIFT_REDEEM_BTN";
    public static final String GIFTCARD_VERIFY_PAGE_NAME = "gift-card-verify-partner";
    public static final String GIFTCARD_CONFIRMATION_PAGE_NAME = "confirm-gift-card-partner";
    public static final String GIFT_CANCEL_BUTTON_PROP1 = "HANDSET_REDEEM_PGC_GIFT_CANCEL_BTN";
    public static final String GIFT_CANCEL_BUTTON_PEV1 = "HANDSET_REDEEM_PGC_GIFT_CANCEL_BTN";
    //till here
    //quickview universal migration
    public static final String LOGIN_QUICKVIEW_BANK = "Login_QuickView_Bank";
    public static final String LOGIN_QUICKVIEW_CARD = "Login_QuickView_Card";
    public static final String LOGIN_QUICKVIEW_BAND_CARD = "Login_QuickView_Bank_And_Card";
    public static final String LOGIN_QUICKVIEW_NOT_ENROLLED = "Login_QuickView_Not_Enrolled";
    public static final String PASSCODE_LOCKOUT = "Passcode_Locked_Out-pg-Overlay";
    public static final String QUICKVIEW_VIEW_GLOBAL_OUTAGE = "QuickView_Global_Outage:";
    public static final String QUICKVIEW_VIEW_DISABLE = "QuickView_Disabled_Error:";


    //Android Pay tags
    public static final String ANDROID_PAY_SETUP_PAGE = "Android_Pay_Setup-pg";
    public static final String ANDROID_PAY_SETUP_GET_STARTED_BTN = "ANDROID_PAY_SETUP_GET_STARTED_BTN";
    public static final String ANDROID_PAY_LNK_O = "lnk_o";
    public static final String ANDROID_PAY_SETUP_FAQ_LNK = "ANDROID_PAY_SETUP_FAQ_LNK";
    public static final String ANDROID_PAY_REQUIREMENTS_NOT_MET_PAGE = "Android_Pay_Requirement_Not_Met-pg";
    public static final String ANDROID_PAY_REQUIREMENT_NOT_MET_FAQ_LNK = "ANDROID_PAY_REQUIREMENT_NOT_MET_FAQ_LNK";
    public static final String ANDROID_PAY_REMOVE_CARD_LANDING = "Android_Pay_Remove_Card_Landing-pg";
    public static final String ANDROID_PAY_EVENT9 = "event9";
    public static final String ANDROID_PAY_EVENT22 = "event22";
    public static final String ANDROID_PAY_REMOVE_CARD_CONFIRMATION_MODAL = "Android_Pay_Removed_Card_Confirmation_Modal-pg";
    public static final String ANDROID_PAY_MY_PROP5 = "ANDROID_PAY_REMOVE_CARD";
    public static final String ANDROID_PAY_AC_HOME_PROVISIONING_ADD_CARD_BTN = "ANDROID_PAY_AC_HOME_PROVISIONING_ADD_CARD_BTN";
    public static final String ANDROID_PAY_AC_HOME_SET_AS_DEFAULT_BTN = "ANDROID_PAY_AC_HOME_SET_AS_DEFAULT_BTN";
    public static final String ANDROID_PAY_CARDS_SET_AS_DEFAULT_BTN = "ANDROID_PAY_CARDS_SET_AS_DEFAULT_BTN";
    public static final String ANDROID_PAY_FREEZE_CARD_LANDING = "Android_Pay_Freeze_Card_Landing-pg";
    public static final String ANDROID_PAY_FREEZE_CARD_MY_EVAR5 = "ANDROID_PAY_FREEZE_CARD";
    public static final String ANDROID_PAY_FROZEN_CARD_CONFIRMATION_MODAL = "Android_Pay_Frozen_Card_Confirmation_Modal-pg";
    public static final String ANDROID_PAY_UNFREEZE_CARD_LANDING = "Android_Pay_UnFreeze_Card_Landing-pg";
    public static final String ANDROID_PAY_UNFREEZE_CARD_MY_EVAR5 = "ANDROID_PAY_UNFREEZE_CARD";
    public static final String ANDROID_PAY_UNFROZEN_CARD_CONFIRMATION_MODAL = "Android_Pay_UnFrozen_Card_Confirmation_Modal-pg";
    public static final String ANDROID_PAY_WHATS_NEW_GET_STARTED_BTN = "ANDROID_PAY_WHATS_NEW_GET_STARTED_BTN";
    public static final String ANDROID_PAY_WHATS_NEW_PAGE = "Android_Pay_Whats_New-pg";
    public static final String ANDROID_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN = "ANDROID_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN";
    public static final String ANDROID_PAY_CARD_TYPE = "ANDROID_PAY_CARD_TYPE:";
    public static final String ANDROID_PAY_PROVISIONING_ACTIVATE_MANAGE_CARD_LNK = "ANDROID_PAY_PROVISIONING_ACTIVATE_MANAGE_CARD_LNK";
    public static final String ANDROID_PAY_DEFAULT_ACTIVATE_MANAGE_CARD_LNK = "ANDROID_PAY_DEFAULT_ACTIVATE_MANAGE_CARD_LNK";

    public static final String ANDROID_PAY_MANAGE_CARDS_NOT_ACTIVATED_PHONE_NUM_LNK = "ANDROID_PAY_MANAGE_CARDS_NOT_ACTIVATED_PHONE_NUM_LNK";
    public static final String ANDROID_PAY_ACTIVE_DEVICE_DETAILS_PG_LOAD = "Android_Pay_Manage_Cards_Card_Active_Device_Details-pg";
    public static final String ANDROID_PAY_NOT_ACTIVATED_DEVICE_DETAILS_PG_LOAD = "Android_Pay_Manage_Cards_Card_Not_Activated_Device_Details-pg";
    public static final String ANDROID_PAY_REMIDER_PG_LOAD = "Android_Pay_Reminder-pg";
    public static final String ANDROID_PAY_REMOVE_CARD_SUCCESSFUL_PG_LOAD = "Android_Pay_Remove_Card_Successful-pg";
    public static final String ANDROID_PAY_FREEZE_ANDROID_PAY_BTN = "ANDROID_PAY_FREEZE_ANDROID_PAY_BTN";
    public static final String ANDROID_PAY_UNFREEZE_CARD_ANDROID_PAY_BTN = "ANDROID_PAY_UNFREEZE_CARD_ANDROID_PAY_BTN";
    public static final String ANDROID_PAY_REMOVE_CARD_ANDROID_PAY_BTN = "ANDROID_PAY_REMOVE_CARD_ANDROID_PAY_BTN";
    public static final String ANDROID_PAY_UNFREEZE_CARD_SUCCESSFUL_PG = "Android_Pay_UnFreeze_Card_Successful-pg";
    public static final String ANDROID_PAY_FREEZE_CARD_SUCCESSFUL_PG = "Android_Pay_Freeze_Card_Successful-pg";
    public static final String ANDROID_PAY_LP_REMOVE_CARD_LNK = "ANDROID_PAY_LP_REMOVE_CARD_LNK";
    public static final String ANDROID_PAY_LP_FREEZE_LNK = "ANDROID_PAY_LP_FREEZE_LNK";
    public static final String ANDROID_PAY_LP_UNFREEZE_ANDROID_PAY_LNK = "ANDROID_PAY_LP_UNFREEZE_ANDROID_PAY_LNK";
    public static final String ANDROID_PAY_SETUP_SELECT_CARD_PG = "Android_Pay_Setup_Select_Card-pg";
    public static final String ANDROID_PAY_SETUP_SELECTCARD_LNK = "ANDROID_PAY_SETUP_SELECTCARD_LNK";
    public static final String ANDROID_PAY_SETUP_ELIGIBLE_USER_PG = "Android_Pay_Setup_Eligible_User-pg";
    public static final String ANDROID_PAY_SETUP_ELIGIBLE_USER = "ANDROID_PAY_SETUP_ELIGIBLE_USER";
    public static final String ANDROID_PAY_SETUP_CANCEL_MODAL_PAGE = "Android_Pay_Setup_Cancel_Modal-pg";
    public static final String ANDROID_PAY_SETUP_CANCELMODAL_YES_LNK = "ANDROID_PAY_SETUP_CANCELMODAL_YES_LNK";
    public static final String ANDROID_PAY_SETUP_CANCELMODAL_NO_BTN = "ANDROID_PAY_SETUP_CANCELMODAL_NO_BTN";
    public static final String ANDROID_PAY_SETUP_TERMSA_AND_CONDITIONS_PG = "Android_Pay_Setup_Terms_and_Conditions-pg";
    public static final String ANDROID_PAY_SETUP_TC_AGREE_BTN = "ANDROID_PAY_SETUP_TC_AGREE_BTN";
    public static final String ANDROID_PAY_SETUP_TC_DISAGREE_LNK = "ANDROID_PAY_SETUP_TC_DISAGREE_LNK";
    public static final String ANDROID_PAY_REMINDER_PAGE = "Android_Pay_Reminder-pg";
    public static final String CARD_LANDING_CARD_LNK = "CARD_LANDING_CARD_LNK";
    public static final String FREEZE_ACCOUNT = "FREEZE_ACCOUNT";
    public static final String ACCOUNT_FREEZE_BTN = "ACCOUNT_FREEZE_BTN";
    public static final String FREEZE_ACCOUNT_FAQ_LNK = "FREEZE_ACCOUNT_FAQ_LNK";
    public static final String ACCOUNT_FROZEN_SUCCESSFUL_PG = "Account_Frozen_Successful_pg";
    public static final String MANAGE_FROZEN_ACCOUNT_BTN = "MANAGE_FROZEN_ACCOUNT_BTN";

    public static final String REPORT_LOST_STOLEN_IMPORTANT_INFO_PG = "Report_Lost_Stolen_Important_Info-pg";
    public static final String REPORT_LOST_STOLEN_LANDING_IMP_INFO_CONFIRM_BTN = "REPORT_LOST_STOLEN_IMPORTANT_INFO_CONFIRM_BTN";
    public static final String REPORT_LOST_STOLEN_CANCEL_IMPORTANT_INFO_LOST_STOLEN_BTN = "REPORT_LOST_STOLEN_IMPORTANT_INFO_CANCEL_LNK";
    public static final String REPORT_LOST_STOLEN_SUCCESS_LOGOUT_BTN = "REPORT_LOST_STOLEN_CONFIRMATION_MODAL_LOGOUT_BTN";
    public static final String REPORT_LOST_STOLEN_SUCCESSFUL_MODAL_PG = "Report_Lost_Stolen_Confirmation_Modal-pg";

    /*Overnight Shipping Tags*/
    public static final String LOST_STOLEN_STND_OVRNHT_SHIPPING_TYPE_PROP5 =  "Lost Stolen Card Delivery Type : Standard and Fedex Overnight Shipping";
    public static final String LOST_STOLEN_STANDARD_SHIPPING_TYPE_PROP5 =  "Lost Stolen Card Delivery Type : Standard  Shipping";
    public static final String LOST_STOLEN_SHIPPING_EVENT22 =  "event22";


    public static final String REPORT_LOST_STOLEN = "REPORT_LOST_STOLEN";
    public static final String REPORT_LOST_STOLEN_LANDING_CONTINUE_BTN = "REPORT_LOST_STOLEN_LANDING_CONTINUE_BTN";
    public static final String REPORT_LOST_CARD_LANDING_PG = "Report_Lost_Card_Landing-pg";

    public static final String ACCOUNT_UNFREEZE_BTN = "ACCOUNT_UNFREEZE_BTN";
    public static final String UNFREEZE_ACCOUNT = "UNFREEZE_ACCOUNT";
    public static final String UNFREEZE_ACCOUNT_PG = "Unfreeze_Account-pg";
    public static final String UNFREEZE_ACCOUNT_CONFIRMATION_PG = "Unfreeze_Account_Confirmation-pg";
    public static final String ANDROID_PAY_HIGHLIGHTED_PG = "Android_Pay_Highlighted-pg";
    public static final String CARD_DETAILS_REPLACE_CARD_BTN = "CARD_DETAILS_REPLACE_CARD_BTN";
    public static final String CARD_DETAIL_FREEZE_CARD_LNK = "CARD_DETAIL_FREEZE_CARD_LNK";
    public static final String CARD_DETAIL_UNFREEZE_CARD_LNK = "CARD_DETAIL_UNFREEZE_CARD_LNK";
    public static final String CARD_DETAIL_REPORT_LOST_STOLEN_LNK = "CARD_DETAIL_REPORT_LOST_STOLEN_LNK";
    public static final String CARD_DETAILED_PG = "Card_Detailed_pg";
    public static final String UNFREEZE_CARD_BTN = "UNFREEZE_CARD_BTN";
    public static final String FREEZE_CARD_BTN = "FREEZE_CARD_BTN";
    public static final String FREEZE_CARD_SUCCESSFUL_PG = "Freeze_Card_Successful-pg";
    public static final String UNFREEZE_CARD_SUCCESSFUL_PG = "UnFreeze_Card_Successful-pg";
    public static final String FREEZE_CARD_LANDING_PG = "Freeze_Card_Landing-pg";
    public static final String FREEZE_CARD = "FREEZE_CARD";
    public static final String UNFREEZE_CARD = "UNFREEZE_CARD";
    public static final String UNFREEZE_CARD_LANDING_PG = "UnFreeze_Card_Landing-pg";
    public static final String REPORT_LOST_STOLEN_LNK = "REPORT_LOST_STOLEN_LNK";
    public static final String UNFREEZE_ACCOUNT_LNK = "UNFREEZE_ACCOUNT_LNK";
    public static final String FREEZE_ACCOUNT_LNK = "FREEZE_ACCOUNT_LNK";
    public static final String MANAGECARDS_ANDROID_PAY_ADDCARD_LNK = "MANAGECARDS_ANDROID_PAY_ADDCARD_LNK";
    public static final String ANDROID_PAY_SETUP_SUCCESSFUL_PG = "Android_Pay_Setup_Successful-pg";
    public static final String REPLACE_CARD = "REPLACE_CARD";
    public static final String REPLACE_CARD_BTN = "REPLACE_CARD_BTN";
    public static final String REPLACE_CARD_SUCCESSFUL_PG = "Replace_Card_Successful-pg";
    public static final String ANDROID_PAY_REMINDER_GET_STARTED_BTN = "ANDROID_PAY_REMINDER_GET_STARTED_BTN";
    public static final String ANDROID_PAY_REMINDER_NOTHANKS_LNK = "ANDROID_PAY_REMINDER_NOTHANKS_LNK";
    public static final String ANDROID_PAY_REMINDER_LATER_LNK = "ANDROID_PAY_REMINDER_LATER_LNK";
    public static final String ANDROID_PAY_SETUP_CARD_NOT_ACTIVATED_PG = "Android_Pay_Setup_Card_Not_Activated-pg";
    public static final String ANDROID_PAY_SETUP_ACTIVATE_LNK = "ANDROID_PAY_SETUP_ACTIVATE_LNK";
    public static final String ACCOUNT_CONFIRMATION_UNFREEZE_BTN = "ACCOUNT_CONFIRMATION_UNFREEZE_BTN";
    public static final String ACCOUNT_CONFIRMATION_FREEZE_BTN = "ACCOUNT_CONFIRMATION_FREEZE_BTN";
    public static final String ACCOUNT_FROZEN_CONFIRMATION_MODAL_PG = "Account_Frozen_Confirmation_Modal-pg";
    //US45590- Passcode modal -START
    public static final String PASSCODE_MODAL_CLOSE_LINK = "LOGIN_SETTINGS_MODAL_SETUP_PASSCODE_CLOSE_LNK";
    public static final String PASSCODE_MODAL_GET_STARTED_BUTTON = "LOGIN_SETTINGS_MODAL_SETUP_PASSCODE_GET_STARTED_BTN";
    //END


    //US53328- OnBoardWiz -START

    public static final String ONBOARDWIZ_LANDING_PAGE_NAME = "Onboarding_Wizard_Welcome-pg";

    public static final String ONBOARDWIZ_LANDING_GET_STARTED_PROP1 = "ONBOARDING_WIZARD_WELCOME_GET_STARTED_BTN";
    public static final String ONBOARDWIZ_LANDING_GET_STARTED_PROP13 = "Onboarding_Wizard_Welcome-pg";
    public static final String ONBOARDWIZ_LANDING_GET_STARTED_PE = "lnk_o";
    public static final String ONBOARDWIZ_LANDING_PAGE_GET_STARTED_PEV1 = "ONBOARDING_WIZARD_WELCOME_GET_STARTED_BTN";

    public static final String ONBOARDWIZ_LANDING_EXIT_LINK_PROP1 = "EXIT_SETUP_LNK";
    public static final String ONBOARDWIZ_LANDING_EXIT_LINK_PROP13 = "";
    public static final String ONBOARDWIZ_LANDING_EXIT_LINK_PE = "lnk_o";
    public static final String ONBOARDWIZ_LANDING_EXIT_LINK_PEV1 = "EXIT_SETUP_LNK";
    public static final String ONBOARDWIZ_LANDING_EXIT_LINK_VAR35 = "EXIT_SETUP_LNK";

    //passcode enable
    public static final String ONBOARDWIZ_PASSCODE_ENABLE_PAGE_NAME = "Passcode_Setup_Intro-pg";
    public static final String ONBOARDWIZ_PASSCODE_ENABLE_PROP1 = "PASSCODE_SETUP_ENABLE_BTN";
    public static final String ONBOARDWIZ_PASSCODE_ENABLE_PROP13 = "Passcode_Setup_Intro-pg";
    public static final String ONBOARDWIZ_PASSCODE_ENABLE_PE = "lnk_o";
    public static final String ONBOARDWIZ_PASSCODE_ENABLE_PEV1 = "PASSCODE_SETUP_ENABLE_BTN";

    //create passcode

    public static final String ONBOARDWIZ_ENTER_PASSCODE_PAGE_NAME = "Passcode_Setup_Enter_Passcode-pg";

    public static final String ONBOARDWIZ_CREATE_PASSCODE_PAGE_NAME = "Passcode_Setup_Create_Passcode-pg";
    public static final String ONBOARDWIZ_PASSCODE_GUIDELINES_PROP1 = "PASSCODE_SETUP_STEP2_PASSCODE_GUIDELINES_LNK";
    public static final String ONBOARDWIZ_PASSCODE_GUIDELINES_PROP13_CREATE = "Passcode_Setup_Create_Passcode-pg";
    public static final String ONBOARDWIZ_PASSCODE_GUIDELINES_PROP13_ENTER = "Passcode_Setup_Enter_Passcode-pg";
    public static final String ONBOARDWIZ_PASSCODE_GUIDELINES_PE = "lnk_o";
    public static final String ONBOARDWIZ_PASSCODE_GUIDELINES_PEV1 = "PASSCODE_SETUP_STEP2_PASSCODE_GUIDELINES_LNK";

    public static final String ONBOARDWIZ_PASSCODE_CANCEL_PROP1 = "CREATE_PASSCODE_CANCEL_LNK";
    public static final String ONBOARDWIZ_PASSCODE_CANCEL_PROP13 = "Passcode_Setup_Create_Passcode-pg";
    public static final String ONBOARDWIZ_PASSCODE_CANCEL_PE = "lnk_o";
    public static final String ONBOARDWIZ_PASSCODE_CANCEL_PEV1 = "CREATE_PASSCODE_CANCEL_LNK";
    public static final String ONBOARDWIZ_PASSCODE_CANCEL_VAR35 = "CREATE_PASSCODE_CANCEL_LNK";

    //verify passcode

    public static final String ONBOARDWIZ_VERIFY_PASSCODE_PAGE_NAME = "Passcode_Setup_Verify_Passcode-pg";

    //Passcode Success

    public static final String ONBOARDWIZ_PASSCODE_SUCCESS_PAGE_NAME = "Passcode_Success_Confirmation-pg";
    public static final String ONBOARDWIZ_PASSCODE_SUCCESS_VAR5_NEW = "New_Setup_Passcode";
    public static final String ONBOARDWIZ_PASSCODE_SUCCESS_VAR5_EXISTING = "Existing_Setup_Passcode";

    //Passcode Exists-Enter Current Passcode/Passcode Already Exists

    public static final String ONBOARDWIZ_PASSCODE_FORGOT_LINK_PROP1 = "FORGOT_PASSCODE_LNK";
    public static final String ONBOARDWIZ_PASSCODE_FORGOT_LINK_PROP13 = "Passcode_Setup_Enter_Passcode-pg";
    public static final String ONBOARDWIZ_PASSCODE_FORGOT_LINK_PE = "lnk_o";
    public static final String ONBOARDWIZ_PASSCODE_FORGOT_LINK_PEV1 = "FORGOT_PASSCODE_LNK";

    //Passcode Guidelines Modal

    public static final String ONBOARDWIZ_PASSCODE_GUIDELINE_MODAL_PAGE_NAME = "Passcode_Guidelines_Modal-pg";

    // Go Back to Passcode/Passcode Step Complete

    public static final String ONBOARDWIZ_PASSCODE_SETUP_COMPLETE_PAGE_NAME = "Passcode_Enabled-pg";


    //Quickview/Enable Quickview

    public static final String ONBOARDWIZ_QUICK_VIEW_INTRO_PAGE_NAME = "Quickview_Intro-pg";

    //Enable Quickview Modal/Quickview Success

    public static final String ONBOARDWIZ_QUICK_VIEW_MODAL_PAGE_NAME = "Enable_Quickview_Modal-pg";

    public static final String ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PROP1 = "ENABLE_QUICKVIEW_ACCEPT_BTN";
    public static final String ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PROP13 = "Enable_Quickview_Modal-pg";
    public static final String ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PE = "lnk_o";
    public static final String ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PEV1 = "ENABLE_QUICKVIEW_ACCEPT_BTN";

    public static final String ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PROP1 = "ENABLE_QUICKVIEW_CANCEL_BTN";
    public static final String ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PROP13 = "Enable_Quickview_Modal-pg";
    public static final String ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PE = "lnk_o";
    public static final String ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PEV1 = "ENABLE_QUICKVIEW_CANCEL_BTN";


    public static final String ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PROP1 = "QUICKVIEW_ENABLE_BTN";
    public static final String ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PROP13 = "Quickview_Intro-pg";
    public static final String ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PE = "lnk_o";
    public static final String ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PEV1 = "QUICKVIEW_ENABLE_BTN";

    //Quickview Success
    public static final String ONBOARDWIZ_QUICK_VIEW_SUCCESS_PAGE_NAME = "Quickview_Success_Confirmation-pg";

    //Back to Quickview/Quickview Step Complete
    public static final String ONBOARDWIZ_QUICK_VIEW_STEP_COMPLETE_PAGE_NAME = "Quickview_Enabled-pg";


    //Confirmation-Alerts/Confirmation Screen

    public static final String ONBOARDWIZ_CONFIRMATION_SCREEN_PAGE_NAME = "Confirmation_Successful_Alerts_Setup-pg";


    public static final String ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PROP1 = "ALERTS_YES_BTN";
    public static final String ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PROP13 = "Confirmation_Successful_Alerts_Setup-pg";
    public static final String ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PE = "lnk_o";
    public static final String ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PEV1 = "ALERTS_YES_BTN";


    public static final String ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PROP1 = "ALERTS_NOT_NOW_LNK";
    public static final String ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PROP13 = "Confirmation_Successful_Alerts_Setup-pg";
    public static final String ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PE = "lnk_o";
    public static final String ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PEV1 = "ALERTS_NOT_NOW_LNK";

    public static final String ONBOARDWIZ_FINGERPRINT_INTRO_PG = "Finger_Print_Intro-pg";
    public static final String ONBOARDWIZ_FINGER_PRINT_SUCCESS_PG = "Finger_Print_Success_Confirmation-pg";
    public static final String ONBOARDWIZ_FINGERPRINT_LINK_O_PG = "lnk_o";


//Passcode Step Complete

    public static final String ONBOARDWIZ_PASSCODE_STEP_COMPLETE_PAGE_NAME = "Onboarding_Success_Confirmation-pg";

    public static final String ONBOARDWIZ_PASSCODE_STEP_COMPLETE_HOME_BUTTON_LINK_PROP1 = "ONBOARDING_PROCESS_SUCCESS_HOME_BTN";
    public static final String ONBOARDWIZ_PASSCODE_STEP_COMPLETE_HOME_BUTTON_PROP13 = "Onboarding_Process_Success_Confirmation-pg";
    public static final String ONBOARDWIZ_PASSCODE_STEP_COMPLETE_HOME_BUTTON_LINK_PE = "lnk_o";
    public static final String ONBOARDWIZ_PASSCODE_STEP_COMPLETE_HOME_BUTTON_LINK_PEV1 = "ONBOARDING_PROCESS_SUCCESS_HOME_BTN";

    //Passcode Errors
    public static final String ONBOARDWIZ_PASSCODE_ERROR_EXISTING = "The Passcode entered does not match.";
    public static final String ONBOARDWIZ_PASSCODE_ERROR_CREATE_PAGE = "The Passcode entered is invalid.";
    public static final String ONBOARDWIZ_PASSCODE_ERROR_VERIFY_PAGE = "The Passcode entered does not match.";
    public static final String ONBOARDWIZ_PASSCODE_ERROR_DEFAULT = "The Passcode entered is invalid.";


//Forward Button

    public static final String ONBOARDWIZ_FORWORD_BUTTON_PROP1 = "FORWARD_BTN";
    public static final String ONBOARDWIZ_FORWORD_BUTTON_VAR35 = "FORWARD_BTN";

    public static final String ONBOARDWIZ_FORWORD_BUTTON_PE = "lnk_o";
    public static final String ONBOARDWIZ_FORWORD_BUTTON_PEV1 = "FORWARD_BTN";


    //Done link
    public static final String ONBOARDWIZ_DONE_LNK_PROP1 = "ONBOARDING_WIZARD_DONE_LNK";
    public static final String ONBOARDWIZ_DONE_LNK_VAR35 = "ONBOARDING_WIZARD_DONE_LNK";

    public static final String ONBOARDWIZ_DONE_LNK_PE = "lnk_o";
    public static final String ONBOARDWIZ_DONE_LNK_PEV1 = "ONBOARDING_WIZARD_DONE_LNK";

//us53328 ends


    //analytics tags for Dynamic banner #US58175
    public static final String CONTACT_INFO_DYNAMIC_BANNER_TOUCH_LINK = "AC_HOME_CONTACT_INFO_BANNER_LNK";
    public static final String CONTACT_INFO_DYNAMIC_BANNER_CLOSE_LINK = "AC_HOME_CONTACT_INFO_BANNER_CLOSE_LNK";
    public static final String CONTACT_INFO_DYNAMIC_BANNER_KEY_PE = "lnk_o";
    //changes by asaraf2 for US58889
    public static final String CLI_EMPLOYERMODAL = "CLI_Employer_Modal-pg";
    public static final String CLI_MANUALREVIEW = "CLI_Manual_Review-pg";
    public static final String CLI_ELECTRONICDISCLOSUREAGREEMENT = "CLI_Electronic_Disclosure_Agreement-pg";
    public static final String CLI_REVIEWCREDITHISTORY = "CLI_Review_Credit_History-pg";
    public static final String CLI_SLIDER = "CLI-Slider";
    public static final String CLI_NOSLIDER = "CLI-NoSlider";
    public static final String KEY_MY_PROPR1 = "my.prop1";
    public static final String KEY_PEV1 = "pev1";
    public static final String KEY_PE = "pe";
    public static final String KEY_PE_VAL = "o";
    public static final String KEY_MY_EVENTS = "my.events";
    public static final String KEY_MY_EVAR5 = "my.evar5";
    public static final String KEY_MY_PROP5 = "my.prop5";

    public static final String CLI_EMPLOYERNAME_LNK_PROP = "CLI_EMPLOYER_NAME_LNK";
    public static final String CLI_EMPLOYERNAMELINK = "lnk_o";
    public static final String CLI_EMPLOYERNAME_LNK = "CLI_EMPLOYER_NAME_LNK";

    public static final String CLI_ENTERINFO_CONTINUE_BTN_PROP1 = "CLI_ENTER_INFORM_CONTINUE_BTN";
    public static final String CLI_ENTERINFO_CONTINUE_BTN_PE = "lnk_o";
    public static final String CLI_ENTERINFO_CONTINUE_BTN_PEV1 = "CLI_ENTER_INFORM_CONTINUE_BTN";

    public static final String CLI_ENTERINFO_CANCEL_BTN_PROP1 = "CLI_ENTER_INFORM_CANCEL_LNK";
    public static final String CLI_ENTERINFO_CANCEL_BTN_PE = "lnk_o";
    public static final String CLI_ENTERINFO_CANCEL_BTN_PEV1 = "CLI_ENTER_INFORM_CANCEL_LNK";

    public static final String CLI_TOTAL_INCOME_MODEL_CLOSE_BTN_PROP1 = "CLI_TOTAL_INCOME_MODAL_CLOSE_BTN";
    public static final String CLI_TOTAL_INCOME_MODEL_CLOSE_BTN_PE = "lnk_o";
    public static final String CLI_TOTAL_INCOME_MODEL_CLOSE_BTN_PEV1 = "CLI_TOTAL_INCOME_MODAL_CLOSE_BTN";

    public static final String CLI_EMPLOYER_MODEL_CLOSE_BTN_PROP1 = "CLI_EMPLOYER_MODAL_CLOSE_BTN";
    public static final String CLI_EMPLOYER_MODEL_CLOSE_BTN_PE = "lnk_o";
    public static final String CLI_EMPLOYER_MODEL_CLOSE_BTN_PEV1 = "CLI_EMPLOYER_MODAL_CLOSE_BTN";

    public static final String CLI_CONFIRMATION_AMOUNTAPPROVED_PG = "CLI_AmountApproved-pg";
    public static final String CLI_SUBMIT_INCREASE_CANCEL_MODAL_PG = "CLI_Submit_Increase_Cancel_Modal-pg";
    public static final String CLI_INCREASE_REQUEST_DECLINED = "CLI_Increase_Request_Declined-pg";
    public static final String NAVDRAWERITEM_CREDIT_LINE_INCREASE = "NavDrawerItem_Credit Line Increase";
    public static final String CLI_TOTAL_ANNUAL_GROSS_INCOME_LNK_PROP1 = "CLI_TOTAL_ANNUAL_GROSS_INCOME_LNK";
    public static final String CLI_TOTAL_ANNUAL_GROSS_INCOME_LNK_PEV1 = "CLI_TOTAL_ANNUAL_GROSS_INCOME_LNK";
    public static final String CLI_TOTAL_ANNUAL_GROSS_INCOME_LNK_PE = "lnk_o";
    public static final String CLI_MANUAL_REVIEW_ACCOUNT_HOME_BTN_PROP1 = "CLI_MANUAL_REVIEW_ACCOUNT_HOME_BTN";
    public static final String CLI_MANUAL_REVIEW_ACCOUNT_HOME_BTN_PEV1 = "CLI_MANUAL_REVIEW_ACCOUNT_HOME_BTN";
    public static final String CLI_MANUAL_REVIEW_ACCOUNT_HOME_BTN_PE = "lnk_o";
    public static final String CLI_ELECTRONIC_DISCLOSURE_AGREE_BTN_PROP1 = "CLI_ELECTRONIC_DISCLOSURE_AGREE_BTN";
    public static final String CLI_ELECTRONIC_DISCLOSURE_AGREE_BTN_PEV1 = "CLI_ELECTRONIC_DISCLOSURE_AGREE_BTN";
    public static final String CLI_ELECTRONIC_DISCLOSURE_AGREE_BTN_PE = "lnk_o";
    public static final String CLI_REVIEW_CREDIT_HISTORY_CONTINUE_BTN_PROP1 = "CLI_REVIEW_CREDIT_HISTORY_CONTINUE_BTN";
    public static final String CLI_REVIEW_CREDIT_HISTORY_CONTINUE_BTN_PEV1 = "CLI_REVIEW_CREDIT_HISTORY_CONTINUE_BTN";
    public static final String CLI_REVIEW_CREDIT_HISTORY_CONTINUE_BTN_PE = "lnk_o";
    public static final String CLI_REVIEW_CREDIT_HISTORY_CANCEL_LNK_PROP1 = "CLI_REVIEW_CREDIT_HISTORY_CANCEL_LNK";
    public static final String CLI_REVIEW_CREDIT_HISTORY_CANCEL_LNK_PEV1 = "CLI_REVIEW_CREDIT_HISTORY_CANCEL_LNK";
    public static final String CLI_REVIEW_CREDIT_HISTORY_CANCEL_LNK_PE = "lnk_o";
    public static final String CLI_CHOOSE_AMT_SUBMIT_INCREASE_BTN_PROP1 = "CLI_CHOOSE_AMT_SUBMIT_INCREASE_BTN";
    public static final String CLI_CHOOSE_AMT_SUBMIT_INCREASE_BTN_PEV1 = "CLI_CHOOSE_AMT_SUBMIT_INCREASE_BTN";
    public static final String CLI_CHOOSE_AMT_SUBMIT_INCREASE_BTN_PE = "lnk_o";
    public static final String CLI_CANCEL_MODEL_CANCEL_REQUEST_BTN_PROP1 = "CLI_CANCEL_MODEL_CANCEL_REQUEST_BTN";
    public static final String CLI_CANCEL_MODEL_CANCEL_REQUEST_BTN_PEV1 = "CLI_CANCEL_MODEL_CANCEL_REQUEST_BTN";
    public static final String CLI_CANCEL_MODEL_CANCEL_REQUEST_BTN_PE = "lnk_o";
    public static final String CLI_CANCEL_MODEL_RETURN_BTN_PROP1 = "CLI_CANCEL_MODEL_RETURN_BTN";
    public static final String CLI_CANCEL_MODEL_RETURN_BTN_PEV1 = "CLI_CANCEL_MODEL_RETURN_BTN";
    public static final String CLI_CANCEL_MODEL_RETURN_BTN_PE = "lnk_o";
    public static final String CLI_CONFIRM_ACCOUNT_HOME_BTN_PROP1 = "CLI_CONFIRM_ACCOUNT_HOME_BTN";
    public static final String CLI_CONFIRM_ACCOUNT_HOME_BTN_PEV1 = "CLI_CONFIRM_ACCOUNT_HOME_BTN";
    public static final String CLI_CONFIRM_ACCOUNT_HOME_BTN_PE = "lnk_o";
    public static final String CLI_DECLINE_ACCOUNT_HOME_BTN_PROP1 = "CLI_DECLINE_ACCOUNT_HOME_BTN";
    public static final String CLI_DECLINE_ACCOUNT_HOME_BTN_PEV1 = "CLI_DECLINE_ACCOUNT_HOME_BTN";
    public static final String CLI_DECLINE_ACCOUNT_HOME_BTN_PE = "lnk_o";

    //added for US103854
    public static final String CLI_TOTAL_AVAILABLE_ASSET_LINK_PROP1 = "CLI_TOTAL_Available_Assests_LNK";
    public static final String CLI_TOTAL_AVAILABLE_ASSET_LINK_PEV1 = "CLI_TOTAL_Available_Assests_LNK";

    public static final String CLI_TOTAL_AVAILABLE_ASSET_MODAL_CLOSE_PROP1 = "CLI_TOTAL_ASSESTS_MODAL_CLOSE_BTN";
    public static final String CLI_TOTAL_AVAILABLE_ASSET_MODAL_CLOSE_PEV1 = "CLI_TOTAL_ASSESTS_MODAL_CLOSE_BTN";


    //US63074 - Verify Trial Deposits: Analytics
    public static final String VERIFY_TRIAL_DEPOSIT_PE = "lnk_o";
    public static final String VERIFY_TRIAL_DEPOSIT_EVENT22 = "event22";
    public static final String VERIFY_TRIAL_DEPOSIT_EVENT9 = "event9";

    //Verify Trial Deposits_Review Transfers
    public static final String VERIFY_TRIAL_DEPOSIT_PEV1 = "REVIEW_TRANFERS_VERIFY_BTN";
    public static final String TRIAL_DEPOSIT_VERIFY_MODAL_LINK_PEV1 = "TRIAL_DEPOSIT_VERIFY_MODAL_LNK";
    public static final String TRAIL_DEPOSIT_VERIFY_SUBMIT_BTN_PEV1 = "TRIAL_DEPOSIT_VERIFY_SUBMIT_BTN";
    public static final String TRAIL_DEPOSIT_VERIFY_CANCEL_LNK_PEV1 = "TRIAL_DEPOSIT_VERIFY_CANCEL_LNK";
    public static final String VERIFY_TRIAL_DEPOSIT_REVIEW_TRANSFER_EVAR5 = "Verify_Trial_Deposit_Review_Transfer";

    //Verify Trial Deposits_Account Activity
    public static final String ACCOUNT_ACTIVITY_VERIFY_BTN_PEV1 = "ACCOUNT_ACTIVITY_VERIFY_BTN";
    public static final String VERIFY_TRIAL_DEPOSIT_ACCOUNT_ACTIVITY_EVAR5 = "Verify_Trial_Deposit_Account_Activity";


    // Tags for Account Profile #US58176
    public static final String ACCOUNT_PROFILE_PG = "Account_Profile-pg";
    public static final String ACCOUNT_PROFILE_TOOLTIP_LNK_PROP1 = "ACCOUNT_PROFILE_TOOLTIP_LNK";
    public static final String ACCOUNT_PROFILE_TOOLTIP_LNK_PE = "lnk_o";
    public static final String ACCOUNT_PROFILE_TOOLTIP_LNK_PEV1 = "ACCOUNT_PROFILE_TOOLTIP_LNK";
    public static final String ACCOUNT_PROFILE_TOTAL_ANNUAL_GROSS_INCOME_OVERLAY_PG = "Total_Annual_Gross _Income_overlay-pg";
    public static final String ACCOUNT_PROFILE_EDIT_BTN_PROP1 = "ACCOUNT_PROFILE_EDIT_BTN";
    public static final String ACCOUNT_PROFILE_EDIT_BTN_PE = "lnk_o";
    public static final String ACCOUNT_PROFILE_EDIT_BTN_PEV1 = "ACCOUNT_PROFILE_EDIT_BTN";
    public static final String ACCOUNT_PROFILE_EDIT_PG = "Account_profile_edit-pg";
    public static final String ACCOUNT_PROFILE_CANCEL_BTN_PROP1 = "ACCOUNT_PROFILE_CANCEL_BTN";
    public static final String ACCOUNT_PROFILE_CANCEL_BTN_PE = "lnk_o";
    public static final String ACCOUNT_PROFILE_CANCEL_BTN_PEV1 = "ACCOUNT_PROFILE_CANCEL_BTN";
    public static final String ACCOUNT_PROFILE_YOUR_CHANGES_WILL_BE_LOST_OVERLAY_PG = "Your_Changes_will_be__lost_overlay-pg";
    public static final String ACCOUNT_PROFILE_CONFIRM_CANCEL_BTN_PROP1 = "ACCOUNT_PROFILE_CONFIRM_CANCEL_BTN";
    public static final String ACCOUNT_PROFILE_CONFIRM_CANCEL_BTN_PE = "lnk_o";
    public static final String ACCOUNT_PROFILE_CONFIRM_CANCEL_BTN_PEV1 = "ACCOUNT_PROFILE_CONFIRM_CANCEL_BTN";
    public static final String ACCOUNT_PROFILE_CONFIRM_GO_BACK_BTN_PROP1 = "ACCOUNT_PROFILE_CONFIRM_GO_BACK_BTN";
    public static final String ACCOUNT_PROFILE_CONFIRM_GO_BACK_BTN_PE = "lnk_o";
    public static final String ACCOUNT_PROFILE_CONFIRM_GO_BACK_BTN_PEV1 = "ACCOUNT_PROFILE_CONFIRM_GO_BACK_BTN";
    public static final String ACCOUNT_PROFILE_SAVE_BTN_PROP1 = "ACCOUNT_PROFILE_SAVE_BTN";
    public static final String ACCOUNT_PROFILE_SAVE_BTN_PE = "lnk_o";
    public static final String ACCOUNT_PROFILE_SAVE_BTN_PEV1 = "ACCOUNT_PROFILE_SAVE_BTN";

    // Tags for SamsungPay
    public static final String SAMSUNG_PAY_REMINDER_PAGENAME = "Samsung_Pay_Reminder-pg";
    public static final String SAMSUNG_PAY_HF_PAGENAME = "Samsung_Pay_Highlighted_Feature-pg";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_TERMS_AND_CONDITIONING_PAGENAME = "Samsung_Pay_In-App_Provisioning_Terms_and_Conditions-pg";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_MULTIPLE_CARDS_PAGENAME = "Samsung_Pay_In-App_Provisioning_Multiple_Cards-pg";
    public static final String SAMSUNG_PAY_SET_UP_ELIGIBLE_USER_PG = "Samsung_Pay_Set_up_Eligible_User-pg";
    public static final String SAMSUNG_PAY_SETUP_ELIGIBLE_USER = "SAMSUNG_PAY_SETUP_ELIGIBLE_USER";
    public static final String SAMSUNG_PAY_EVENT_22 = "event22";
    public static final String SAMSUNG_PAY_EVENT_9 = "event9";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_SUCCESSFUL = "Samsung_Pay_In-App_Provisioning_Successful-pg";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_CANCEL_MODAL = "Samsung_Pay_In-App_Provisioning_Cancel_Modal-pg";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_ADD_CARD_ERROR_MODAL = "Samsung_Pay_In-App_Provisioning_AddCard_Error_Modal-pg";
    public static final String SAMSUNG_PAY_ADD_CARD_ERROR = "Samsung Pay: Add Card Error";
    public static final String SAMSUNG_PAY_REMINDER_REMIND_ME_LATER_LNK = "SAMSUNG_PAY_REMINDER_REMIND_ME_LATER_LNK";
    public static final String SAMSUNG_PAY_LNK_O = "lnk_o";
    public static final String SAMSUNG_PAY_REMINDER_NO_THANKS_LNK = "SAMSUNG_PAY_REMINDER_NO_THANKS_LNK";
    public static final String SAMSUNG_PAY_REMOVE_CARD_SUCCESSFUL_MODAL_PO = "Samsung_Pay_Remove_Card_Successful_Modal-pg";
    public static final String SAMSUNG_PAY_REMOVE_CARD_BTN = "SAMSUNG_PAY_REMOVE_CARD_BTN";
    public static final String SAMSUNG_PAY_REMOVE_CARD_LANDING = "Samsung_Pay_Remove_Card_Landing-pg";
    public static final String SAMSUNG_PAY_REMOVE_CARD = "SAMSUNG_PAY_REMOVE_CARD";
    public static final String SAMSUNG_PAY_FREEZE_CARD_SUCCESSFUL_MODAL_PO = "Samsung_Pay_Freeze_Card_Successful_Modal-pg";
    public static final String SAMSUNG_PAY_UNFREEZE_CARD_SUCCESSFUL_MODAL_PO = "Samsung_Pay_UnFreeze_Card_Successful_Modal-pg";
    public static final String SAMSUNG_PAY_UNFREEZE_SAMSUNG_PAY_BTN = "SAMSUNG_PAY_UNFREEZE_SAMSUNG_PAY_BTN";
    public static final String SAMSUNG_PAY_UNFREEZE_CARD_LANDING = "Samsung_Pay_UnFreeze_Card_Landing-pg";
    public static final String SAMSUNG_PAY_UNFREEZE_CARD = "SAMSUNG_PAY_UNFREEZE_CARD";
    public static final String SAMSUNG_PAY_FREEZE_SAMSUNG_PAY_BTN = "SAMSUNG_PAY_FREEZE_SAMSUNG_PAY_BTN";
    public static final String SAMSUNG_PAY_FREEZE_CARD_LANDING = "Samsung_Pay_Freeze_Card_Landing-pg";
    public static final String SAMSUNG_PAY_FREEZE_CARD = "SAMSUNG_PAY_FREEZE_CARD";
    public static final String SAMSUNG_PAY_LP_REMOVE_CARD_FROM_SAMSUNG_PAY_LNK = "SAMSUNG_PAY_LP_REMOVE_CARD_FROM_SAMSUNG_PAY_LNK";
    public static final String SAMSUNG_PAY_LP_UNFREEZE_SAMSUNG_PAY_LNK = "SAMSUNG_PAY_LP_UNFREEZE_SAMSUNG_PAY_LNK";
    public static final String SAMSUNG_PAY_LP_FREEZE_LNK = "SAMSUNG_PAY_LP_FREEZE_LNK";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_CANCEL_MODAL_YES_LNK = "SAMSUNG_PAY_IN-APP_PROVISIONING_CANCEL_MODAL_YES_LNK";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_CANCEL_MODAL_NO_BTN = "SAMSUNG_PAY_IN-APP_PROVISIONING_CANCEL_MODAL_NO_BTN";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_MULTIPLE_CARD_SELECTION_BTN = "";
    public static final String SAMSUNG_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN = "SAMSUNG_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN";
    public static final String SAMSUNG_PAY_MANAGE_CARDS_ADD_CARD_LNK = "SAMSUNG_PAY_MANAGE_CARDS_ADD_CARD_LNK";
    public static final String SAMSUNG_PAY_SET_UP_GET_STARTED_BTN = "SAMSUNG_PAY_SET_UP_GET_STARTED_BTN";
    public static final String SAMSUNG_PAY_SET_UP_SAMSUNG_PAY_FAQ_LNK = "SAMSUNG_PAY_SET_UP_SAMSUNG_PAY_FAQ_LNK";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_TERMS_CONDITIONS_AGREE_BTN = "SAMSUNG_PAY_IN-APP_PROVISIONING_TERMS_CONDITIONS_AGREE_BTN";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_TERMS_CONDITIONS_BACK_BTN = "SAMSUNG_PAY_IN-APP_PROVISIONING_TERMS_CONDITIONS_BACK_BTN";
    public static final String SAMSUNG_PAY_REMINDER_GET_STARTED_BTN = "SAMSUNG_PAY_REMINDER_GET_STARTED_BTN";
    public static final String SAMSUNG_PAY_SET_UP_ACTIVATE_ACCOUNT_PAGE = "Samsung_Pay_Set_up_Activate_Account-pg";
    public static final String SAMSUNG_PAY_SET_UP_SAMSUNG_ACCOUNT_LNK = "SAMSUNG_PAY_SET_UP_SAMSUNG_ACCOUNT_LNK";
    public static final String SAMSUNG_PAY_SET_UP_CARD_NOT_ACTIVATED_PAGE = "Samsung_Pay_Set_up_Card_Not_Activated-pg";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_TERMS_CONDITIONS_DISAGREE_LNK = "SAMSUNG_PAY_IN-APP_PROVISIONING_TERMS_CONDITIONS_DISAGREE_LNK";
    public static final String SAMSUNG_PAY_SET_UP_ACTIVATE_LNK = "SAMSUNG_PAY_SET_UP_ACTIVATE_LNK";
    public static final String SAMSUNG_PAY_SET_UP_CARD_NOT_ACTIVATED = "Samsung_Pay_Set_up_Card_Not_Activated-pg";

    //Samsung Pay Phase-2
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_MANAGE_CARD_PAY_DETAILS_BTN = "SAMSUNG_PAY_IN-APP_PROVISIONING_MANAGE_CARD_PAY_DETAILS_BTN";
    public static final String SAMSUNG_PAY_HELP_ICON_OVERLAY_MODAL_PAGE = "Samsung_Pay_Help_Icon_Overlay_Modal-pg";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_VERIFICATION_REQUIRED_MODAL_PAGE = "Samsung_Pay_In-App_Provisioning_Verification_Required_Modal-pg";
    public static final String SAMSUNG_PAY_IN_APP_PROVISIONING_ADDCARD_ERROR_MODAL_CLOSE_BTN = "SAMSUNG_PAY_IN-APP_PROVISIONING_ADDCARD_ERROR_MODAL_CLOSE_BTN";
    public static final String SAMSUNG_PAY_VERIFICATION_REQUIRED_MODAL_CALL_DISCOVER_BTN = "SAMSUNG_PAY_VERIFICATION_REQUIRED_MODAL_CALL_DISCOVER_BTN";
    public static final String SAMSUNG_PAY_VERIFICATION_REQUIRED_MODAL_VERIFY_LATER_LNK = "SAMSUNG_PAY_VERIFICATION_REQUIRED_MODAL_VERIFY_LATER_LNK";
    public static final String SAMSUNG_PAY_VERIFICATION_REQUIRED_MODAL_PHONE_NUM_LNK = "SAMSUNG_PAY_VERIFICATION_REQUIRED_MODAL_PHONE_NUM_LNK";
    public static final String SAMSUNG_PAY_MANAGE_CARDS_CARD_NOT_ACTIVATED_DEVICE_DETAILS_PAGE = "Samsung_Pay_Manage_Cards_Card_Not_Activated_Device_Details-pg";
    public static final String SAMSUNG_PAY_MANAGE_CARDS_NOT_ACTIVATED_PHONE_NUM_LNK = "SAMSUNG_PAY_MANAGE_CARDS_NOT_ACTIVATED_PHONE_NUM_LNK";
    public static final String SAMSUNG_PAY_MANAGE_CARDS_NOT_ACTIVATED_DEVICE_DETAILS_PHONE_NUM_LNK = "SAMSUNG_PAY_MANAGE_CARDS_NOT_ACTIVATED_DEVICE_DETAILS_PHONE_NUM_LNK";
    public static final String SAMSUNG_PAY_MANAGE_CARDS_NOT_ACTIVATED_DEVICE_DETAILS_SAMSUNG_PAY_FAQ_LNK = "SAMSUNG_PAY_MANAGE_CARDS_NOT_ACTIVATED_DEVICE_DETAILS_SAMSUNG_PAY_FAQ_LNK";
    public static final String SAMSUNG_PAY_SET_UP_MULTIPLE_INELIGIBLE_PAGE = "Samsung_Pay_Set_up_Multiple_InEligible-pg";


    //Android Pay Sitecats-Phase-2
    public static final String ANDROID_PAY_GOOGLE_IN_APP_PROVISIONING_ADDCARD_SUCCESS_PAGE = "Android_Pay_Google_In-App_Provisioning_AddCard_Success-pg";
    public static final String ANDROID_PAY_SETUP_CARD_SET_AS_DEFAULT_BTN = "ANDROID_PAY_SETUP_CARD_SET_AS_DEFAULT_BTN";
    public static final String ANDROID_PAY_LP_SET_AS_DEFAULT_BTN = "ANDROID_PAY_LP_SET_AS_DEFAULT_BTN";
    public static final String ANDROID_PAY_SETUP_CARD_NOT_NOW_LNK = "ANDROID_PAY_SETUP_CARD_NOT_NOW_LNK";
    public static final String ANDROID_PAY_SETUP_CARD_AS_DEFAULT_SUCCESS_PAGE = "Android_Pay_Setup_Card_As_Default_Success-pg";
    public static final String ANDROID_PAY_MANAGECARD_SETUP_CARD_AS_DEFAULT_SUCCESS_PAGE = "Android_Pay_Managecard_Setup_Card_As_Default_Success-pg";
    public static final String ANDROID_PAY_SETUP_CARD_AS_DEFAULT_ERROR_MODAL_PAGE = "Android_Pay_Setup_Card_As Default_Error_Modal-pg";
    public static final String ANDROID_PAY_SET_UP_INELIGIBLE_USER_PAGE = "Android_Pay_Set_up_InEligible_User-pg";
    public static final String ANDROID_PAY_SETUP_INELIGIBLE_USER = "ANDROID_PAY_SETUP_INELIGIBLE_USER";
    public static final String ANDROID_PAY_MANAGECARD_SETUP_CARD_AS_DEFAULT_BTN = "ANDROID_PAY_MANAGECARD_SETUP_CARD_AS_DEFAULT_BTN";

    public static final String ANDROID_PAY_OVERLAY_MODAL_PG_LOAD = "Android_Pay_Help_Icon_Overlay_Modal-pg";


    public static final String SAMSUNG_PAY_ACTIVE_DEVICE_DETAILS_PG_LOAD = "Samsung_Pay_Manage_Cards_Card_Active_Device_Details-pg";
    public static final String SAMSUNG_PAY_NOT_ACTIVATED_DEVICE_DETAILS_PG_LOAD = "Samsung_Pay_Manage_Cards_Card_Not_Active_Device_Details-pg";
    public static final String SAMSUNG_PAY_OVERLAY_MODAL_PG_LOAD = "Samsung_Pay_Help_Icon_Overlay_Modal-pg";
    public static final String SAMSUNG_PAY_SET_UP_INELIGIBLE_USER_PAGE = "Samsung_Pay_Set_up_InEligible_User-pg";
    public static final String SAMSUNG_PAY_SETUP_INELIGIBLE_USER = "SAMSUNG_PAY_SETUP_INELIGIBLE_USER";


    //Tags for Refer a Friend

    //“o” (Custom Links)
    public static final String LINK_TYPE_O = "o";
    //“d” (File Downloads)
    public static final String LINK_TYPE_D = "d";
    //“e” (Exit Links)
    public static final String LINK_TYPE_E = "e";


    public static final String RAF_PE = "lnk_o";

    public static final String LHN_CBB_RAF_PROP1 = "NavDrawerSection_NavDrawerItem_Refer A Friend";
    public static final String LHN_CBB_RAF_PEV1 = "NavDrawerSection_NavDrawerItem_Refer A Friend";

    public static final String RAF_LANDING_PAGE_PAGE_LOAD = "Refer_A_Friend-pg";

    public static final String RAF_EMAIL_SHARE_LNK_PROP1 = "REFER_A_FRIEND_EMAIL_SHARE_LNK";
    public static final String RAF_EMAIL_SHARE_LNK_PEV1 = "REFER_A_FRIEND_EMAIL_SHARE_LNK";

    public static final String RAF_FB_SHARE_LNK_PROP1 = "REFER_A_FRIEND_FACEBOOK_SHARE_LNK";
    public static final String RAF_FB_SHARE_LNK_PEV1 = "REFER_A_FRIEND_FACEBOOK_SHARE_LNK";

    public static final String RAF_TWITTER_SHARE_LNK_PROP1 = "REFER_A_FRIEND_TWITTER_SHARE_LNK";
    public static final String RAF_TWITTER_SHARE_LNK_PEV1 = "REFER_A_FRIEND_TWITTER_SHARE_LNK";

    public static final String RAF_TEXT_SHARE_LNK_PROP1 = "REFER_A_FRIEND_TEXT_SHARE_LNK";
    public static final String RAF_TEXT_SHARE_LNK_PEV1 = "REFER_A_FRIEND_TEXT_SHARE_LNK";

    public static final String RAF_EMAIL_SHARE_LNK_PAGENAME = "Refer_A_Friend_Email_Share-pg";
    public static final String RAF_EMAIL_SHARE_LNK_EVENTS = "event22";
    public static final String RAF_EMAIL_SHARE_LNK_PROP5 = "RAF:EMAIL_SHARE";
    public static final String RAF_EMAIL_SHARE_LNK_EVAR5 = "RAF:EMAIL_SHARE";

    public static final String RAF_EMAIL_SHARE_SEND_BUTTON_PROP1 = "REFER_A_FRIEND_EMAIL_SHARE_SEND_BTN";
    public static final String RAF_EMAIL_SHARE_SEND_BUTTON_PROP5_EDITED = "RAF:EMAIL_MSG_CONTENT:EDITED";
    public static final String RAF_EMAIL_SHARE_SEND_BUTTON_PROP5_NON_EDITED = "RAF:EMAIL_MSG_CONTENT:NOT_EDITED";
    public static final String RAF_EMAIL_SHARE_SEND_BUTTON_PEV1 = "REFER_A_FRIEND_EMAIL_SHARE_SEND_BTN";


    public static final String RAF_EMAIL_SHARE_MSG_SENT_SUCCESS_PAGENAME = "Refer_A_Friend_Email_Share_Successful-pg";
    public static final String RAF_EMAIL_SHARE_MSG_SENT_SUCCESS_EVENT = "event9";

    public static final String RAF_EMAIL_SHARE_ERROR_MESSAGE_PAGENAME = "Refer_A_Friend-pg";

    public static final String LHN_OPEN_PAGE_TRACK = "LHN_Open";

    //US79057 - Change Password: Analytics

    public static final String PROP1 = DiscoverActivityManager.getString(R.string.prop1);
    public static final String PROP5 = DiscoverActivityManager.getString(R.string.prop5);
    public static final String EVAR5 = DiscoverActivityManager.getString(R.string.evar5);
    public static final String EVAR35 = DiscoverActivityManager.getString(R.string.evar35);
    public static final String MYEVENTS = DiscoverActivityManager.getString(R.string.myevents);
    public static final String PE = DiscoverActivityManager.getString(R.string.pe);
    public static final String PEV1 = DiscoverActivityManager.getString(R.string.pev1);
    public static final String PAGENAME = DiscoverActivityManager.getString(R.string.pagename);
    public static final String EVENTS = DiscoverActivityManager.getString(R.string.events);
    public static final String MYPRODUCTS = DiscoverActivityManager.getString(R.string.myproducts);
    public static final String KEY_PRODUCTS= DiscoverActivityManager.getString(R.string.key_products);
    public static final String PROP13= DiscoverActivityManager.getString(R.string.prop13);
    public static final String PROP10= DiscoverActivityManager.getString(R.string.prop10);
    public static final String PROP35= "my.prop35";
    public static final String EVAR19="my.eVar19";
    public static final String EVAR20="my.eVar20";
    public static final String EVAR41="my.eVar41";
    public static final String PROP3="my.prop3";
    public static final String EVAR3="my.eVar3";
    public static final String EVAR39="my.eVar39";


    public static final String BANK_CHANGE_PASSWORD_EVENT22 = "event22";
    public static final String BANK_CHANGE_PASSWORD_EVENT9 = "event9";
    public static final String BANK_CHANGE_PASSWORD = "Password_Change";
    public static final String BANK_CHANGE_PASSWORD_BACK_ARROW = "CHANGE_PASSWORD_BACK_ARROW_LNK";
    public static final String BANK_CHANGE_PASSWORD_LINK = "PROFILES_AND_SETTINGS_CHANGE_PASSWORD_LNK";
    public static final String BANK_CHANGE_PASSWORD_SAVE_BUTTON = "CHANGE_PASSWORD_SAVE_BTN";
    public static final String BANK_CHANGE_PASSWORD_CANCEL_BUTTON = "CHANGE_PASSWORD_CANCEL_BTN";
    public static final String BANK_CHANGE_PASSWORD_HELP_ICON = "CHANGE_PASSWORD_STRENGTH_METER_LNK";
    public static final String BANK_CHANGE_PASSWORD_PAGE = "Change_Password_pg";
    public static final String BANK_CHANGE_PASSWORD_SUCCESS_MSG = "Change_Password_successful-pg";
    //US69926-Account Activity: Add Site Cat Tag to New DPL Payment Button-Start
    public static final String DPL_ACCT_ACTIVITY_MAKE_A_PAYMENT_LNK_PROP1 = "DPL_ACCT_ACTIVITY_MAKE_A_PAYMENT_LNK";
    public static final String DPL_ACCT_ACTIVITY_MAKE_A_PAYMENT_LNK_PEV1 = "DPL_ACCT_ACTIVITY_MAKE_A_PAYMENT_LNK";
    //US69926-Account Activity: Add Site Cat Tag to New DPL Payment Button-End


    /** Start Changes for US71879: Fingerprint Site Catalyst Tags */
    public static final String FINGER_PRINT_LOGIN_MODAL_PG = "Finger_Print_login_modal-pg";
    public static final String FINGER_PRINT_LOGIN_LNK = "FINGER_PRINT_LOGIN_LNK";
    public static final String FINGER_PRINT_MODAL_CANCEL_LNK = "FINGER_PRINT_MODAL_CANCEL_LNK";
    public static final String FINGER_PRINT_NOT_RECOGNIZED_MODAL_CANCEL_LNK = "FINGER_PRINT_NOT_RECOGNIZED_MODAL_CANCEL_LNK";
    public static final String FINGER_PRINT_EVENT10 = "event10";
    public static final String FINGER_PRINT_LOG_IN = "Log In - Finger Print";
    public static final String INVALID_FINGER_PRINT = "Invalid Finger Print";
    public static final String CONTEXT_MY_EVENTS = DiscoverActivityManager.getString(R.string.context_my_events);
    public static final String CONTEXT_MY_EVAR34 = DiscoverActivityManager.getString(R.string.context_my_eVar34);
    public static final String CONTEXT_MY_PROP34 = DiscoverActivityManager.getString(R.string.context_my_prop34);
    public static final String FINGER_PRINT_TEMP_UNAVAILABLE_OVERLAY_PG = "Finger_Print_Temp_Unavailable_Overlay-pg";
    public static final String FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_REACTIVATE_FINGERPRINT_BTN = "FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_REACTIVATE_FINGERPRINT_BTN";
    public static final String FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_CLOSE_LNK = "FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_CLOSE_LNK";
    public static final String PROFILES_AND_SETTINGS_FINGERPRINT_LNK = "PROFILES_AND_SETTINGS_FINGERPRINT_LNK";
    public static final String FINGER_PRINT_PG = "Finger_Print-pg";
    public static final String FINGER_PRINT_PASSCODE_VERIFICATION_PG = "Finger_Print_Passcode_Verification-pg";
    public static final String FINGER_PRINT_SETUP_CANCEL_OVERLAY_PG = "Finger_Print_Setup_Cancel_Overlay-pg";
    public static final String FINGER_PRINT_SETUP_CANCEL_MODAL_NO_CONTINUE_LNK = "FINGER_PRINT_SETUP_CANCEL_MODAL_NO_CONTINUE_LNK";

    //Start: US72282: FingerPrint Analytics
    public static final String FINGER_PRINT_SETUP_CANCEL_MODAL_CLOSE_LNK = "FINGER_PRINT_SETUP_CANCEL_MODAL_CLOSE_LNK";
    public static final String PASSCODE_CREATED_MODAL_HOME_LNK = "PASSCODE_CREATED_MODAL_HOME_LNK";
    //End: US72282: FingerPrint Analytics

    public static final String FINGER_PRINT_SETUP_MODAL_CONFIRM_YES_CANCEL_BTN = "FINGER_PRINT_SETUP_MODAL_CONFIRM_YES_CANCEL_BTN";
    public static final String FINGER_PRINT_ENABLED_OVERLAY_PG = "`-pg";
    public static final String FINGER_PRINT_DISABLED_OVERLAY_PG = "Finger_Print_Disabled_Overlay-pg";
    public static final String FINGER_PRINT_ENABLED_MODAL_HOME_BTN = "FINGER_PRINT_ENABLED_MODAL_HOME_BTN";
    public static final String FINGER_PRINT_ENABLED_MODAL_CLOSE_LNK = "FINGER_PRINT_ENABLED_MODAL_CLOSE_LNK";
    public static final String FINGER_PRINT_DISABLED_MODAL_HOME_BTN = "FINGER_PRINT_DISABLED_MODAL_HOME_BTN";
    public static final String FINGER_PRINT_DISABLED_MODAL_CLOSE_LNK = "FINGER_PRINT_DISABLED_MODAL_CLOSE_LNK";
    public static final String FINGER_PRINT_SETUP_PASSCODE_OVERLAY_PG = "Finger_Print_Setup_Passcode_Overlay-pg";
    public static final String FINGER_PRINT_NOT_REGISTERED_OVERLAY_PG = "Finger_Print_Not_Registered_Overlay-pg";
    public static final String FINGER_PRINT_ENABLE_MODAL_SETUP_PASSCODE_BTN = "FINGER_PRINT_ENABLE_MODAL_SETUP_PASSCODE_BTN";
    public static final String FINGER_PRINT_ENABLE_MODAL_CANCEL_LNK = "FINGER_PRINT_ENABLE_MODAL_CANCEL_LNK";
    public static final String FINGER_PRINT_NOT_REGISTERED_MODAL_SETTINGS_BTN = "FINGER_PRINT_NOT_REGISTERED_MODAL_SETTINGS_BTN";
    public static final String FINGER_PRINT_NOT_REGISTERED_MODAL_CANCEL_LNK = "FINGER_PRINT_NOT_REGISTERED_MODAL_CANCEL_LNK";
    public static final String PASSCODE_OVERVIEW_MODAL_PG = "Passcode_Overview_Modal-pg";
    public static final String PASSCODE_OVERVIEW_MODAL_CLOSE_LNK = "PASSCODE_OVERVIEW_MODAL_CLOSE_LNK";
    public static final String PASSCODE_SETUP_PG = "Passcode_Setup-pg";
    public static final String PASSCODE_CREATED_MODAL_PG = "Passcode_Created_Modal-pg";
    public static final String PASSCODE_CREATED_MODAL_ENABLE_FINGER_PRINT_BTN = "PASSCODE_CREATED_MODAL_ENABLE_FINGER_PRINT_BTN";
    public static final String PASSCODE_CREATED_MODAL_CLOSE_LNK = "PASSCODE_CREATED_MODAL_CLOSE_LNK";
    public static final String DISABLE_PASSCODE_MODAL_PG = "Disable_Passcode_Modal-pg";
    public static final String DISABLE_PASSCODE_MODAL_DISABLE_PASSCODE_BTN = "DISABLE_PASSCODE_MODAL_DISABLE_PASSCODE_BTN";
    public static final String DISABLE_PASSCODE_MODAL_DONT_DISABLE_PASSCODE_LNK = "DISABLE_PASSCODE_MODAL_DONT_DISABLE_PASSCODE_LNK";
    public static final String PASSCODE_DISABLED_MODAL_PG = "Passcode_Disabled_Modal-pg";
    public static final String PASSCODE_DISABLED_MODAL_CLOSE_LNK = "PASSCODE_DISABLED_MODAL_CLOSE_LNK";
    public static final String PASSCODE_DISABLED_MODAL_HOME_BTN = "PASSCODE_DISABLED_MODAL_HOME_BTN";
    public static final String PASSCODE_UPDATED_MODAL_PG = "Passcode_Updated_Modal-pg";
    public static final String PASSCODE_UPDATED_MODAL_HOME_BTN = "PASSCODE_UPDATED_MODAL_HOME_BTN";
    public static final String FINGER_PRINT_WHATSNEW_PG = "Finger_Print_WhatsNew-pg";
    public static final String FINGER_PRINT_HIGHLIGHTED_PG = "Finger_Print_Highlighted-pg";
    public static final String FINGER_PRINT_REMINDER_PG = "Finger_Print_Reminder-pg";
    public static final String FINGER_PRINT_WHATS_NEW_ENABLE_FINGERPRINT_BTN = "FINGER_PRINT_WHATS_NEW_ENABLE_FINGERPRINT_BTN";
    public static final String FINGER_PRINT_HIGHLIGHTED_FEATURE_ENABLE_FINGERPRINT_BTN = "FINGER_PRINT_HIGHLIGHTED_FEATURE_ENABLE_FINGERPRINT_BTN";
    public static final String FINGER_PRINT_REMINDER_ENABLE_FINGERPRINT_BTN = "FINGER_PRINT_REMINDER_ENABLE_FINGERPRINT_BTN";
    public static final String FINGER_PRINT_REMINDER_NO_THANKS_LNK = "FINGER_PRINT_REMINDER_NO_THANKS_LNK";
    public static final String FINGER_PRINT_REMINDER_REMIND_ME_LATER_LNK = "FINGER_PRINT_REMINDER_REMIND_ME_LATER_LNK";
    public static final String FINGER_PRINT_QUICKER_LOGIN_OVERLAY_PG = "Finger_Print_Quicker_Login_Overlay-pg";
    public static final String FINGER_PRINT_QUICKER_LOGIN_MODAL_ENABLE_BTN = "FINGER_PRINT_QUICKER_LOGIN_MODAL_ENABLE_BTN";
    public static final String FINGER_PRINT_QUICKER_LOGIN_MODAL_DONT_ENABLE_LNK = "FINGER_PRINT_QUICKER_LOGIN_MODAL_DONT_ENABLE_LNK";
    public static final String FINGER_PRINT_TOAST_MESSAGE_OVERLAY = "Finger_Print_Toast_Message_Overlay";
    public static final String FINGER_PRINT_INTRO_PG = "Finger_Print_Intro-pg";
    public static final String FINGER_PRINT_SUCCESS_CONFIRMATION_PG = "Finger_Print_Success_Confirmation-pg";
    public static final String FINGER_PRINT_INTRO_ENABLE_BTN = "FINGER_PRINT_INTRO_ENABLE_BTN";
    public static final String EXIT_SETUP_LNK = "EXIT_SETUP_LNK";
    public static final String FINGERPRINT_ENABLED_PG = "FingerPrint_Enabled-pg";
    public static final String FINGER_PRINT_SETUP_PASSCODE_PG = "Finger_Print_Setup_Passcode-pg";
    public static final String FINGER_PRINT_SETUP_DEVICE_PG = "Finger_Print_Setup_Device-pg";
    public static final String FP_PAGENAME = "pageName";
    public static final String PASSCODE_SETUP_ON = "Passcode Setup:On";
    public static final String PASSCODE_SETUP_OFF = "Passcode Setup:Off";
    public static final String FINGERPRINT_OFF = "Finger Print:Off";
    public static final String FINGERPRINT_ON = "Finger Print:On";
    public static final String FINGERPRINT_LOGIN_PG = "login-pg";
    public static final String FINGERPRINT_LOGIN_SUCCESSFUL = "login_successful";
    public static final String FINGERPRINT_EVENT4 = "event4";
    /**End Changes for US71879: Fingerprint Site Catalyst Tags*/

    /** Start Changes for US79561: App Store Pop Up Analytics Tags */
    public static final String APP_STORE_MODAL_PG = "App_Store_Modal-pg";
    public static final String APP_STORE_MODAL_RATE_DISCOVER_LNK = "APP_STORE_MODAL_RATE_DISCOVER_LNK";
    public static final String APP_STORE_MODAL_REMIND_ME_LATER_LN = "APP_STORE_MODAL_REMIND_ME_LATER_LNK";
    public static final String APP_STORE_MODAL_NO_THANKS_LNK = "APP_STORE_MODAL_NO_THANKS_LNK";
    /** End Changes for US79561: App Store Pop Up Analytics Tags */


    //Start: US48867-ATM Analytics
    public static final String ATM_HELP_ICON = "ATM_HelpIcon";
    public static final String ATM_LOCATION_SERVICES_ALLOW_BTN = "ATM_LOCATION_SERVICES_ALLOW_BTN";
    public static final String ATM_LOCATION_SERVICES_DONT_ALLOW_BTN = "ATM_LOCATION_SERVICES_DONT_ALLOW_BTN";
    public static final String ATM_TAPTOHOLD_TOGGLE_ON = "ATM_TapToHold_Toggle_On";
    public static final String ATM_TAPTOHOLD_TOGGLE_OFF = "ATM_TapToHold_Toggle_Off";
    public static final String ATM_KEYBOARD_ARROW_SEARCH_BTN = "ATM_KEYBOARD_ARROW_SEARCH_BTN";
    public static final String ATM_RESULTS_LIST_VIEW = "ATM_Results_List_View_";
    public static final String LINK = "_Lnk";
    public static final String ATM_LOCATION_ICON_TOGGLEON = "ATM_LOCATION_ICON_Toggle_On";
    public static final String ATM_LOCATION_ICON_TOGGLEOFF = "ATM_LOCATION_ICON_Toggle_Off";
    public static final String ATM_MAP_PIN_LNK = "ATM_MAP_VIEW_ATM_PIN_LNK";
    public static final String ATM_LIST_VIEW_REPORT_ATM_PROBLEM_LNK = "ATM_LIST_VIEW_REPORT_ATM _PROBLEM_LNK";
    public static final String ATM_LIST_VIEW_ATM_PIN_LNK = "ATM_LIST_VIEW_ATM_PIN_LNK";
    public static final String ATM_SEARCH_AUTOCOMPLETE = "ATM_SEARCH_AUTOCOMPLETE";
    //End:  US48867-ATM Analytics

    //Start: US89316: Repeating Bill Pay Analytics
    public static final String PAYBILL_DELETE_SCHEDULE_PAYMENT_MODAL = "Paybills_Delete_this_Schedule_Payment_Modal-pg";
    public static final String PAYMENT_SCHEDULEDETAILS = "PayBills_PaymentDetails";
    public static final String PAYBILL_EVENT22 = "event22";
    public static final String PAYBILL_EVENT9 = "event9";
    public static final String PAYBILLS_DELETE_SCHEDULE_PAYMENT_ENTIRE_SERIES_LNK = "PAYBILLS_DELETE_SCHEDULE_PAYMENT_ENTIRE_SERIES_LNK";
    public static final String PAYBILLS_DELETE_SCHEDULE_PAYMENT_THIS_PAYMENT_ONLY_BTN = "PAYBILLS_DELETE_SCHEDULE_PAYMENT_THIS_PAYMENT_ONLY_BTN";
    public static final String PAYBILLS_SCHEDULE_PAYMENT_CANCEL_LNK = "PAYBILLS_SCHEDULE_PAYMENT_CANCEL_LNK";
    public static final String PAYBILLS_SCHEDULE_PAYMENT = "PAYBILLS_SCHEDULE_PAYMENT_";
    public static final String SCHEDULE_PAYMENT_BTN = "_SCHEDULE_PAYMENT_BTN";
    public static final String PAYBILL_DELETE_SCHEDULE_PAYMENT_SUCCESSFUL = "Paybills_Delete_this_Schedule_Payment_Successful-pg";

    //US99421: Manage External Accounts: Analytics
    public static final String MEA_ADD_EXTERNAL_ACCOUNT_BTN = "MEA_ADD_EXTERNAL_ACCOUNT_BTN";
    public static final String MEA_ADD_EXTERNAL_ACCOUNT_LNK = "MEA_ADD_EXTERNAL_ACCOUNT_LNK";
    public static final String MEA_DO_YOU_OWN_THIS_ACCOUNT_VERIFY_ACCOUNT_BTN = "MEA_DO_YOU_OWN_THIS_ACCOUNT_VERIFY_ACCOUNT_BTN";
    public static final String BANK_EVENT9 = "event9";
    public static final String MEA_ADD_EXTERNAL_ACCOUNT_SUCCESS_PAGE = "MEA_Add_New_Account_Successful-pg";
    public static final String MEA_TRIAL_DEPOSIT_SUCCESS_PAGE = "MEA_Trial_Deposit_Information_Success-pg";
    public static final String MEA_DELETE_EXTERNAL_MODAL_YES_DELETE_BTN = "MEA_DELETE_EXTERNAL_MODAL_YES_DELETE_BTN";
    public static final String MEA_ADD_EXTERNAL_ACCOUNT_PAGE = "MEA_Add_External_Account-pg";
    public static final String MEA_ADD_NEW_ACCOUNT_PAGE = "MEA_Add_New_Account-pg";
    public static final String MEA_TRIAL_DEPOSIT_INFORMATION_PAGE = "MEA_Trial_Deposit_Information-pg";
    public static final String MEA_ADD_ACCOUNT_PROP5 = "Add_Account";
    public static final String MEA_ADD_ACCOUNT_EVAR5 = "Add_Account";
    public static final String MEA_DEPOSIT_INFORMATION_EVAR5 = "Deposit Information";
    public static final String MEA_DEPOSIT_INFORMATION_PROP5 = "Deposit Information";
    public static final String MEA_ADD_ACCOUNT_EVENT22 = "event22";


    //US99183: Rocket fuel tags for BT flow constants:
    public static final String BT_LANDING_TITLE = "BT Landing page";
    public static final String BT_COMPLETED = "BT Complete";
    public static final String BT_ABANDON = "BT abandon";

    //US103379 ; Rocket fuel tags for RAF
    public static final String RAF_LANDING_TITLE = "Refer a Friend Landing Page";
    public static final String RAF_EMAIL_TITLE = "Refer a Friend-Email";
    public static final String RAF_FB_TITLE = "Refer a Friend-Facebook";
    public static final String RAF_TWITTER_TITLE = "Refer a Friend-Twitter";
    public static final String RAF_TEXT_TITLE = "Refer a Friend-Text";

    //US103375: Rocket fuel tags for FICO
    public static final String FICO_LANDING_TITLE = "FICO";

    //US103386: Rocket fuel tags for Alerts

    public static final String ALERTS_LANDING_TITLE = "Manage Alerts Page";
    public static final String ALERTS_SAVE_TITLE = "Mange Alerts-Save Changes";

    //US103389: Rocket fuel tags for make payment
    public static final String MAKE_PAYMENT_LANDING_TITLE = "Make a Payment Landing Page";
    public static final String MAKE_PAYMENT_CONFIRMATION_TITLE = "Make a Payment Confirmation Page";

    //US103817-- DPL Analytics

    public static final String DPL_PAYMENT_SAVE_PHOTO_BTN = "PAYMENT_SAVE_PHOTO_BTN";
    public static final String DPL_CONTINUE_TO_SUBMIT_PAYMENT_BTN = "CONTINUE_TO_SUBMIT_PAYMENT_BTN";
    public static final String DPL_MAKE_A_PAYMENT_MULTIPLE_PMTS_BTN = "MAKE_A_PAYMENT_MULTIPLE_PMTS_BTN";
    public static final String DPL_VIEW_SCHEDULED_PAYMENTS_BTN = "VIEW_SCHEDULED_PAYMENTS_BTN";
    public static final String DPL_MAKE_A_PAYMENT_DELINQUENT_BTN = "MAKE_A_PAYMENT_DELINQUENT_BTN";
    public static final String DPL_OTHER_AMOUNT_BTN = "OTHER_AMOUNT_BTN";
    public static final String DPL_TOTAL_PAYOFF_AMOUNT_BTN = "TOTAL_PAYOFF_AMOUNT_BTN";
    public static final String DPL_SCHEDULE_PAYMENT_BTN = "SCHEDULE_PAYMENT_BTN";
    public static final String DPL_MAKE_A_PAYMENT_PAGE = "MakeaLoanPayment_PaymentDetails";

    //US109616: Rocket fuel tags for BT
    public static final String BALANCE_TRANSFER_OFFER_DETAIL = "BT offer detail";
    public static final String BALANCE_TRANSFER_CREDIT_CARD_LOAN = "BT Pay off a Credit Card or Loan";
    public static final String BALANCE_TRANSFER_TRANSFER_FUND_INTO_CHECKING = "BT transfer fund into checking";
    public static final String BALANCE_TRANSFER_TRANSFER_REVIEW_PAGE = "BT review page";

    //US109617: Rocket fuel tags for Statement Credit

    public static final String STATEMENT_CREDIT_LANDING_PAGE = "Statement Credit landing page";
    public static final String STATEMENT_CREDIT_VERIFY_PAGE = "Statement Credit verify page";

    //US109618: Rocket fuel tags for Electronic deposit

    public static final String REDEM_ELECTRONIC_DEPO_LANDING_PAGE = "Electronic Credit landing page";
    public static final String REDEM_ELECTRONIC_DEPO_VERIFY_PAGE = "Electronic Deposit verify page";


    //US109619: Rocket fuel tags for Amazon
    public static final String REDEM_AMAZON_CLICK = "Amazon.com click";


    /*Start Changes for US88453*/
    public static final String CONTACTUS_ONLINE_MESSAGING_TXT = "CONTACTUS_ONLINE_MESSAGING_TXT";
    public static final String MESSAGING_INAPP_CHAT_PG = "Messaging_InApp_Chat-pg";
    public static final String SUBMENU_MESSAGING_TXT = "SUBMENU_MESSAGING_TXT";
    public static final String SUBMENU_SMC_TXT = "SUBMENU_SMC_TXT";
    public static final String SUBMENU_NOTIFICATION_TXT = "SUBMENU_NOTIFICATION_TXT";
    public static final String CONTACTUS_PAGE_MSG_LINK = "Contact Us:Messaging:";
    public static final String CONTACTUS_PAGE_MSG_LINK_PAGE = "ContactUs_Loggedin-pg";
    public static final String SMC_PAGE_MSG_LINK = "SMC:Messaging:";
    public static final String SMC_SENT_MESSAGE_TAG = "Messaging:Sent Messages:";
    public static final String SMC_INBOX_MESSAGE_TAG = "Messaging:Inbox Messages:";
    public static final String NOTIFICATION_PAGE_MSG_LINK = "Notification:Messaging:";
    public static final String NOTIFICATION_PAGE_MSG_LINK_PAGE = "alertHistory-pg";
    public static final String MESSAGING_RATE_YOUR_EXPERIENCE_POST_SURVEY_CLOSE_LNK = "MESSAGING_RATE_YOUR_EXPERIENCE_POST_SURVEY_CLOSE_LNK";
    public static final String MESSAGING_LOG_OUT_MODAL_PG = "Messaging_Log_Out_Modal-pg";
    public static final String MESSAGING_LOGOUT_MODAL_CONTINUELOGOUT_BTN = "MESSAGING_LOGOUT_MODAL_CONTINUELOGOUT_BTN";
    public static final String MESSAGING_LOGOUT_MODAL_READLATER_BTN = "MESSAGING_LOGOUT_MODAL_READLATER_BTN";
    public static final String MESSAGING_ERROR_MODAL_PG = "Messaging_Error_Modal-pg";
    public static final String MESSAGING_RATE_YOUR_EXPERIENCE_POST_SURVEY_PG = "Messaging_Rate_your_Experience_Post_Survey-pg";
    public static final String SMC_PAGE_NAME = "SecureMessageCenter_Landing_pg";
    /*End Changes for US88453*/

    /*US125198-Android- Whats New TAGGING - Messaging start*/

    public static final String APP_MESSAGING_WHATSNEW_PG = "Message_MessageUs_WhatsNew-pg";
    public static final String APP_MESSAGING_HIGHLIGHTED_PG = "Message_MessageUs_Highlighted_Feature-pg";
    public static final String APP_MESSAGING_WHATSNEW_GOTO_MSG_BTN = "MESSAGE_MESSAGEUS_WHATSNEW_GOTOMSG_BTN";
    public static final String APP_MESSAGING_HF_GOTO_MSG_BTN = "MESSAGE_MESSAGEUS_HIGHLIGHTED_FEATURE_GOTOMSG_BTN";

    /*US125198-Android- Whats New TAGGING - Messaging end*/


    public static final String CARD_HOME_Dynamic_Value_BANNER_LNK = "CARD_HOME_TIER%s_BANNER_LNK";
    public static final String Card_Home_WT_Banner_Modal_Page = "Card_Home_WT_Banner_Modal-pg";
    public static final String CARD_HOME_Dynamic_value_MODAL_CLOSE_BTN = "CARD_HOME_TIER%s_MODAL_CLOSE_BTN";
    public static final String CARD_HOME_TIER_BANNER_CLOSE_LNK = "CARD_HOME_TIER%s_BANNER_CLOSE_LNK";

    /* sitecat tags for ANR intercept*/
    public static final String FRAUD_INTERCEPT_PAGE = "Account_Transfer_Fraud_During-pg";
    public static final String FRAUD_INTERCEPT_CONTINUE_TO_HOME_BTN_PROP1_PEV1 = "ACCT_XFER_FRAUD_DURING_CONTINUE_TO_ACCT_HOME_BTN";
    public static final String FRAUD_INTERCEPT_COMMON_QUESTION_EXPAND = "ACCT_XFER_FRAUD_DURING_COMMON_QUES_EXPAND_LNK";
    public static final String FRAUD_INTERCEPT_COMMON_QUESTION_COLLAPSE = "ACCT_XFER_FRAUD_DURING_COMMON_QUES_COLLAPSE_LNK";
    public static final String LOST_STOLEN_INTERCEPT_PAGE = "Account_Transfer_Lost_Stolen_During-pg";
    public static final String LOST_STOLEN_INTERCEPT_CONTINUE_TO_HOME_BTN_PROP1_PEV1 = "ACCT_XFER_LOST_STOLEN_DURING_CONTINUE_TO_ACCT_HOME_BTN";
    public static final String LOST_STOLEN_INTERCEPT_COMMON_QUESTION_EXPAND = "ACCT_XFER_LOST_STOLEN_DURING_COMMON_QUES_EXPAND_LNK";
    public static final String LOST_STOLEN_INTERCEPT_COMMON_QUESTION_COLLAPSE = "ACCT_XFER_LOST_STOLEN_DURING_COMMON_QUES_COLLAPSE_LNK";
    public static final String ACHOME_BANNER_ACCOUNT_SETUP_PEV1_PROP1 = "AC_HOME_ACCOUNT_SETUP_BANNER_LNK";
    public static final String ACHOME_BANNER_ACCOUNT_CLOSE_BUTTON_SETUP_PEV1_PROP1 = "AC_HOME_ACCOUNT_SETUP_BANNER_CLOSE_LNK";
    public static final String ACHOME_BANNER_DISPLAY_MODAL = "Account_Transfer_Setup_Modal-pg";
    public static final String ACHOME_BANNER_DISPLAY_MODAL_CLOSE_BUTTON_PROP1_PEV1 = "ACCT_XFER_SETUP_MODAL_CLOSE_BTN";
    public static final String ANR_RESTRICTED_MODAL_PAGE = "ANR_Restricted_Modal-pg";
    public static final String ANR_RESTRICTED_MODAL_CLOSE_BUTTON = "ANR_RESTRICTED_MODAL_CLOSE_BTN";

    /*Start Changes for US121913*/
    public static final String FICO_CREDITSCORE_PG = "FICO_CreditScore-pg";
    public static final String FICO_CREDITSCORE_RATING = "CSC:FICO Score:";
    public static final String FICO_CREDITSCORE_HELPING = "CSC:Helping:";
    public static final String FICO_CREDITSCORE_HURTING = "CSC:Hurting:";
    public static final String FICO_CREDITSCORE_WITH_GAP=":90 Days Avail:Details Avail:With Gaps";
    public static final String FICO_CREDITSCORE_WITHOUT_GAP=":90 Days Unavail:Details Unavail:Without Gaps";
    public static final String FICO_CREDITSCORE_INCREASED = "Increased";
    public static final String FICO_CREDITSCORE_DECREASED = "Decreased";
    public static final String FICO_CREDITSCORE_NO_CHANGE = "No Change";
    public static final String FICO_CREDITSCORE_NO_PREVIOUS = "No Previous";
    public static final String FICO_CREDITSCORE_DETAILS_PG = "FICO_CreditScore_Details-pg";
    //Total Account
    public static final String FICO_CREDITSCORE_TOTALACCOUNTS_PG = "FICO_CreditScore_TotalAccounts-pg";
    public static final String FICO_CREDITSCORE_TOTAL_ACCOUNT_RATING = "CSC:Total Accounts:";
    public static final String FICO_CREDITSCORE_TOTAL_ACCOUNT_WITH_CHANGE= "CSC:Total Accounts:With Change";
    public static final String FICO_CREDITSCORE_TOTAL_ACCOUNT_WITHOUT_CHANGE = "CSC:Total Accounts:Without Change";
    //Length of Credit
    public static final String FICO_CREDITSCORE_LENGHTOFCREDIT_PG = "FICO_CreditScore_LenghtofCredit-pg";
    public static final String FICO_CREDITSCORE_LENGTH_OF_CREDIT_RATING = "CSC:Length of Credit:";
    //Inquiries
    public static final String FICO_CREDITSCORE_INQUIRIES_PG = "FICO_CreditScore_Inquiries-pg";
    public static final String FICO_CREDITSCORE_INQUIRIES_RATING = "CSC:Inquiries:";
    public static final String FICO_CREDITSCORE_INQUIRIES_WITH_CHANGE = "CSC:Inquiries:With Change";
    public static final String FICO_CREDITSCORE_INQUIRIES_WITHOUT_CHANGE = "CSC:Inquiries:Without Change";
    //Revolving Utilization
    public static final String FICO_CREDITSCORE_REVOLVINGUTILIZATION_PG = "FICO_CreditScore_RevolvingUtilization-pg";
    public static final String FICO_CREDITSCORE_REVOLVINGUTILIZATION_RATING = "CSC:Revolving Utilization:";
    //Revolving Utilization Unavailable
    public static final String FICO_CREDITSCORE_REVOLVINGUTILIZATION = "CSC:Revolving Utilization";
    public static final String FICO_CREDITSCORE_REVOLVINGUTILIZATION_UNAVAILABLE = "CSC:Revolving Utilization:Unavailable";
    //Missed Payments
    public static final String FICO_CREDITSCORE_MISSEDPAYMENTS_PG = "FICO_CreditScore_MissedPayments-pg";
    public static final String FICO_CREDITSCORE_MISSEDPAYMENTS_RATING = "CSC:Missed Payment:";
    public static final String FICO_CREDITSCORE_MISSEDPAYMENTS_WITH_CHANGE= "CSC:Missed Payment:With Change";
    public static final String FICO_CREDITSCORE_MISSEDPAYMENTS_WITHOUT_CHANGE = "CSC:Missed Payment:Without Change";
    public static final String FICO_CREDITSCORE_NOSCORE_PG = "FICO_CreditScore_NoScore-pg";
    public static final String FICO_CREDITSCORE_ATTRIBUTE_UNAVAIL_MODAL_PG = "FICO_CreditScore_Attribute_Unavail_Modal-pg";
    //Link Tracking
    public static final String FICO_CREDITSCORE_FAQ_LINK = "CSC:FICO Score:FAQ";
    public static final String FICO_CREDITSCORE_GRAPH_TOGGLE_LINK = "CSC:FICO Score:Toggle:Graph";
    public static final String FICO_CREDITSCORE_TOGGLE_TABLE_LINK = "CSC:FICO Score:Toggle:Table";
    public static final String FICO_CREDITSCORE_EXPAND_KEY_FACTORS = "CSC:FICO Score:Expand:Key Factors";
    public static final String FICO_CREDITSCORE_HELP_SCORE_STRENGTH = "CSC:FICO Score:Help:Score Strength";
    public static final String FICO_CREDITSCORE_TOTAL_ACCOUNTS_IMPACT = "CSC:Total Accounts:Impact";
    public static final String FICO_CREDITSCORE_LENGT_OF_CREDIT_IMPACT = "CSC:Length of Credit:Impact";
    public static final String FICO_CREDITSCORE_INQUIRIES_IMPACT = "CSC:Inquiries:Impact";
    public static final String FICO_CREDITSCORE_REVOLVING_UTILIZATION_IMPACT = "CSC:Revolving Utilization:Impact";
    public static final String FICO_CREDITSCORE_MISSED_PAYMENTS_IMPACT = "CSC:Missed Payments:Impact";
    public static final String FICO_CREDITSCORE_90_DAYS_UNAVAILABLE_WHY = "CSC:FICO Score:90 Days Unavailable:Why";
    /*End Changes for US121913*/

    /*US113465 : OverDraft Whatsnew Sitcat*/
    public static final String WHATS_NEW_X_BUTTON_MYPROP = "OVERDRAFT_PROTECTION_WHATS_NEW_CLOSE_LNK";
    public static final String WHATS_NEW_X_BUTTON_PEV1 = "OVERDRAFT_PROTECTION_WHATS_NEW_CLOSE_LNK";

    /** Start Changes for US14072 */
    public static final String CASH_BACK_BONUS_EVENT22 = "event22";
    public static final String CASH_BACK_BONUS_EVENT9 = "event9";
    public static final String CASH_BACK_BONUS_PROMOS_LANDING_PG = "Cash_Back_Bonus_Promos_Landing-pg";
    public static final String CASH_BACK_BONUS_PROMOS_ACTIVATE_NOW_LNK = "CASH_BACK_BONUS_PROMOS_ACTIVATE_NOW_LNK";
    public static final String CASH_BACK_BONUS = "CASH_BACK_BONUS:";
    public static final String CASH_BACK_BONUS_PROMOS_DETAIL_LNK = "CASH_BACK_BONUS_PROMOS_DETAIL_LNK";
    public static final String CASH_BACK_BONUS_PROMOS_SAVE_CALENDAR_TO_PHOTOS_LNK = "CASH_BACK_BONUS_PROMOS_SAVE_CALENDAR_TO_PHOTOS_LNK";
    public static final String CASH_BACK_BONUS_PROMOS_SAVE_CALENDAR_TO_PHOTOS_PG = "Cash_Back_Bonus_Promos_Save_Calendar_to_Photos-pg";
    public static final String CASH_BACK_BONUS_PROMOS_SAVE_CALENDAR_TO_PHOTOS_SAVE_BTN = "CASH_BACK_BONUS_PROMOS_SAVE_CALENDAR_TO_PHOTOS_SAVE_BTN";
    public static final String CASH_BACK_BONUS_PROMOS_SAVE_CALENDAR_TO_PHOTOS_CANCEL_LNK = "CASH_BACK_BONUS_PROMOS_SAVE_CALENDAR_TO_PHOTOS_CANCEL_LNK";
    public static final String CASH_BACK_BONUS_PROMOS_DETAIL_PG = "Cash_Back_Bonus_Promos_Detail-pg";
    public static final String CASH_BACK_BONUS_PROMOS_DETAIL_ACTIVATE_NOW_BTN = "CASH_BACK_BONUS_PROMOS_DETAIL_ACTIVATE_NOW_BTN";
    public static final String CASH_BACK_BONUS_CONFIRMATION_PG = "Cash_Back_Bonus_Confirmation-pg";
    public static final String CASH_BACK_BONUS_PROMOS_DETAIL_ADD_TO_CALENDAR_BTN = "CASH_BACK_BONUS_PROMOS_DETAIL_ADD_TO_CALENDAR_BTN";
    public static final String CASH_BACK_BONUS_ADD_CALENDAR_PG = "Cash_Back_Bonus_Add_Calendar-pg";
    public static final String CASH_BACK_BONUS_PROGRAM_TERMS_MODAL_PG = "Cash_Back_Bonus_Program_Terms_Modal-pg";
    public static final String CASH_BACK_BONUS_PROMOS_EVENT_ADDED_SUCCESSFUL_PG = "Cash_Back_Bonus_Promos_Event_Added_Successful-pg";
    public static final String CASH_BACK_BONUS_PROMOS_DETAIL_VIEW_IN_CALENDAR_BTN = "CASH_BACK_BONUS_PROMOS_DETAIL_VIEW_IN_CALENDAR_BTN";

    public static final String Cash_Back_Bonus_Edit_Calendar_pg = "Cash_Back_Bonus_Edit_Calendar-pg";
    public static final String CASH_BACK_BONUS_DELETE_CALENDAR_PG = "Cash_Back_Bonus_Delete_Calendar-pg";
    public static final String CASH_BACK_BONUS_VIEW_CALENDAR_PG = "Cash_Back_Bonus_View_Calendar-pg";
    public static final String CASH_BACK_BONUS_PROMOS_EVENT_DELETE_SUCCESSFUL_PG = "Cash_Back_Bonus_Promos_Event_Delete_Successful-pg";
    /** End Changes for US14072*/

    public static final String  LOST_STOLEN_CARD_OVERNIGHT_SHIPPING_TYPE = "LOST_STOLEN_CARD_DELIVERY:FEDEX OVERNIGHT SHIPPING" ;
    public static final String  LOST_STOLEN_CARD_STANDARD_SHIPPING_TYPE = "LOST_STOLEN_CARD_DELIVERY:STANDARD SHIPPING" ;
    public static final String REPORT_LOST_STOLEN_IMPORTANT_INFO_PHONE_NUMBER_LNK = "REPORT_LOST_STOLEN_IMPORTANT_INFO_PHONE_NUMBER_LNK";

    //Replace Card Overnight Shipping Tagging
    public static final String REPLACE_CARD_SHIPPING_LANDING_PAGE =  "Replace_Card_Important_Info-pg";
    public static final String REPLACE_CARD_CONFIRMATION_MESSAGE_PAGE =  "Replace_Card_Confirmation_Message-pg";
    public static final String REPLACE_CARD_SHIPPING_LANDING_PAGE_PROP5 =  "Replace Card Delivery Type : Standard and Fedex Overnight Shipping";
    public static final String REPLACE_CARD_STANDARD_SHIPPING_LANDING_PAGE_PROP5 =  "Replace Card Delivery Type : Standard Shipping";
    public static final String REPLACE_CARD_OVERNIGHT_SHIPPING_LANDING_PAGE_PROP5 =  "Replace Card Delivery Type : Overnight Shipping";
    public static final String REPLACE_CARD_IMPORTANT_INFO_CONFIRM_BTN =  "REPLACE_CARD_IMPORTANT_INFO_CONFIRM_BTN";
    public static final String REPLACE_CARD_STANDARD_SHIPPING_TYPE =  "REPLACE_CARD_DELIVERY:STANDARD SHIPPING";
    public static final String REPLACE_CARD_OVERNIGHT_SHIPPING_TYPE =  "REPLACE_CARD_DELIVERY:FEDEX OVERNIGHT SHIPPING";
    public static final String REPLACE_CARD_IMPORTANT_INFO_CANCEL_LNK =  "REPLACE_CARD_IMPORTANT_INFO_CANCEL_LNK";
    public static final String REPLACE_CARD_IMPORTANT_INFO_PHONENUMBER_LNK =  "REPLACE_CARD_IMPORTANT_INFO_PHONENUMBER_LNK";
    public static final String REPLACE_CARD_SHIPPING_EVENT22 =  "event22";
    public static final String REPLACE_CARD_CONFIRMATION_PG = "Replace_Card_Confirmation_Message-pg";


    // US152703 Apply-now tags - Start
    String APPLY_NOW_BANNER_PAGE_NAME = "Apply_Prompt_Message_Modal-pg";
    String APPLY_NOW_BANNER_PAGE_PROP1 = "APPLY_PROMPT_MESSAGE_BANNER_LNK";
    String APPLY_NOW_BANNER_PAGE_PEV1 = "APPLY_PROMPT_MESSAGE_BANNER_LNK";

    String APPLY_NOW_DIT_PAGE_NAME = "Apply_Prompt_Card_Message_Modal-pg";
    String APPLY_NOW_DIT_PROP1 = "APPLY_PROMPT_CARD_MESSAGE_MODAL_APPLY_NOW_LNK";
    String APPLY_NOW_DIT_PEV1 = "APPLY_PROMPT_CARD_MESSAGE_MODAL_APPLY_NOW_LNK";
//    String APPLY_NOW_DIT_PROP20 = "https://www.discover.com/credit-cards/cash-back/it-card.html?SCMobileOrigin=AndroidMobile";

    String APPLY_NOW_ONLINE_BANKING_PAGE_NAME = "Apply_Prompt_Open_Bank_Account_Message_Modal-pg";
    String APPLY_NOW_ONLINE_BANKING_PROP1 = "APPLY_PROMPT_OPEN_BANK_ACCOUNT_MESSAGE_MODAL_OPEN_AN_ACCOUNT_LNK";
    String APPLY_NOW_ONLINE_BANKING_PEV1 = "APPLY_PROMPT_OPEN_BANK_ACCOUNT_MESSAGE_MODAL_OPEN_AN_ACCOUNT_LNK";

    String APPLY_NOW_PERSONAL_LOAN_PAGE_NAME = "Apply_Prompt_CYR_DPL_Message_Modal-pg";
    String APPLY_NOW_PERSONAL_LOAN_PROP1 = "APPLY_PROMPT_CYR_DPL_MESSAGE_MODAL_CHECK_YOUR_RATE_LNK";
    String APPLY_NOW_PERSONAL_LOAN_PEV1 = "APPLY_PROMPT_CYR_DPL_MESSAGE_MODAL_CHECK_YOUR_RATE_LNK";

    String APPLY_NOW_PAGE_NAMES[] = {APPLY_NOW_DIT_PAGE_NAME, APPLY_NOW_ONLINE_BANKING_PAGE_NAME, APPLY_NOW_PERSONAL_LOAN_PAGE_NAME};
    String APPLY_NOW_PROP1_ARRAY[] = {APPLY_NOW_DIT_PROP1, APPLY_NOW_ONLINE_BANKING_PROP1, APPLY_NOW_PERSONAL_LOAN_PROP1};
    String APPLY_NOW_PEV1_ARRAY[] = {APPLY_NOW_DIT_PEV1, APPLY_NOW_ONLINE_BANKING_PEV1, APPLY_NOW_PERSONAL_LOAN_PEV1};
    // US15'2703 Apply-now tags - End

    //Profile Redesign Tags
    public static final String PROFILES_AND_SETTINGS_PROFILE_LNK = "PROFILES_AND_SETTINGS_PROFILE_LNK";
    public static final String ACCOUNT_PROFILE_EDUCATION_INFO_LNK = "ACCOUNT_PROFILE_EDUCATION_INFO_LNK";
    public static final String ACCOUNT_PROFILE_CONTACT_INFO_LNK = "ACCOUNT_PROFILE_CONTACT_INFO_LNK" ;
    public static final String  ACCOUNT_PROFILE_INCOME_AND_HOUSING_INFO_LNK = "ACCOUNT_PROFILE_INCOME_AND_HOUSING_INFO_LNK" ;
    public static final String ACCOUNT_PROFILE_ACCOUNT_INFO_MANAGE_CARD_LNK = "ACCOUNT_PROFILE_ACCOUNT_INFO_MANAGE_CARD_LNK";
    public static final String  ACCOUNT_PROFILE_ACCOUNT_INFO_MANAGE_LNK = "ACCOUNT_PROFILE_ACCOUNT_INFO_MANAGE_LNK" ;
    public static final String  ACCOUNT_PROFILE_INCOME_AND_HOUSING_INFO_EDIT_LNK = "ACCOUNT_PROFILE_INCOME_AND_HOUSING_INFO_EDIT_LNK";
    public static final String  ACCOUNT_PROFILE_EDUCATION_INFO_EDIT_LNK = "ACCOUNT_PROFILE_EDUCATION_INFO_EDIT_LNK";
    public static final String  ACCOUNT_PROFILE_CONTACT_INFO_EDIT_LNK = "ACCOUNT_PROFILE_CONTACT_INFO_EDIT_LNK";
    public static final String  ACCOUNT_PROFILE_EDUCATION_INFO_EDIT_PAGE = "Account_Profile_Education_Info_Edit-pg";
    public static final String  ACCOUNT_PROFILE_CONTACT_INFO_EDIT_PAGE = "Account_Profile_Contact_Info_Edit-pg";
    public static final String  ACCOUNT_PROFILE_INCOME_HOUSING_INFO_EDIT_PAGE = "Account_Profile_Income_And_Housing_Info_Edit-pg";

    public static final String ACCOUNT_PROFILE_EDUCATION_INFO_EDIT_CANCEL_LNK = "ACCOUNT_PROFILE_EDUCATION_INFO_EDIT_CANCEL_LNK";
    public static final String ACCOUNT_PROFILE_CONTACT_INFO_EDIT_CANCEL_LNK = "ACCOUNT_PROFILE_CONTACT_INFO_EDIT_CANCEL_LNK";
    public static final String ACCOUNT_PROFILE_INCOME_AND_HOUSING_EDIT_CANCEL_LNK = "ACCOUNT_PROFILE_INCOME_AND_HOUSING_EDIT_CANCEL_LNK";

    public static final String ACCOUNT_PROFILE_EDUCATION_INFO_EDIT_SAVE_BTN = "ACCOUNT_PROFILE_EDUCATION_INFO_EDIT_SAVE_BTN";
    public static final String ACCOUNT_PROFILE_CONTACT_INFO_EDIT_SAVE_BTN = "ACCOUNT_PROFILE_CONTACT_INFO_EDIT_SAVE_BTN";
    public static final String ACCOUNT_PROFILE_INCOME_AND_HOUSING_EDIT_SAVE_BTN = "ACCOUNT_PROFILE_INCOME_AND_HOUSING_EDIT_SAVE_BTN";

    public static final String ACCOUNT_PROFILE_TOTAL_ANUAL_GROSS_INCOME_MODEL =  "Account_Profile_Total_Annual_Gross_Income_Modal-pg";
    public static final String ACCOUNT_PROFILE_TOTAL_AVAILABLE_ASSETS_MODEL  =  "Account_Profile_Total_Available_Assets_Modal-pg";
    public static final String ACCOUNT_PROFILE_CHANGES_ABANDON_MODEL =  "Account_Profile_Changes_Will_Be_Lost_Modal-pg";
    public static final String ACCOUNT_PROFILE_EDIT_CONTACT_SUCCESS_PG =  "Account_Profile_Edit_Contact_Info_Success-pg";
    public static final String ACCOUNT_PROFILE_EDIT_EDUCATION_SUCCESS_PG =  "Account_Profile_Edit_Education_Info_Success-pg";
    public static final String ACCOUNT_PROFILE_EDIT_INCOME_HOUSING_SUCCESS_PG =  "Account_Profile_Edit_Income_And_Housing_Info_Success-pg";

    public static final String ACCOUNT_PROFILE_CHANGES_WILL_BE_LOST_MODAL_CONTINUE_BTN = "ACCOUNT_PROFILE_CHANGES_WILL_BE_LOST_MODAL_CONTINUE_BTN";
    public static final String ACCOUNT_PROFILE_CHANGES_WILL_BE_LOST_MODAL_GOBACK_BTN = "ACCOUNT_PROFILE_CHANGES_WILL_BE_LOST_MODAL_GOBACK_BTN";

    //change user id and password tags -- starts
    String CHANGE_USERID_PASSWORD_PROFILESETTINGS_LNK_PROP1_PEV1 = "PROFILES_AND_SETTINGS_USERID_AND_PASSWORD_LNK";
    String CHANGE_USERID_PASSWORD_LANDINGPAGE = "Change_UserID_Password-pg";
    String CHANGE_USERID_PASSWORD_CHANGEUSERID_PENCILICON_PEV1_PROP1 = "CHANGE_USERID_PASSWORD_CHANGE_USERID_LNK";
    String CHANGE_USERID_PASSWORD_CHANGEPASSWORD_PENCILICON_PEV1_PROP1 = "CHANGE_USERID_PASSWORD_CHANGE_PASSWORD_LNK";
    String CHANGE_USERID_PASSWORD_FORGOT_LNK_PROP1_PEV1 = "CHANGE_USERID_PASSWORD_FORGOT_PASSWORD_LNK";
    String CHANGE_USERID_PASSWORD_CHANGEUSERID_LANDING_PAGE = "Change_UserID_Landing-pg ";
    String CHANGE_USERID_PASSWORD_CHANGEUSERID_LANDING_PAGE_EVENTS = "event22";

    String CHANGE_USERID_PASSWORD_CHANGEUSERID_PROP5_VAR5= "UserID_Change";
    String CHANGE_USERID_FORGOTPASSWORD_LNK_PROP1_PEV1= "CHANGE_USERID_FORGOT_PASSWORD_LNK";
    String CHANGE_USERID_SAVE_BUTTON_LNK_PROP1_PEV1= "CHANGE_USERID_SAVE_BTN";
    String CHANGE_USERID_SUCCESS_PAGE= "Change_UserID_Successful-pg";
    String CHANGE_USERID_SUCCESS_PAGE_EVENTS= "event9";
    String CHANGE_USERID_CANCEL_BUTTON_LNK_PROP1_PEV1= "CHANGE_USERID_CANCEL_LNK";

    String CHANGE_USERID_PASSWORD_CHANGEPASSWORD_LANDING_PAGE = "Change_Password_Landing-pg";
    String CHANGE_USERID_PASSWORD_CHANGEPASSWORD_LANDING_PAGE_EVENTS = "event22";
    String CHANGE_USERID_PASSWORD_CHANGEPASSWORD_PROP5_VAR5= "Password_Change";
    String CHANGE_PASSWORD_SAVE_BUTTON_LNK_PROP1_PEV1= "CHANGE_PASSWORD_SAVE_BTN";
    String CHANGE_PASSWORD_SAVE_BUTTON_LNK_PROP35= "CHANGE PASSWORD STRENGTH:";
    String CHANGE_PASSWORD_SUCCESS_PAGE= "Change_UserID_Successful-pg";
    String CHANGE_PASSWORD_SUCCESS_PAGE_EVENTS= "Change_Password_Successful-pg";
    String CHANGE_PASSWORD_CANCEL_BUTTON_LNK_PROP1_PEV1= "CHANGE_PASSWORD_CANCEL_LNK";
    String CHANGE_USERID_ERROR_TAGS= "Change_UserID:";
    String CHANGE_PASSWORD_ERROR_TAGS= "Change_Password:";
    // change user id and password tags -- ends

    //Customer service tags starts
    String FAQLANDINGPAGE= "FAQ_Landing-pg";
    String TRAVELNOTIFICATIONLANDING= "TravelNotificationDashboard-pg";
    String CUSTOMERSERVICELANDINGPAGE= "CustomerService_Landing-pg";
    String CUSTOMERSERVICEHFMANAGEALERTS = "HF_Alerts-pg";
    String CUSTOMERSERVICEHFMESSAGING = "HF_Messaging-pg";
    String CUSTOMERSERVICEHFFICOCREDIT = "HF_FICOScore-pg";
    String CUSTOMERSERVICEHFRAF = "HF_RAF-pg";
    String CUSTOMERSERVICEMAPCBB = "HF_MAP_CBB-pg";
    String CUSTOMERSERVICEFP = "HF_Fingerprint-pg";
    //Customer service tags ends

    //change password successful modal tags -- starts
    String CHANGE_PASSWORD_SUCCESS_MODAL_PAGE = "Change_Password_Successful_Modal-pg";
    String CHANGE_PASSWORD_SUCCESS_MODAL_EVENT9 = "event9";
    String CHANGE_PASSWORD_SUCCESS_MODAL_CHANGE_PASSCODE_BTN = "CHANGE_PASSWORD_SUCCESSFUL_MODAL_CHANGE_PASSCODE_BTN";
    String CHANGE_PASSWORD_SUCCESS_MODAL_CLOSE_LNK = "CHANGE_PASSWORD_SUCCESSFUL_MODAL_CLOSE_LNK";
    //change password successful modal tags -- ends


    /** Start changes for US163068 */
    public static final String DISCOVER_DEALS_MOP = "MOP:";
    public static final String DISCOVER_DEALS_SAVE_OFFER = "Deals Save Offer";
    public static final String DISCOVER_DEALS_UNSAVE_OFFER = "Deals Unsave Offer";
    public static final String DISCOVER_DEALS_UNSAVE = "UnSave";
    public static final String DISCOVER_DEALS_SAVE = "Save";
    public static final String DISCOVER_DEALS_PRE_LOGIN = "Pre-login:";
    public static final String DISCOVER_DEALS_POST_LOGIN = "Post-login:";
    public static final String DISCOVER_DEALS_HOME = "DealsHome:";
    public static final String DISCOVER_DEALS_SEARCH = "DealsSearch:";
    public static final String DISCOVER_DEALS_CATEGORY = "DealsCategory:";
    public static final String DISCOVER_DEALS_SAVED = "DealsSaved:";
    /** End changes for US163068*/

}
