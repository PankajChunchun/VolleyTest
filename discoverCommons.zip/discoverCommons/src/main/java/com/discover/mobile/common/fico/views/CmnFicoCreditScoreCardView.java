package com.discover.mobile.common.fico.views;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.fico.adapter.CmnCreditscoreListAdapter;
import com.discover.mobile.common.fico.adapter.CmnFicoKeyFactorsListAdapter;
import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.bean.FicoScoreList;
import com.discover.mobile.common.fico.bean.NegativeKeyFactor;
import com.discover.mobile.common.fico.bean.PositiveKeyFactor;
import com.discover.mobile.common.fico.interfaces.CmnFicoListItemInterface;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreLandingUIInterface;
import com.discover.mobile.common.fico.interfaces.FicoDashBoardExpandCollapseListner;
import com.discover.mobile.common.fico.interfaces.GraphClickListner;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.ui.table.TableHeaderButton;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.view.animation.TranslateAnimation;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;


/**
 * Created by 526158 on 5/10/2017.
 * This is common FICO Card View Layout
 */

public class CmnFicoCreditScoreCardView extends RelativeLayout implements FicoDashBoardExpandCollapseListner, GraphClickListner{

    private Context mContext;
    private FicoCardViewHolder ficoCardViewHolder;
    private int collapsedState = 2, expandedState = 1;
    private FicoCreditScore mFicoCreditScore = null;
    private FicoScoreList mFicoScoreListItem = null;
    private List<PositiveKeyFactor> mPositiveKeyFactorList = null;
    private List<NegativeKeyFactor> mNegativeKeyFactorList = null;
    private FicoCreditScoreLandingUIInterface mLandingUIInterface;
    private boolean isRevUtiExpandDisabled = false;
    private boolean isAllAttributeUnavail = false;
    private int state = expandedState;
    private int selectedListIndex = 0; // By default 0th list is selected
    private int listCountSize = 2; // Size of lists
    private LinkedHashMap<String, ArrayList<CmnFicoListItemInterface>> creditScoreListMap = null;
    private boolean isNoScoreAvailableFor90Days =false;


    /** start Key-factors changes */
    private int posExpListGroupHeight = 0;
    private int negExpListGroupHeight = 0;
    private int posExpListGroupSelected = -11;
    private int negExpListGroupSelected = -11;
    private int LIST_RENDERING_DELAY_INMISEC = 200;
    private int KEYFACTORS_RENDERING_DELAY_INMISEC = 50;
    /** end Key-factors changes */

    /*Start Changes For US121913*/
    private ArrayList<String> helpHurtArr = new ArrayList<String>();
    private String ratingValue = "Not Available", previousScoreChange = "Not Available";
    /*End Changes For US121913*/

    public CmnFicoCreditScoreCardView(Context context, final AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        initUI();
    }

    public CmnFicoCreditScoreCardView(Context context) {
        super(context);
        mContext = context;
        initUI();
    }

    private void initUI() {
        inflate(mContext, R.layout.cmn_fico_score_cardview, this);
        setUpViewHolder();
        handleClickEvents();
    }

    /**
     * Method to start data binding to this custom view
     */
    public void mapDataWithView(FicoCreditScore ficoCreditScore, FicoScoreList validScoreListItem,
                                List<PositiveKeyFactor> positiveKeyFactorList, List<NegativeKeyFactor> negativeKeyFactorList, FicoCreditScoreLandingUIInterface landingUIInterface) {
        mFicoCreditScore = ficoCreditScore;
        mFicoScoreListItem = validScoreListItem;
        mPositiveKeyFactorList = positiveKeyFactorList;
        mNegativeKeyFactorList = negativeKeyFactorList;
        mLandingUIInterface = landingUIInterface;

        setScoreNDateHeader();
        setFicoScoreBoxDetails();
        setGraphValues(mFicoCreditScore);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                /**For Tablet Landscape show key-factors here */
                int orientation = mContext.getResources().getConfiguration().orientation;
                if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
                    if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                        showKeyfactors();
                    }
                }
            }
        }, KEYFACTORS_RENDERING_DELAY_INMISEC);

        /*Start Changes for US121913*/
        getPostiveNegativeKeyFactorName();
        if (isExpandDisabled(mFicoScoreListItem)) {
            FicoUtils.trackFicoCreditScorPage(mContext, ratingValue, previousScoreChange, helpHurtArr, isNoScoreAvailableFor90Days);
            isAllAttributeUnavail = true;
        } else if (!isAllAttributeUnavail && isRevolvingUtlizationUnavail()) {
            FicoUtils.trackRevolvingUtilizationUnavailableTags(mContext);
        } else {
            FicoUtils.trackFicoCreditScorPage(mContext, ratingValue, previousScoreChange, helpHurtArr, isNoScoreAvailableFor90Days);
        }
        /*End Changes for US121913*/
    }

    private void setUpViewHolder() {

        ficoCardViewHolder = new FicoCardViewHolder();
        ficoCardViewHolder.scoreCardBoxLayout = (RelativeLayout) findViewById(R.id.scoreCardBoxLayout);
        ficoCardViewHolder.horzonScoreColorView = (View) findViewById(R.id.hor_score_color_view);
        ficoCardViewHolder.verticleScoreColorView = (View) findViewById(R.id.verticle_score_color_view);
        ficoCardViewHolder.up_down_img = (ImageView) findViewById(R.id.up_down_img);

        ficoCardViewHolder.ficoGraphListContainer = (LinearLayout) findViewById(R.id.ficoGraphListContainer);
        ficoCardViewHolder.graphListTabToggle = (CmnFicoToggleButtonCustomView) findViewById(R.id.graphListTabToggleView);
        ficoCardViewHolder.litsNavParentLayout = (LinearLayout) findViewById(R.id.cmnFicoList_NavRootContainer);
        ficoCardViewHolder.listLeftNavImgBtn = (ImageButton) findViewById(R.id.cmnFicoList_LeftNav);
        ficoCardViewHolder.listRightNavImgBtn = (ImageButton) findViewById(R.id.cmnFicoList_RightNav);
        ficoCardViewHolder.ficoGraph = (CmnFicoChart) findViewById(R.id.cmnFicoScoreGraph);
        ficoCardViewHolder.ficoList = (ListView) findViewById(R.id.cmnFicoScoreListViewId);

        ficoCardViewHolder.histroryKeyFactorTxtLayout = ((LinearLayout) findViewById(R.id.histroryKeyFactorTxtLayout));
        ficoCardViewHolder.creditScoreMonthLayout = (RelativeLayout) findViewById(R.id.creditScoreMonthLayout);
        ficoCardViewHolder.monthScoreValueTxt = ((TextView) findViewById(R.id.monthScoreValueTxt));
        ficoCardViewHolder.monthScoreDesTxt = ((TextView) findViewById(R.id.monthScoreDesTxt));
        ficoCardViewHolder.fico_card_parent_layout = (RelativeLayout) findViewById(R.id.fico_card_parent_layout);
        ficoCardViewHolder.histroryKeyFactorTxt = ((TextView) findViewById(R.id.histroryKeyFactorTxt));

         /*Start Changes for US117369*/
        ficoCardViewHolder.ficoScoreHelpIconImg = (ImageView) findViewById(R.id.ficoScoreHelpIconImg);
        ficoCardViewHolder.ficoScoreBoxTitleTxt = ((TextView) findViewById(R.id.ficoScoreBoxTitleTxt));
        ficoCardViewHolder.ficoCurrentScoreValueTxt = ((TextView) findViewById(R.id.ficoCurrentScoreValueTxt));
        ficoCardViewHolder.ficoPreviousScoreValueTxt = ((TextView) findViewById(R.id.ficoPreviousScoreValueTxt));
        ficoCardViewHolder.ficoScoreChangeValueTxt = ((TextView) findViewById(R.id.ficoScoreChangeValueTxt));
        ficoCardViewHolder.ficoScoreRangeTxt = ((TextView) findViewById(R.id.ficoScoreRangeTxt));
        ficoCardViewHolder.fico_score_arrow_img = ((ImageView) findViewById(R.id.fico_score_arrow_img));
        ficoCardViewHolder.ficoRangeHelpContainerLayout = ((LinearLayout) findViewById(R.id.ficoRangeHelpContainerLayout));
         /*End Changes for US117369*/

        /*Start changes for US118293*/
        ficoCardViewHolder.fico_prev_score_txt = ((TextView) findViewById(R.id.fico_prev_score_txt));
        ficoCardViewHolder.fico_score_change_txt = ((TextView) findViewById(R.id.fico_score_change_txt));
        ficoCardViewHolder.graph_line = ((TextView) findViewById(R.id.graph_line));
       ficoCardViewHolder.score_line = ((TextView) findViewById(R.id.score_line));
       /*End changes for US118293*/

        /**Start Key-factors changes*/
        ficoCardViewHolder.ficoKeyFactorsConRoot = (RelativeLayout) findViewById(R.id.cmnFicoKeyFactorsConRoot);
        ficoCardViewHolder.cmnFicoKeyFactorsBottomSep = findViewById(R.id.cmnFicoKeyFactorsBottomSep);
        ficoCardViewHolder.cmnFicoPosKeyFactorsSepBottom = findViewById(R.id.cmnFicoPosKeyFactorsSepBottom);
        ficoCardViewHolder.hideKeyFactorsLink = (TextView) findViewById(R.id.cmnFicoHideKeyFactorsLink);
        ficoCardViewHolder.positiveKeyFactorsRoot = (RelativeLayout) findViewById(R.id.cmnFicoPosKeyFactoryRoot);
        ficoCardViewHolder.negativeKeyFactorsRoot = (RelativeLayout) findViewById(R.id.cmnFicoNegFactoryRoot);

        ficoCardViewHolder.positiveKeyFactorsListView = (ExpandableListView) findViewById(R.id.cmnFicoPosKeyFactorsList);
        ficoCardViewHolder.nagavtiveKeyFactorsListView = (ExpandableListView) findViewById(R.id.cmnFicoNegKeyFactorsList);
        /** End Key-factors changes*/
        ficoCardViewHolder.paddingBottomView= (View) findViewById(R.id.paddingBottomView);
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            setUpTabletDefaultUI();
        }
    }

    /**
     * Method to set Current score & Date in header
     */
    private void setScoreNDateHeader() {
        isNoScoreAvailableFor90Days = mFicoCreditScore.isScoreTooOld();
        if (!isNoScoreAvailableFor90Days) {
            if (ficoCardViewHolder.monthScoreDesTxt != null) {
                if (CommonUtils.isRunningOnHandset(mContext)) {
                    ficoCardViewHolder.monthScoreDesTxt.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_month_score_des)));
                } else {
                    ficoCardViewHolder.monthScoreDesTxt.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_month_score_des_tablet)));
                }
            }
            if (ficoCardViewHolder.monthScoreValueTxt != null && null != mFicoCreditScore && mFicoCreditScore.getScoreDate() != null) {
                //Removed date format as per US124309
                String mDate = mFicoCreditScore.getScoreDate();
                if (mDate != null) {
                    ficoCardViewHolder.monthScoreValueTxt.setText(mContext.getString(R.string.fico_month_score_title) + " " + mDate);
                }
            }
        } else {
            if (ficoCardViewHolder.monthScoreDesTxt != null) {
                ficoCardViewHolder.monthScoreDesTxt.setVisibility(View.GONE);
            }
            if (ficoCardViewHolder.monthScoreValueTxt != null && null != mFicoCreditScore && mFicoCreditScore.getScoreDate() != null) {
                ficoCardViewHolder.monthScoreValueTxt.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_box_90_days_title) + " " + mFicoCreditScore.getScoreDate()));
            }
            ficoCardViewHolder.histroryKeyFactorTxtLayout.setVisibility(View.VISIBLE);
            if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
                int orientation = mContext.getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    ficoCardViewHolder.histroryKeyFactorTxt.setText(mContext.getResources().getString(R.string.cmn_fico_score_unavailable_txt));
                    ficoCardViewHolder.score_line.setVisibility(View.INVISIBLE);
                }
            }
        }
    }

    /**
     * Method to initialize Tablet UI
     */
    private void setUpTabletDefaultUI() {

        int orientation = mContext.getResources().getConfiguration().orientation;
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                // Disable expand click for Tablet Landscape
                ficoCardViewHolder.scoreCardBoxLayout.setClickable(false);
                ficoCardViewHolder.horzonScoreColorView.setVisibility(View.VISIBLE);
                ficoCardViewHolder.verticleScoreColorView.setVisibility(View.INVISIBLE);
                ficoCardViewHolder.up_down_img.setVisibility(View.INVISIBLE);
                ficoCardViewHolder.histroryKeyFactorTxtLayout.setVisibility(View.GONE);

                ficoCardViewHolder.ficoGraphListContainer.setVisibility(View.VISIBLE);
                ficoCardViewHolder.graphListTabToggle.setGraphSelected();
                ficoCardViewHolder.ficoGraph.setVisibility(View.VISIBLE);
                ficoCardViewHolder.ficoList.setVisibility(View.GONE);
                ficoCardViewHolder.litsNavParentLayout.setVisibility(View.GONE);
                ficoCardViewHolder.creditScoreMonthLayout.setVisibility(View.GONE);
                //Don't show Hide key-factors link here
                ficoCardViewHolder.cmnFicoKeyFactorsBottomSep.setVisibility(View.GONE);
                ficoCardViewHolder.hideKeyFactorsLink.setVisibility(View.GONE);
                ficoCardViewHolder.paddingBottomView.setVisibility(View.GONE);
            } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                FicoUtils.setPaddingForTabletPort(ficoCardViewHolder.fico_card_parent_layout, mContext, 24);
            }
        }
    }

    /* This Method handles click events*/
    private void handleClickEvents() {
        ficoCardViewHolder.scoreCardBoxLayout.setOnClickListener(scoreCardBoxLayoutListener);
        ficoCardViewHolder.graphListTabToggle.setGroupObserver(graphListTabListener);
        ficoCardViewHolder.ficoRangeHelpContainerLayout.setOnClickListener(ficoScoreHelpIconListner);
        ficoCardViewHolder.histroryKeyFactorTxtLayout.setOnClickListener(scoreUnavailableListner);
        ficoCardViewHolder.hideKeyFactorsLink.setOnClickListener(scoreCardBoxLayoutListener);
    }

    private OnClickListener graphListTabListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            final TableHeaderButton hitButton = (TableHeaderButton) view;
            if (ficoCardViewHolder.graphListTabToggle.getGraphButton().getText().equals(hitButton.getText())) {
                // load the FICO Graph View
                ficoCardViewHolder.graphListTabToggle.setGraphSelected();
                ficoCardViewHolder.ficoGraph.setVisibility(View.VISIBLE);
                //setGraphValues(mFicoCreditScore); Commented for US153380 for retaining Dot fill & graph state
                ficoCardViewHolder.ficoList.setVisibility(View.GONE);
                ficoCardViewHolder.litsNavParentLayout.setVisibility(View.GONE);
               /* Start Changes for 121913*/
                FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_GRAPH_TOGGLE_LINK);
               /* End Changes for 121913*/
            } else {
                // load the FICO Score List View
                selectedListIndex = 0;
                ficoCardViewHolder.graphListTabToggle.setListSelected();
                ficoCardViewHolder.ficoGraph.setVisibility(View.GONE);
                ficoCardViewHolder.ficoList.setVisibility(View.VISIBLE);
                showCreditScoreList(selectedListIndex);
                /* Start Changes for 121913*/
                FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_TOGGLE_TABLE_LINK);
               /* End Changes for 121913*/
            }
        }
    };

    private void showCreditScoreList(int listKeyIndex) {
        if (null != mFicoCreditScore && null == creditScoreListMap) {
            creditScoreListMap = FicoUtils.getFicoListMap(mFicoCreditScore, mContext);
        }
        Set<String> scoreListKeys = creditScoreListMap.keySet();
        listCountSize = scoreListKeys.size();
        String mapKey = (String) scoreListKeys.toArray()[listKeyIndex];
        ArrayList<CmnFicoListItemInterface> ficoList = creditScoreListMap.get(mapKey);
        CmnCreditscoreListAdapter listAdapter = new CmnCreditscoreListAdapter(mContext, ficoList, mLandingUIInterface);
        ficoCardViewHolder.ficoList.setAdapter(listAdapter);
        FicoUtils.setListViewSize(ficoCardViewHolder.ficoList);
        setUpListNavigator();
    }

    private void setUpListNavigator() {
        ficoCardViewHolder.litsNavParentLayout.setVisibility(View.VISIBLE);
        if (selectedListIndex <= 0) {
            ficoCardViewHolder.listLeftNavImgBtn.setOnClickListener(null);
            ficoCardViewHolder.listLeftNavImgBtn.setAlpha(0.3f);
            ficoCardViewHolder.listRightNavImgBtn.setOnClickListener(listRightNavListener);
            ficoCardViewHolder.listRightNavImgBtn.setAlpha(1.0f);
            ficoCardViewHolder.listLeftNavImgBtn.setContentDescription(mContext.getResources().getString(R.string.prev_button_desc));
            ficoCardViewHolder.listRightNavImgBtn.setContentDescription(mContext.getResources().getString(R.string.next_button_tap_desc));
        } else if (selectedListIndex == listCountSize - 1) {
            ficoCardViewHolder.listLeftNavImgBtn.setOnClickListener(listLeftNavListener);
            ficoCardViewHolder.listLeftNavImgBtn.setAlpha(1.0f);
            ficoCardViewHolder.listRightNavImgBtn.setOnClickListener(null);
            ficoCardViewHolder.listRightNavImgBtn.setAlpha(0.3f);
            ficoCardViewHolder.listLeftNavImgBtn.setContentDescription(mContext.getResources().getString(R.string.prev_button_tap_desc));
            ficoCardViewHolder.listRightNavImgBtn.setContentDescription(mContext.getResources().getString(R.string.next_button_desc));
        }
    }

    private OnClickListener listLeftNavListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            if (selectedListIndex > 0) {
                selectedListIndex--;
                showCreditScoreList(selectedListIndex);
            }
        }
    };

    private OnClickListener listRightNavListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            if (selectedListIndex < listCountSize) {
                selectedListIndex++;
                showCreditScoreList(selectedListIndex);
            }
        }
    };

    private OnClickListener scoreCardBoxLayoutListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
                int orientation = mContext.getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    ficoCardViewHolder.scoreCardBoxLayout.setClickable(false);
                } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    hideShowGraphListLayout(state);
                    mLandingUIInterface.onCreditScoreBoxClick(state);


                }
            } else {
                hideShowGraphListLayout(state);
                mLandingUIInterface.onCreditScoreBoxClick(state);
            }
        }
    };



    private OnClickListener scoreUnavailableListner = new OnClickListener() {
        @Override
        public void onClick(View view) {
            if (ficoCardViewHolder.histroryKeyFactorTxt.getText().toString().equalsIgnoreCase(mContext.getString(R.string.cmn_fico_score_unavailable_txt))) {
               /* Start Changes for 121913*/
                FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_90_DAYS_UNAVAILABLE_WHY);
                 /* End Changes for 121913*/
                mLandingUIInterface.showScoreUnavailableModal();
            } else {
                if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
                    int orientation = mContext.getResources().getConfiguration().orientation;
                    if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                        ficoCardViewHolder.scoreCardBoxLayout.setClickable(false);
                    } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                        hideShowGraphListLayout(state);
                        mLandingUIInterface.onCreditScoreBoxClick(state);
                    }
                } else {
                    hideShowGraphListLayout(state);
                    mLandingUIInterface.onCreditScoreBoxClick(state);
                }
            }

        }
    };

    private OnClickListener ficoScoreHelpIconListner = new OnClickListener() {
        @Override
        public void onClick(View view) {
            if (null != mLandingUIInterface) {
              /* Start Changes for 121913*/
                FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_HELP_SCORE_STRENGTH);
              /* End Changes for 121913*/
                mLandingUIInterface.handleCreditScoreHelpEvent(mFicoCreditScore.getCurrentScore());
            }
        }
    };

    /**
     * This method show card view
     */
    private void hideShowGraphListLayout(int creditBoxState) {
        state = creditBoxState;
        if (state == expandedState) {
            ficoCardViewHolder.scoreCardBoxLayout.setOnClickListener(null);
            ficoCardViewHolder.verticleScoreColorView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    if (Build.VERSION.SDK_INT < 16) {
                        ficoCardViewHolder.verticleScoreColorView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                    } else {
                        ficoCardViewHolder.verticleScoreColorView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }

                    final int initialHeight = ficoCardViewHolder.verticleScoreColorView.getHeight(); //height is ready
                    collapse(ficoCardViewHolder.verticleScoreColorView, initialHeight);
                }
            });
            ficoCardViewHolder.ficoGraphListContainer.setVisibility(View.VISIBLE);
            ficoCardViewHolder.up_down_img.setBackgroundResource(R.drawable.up_arrow_fico);
            /*Start changes for US118293*/
            if(isNoScoreAvailableFor90Days){
                ficoCardViewHolder.histroryKeyFactorTxtLayout.setVisibility(View.VISIBLE);
                ficoCardViewHolder.histroryKeyFactorTxt.setText(mContext.getResources().getString(R.string.cmn_fico_score_unavailable_txt));
                ficoCardViewHolder.score_line.setVisibility(View.INVISIBLE);
            }else{
                ficoCardViewHolder.histroryKeyFactorTxtLayout.setVisibility(View.GONE);
            }
            /*End changes for US118293*/
            ficoCardViewHolder.graphListTabToggle.setGraphSelected();
            ficoCardViewHolder.ficoGraph.setVisibility(View.VISIBLE);
            setGraphValues(mFicoCreditScore);
            ficoCardViewHolder.ficoList.setVisibility(View.GONE);
            ficoCardViewHolder.litsNavParentLayout.setVisibility(View.GONE);
            state = collapsedState;
            /**Show key-factors here */
            showKeyfactors();
             /* Start Changes for 121913*/
            FicoUtils.trackCreditScorecardOnBoxClick(ratingValue, mContext);
             /* End Changes for 121913*/
        } else {
            ficoCardViewHolder.horzonScoreColorView.setVisibility(View.INVISIBLE);
            ficoCardViewHolder.verticleScoreColorView.setVisibility(View.VISIBLE);
            ficoCardViewHolder.ficoGraphListContainer.setVisibility(View.GONE);
            ficoCardViewHolder.up_down_img.setBackgroundResource(R.drawable.down_arrow_fico);
            ficoCardViewHolder.histroryKeyFactorTxtLayout.setVisibility(View.VISIBLE);
            ficoCardViewHolder.histroryKeyFactorTxt.setText(mContext.getResources().getString(R.string.fico_key_factor_show_score_title));
            ficoCardViewHolder.histroryKeyFactorTxt.setContentDescription(mContext.getResources().getString(R.string.fico_key_factor_show_score_title_desc));
            ficoCardViewHolder.histroryKeyFactorTxtLayout.setContentDescription(mContext.getResources().getString(R.string.fico_key_factor_show_score_title_desc));
            ficoCardViewHolder.score_line.setVisibility(View.VISIBLE);
            state = expandedState;
        }
    }

    /**
     * This method for animation left to right
     */
    private Animation inFromLeftAnimation() {
        Animation inFromLeft = new TranslateAnimation(
                Animation.RELATIVE_TO_PARENT, -1.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f);
        inFromLeft.setDuration(20);
        inFromLeft.setInterpolator(new AccelerateInterpolator());
        inFromLeft.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ficoCardViewHolder.horzonScoreColorView.clearAnimation();
                ficoCardViewHolder.horzonScoreColorView.setVisibility(View.VISIBLE);
                ficoCardViewHolder.scoreCardBoxLayout.setOnClickListener(scoreCardBoxLayoutListener);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        return inFromLeft;
    }
    /*Start Changes for US117369*/

    /**
     * This method setting the values for Fico Score box
     */
    private void setFicoScoreBoxDetails() {

        if (!isNoScoreAvailableFor90Days) {
            int ficoScoreRangeColor = FicoUtils.getColorCodeFromScoreValue(mFicoCreditScore.getCurrentScore());
            if (ficoScoreRangeColor != 0) {
                ficoCardViewHolder.horzonScoreColorView.setBackgroundColor(mContext.getResources().getColor(ficoScoreRangeColor));
                ficoCardViewHolder.verticleScoreColorView.setBackgroundColor(mContext.getResources().getColor(ficoScoreRangeColor));
            }
            ficoCardViewHolder.ficoScoreRangeTxt.setText(FicoUtils.getFicoScoreRangeValue(mFicoCreditScore.getCurrentScore()));
            ratingValue = FicoUtils.getFicoScoreRangeValue(mFicoCreditScore.getCurrentScore());
            if (CommonUtils.isRunningOnHandset(mContext)) {
                ficoCardViewHolder.ficoScoreBoxTitleTxt.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_box_title)));
            } else {
                ficoCardViewHolder.ficoScoreBoxTitleTxt.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_box_title_tablet)));
            }
            if (String.valueOf(mFicoCreditScore.getCurrentScore()) != null) {
                ficoCardViewHolder.ficoCurrentScoreValueTxt.setText(String.valueOf(mFicoCreditScore.getCurrentScore()));
            }
            String ficoCurrentMonth = "";
            if (mFicoCreditScore.getScoreDate() != null) {
                ficoCurrentMonth = FicoUtils.getFicoMonthValue(mFicoCreditScore.getScoreDate());
            }

            String previousFicoMonth = FicoUtils.getPreviousMonthFromCurrentMonth(ficoCurrentMonth);
            if (mFicoCreditScore.getFicoScoreList().size() != 0 && previousFicoMonth != null) {
                for (int i = 0; i <= mFicoCreditScore.getFicoScoreList().size(); i++) {
                    if (previousFicoMonth.equals(FicoUtils.getFicoMonthValue(mFicoCreditScore.getFicoScoreList().get(i).getScoreDate()))) {
                        if (mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore() != 0) {
                            ficoCardViewHolder.ficoPreviousScoreValueTxt.setText(String.valueOf(mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore()));
                            ficoCardViewHolder.ficoScoreChangeValueTxt.setText(FicoUtils.getFicoScoreDiff(mFicoCreditScore.getCurrentScore(), mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore()));
                            setUpDownArrow(mFicoCreditScore.getCurrentScore(), mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore());
                            /** Start Show date instead of "Previous" text US124309 */
                            String previousScoreDate = mFicoCreditScore.getFicoScoreList().get(i).getScoreDate();
                            if (!PortalUtils.isStrFieldEmpty(previousScoreDate)) {
                                ficoCardViewHolder.fico_prev_score_txt.setText(previousScoreDate);
                            }
                            /** end Show date instead of "Previous" text US124309 */
                        }else{
                            ficoCardViewHolder.ficoPreviousScoreValueTxt.setText("--");
                            ficoCardViewHolder.ficoScoreChangeValueTxt.setText("--");
                            ficoCardViewHolder.fico_score_arrow_img.setVisibility(View.INVISIBLE);
//                            ficoCardViewHolder.fico_prev_score_txt.setVisibility(View.INVISIBLE);
//                            ficoCardViewHolder.fico_score_change_txt.setVisibility(View.INVISIBLE);
                        }

//                        ficoCardViewHolder.ficoScoreChangeValueTxt.setText(FicoUtils.getFicoScoreDiff(mFicoCreditScore.getCurrentScore(), mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore()));
//                        setUpDownArrow(mFicoCreditScore.getCurrentScore(), mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore());
                        break;
                    }
                }
            }

        } else {

            /*Start changes for US118293*/
            int lastAvailableScoreValue = 0;
            String lastAvailableScoreDate = "";
            if (null != mFicoScoreListItem) {
                lastAvailableScoreValue = mFicoScoreListItem.getCurrentScore();
                lastAvailableScoreDate = mFicoScoreListItem.getScoreDate();
            }
            showFicoBoxUnavailableScore90DaysScenario(lastAvailableScoreValue, lastAvailableScoreDate);
        }
       /*End changes for US118293*/

    }


    /**
     * This method showing 90 days scenario for Fico Score
     * @param lastAvailableScoreValue
     * @param lastAvailableScoreDate
     */

    private void showFicoBoxUnavailableScore90DaysScenario(int lastAvailableScoreValue, String lastAvailableScoreDate) {
        int ficoScoreRangeColor = FicoUtils.getColorCodeFromScoreValue(lastAvailableScoreValue);
        if (ficoScoreRangeColor != 0) {
            ficoCardViewHolder.horzonScoreColorView.setBackgroundColor(mContext.getResources().getColor(ficoScoreRangeColor));
            ficoCardViewHolder.verticleScoreColorView.setBackgroundColor(mContext.getResources().getColor(ficoScoreRangeColor));
        }

        String mRangeStr = FicoUtils.getFicoScoreRangeValue(lastAvailableScoreValue);
        if (mRangeStr != null) {
            ficoCardViewHolder.ficoScoreRangeTxt.setText(mRangeStr);
            ratingValue = mRangeStr;
        }

        ficoCardViewHolder.ficoScoreBoxTitleTxt.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_box_title)));
        ficoCardViewHolder.ficoCurrentScoreValueTxt.setText(String.valueOf(lastAvailableScoreValue));
        String ficoCurrentMonth = "";
        if (lastAvailableScoreDate != null) {
            ficoCurrentMonth = FicoUtils.getFicoMonthValue(lastAvailableScoreDate);
        }

        String previousFicoMonth = FicoUtils.getPreviousMonthFromCurrentMonth(ficoCurrentMonth);
          if (mFicoCreditScore.getFicoScoreList().size() != 0 && previousFicoMonth != null) {
            for (int i = 0; i <= mFicoCreditScore.getFicoScoreList().size(); i++) {
                if (previousFicoMonth.equals(FicoUtils.getFicoMonthValue(mFicoCreditScore.getFicoScoreList().get(i).getScoreDate()))) {
                    if (mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore() != 0) {
                        ficoCardViewHolder.ficoPreviousScoreValueTxt.setText(String.valueOf(mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore()));
                        /** Start Show date instead of "Previous" text US124309 */
                        String previousScoreDate = mFicoCreditScore.getFicoScoreList().get(i).getScoreDate();
                        if (!PortalUtils.isStrFieldEmpty(previousScoreDate)) {
                            ficoCardViewHolder.fico_prev_score_txt.setText(previousScoreDate);
                        }
                        /** end Show date instead of "Previous" text US124309 */
                        ficoCardViewHolder.ficoScoreChangeValueTxt.setText(FicoUtils.getFicoScoreDiff(lastAvailableScoreValue, mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore()));
                        setUpDownArrow(lastAvailableScoreValue, mFicoCreditScore.getFicoScoreList().get(i).getCurrentScore());
                        break;
                    } else {
                        ficoCardViewHolder.ficoPreviousScoreValueTxt.setText("--");
                        ficoCardViewHolder.ficoScoreChangeValueTxt.setText("--");
                        ficoCardViewHolder.fico_score_arrow_img.setVisibility(View.INVISIBLE);
//                        ficoCardViewHolder.fico_prev_score_txt.setVisibility(View.INVISIBLE);
//                        ficoCardViewHolder.fico_score_change_txt.setVisibility(View.INVISIBLE);
                        break;
                    }
                }
            }
        }
    }

    /**
     * This method set the up and down arrow as per Fico Score value
     * @param currentMonthScore
     * @param previousMonthScore
     */
    private void setUpDownArrow(int currentMonthScore, int previousMonthScore) {
        if (currentMonthScore > previousMonthScore) {
            ficoCardViewHolder.fico_score_arrow_img.setBackgroundResource(R.drawable.score_up_arrow);
            previousScoreChange = AnalyticsPage.FICO_CREDITSCORE_INCREASED;
        } else if (currentMonthScore < previousMonthScore) {
            ficoCardViewHolder.fico_score_arrow_img.setBackgroundResource(R.drawable.score_down_arrow);
            previousScoreChange = AnalyticsPage.FICO_CREDITSCORE_DECREASED;
        } else {
            ficoCardViewHolder.fico_score_arrow_img.setVisibility(View.INVISIBLE);
            previousScoreChange = AnalyticsPage.FICO_CREDITSCORE_NO_CHANGE;
        }
    }

    /*End Changes for US117369*/
    /**
     * This methos is showing bottom to top animation
     */
    private void collapse(final View v, final int height) {
        final int initialHeight = height;
        Animation a = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {
                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };
        a.setDuration((int) (initialHeight / v.getContext().getResources().getDisplayMetrics().density));
        v.startAnimation(a);
        a.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ficoCardViewHolder.verticleScoreColorView.setVisibility(View.INVISIBLE);
                ficoCardViewHolder.verticleScoreColorView.clearAnimation();
                ficoCardViewHolder.verticleScoreColorView.getLayoutParams().height = LayoutParams.MATCH_PARENT;
                ficoCardViewHolder.horzonScoreColorView.startAnimation(inFromLeftAnimation());
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
    }

    @Override
    public void expandCollapseDashboard() {
        if(state == collapsedState)
            hideShowGraphListLayout(state);
    }


    public static class FicoCardViewHolder {
        public LinearLayout histroryKeyFactorTxtLayout, ficoGraphListContainer, ficoRangeHelpContainerLayout, litsNavParentLayout;
        public RelativeLayout ficoScoreViewLayout,
                scoreCardBoxLayout, creditScoreMonthLayout, fico_card_parent_layout;
        public ImageView up_down_img;
        public TextView monthScoreValueTxt, monthScoreDesTxt;
        public CmnFicoToggleButtonCustomView graphListTabToggle;
        public View horzonScoreColorView, verticleScoreColorView;
        public CmnFicoChart ficoGraph;
        public ListView ficoList;
        public ImageButton listLeftNavImgBtn, listRightNavImgBtn;
        /*Start Changes for US117369*/
        public ImageView ficoScoreHelpIconImg;
        public TextView ficoScoreBoxTitleTxt, ficoCurrentScoreValueTxt, ficoPreviousScoreValueTxt, ficoScoreChangeValueTxt, ficoScoreRangeTxt,histroryKeyFactorTxt;
        public ImageView fico_score_arrow_img;
        /*End Changes for US117369*/

        /*Start changes for US118293*/
        public TextView fico_prev_score_txt, fico_score_change_txt, graph_line, score_line, no_score_line;
       /*End changes for US118293*/

        /** Start Key-factors changes */
        View cmnFicoKeyFactorsBottomSep, cmnFicoPosKeyFactorsSepBottom;
        TextView hideKeyFactorsLink;
        RelativeLayout ficoKeyFactorsConRoot;
        RelativeLayout positiveKeyFactorsRoot;
        RelativeLayout negativeKeyFactorsRoot;
        ExpandableListView positiveKeyFactorsListView;
        ExpandableListView nagavtiveKeyFactorsListView;
        /**end Key-factors changes */
        public View paddingBottomView;
    }

    /**
     * Set Graph for UI specs & data
     * Convert response json values into 3 two dimensional array for graph component
     */
    private void setGraphValues(FicoCreditScore ficoCreditScore) {
        inItFicoGraphUI();
        String[][] array = FicoUtils.getGraphData(ficoCreditScore);
        if (null != array) {
            ficoCardViewHolder.ficoGraph.setData(array);
        }

    }

    /**
     * It initalizes UI of FICO Graph
     */
    private void inItFicoGraphUI() {

        int topMargin, bottomMargin, rightMargin, leftMargin;
        LinearLayout.LayoutParams graphLayParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                (mContext.getResources()
                        .getDrawable(R.drawable.fico_graph_gradient)
                        .getMinimumHeight() + mContext.getResources()
                        .getDimensionPixelSize(R.dimen.cmn_graph_extraspace_size)));

        topMargin = mContext.getResources().getDimensionPixelSize(R.dimen.cmn_graph_container_margin_top);
        bottomMargin = mContext.getResources().getDimensionPixelSize(R.dimen.cmn_graph_container_margin_bottom);
        rightMargin = mContext.getResources().getDimensionPixelSize(R.dimen.cmn_graph_container_margin_right);
        leftMargin = mContext.getResources().getDimensionPixelSize(R.dimen.cmn_graph_container_margin_left);
        graphLayParams.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);

        ficoCardViewHolder.ficoGraph.setLayoutParams(graphLayParams);
        ficoCardViewHolder.ficoGraph.setFontColor(mContext.getResources().getColor(
                R.color.cmn_fico_linear_layout_border));
        ficoCardViewHolder.ficoGraph.setLineColor(mContext.getResources().getColor(
                R.color.cmn_fico_graph_grey_line_color));
        ficoCardViewHolder.ficoGraph.setiTopBottomLineColor(mContext.getResources().getColor(
                R.color.cmn_fico_graph_dark_gray));
        ficoCardViewHolder.ficoGraph.setyAxisTextColor(mContext.getResources().getColor(
                R.color.cmn_fico_y_axis_text_color));

        ficoCardViewHolder.ficoGraph.setCliclePlotColor(mContext.getResources().getColor(
                R.color.cmn_fico_circle_plot_color));
        ficoCardViewHolder.ficoGraph.setGraphFillColor(mContext.getResources().getColor(R.color.cmn_fico_graph_fill_color));
        ficoCardViewHolder.ficoGraph.setCirclePlotStroke(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_fico_circle_plot_stroke));

        ficoCardViewHolder.ficoGraph.setPillarGap(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_pillar_width));
        ficoCardViewHolder.ficoGraph.setiStrokeValue(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_line_stroke));
        ficoCardViewHolder.ficoGraph.setfMarginRight(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_margin_right)); //for shifting graph right most point
        ficoCardViewHolder.ficoGraph.setfMarginLeft(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_margin_left));
        ficoCardViewHolder.ficoGraph.setFontSize(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_axis_font_size));
        ficoCardViewHolder.ficoGraph.setXaxisLabelTopMargin(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_xaxis_label_top_margin));
        ficoCardViewHolder.ficoGraph.setPlotValueBottomMargin(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_plot_value_bottom_margin));
        ficoCardViewHolder.ficoGraph.setRADIUS(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_point_radius));

        ficoCardViewHolder.ficoGraph.setEmptyCircleOffset(mContext.getResources().getDimensionPixelSize(
                R.dimen.cmn_graph_empty_circle_offset));

        ficoCardViewHolder.ficoGraph.setMarginTopBottom(mContext.getResources().getDimensionPixelSize(R.dimen.cmn_graph_topbottom_margin));
        ficoCardViewHolder.ficoGraph.setSidebarRightMargin(mContext.getResources().getDimensionPixelSize(R.dimen.cmn_graph_sidebar_right_margin));
        ficoCardViewHolder.ficoGraph.setSidebarTopMargin(mContext.getResources().getDimensionPixelSize(R.dimen.cmn_graph_sidebar_top_margin));
        ficoCardViewHolder.ficoGraph.setClickListner(this);
    }

    /**
     * Method to show Positive, Negative Key-factors
     */
    private void showKeyfactors() {
        if ((null == mPositiveKeyFactorList && null == mNegativeKeyFactorList) || (
                null != mPositiveKeyFactorList && mPositiveKeyFactorList.isEmpty() && null != mNegativeKeyFactorList && mNegativeKeyFactorList.isEmpty())) {
            //hide key-factors container
            ficoCardViewHolder.ficoKeyFactorsConRoot.setVisibility(View.GONE);
        } else {
            showPositiveKeyFactors(mPositiveKeyFactorList);
            showNegativeKeyFactors(mNegativeKeyFactorList);
        }
    }

    /**
     * Show positive key factors list data
     */
    private void showPositiveKeyFactors(List<PositiveKeyFactor> positiveKeyFactorList) {

        if (null != positiveKeyFactorList && !positiveKeyFactorList.isEmpty()) {

            List<String> posListDataGroup = new ArrayList<>();
            HashMap<String, List<String>> posListDataChild = new HashMap<>();

            for (PositiveKeyFactor posKeyFacItem : positiveKeyFactorList) {
                posListDataGroup.add(posKeyFacItem.getShortDesc());
                List<String> childList = new ArrayList<>();
                childList.add(posKeyFacItem.getLongDesc());
                posListDataChild.put(posKeyFacItem.getShortDesc(), childList); // Header, Child data
            }
            ficoCardViewHolder.positiveKeyFactorsListView.setVisibility(View.VISIBLE);
            CmnFicoKeyFactorsListAdapter listAdapter = new CmnFicoKeyFactorsListAdapter(mContext, posListDataGroup, posListDataChild);
            ficoCardViewHolder.positiveKeyFactorsListView.setAdapter(listAdapter);

            /**start Defect fixes 14532, 15256 */
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    posExpListGroupHeight = FicoUtils.getExpandableListGroupViewsHeight(ficoCardViewHolder.positiveKeyFactorsListView);
                    FicoUtils.setExpandableListViewHeight(ficoCardViewHolder.positiveKeyFactorsListView, posExpListGroupHeight);
                    ficoCardViewHolder.positiveKeyFactorsListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

                        @Override
                        public void onGroupExpand(int groupPosition) {
                            // Also collapse Negative Key-factors list expanded item if any
                            if (null != ficoCardViewHolder.nagavtiveKeyFactorsListView && null != ficoCardViewHolder.nagavtiveKeyFactorsListView.getAdapter() && ficoCardViewHolder.nagavtiveKeyFactorsListView.isGroupExpanded(negExpListGroupSelected)) {
                                ficoCardViewHolder.nagavtiveKeyFactorsListView.collapseGroup(negExpListGroupSelected);
                            }
                            if (groupPosition != posExpListGroupSelected) {
                                ficoCardViewHolder.positiveKeyFactorsListView.collapseGroup(posExpListGroupSelected);
                            }
                            posExpListGroupSelected = groupPosition;
                            int expandedChildsHeight = FicoUtils.getExpandableListChildViewsHeight(ficoCardViewHolder.positiveKeyFactorsListView, groupPosition);
                            expandedChildsHeight += posExpListGroupHeight;
                            FicoUtils.setExpandableListViewHeight(ficoCardViewHolder.positiveKeyFactorsListView, expandedChildsHeight);
                            /*Start Changes for US121913*/
                            HashMap<String, Object> extras = new HashMap<String, Object>();
                            extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FICO_CREDITSCORE_EXPAND_KEY_FACTORS);
                            extras.put(mContext.getResources().getString(R.string.mylist1), helpHurtArr.toString().replace("[", "").replace("]", ""));
                            TrackingHelper.trackClickEvents(AnalyticsPage.FICO_CREDITSCORE_EXPAND_KEY_FACTORS, null, AnalyticsPage.LINK_TYPE_O, extras);
                             /*End Changes for US121913*/
                        }
                    });

                    ficoCardViewHolder.positiveKeyFactorsListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
                        @Override
                        public void onGroupCollapse(int groupPosition) {
                            // If same group is collapsed then reset size of list
                            if (posExpListGroupSelected == groupPosition) {
                                FicoUtils.setExpandableListViewHeight(ficoCardViewHolder.positiveKeyFactorsListView, posExpListGroupHeight);
                            }
                        }
                    });

                    //Added for Defect# 16661 List Scroll Issue on Tablet Landscape mode
                    if (null != mLandingUIInterface) {
                        mLandingUIInterface.setListFocus();
                    }
                }
            }, LIST_RENDERING_DELAY_INMISEC);
            /**end Defect fixes 14532, 15256 */

        } else {
            ficoCardViewHolder.positiveKeyFactorsRoot.setVisibility(View.GONE);
        }
    }

    /**
     * Show positive key factors list data
     */
    private void showNegativeKeyFactors(List<NegativeKeyFactor> negativeKeyFactorList) {

        if (null != negativeKeyFactorList && !negativeKeyFactorList.isEmpty()) {

            List<String> negListDataGroup = new ArrayList<>();
            HashMap<String, List<String>> negListDataChild = new HashMap<>();

            for (NegativeKeyFactor negKeyFacItem : negativeKeyFactorList) {
                negListDataGroup.add(negKeyFacItem.getShortDesc());
                List<String> childList = new ArrayList<>();
                childList.add(negKeyFacItem.getLongDesc());
                negListDataChild.put(negKeyFacItem.getShortDesc(), childList); // Header, Child data
            }
            ficoCardViewHolder.nagavtiveKeyFactorsListView.setVisibility(View.VISIBLE);
            CmnFicoKeyFactorsListAdapter listAdapter = new CmnFicoKeyFactorsListAdapter(mContext, negListDataGroup, negListDataChild);
            ficoCardViewHolder.nagavtiveKeyFactorsListView.setAdapter(listAdapter);

            /**start Defect fixes 14532, 15256 */
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    negExpListGroupHeight = FicoUtils.getExpandableListGroupViewsHeight(ficoCardViewHolder.nagavtiveKeyFactorsListView);
                    FicoUtils.setExpandableListViewHeight(ficoCardViewHolder.nagavtiveKeyFactorsListView, negExpListGroupHeight);
                    ficoCardViewHolder.nagavtiveKeyFactorsListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

                        @Override
                        public void onGroupExpand(int groupPosition) {
                            // Also collapse Positive Key-factors list expanded item if any
                            if (null != ficoCardViewHolder.positiveKeyFactorsListView && null != ficoCardViewHolder.positiveKeyFactorsListView.getAdapter() && ficoCardViewHolder.positiveKeyFactorsListView.isGroupExpanded(posExpListGroupSelected)) {
                                ficoCardViewHolder.positiveKeyFactorsListView.collapseGroup(posExpListGroupSelected);
                            }
                            if (groupPosition != negExpListGroupSelected) {
                                ficoCardViewHolder.nagavtiveKeyFactorsListView.collapseGroup(negExpListGroupSelected);
                            }
                            negExpListGroupSelected = groupPosition;
                            int expandedChildsHeight = FicoUtils.getExpandableListChildViewsHeight(ficoCardViewHolder.nagavtiveKeyFactorsListView, groupPosition);
                            expandedChildsHeight += negExpListGroupHeight;
                            FicoUtils.setExpandableListViewHeight(ficoCardViewHolder.nagavtiveKeyFactorsListView, expandedChildsHeight);
                           /*Start changes for US121913*/
                            HashMap<String, Object> extras = new HashMap<String, Object>();
                            extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FICO_CREDITSCORE_EXPAND_KEY_FACTORS);
                            extras.put(mContext.getResources().getString(R.string.mylist1), helpHurtArr.toString().replace("[", "").replace("]", ""));
                            TrackingHelper.trackClickEvents(AnalyticsPage.FICO_CREDITSCORE_EXPAND_KEY_FACTORS, null, AnalyticsPage.LINK_TYPE_O, extras);
                           /*End changes for US121913*/
                        }
                    });
                    ficoCardViewHolder.nagavtiveKeyFactorsListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
                        @Override
                        public void onGroupCollapse(int groupPosition) {
                            // If same group is collapsed then reset size of list
                            if (negExpListGroupSelected == groupPosition) {
                                FicoUtils.setExpandableListViewHeight(ficoCardViewHolder.nagavtiveKeyFactorsListView, negExpListGroupHeight);
                            }
                        }
                    });

                    //Added for Defect# 16661 List Scroll Issue on Tablet Landscape mode
                    if (null != mLandingUIInterface) {
                        mLandingUIInterface.setListFocus();
                    }

                }
            }, LIST_RENDERING_DELAY_INMISEC);
            /**end Defect fixes 14532, 15256 */

        } else {
            ficoCardViewHolder.cmnFicoPosKeyFactorsSepBottom.setVisibility(View.INVISIBLE);
            ficoCardViewHolder.negativeKeyFactorsRoot.setVisibility(View.GONE);
        }
    }

       /*Start Changes for US121913*/

    private void getPostiveNegativeKeyFactorName() {
        if (null != mPositiveKeyFactorList && !mPositiveKeyFactorList.isEmpty()) {
            for (PositiveKeyFactor posKeyFacItem : mPositiveKeyFactorList) {
                //Adding positive key factor title
                helpHurtArr.add(AnalyticsPage.FICO_CREDITSCORE_HELPING + posKeyFacItem.getShortDesc());
            }
        }
        if (null != mNegativeKeyFactorList && !mNegativeKeyFactorList.isEmpty()) {
            for (NegativeKeyFactor negKeyFacItem : mNegativeKeyFactorList) {
                //Adding positive key factor title
                helpHurtArr.add(AnalyticsPage.FICO_CREDITSCORE_HURTING + negKeyFacItem.getShortDesc());
            }
        }
    }

    public boolean isRevolvingUtlizationUnavail() {
        if (mFicoScoreListItem.getOpenRvlUtilizationPct() == null || Double.parseDouble(mFicoScoreListItem.getOpenRvlUtilizationPct()) < 0) {
            isRevUtiExpandDisabled = true;
        }
        return isRevUtiExpandDisabled;
    }

    public boolean isExpandDisabled(FicoScoreList ficoScoreListItem) {
        boolean isExpandDisabled = false;
        boolean areAllValuesNegative = false;

        if ((ficoScoreListItem.getTradeCount() != null && ficoScoreListItem.getInquiryCount() != null && ficoScoreListItem.getTotalMissedPymt() != null && ficoScoreListItem.getOpenRvlUtilizationPct() != null && ficoScoreListItem.getOldestTradeMonthCount() != null)) {
            if (Double.parseDouble(ficoScoreListItem.getTradeCount()) < 0 && Double.parseDouble(ficoScoreListItem.getInquiryCount()) < 0 && Double.parseDouble(ficoScoreListItem.getTotalMissedPymt()) < 0 && Double.parseDouble(ficoScoreListItem.getOpenRvlUtilizationPct()) < 0 && Double.parseDouble(ficoScoreListItem.getOldestTradeMonthCount()) < 0) {
                areAllValuesNegative = true;
            }
        }
        if ((ficoScoreListItem.getTradeCount() == null && ficoScoreListItem.getInquiryCount() == null && ficoScoreListItem.getTotalMissedPymt() == null && ficoScoreListItem.getOpenRvlUtilizationPct() == null && ficoScoreListItem.getOldestTradeMonthCount() == null) || areAllValuesNegative) {
            isExpandDisabled = true;
        }
        return isExpandDisabled;
    }
    /*End Changes for US121913*/

    @Override
    public void onItemClicked(int iIndex) {
        if (null != mLandingUIInterface) {
            if (null != mFicoCreditScore && null != mFicoCreditScore.getFicoScoreList()) {
                FicoScoreList ficoScoreList = mFicoCreditScore.getFicoScoreList().get(iIndex);
                mLandingUIInterface.showKeyFactorDetailModal(ficoScoreList);
            }
        }
    }
}
