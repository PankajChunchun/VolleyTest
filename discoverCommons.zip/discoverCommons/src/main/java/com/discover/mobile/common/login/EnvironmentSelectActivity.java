package com.discover.mobile.common.login;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.discover.mobile.common.R;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.common.widget.BankUrlChangerPreferences;
import com.discover.mobile.common.widget.BankUrlSite;
import com.discover.mobile.common.widget.SelectEnvironmentAdaptor;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mgupta4 on 5/12/2016.
 *
 * UPDATED by pdesai4 on 2/2/2017.
 *      -Using BankUrlChangerPreferences to get the default sites and saved preferences.
 *      -Ability to add new environments
 */
public class EnvironmentSelectActivity extends DiscoverBaseActivity implements DialogInterface.OnDismissListener {

    private ListView urlListview;
    private SelectEnvironmentAdaptor adapter;
    private ArrayList<BankUrlSite> allSites;
    private EditText cardIpAddress, bankIpAddress,appVersion;
    private CheckBox dummyOOBSupportChkBox;
    private BankUrlChangerPreferences bankUrlChangerPreferences;
    String intentSendExtra ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DiscoverActivityManager.setActiveActivity(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.environment_select);
        if(getIntent()!=null) {
            intentSendExtra  = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        }
        initListview();
        footerView();
    }

    private void initListview() {
        dummyOOBSupportChkBox = (CheckBox) findViewById(R.id.dummyOOBSupportcheckBox);
        appVersion = (EditText) findViewById(R.id.appVersionEntry);
        urlListview = (ListView) findViewById(R.id.url_list);
        allSites = new ArrayList<BankUrlSite>();
        bankUrlChangerPreferences = new BankUrlChangerPreferences();
        allSites.addAll(bankUrlChangerPreferences.getSites(this));
        adapter = new SelectEnvironmentAdaptor(this, R.layout.environment_select, allSites);
        urlListview.setDivider(getResources().getDrawable(R.drawable.gray_gradient_square));
        urlListview.setAdapter(adapter);
        urlListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //US146280- Andriod env selection
                BankUrlSite bankUrlSite=allSites.get(position);
                if (bankUrlSite.title.equalsIgnoreCase("prod-was8; prod-was8")) {
                    showDialogForProductionURLs(bankUrlSite);
                } else {
                    new BankUrlChangerPreferences().saveBankIPAddress(EnvironmentSelectActivity.this, bankIpAddress.getText().toString());
                    new BankUrlChangerPreferences().savedCardIPAddress(EnvironmentSelectActivity.this, cardIpAddress.getText().toString());
                    Log.d(EnvironmentSelectActivity.class.getSimpleName(), "Select Environment row tag  " + view.getTag());
                    FacadeFactory.getBankFacade().setBankBaseUrl(allSites.get(position).bankLink, bankIpAddress.getText().toString());
                    FacadeFactory.getCardFacade().setCardBaseUrl(allSites.get(position).cardLink, cardIpAddress.getText().toString());
                    //US82010: Dummy OOB Support in PA environment
                    if (dummyOOBSupportChkBox.isChecked()) {
                        Globals.setforDummyOOB(true);

                    } else {
                        Globals.setforDummyOOB(false);

                    }
                    if (appVersion.getText().toString() != null)
                        Globals.setAppVersion(appVersion.getText().toString());
                    Intent loginIntent = new Intent(EnvironmentSelectActivity.this, LoginActivity.class);
                    loginIntent.putExtra("fromWidget", true);
                    loginIntent.putExtra(Intent.EXTRA_TEXT, intentSendExtra);
                    startActivity(loginIntent);
                }
            }
        });



    }

    public void footerView()
    {
        View footerView = ((LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.environment_select_footer, null, false);
        cardIpAddress = (EditText) footerView.findViewById(R.id.card_ip_input);
        bankIpAddress = (EditText) footerView.findViewById(R.id.bank_ip_input);
        cardIpAddress.setText(new BankUrlChangerPreferences().getSavedCardIPAddress(this));
        bankIpAddress.setText(new BankUrlChangerPreferences().getSavedBankIPAddress(this));

        urlListview.addFooterView(footerView);
    }

    /**
     * US146280- Andriod env selection
     * Show dialog for production enviornment.
     * @param bankUrlSite
     */
    private void showDialogForProductionURLs(BankUrlSite bankUrlSite){
        FragmentManager fragmentManager = getFragmentManager();
        AddProductionEnvDialog addProductionEnvDialog = new AddProductionEnvDialog();
        addProductionEnvDialog.show(fragmentManager,AddProductionEnvDialog.class.getSimpleName());
    }

    //listens for the dismiss from the add environment button
    @Override
    public void onDismiss(final DialogInterface dialog) {
        initListview();
    }

    //opens Dialog fragment for adding new environment
    public void addEnvironment(View v){
        FragmentManager fragmentManager = getFragmentManager();
        EnvironmentAddDialog newFragment = new EnvironmentAddDialog();
        newFragment.show(fragmentManager,"New Environment");

    }
}
