package com.discover.mobile.common.onboardwiz.fragment;

/**
 * Created by 482127 on 4/27/2016.
 */
public interface OnBoardNavigationListener {

    public void moveToNextPage();

    public void moveToPreviousPage();

}
