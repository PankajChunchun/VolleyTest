package com.discover.mobile.common.fico.interfaces;

import android.view.View;

/**
 * Created by 451769 on 6/7/2017.
 */

public interface FicoDashBoardExpandCollapseListner {
    void expandCollapseDashboard();

}
