package com.discover.mobile.common.shared.net;

/**
 * Utility class with contains a collection of header name that can found in a HTTP request or
 * response.
 *
 * @author henryoyuela
 */
public class HttpHeaders {
    public static final String Authorization = "Authorization";
    public static final String XSecToken = "X-Sec-Token";
    public static final String Authentication = "WWW-Authenticate";
    public static final String XHttpMethodOveride = "X-HTTP-Method-Override";
    public static final String XIPAddress = "X-IPAddress";
    public static final String XDeviceId = "X-Device-ID";
    public static final String ContentType = "Accept";
    //US54417-Golden: Profile: Threatmetrics Generate TMX-SID-Start
    public static final String XThreatMetrixID = "X-TMX-SID";
    //US54417-Golden: Profile: Threatmetrics Generate TMX-SID-End

    //US158164: Android: Add Default X-Header to PA Environment
    public static final String XHttpDefaultOOB = "X-Default-OOB";


    protected HttpHeaders() {
        throw new UnsupportedOperationException("This class is non-instantiable"); //$NON-NLS-1$
    }
}
