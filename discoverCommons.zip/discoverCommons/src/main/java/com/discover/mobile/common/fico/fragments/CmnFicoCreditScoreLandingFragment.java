package com.discover.mobile.common.fico.fragments;

import com.discover.mobile.common.R;
import com.discover.mobile.common.fico.adapter.FicoBoxAdapter;
import com.discover.mobile.common.fico.bean.FicoCollapsedDetails;
import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.bean.FicoScoreList;
import com.discover.mobile.common.fico.bean.NegativeKeyFactor;
import com.discover.mobile.common.fico.bean.PositiveKeyFactor;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreLandingUIInterface;
import com.discover.mobile.common.fico.presenter.FicoCreditScoreLandingPresenter;
import com.discover.mobile.common.fico.presenter.FicoCreditScoreLandingPresenterImpl;
import com.discover.mobile.common.fico.utils.CreditScoreStrengths;
import com.discover.mobile.common.fico.utils.FicoCreditScoreConstants;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.fico.views.CmnFicoCreditScoreCardView;
import com.discover.mobile.common.onboardwiz.utils.BannerMessage;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by slende on 5/4/2017.
 * Its FICO credit score Dashboard
 */

public class CmnFicoCreditScoreLandingFragment extends Fragment implements FicoCreditScoreLandingUIInterface {

    private Context mContext;
    private TextView tvNoScoresTitle, tvNoScoresDescription, monthScoreValueTxtLand, privacyTermLandTxt, providFeedbackLandTxt, monthScoreDesTxtLand;
    private View ficoScoreNotAvailableLayout;
    private FicoCreditScoreLandingPresenter mFicoCreditScorePresenter;
    private ListView ficoScoreListView, ficoScoreCardBoxlist;
    private FicoBoxAdapter ficoViewAdapter;
    private CardView ficoCardView;
    private int prevPosition = -1;
    private View mainView;
    private LinearLayout expandedLayout;
    private RelativeLayout collapsedLayout;
    private FicoUtils.FicoBoxType ficoBoxType = FicoUtils.FicoBoxType.NONE;
    private RelativeLayout  creditScoreMonthLayoutLand;
    private ArrayList<FicoCollapsedDetails> ficoCollapsedDetails;
    private CmnFicoCreditScoreMasterFragment mCmnFicoCreditScoreMasterFragment;
    private LinearLayout privacyProvideFooterLayout;
    private boolean isBoxExpanded = false;
    private View horizontalColorView;
    private View verticalColorView;
    private long SLEEP_TIME_TO_RETAINS_STATE = 200;
    private CmnFicoCreditScoreCardView cmnFicoCreditScoreCardView;
    private View prevItemView;
    private boolean isExpandDisabled = false;
    private boolean isRevUtiExpandDisabled = false;
    private BannerMessage bannerMessage = null;
    private boolean isTotalAccountsBoxDisabled = false;
    private boolean isLengthCreditBoxDisabled = false;
    private boolean isInquiriesBoxDisabled = false;
    private boolean isMissedPaymentsBoxDisabled = false;
    private boolean isRunningOnHandset = false;
    private String limitedAuthUserError = null, noRevolvingTradeError = null, ficoTotalError = null;
    /**
     * start code optimization for CreditScore Box
     */
    private FicoCreditScore mFicoCreditScore = null;
    private FicoScoreList mValidScoreListItem = null;
    private List<PositiveKeyFactor> mPositiveKeyFactorList = null;
    private List<NegativeKeyFactor> mNegativeKeyFactorList = null;
    /**
     * end code optimization for CreditScore Box
     */

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFicoCreditScorePresenter = new FicoCreditScoreLandingPresenterImpl(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mainView = (ViewGroup) inflater.inflate(R.layout.fico_credit_scorecard_landing_frag, null);
        initUI(mainView);
        mFicoCreditScorePresenter.getFicoScoreListData(getArguments());
        return mainView;
    }

    private void initUI(View mainView) {
        isRunningOnHandset = CommonUtils.isRunningOnHandset(mContext);
        bannerMessage = new BannerMessage(mContext);
        tvNoScoresDescription = ((TextView) mainView.findViewById(R.id.tv_no_scores_description));
        ficoScoreNotAvailableLayout = (View) mainView.findViewById(R.id.fico_score_not_available_layout);
        tvNoScoresTitle = ((TextView) mainView.findViewById(R.id.tv_no_scores_title));
        tvNoScoresDescription = ((TextView) mainView.findViewById(R.id.tv_no_scores_description));
        ficoScoreListView = (ListView) mainView.findViewById(R.id.fico_list_view);
        mCmnFicoCreditScoreMasterFragment = (CmnFicoCreditScoreMasterFragment) getParentFragment();
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            ficoScoreCardBoxlist = (ListView) mainView.findViewById(R.id.ficoScoreCardBoxlist);
            monthScoreValueTxtLand = ((TextView) mainView.findViewById(R.id.monthScoreValueTxtLand));
            privacyTermLandTxt = ((TextView) mainView.findViewById(R.id.privacy_terms));
            providFeedbackLandTxt = ((TextView) mainView.findViewById(R.id.provide_feedback_button));
            monthScoreDesTxtLand = ((TextView) mainView.findViewById(R.id.monthScoreDesTxtLand));
            creditScoreMonthLayoutLand = (RelativeLayout) mainView.findViewById(R.id.creditScoreMonthLayoutLand);
            setLandscapeViewClick();
        }
    }

    /*This method setting Landscape view of Tablet*/
    private void setLandscapeViewClick() {
        if (monthScoreDesTxtLand != null) {
            monthScoreDesTxtLand.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_month_score_des_tablet)));
        }
        if (privacyTermLandTxt != null) {
            privacyTermLandTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mCmnFicoCreditScoreMasterFragment.handlePrivacyAndTermsClick();
                }
            });
        }
        if (providFeedbackLandTxt != null) {
            providFeedbackLandTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mCmnFicoCreditScoreMasterFragment.handleProvideFeedbackClick();
                }
            });
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        /*Start Changes for defect Fixed : 17239*/
        if (FicoUtils.isTalkBackEnabled(mContext)) {
            ficoViewAdapter = new FicoBoxAdapter(mContext, ficoCollapsedDetails, ficoBoxType, isExpandDisabled);
            ficoScoreListView.setAdapter(ficoViewAdapter);
            ficoViewAdapter.notifyDataSetInvalidated();
            FicoUtils.isTalkBackEnabledCalled = true;
        } else if (FicoUtils.isTalkBackEnabledCalled) {
            FicoUtils.isTalkBackEnabledCalled = false;
            ficoViewAdapter = new FicoBoxAdapter(mContext, ficoCollapsedDetails, ficoBoxType, isExpandDisabled);
            ficoScoreListView.setAdapter(ficoViewAdapter);
            ficoViewAdapter.notifyDataSetInvalidated();
        }
      /*End Changes for defect Fixed : 17239*/
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    /**
     * This method will show FICO dashboard
     */
    @Override
    public void showFicoDashboard(FicoCreditScore ficoCreditScore, FicoScoreList validScoreListItem,
                                  List<PositiveKeyFactor> positiveKeyFactorList, List<NegativeKeyFactor> negativeKeyFactorList) {
        mFicoCreditScore = ficoCreditScore;
        mValidScoreListItem = validScoreListItem;
        mPositiveKeyFactorList = positiveKeyFactorList;
        mNegativeKeyFactorList = negativeKeyFactorList;
        updateFicoListUI(mFicoCreditScore, mValidScoreListItem, mPositiveKeyFactorList, mNegativeKeyFactorList);
        showFicoCollapseListView(mValidScoreListItem);
        setTabletLandViewData(mFicoCreditScore);
    }

    /**
     * This method initialise views of the fragment
     */
    private void updateFicoListUI(FicoCreditScore ficoCreditScore, FicoScoreList validScoreListItem,
                                  List<PositiveKeyFactor> positiveKeyFactorList, List<NegativeKeyFactor> negativeKeyFactorList) {

        cmnFicoCreditScoreCardView = new CmnFicoCreditScoreCardView(mContext);
        cmnFicoCreditScoreCardView.mapDataWithView(ficoCreditScore, validScoreListItem, positiveKeyFactorList, negativeKeyFactorList, this);
        View ficoFooterView = ((LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.fico_footer_view_layout, null, false);
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            int orientation = mContext.getResources().getConfiguration().orientation;
            if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                ficoScoreListView.setVisibility(View.VISIBLE);

                /**Start Adding view to layout has wrap content issue, so using listview for adding CardBox view */
                if (ficoScoreCardBoxlist.getHeaderViewsCount() == 0) {
                    ficoScoreCardBoxlist.addHeaderView(cmnFicoCreditScoreCardView);
                }
                ficoScoreCardBoxlist.setAdapter(null);
                /** end*/
                showFicoFooterView(ficoFooterView);
                ficoFooterView.setPadding(FicoUtils.dpToPx(11, mContext), 0, FicoUtils.dpToPx(11, mContext), 0);
                privacyProvideFooterLayout.setVisibility(View.GONE);

            } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                if (ficoScoreListView.getHeaderViewsCount() == 0) {
                    ficoScoreListView.addHeaderView(cmnFicoCreditScoreCardView);
                    ficoScoreListView.setVisibility(View.VISIBLE);
                    showFicoFooterView(ficoFooterView);
                }
            }
        } else {
            if (ficoScoreListView.getHeaderViewsCount() == 0) {
                ficoScoreListView.addHeaderView(cmnFicoCreditScoreCardView);
                ficoScoreListView.setVisibility(View.VISIBLE);
                showFicoFooterView(ficoFooterView);
            }
        }

        ficoScoreListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int revUtiPosition = 4;
                int orientation = mContext.getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    revUtiPosition = 3;
                }
                if (!(isExpandDisabled || isSpecificBoxDisabled(position))) {
                    if (!(position == revUtiPosition && isRevUtiExpandDisabled)) {
                        if (prevPosition != -1 && prevPosition != position) {
                            expandedLayout.setVisibility(View.GONE);
                            collapsedLayout.setVisibility(View.VISIBLE);
                            horizontalColorView.setVisibility(View.GONE);
                            verticalColorView.setVisibility(View.VISIBLE);

                        }
                        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext) && mContext.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                            prevItemView = view;
                            expandCollapseBox(position, view);

                        } else {
                            if (position != 0) {
                                prevItemView = view;
                                expandCollapseBox(position, view);
                            } else {
                                if (prevPosition != -1) {
                                    expandCollapseBox(prevPosition, prevItemView);
                                }
                            }
                        }
                    }
                }
            }
        });
    }

    public void expandCollapseBox(final int position, View view) {

        ficoCardView = (CardView) view.findViewById(R.id.fico_card_view);
        expandedLayout = (LinearLayout) view.findViewById(R.id.fico_expanded_layout);
        collapsedLayout = (RelativeLayout) view.findViewById(R.id.collapsed_layout);
        verticalColorView = (View) view.findViewById(R.id.collapsed_vertical_color_view);
        horizontalColorView = (View) view.findViewById(R.id.expanded_box_color_view);

        if (collapsedLayout.getVisibility() == View.VISIBLE) {
            expandedLayout.setVisibility(View.VISIBLE);
            collapsedLayout.setVisibility(View.GONE);
            Animation expandAnim;
            if (isBoxExpanded && position < prevPosition) {
                expandAnim = AnimationUtils.loadAnimation(mContext,
                        R.anim.fico_anim_bottom_down);
            } else if (isBoxExpanded && position > prevPosition) {
                expandAnim = AnimationUtils.loadAnimation(mContext,
                        R.anim.fico_anim_bottom);
            } else {
                expandAnim = AnimationUtils.loadAnimation(mContext,
                        R.anim.fico_anim_center);
            }
            expandedLayout.startAnimation(expandAnim);
            verticalColorView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    if (Build.VERSION.SDK_INT < 16) {
                        verticalColorView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                    } else {
                        verticalColorView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                    final int initialHeight = verticalColorView.getHeight();
                    FicoUtils.animateColorViews(verticalColorView, initialHeight, horizontalColorView, ficoScoreListView, position, mContext);

                }
            });

            isBoxExpanded = true;
            int orientation = mContext.getResources().getConfiguration().orientation;
            if (orientation != Configuration.ORIENTATION_LANDSCAPE && position != 0) {
                cmnFicoCreditScoreCardView.expandCollapseDashboard();
            }
                /* Start Changes for 121913*/
            if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext) && orientation == Configuration.ORIENTATION_LANDSCAPE) {
                FicoUtils.trackFicoBoxesExapandTags(mContext, position, ficoCollapsedDetails.get(position));
            } else {
                if (position != 0 && position < 6) {
                    int boxPos = 0;
                    boxPos = position - 1;
                    FicoUtils.trackFicoBoxesExapandTags(mContext, boxPos, ficoCollapsedDetails.get(boxPos));
                }
            }
                /* End Changes for 121913*/
        } else {
            horizontalColorView.setVisibility(View.INVISIBLE);
            expandedLayout.setVisibility(View.GONE);
            collapsedLayout.setVisibility(View.VISIBLE);
            verticalColorView.setVisibility(View.VISIBLE);
            isBoxExpanded = false;
            /*Start changes for US153330*/
            if (mContext.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                FicoUtils.smoothScrollToPositionFromTop(ficoScoreListView, 0, mContext);
            }
           /*End changes for US153330*/
        }

        ficoViewAdapter.notifyDataSetChanged();
        prevPosition = position;
    }


    /**
     * This method call when service Fails
     */
    private void setCollapsedBoxTitleAndValues(FicoScoreList ficoScoreListItem) {

        /**
         *As we dont want to hard code these error codes, we are keeping them in WSCR infomessage.json.
         *These special error code are handled with reference of User Story USXXXX.
         **/
        limitedAuthUserError = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.CMN_FICO_lIMITED_AUTHOR_USER_ERROR); //-0999999998
        noRevolvingTradeError = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.CMN_FICO_NO_REVOLVING_TRADE_ERROR); //-0999999989
        ficoTotalError = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.CMN_FICO_TOTAL_ERROR); //-1999999996

        // Total Accounts
        if ((ficoScoreListItem.getOpenRvlTradeCount() != null && ficoScoreListItem.getOpenRvlTradeCount().equals(limitedAuthUserError)) ||
                (ficoScoreListItem.getOpenInstTradeCount() != null && ficoScoreListItem.getOpenInstTradeCount().equals(limitedAuthUserError)) ||
                (ficoScoreListItem.getTradeCount() != null && ficoScoreListItem.getTradeCount().equals(ficoTotalError))) {
            isTotalAccountsBoxDisabled = true;
        }
        // Length of Credit
        if (ficoScoreListItem.getOldestTradeMonthCount() != null && ficoScoreListItem.getOldestTradeMonthCount().equals(limitedAuthUserError)) {
            isLengthCreditBoxDisabled = true;
        }
        // Inquiries
        if (ficoScoreListItem.getInquiryCount() != null && ficoScoreListItem.getInquiryCount().equals(limitedAuthUserError)) {
            isInquiriesBoxDisabled = true;
        }
        //Missed Payments
        if ((ficoScoreListItem.getTotalMissedPymt() != null && ficoScoreListItem.getTotalMissedPymt().equals(limitedAuthUserError)) ||
                (ficoScoreListItem.getMissedPaymentsInLastyear() != null && ficoScoreListItem.getMissedPaymentsInLastyear().equals(limitedAuthUserError))) {
            isMissedPaymentsBoxDisabled = true;
        }
        //revolving utilization
        if ((ficoScoreListItem.getOpenRvlUtilizationPct() != null && (ficoScoreListItem.getOpenRvlUtilizationPct().equals(limitedAuthUserError) || ficoScoreListItem.getOpenRvlUtilizationPct().equals(noRevolvingTradeError))) ||
                (ficoScoreListItem.getTotalRvlBalAmt() != null && (ficoScoreListItem.getTotalRvlBalAmt().equals(limitedAuthUserError) || ficoScoreListItem.getTotalRvlBalAmt().equals(noRevolvingTradeError)))) {
            isRevUtiExpandDisabled = true;
        }
        //Show Disabled Error Message in Banner
        if (isTotalAccountsBoxDisabled && isLengthCreditBoxDisabled && isInquiriesBoxDisabled && isMissedPaymentsBoxDisabled && isRevUtiExpandDisabled) {
            isExpandDisabled = true;
            showDisabledErrorBanner();
        } else if (isRevUtiExpandDisabled) {
            showRevolvingDisabledErrorBanner();
        }

        ficoCollapsedDetails = new ArrayList<>();
        ficoCollapsedDetails.add(new FicoCollapsedDetails(mContext.getResources().getString(R.string.cmn_fico_total_accounts_box_title), ficoScoreListItem.getTradeCount(), ficoScoreListItem.getOpenRvlTradeCount(), ficoScoreListItem.getOpenInstTradeCount(), ficoScoreListItem.getTradeCount(), FicoUtils.getColorBasedOnRatingCode(ficoScoreListItem.getTotalAccountRatingCode(), mContext), ficoScoreListItem.getTotalAccountRating(), isTotalAccountsBoxDisabled));
        ficoCollapsedDetails.add(new FicoCollapsedDetails(mContext.getResources().getString(R.string.cmn_fico_length_of_credit_box_title), ficoScoreListItem.getOldestTradeMonthCount(), null, ficoScoreListItem.getOldestTradeMonthCount(), null, FicoUtils.getColorBasedOnRatingCode(ficoScoreListItem.getLengthOfCreditRatingCode(), mContext), ficoScoreListItem.getLengthOfCreditRating(), isLengthCreditBoxDisabled));
        ficoCollapsedDetails.add(new FicoCollapsedDetails(mContext.getResources().getString(R.string.cmn_fico_inquiries_box_title), ficoScoreListItem.getInquiryCount(), null, ficoScoreListItem.getInquiryCount(), null, FicoUtils.getColorBasedOnRatingCode(ficoScoreListItem.getInquiriesRatingCode(), mContext), ficoScoreListItem.getInquiriesRating(), isInquiriesBoxDisabled));
        ficoCollapsedDetails.add(new FicoCollapsedDetails(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_box_title), ficoScoreListItem.getOpenRvlUtilizationPct(), ficoScoreListItem.getOpenRvlUtilizationPct(), ficoScoreListItem.getTotalRvlBalAmt(), null, FicoUtils.getColorBasedOnRatingCode(ficoScoreListItem.getRevolvingUtilizationRatingCode(), mContext), ficoScoreListItem.getRevolvingUtilizationRating(), isRevUtiExpandDisabled));
        ficoCollapsedDetails.add(new FicoCollapsedDetails(mContext.getResources().getString(R.string.cmn_fico_missed_payments_box_title), ficoScoreListItem.getMissedPaymentsInLastyear(), ficoScoreListItem.getTotalMissedPymt(), ficoScoreListItem.getMissedPaymentsInLastyear(), null, FicoUtils.getColorBasedOnRatingCode(ficoScoreListItem.getMissedPaymentsRatingCode(), mContext), ficoScoreListItem.getMissedPaymentsRating(), isMissedPaymentsBoxDisabled));
    }

    public void showDisabledErrorBanner() {
        bannerMessage.setMessage(mContext.getResources().getString(R.string.cmn_fico_no_attribute_banner_message));
        ((ViewGroup) mainView).removeView(mainView.findViewById(com.discover.mobile.common.R.id.animation_container));
        bannerMessage.make(mContext, ((CmnFicoCreditScoreMasterFragment) getParentFragment()).getParentView(), mContext.getResources().getString(R.string.cmn_fico_no_attribute_banner_message), BannerMessage.FICO_ATTRIBUTE_UNAVAILABLE_ERROR);
        bannerMessage.show();
    }

    public void showRevolvingDisabledErrorBanner() {
        bannerMessage.setMessage(mContext.getResources().getString(R.string.cmn_fico_no_attribute_banner_message));
        ((ViewGroup) mainView).removeView(mainView.findViewById(com.discover.mobile.common.R.id.animation_container));
        bannerMessage.make(mContext, ((CmnFicoCreditScoreMasterFragment) getParentFragment()).getParentView(), mContext.getResources().getString(R.string.cmn_fico_rev_utilization_not_available_banner_message), BannerMessage.FICO_REVOLVING_UTIL_UNAVAILABLE_ERROR);
        bannerMessage.show();
    }

    private boolean isSpecificBoxDisabled(int boxPosition) {
        boolean disableBox = false;
        int orientation = mContext.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (boxPosition == 0 && isTotalAccountsBoxDisabled) {
                disableBox = true;
            } else if (boxPosition == 1 && isLengthCreditBoxDisabled) {
                disableBox = true;
            } else if (boxPosition == 2 && isInquiriesBoxDisabled) {
                disableBox = true;
            } else if (boxPosition == 4 && isMissedPaymentsBoxDisabled) {
                disableBox = true;
            }
        } else {
            if (boxPosition == 1 && isTotalAccountsBoxDisabled) {
                disableBox = true;
            } else if (boxPosition == 2 && isLengthCreditBoxDisabled) {
                disableBox = true;
            } else if (boxPosition == 3 && isInquiriesBoxDisabled) {
                disableBox = true;
            } else if (boxPosition == 5 && isMissedPaymentsBoxDisabled) {
                disableBox = true;
            }
        }
        return disableBox;
    }

    @Override
    public void showNoFicoScoreAvailableScreen() {
        if (creditScoreMonthLayoutLand != null) {
            creditScoreMonthLayoutLand.setVisibility(View.GONE);
        }
        ficoScoreNotAvailableLayout.setVisibility(View.VISIBLE);
        if (isRunningOnHandset) {
            tvNoScoresTitle.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.no_scores_title)));
            tvNoScoresDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.no_scores_description)));
        } else {
            tvNoScoresTitle.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.no_scores_title_tablet)));
            tvNoScoresDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.no_scores_description_tablet)));
        }

    }

    @Override
    public void hideSpinner() {
        PortalUtils.hideSpinner(mContext);
    }

    @Override
    public void showSpinner() {
        PortalUtils.showSpinner(mContext);
    }


    @Override
    public void showFicoCollapseListView(FicoScoreList ficoScoreList) {
        ficoBoxType = FicoUtils.FicoBoxType.ACCOUNT_DETAILS_BOX_COLLAPSED;
        setCollapsedBoxTitleAndValues(ficoScoreList);
        ficoViewAdapter = new FicoBoxAdapter(mContext, ficoCollapsedDetails, ficoBoxType, isExpandDisabled);
        ficoScoreListView.setAdapter(ficoViewAdapter);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        ficoViewAdapter.notifyDataSetChanged();
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            populateViewOnOrientation(inflater, (ViewGroup) getView());
        }
        if (isBoxExpanded) {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    View view;
                    int orientation = mContext.getResources().getConfiguration().orientation;
                    if (!isRunningOnHandset && orientation == Configuration.ORIENTATION_LANDSCAPE) {
                        view = ficoScoreListView.getChildAt(prevPosition - 1);
                        prevPosition = prevPosition - 1;
                    } else {
                        prevPosition = prevPosition + 1;
                        view = ficoScoreListView.getChildAt(prevPosition);

                    }
                    ficoCardView = (CardView) view.findViewById(R.id.fico_card_view);
                    expandedLayout = (LinearLayout) view.findViewById(R.id.fico_expanded_layout);
                    collapsedLayout = (RelativeLayout) view.findViewById(R.id.collapsed_layout);
                    expandedLayout.setVisibility(View.VISIBLE);
                    collapsedLayout.setVisibility(View.GONE);
                    horizontalColorView = (View) view.findViewById(R.id.expanded_box_color_view);
                    verticalColorView = (View) view.findViewById(R.id.collapsed_vertical_color_view);
                    horizontalColorView.setVisibility(View.VISIBLE);
                    verticalColorView.setVisibility(View.GONE);
                }
            }, SLEEP_TIME_TO_RETAINS_STATE);
        }
    }

    private void populateViewOnOrientation(LayoutInflater inflater, ViewGroup rootViewGroup) {
        rootViewGroup.removeAllViews();
        rootViewGroup.setPadding(0, 0, 0, 0);
        mainView = inflater.inflate(R.layout.fico_credit_scorecard_landing_frag, null, false);
        rootViewGroup.addView(mainView);
        initUI(mainView);
        /**start code optimization for CreditScore Box */
        updateFicoListUI(mFicoCreditScore, mValidScoreListItem, mPositiveKeyFactorList, mNegativeKeyFactorList);
        showFicoCollapseListView(mValidScoreListItem);
        setTabletLandViewData(mFicoCreditScore);
        /**end code optimization for CreditScore Box */
    }

    private void showFicoFooterView(View footerView) {
        ficoScoreListView.addFooterView(footerView);
        TextView tvScoresFaq = ((TextView) footerView.findViewById(R.id.tv_scores_faq));
        TextView tvScoresTerms = ((TextView) footerView.findViewById(R.id.tv_scores_terms));
        final TextView tvScoresTermsDescription = ((TextView) footerView.findViewById(R.id.tv_scores_terms_description));
        TextView privacy_terms_txt = ((TextView) footerView.findViewById(R.id.privacy_terms));
        TextView provide_feedback_txt = ((TextView) footerView.findViewById(R.id.provide_feedback_button));
        LinearLayout fico_footer_parent_layout = ((LinearLayout) footerView.findViewById(R.id.fico_footer_parent_layout));
        if (isRunningOnHandset) {
            tvScoresTerms.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_terms)));
            tvScoresFaq.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_faq)));
        } else {
            tvScoresTerms.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_terms_tablet)));
            tvScoresFaq.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_faq_tablet)));
        }
        privacyProvideFooterLayout = ((LinearLayout) footerView.findViewById(R.id.privacyProvideFooterLayout));

        tvScoresFaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCmnFicoCreditScoreMasterFragment.handleFicoScoreFAQClick();
            }
        });
        FicoUtils.setPaddingForTabletPort(fico_footer_parent_layout, mContext, 16);
        String scoreTermsDescription = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.CMN_CREDIT_SCORECARD_TERMS_CONDITION_DESP_MSG);
        if (!CommonUtils.isNullOrEmpty(scoreTermsDescription)) {
            tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(scoreTermsDescription));
        } else {
            if (isRunningOnHandset) {
                tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_decription)));
            } else {
                tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_decription_tablet)));
            }
        }

        /*Defect fixed: 13273*/
        showPhoneWebUrlLink(tvScoresTermsDescription);
        privacy_terms_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCmnFicoCreditScoreMasterFragment.handlePrivacyAndTermsClick();
            }
        });
        provide_feedback_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCmnFicoCreditScoreMasterFragment.handleProvideFeedbackClick();
            }
        });
    }


    @Override
    public void setTabletLandViewData(FicoCreditScore ficoCreditScore) {
        if (ficoCreditScore != null) {
            if (!ficoCreditScore.isScoreTooOld()) {
                if (monthScoreValueTxtLand != null && ficoCreditScore.getScoreDate() != null) {
                    //Removed date format as per US124309
                    String mDate = ficoCreditScore.getScoreDate();
                    if (mDate != null) {
                        monthScoreValueTxtLand.setText(mContext.getString(R.string.fico_month_score_title) + " " + mDate);
                    }
                }
            } else {
                if (monthScoreValueTxtLand != null && ficoCreditScore.getScoreDate() != null) {
                    monthScoreValueTxtLand.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_box_90_days_title_tablet) + " " + ficoCreditScore.getScoreDate()));
                }
                if (monthScoreDesTxtLand != null) {
                    monthScoreDesTxtLand.setVisibility(View.GONE);
                }
            }
        }

    }
    @Override
    public void onCreditScoreBoxClick(int boxState) {
        ficoViewAdapter.notifyDataSetChanged();
        int orientation = mContext.getResources().getConfiguration().orientation;
        if (orientation != Configuration.ORIENTATION_LANDSCAPE) {
            if (boxState == 2 && prevPosition != -1 && isBoxExpanded) {
                expandCollapseBox(prevPosition, prevItemView);
            }
        }

    }

    @Override
    public void handleCreditScoreHelpEvent(int currentScoreInt) {
        CreditScoreStrengths strengthType = null;
        strengthType = FicoUtils.getScoreStrength(currentScoreInt);
        if (null == strengthType) {
            return;
        }

        String modalTitle = null, modalDesc = null, contentDesc = null;

        switch (strengthType) {

            case EXCEPTIONAL_RATING:
                modalTitle = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_TITLE_EXCEPTIONAL_RATING);
                modalDesc = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_DESC_EXCEPTIONAL_RATING);
                if (PortalUtils.isStrFieldEmpty(modalTitle) || PortalUtils.isStrFieldEmpty(modalDesc)) {
                    modalTitle = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_title_exceptional_rating);
                    modalDesc = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_desc_exceptional_rating);
                }
                break;

            case VERY_GOOD_RATING:
                modalTitle = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_TITLE_VERY_GOOD_RATING);
                modalDesc = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_DESC_VERY_GOOD_RATING);
                if (PortalUtils.isStrFieldEmpty(modalTitle) || PortalUtils.isStrFieldEmpty(modalDesc)) {
                    modalTitle = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_title_very_good_rating);
                    modalDesc = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_desc_very_good_rating);
                }
                break;

            case GOOD_RATING:
                modalTitle = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_TITLE_GOOD_RATING);
                modalDesc = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_DESC_GOOD_RATING);
                if (PortalUtils.isStrFieldEmpty(modalTitle) || PortalUtils.isStrFieldEmpty(modalDesc)) {
                    modalTitle = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_title_good_rating);
                    modalDesc = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_desc_good_rating);
                }
                break;

            case FAIR_RATING:
                modalTitle = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_TITLE_FAIR_RATING);
                modalDesc = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_DESC_FAIR_RATING);
                if (PortalUtils.isStrFieldEmpty(modalTitle) || PortalUtils.isStrFieldEmpty(modalDesc)) {
                    modalTitle = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_title_fair_rating);
                    modalDesc = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_desc_fair_rating);
                }
                break;

            case POOR_RATING:
                modalTitle = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_TITLE_POOR_RATING);
                modalDesc = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.STDES_MODAL_DESC_POOR_RATING);
                if (PortalUtils.isStrFieldEmpty(modalTitle) || PortalUtils.isStrFieldEmpty(modalDesc)) {
                    modalTitle = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_title_poor_rating);
                    modalDesc = mContext.getResources().getString(R.string.cmn_fico_stdes_modal_desc_poor_rating);
                }
                break;

            default:
                break;
        }
        if (!isRunningOnHandset) {
            modalDesc = modalDesc.replace(mContext.getResources().getString(R.string.fico_small_reg_mark), mContext.getResources().getString(R.string.fico_large_reg_mark));
        }
        if (modalDesc.contains("-")) {
            contentDesc = modalDesc.replace("-", mContext.getResources().getString(R.string.to_desc));
        } else {
            contentDesc = modalDesc;
        }
        showStrengthDescModal(mContext, modalTitle, modalDesc, contentDesc);

    }

    @Override
    public void showStrengthDescModal(Context mContext, String titleStr, String descStr,String contentDesc) {

        if (null != mContext && !PortalUtils.isStrFieldEmpty(titleStr) && !PortalUtils.isStrFieldEmpty(descStr)) {

            final DiscoverAlertDialog strengthDescDialog = new DiscoverAlertDialog();
            strengthDescDialog.setContentDesc(contentDesc);
            strengthDescDialog.setTitle(titleStr).
                    setMessage(CommonUtils.getHtmlFormattedText(descStr)).
                    setPositiveButton(mContext.getResources().getString(R.string.cmn_fico_stdes_modal_close_btn_text), new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    }).setCanCancelable(true).setCanceledOnTouchOutside(false).show((AppCompatActivity) mContext);
        }
    }


    private void showPhoneWebUrlLink(final TextView tvScoresTermsDescription) {
        if (com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            Linkify.TransformFilter myTransformFilter = new Linkify.TransformFilter() {
                @Override
                public String transformUrl(Matcher match, String url) {
                    if (url != null && url.equalsIgnoreCase(FicoCreditScoreConstants.US_NUMBER)) {
                        return FicoCreditScoreConstants.US_NUMBER_URI;
                    }
                    return url;
                }
            };
            if (isRunningOnHandset) {
                tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.cmn_fico_score_decription)));
            } else {
                tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.cmn_fico_score_decription_tablet)));
            }
            Linkify.addLinks(tvScoresTermsDescription, Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
            Linkify.addLinks(tvScoresTermsDescription, Pattern.compile(FicoCreditScoreConstants.US_NUMBER), FicoCreditScoreConstants.US_NUMBER_URI, null, myTransformFilter);
            tvScoresTermsDescription.post(new Runnable() {
                @Override
                public void run() {
                    FicoUtils.removeUnderlines(tvScoresTermsDescription);
                }
            });
        } else {
            if (isRunningOnHandset) {
                tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.cmn_fico_score_decription)));
            } else {
                tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.cmn_fico_score_decription_tablet)));
            }
            Linkify.addLinks(tvScoresTermsDescription, Linkify.WEB_URLS);
            tvScoresTermsDescription.post(new Runnable() {
                @Override
                public void run() {
                    FicoUtils.removeUnderlines(tvScoresTermsDescription);
                }
            });
        }
    }


      /*Start Changes for US118296*/

    /**
     * This method shows Fico Score Unavailabel Model
     */
    @Override
    public void showScoreUnavailableModal() {
        final DiscoverAlertDialog scoreUnavailabelModel = new DiscoverAlertDialog();
        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View child = layoutInflater.inflate(R.layout.fico_score_unavailable_model_layout, null);
        if (isRunningOnHandset) {
            scoreUnavailabelModel.setTitle(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_90_days_unavailabel_title)));
        } else {
            scoreUnavailabelModel.setTitle(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_90_days_unavailabel_title_tablet)));
        }
        scoreUnavailabelModel.setCustomContentView(child);

        TextView cmn_fico_header = (TextView) child.findViewById(R.id.header_tv);
        TextView point1_desc = (TextView) child.findViewById(R.id.point1_desc);
        TextView point2_desc = (TextView) child.findViewById(R.id.point2_desc);
        TextView point3_desc = (TextView) child.findViewById(R.id.point3_desc);
        TextView point4_desc = (TextView) child.findViewById(R.id.point4_desc);
        TextView point5_desc = (TextView) child.findViewById(R.id.point5_desc);
        TextView point6_desc = (TextView) child.findViewById(R.id.point6_desc);

        cmn_fico_header.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_header)));
        point1_desc.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_bullet_one_desp)));
        point2_desc.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_bullet_two_desp)));
        if (com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            CommonUtils.handlePhoneNumberClick(mContext, null, point2_desc, point2_desc.getText().toString());
        }
        if (com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            point3_desc.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_bullet_three_desp)));
        } else {
            point3_desc.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_bullet_three_desp_tablet)));
        }
        point4_desc.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_bullet_four_desp)));
        point5_desc.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_bullet_five_desp)));
        point6_desc.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_bullet_six_desp)));

        scoreUnavailabelModel.setPositiveButton(mContext.getResources().getString(R.string.cmn_fico_stdes_modal_close_btn_text), new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        scoreUnavailabelModel.setCanceledOnTouchOutside(false).show(DiscoverActivityManager.getActiveAppCompatActivity());

    }
    /*End Changes for US118296*/

    /**
     * Method to show Key-factors modal on tap of plot overlay from FICO Graph
     */
    @Override
    public void showKeyFactorDetailModal(FicoScoreList ficoScoreListItem) {
        if (null != ficoScoreListItem) {
            Bundle bundle = new Bundle();
            bundle.putSerializable(FicoCreditScoreConstants.FICO_CREDIT_SCORE, mFicoCreditScore);
            bundle.putSerializable(FicoCreditScoreConstants.FICO_SELECTED_LIST_ITEM, ficoScoreListItem);
            CmnFicoKeyFactorAlertDialog keyFactorsModal = new CmnFicoKeyFactorAlertDialog();
            keyFactorsModal.setArguments(bundle);
            keyFactorsModal.show((AppCompatActivity) mContext);
        }
    }

    //Added for Defect# 16661 List Scroll Issue on Tablet Landscape mode
    @Override
    public void setListFocus() {
        int orientation = mContext.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (null != ficoScoreCardBoxlist) {
                ficoScoreCardBoxlist.setSelection(0);
            }
        }
    }
}