package com.discover.mobile.common.services;

//import roboguice.inject.ContextSingleton;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;

import com.discover.mobile.common.R;
import com.xtify.sdk.api.XtifySDK;

import android.content.Context;

/**
 * Service class for the push notifications. Right now this is meant to be a
 * singleton as there is no reason to have more than one of these. This class
 * currently provides common notification service methods including the starting
 * of the Xtify Service.
 *
 * @author jthornton
 */

public class PushNotificationService {

    /**
     * Starts the Xtify SDK using the correct app key and the correct Google
     * Project ID specific to the environment
     *
     * @param context - application context
     */
    public void start(final Context context) {
        final String xtifyAppKey = context.getResources().getString(
                R.string.push_key);
        final String googleProjectId = context.getResources().getString(
                R.string.push_id);
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(context.getApplicationContext());
        boolean isAndroidDevice = true;
        if (status != ConnectionResult.SUCCESS) {
            isAndroidDevice = false;
        }
        if (isAndroidDevice) {
            XtifySDK.start(context.getApplicationContext(), xtifyAppKey,
                    googleProjectId);
        } else {
            /**
             * This function should be called for Amazon push notification
             */
            //TODO:: To be removed below line to avoid crash at Amazon device.
            //  XtifySDK.start(context.getApplicationContext());
        }
    }
}