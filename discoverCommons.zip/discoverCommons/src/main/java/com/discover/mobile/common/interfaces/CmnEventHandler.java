package com.discover.mobile.common.interfaces;

/**
 * Created by slende on 5/24/2017.
 * Generic call-back handler for Common features between card & bank
 */

public interface CmnEventHandler {

    /**
     * Events that needs to handle either Card specific or Bank specific only
     */
    enum CmnEvent {
        PRIVACY_AND_TERMS_CLICK_EVENT,
        PROVIDE_FEEDBACK_CLICK_EVENT,
        API_ERROR,
        FAQ_EVENT,
        FAQ_NO_SCORE_EVENT
    }

    boolean handleEvent(CmnEvent strAction, String strParameter);
}
