package com.discover.mobile.common.fico.fragments;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.fico.utils.FicoCreditScoreConstants;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.shared.utils.CommonUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by 451769 on 6/30/2017.
 */

public class CmnFicoNoScoreFragment extends Fragment {

    private View noScoreView;
    private TextView noScoreBulletPtOne, noScoreBulletPtTwo, noScoreBulletPtThree, noScoreBulletPtFour, noScoreBulletPtFive, noScoreBulletPtSix;
    private TextView tvNoScoresTitle, tvNoScoresDescription, monthScoreDesTxtLand, privacyTermLandTxt, providFeedbackLandTxt, monthScoreValueTxtLand;
    private TextView tvScoresFaq, tvScoresTerms, tvScoresTermsDescription, privacy_terms_txt, provide_feedback_txt;
    private LinearLayout privacyProvideFooterLayout, fico_footer_parent_layout;
    private Context mContext;
    private CmnFicoCreditScoreMasterFragment mCmnFicoCreditScoreMasterFragment;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        noScoreView = (ViewGroup) inflater.inflate(R.layout.fico_no_score_available_layout, null);
        initUI(noScoreView);
         /* Start Changes for 121913*/
        TrackingHelper.trackPageView(AnalyticsPage.FICO_CREDITSCORE_NOSCORE_PG);
         /* End Changes for 121913*/
        showTermsConditions(noScoreView);
        return noScoreView;
    }

    private void initUI(View view) {

        tvScoresFaq = ((TextView) view.findViewById(R.id.tv_scores_faq));
        mCmnFicoCreditScoreMasterFragment = (CmnFicoCreditScoreMasterFragment) getParentFragment();
        tvScoresTerms = ((TextView) view.findViewById(R.id.tv_scores_terms));
        tvScoresTermsDescription = ((TextView) view.findViewById(R.id.tv_scores_terms_description));
        privacy_terms_txt = ((TextView) view.findViewById(R.id.privacy_terms));
        provide_feedback_txt = ((TextView) view.findViewById(R.id.provide_feedback_button));
        fico_footer_parent_layout = ((LinearLayout) view.findViewById(R.id.fico_footer_parent_layout));
        privacyProvideFooterLayout = ((LinearLayout) view.findViewById(R.id.privacyProvideFooterLayout));
        noScoreBulletPtOne = (TextView) view.findViewById(R.id.bullet_point_one);
        noScoreBulletPtTwo = (TextView) view.findViewById(R.id.bullet_point_two);
        noScoreBulletPtThree = (TextView) view.findViewById(R.id.bullet_point_three);
        noScoreBulletPtFour = (TextView) view.findViewById(R.id.bullet_point_four);
        noScoreBulletPtFive = (TextView) view.findViewById(R.id.bullet_point_five);
        noScoreBulletPtSix = (TextView) view.findViewById(R.id.bullet_point_six);
        tvNoScoresDescription = ((TextView) view.findViewById(R.id.tv_no_scores_description));
        tvNoScoresTitle = ((TextView) view.findViewById(R.id.tv_no_scores_title));
        if (CommonUtils.isRunningOnHandset(mContext)) {
            tvScoresTerms.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_terms)));
            tvScoresFaq.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_faq)));
            tvNoScoresTitle.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_not_available_title)));
            tvNoScoresDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_not_available_desc)));
            noScoreBulletPtTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_two_desp)));
            noScoreBulletPtThree.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_three_desp)));
            tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_decription)));

        } else {
            tvScoresTerms.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_terms_tablet)));
            tvScoresFaq.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_faq_tablet)));
            tvNoScoresTitle.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_not_available_title_tablet)));
            tvNoScoresDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_not_available_desc_tablet)));
            noScoreBulletPtTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_two_desp_tablet)));
            noScoreBulletPtThree.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_three_desp_tablet)));
            tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_decription_tablet)));
        }
        noScoreBulletPtOne.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_one_desp)));
        noScoreBulletPtFour.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_four_desp)));
        noScoreBulletPtFive.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_five_desp)));
        noScoreBulletPtSix.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_bullet_six_desp)));
        linkyfyText();
        setLandscapeView(view);
        tvScoresFaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCmnFicoCreditScoreMasterFragment.handleFicoScoreFAQClick();
            }
        });

    }

    private void linkyfyText() {
        showPhoneWebUrlLink(tvScoresTermsDescription);
        if (com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            Linkify.TransformFilter myTransformFilter = new Linkify.TransformFilter() {
                @Override
                public String transformUrl(Matcher match, String url) {
                    if (url != null && url.equalsIgnoreCase(FicoCreditScoreConstants.US_NUMBER)) {
                        return FicoCreditScoreConstants.US_NUMBER_URI;
                    }
                    return url;
                }
            };

            Linkify.addLinks(noScoreBulletPtTwo, Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
            Linkify.addLinks(noScoreBulletPtTwo, Pattern.compile(FicoCreditScoreConstants.US_NUMBER), FicoCreditScoreConstants.US_NUMBER_URI, null, myTransformFilter);
            FicoUtils.removeUnderlines(noScoreBulletPtTwo);
        }
    }

    private void setLandscapeView(View view) {
        int orientation = mContext.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE)
            privacyTermLandTxt = ((TextView) view.findViewById(R.id.privacy_terms));
            providFeedbackLandTxt = ((TextView) view.findViewById(R.id.provide_feedback_button));

            if (monthScoreDesTxtLand != null) {
                monthScoreDesTxtLand.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_month_score_des_tablet)));
            }
            if (privacyTermLandTxt != null) {
                privacyTermLandTxt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mCmnFicoCreditScoreMasterFragment.handlePrivacyAndTermsClick();
                    }
                });
            }
            if (providFeedbackLandTxt != null) {
                providFeedbackLandTxt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mCmnFicoCreditScoreMasterFragment.handleProvideFeedbackClick();
                    }
                });
            }
        }


    private void showPhoneWebUrlLink(final TextView tvScoresTermsDescription) {
        if (com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            Linkify.TransformFilter myTransformFilter = new Linkify.TransformFilter() {
                @Override
                public String transformUrl(Matcher match, String url) {
                    if (url != null && url.equalsIgnoreCase(FicoCreditScoreConstants.US_NUMBER)) {
                        return FicoCreditScoreConstants.US_NUMBER_URI;
                    }
                    return url;
                }
            };
            tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.cmn_fico_score_decription)));
            Linkify.addLinks(tvScoresTermsDescription, Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
            Linkify.addLinks(tvScoresTermsDescription, Pattern.compile(FicoCreditScoreConstants.US_NUMBER), FicoCreditScoreConstants.US_NUMBER_URI, null, myTransformFilter);
            tvScoresTermsDescription.post(new Runnable() {
                @Override
                public void run() {
                    FicoUtils.removeUnderlines(tvScoresTermsDescription);
                }
            });
        } else {
            tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.cmn_fico_score_decription)));
            Linkify.addLinks(tvScoresTermsDescription, Linkify.WEB_URLS);
            tvScoresTermsDescription.post(new Runnable() {
                @Override
                public void run() {
                    FicoUtils.removeUnderlines(tvScoresTermsDescription);
                }
            });
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            populateViewOnOrientation(inflater, (ViewGroup) getView());
        }
    }

    private void populateViewOnOrientation(LayoutInflater inflater, ViewGroup rootViewGroup) {
        rootViewGroup.removeAllViews();
        noScoreView = inflater.inflate(R.layout.fico_no_score_available_layout, null, false);
        rootViewGroup.addView(noScoreView);
        initUI(noScoreView);
    }

    private void showTermsConditions(View view) {
        TextView tvScoresFaq = ((TextView) view.findViewById(R.id.tv_scores_faq));
        TextView tvScoresTerms = ((TextView) view.findViewById(R.id.tv_scores_terms));
        final TextView tvScoresTermsDescription = ((TextView) view.findViewById(R.id.tv_scores_terms_description));
        TextView privacy_terms_txt = ((TextView) view.findViewById(R.id.privacy_terms));
        TextView provide_feedback_txt = ((TextView) view.findViewById(R.id.provide_feedback_button));
        LinearLayout fico_footer_parent_layout = ((LinearLayout) view.findViewById(R.id.fico_footer_parent_layout));
        tvScoresTerms.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_terms)));
        tvScoresFaq.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_scores_faq)));
        privacyProvideFooterLayout = ((LinearLayout) view.findViewById(R.id.privacyProvideFooterLayout));

        tvScoresFaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCmnFicoCreditScoreMasterFragment.handleNoScoreFicoFAQClick();
            }
        });

        tvScoresTermsDescription.setText(CommonUtils.getHtmlFormattedText(mContext.getString(R.string.cmn_fico_score_decription)));


        /*Defect fixed: 13273*/
        showPhoneWebUrlLink(tvScoresTermsDescription);
        privacy_terms_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCmnFicoCreditScoreMasterFragment.handlePrivacyAndTermsClick();
            }
        });
        provide_feedback_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCmnFicoCreditScoreMasterFragment.handleProvideFeedbackClick();
            }
        });
    }
}
