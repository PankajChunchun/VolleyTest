package com.discover.mobile.common.services;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.network.error.bean.ErrorResponseDetails;

/**
 * Created by skrish1 on 7/15/2016.
 */
public class RAFErrorDetails extends ErrorResponseDetails {

    @SerializedName("unique_id")
    private String uniqueId;

    @SerializedName("http_status_code")
    private String httpStatusCode;

    /*@SerializedName("message")
    private String message;*/

    @SerializedName("code")
    private String code;

    @SerializedName("parameters")
    private Parameters parameters;

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(String httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Parameters getParameters() {
        return parameters;
    }

    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }


}
