package com.discover.mobile.common.onboardwiz.utils;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * This holds the paperless & customer information to display on the onBoarding wizard
 * *
 */
public class BankOnBoardingInfo implements Serializable {

    //Customer email address
    //This will use in paperless setup screen
    public String mEmail;
    //Name of the Customer
    //This will use in paperless landing page
    public String mFormattedName;
    //Boolean to check whether user has checking account or not
    //This will use in paperless setup screen to show different message for customer with checking
    // and any other account with paperless statements.
    public boolean mHasCheckingAccounts;

    //List of all paperless account
    public ArrayList<PaperlessDetails> mPaperlessAccountlist = null;

    //paperless enable  modal content url
    public String mPaperlessEnableWebview;

    //paperless disable  modal content url
    public String mPaperlessDisableWebview;


    //child class storing all details for account with paperless feature
    public class PaperlessDetails {
        //Customer Account Nickname
        public String mAccountNickName;
        //Customer Account ending 4-digits value
        public String mAccEnding;
        //Customer Account Id
        public String mAccountId;
        //Paperless state either ON or OFF
        public boolean mPaperlessState;
    }

}