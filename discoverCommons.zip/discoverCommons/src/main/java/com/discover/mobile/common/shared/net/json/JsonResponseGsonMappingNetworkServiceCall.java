package com.discover.mobile.common.shared.net.json;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import com.discover.mobile.common.shared.net.NetworkServiceCall;
import com.discover.mobile.common.shared.net.ServiceCallParams;
import com.discover.mobile.common.shared.utils.CommonUtils;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import java.util.Map;

/**
 * A {@link NetworkServiceCall} that handles mapping of JSON requests and responses.
 *
 * @param <M> The <u>m</u>odel type for the JSON result
 */
public abstract class JsonResponseGsonMappingNetworkServiceCall<M> extends NetworkServiceCall<M> {

    private static final String TAG = JsonResponseGsonMappingNetworkServiceCall.class.getSimpleName();

    private final Class<M> modelClass;

    /**
     * Holds information that is used to communicate between the caller sending the request and
     * handler handling the response
     */
    private final Bundle extras;

    /**
     * JSON mapping service call used with the base url defaulted to card.
     */
    protected JsonResponseGsonMappingNetworkServiceCall(final Context context, final ServiceCallParams params,
                                                        final Class<M> modelClass) {
        super(context, params);
        CommonUtils.checkNotNull(modelClass, "modelClass cannot be null");

        extras = new Bundle();
        this.modelClass = modelClass;
        Log.d(TAG, modelClass.toString());
    }

    /**
     * JSON mapping service call used with the base url defaulted to card.
     */
    protected JsonResponseGsonMappingNetworkServiceCall(final Context context, final ServiceCallParams params,
                                                        final Class<M> modelClass, final String url) {
        super(context, params, url);
        CommonUtils.checkNotNull(modelClass, "modelClass cannot be null");

        extras = new Bundle();
        this.modelClass = modelClass;
        Log.d(TAG, modelClass.toString());
    }


    @Override
    protected M parseSuccessResponse(final int status,
                                     final Map<String, List<String>> headers, final InputStream body)
            throws IOException {
        //Gson gson = new GsonBuilder().serializeNulls().create();
        Gson gson = new GsonBuilder().create();
        Reader reader = new InputStreamReader(body);
        M dataReader = gson.fromJson(reader, modelClass);
        return dataReader;
        // return JacksonObjectMapperHolder.mapper.readValue(body, modelClass);
    }

    /** Method used to fetch the bundle of information stored in the service call. */
    public Bundle getExtras() {
        return extras;
    }

}
