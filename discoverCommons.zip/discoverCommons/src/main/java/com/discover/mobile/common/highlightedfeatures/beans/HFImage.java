package com.discover.mobile.common.highlightedfeatures.beans;

import com.google.gson.annotations.SerializedName;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Contains Image details {@link HFImageUrlContent} for Handset and Tablet.
 *
 * @author pkuma13
 */
public class HFImage implements Serializable, Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<HFImage> CREATOR = new Parcelable.Creator<HFImage>() {
        @Override
        public HFImage createFromParcel(Parcel in) {
            return new HFImage(in);
        }

        @Override
        public HFImage[] newArray(int size) {
            return new HFImage[size];
        }
    };
    @SerializedName("Tablet")
    private HFImageUrlContent tablet;
    @SerializedName("Handset")
    private HFImageUrlContent handset;

    // ***********************************************************
    // ******* PARCELABLE Codes starts
    // ***********************************************************
    protected HFImage(Parcel in) {
        tablet = (HFImageUrlContent) in.readValue(HFImageUrlContent.class.getClassLoader());
        handset = (HFImageUrlContent) in.readValue(HFImageUrlContent.class.getClassLoader());
    }

    public final HFImageUrlContent getTablet() {
        return tablet;
    }

    public final void setTablet(HFImageUrlContent tablet) {
        this.tablet = tablet;
    }

    public final HFImageUrlContent getHandset() {
        return handset;
    }

    public final void setHandset(HFImageUrlContent handset) {
        this.handset = handset;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(tablet);
        dest.writeValue(handset);
    }
    // ***********************************************************
    // ******* PARCELABLE Codes end
    // ***********************************************************
}