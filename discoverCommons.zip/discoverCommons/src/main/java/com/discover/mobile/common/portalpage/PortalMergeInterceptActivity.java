package com.discover.mobile.common.portalpage;

import com.discover.mobile.common.R;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.net.cookie.BankSessionCookieManager;
import com.discover.mobile.common.net.cookie.CookieManagerProxy;
import com.discover.mobile.common.net.cookie.SessionCookieManager;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.service.PortalPageServiceClass;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalConstants;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

/**
 * Account Eligible Intercept page, to start card merge flow
 * Added for CLA merge on client side
 */
public class PortalMergeInterceptActivity extends ActionBarBaseActivity implements OnClickListener {

    private static final String TAG = PortalMergeInterceptActivity.class.getSimpleName();
    private TextView mergeTitleTv, mMergeTitleTv2, mMergeTitleTv3;
    private Button getStartedBtn, skipNowBtn;
    private TextView terms;
    private TextView feedback;
    private boolean isInitialSkipAttempt;

    private Bundle extras;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if(com.discover.mobile.common.Utils.checkPermissionTampering(this)){
            return;
        }
        setContentView(R.layout.portal_merge_intercept_page);
        setLogoInCenter();

        DiscoverActivityManager.setActiveActivity(this);

        initUIComponents();
        setListeners();

    }

    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }

    private void initUIComponents() {

        mergeTitleTv = (TextView) findViewById(R.id.merge_intercept_title);
        getStartedBtn = (Button) findViewById(R.id.merge_intercept_get_started_button);
        skipNowBtn = (Button) findViewById(R.id.merge_intercept_skip_button);
        terms = (TextView) findViewById(R.id.privacy_terms);
        feedback = (TextView) findViewById(R.id.provide_feedback_button);
        mMergeTitleTv2 = (TextView) findViewById(R.id.merge_intercept_title_2);
        mMergeTitleTv3 = (TextView) findViewById(R.id.merge_intercept_title_3);

        extras = getIntent().getExtras();
        if(null!=extras) {
            String customerFName = extras.getString(PortalConstants.Misc.CLA_MERGE_CUSTOMER_FIRSTNAME);
            Boolean isForceMerge = extras.getBoolean(PortalConstants.Misc.CLA_MERGE_ISFORCEMERGE);
            isInitialSkipAttempt = extras.getBoolean(PortalConstants.Misc.CLA_MERGE_ISINITIAL_SKIPATTEMPT, true);
            mergeTitleTv.setText(String.format(getResources().getString(R.string.merge_flow_title), toDisplayFirstName(customerFName)));
            mergeTitleTv.setContentDescription(mergeTitleTv.getText().toString());
            if (isForceMerge) {
                skipNowBtn.setVisibility(View.GONE);
            } else if (! isInitialSkipAttempt) {
                // US126324 - SSO eligible intercept changes - start
                skipNowBtn.setText(getResources().getString(R.string.merge_flow_no_thankyou_lbl));
                // mMergeTitleTv2.setText(getResources().getString(R.string.merge_flow_no_thankyou_message));
                // mMergeTitleTv3.setText(getResources().getString(R.string.merge_flow_no_thankyou_to_do));
                // US126324 - SSO eligible intercept changes - end
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        DiscoverActivityManager.setActiveActivity(this);
    }

    private void setListeners() {
        getStartedBtn.setOnClickListener(this);
        skipNowBtn.setOnClickListener(this);
        terms.setOnClickListener(this);
        feedback.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        // click on get started button
        if (view.getId() == R.id.merge_intercept_get_started_button) {
            /**Added the method to invoke BBRedirect page for US47049*/
            invokeBBRedirectFramework();
        }

        // click on skip button
        else if (view.getId() == R.id.merge_intercept_skip_button) {
            if (((Button)view).getText().toString().equalsIgnoreCase(getResources()
                    .getString(R.string.merge_flow_no_thankyou_lbl))) {
                // Do not show modal. Goto home page
                skipMergeInterceptCall();
                navigateToHomeScreenOrPortalPage();
            } else {
                showSkipForNowModal();
            }
        }

        // click on privacy and terms
        else if (view.getId() == R.id.privacy_terms) {
            //code for bank  selected privacy &terms
            if (Globals.isBankLoginSelected()) {
                FacadeFactory.getBankLoginFacade().openPrivacyAndTerms();
            } else {
                FacadeFactory.getCardFacade().navToPrivacyTerms(
                        PortalMergeInterceptActivity.this);
            }

        }

        // click on feedback
        else if (view.getId() == R.id.provide_feedback_button) {

            if (Globals.isBankLoginSelected()) {
                FacadeFactory.getBankLoginFacade().navigateToFeedback();
            } else {
                FacadeFactory.getCardFacade().navToProvideFeedback(
                        PortalMergeInterceptActivity.this);
            }
        }

    }

    /*
    This will display modal for skip for now functionality.
     */
    private void showSkipForNowModal() {
        String title = null;
        String message = null;

        title = InfoMessageUtils.Instance().getErrorMessage(PortalUtils.CLA_MERGE_SKIP_FOR_NOW_MODAL_TITLE);
        if (TextUtils.isEmpty(title)) {
            title = getString(R.string.merge_later_alert_title);
        }

        message = InfoMessageUtils.Instance().getErrorMessage(PortalUtils.CLA_MERGE_SKIP_FOR_NOW_MODAL_MESSAGE);
        if (TextUtils.isEmpty(message)) {
            message = getString(R.string.merge_later_alert_title_desc);
        }

        final DiscoverAlertDialog skipNowAlertDialog = new DiscoverAlertDialog().
                setTitle(title).
                setMessage(message).
                setPositiveButton(getString(R.string.merge_later_alert_button1), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        skipMergeInterceptCall();
                        navigateToHomeScreenOrPortalPage();
                    }
                }).
                setNegativeButton(getString(R.string.merge_later_alert_button2), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        invokeBBRedirectFramework();
                    }
                }).
                setCanCancelable(false).
                show(PortalMergeInterceptActivity.this);
    }

    /*
    #US38224
    This method calls to skip user authentication for now.
     */
    private void skipMergeInterceptCall() {
        NetworkRequestListener networkRequestListener = new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {

            }

            @Override
            public void onError(Object data) {

            }
        };

        PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(PortalMergeInterceptActivity.this);
        portalPageServiceClass.skipMergeIntercept(networkRequestListener);
    }


    private void invokeBBRedirectFramework() {
        /**Added this method for US47049*/
        // defect Fix:  321 & 264 Delete all bank cookie and cardside PMdata cookie.
        SessionCookieManager coockieManager = SessionCookieManager.getInstance();
        CookieManagerProxy cookieManagerProxy = (CookieManagerProxy) coockieManager.getCookieManager();
        cookieManagerProxy.clearAllCookies();

        FacadeFactory.getCardFacade().invokeBBRedirect(PortalMergeInterceptActivity.this, PortalConstants.Misc.LINKTO_CLA_MERGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    private class ModuleExitHandler implements NetworkRequestListener {
        Runnable exitAction;
        private Context ctx;

        public ModuleExitHandler(Runnable exitAction, Context ctx) {

            this.exitAction = exitAction;
            this.ctx = ctx;
        }

        @Override
        public void onError(Object data) {

            if (exitAction != null)
                exitAction.run();
        }

        @Override
        public void onSuccess(Object data) {

            if (exitAction != null)
                exitAction.run();

        }

    }

    @Override
    public void onBackPressed() {
        // disable back button functionality as per the requirement of #US38224
        //navigating either to Account Home Summary screen or Portal page
        //navigateToHomeScreenOrPortalPage();

    }

    public void navigateToHomeScreenOrPortalPage() {

        // if bank Login is selected user should navigate to Home page
        if (Globals.isBankLoginSelected()) {
            BankSessionCookieManager.getInstance(DiscoverActivityManager.getActiveActivity()).clearAllCookie();
            FacadeFactory.getBankLoginFacade().navigateToBankHomePage();
        } else {
            final AccountV2Details portalAccountDetails = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();

            if (PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getIfPortalPageShown()) {
                PortalUtils.navToPortalActivity();
            } else {
                Activity activity = DiscoverActivityManager.getActiveActivity();
                String key = (String) portalAccountDetails.getCardAccountsMap().keySet().toArray()[0];
                PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setSelectedAccKey(key);
                FacadeFactory.getPortalPageFacade().navToCardHome(activity, key);
            }
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        setContentView(R.layout.portal_merge_intercept_page);
        setLogoInCenter();

        DiscoverActivityManager.setActiveActivity(this);

        initUIComponents();
        setListeners();
    }

    private String toDisplayFirstName(String s) {

        if (s == null) {
            return "";
        }

        s = s.trim();
        StringBuilder sb = new StringBuilder();
        boolean capNext = true;

        for (char c : s.toCharArray()) {
            c = (capNext)
                    ? Character.toUpperCase(c)
                    : Character.toLowerCase(c);
            sb.append(c);
            capNext = false;
        }
        return sb.toString();
    }
}
