package com.discover.mobile.common.fico.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Tip implements Serializable {
    private static final long serialVersionUID = 419682316665845456L;

    @SerializedName("message")
    private String message;

    @SerializedName("efftDate")
    private String efftDate;

    @SerializedName("key")
    private String key;

    @SerializedName("code")
    private String code;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getEfftDate() {
        return efftDate;
    }

    public void setEfftDate(String efftDate) {
        this.efftDate = efftDate;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
