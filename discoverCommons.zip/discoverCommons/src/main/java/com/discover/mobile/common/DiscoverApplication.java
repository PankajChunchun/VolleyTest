package com.discover.mobile.common;

import com.apiguard.AGCallbackInterface;
import com.apiguard.APIGuard;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.TokenUtil;
import com.discover.mobile.common.threatmatrix.ThreatMatrixSingleton;
import com.liveperson.mobile.android.service.ApplicationLifecycleHandler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.support.multidex.MultiDex;

import java.io.IOException;
import java.security.cert.Certificate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressLint("NewApi")
public class DiscoverApplication extends Application implements AGCallbackInterface {

    public static boolean logoutErrorMessage = false;
    public static boolean isInQuickViewMode = false; // to maintain quickview
    /**
     * The cache object that maintains the most recent user's choice to use
     * current location
     */
    private static LocationPreferenceCache locationPreference = new LocationPreferenceCache();
    private static Context context; // fix crash log

    static {
        System.setProperty("guice.custom.loader", "false");
    }

    public boolean loginToCardFromRegisterFlow = false;
    public boolean loginKeyBoardStateVisible = false;
    Map<String, Object> globalData = new HashMap<String, Object>();
    List<String> cookie;
    //quickview widget properties
    String mEncryptedBankToken = null;
    String mBankToken = null;
    boolean mIsRunningOnHandset = false;
    Intent quickViewIntent = null;
    private boolean isShowAnimation = false;
    private int focusedView = -1;

    /**
     * @return a reference to the current locationPreference object for this
     * instance of the application. Used for caching user settings for
     * the ATM Locator, use my location modal.
     */
    public static final LocationPreferenceCache getLocationPreference() {
        if (locationPreference == null) {
            locationPreference = new LocationPreferenceCache();
        }

        return locationPreference;
    }
    // page visible state

    // fix crash log
    public static Context getGlobalContext() {
        return context;
    }

    // fix crash log
    public static void setGlobalContext(Context externalContext) {
        context = externalContext;
    }

    public boolean isShowAnimation() {
        return isShowAnimation;
    }

    public void setShowAnimation(boolean isShowAnimation) {
        this.isShowAnimation = isShowAnimation;
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @SuppressLint("NewApi")
    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();// fix crash log
        // Update the user preferences if it is needed.
        Globals.updateVersionPrefsIfNeeded(this);

        isShowAnimation = true;
        String baseURL = FacadeFactory.getCardFacade().getCardBaseUrl();
        String prodUrl = FacadeFactory.getCardFacade().getCardProdUrl();

        /** Live person changes akamble */
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            // Register to the ActivityLifecycleCallbacks in order to support
            // notifications
            registerActivityLifecycleCallbacks(new ApplicationLifecycleHandler() {
                @Override
                public void onActivityCreated(Activity a,
                                              Bundle savedInstanceState) {

                    //Catch the exception to make sure our Discover app is not crashing in case issue with
                    //APIGuard(SHAPE SDK)
                    try{
                        initApiGuard();
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                    super.onActivityCreated(a, savedInstanceState);
                }
                @Override
                public void onActivityStarted(Activity a) {
                    super.onActivityStarted(a);
                }
                @Override
                public void onActivityResumed(Activity a) {
                    super.onActivityResumed(a);
                }
                @Override
                public void onActivityPaused(Activity a) {
                    super.onActivityPaused(a);
                }
                @Override
                public void onActivityStopped(Activity a) {
                    super.onActivityStopped(a);
                }
                @Override
                public void onActivitySaveInstanceState(Activity a,
                                                        Bundle outState) {
                    super.onActivitySaveInstanceState(a, outState);
                }
                @Override
                public void onActivityDestroyed(Activity a) {
                    super.onActivityDestroyed(a);
                }
            });
        }
        /** Lib changes ends */
        // Start-15.4 Updated for threat matrix- rsharm9
        // This will initialize the threat matrix
        ThreatMatrixSingleton.Instance().init(getApplicationContext());
        // End-15.4 Updated for threat matrix- rsharm9

        // Added for US34562 - rjagdal
       /* if (!(baseURL.equalsIgnoreCase(prodUrl))) {
            // Setup handler for uncaught exceptions.
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread thread, Throwable e) {
                    handleUncaughtException(thread, e);

                }
            });
        }*/

    }

    /**
     * Set the data in the hashmap
     *
     * @param className class name where data is located
     * @param data      actual data returned from webservice
     */
    public void setData(final String className, final Object data) {
        globalData.put(className, data);
    }

    /**
     * Thsi method return the data stored in hashmap
     *
     * @return data Actual data
     */
    public Map<String, Object> getData() {
        return globalData;

    }

    /**
     * This function clear whole cache.
     */
    public void clearCache() {
        if (globalData != null) {
            Object object = globalData.get(context.getResources().getString(
                    R.string.json_file_error_key));// avoid clearing json error
            // object.

            globalData.clear();

            setData("error", object);
        }
    }

    /**
     * This will delete cache object by sending key
     */
    public void deleteCacheObject(final String key) {
        if (globalData != null) {
            globalData.remove(key);
        }
    }

    public List<String> getCookie() {
        return cookie;
    }

    public void setCookie(final List<String> cookie) {
        this.cookie = cookie;
    }

    // fix crash log

    public final int getFocusedView() {
        return focusedView;
    }

    public final void setFocusedView(int focusedView) {
        this.focusedView = focusedView;
    }

    public final void resetFocusedView() {
        this.focusedView = -1;
    }

    public boolean isLoginToCardFromRegisterFlow() {
        return loginToCardFromRegisterFlow;
    }

    public void setLoginToCardFromRegisterFlow(
            boolean loginToCardFromRegisterFlow) {
        this.loginToCardFromRegisterFlow = loginToCardFromRegisterFlow;
    }

    public boolean isLoginKeyBoardStateVisible() {
        return loginKeyBoardStateVisible;
    }

    public void setLoginKeyBoardStateVisible(boolean loginKeyBoardStateVisible) {
        this.loginKeyBoardStateVisible = loginKeyBoardStateVisible;
    }

    /**
     * Method to handle uncaught exception - by sending crash log through mail
     */
    public void handleUncaughtException(Thread thread, Throwable e) {
        e.printStackTrace();
        String logTxt = prepareLog(e);
        Intent intent = new Intent(getApplicationContext(), SendLog.class);
        intent.setType("text/html");

        Bundle b = new Bundle();
        b.putString("CrashLogData", logTxt);
        intent.putExtras(b);

        intent.setAction("com.discover.mobile.common.SendLog");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // required when
        // starting from
        // Application
        startActivity(intent);

        System.exit(2); // kill off the crashed app

    }

    /**
     * Method for formatting crash log to be readable
     *
     * @return crashReport
     */
    private String prepareLog(Throwable e) {

        StackTraceElement[] arr = e.getStackTrace();
        String report = "";
        report += "--------- Device Information ---------\n\n";

        report += getDeviceInfo();

        report += "--------- Crash Reason ---------\n\n";
        report += e.toString() + "\n\n";

        report += "--------- Stack trace ---------\n\n";

        for (StackTraceElement i : arr) {
            report += "    " + i.toString() + "\n";
        }

        report += "\n\n-------------------------------\n\n";

        // If the exception was thrown in a background thread inside
        // AsyncTask, then the actual exception can be found with getCause

        Throwable cause = e.getCause();
        if (cause != null) {
            report += cause.toString() + "\n\n";
            arr = cause.getStackTrace();
            report += "--------- Cause ---------\n\n";

            for (StackTraceElement i : arr) {
                report += "    " + i.toString() + "\n";
            }

            report += "-------------------------------\n\n";
        }

        return report;
    }

    /**
     * Method to extract device information for sending crash report with
     * details
     *
     * @return deviceInfo - device information
     */
    private String getDeviceInfo() {
        String deviceInfo;
        String android_Version = "Android version: " + Build.VERSION.RELEASE
                + "\n";
        String model = Build.MODEL;
        if (!model.startsWith(Build.MANUFACTURER))
            model = Build.MANUFACTURER + " " + model;
        PackageManager manager = this.getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(this.getPackageName(), 0);
        } catch (NameNotFoundException e2) {
        }

        String model_Info = "Device: " + model + "\n";
        String App_ver = "App version: "
                + (info == null ? "(null)" : info.versionName) + "\n";

        deviceInfo = android_Version + "\n" + model_Info + "\n" + App_ver
                + "\n\n";

        return deviceInfo;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        //This has been added to recreate the quickview widget while changing the orientation.
        try {
            mIsRunningOnHandset = Utils.isRunningOnHandset(context);

            if (!mIsRunningOnHandset) {
                mEncryptedBankToken = null;
                mBankToken = null;

                mEncryptedBankToken = FacadeFactory.getCardLoginFacade().getQuickViewToken(context);
                if(mEncryptedBankToken!=null)
                    mBankToken = TokenUtil.parseAndDecryptToken(context, mEncryptedBankToken);

                if (FacadeFactory.getCardLoginFacade() != null && mBankToken != null) {

                    // create intent to update all instances of the widget
                    quickViewIntent = new Intent("com.discover.mobile.bank.QuickViewOrientationChanged", null, this, FacadeFactory.getCardLoginFacade().getWidgetProvider());

                    // update the widget
                    sendBroadcast(quickViewIntent);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            mEncryptedBankToken = null;
            mBankToken = null;
            mIsRunningOnHandset = false;
            quickViewIntent = null;

        }
    }

    @Override
    public void reauthenticate() {

    }

    @Override
    public void checkCertificates(List<Certificate> list, String s) throws IOException {

    }

    @Override
    public void logAGMessage(String s) {

    }

    static APIGuard apiGuard = new APIGuard();
    // Create getter for the API Guard Instance
    public static APIGuard getAPIGuard() {
        return apiGuard;
    }
    // Initialize API Guard instance with a set of properties
    private void initApiGuard() {
        Map<String, Object> agProperties = new HashMap<>();
        agProperties.put(APIGuard.INTEGRITY_CHECK_URL,
                "https://mapi.discovercard.com/v1/native-app/initialize  ");
        agProperties.put(APIGuard.GUARDED_DOMAINS,
                new String[]{"mapi.discovercard.com", ".mapi.discovercard.com", "mapi.discoverbank.com", ".mapi.discoverbank.com"});

        // Update interval, in seconds, between visitor legitimacy
        // assessments (4 hours).
        agProperties.put(APIGuard.UPDATE_INTERVAL, 14400);
        // Lifetime, in seconds, of VASB cache entry (14 days)
        agProperties.put(APIGuard.KEY_CACHE_TTL, 1209600);
        // Configuration key provided by Shape Security.
        String shapeAIDKey =  getResources().getString(R.string.shape_security_key);
        agProperties.put(APIGuard.AID, shapeAIDKey);
        apiGuard.initializeWithProperties(this, agProperties, this);
    }
}
