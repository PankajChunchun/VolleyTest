package com.discover.mobile.common.productpage.beans;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProductsContent implements Serializable {

    private static final long serialVersionUID = 2053266991172619426L;
    @SerializedName("categories")
    @Expose
    private List<ProductsCategory> categories = new ArrayList<ProductsCategory>();

    public List<ProductsCategory> getCategories() {
        return categories;
    }

    public void setCategories(List<ProductsCategory> categories) {
        this.categories = categories;
    }
}