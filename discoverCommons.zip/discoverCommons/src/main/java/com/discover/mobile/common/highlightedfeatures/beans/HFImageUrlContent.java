package com.discover.mobile.common.highlightedfeatures.beans;

import com.google.gson.annotations.SerializedName;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Details of a Highlighted feature image.
 *
 * @author pkuma13
 */
public class HFImageUrlContent implements Serializable, Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<HFImageUrlContent> CREATOR = new Parcelable.Creator<HFImageUrlContent>() {
        @Override
        public HFImageUrlContent createFromParcel(Parcel in) {
            return new HFImageUrlContent(in);
        }

        @Override
        public HFImageUrlContent[] newArray(int size) {
            return new HFImageUrlContent[size];
        }
    };
    @SerializedName("Name")
    private String name;
    @SerializedName("Orientations")
    private ArrayList<String> orientations;
    @SerializedName("Densities")
    private ArrayList<String> densities;
    @SerializedName("BaseUrl")
    private String baseUrl;

    // ***********************************************************
    // ******* PARCELABLE Codes starts
    // ***********************************************************
    protected HFImageUrlContent(Parcel in) {
        name = in.readString();
        if (in.readByte() == 0x01) {
            orientations = new ArrayList<String>();
            in.readList(orientations, String.class.getClassLoader());
        } else {
            orientations = null;
        }
        if (in.readByte() == 0x01) {
            densities = new ArrayList<String>();
            in.readList(densities, String.class.getClassLoader());
        } else {
            densities = null;
        }
        baseUrl = in.readString();
    }

    public final String getName() {
        return name;
    }

    public final void setName(String name) {
        this.name = name;
    }

    public final ArrayList<String> getOrientations() {
        return orientations;
    }

    public final void setOrientations(ArrayList<String> orientations) {
        this.orientations = orientations;
    }

    public final ArrayList<String> getDensities() {
        return densities;
    }

    public final void setDensities(ArrayList<String> densities) {
        this.densities = densities;
    }

    public final String getBaseUrl() {
        return baseUrl;
    }

    public final void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        if (orientations == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(orientations);
        }
        if (densities == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(densities);
        }
        dest.writeString(baseUrl);
    }
    // ***********************************************************
    // ******* PARCELABLE Codes end
    // ***********************************************************
}
