package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class IraPlan implements Serializable, PortalBoxInterface {

    private static final long serialVersionUID = 4622340045540593102L;
    private final static String ACC_IRA = "ACC_IRA | ";

    @SerializedName("index")
    private Integer index;

    @SerializedName("totalInterestYearToDate")
    private String totalInterestYearToDate;

    @SerializedName("totalCurrentBalance")
    private String totalCurrentBalance;

    @SerializedName("totalAvailableBalance")
    private String totalAvailableBalance;

    @SerializedName("acctNickName")
    private String acctNickName;

    @SerializedName("iraTypeCode")
    private String iraTypeCode;

    @SerializedName("iraAccounts")
    private List<IraAccount> iraAccounts = new ArrayList<IraAccount>();

    @SerializedName("isVerified")
    private Boolean isVerified;

    public String getTotalAvailableBalance() {
        return totalAvailableBalance;
    }

    public void setTotalAvailableBalance(String totalAvailableBalance) {
        this.totalAvailableBalance = totalAvailableBalance;
    }

    /**
     * @return The index
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * @param index The index
     */
    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * @return The totalInterestYearToDate
     */
    public String getTotalInterestYearToDate() {
        return totalInterestYearToDate;
    }

    /**
     * @param totalInterestYearToDate The totalInterestYearToDate
     */
    public void setTotalInterestYearToDate(String totalInterestYearToDate) {
        this.totalInterestYearToDate = totalInterestYearToDate;
    }

    /**
     * @return The totalCurrentBalance
     */
    public String getTotalCurrentBalance() {
        return totalCurrentBalance;
    }

    /**
     * @param totalCurrentBalance The totalCurrentBalance
     */
    public void setTotalCurrentBalance(String totalCurrentBalance) {
        this.totalCurrentBalance = totalCurrentBalance;
    }

    /**
     * @return The acctNickName
     */
    public String getAcctNickName() {
        return acctNickName;
    }

    /**
     * @param acctNickName The acctNickName
     */
    public void setAcctNickName(String acctNickName) {
        this.acctNickName = acctNickName;
    }

    /**
     * @return The iraTypeCode
     */
    public String getIraTypeCode() {
        return iraTypeCode;
    }

    /**
     * @param iraTypeCode The iraTypeCode
     */
    public void setIraTypeCode(String iraTypeCode) {
        this.iraTypeCode = iraTypeCode;
    }

    /**
     * @return The iraAccounts
     */
    public List<IraAccount> getIraAccounts() {
        return iraAccounts;
    }

    /**
     * @param iraAccounts The iraAccounts
     */
    public void setIraAccounts(List<IraAccount> iraAccounts) {
        this.iraAccounts = iraAccounts;
    }

    /**
     *
     * @return
     */
    public Boolean getIsVerified() {
        return isVerified;
    }

    /**
     *
     * @param isVerified
     */
    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    @Override
    public String getSortId() {
        return this.index != -1 ? this.ACC_IRA.concat(String.valueOf(this.index)) : null;
    }
}
