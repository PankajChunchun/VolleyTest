package com.discover.mobile.common.help;

import com.discover.mobile.common.BaseFragment;
import com.discover.mobile.common.R;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;

//import com.actionbarsherlock.view.MenuItem;

@SuppressLint("ValidFragment")
public class CustomerServiceMenuFragment extends BaseFragment implements
        OnClickListener {
    private static final String TAG = CustomerServiceMenuFragment.class
            .getSimpleName();

    private static final String SHOW_HIGHLIGHTED = "SHOW_HIGHLIGHTED";

    private boolean cardMode;
    private boolean showHighlightedFeatures = false;

    public CustomerServiceMenuFragment() {

    }

    public CustomerServiceMenuFragment(boolean showHighlightedFeatures) {
        this.showHighlightedFeatures = showHighlightedFeatures;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //activity.getActionBar().setDisplayHomeAsUpEnabled(true);
        if (showHighlightedFeatures == false && savedInstanceState != null) {
            showHighlightedFeatures = savedInstanceState.getBoolean(
                    SHOW_HIGHLIGHTED, false);
        }

        Bundle arguments = getArguments();
        if (arguments != null) {
            cardMode = arguments.getBoolean("IS_CARD_SELECTED");
        }

        View mainView = inflater.inflate(R.layout.help_menu_layout,
                null);

        if (!showHighlightedFeatures) {
            mainView.findViewById(R.id.customer_service_menu_features)
                    .setVisibility(View.GONE);
            mainView.findViewById(R.id.customer_service_menu_features_divider)
                    .setVisibility(View.GONE);
        }

        setupMenu(mainView);

        return mainView;

    }

    // All menu items will be handled by a single listener
    private void setupMenu(View view) {
        LinearLayout menu = (LinearLayout) view
                .findViewById(R.id.customer_service_menu_list);
        for (int i = 0; i < menu.getChildCount(); i++) {
            menu.getChildAt(i).setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {/*
        int id = v.getId();
		if (id == R.id.customer_service_register_now) {
			final Activity currentActivity = DiscoverActivityManager
					.getActiveActivity();
			FacadeFactory.getCardFacade().navToRegister(
					(BaseFragmentActivity) currentActivity);
		} else if (id == R.id.customer_service_menu_features) {
			final Activity currentActivity = DiscoverActivityManager
					.getActiveActivity();
			TrackingHelper.trackCardPageProp1(AnalyticsPage.HF_CS_MENU_CLICK,
					AnalyticsPage.HF_CS_MENU_CLICK);
			FacadeFactory.getHighlightedFeaturesFacade()
					.getPreloginHighlightedFeaturesFragment(currentActivity,
							new NetworkRequestListener() {
								@Override
								public void onSuccess(Object data) {
									Fragment fragment = (Fragment) data;
									((NavigationRootActivity) currentActivity)
											.makeFragmentVisible(fragment);
								}

								@Override
								public void onError(Object data) {
									// TODO Show an error message here.
								}
							});

		}*/

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putBoolean(SHOW_HIGHLIGHTED, showHighlightedFeatures);
    }

    @Override
    public int getActionBarTitle() {
        return R.string.customer_service_menu_help_title;
    }

    @Override
    public int getGroupMenuLocation() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int getSectionMenuLocation() {
        // TODO Auto-generated method stub
        return 0;
    }

    public void setCardMode(final boolean isCard) {
        cardMode = isCard;
    }

	/*
	 * @Override public boolean onOptionsItemSelected(MenuItem item) { switch
	 * (item.getItemId()) { // Respond to the action bar's Up/Home button case
	 * android.R.id.home: finish(); return true; } return
	 * super.onOptionsItemSelected(item); }
	 */
}
