package com.discover.mobile.common.shared.utils;

import java.util.List;

/**
 * Class used to store constants used throughout the app related to String building and comparison.
 * Helps to prevent repeated static instances of commonly used String values.
 *
 * @author allie
 */
public final class StringUtility {

    public static final String EMPTY = "";
    public static final String SPACE = " ";
    public static final String ENCODED_SPACE = "%20";
    public static final String COMMA = ",";
    public static final String NEW_LINE = "\n";
    public static final String NON_NUMBER_CHARACTERS = "[^0-9]";
    public static final String DASH = "-";
    public static final String UNDERSCORE = "_";
    public static final String HASH = "#";
    public static final String QUESTION_MARK = "?";
    public static final String SLASH = "/";
    public static final String PERIOD = ".";
    public static final String COLON = ":";
    public static final String PLUS = "+";
    public static final String BOLD_START = "<b>";
    public static final String BOLD_END = "</b>";
    public static final String DOLLAR_SIGN = "$";
    public static final String LEFT_PARENTHESIS = "(";
    public static final String RIGHT_PARENTHESIS = ")";
    public static final String ELLIPSIS = "...";
    public static final String LEFT_ANGULAR_BRACKET = "<";
    public static final String RIGHT_ANGULAR_BRACKET = ">";
    /* Common String patterns to use for Class Pattern. */
    public static final String PATTERN_DIGIT = "[0-9]";
    public static final String PATTERN_LETTER = "[a-zA-Z]";

    public static final String HTML_MIME_TYPE = "text/html";
    public static final String UTF8_ENCODING = "UTF-8";

    public static final String SERVER_DATE_FORMAT = "yyyy-MM-dd'T'hh:mm:ssZ";
    public static final String SERVER_BILL_DUE_DATE_FORMAT = "EEE MMM d HH:mm:ss z yyyy";
    public static final String SERVER_LOANS_DATE_FORMAT = "yyyy-MM-dd'T'hh:mm:ssZ";
    public static final String BASIC_DATE_FORMAT = "MM/dd/yy";
    public static final String BASIC_DATE_FORMAT_FULL = "MM/dd/yyyy";
    public static final String YEAR_FIRST_DATE_FORMAT = "yyyy-MM-dd";

    public static final String SMC_DATE_FORMAT = "MMMM d yyyy";
    public static final String SMC_HOUR_FORMAT = "h:mm aa";

    public static final String DATETIME_DELIMITER = "T";

    public static final String US_EASTERN = "US/Eastern";

    /** Network Service Constants */
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";

    private StringUtility() {
        throw new AssertionError();
    }

    public static String join(List<String> list, String delimeter) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (String item : list) {
            if (first) {
                first = false;
            } else {
                sb.append(delimeter);
            }
            sb.append(item);
        }
        return sb.toString();
    }



}
