package com.discover.mobile.common;

import com.discover.mobile.common.analytics.TrackingHelper;

import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * Created by 388402 on 6/2/2016.
 * US57423
 */
public abstract class BaseChildFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         /* US59153 : set last valid page name which will be used for error enhanced modal*/
        TrackingHelper.currentPageName = null;
    }

}
