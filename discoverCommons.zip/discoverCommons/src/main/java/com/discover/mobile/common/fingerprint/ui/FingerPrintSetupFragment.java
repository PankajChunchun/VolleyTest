package com.discover.mobile.common.fingerprint.ui;


import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.interfaces.FingerprintSetUpInterface;
import com.discover.mobile.common.fingerprint.interfaces.FingerprintUIInterface;
import com.discover.mobile.common.fingerprint.utils.FingerPrintConstants;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.onboardwiz.utils.BannerMessage;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.shared.utils.StringUtility;
import com.discover.mobile.common.shared.utils.TokenUtil;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.common.ui.widgets.PasscodeCircularEditText;
import com.discover.mobile.common.uiwidget.CmnSwitch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.HashMap;

/** This class is added for the fingerprint for the US70151 */
public class FingerPrintSetupFragment extends Fragment implements View.OnKeyListener, FingerprintUIInterface {

    ViewGroup mainView = null;
    public static final int KEY_DELETE = 67;
    private FingerPrintUtils fingerPrintUtils;
    PasscodeUtils mPasscodeUtils;
    private CmnSwitch fingerPrintToggle;
    protected RelativeLayout enterPasscodeLayout, FOOTER, fingerprintRootView;
    protected PasscodeCircularEditText[] fieldTVs = new PasscodeCircularEditText[4];
    protected Context mContext;
    protected ImageView validationIV, helpIcon;
    private String deviceToken;
    private static final int[] fieldIds;
    private Bundle extras;
    TextView privacy_terms, provide_feedback_button, headerTitle;
    FingerprintSetupPresenter mFingerprintSetupPresenter;
    FingerprintSetUpInterface mFingerprintSetUpInterface;
    boolean isedited = false;
    LinearLayout bannerContainer;

    static {
        fieldIds = new int[4];
        fieldIds[0] = R.id.fingerprint_passcode01;
        fieldIds[1] = R.id.fingerprint_passcode02;
        fieldIds[2] = R.id.fingerprint_passcode03;
        fieldIds[3] = R.id.fingerprint_passcode04;
    }

    private BannerMessage bannerMessage;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(mContext)) {
            getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        }
        //Shared Preference needs to taken seperately for bank and card
        if (Globals.isBankLoginSelected) {
            mPasscodeUtils = new PasscodeUtils(getActivity().getApplicationContext(), false);
        } else {
            mPasscodeUtils = new PasscodeUtils(getActivity().getApplicationContext(), true);
        }
        fingerPrintUtils = new FingerPrintUtils(getActivity().getApplicationContext());
        this.mFingerprintSetupPresenter = new FingerprintSetupPresenterImpl(this, new FingerprintInteractorImpl(fingerPrintUtils, mFingerprintSetUpInterface));

        mainView = (ViewGroup) inflater.inflate(R.layout.finger_print_layout, null);
        //US78893-FingerPrint Login - Shrink Modal enable button handling-Start
        if (FacadeFactory.getBankLoginFacade() != null) {
            FacadeFactory.getBankLoginFacade().setDeeplinkValue(StringUtility.EMPTY);
        }
        //US78893-FingerPrint Login - Shrink Modal enable button handling-End
        //Setting the UI
        initUI();


        return mainView;
    }

    /**
     * This method check fingerprint status and enable/disable the toggle state as well as passcode
     * layout
     */
    private void setToggleState() {
        HashMap<String, Object> extras;
        //Start: US72282: FingerPrint Analytics
        if(Globals.isBankLoginSelected) {
             extras= FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
        }else {
            //End: US72282: FingerPrint Analytics
            /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
            //On the pageload, capture whether the finger print is On/Off in prop5 on the finger print landing page
             extras = new HashMap<String, Object>();
        }
        if (fingerPrintUtils.getFingerPrintStatus()) {
            fingerPrintToggle.setChecked(true);
            hidePasscodeLayout();
            if (!FingerPrintUtils.isCancelModelShow) {
                extras.put(AnalyticsPage.KEY_MY_PROP5, AnalyticsPage.FINGERPRINT_ON);
            }

        } else {
            fingerPrintToggle.setChecked(false);
            if (!FingerPrintUtils.isCancelModelShow) {
                extras.put(AnalyticsPage.KEY_MY_PROP5, AnalyticsPage.FINGERPRINT_OFF);
            }

        }
        //Start: US72282: FingerPrint Analytics
        if(Globals.isBankLoginSelected)

            TrackingHelper.trackBankPage(AnalyticsPage.FINGER_PRINT_PG,extras);
        else
        //End: US72282: FingerPrint Analytics
        TrackingHelper.trackCardPage(AnalyticsPage.FINGER_PRINT_PG, extras);
        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/

    }

    CompoundButton.OnCheckedChangeListener compoundButtonListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            if (fingerPrintToggle.isChecked()) {
                mFingerprintSetupPresenter.onToggleStateChange(true);
            } else {
                mFingerprintSetupPresenter.onToggleStateChange(false);
            }
        }
    };

    @Override
    public void onDetach() {
        super.onDetach();
        //Fix for defect#1546
        forceSoftKeyboardHidden();
        if (null != mFingerprintSetUpInterface)
            mFingerprintSetUpInterface.enableBackNavigationForFingerPrint(false);
    }

    private void initUI() {
        mContext = getActivity();
        final int fieldInt = 3;
        headerTitle = ((TextView) mainView.findViewById(R.id.header_title));
        if (Globals.isBankLoginSelected) {
            headerTitle.setVisibility(View.GONE);
        }
        fieldTVs[0] = (PasscodeCircularEditText) mainView.findViewById(R.id.fingerprint_passcode01);
        fieldTVs[1] = (PasscodeCircularEditText) mainView.findViewById(R.id.fingerprint_passcode02);
        fieldTVs[2] = (PasscodeCircularEditText) mainView.findViewById(R.id.fingerprint_passcode03);
        fieldTVs[3] = (PasscodeCircularEditText) mainView.findViewById(R.id.fingerprint_passcode04);
        enterPasscodeLayout = (RelativeLayout) mainView.findViewById(R.id.enter_passcode_layout);
        fingerPrintToggle = (CmnSwitch) mainView.findViewById(R.id.fingerprint_toggle);
        validationIV = ((ImageView) mainView.findViewById(R.id.validation));
        privacy_terms = ((TextView) mainView.findViewById(R.id.privacy_terms));
        provide_feedback_button = ((TextView) mainView.findViewById(R.id.provide_feedback_button));
        fingerprintRootView = (RelativeLayout) mainView.findViewById(R.id.fingerprint_root_view);
        bannerContainer = (LinearLayout) mainView.findViewById(R.id.banner_container);
        setupPasscodeField(0);
        setupPasscodeField(1);
        setupPasscodeField(2);
        setupPasscodeField(3);

        final PasscodeCircularEditText et = fieldTVs[fieldInt];
        et.setOnTouchListener(new PasscodeTouchListner(fieldInt));
        et.removeTextChangedListener(submitTextWatcher);
        et.addTextChangedListener(submitTextWatcher);

        validationIV.setVisibility(View.INVISIBLE);
        deviceToken = TokenUtil.genClientBindingToken();
        hidePasscodeLayout();
        if (null != mFingerprintSetUpInterface)
            mFingerprintSetUpInterface.enableBackNavigationForFingerPrint(true);
        fingerPrintToggle.setOnCheckedChangeListener(compoundButtonListener);

        //Check toggle on/off depending upon the fingerprint status
        setToggleState();

        privacy_terms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFingerprintSetupPresenter.onClickPrivacyTerms();
            }
        });
        provide_feedback_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFingerprintSetupPresenter.onClickProvideFeedback();
            }
        });


    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mContext = getActivity();
            mFingerprintSetUpInterface = (FingerprintSetUpInterface) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement FingerPrintListener");
        }
    }

    private void setupAllFields() {
        setupPasscodeField(0);
        setupPasscodeField(1);
        setupPasscodeField(2);
        setupPasscodeField(3);

        setupSubmit();

    }

    private void setupSubmit() {
        final int fieldInt = 3;
        final PasscodeCircularEditText et = fieldTVs[fieldInt];
        et.setOnTouchListener(new PasscodeTouchListner(fieldInt));
        et.removeTextChangedListener(submitTextWatcher);
        et.addTextChangedListener(submitTextWatcher);
    }

    /**
     * Show passcode fields and keyboard
     */
    private void showPasscodeLayout() {
        int nextInput = getNextInput();
        fieldTVs[nextInput].requestFocus();
        enterPasscodeLayout.setVisibility(View.VISIBLE);
        forceSoftKeyboardShown(nextInput);
    }

    protected boolean isPasscodeValidLocally(String passcode) {
        return PasscodeUtils.isPasscodeValidLocally(passcode);
    }

    // returns input fields as string
    protected String getPasscodeString() {
        String retVal = "";
        for (int i = 0; i < fieldTVs.length; i++) {
            retVal += fieldTVs[i].getText();
        }
        return retVal;
    }

    /**
     * Hide passcode fields and keyboard
     */
    private void hidePasscodeLayout() {
        enterPasscodeLayout.setVisibility(View.GONE);
        //Defect 3583
        DiscoverActivityManager
                .getActiveActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        forceSoftKeyboardHidden();
    }

    private int getNextInput() {
        for (int i = 0; i < fieldTVs.length; i++) {
            if (fieldTVs[i].length() == 0) {
                return i;
            }
        }
        return 0;
    }

    private void forceSoftKeyboardShown(int inputId) {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(fieldTVs[inputId], InputMethodManager.SHOW_IMPLICIT);
    }

    private void forceSoftKeyboardHidden() {
        Activity activity = getActivity();
        if (activity == null) {
            return;
        }
        View currentFocus = activity.getCurrentFocus();
        if (currentFocus != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    private void setupPasscodeField(final int fieldInt) {
        final PasscodeCircularEditText et = fieldTVs[fieldInt];
        et.setOnKeyListener(this);
        et.setFillColor(R.color.onboard_circular_text_fill_color);
        et.setOnTouchListener(new PasscodeTouchListner(fieldInt));
        et.setTransformationMethod(PasswordTransformationMethod
                .getInstance());
        et.addTextChangedListener(new TextWatcher() {
            // Logic to mask input and go to next item
            public void afterTextChanged(Editable paramAnonymousEditable) {
                isedited = true;
                // Added for US74896. Dismiss banner after passcode retry.
                if (bannerMessage != null && bannerMessage.getVisibility() == View.VISIBLE)
                    bannerMessage.dismiss();

                validatePasscodeField(fieldInt, paramAnonymousEditable);
            }

            // REQUIRED EVEN THOUGHT LEFT EMPTY
            public void beforeTextChanged(
                    CharSequence paramAnonymousCharSequence,
                    int paramAnonymousInt1, int paramAnonymousInt2,
                    int paramAnonymousInt3) {
            }

            // REQUIRED EVEN THOUGHT LEFT EMPTY
            public void onTextChanged(CharSequence paramAnonymousCharSequence,
                                      int paramAnonymousInt1, int paramAnonymousInt2,
                                      int paramAnonymousInt3) {
            }

        });
    }

    public void enableFpToggle() {
        //Checking fingerprint registered on the device or not
        if (FingerPrintUtils.isFingerprintRegistered(mContext)) {
            if (mPasscodeUtils.getPasscodeToken() != null) {
                if (fingerPrintUtils.getFingerPrintStatus()) {
                    fingerPrintToggle.setChecked(true);
                    hidePasscodeLayout();
                } else {
                    if(!FingerPrintUtils.isCancelModelShow) {
                        //Start: US72282: FingerPrint Analytics
                        if(Globals.isBankLoginSelected)
                            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_PASSCODE_VERIFICATION_PG);
                        else
                        //End: US72282: FingerPrint Analytics
                        /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                        //On the page load passcode verification
                        TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_PASSCODE_VERIFICATION_PG);
                        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                    }
                    showPasscodeLayout();
                }
            } else {
                //*This method shows passcode enable model*//*
                fingerPrintToggle.setChecked(false);
                mFingerprintSetUpInterface.showSetupPcdFpModel();
            }
        } else {
            //*This method shows set up model for fingerprint*//*
            fingerPrintToggle.setChecked(false);
        }

    }


    public void disableFpToggle() {

        hidePasscodeLayout();
//        defect 3228 fix
        clearAllFields();
        //defect #92 Bank side Fix
        isedited = false;
        if (fingerPrintUtils.getFingerPrintStatus()) {
            //added if condition for Fix for defect# 97
            showDialog(FingerPrintConstants.DIALOG_DISABLE_FINGERPRINT);
            fingerPrintUtils.removeFingerprintPasscode();
            fingerPrintUtils.setFingerPrintStatus(false);
            mFingerprintSetUpInterface.updateProfileSettingFingerPrintStatus(false, fingerPrintUtils.getUserId(mContext), mContext);
        }
    }

    public boolean onKey(View paramView, int fieldInt, KeyEvent paramKeyEvent) {
        // delete key
        if (paramKeyEvent.getAction() == KeyEvent.ACTION_DOWN && fieldInt == KEY_DELETE) {
            deleteLatestInput().requestFocus();
        }
        if (paramKeyEvent.getAction() == KeyEvent.ACTION_DOWN) {
            return false;
        }
        if (fieldInt == KeyEvent.KEYCODE_BACK) {
            printFragmentsInBackStack();
        }
        return super.getActivity().onKeyUp(fieldInt, paramKeyEvent);
    }

    public void printFragmentsInBackStack() {
        final FragmentManager fragManager = getActivity().getSupportFragmentManager();
        final int fragCount = fragManager.getBackStackEntryCount();
        if (fragCount > 0) {
            for (int i = 0; i < fragCount; i++) {
                if (null != fragManager.getBackStackEntryAt(i).getName()) {
                    Utils.log("Tag", fragManager
                            .getBackStackEntryAt(i).getName());
                }

            }
        }
    }

    // deletes most recent input
    public TextView deleteLatestInput() {
        for (int i = fieldTVs.length - 1; i >= 0; i--) {
            if (fieldTVs[i].length() > 0) {
                clearField(fieldTVs[i]);
                return fieldTVs[i];
            }
        }
        return fieldTVs[0];
    }


    private void clearPasscodeFields() {
        for (final PasscodeCircularEditText fieldTV : fieldTVs) {
            if (!TextUtils.isEmpty(fieldTV.getText())) {
                clearField(fieldTV);
            }
        }

    }

    /**
     * Added for US74894
     * check If passcode layout is visible.
     */
    public boolean isPasscodelayoutVisible() {
        return (enterPasscodeLayout.getVisibility() == View.VISIBLE ? true : false);
    }


    @Override
    public void updateUI(boolean toggleState) {

    }

    @Override
    public void updateUI(boolean isSuccess, String passcode) {
        Utils.log("tag", "PasscodeResponse");
        if (isSuccess) {
            clearAllFields();
            //defect #92 Bank side Fix
            isedited = false;
            fingerPrintToggle.setChecked(true);
            hidePasscodeLayout();

        } else {
            vibrateandShake();
            guiValidationReset();
            clearPasscodeFields();
        }
    }

    @Override
    public void onToggleStateChanged(boolean toggleState) {

        if (toggleState)
            enableFpToggle();
        else
            disableFpToggle();
    }

    @Override
    public void showDialog(int type) {

        switch (type) {
            case FingerPrintConstants.DIALOG_DISABLE_FINGERPRINT:
                showFingerprintDisableModel();
                break;
            case FingerPrintConstants.DIALOG_ENABLE_FINGERPRINT:
                showFingerprintEnableModel();
                break;
            case FingerPrintConstants.DIALOG_SETUP_FINGERPRINT:
                showSetUpFingerprintModel();
                break;

            default:
                break;
        }

    }

    @Override
    public void navigateTo(int type) {

        if (type == FingerPrintConstants.TYPE_PRIVACY_AND_TERMS)
            mFingerprintSetUpInterface.privacyTermsClickListener();
        else if (type == FingerPrintConstants.TYPE_PROVIDE_FEEDBACK)
            mFingerprintSetUpInterface.feedbackClickListener();
    }


    private class PasscodeTouchListner implements View.OnTouchListener {

        private int fieldInt;

        public PasscodeTouchListner(int fieldInt) {
            this.fieldInt = fieldInt;
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            int nextInput = getNextInput();
            if (fieldInt != nextInput) {
                fieldTVs[fieldInt].clearFocus();
                fieldTVs[nextInput].requestFocus();
                forceSoftKeyboardShown(nextInput);
                return true;
            }
            return false;
        }

    }

    /*
    * Returns true if at id fieldInt is valid 0-9. If not it clears the field
    * and returns false.
    */
    protected boolean validatePasscodeField(int fieldInt, Editable paramEditable) {
        TextView localTextView = fieldTVs[fieldInt];
        // if transformation method isn't password set it anyways
        if (!(localTextView.getTransformationMethod() instanceof PasswordTransformationMethod)) {
            localTextView.setTransformationMethod(PasswordTransformationMethod
                    .getInstance());
        }

        // validate input is exactly 1 character and 0-9
        if (isCharNumeric(paramEditable)) {
            advanceInput(fieldInt).requestFocus();
            return true;
        } else if (isCharEmpty(paramEditable)) {
            // do nothing
            return false;
        } else {
            // invalid input
            clearField(localTextView);
            return false;
        }
    }

    // remove text from field
    private void clearField(TextView paramTextView) {
        paramTextView.setText("");
    }

    private boolean isCharEmpty(CharSequence paramCharSequence) {
        return (paramCharSequence.length() == 0);
    }

    private boolean isCharNumeric(CharSequence paramCharSequence) {
        if (paramCharSequence.length() != 1) {
            return false;
        }
        return new String("1234567890").contains(paramCharSequence);
    }

    // advances input to next field
    private TextView advanceInput(int currentIndex) {
        if (currentIndex < fieldTVs.length - 1) {
            return fieldTVs[currentIndex + 1];
        } else if (currentIndex < 0) {
            return fieldTVs[0];
        } else {
            return fieldTVs[fieldTVs.length - 1];
        }
    }

    /**
     * US71616: This method invoke when User wants to disable fingerprint of the app.
     */
    private void showFingerprintDisableModel() {
        //Start: US72282: FingerPrint Analytics
        if(Globals.isBankLoginSelected)
            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_DISABLED_OVERLAY_PG);
        else
        //End: US72282: FingerPrint Analytics
        /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
        TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_DISABLED_OVERLAY_PG);
        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/

        final DiscoverAlertDialog passcodeCreatedDialog = new DiscoverAlertDialog();
        passcodeCreatedDialog.setTitle(getResources().getString(R.string.fingerprint_disable_title)).
                setMessage(getResources().getString(R.string.fingerprint_disable_desc)).
                setPositiveButton(getResources().getString(R.string.fingerprint_home_btn_text), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //US71450:Fingerprint Enabled or Disabled Modal code changes start
                        passcodeCreatedDialog.dismiss();
                        fingerPrintUtils.removeFingerprintPasscode();
                        fingerPrintUtils.setFingerPrintStatus(false);
                        //Navigate to home page
                        mFingerprintSetUpInterface.navToHome();
                        //Defect 3583
                        DiscoverActivityManager
                                .getActiveActivity().getWindow().setSoftInputMode(
                                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                        forceSoftKeyboardHidden();
                        //US71450:Fingerprint Enabled or Disabled Modal code changes end

                        //Start: US72282: FingerPrint Analytics
                        if (Globals.isBankLoginSelected) {
                            HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                            extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_HOME_BTN);
                            TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_HOME_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                        } else {
                            //End: US72282: FingerPrint Analytics
                        /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                        //On the Click of Home Button
                        HashMap<String, Object> extras = new HashMap<String, Object>();
                        extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_HOME_BTN);
                        TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_HOME_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                    }
                    }
                }).setNegativeButton(getResources().getString(R.string.fingerprint_close_btn_text), new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //US71450:Fingerprint Enabled or Disabled Modal code changes start
                forceSoftKeyboardHidden();
                passcodeCreatedDialog.dismiss();
                //Defect 3583
                DiscoverActivityManager
                        .getActiveActivity().getWindow().setSoftInputMode(
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                forceSoftKeyboardHidden();
                //US71450:Fingerprint Enabled or Disabled Modal code changes end
                //Start: US72282: FingerPrint Analytics
                if(Globals.isBankLoginSelected) {
                    HashMap<String, Object> extras =FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                    extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_CLOSE_LNK);
                    TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_CLOSE_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                }
                else {
                    //End: US72282: FingerPrint Analytics
                    /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                    //On the Click of Close link
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_CLOSE_LNK);
                    TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_DISABLED_MODAL_CLOSE_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                    /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                }
            }
        }).setCanCancelable(true).setCanceledOnTouchOutside(false).
                show((AppCompatActivity) getContext());
    }

    /**
     * US71616: This method invoke when User enable fingerprint.
     */
    private void showFingerprintEnableModel() {
        //Start: US72282: FingerPrint Analytics
        if(Globals.isBankLoginSelected)
            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_ENABLED_OVERLAY_PG);
        else
        //End: US72282: FingerPrint Analytics
        /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
        //On the page load overlay of enable model
        TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_ENABLED_OVERLAY_PG);
        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/

        hidePasscodeLayout();
        final DiscoverAlertDialog passcodeCreatedDialog = new DiscoverAlertDialog();
        passcodeCreatedDialog.setTitle(getResources().getString(R.string.fingerprint_enable_title)).
                setMessage(getResources().getString(R.string.fingerprint_enable_desc)).
                setPositiveButton(getResources().getString(R.string.fingerprint_home_btn_text), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //US71450:Fingerprint Enabled or Disabled Modal code changes start
                        passcodeCreatedDialog.dismiss();
                        //Navigate to home page
                        mFingerprintSetUpInterface.navToHome();
                        //Defect 3583
                        DiscoverActivityManager
                                .getActiveActivity().getWindow().setSoftInputMode(
                                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                        forceSoftKeyboardHidden();
                        //Start: US72282: FingerPrint Analytics
                        if (Globals.isBankLoginSelected) {
                            HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                            extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_HOME_BTN);
                            TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_HOME_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                        } else {
                            //End: US72282: FingerPrint Analytics
                            //US71450:Fingerprint Enabled or Disabled Modal code changes end
                            /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                            //On the click home button
                            HashMap<String, Object> extras = new HashMap<String, Object>();
                            extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_HOME_BTN);
                            TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_HOME_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                            /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                        }
                    }
                }).setNegativeButton(getResources().getString(R.string.fingerprint_close_btn_text), new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //US71450:Fingerprint Enabled or Disabled Modal code changes start

                passcodeCreatedDialog.dismiss();
                //Defect 3583
                DiscoverActivityManager
                        .getActiveActivity().getWindow().setSoftInputMode(
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                forceSoftKeyboardHidden();

                //Start: US72282: FingerPrint Analytics
                if(Globals.isBankLoginSelected) {
                    HashMap<String, Object> extras =FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                    extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_CLOSE_LNK);
                    TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_CLOSE_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                }
                else
                {
                    //End:  US72282: FingerPrint Analytics
                    //US71450:Fingerprint Enabled or Disabled Modal code changes end

                    /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_CLOSE_LNK);
                    TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_ENABLED_MODAL_CLOSE_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                    /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                }

            }
        }).setCanCancelable(true).setCanceledOnTouchOutside(false).
                show((AppCompatActivity) getContext());
    }

    /**
     * For US71618: This method navigate user to Setting of the device for setting
     * the fingerprint
     */
    private void showSetUpFingerprintModel() {
        //Start: US72282: FingerPrint Analytics
        if(Globals.isBankLoginSelected)
            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_OVERLAY_PG);
        else
        //End: US72282: FingerPrint Analytics

        /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
        //On the pageload overlay SetUp Fingerprint Model on device
        TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_OVERLAY_PG);
        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/

        final DiscoverAlertDialog enablePasscodeDialog = new DiscoverAlertDialog();
        enablePasscodeDialog.setTitle(getResources().getString(R.string.enable_fingerprint_title)).
                setIcon(R.drawable.fingerprint_error_icon).
                setMessage(getResources().getString(R.string.enable_fingerprint_msg)).
                setPositiveButton(getResources().getString(R.string.setting), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //navigate to setting of device
                        Intent seetingIntent = new Intent(Settings.ACTION_SECURITY_SETTINGS); // Fix for defect# 1567
                        seetingIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(seetingIntent);
                        //Start: US72282: Fingerprint Analytics
                        if(Globals.isBankLoginSelected)
                        {
                            HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                            extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_SETTINGS_BTN);
                            TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_SETTINGS_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                        }
                        else {
                         //End: US72282: Fingerprint Analytics

                            /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                            //On the Click of Enable Fingerprint on Device Modal - SETTINGS Button
                            HashMap<String, Object> extras = new HashMap<String, Object>();
                            extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_SETTINGS_BTN);
                            TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_SETTINGS_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                            /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                        }

                    }
                }).setNegativeButton(getResources().getString(R.string.fingerprint_login_modal_cancel_btn_text), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Start: US72282: Fingerprint Analytics
                if(Globals.isBankLoginSelected) {
                    HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                    extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_CANCEL_LNK);
                    TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_CANCEL_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                }
                else {
                    //End: US72282: Fingerprint Analytics
                    /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                    //On the Click of Enable Fingerprint on Device Modal - CANCEL link
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_CANCEL_LNK);
                    TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_NOT_REGISTERED_MODAL_CANCEL_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                    /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                }
            }
        }).setCanCancelable(true).setCanceledOnTouchOutside(false).show((AppCompatActivity) getContext());
    }

    private void clearAllFields() {

        for (int j = 0; j < fieldTVs.length; j++) {
            clearField(fieldTVs[j]);
        }
        fieldTVs[0].requestFocus();
    }

    private TextWatcher submitTextWatcher = new TextWatcher() {

        // Logic to mask input and go to next item
        public void afterTextChanged(Editable paramAnonymousEditable) {


            // ensure this field passed validation (i.e. not comma or bad haracter or blank (due to clearing input))

            if (!validatePasscodeField(3, paramAnonymousEditable)) {
                return;
            }
            fieldTVs[0].requestFocus();
            mFingerprintSetupPresenter.validatePasscode(getPasscodeString());

        }

        // REQUIRED EVEN THOUGHT LEFT EMPTY
        public void beforeTextChanged(
                CharSequence paramAnonymousCharSequence,
                int paramAnonymousInt1, int paramAnonymousInt2,
                int paramAnonymousInt3) {
        }

        // REQUIRED EVEN THOUGHT LEFT EMPTY
        public void onTextChanged(CharSequence paramAnonymousCharSequence,
                                  int paramAnonymousInt1, int paramAnonymousInt2,
                                  int paramAnonymousInt3) {
        }
    };


    /**
     * Added for US74896
     * Show Banner after invalid passcode. Show until user retry passcode again.
     */
    @Override
    public void showInvalidPasscodeBanner() {

        //Start US US74896
        if (null == bannerMessage)
            bannerMessage = new BannerMessage(getActivity());
        //US84853 - start
        if (Globals.isBankLoginSelected && !Utils.isRunningOnHandset(mContext)) {
            bannerMessage.make(getActivity(), mainView, getString(R.string.error_message_incorrect_passcode), BannerMessage.ERROR);
        } else {
            mainView.removeView(mainView.findViewById(R.id.animation_container));
            bannerMessage.make(getActivity(), getParentFragment().getView(), getString(R.string.error_message_incorrect_passcode), BannerMessage.ERROR);
        }
        //US84853 - end
        bannerMessage.show();
        //Start: US72282: FingerPrint Analytics
        if(Globals.isBankLoginSelected)
        {
            HashMap<String, Object> extras =FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
            extras.put(AnalyticsPage.CONTEXT_PROPERTY_10, getString(R.string.error_message_incorrect_passcode));
            TrackingHelper.trackBankPage(AnalyticsPage.FINGER_PRINT_PASSCODE_VERIFICATION_PG, extras);
        }
        else {
            //End: US72282: FingerPrint Analytics
            /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put(AnalyticsPage.CONTEXT_PROPERTY_10, getString(R.string.error_message_incorrect_passcode));
            TrackingHelper.trackCardPage(AnalyticsPage.FINGER_PRINT_PASSCODE_VERIFICATION_PG, extras);
            /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
        }
        }

    /**
     * Added for US74896
     * Vibrate and shake animation for invalid passcode.
     */
    public void vibrateandShake() {
        Vibrator vibrate = (Vibrator) getActivity().getSystemService(
                Context.VIBRATOR_SERVICE);
        vibrate.vibrate(100);

        Animation shake = AnimationUtils.loadAnimation(getActivity(),
                R.anim.shake);
        for (int i = 0; i < fieldTVs.length; i++) {
            fieldTVs[i].startAnimation(shake);
        }
    }

    /**
     * Redraw passcode circles.
     */
    private void guiValidationReset() {
        for (int i = 0; i < 4; i++) {
            fieldTVs[i].invalidate();
        }
        validationIV.setVisibility(View.INVISIBLE);
    }

    //to check whetherpasscode is edited
    public Boolean isEdited() {
        return isedited;
    }

    // Added for Fix: defect 79; Banner Issue
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        int paddingLeftInDp = 96;
        int paddingTopInDp = 14;
        int paddingRightInDp = 40;
        int paddingBottomInDp = 16;

        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (null != fingerprintRootView) {
                fingerprintRootView.setPadding(Utils.dpToPx(paddingLeftInDp, displayMetrics), Utils.dpToPx(paddingTopInDp, displayMetrics), Utils.dpToPx(paddingLeftInDp, displayMetrics), Utils.dpToPx(paddingBottomInDp, displayMetrics));
            }
            if (bannerMessage != null) {
                bannerMessage.invalidate();
            }
        } else {
            if (null != fingerprintRootView) {
                fingerprintRootView.setPadding(Utils.dpToPx(paddingRightInDp, displayMetrics), Utils.dpToPx(paddingTopInDp, displayMetrics), Utils.dpToPx(paddingRightInDp, displayMetrics), Utils.dpToPx(paddingBottomInDp, displayMetrics));
            }
            if (bannerMessage != null) {
                bannerMessage.invalidate();
            }
        }
    }

}
