package com.discover.mobile.common.ui.chipView;

public class Tag implements Chip, Comparable<Tag> {
    private String mName;
    private int mType = 0;

    public Tag(String name, int type) {
        this(name);
        mType = type;
    }

    public Tag(String name) {
        mName = name;
    }

    @Override
    public String getText() {
        return mName;
    }

    @Override
    public int getType() {
        return mType;
    }

    @Override
    public int compareTo(Tag another) {
        return this.mName.compareTo(another.getText());
    }
}
