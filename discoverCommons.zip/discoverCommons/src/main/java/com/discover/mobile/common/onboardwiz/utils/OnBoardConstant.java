package com.discover.mobile.common.onboardwiz.utils;

/**
 * Created by 482127 on 4/27/2016.
 */
public class OnBoardConstant {
    public static final String PASSCODE_STATE_KEY = "PASSCODE_STATE_KEY";
    public static final String INTERNAL_SERVER_ERROR = "500";
    public static final String PASSCODE_VALUE = "passcode";
    public static final String QUICKVIEW_REMINDER = "QuickView";
    public static boolean isFpSuccessConfirmTagFired = false;
    public static final String PASSCODE_LAST_ATTEMPT = "2115";
    public static final String PASSCODE_TEMP_LOCKED = "2116";

    /*Exit Animation Related constants*/
    public static final String ONBOARD_EXIT_ANIM_SHARED_VIEW_NAME = "onboard_shared_view_name";
    public static final String ONBOARD_EXIT_ANIM_KEY = "onboard_exit_anim_key";
    public static int PAGER_SIZE = 4;
    public static int PAPERLESS_PAGE = 3;
    public static int QUICKVIEW_PAGE = 2;
    public static int PASSCODE_PAGE = 0;
    public static int FINGERPRINT_PAGE = 1;
    public enum PASSCODE_PAGE_STATE {
        ENABLE_PAGE,
        VERIFY_PAGE,
        CREATE_PAGE,
        EXISTING_PAGE,
        CONFIRMATION_PAGE,
        PASSCODE_DONE_PAGE
    }
    public enum QUICKVIEW_PAGE_STATE {
        ENABLE_PAGE,
        CONFIRMATION_PAGE,
        QUICKVIEW_DONE_PAGE
    }

    public class FingerprintPageState {
        public static final int FINGERPRINT_ENABLED = 101;
        public static final int FINGERPRINT_NOT_REGISTERED = 102;
        public static final int PASSCODE_NOT_ENABLED = 103;
        public static final int FINGERPRINT_SETUP_COMPLETED = 104;
        public static final int FINGERPRINT_NOT_ENABLED = 105;
    }

}
