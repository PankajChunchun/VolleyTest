package com.discover.mobile.common.facade;

import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.ui.modals.SimpleTwoButtonModal;

import android.content.Context;

/**
 * Created by 409992 on 5/13/2016.
 * Facade for Card side Passcode and Quickview
 */
public interface CardOnBoardFacade {

    public void getPasscodeBindService(Context context, final String deviceToken, final NetworkRequestListener listener);

    public void getCreatePasscodeService(Context context, final String deviceToken, final String mPasscode, final NetworkRequestListener listener);

    public void getResetPasscodeService(Context context, final String deviceToken, final String mPasscode, final NetworkRequestListener listener);

    public void getMatchPasscodeService(Context context, final String mPasscode, final NetworkRequestListener listener);

    public void getPasscodeStatusService(Context context, final String mPasscode, final NetworkRequestListener listener);

    public void getValidatePasscodeSyntax(Context context, final String mPasscode, final NetworkRequestListener listener);

    public void getQuickViewBindStatus(Context context, final String mToken, final NetworkRequestListener listener);

    public void getQuickViewUpdateService(Context context, final boolean quickViewOn, final NetworkRequestListener listener);

    public void enablePasscodeState(Context context);

    public void launchPushAlerts(Context context);

    public void launchEwalletFlow(Context context);

    public SimpleTwoButtonModal showTempLockModal(Context context);

    public void getEwalletProvisioningEligibilityService(Context context, final NetworkRequestListener listener);


}
