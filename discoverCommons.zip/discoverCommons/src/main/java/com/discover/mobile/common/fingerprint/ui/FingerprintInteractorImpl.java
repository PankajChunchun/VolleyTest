package com.discover.mobile.common.fingerprint.ui;

import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.interfaces.FingerprintSetUpInterface;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.utils.PasscodeUtils;

/**
 * Presenter implementation class for {@Link : FingerprintIntractor}
 */
public class FingerprintInteractorImpl implements FingerprintInteractor {

    private final FingerPrintUtils mMFingerPrintUtils;
    private final FingerprintSetUpInterface mFingerprintSetUpInterface;

    public FingerprintInteractorImpl(FingerPrintUtils fingerPrintUtils, FingerprintSetUpInterface fingerprintSetUpInterface) {
        mMFingerPrintUtils = fingerPrintUtils;
        mFingerprintSetUpInterface = fingerprintSetUpInterface;
    }

    @Override
    public void validatePasscodeAndSubmit(final String passcode, final NetworkRequestListener listener) {
        boolean isValid = PasscodeUtils.isPasscodeValidLocally(passcode);
        if (isValid) {
            mFingerprintSetUpInterface.matchPcdFpService(passcode, listener);
        }else
            listener.onError(null);

    }

    @Override
    public boolean isFingerprintRegisteronDevice() {

        return mMFingerPrintUtils.isFingerprintRegistered(DiscoverActivityManager.getActiveActivity());
    }

    @Override
    public void setFingerPrintStatus(String passcode, boolean status, boolean isSuccess) {
            if (isSuccess) {
                mMFingerPrintUtils.storePasscodeForFingerPrint(passcode);
                mMFingerPrintUtils.setFingerPrintStatus(true);
                mFingerprintSetUpInterface.updateProfileSettingFingerPrintStatus(true, mMFingerPrintUtils.getUserId(DiscoverActivityManager.getActiveActivity()), DiscoverActivityManager.getActiveActivity());
            } else{
                 mMFingerPrintUtils.removeFingerprintPasscode();
                 mMFingerPrintUtils.setFingerPrintStatus(false);
                 mFingerprintSetUpInterface.updateProfileSettingFingerPrintStatus(false, mMFingerPrintUtils.getUserId(DiscoverActivityManager.getActiveActivity()), DiscoverActivityManager.getActiveActivity());
            }
    }

    @Override
    public boolean getFingerPrintStatus() {
        return mMFingerPrintUtils.getFingerPrintStatus();
    }

}
