package com.discover.mobile.common.nav.adapters;

import com.discover.mobile.common.R;
import com.discover.mobile.common.appmessaging.helper.WinkDetail;
import com.discover.mobile.common.nav.modals.NavigationMenuItem;
import com.discover.mobile.common.nav.modals.NavigationMenuSubItem;

import android.content.Context;
import android.graphics.Color;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.List;
import java.util.Map;

/**
 * Adapter for LHN menu list of {@link}s.
 */
public class DrawerExpandableAdapter extends AnimatedExpandableListView.AnimatedExpandableListAdapter {
    private LayoutInflater mLayoutInflater;
    private List<NavigationMenuItem> items;
    private Context context;
    private Map<String, WinkDetail> winkDetailList;
    private String ParentItem = "ParentItem_";
    private String ChildItem = "ChildItem_";
    private String WinkImage = "_Wink";
    public DrawerExpandableAdapter(Context context) {
        this.context = context;
        mLayoutInflater = LayoutInflater.from(context);
    }

    public void setData(List<NavigationMenuItem> items) {
        this.items = items;
    }

    /**
     * Method to set list of wink detail
     */
    public void setWinkDetailList(Map<String, WinkDetail> winkDetailList) {
        this.winkDetailList = winkDetailList;
    }

    /**
     * Method to get child view type
     */
//    @Override
    public int getRealChildViewType(int groupPosition, int childPosition) {
        int childViewType = 0;

        if ((winkDetailList != null) && winkDetailList.size() > 0) {
            List<NavigationMenuSubItem> menuItemList = items.get(groupPosition).getNavigationMenuSubItems();
            String key = menuItemList.get(childPosition).getComponentkey();
            if (winkDetailList.containsKey(key)) {
                WinkDetail winkDetail = winkDetailList.get(key);
                childViewType = winkDetail.getViewType();
            }
        }

        return childViewType;
    }

    /**
     * Method to get group view type
     */
//    @Override
    public int getGroupViewType(int groupPosition) {

        int groupViewType = 0;

        if (winkDetailList != null && winkDetailList.size() > 0) {
            String key = items.get(groupPosition).getComponentkey();
            if (winkDetailList.containsKey(key)) {
                WinkDetail winkDetail = winkDetailList.get(key);
                groupViewType = winkDetail.getViewType();
            }
        }
        return groupViewType;
    }

    @Override
    public NavigationMenuSubItem getChild(int groupPosition, int childPosition) {
        return items.get(groupPosition).getNavigationMenuSubItems().get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getRealChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        NavigationMenuItem navMenuItem = items.get(groupPosition);
        NavigationMenuSubItem childItem = navMenuItem.getNavigationMenuSubItems().get(childPosition);
        ChildItemHolder childItemHolder;

        switch (getRealChildViewType(groupPosition, childPosition)) {
            case WinkDetail.WITHOUT_WINK_AND_BADGE:

                if (convertView == null) {
                    childItemHolder = new ChildItemHolder();
                    convertView = mLayoutInflater.inflate(R.layout.drawer_list_subitem,
                            null);
                    childItemHolder.childtitleTextView = (TextView) convertView
                            .findViewById(R.id.item_title_child);
                    childItemHolder.childItemParentLayout = (RelativeLayout) convertView.findViewById(R.id.childItemParentLayout);
                    childItemHolder.childViewType = WinkDetail.WITHOUT_WINK_AND_BADGE;

                    convertView.setTag(childItemHolder);
                } else {
                    childItemHolder = (ChildItemHolder) convertView.getTag();
                    if ((childItemHolder == null) || (childItemHolder != null && childItemHolder.childViewType != WinkDetail.WITHOUT_WINK_AND_BADGE)) {
                        convertView = mLayoutInflater.inflate(R.layout.drawer_list_subitem,
                                null);
                        childItemHolder = new ChildItemHolder();
                        childItemHolder.childtitleTextView = (TextView) convertView
                                .findViewById(R.id.item_title_child);
                        childItemHolder.childItemParentLayout = (RelativeLayout) convertView.findViewById(R.id.childItemParentLayout);
                        childItemHolder.childViewType = WinkDetail.WITHOUT_WINK_AND_BADGE;

                        convertView.setTag(childItemHolder);
                    }
                }

                childItemHolder = (ChildItemHolder) convertView.getTag();
                childItemHolder.childtitleTextView.setTextColor(Color.BLACK);

                if (childItem.getChildTitle().equalsIgnoreCase(navMenuItem.getSelectedchildItem())) {
                    childItemHolder.childtitleTextView.setTextColor(context.getResources().getColor(R.color.highlight_orange));
                }

                if (childItemHolder != null && childItem != null) {
                    childItemHolder.childtitleTextView.setText(Html.fromHtml(childItem.getChildTitle()));
                }

                //childItemHolder.childtitleTextView.setTag(ChildItem + groupPosition + "_" + childItem.getChildTitle());
                childItemHolder.childItemParentLayout.setTag(childItem.getChildTitle());
                break;

            case WinkDetail.WITH_BADGE:

                if (convertView == null) {
                    convertView = mLayoutInflater.inflate(R.layout.drawer_list_subitem_wink_and_badge,
                            null);
                    childItemHolder = setupChildViewHolderWithWinkOrBadge(convertView);
                    childItemHolder.appMsgChildImgView.setVisibility(View.GONE);
                    childItemHolder.childViewType = WinkDetail.WITH_BADGE;
                    convertView.setTag(childItemHolder);
                } else {
                    childItemHolder = (ChildItemHolder) convertView.getTag();
                    if ((childItemHolder == null) || (childItemHolder != null && childItemHolder.childViewType != WinkDetail.WITH_BADGE)) {
                        convertView = mLayoutInflater.inflate(R.layout.drawer_list_subitem_wink_and_badge,
                                null);
                        childItemHolder = setupChildViewHolderWithWinkOrBadge(convertView);
                        childItemHolder.appMsgChildImgView.setVisibility(View.GONE);
                        childItemHolder.childViewType = WinkDetail.WITH_BADGE;
                        convertView.setTag(childItemHolder);
                    }
                }

                childItemHolder = (ChildItemHolder) convertView.getTag();
                childItemHolder.childtitleTextView.setTextColor(Color.BLACK);

                if (childItem.getChildTitle().equalsIgnoreCase(navMenuItem.getSelectedchildItem())) {
                    childItemHolder.childtitleTextView.setTextColor(context.getResources().getColor(R.color.highlight_orange));
                }

                if (childItemHolder != null && childItem != null) {
                    childItemHolder.childtitleTextView.setText(Html.fromHtml(childItem.getChildTitle()));

                }

                //Display wink or badge
                WinkDetail winkDetail = winkDetailList.get(childItem.getComponentkey());

                //Should hide app message wink if badge is available
                childItemHolder.appMsgChildImgView.setVisibility(View.GONE);
                childItemHolder.badgeCountChildTextView.setVisibility(View.VISIBLE);
                int badgeCount = winkDetail.getBadgeCount();
                String badgeCountStr = badgeCount < 99 ? String.valueOf(badgeCount) : "99+";
                childItemHolder.badgeCountChildTextView.setText(badgeCountStr);

                //childItemHolder.childtitleTextView.setTag(ChildItem + groupPosition + "_" + childItem.getChildTitle());
                childItemHolder.childItemParentLayout.setTag(childItem.getChildTitle());
                //childItemHolder.badgeCountChildTextView.setTag(ChildItem + groupPosition + "_" + badgeCountStr);
                break;
            case WinkDetail.WITH_WINK:

                if (convertView == null) {
                    convertView = mLayoutInflater.inflate(R.layout.drawer_list_subitem_wink_and_badge,
                            null);
                    childItemHolder = setupChildViewHolderWithWinkOrBadge(convertView);
                    childItemHolder.badgeCountChildTextView.setVisibility(View.GONE);
                    childItemHolder.childViewType = WinkDetail.WITH_WINK;
                    convertView.setTag(childItemHolder);
                } else {
                    childItemHolder = (ChildItemHolder) convertView.getTag();
                    if ((childItemHolder == null) || (childItemHolder != null && childItemHolder.childViewType != WinkDetail.WITH_WINK)) {
                        convertView = mLayoutInflater.inflate(R.layout.drawer_list_subitem_wink_and_badge,
                                null);
                        childItemHolder = setupChildViewHolderWithWinkOrBadge(convertView);
                        childItemHolder.badgeCountChildTextView.setVisibility(View.GONE);
                        childItemHolder.childViewType = WinkDetail.WITH_WINK;
                        convertView.setTag(childItemHolder);
                    }
                }

                //Show wink
                childItemHolder.appMsgChildImgView.setVisibility(View.VISIBLE);
                //Hide Badge
                childItemHolder.badgeCountChildTextView.setVisibility(View.GONE);

                childItemHolder = (ChildItemHolder) convertView.getTag();
                childItemHolder.childtitleTextView.setTextColor(Color.BLACK);

                if (childItem.getChildTitle().equalsIgnoreCase(navMenuItem.getSelectedchildItem())) {
                    childItemHolder.childtitleTextView.setTextColor(context.getResources().getColor(R.color.highlight_orange));

                    //Hide wink if item is selected
                    childItemHolder.appMsgChildImgView.setVisibility(View.GONE);
                }

                if (childItemHolder != null && childItem != null) {
                    childItemHolder.childtitleTextView.setText(Html.fromHtml(childItem.getChildTitle()));
                    childItemHolder.childtitleTextView.setContentDescription(Html.fromHtml(childItem.getChildTitle()) + " featured");
                    //childItemHolder.childtitleTextView.setTag(ChildItem + groupPosition + "_" + childItem.getChildTitle());
                    childItemHolder.childItemParentLayout.setTag(childItem.getChildTitle());
                    //childItemHolder.appMsgChildImgView.setTag(ChildItem + groupPosition + WinkImage);
                }

                break;
        }

        return convertView;
    }

    /**
     * Method to set up child view holder with wink or badge
     */
    private ChildItemHolder setupChildViewHolderWithWinkOrBadge(View view) {
        ChildItemHolder childItemHolder = new ChildItemHolder();
        childItemHolder.childItemParentLayout = (RelativeLayout) view.findViewById(R.id.childItemParentLayout);
        childItemHolder.childtitleTextView = (TextView) view
                .findViewById(R.id.item_title_child);
        childItemHolder.badgeCountChildTextView = (TextView) view.findViewById(R.id.push_count_child);
        childItemHolder.appMsgChildImgView = (ImageView) view.findViewById(R.id.app_msg_wink_child);
        return childItemHolder;
    }

    /**
     * Method to set up group view holder with wink or badge
     */
    private GroupItemHolder setupGroupViewHolderWithWinkOrBadge(View view) {

        GroupItemHolder groupItemHolder = new GroupItemHolder();
        groupItemHolder.groupItemParentLayout = (RelativeLayout) view.findViewById(R.id.groupItemParentLayout);
        groupItemHolder.grouptitleTextView = (TextView) view
                .findViewById(R.id.item_caption);
        groupItemHolder.badgeCountTextView = (TextView) view
                .findViewById(R.id.push_count);
        groupItemHolder.appMsgImgView = (ImageView) view
                .findViewById(R.id.app_msg_wink);
        groupItemHolder.itemDevider = view.findViewById(R.id.item_devider);

        return groupItemHolder;
    }

    @Override
    public int getRealChildrenCount(int groupPosition) {
        List<NavigationMenuSubItem> childItems = items.get(groupPosition).getNavigationMenuSubItems();
        if (childItems != null) {
            return childItems.size();
        }
        return 0;
    }

    @Override
    public NavigationMenuItem getGroup(int groupPosition) {
        return items.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return items.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        NavigationMenuItem groupItem = items.get(groupPosition);
        GroupItemHolder groupItemHolder;

        switch (getGroupViewType(groupPosition)) {
            case WinkDetail.WITHOUT_WINK_AND_BADGE:

                if (convertView == null) {
                    convertView = mLayoutInflater.inflate(R.layout.drawer_list_item,
                            null);
                    groupItemHolder = new GroupItemHolder();
                    groupItemHolder.grouptitleTextView = (TextView) convertView
                            .findViewById(R.id.item_caption);
                    groupItemHolder.groupItemParentLayout = (RelativeLayout) convertView.findViewById(R.id.groupItemParentLayout);
                    groupItemHolder.itemDevider = convertView.findViewById(R.id.item_devider);
                    groupItemHolder.groupViewType = WinkDetail.WITHOUT_WINK_AND_BADGE;
                    convertView.setTag(groupItemHolder);
                } else {
                    groupItemHolder = (GroupItemHolder) convertView.getTag();
                    if ((groupItemHolder == null) || (groupItemHolder != null && groupItemHolder.groupViewType != WinkDetail.WITHOUT_WINK_AND_BADGE)) {
                        convertView = mLayoutInflater.inflate(R.layout.drawer_list_item,
                                null);
                        groupItemHolder = new GroupItemHolder();
                        groupItemHolder.grouptitleTextView = (TextView) convertView
                                .findViewById(R.id.item_caption);
                        groupItemHolder.groupItemParentLayout = (RelativeLayout) convertView.findViewById(R.id.groupItemParentLayout);
                        groupItemHolder.itemDevider = convertView.findViewById(R.id.item_devider);
                        groupItemHolder.groupViewType = WinkDetail.WITHOUT_WINK_AND_BADGE;
                        convertView.setTag(groupItemHolder);
                    }
                }

                groupItemHolder.grouptitleTextView.setText(Html.fromHtml(groupItem.getGroupTitle()));
                if (isExpanded) {
                    groupItemHolder.grouptitleTextView.setTextColor(context.getResources().getColor(R.color.highlight_orange));
                } else {
                    groupItemHolder.grouptitleTextView.setTextColor(Color.BLACK);
                }
                if (groupPosition == 0) {
                    groupItemHolder.itemDevider.setVisibility(View.GONE);
                } else {
                    groupItemHolder.itemDevider.setVisibility(View.VISIBLE);
                }

                groupItemHolder.groupItemParentLayout.setTag(groupItem.getGroupTitle());
                groupItemHolder.grouptitleTextView.setTag(ParentItem + groupPosition + "_" + groupItem.getGroupTitle());
                break;
            case WinkDetail.WITH_BADGE:

                if (convertView == null) {
                    convertView = mLayoutInflater.inflate(R.layout.drawer_list_item_wink_and_badge,
                            null);
                    groupItemHolder = setupGroupViewHolderWithWinkOrBadge(convertView);
                    groupItemHolder.appMsgImgView.setVisibility(View.GONE);
                    groupItemHolder.groupViewType = WinkDetail.WITH_BADGE;
                    convertView.setTag(groupItemHolder);
                } else {
                    groupItemHolder = (GroupItemHolder) convertView.getTag();
                    if ((groupItemHolder == null) || (groupItemHolder != null && groupItemHolder.groupViewType != WinkDetail.WITH_BADGE)) {
                        convertView = mLayoutInflater.inflate(R.layout.drawer_list_item_wink_and_badge,
                                null);
                        groupItemHolder = setupGroupViewHolderWithWinkOrBadge(convertView);
                        groupItemHolder.appMsgImgView.setVisibility(View.GONE);
                        groupItemHolder.groupViewType = WinkDetail.WITH_BADGE;
                        convertView.setTag(groupItemHolder);
                    }
                }

                groupItemHolder.grouptitleTextView.setText(Html.fromHtml(groupItem.getGroupTitle()));
                if (isExpanded) {
                    groupItemHolder.grouptitleTextView.setTextColor(context.getResources().getColor(R.color.highlight_orange));
                    //US58263 code changes start
                    groupItemHolder.badgeCountTextView.setVisibility(View.GONE);
                    //US58263 code changes end

                } else {
                    groupItemHolder.grouptitleTextView.setTextColor(Color.BLACK);
                    //US58263 code changes start
                    groupItemHolder.badgeCountTextView.setVisibility(View.VISIBLE);
                    //US58263 code changes end
                }
                if (groupPosition == 0) {
                    groupItemHolder.itemDevider.setVisibility(View.GONE);
                } else {
                    groupItemHolder.itemDevider.setVisibility(View.VISIBLE);
                }

                //Display wink or badge
                WinkDetail winkDetail = winkDetailList.get(groupItem.getComponentkey());

                //Should hide app message wink if badge is available
                groupItemHolder.appMsgImgView.setVisibility(View.GONE);

                int badgeCount = winkDetail.getBadgeCount();
                String badgeCountStr = badgeCount < 99 ? String.valueOf(badgeCount) : "99+";
                groupItemHolder.badgeCountTextView.setText(badgeCountStr);

                groupItemHolder.grouptitleTextView.setTag(ParentItem + groupPosition + "_" + groupItem.getGroupTitle());
                groupItemHolder.groupItemParentLayout.setTag(groupItem.getGroupTitle());
                groupItemHolder.badgeCountTextView.setTag(ParentItem + groupPosition + "_" + badgeCountStr);
                break;

            case WinkDetail.WITH_WINK:

                if (convertView == null) {
                    convertView = mLayoutInflater.inflate(R.layout.drawer_list_item_wink_and_badge,
                            null);
                    groupItemHolder = setupGroupViewHolderWithWinkOrBadge(convertView);
                    groupItemHolder.badgeCountTextView.setVisibility(View.GONE);
                    groupItemHolder.groupViewType = WinkDetail.WITH_WINK;
                    convertView.setTag(groupItemHolder);
                } else {
                    groupItemHolder = (GroupItemHolder) convertView.getTag();
                    if ((groupItemHolder == null) || (groupItemHolder != null && groupItemHolder.groupViewType != WinkDetail.WITH_WINK)) {
                        convertView = mLayoutInflater.inflate(R.layout.drawer_list_item_wink_and_badge,
                                null);
                        groupItemHolder = setupGroupViewHolderWithWinkOrBadge(convertView);
                        groupItemHolder.badgeCountTextView.setVisibility(View.GONE);
                        groupItemHolder.groupViewType = WinkDetail.WITH_WINK;
                        convertView.setTag(groupItemHolder);
                    }
                }

                groupItemHolder.grouptitleTextView.setText(Html.fromHtml(groupItem.getGroupTitle()));
                groupItemHolder.grouptitleTextView.setContentDescription(Html.fromHtml(groupItem.getGroupTitle()) + " featured");
                if (isExpanded) {
                    groupItemHolder.grouptitleTextView.setTextColor(context.getResources().getColor(R.color.highlight_orange));

                    //Hide wink on item expanded state
                    groupItemHolder.appMsgImgView.setVisibility(View.GONE);
                } else {
                    groupItemHolder.grouptitleTextView.setTextColor(Color.BLACK);

                    //Show wink on item collapse state
                    groupItemHolder.appMsgImgView.setVisibility(View.VISIBLE);

                }
                if (groupPosition == 0) {
                    groupItemHolder.itemDevider.setVisibility(View.GONE);
                } else {
                    groupItemHolder.itemDevider.setVisibility(View.VISIBLE);
                }

                //Hide Badge
                groupItemHolder.badgeCountTextView.setVisibility(View.GONE);

                groupItemHolder.grouptitleTextView.setTag(ParentItem + groupPosition + "_" + groupItem.getGroupTitle());
                groupItemHolder.groupItemParentLayout.setTag(groupItem.getGroupTitle());
                groupItemHolder.appMsgImgView.setTag(ParentItem + groupPosition + WinkImage );
                break;
        }

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int arg0, int arg1) {
        return true;
    }

    /**
     * Method to refresh LHN menu
     */
    public void refreshLHN() {
        this.notifyDataSetChanged();
    }

    private static class GroupItemHolder {
        RelativeLayout groupItemParentLayout;
        TextView grouptitleTextView;
        TextView badgeCountTextView;
        ImageView appMsgImgView;
        View itemDevider;
        int groupViewType;
    }

    private static class ChildItemHolder {
        RelativeLayout childItemParentLayout;
        TextView childtitleTextView;
        TextView badgeCountChildTextView;
        ImageView appMsgChildImgView;
        int childViewType;
    }

}