package com.discover.mobile.common.fico.interactor;

import com.discover.mobile.common.shared.net.NetworkRequestListener;

/**
 * Created by slende on 5/5/2017.
 * Interactor for FICO feature
 */

public interface FicoCreditScoreInteractor {

    void getFicoCreditScore(final NetworkRequestListener ntListener);
}
