package com.discover.mobile.common.highlightedfeatures.utils;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Constants class for Highlighted-feature and Whatsnew.
 */
public class HFConstants {

    public static final String FILE_NAME_PREFIX = "HF_Android_";
    public static final String FILE_EXTENSION = ".json";
    public static Map<String, Double> DENSITY_MAP;

    static {
        Map<String, Double> map = new HashMap<String, Double>();
        map.put(Density.LDPI, 0.75);
        map.put(Density.MDPI, 1.0);
        map.put(Density.HDPI, 1.5);
        map.put(Density.XHDPI, 2.0);
        map.put(Density.XXHDPI, 3.0);
        map.put(Density.XXXHDPI, 4.0);
        DENSITY_MAP = Collections.unmodifiableMap(map);
    }

    private HFConstants() {
        throw new UnsupportedOperationException("Cannot instantiate the type " + HFConstants.class.getSimpleName());
    }

    /**
     * Enum for Login type. Represents SSO, CARD and BANK login.
     */
    public static enum LoginType {
        SSO(0), CARD(1), BANK(2);

        private int value;

        private LoginType(int value) {
            this.value = value;
        }

        public static LoginType getLoginTypeById(int id) {

            LoginType type = null;

            switch (id) {
                case 0:
                    type = SSO;
                    break;
                case 1:
                    type = CARD;
                    break;
                case 2:
                    type = BANK;
                    break;
                default:
                    break;
            }
            return type;
        }

        public int getValue() {
            return value;
        }
    }

    /**
     * Density constants. Values has been mapped to HF/Whats-new JSON.
     */
    public static final class Density {
        public static final String LDPI = "LDPI".toLowerCase();
        public static final String MDPI = "MDPI".toLowerCase();
        public static final String HDPI = "HDPI".toLowerCase();
        public static final String XHDPI = "XHDPI".toLowerCase();
        public static final String XXHDPI = "XXHDPI".toLowerCase();
        public static final String XXXHDPI = "XXXHDPI".toLowerCase();
    }

    /**
     * Orientation constants. Values has been mapped to HF/Whats-new JSON.
     */
    public static final class Orientation {
        public static final String LANDSCAPE = "land";
        public static final String PORTRAIT = "port";
    }

    /**
     * Device type supported for HF/Whats-new features.
     */
    public static final class Device {
        public static final String HANDSET = "Handset";
        public static final String TABLET = "Tablet";
    }

    /**
     * Constants class for keys of Bundle used for Highlighted feature and whats-new.
     */
    public static final class Args {
        /**
         * Used as Key to handle current selected page into mViewPager-view. It takes integer
         * values.
         */
        public static final String PAGER_LOCATION = "pager_location";

        /**
         * Used as key which handles pre-post login scenario. It takes boolean values.
         */
        public static final String PRE_LOGIN_FLAG = "is_prelogin";

        /**
         * Used as key which handles whats new or HF features. It takes boolean value.
         */
        public static final String WHATS_NEW_FLAG = "is_whats_new";

        /**
         * Used as key which handles CARD/ BANK/ SSO login. Values must be {@link
         * com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
         */
        public static final String LOGIN_TYPE = "login_type";

        /**
         * Used as key which handles Highlighted features list on orientation change.
         */
        public static final String HF_LIST = "highlighted_feature_list";
    }

    /**
     * Card type constants.
     */
    public static final class CardType {
        public static final String DIT = "DIT";
        public static final String MOR = "MOR";
        public static final String MTV = "MTV";
        public static final String OPR = "OPR";
        public static final String DIM = "DIM";
        public static final String MLS = "MLS";
        public static final String ESC = "ESC";
        public static final String ESN = "ESN";
        public static final String ESF = "ESF";
        public static final String DIG = "DIG";

        public static final String GROUP_IT = "it";
        public static final String GROUP_MILES = "miles";
        public static final String GROUP_ESSENTIAL = "essential";
    }
}
