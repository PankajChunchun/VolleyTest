package com.discover.mobile.common.fingerprint.utils;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import com.discover.mobile.common.Constants;
import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.shared.utils.SecurityUtil;
import com.discover.mobile.common.shared.utils.StringUtility;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.pass.Spass;
import com.samsung.android.sdk.pass.SpassFingerprint;

import java.util.HashMap;

/**
 * Utility class to detect hardware and fingerprint status.
 */
public class FingerPrintUtils {

    Context context = null;
    public static boolean isCancelModelShow=false;

    /**
     * File Name for shared preferences for FP - CARD Login
     */
    private final String FILENAME_PREFS_FP_CARD = "prefs_fp_card";

    /**
     * File Name for shared preferences for FP - BANK Login
     */
    private final String FILENAME_PREFS_FP_BANK = "prefs_fp_bank";

    /**
     * File Name for shared preferences for FP - SSO Login
     */
    private final String FILENAME_PREFS_FP_SSO = "prefs_fp_sso";

    /**
     * File Name for shared preferences for Kill-switch for Fingerprint
     */
    private final String FILENAME_PREFS_FP_KILL_SWITCH = "prefs_fp_killswitch";

    /**
     * Preferences variable for Kill-switch for Fingerprint
     */
    private SharedPreferences _FPSharedPref_killswitch;

    /**
     * Preferences editor for Kill-switch for Fingerprint
     */
    private SharedPreferences.Editor _FPSharedPrefEditor_killswitch;

    /**
     * Key to store pre-login kill-switch status
     */
    public final String FP_PRELOGIN_KILLSWITCH_STATUS_KEY = "fp_prelogin_killswitch_status";

    /**
     * Preferences variable either for Card or Bank
     */
    private SharedPreferences _FPSharedPref;

    /**
     * Preferences editor either for Card or Bank
     */
    private SharedPreferences.Editor _FPSharedPrefEditor;

    /**
     * Preferences variable for SSO User
     */
    private SharedPreferences _FPSharedPref_SSO;

    /**
     * Preferences editor for SSO User
     */
    private SharedPreferences.Editor _FPSharedPrefEditor_SSO;

    private PasscodeUtils passcodeUtils = null;
    /**
     * Common Key to store status of FP is enabled or not on Discover app level by user
     */
    public final String FP_ENABLE_STATUS_KEY = "is_fp_enable_status";

    /**
     * Common Key to store p***$$ in ###$$$$ form
     */
    public final String FP_PASS_KEY = "fp_pass";

    public static final String CARD_FINGERPRINT_LOGIN = "isCardFingerprintLogin";


    /**
     * Fingerprint deep-link code added for US71608 - Shake modal, whats new & reminder page
     */
    public static final String fpSetupDeeplinkCode = "linktotouchid";

    public static final String FP_SCANNING_FAILED_COUNT_KEY = "fpscanningfailedcount";
    public static final int FP_SCANNING_MAX_FAILED_COUNT = 4;

    public static final String MANUFACTURER_SAMSUNG = "samsung";

    public static String TAG = FingerPrintUtils.class.getSimpleName();


    /**
     * Modal- Invokes when user has changed passcode on other device and passocde authentication
     * failed on current device.
     * Added for US71614
     */
    public static void showFingerprintTempDisableModal(final Context context) {
        //Added for US71614. Reset fingerprint login status  after showing Fingerprint temp disabled modal.
        PortalUtils.setFingerprintLogin(false);
        /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
        TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_TEMP_UNAVAILABLE_OVERLAY_PG);
        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
        FingerPrintUtils fingerPrintUtils = new FingerPrintUtils(context);
        // Disable fingerprint, remove saved passcode and disable fingerprint on profile and settings.
        fingerPrintUtils.removeFingerprintPasscode();
        fingerPrintUtils.setFingerPrintStatus(false);
        FacadeFactory.getCardFacade().updateProfileSettingFingerPrintStatus(false, fingerPrintUtils.getUserId(context), context);

        final DiscoverAlertDialog fingerprintDisableDialog = new DiscoverAlertDialog();
        final int version = Build.VERSION.SDK_INT;
        if (version >= 21) {
            fingerprintDisableDialog.setIcon(ContextCompat.getDrawable(context, R.drawable.fingerprint_error_icon));
        } else {
            fingerprintDisableDialog.setIcon(context.getResources().getDrawable(R.drawable.fingerprint_error_icon));
        }

        fingerprintDisableDialog.setTitle(context.getString(R.string.title_fp_temporary_disable_dialog)).setMessage(context.getString(R.string.message_fp_temporary_disable_dialog)).
                setPositiveButton(context.getString(R.string.txt_fp_temporary_disable_doalog_positive), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                            /**Start Changes for US71879: Fingerpeint Site Catalyst Tags*/
                            //On the click of Reactivate Finger print button
                            HashMap<String, Object> extras = new HashMap<String, Object>();
                            extras.put(context.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_REACTIVATE_FINGERPRINT_BTN);
                            TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_REACTIVATE_FINGERPRINT_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                            /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/
                        // Set a Fingerprint setup deep-link code here
                        FacadeFactory.getCardFacade().setFingerprintSetupDeeplink(context);

                        /**Start changes for US79223*/
                        Toast toast = Toast.makeText(context, context.getString(R.string.msg_fp_shake_dialog_enable), Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        /**End changes for US79223*/

                    }
                }).setNegativeButton(context.getString(R.string.txt_fp_temporary_disable_doalog_negative), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    /**Start Changes for US71879: Fingerpeint Site Catalyst Tags*/
                    //On the click of Close link
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(context.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_CLOSE_LNK);
                    TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_TEMP_UNAVAILABLE_MODAL_CLOSE_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                    /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/
                fingerprintDisableDialog.dismiss();
            }
        }).setCanCancelable(true).setCanceledOnTouchOutside(false).
                show((AppCompatActivity) context);
    }

    public enum FPApiType {
        DEFAULT_GOOGLE_API, SAMSUNG_PASS_API
    }

    public static FPApiType availableFPApiType;

    public static void setAvailableFPApiType(FPApiType fPApiType) {
        availableFPApiType = fPApiType;
    }

    public static FPApiType getAvailableFPApiType() {
        return availableFPApiType;
    }

    public FingerPrintUtils(Context context) {
        this(context, !Globals.isBankLoginSelected());
    }

    public FingerPrintUtils(Context context, boolean iscardlogin) {

        this.context = context;

        if (iscardlogin) {
            this._FPSharedPref = context.getSharedPreferences(FILENAME_PREFS_FP_CARD, Activity.MODE_PRIVATE);
        } else {
            this._FPSharedPref = context.getSharedPreferences(FILENAME_PREFS_FP_BANK, Activity.MODE_PRIVATE);
        }
        this._FPSharedPrefEditor = _FPSharedPref.edit();

        this._FPSharedPref_SSO = context.getSharedPreferences(FILENAME_PREFS_FP_SSO, Activity.MODE_PRIVATE);
        this._FPSharedPrefEditor_SSO = _FPSharedPref_SSO.edit();

        // Also access for passcode util here
        passcodeUtils = new PasscodeUtils(context, iscardlogin);

        this._FPSharedPref_killswitch = context.getSharedPreferences(FILENAME_PREFS_FP_KILL_SWITCH, Activity.MODE_PRIVATE);
        this._FPSharedPrefEditor_killswitch = _FPSharedPref_killswitch.edit();

    }

    /**
     * Check if fingerprint hardware is present on device.
     * This method also checks which type of FP-API to use
     */
    @TargetApi(Build.VERSION_CODES.M)
    public static boolean isFingerprintHardwareAvailable(Context context) {

        setAvailableFPApiType(null);


        // Added for US76092. If device rooted return fingerprint status false.
        if (Utils.isRooted()) {
            return false;
        }

        /**For devices (like Samsung) that are upgraded from below M OS version to M & M+ version, method - isHardwareDetected() is always returning false though they have fingeprint sensor
         * on device level, so need to check hardware feasibility using Pass SDK - slende*/
        boolean isHardwareDetected = false;
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Need to do premission modal handling for M
                return false;
            }

            isHardwareDetected = ((FingerprintManager) context.getSystemService(Context.FINGERPRINT_SERVICE)).isHardwareDetected();
            Utils.log(TAG, "isFingerprintHardwareAvailable defaul API: OS vesrion : " + android.os.Build.VERSION.SDK_INT + " : " + isHardwareDetected);
        }

        if (!isHardwareDetected) {
            if (getManufacturer().equalsIgnoreCase(MANUFACTURER_SAMSUNG) && android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                Spass spass = new Spass();
                try {
                    spass.initialize(context);
                } catch (SsdkUnsupportedException e) {
                    e.printStackTrace();
                    return false;
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
                isHardwareDetected = spass.isFeatureEnabled(Spass.DEVICE_FINGERPRINT);
                if (isHardwareDetected) {
                    // Samsung Pass API available
                    setAvailableFPApiType(FPApiType.SAMSUNG_PASS_API);
                }
                Utils.log(TAG, "isFingerprintHardwareAvailable Samsung PASS API: OS vesrion : " + android.os.Build.VERSION.SDK_INT + " : " + isHardwareDetected);
                return isHardwareDetected;
            } else {
                //This device is not compatible.
                return isHardwareDetected;
            }
        } else {
            // Default google API available
            setAvailableFPApiType(FPApiType.DEFAULT_GOOGLE_API);
            return isHardwareDetected;
        }
    }


    /**
     * Check If there is atleast 1 fingerprint registered on device.
     */
    @TargetApi(Build.VERSION_CODES.M)
    public static boolean isFingerprintRegistered(Context context) {

        /**For devices (like Samsung) that are upgraded from below M - OS version to M & M+ version, method - hasEnrolledFingerprints() is always returning false though they have fingeprint registered
         * on device level, so need to check fingerprint enrollment using Pass SDK - slende*/
        boolean hasEnrolledFingerprints = false;
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Need to do premission modal handling for M
                return false;
            }
            //CrashLytics fix for #1161
            try {
                hasEnrolledFingerprints = ((FingerprintManager) context.getSystemService(Context.FINGERPRINT_SERVICE)).hasEnrolledFingerprints();
            }catch(SecurityException e){
                e.printStackTrace();
            }

        }

        if (!hasEnrolledFingerprints) {
            if (getManufacturer().equalsIgnoreCase(MANUFACTURER_SAMSUNG) && android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
             //Fix for crashlytics #309
                try {
                    hasEnrolledFingerprints = new SpassFingerprint(context).hasRegisteredFinger();
                }catch(UnsupportedOperationException e){
                    hasEnrolledFingerprints = false;
                    e.printStackTrace();
                }

                return hasEnrolledFingerprints;
            } else {
                //This device is not compatible.
                return hasEnrolledFingerprints;
            }
        } else {
            return hasEnrolledFingerprints;
        }
    }

    /**
     * Method return device manufacturer
     */
    public static String getManufacturer() {
        return Build.MANUFACTURER;
    }

    /**
     * This method gives  current user id
     */
    public String getUserId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Constants.PROFILE_SETTINGS_SHARED_PREF, Context.MODE_PRIVATE);
        String userId = prefs.getString(Constants.PROFILE_SETTINGS_CURRENT_USER_ID, null);
        if (userId != null && userId.equalsIgnoreCase(Constants.PROFILE_SETTINGS_INVALID_USER_ID)) {
            userId = null;
        }

        return userId;
    }

    /**
     * Encryption algorithms for passcode for US70151
     */
    public void storePasscodeForFingerPrint(String pcd) {
        final String encryptedPcd;
        //set/update user sharedpref with new/updated passcode
        /*if(PasscodeUtils.ssouser) {
            User.getInstance().setPasscodeToken(pcd);
            PortalSharedPreferenceUtil.getInstance().saveOrUpdatePasscodeToUserSharedPref();
        }*/
        if (!pcd.isEmpty()) {
            try {
                encryptedPcd = SecurityUtil.encrypt(pcd);
            } catch (final Exception e) {
                // Failed to encrypt user. Will not store on device.
                return;
            }
        } else { // No need to encrypt an empty String.
            encryptedPcd = pcd;
        }

        /**start SSO changes for FP-Login */
        if (PasscodeUtils.ssouser || passcodeUtils.hideToggle()) {
            _FPSharedPrefEditor_SSO.putString(FP_PASS_KEY, encryptedPcd);
            _FPSharedPrefEditor_SSO.commit();
        } else {
            _FPSharedPrefEditor.putString(FP_PASS_KEY, encryptedPcd);
            _FPSharedPrefEditor.commit();
        }
        /**end SSO changes for FP-Login */
    }

    /**
     * Decryption algorithms for passcode for US70151
     */
    public String getPasscodeFingerPrint() {

        /**start SSO changes for FP-Login */
        String user = "";
        String encryptedPcd = "";

        if (Globals.isLoggedIn()) {
            if (PasscodeUtils.ssouser) {
                encryptedPcd = _FPSharedPref_SSO.getString(FP_PASS_KEY, "");

            } else {
                encryptedPcd = _FPSharedPref.getString(FP_PASS_KEY, "");

            }
        } else if (passcodeUtils.hideToggle()) {
            encryptedPcd = _FPSharedPref_SSO.getString(FP_PASS_KEY, "");

        } else {
            encryptedPcd = _FPSharedPref.getString(FP_PASS_KEY, "");

        }

        /**end SSO changes for FP-Login */

        if (!encryptedPcd.isEmpty()) {
            try {
                user = SecurityUtil.decrypt(encryptedPcd);
            } catch (final Exception e) { // Failed to decrypt user.
                return StringUtility.EMPTY;
            }
        }
        return user;
    }

    /**
     * Removing the passcode from shared pref if passcode is removed
     */
    public void removeFingerprintPasscode() {
        try {
            _FPSharedPrefEditor.remove(FP_PASS_KEY);
            _FPSharedPrefEditor.commit();
            setFingerPrintStatus(false);

            /**start SSO changes for FP-Login */
            _FPSharedPrefEditor_SSO.remove(FP_PASS_KEY);
            _FPSharedPrefEditor_SSO.commit();
            /**end SSO changes for FP-Login */
        } catch (Exception e) {
        }
    }

    /**
     * Facade call to reset Fingerprint status on Pr0file & settings page; its card only method,
     * bank don't it
     */
    public void resetProfileSettingFingerPrintStatus() {
        FacadeFactory.getCardFacade().updateProfileSettingFingerPrintStatus(false, getUserId(this.context), this.context);
    }

    /**
     * Saving the fingerprint status in shared preference for US70151
     */
    public void setFingerPrintStatus(boolean isFingerprintStatus) {

        /**start SSO changes for FP-Login */
        if (PasscodeUtils.ssouser || passcodeUtils.hideToggle()) {
            _FPSharedPrefEditor_SSO.putBoolean(FP_ENABLE_STATUS_KEY, isFingerprintStatus);
            _FPSharedPrefEditor_SSO.commit();
        } else {
            _FPSharedPrefEditor.putBoolean(FP_ENABLE_STATUS_KEY, isFingerprintStatus);
            _FPSharedPrefEditor.commit();
        }
        /*Defect Fixed 166 : Setting the reminder flag true if Fingerprint is enable. */
        if(isFingerprintStatus){
            FacadeFactory.getWhatsNewReminderFacade().isAllowFingerPrintAccess(context, true);
        }
        /**end SSO changes for FP-Login */
    }

    /**
     * Method to clear FP status flag for SSO User too on Device Rooted or All registered
     * FP removed from device level
     */
    public void clearSSOFingerPrintStatus() {
        _FPSharedPrefEditor.putBoolean(FP_ENABLE_STATUS_KEY, false);
        _FPSharedPrefEditor.commit();
        _FPSharedPrefEditor_SSO.putBoolean(FP_ENABLE_STATUS_KEY, false);
        _FPSharedPrefEditor_SSO.commit();
    }

    /**
     * Getting the fingerprint status in shared preference for US70151
     */
    public boolean getFingerPrintStatus() {

        /**start SSO changes for FP-Login */

        boolean fpStatusBool;

        if (Globals.isLoggedIn()) {
            if (PasscodeUtils.ssouser) {
                fpStatusBool = _FPSharedPref_SSO.getBoolean(FP_ENABLE_STATUS_KEY, false);

            } else {
                fpStatusBool = _FPSharedPref.getBoolean(FP_ENABLE_STATUS_KEY, false);

            }
        } else if (passcodeUtils.hideToggle()) {
            fpStatusBool = _FPSharedPref_SSO.getBoolean(FP_ENABLE_STATUS_KEY, false);

        } else {
            fpStatusBool = _FPSharedPref.getBoolean(FP_ENABLE_STATUS_KEY, false);

        }
        return fpStatusBool;

        /**end SSO changes for FP-Login */
    }


    /**
     * Method to store fingerprint scanning failed count in shared preferences
     */
    public void setFPScanningFailedCount(int failureCount) {

        /**start SSO changes for FP-Login */
        if (PasscodeUtils.ssouser || passcodeUtils.hideToggle()) {
            _FPSharedPrefEditor_SSO.putInt(FP_SCANNING_FAILED_COUNT_KEY, failureCount);
            _FPSharedPrefEditor_SSO.commit();
        } else {
            _FPSharedPrefEditor.putInt(FP_SCANNING_FAILED_COUNT_KEY, failureCount).commit();
        }
        /**end SSO changes for FP-Login */
    }

    /**
     * Method to get fingerprint scanning failed count from shared preferences
     */
    public int getFPScanningFailedCount() {

        int fPScanningFailedCount;

        if (PasscodeUtils.ssouser || passcodeUtils.hideToggle()) {
            fPScanningFailedCount = _FPSharedPref_SSO.getInt(FP_SCANNING_FAILED_COUNT_KEY, 0);

        } else {
            fPScanningFailedCount = _FPSharedPref.getInt(FP_SCANNING_FAILED_COUNT_KEY, 0);

        }
        return fPScanningFailedCount;
    }

    /**
     * Method to get fingerprint scanning failure count from shared preferences
     */
    public void resetFPScanningFailedCount() {
        setFPScanningFailedCount(0);
    }


    /**
     * Method to set pre-login fingerprint kill-switch status.
     */
    public void setFPPreloginKillSwitchEnabled(boolean iskillSwitchEnabled) {
        _FPSharedPrefEditor_killswitch.putBoolean(FP_PRELOGIN_KILLSWITCH_STATUS_KEY, iskillSwitchEnabled);
        _FPSharedPrefEditor_killswitch.commit();
    }

    /**
     * Method to get pre-login fingerprint kill-switch status.
     */
    public boolean isFPPreloginKillSwitchEnabled() {
        return _FPSharedPref_killswitch.getBoolean(FP_PRELOGIN_KILLSWITCH_STATUS_KEY, false);
    }

    public static void trackFpSuccessAnalyticsTag() {

            /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put(AnalyticsPage.CONTEXT_MY_EVENTS, AnalyticsPage.FINGERPRINT_EVENT4);
            extras.put(AnalyticsPage.CONTEXT_MY_EVAR34, AnalyticsPage.FINGER_PRINT_LOG_IN);
            extras.put(AnalyticsPage.CONTEXT_MY_PROP34, AnalyticsPage.FINGER_PRINT_LOG_IN);
            TrackingHelper.trackCardPage(AnalyticsPage.FINGERPRINT_LOGIN_SUCCESSFUL, extras);
            /**End Changes for US71879: Fingerprint Site Catalyst Tags*/

    }
}
