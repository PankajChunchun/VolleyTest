package com.discover.mobile.common.shared.callback;

import java.util.Comparator;

class GenericCallbackListenerComparator implements Comparator<GenericCallbackListener> {

    @Override
    public int compare(final GenericCallbackListener lhs, final GenericCallbackListener rhs) {
        return lhs.getCallbackPriority().compareTo(rhs.getCallbackPriority());
    }

}
