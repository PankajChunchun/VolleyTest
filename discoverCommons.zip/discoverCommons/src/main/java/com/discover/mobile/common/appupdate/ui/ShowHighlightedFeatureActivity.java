package com.discover.mobile.common.appupdate.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.highlightedfeatures.ui.HighlightedFeaturesLandingFragment;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;


public class ShowHighlightedFeatureActivity extends ActionBarBaseActivity {
    public static final String GO_BACK_TO_LOGIN = "goBackToLogin";
    private boolean goBackToLogin = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if(Utils.checkPermissionTampering(this)){
            return;
        }
        /**Defect:1268 end**/
        setContentView(R.layout.show_highlighted_feature_container);

        showBackX();
        Bundle bundle = getIntent().getExtras();
        goBackToLogin = bundle.getBoolean(GO_BACK_TO_LOGIN, true);

        // US45209 Changes starts.
        HighlightedFeaturesLandingFragment fragment = new HighlightedFeaturesLandingFragment();
        bundle.putBoolean(ShowHighlightedFeatureActivity.GO_BACK_TO_LOGIN, goBackToLogin);
        fragment.setArguments(bundle);
        makeFragmentVisible(fragment);
        /*FacadeFactory.getHighlightedFeaturesFacade()
                .getPreloginHighlightedFeaturesFragment(this, null,
                        new NetworkRequestListener() {
                            @Override
                            public void onSuccess(Object data) {
                                Log.d("TEST", "From onSuccess. makeFragmentVisible");
                                makeFragmentVisible((Fragment) data);
                            }

                            @Override
                            public void onError(Object data) {
                                // TODO Show an error message here.
                            }
                        });*/
        // US45209 Changes end.

    }

    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }


    @Override
    public void onBackPressed() {
        final FragmentManager fragmentManager = getSupportFragmentManager();
        final int backStackCount = fragmentManager.getBackStackEntryCount();

        if (backStackCount > 1) {
            super.onBackPressed();
        } else if (goBackToLogin) {
            finish();
        } else {
            finish();
        }
    }

    /**
     * Method used to enable or disable sliding navigation menu. If disabled
     * then user will not be able to use a swipe gesture to see the navigation
     * menu.
     *
     * @param value True to enable sliding navigation menu, false otherwise.
     */
    public void enableSlidingMenu(final boolean value) {
       /* final SlidingMenu slidingMenu = getSlidingMenu();

        if (value) {
            slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
        } else {
            slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
        }*/
    }

    /*@Override
    public void disableMenuButton() {
        // TODO Auto-generated method stub
        super.disableMenuButton();
    }*/

    public void showBackX() {
        setActionbarBackNavigation(new Runnable() {
            @Override
            public void run() {
                onBackPressed();
            }
        });
    }
}
