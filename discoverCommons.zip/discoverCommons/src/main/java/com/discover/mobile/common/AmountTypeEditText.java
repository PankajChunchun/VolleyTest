package com.discover.mobile.common;

import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.StringUtility;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Created by pdesai2 on 7/8/2016.
 * <p/>
 * Implements the methods of the EditTextStrategy
 */
public class AmountTypeEditText implements EditTextStrategy {

    private static final Double MAX_AMOUNT = 999999.99;                      //max amount
    private static final int MAX_INT = 6;


    @Override
    public String textChange(String currentInput) {
        String formattedInput;
        formattedInput = CommonUtils.getDashlessString(currentInput);
        formattedInput = formattedInput.replaceAll("[$]", "");
        formattedInput = addDotAtIndex(formattedInput, MAX_INT);

        return formattedInput;
    }

    private String addDotAtIndex(String formattedInput, int index) {
        //Adds a dollar sign and "." after the 6th character
        if (formattedInput.length() > index && !formattedInput.contains(".")) {
            formattedInput = StringUtility.DOLLAR_SIGN + formattedInput.substring(0, index)
                    + "." + formattedInput.substring(index);
            return formattedInput;
        }
        //if the string is empty then don't display dollar sign
        else if (formattedInput.equals("")) {
            formattedInput = "";
            return formattedInput;
        } else {
            formattedInput = StringUtility.DOLLAR_SIGN + formattedInput;
            //if the current string has a "." in it then restrict for only 2 more characters to be inputted
            if (formattedInput.contains(".")) {
                //if total length - the index of "." isnt greater than 3 than allow user to continue inputting
                if (!((formattedInput.length() - formattedInput.indexOf(".")) > 3)) {
                    return formattedInput;
                }
                //else only keep of the substring of the valid number of inputted characters;
                else {
                    int decimal = formattedInput.length() - ((formattedInput.length() - formattedInput.indexOf(".")) - 3);
                    return formattedInput.substring(0, decimal);
                }
            }
            return formattedInput;

        }
    }

    //formats the amount with a $ sign and commas properly, even decimals
    @Override
    public String postTextChange(String currentInput) {
        String checkText = currentInput.replaceAll("[$,]", "");
        /*To Fix crash issue when running in device English_UK or other language*/
        Locale locale = new Locale("en", "US");
        NumberFormat defaultFormat = NumberFormat.getCurrencyInstance(locale);

        String newStyleString;
        //decimal formatting
        if (checkText.contains(".")) {
            checkText = decimalFix(checkText);
            checkText = checkText.replaceAll("[.]", "");
            Double currentAmount = Double.parseDouble(checkText);
            newStyleString = defaultFormat.format(currentAmount / 100);
            return newStyleString;
        } else {
            Double currentAmount = Double.parseDouble(checkText);
            newStyleString = defaultFormat.format(currentAmount);
            return newStyleString;
        }
    }

    public String decimalFix(String checkText) {
        if (checkText.indexOf(".") == (checkText.length() - 1)) {
            checkText += "00";
            return checkText;
        } else if (checkText.indexOf(".") == (checkText.length() - 2)) {
            checkText += "0";
            return checkText;
        } else {
            return checkText;
        }
    }


    //checks for a valid amount
    @Override
    public Boolean textCheck(int length, String currentInput) {

        String checkText = currentInput.replaceAll("[$,]", "");
        if (checkText.contains(".")) {
            checkText = checkText.replaceAll("[.]", "");
            try {
                Double currentAmount = Double.parseDouble(checkText);
                if ((currentAmount / 100) <= MAX_AMOUNT) {
                    return true;
                }
            } catch (Exception e) {
                return false;
            }
        } else {
            try {
                Double currentAmount = Double.parseDouble(checkText);
                if (currentAmount <= MAX_AMOUNT) {
                    return true;
                }
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
}
