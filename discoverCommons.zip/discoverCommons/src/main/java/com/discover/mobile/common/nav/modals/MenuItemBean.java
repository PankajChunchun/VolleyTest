package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

/**
 * Created by 468195 on 2/16/2016.
 */
public class MenuItemBean {
   /* public static enum MENU_TYPE {ACTION_ITEM,OVERFLOW_ITEM};*/

    @SerializedName("isActionItem")
    private boolean isActionItem;
    @SerializedName("menuTitle")
    private String menuTitle = "";
    @SerializedName("icon")
    private String icon;
    @SerializedName("position")
    private int position;
    @SerializedName("isNormalUser")
    private boolean isNormalUser;

    public boolean isNormalUser() {
        return isNormalUser;
    }

    public void setNormalUser(boolean isNormalUser) {
        this.isNormalUser = isNormalUser;
    }


    /*  public MENU_TYPE isIsActionItem() {

          if(isActionItem)
          {
              return MENU_TYPE.ACTION_ITEM;
          }
          return MENU_TYPE.OVERFLOW_ITEM;
      }*/
    public void setIsActionItem(boolean mIsActionItem) {
        this.isActionItem = mIsActionItem;
    }

    public String getmTitle() {
        return menuTitle;
    }

    public void setmTitle(String mTitle) {
        this.menuTitle = mTitle;
    }

    public String getmMenuImage() {
        return icon;
    }

    public void setmMenuImage(String mMenuImage) {

        this.icon = mMenuImage;
    }

    public int getmPosition() {
        return position;
    }

    public void setmPosition(int mPosition) {
        this.position = mPosition;
    }


}
