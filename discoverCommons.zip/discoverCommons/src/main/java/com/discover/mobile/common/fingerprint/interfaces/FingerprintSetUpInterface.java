package com.discover.mobile.common.fingerprint.interfaces;

import com.discover.mobile.common.shared.net.NetworkRequestListener;

import android.content.Context;

/**
 * UI Interface implemented by {@link CardDrawerActivity} . used to get callbacks
 * to update the UI & Service call for FingerPrintSetup
 */
public interface FingerprintSetUpInterface {
    void showSetupPcdFpModel();

    void matchPcdFpService(String passcode, final NetworkRequestListener listener);

    void privacyTermsClickListener();

    void feedbackClickListener();

    void navToHome();

    void updateProfileSettingFingerPrintStatus(boolean isSuccess, String userId, Context context);

    void enableBackNavigationForFingerPrint(boolean isEnabled);

}
