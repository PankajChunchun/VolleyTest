package com.discover.mobile.common.nav.section;

import android.support.v4.app.Fragment;
import android.view.View.OnClickListener;

import javax.annotation.concurrent.Immutable;

//import com.actionbarsherlock.app.SherlockFragment;

/**
 * This Component info class accepts a fragment class. The default action for this is to just
 * transition the fragment into view.
 *
 * @author ajleeds
 */
@Immutable
public class FragmentComponentInfo extends ComponentInfo {

    private final Class<? extends Fragment> fragmentClass;

    public FragmentComponentInfo(final int titleResource, final Class<? extends Fragment> fragmentClass) {
        super(titleResource);
        this.fragmentClass = fragmentClass;
    }

    public FragmentComponentInfo(final int titleResource, final boolean isicon, final Class<? extends Fragment> fragmentClass) {
        super(titleResource, isicon);
        this.fragmentClass = fragmentClass;
    }

    public FragmentComponentInfo(final int titleResource, final boolean showPushCount, final OnClickListener pushCLickListener, final Class<? extends Fragment> fragmentClass) {
        super(titleResource, showPushCount, pushCLickListener);
        this.fragmentClass = fragmentClass;
    }

    public final Class<? extends Fragment> getFragmentClass() {
        return fragmentClass;
    }

}
