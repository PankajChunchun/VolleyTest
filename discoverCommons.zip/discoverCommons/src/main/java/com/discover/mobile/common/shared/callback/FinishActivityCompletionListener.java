package com.discover.mobile.common.shared.callback;

import com.discover.mobile.common.shared.callback.GenericCallbackListener.CompletionListener;
import com.discover.mobile.common.shared.net.NetworkServiceCall;

import android.app.Activity;

public class FinishActivityCompletionListener implements CompletionListener {

    private final Activity activity;

    public FinishActivityCompletionListener(final Activity activityToFinish) {
        activity = activityToFinish;
    }

    @Override
    public CallbackPriority getCallbackPriority() {
        return CallbackPriority.LAST;
    }

    @Override
    public void complete(final NetworkServiceCall<?> sender, final Object result) {
        activity.finish();
    }

}
