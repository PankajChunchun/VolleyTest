package com.discover.mobile.common.appmessaging.helper;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Class to hold app target message list
 * US159289 - Update target messaging end point
 */

public class AppTargetMessageList {

    @SerializedName("targets")
    private List<AppMessage> mAppMessageList;

    public List<AppMessage> getAppMessageList() {
        return mAppMessageList;
    }

    public void setAppMessageList(List<AppMessage> appMessageList) {
        mAppMessageList = appMessageList;
    }

}
