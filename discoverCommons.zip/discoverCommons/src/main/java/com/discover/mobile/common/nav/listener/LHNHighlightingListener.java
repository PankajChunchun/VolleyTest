package com.discover.mobile.common.nav.listener;

import android.support.v4.app.Fragment;

/**
 * Interface which is used as a listener for highlighting
 * the LHN menu items explicitly
 */
public interface LHNHighlightingListener {

    public void onHighlightingChanged(Fragment fragment);

}
