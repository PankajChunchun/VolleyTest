package com.discover.mobile.common;

/**
 * Created by pdesai2 on 7/8/2016.
 *
 * Interface for AmountTypeEditText,PhoneTypeEditText,ZipTypeEditText
 */
public interface EditTextStrategy {

    public String textChange(String currentInput);
    public String postTextChange(String currentInput);
    public Boolean textCheck(int length, String currentInput);

}
