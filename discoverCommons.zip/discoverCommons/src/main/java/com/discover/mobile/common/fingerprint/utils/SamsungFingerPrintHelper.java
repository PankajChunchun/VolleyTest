package com.discover.mobile.common.fingerprint.utils;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.discover.mobile.common.fingerprint.listener.FingerPrintListener;
import com.discover.mobile.common.fingerprint.listener.DiscoverFingerPrintManager;
import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.pass.Spass;
import com.samsung.android.sdk.pass.SpassFingerprint;
import com.samsung.android.sdk.pass.SpassInvalidStateException;


/**
 * Helper class for fingerprint authentication using Samsung fingerprint sdk.
 */
public class SamsungFingerPrintHelper implements DiscoverFingerPrintManager, Handler.Callback, SpassFingerprint.IdentifyListener {


    private static final int MSG_AUTH = 100;

    @Override
    public void startListening() {
        startIdentify();
    }

    @Override
    public void stopListening() {

        stopIdentify();

    }


    private final Spass mSpass;
    private SpassFingerprint mSpassFingerprint;
    private FingerPrintListener fingerPrintListener;
    private Context mContext;
    private Handler mHandler;
    private boolean shouldRetry = false;

    public SamsungFingerPrintHelper(Context context, FingerPrintListener fingerPrintListener) {
        mSpass = new Spass();

        try {
            mSpass.initialize(context);
        } catch (SsdkUnsupportedException e) {
            e.printStackTrace();
        }
        mSpassFingerprint = new SpassFingerprint(context);
        this.fingerPrintListener = fingerPrintListener;
        this.mContext = context;
        mHandler = new Handler(this);
    }


    /**
     * Calls system setting to add fingerprint.
     */
    private void registerFingerprint() {
        if (mSpassFingerprint != null) {
            mSpassFingerprint.registerFinger(mContext, mRegisterListener);
        }


    }


    /**
     * Calls when fingerprint is registered.
     */
    private SpassFingerprint.RegisterListener mRegisterListener = new SpassFingerprint.RegisterListener() {
        @Override
        public void onFinished() {
            Toast.makeText(mContext, "RegisterListener.onFinished()", Toast.LENGTH_LONG).show();
        }
    };


    /**
     * Start Identifying fingerprint without Samsung default dialog.
     */
    private void startIdentify() {

        try {

            if (mSpassFingerprint != null) {

                Log.d("test", "startIdentify");
                shouldRetry = false;
                mSpassFingerprint.startIdentify(this);
            }

        } catch (SpassInvalidStateException ise) {
            if (ise.getType() == SpassInvalidStateException.STATUS_OPERATION_DENIED) {
                ise.printStackTrace();
            }
        } catch (IllegalStateException e) {

            e.printStackTrace();
        }


    }


    /**
     * Stop/cancel fingerprint identify.
     */
    private void stopIdentify() {
//        if (mSpassFingerprint != null) {
//            mSpassFingerprint.cancelIdentify();
//        }
    }


    @Override
    public boolean handleMessage(Message msg) {
        switch (msg.what) {
            case MSG_AUTH:

                if (shouldRetry) {

                    startListening();
                }

                break;
        }
        return true;
    }

    @Override
    public void onFinished(int eventStatus) {
        //CrashLytics fix 637
        int FingerprintIndex = 0;
        String fingerPrintGuideText = "Failed to identify. Please try again";
        try {
            FingerprintIndex = mSpassFingerprint.getIdentifiedFingerprintIndex();
        } catch (IllegalStateException ise) {
            ise.printStackTrace();
        }
        if (eventStatus == SpassFingerprint.STATUS_AUTHENTIFICATION_SUCCESS) {
            shouldRetry = false;
            fingerPrintListener.onAuthenticated();
        } else if (eventStatus == SpassFingerprint.STATUS_OPERATION_DENIED) {
        } else if (eventStatus == SpassFingerprint.STATUS_USER_CANCELLED) {
        } else if (eventStatus == SpassFingerprint.STATUS_TIMEOUT_FAILED) {
        } else if (eventStatus == SpassFingerprint.STATUS_QUALITY_FAILED) {
            //mSpassFingerprint.getGuideForPoorQuality();
            fingerPrintListener.onAuthenticationHelp(fingerPrintGuideText);
            shouldRetry = true;
        } else {
            shouldRetry = true;
            fingerPrintListener.onError(fingerPrintGuideText);
        }
    }

    @Override
    public void onReady() {
        Log.d("test", "identify state is ready");
    }

    @Override
    public void onStarted() {
        Log.d("test", "User touched fingerprint sensor");
    }

    @Override
    public void onCompleted() {
        Log.d("test", "Samsung: onCompleted");

        mHandler.sendEmptyMessageDelayed(MSG_AUTH, 300);
    }
}
