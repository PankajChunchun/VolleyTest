package com.discover.mobile.common.shared.net.error;

public class HttpOnlyErrorResponse extends AbstractErrorResponse<HttpOnlyErrorResponse> {

    private static final long serialVersionUID = -2244898115736590761L;

    @Override
    public ErrorMessageMapper<HttpOnlyErrorResponse> getMessageMapper() {
        // TODO Auto-generated method stub
        return null;
    }

}
