package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import android.annotation.SuppressLint;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

@SuppressLint("UseSparseArrays")
public class AccountV2Details implements Serializable {
    private static final long serialVersionUID = -2497840246707962372L;

    private LinkedHashMap<String, CardAccount> cardAccountsMap = new LinkedHashMap<String, CardAccount>();

    private LinkedHashMap<Integer, LoanAccount> loanAccountsMap = new LinkedHashMap<Integer, LoanAccount>();

    private LinkedHashMap<Integer, DepositAccount> depositAccountsMap = new LinkedHashMap<Integer, DepositAccount>();

    private LinkedHashMap<Integer, IraPlan> iraPlansMap = new LinkedHashMap<Integer, IraPlan>();

    private String bankSummaryStatus;

    private boolean isSSOUser;

    private String payLoadSSOText;

    private DynamicProperties dynamicProperties;

    private String partyId;

    private boolean errorRetrievingCardData;

    private boolean errorRetrievingBankData;

    private boolean isUserIdAvailable;

    private String customerFirstName;

    private String userId;

    public DynamicBannerMessages getDynamicBannerMessages() {
        return dynamicBannerMessages;
    }

    public void setDynamicBannerMessages(DynamicBannerMessages dynamicBannerMessages) {
        this.dynamicBannerMessages = dynamicBannerMessages;
    }

    @SerializedName("dynamicBannerMessages")
    private DynamicBannerMessages dynamicBannerMessages;

    @SerializedName("gatewayOauthURL")
    private String gatewayOauthURL;

    /** start Added for US38219 CLA merge intercept page */
    @SerializedName("isForceMerge")
    private Boolean isForceMerge;

    public Boolean isForceMerge() {
        if (null != isForceMerge)
            return isForceMerge;
        else
            return false;
    }

    public void setIsForceMerge(Boolean forceMerge) {
        isForceMerge = forceMerge;
    }

    /** end Added for US38219 CLA merge intercept page */

    /** start newly added field for US48093 changes */

    @SerializedName("isMergeEligible")
    private Boolean isMergeEligible;

    // US126324 Changes - start
    @SerializedName("isInitialSkipAttempt")
    private boolean isInitialSkipAttempt;
    // US126324 Changes - end

    @SerializedName("isEDSFiltered")
    private Boolean isEDSFiltered;
    @SerializedName("jointCardsLastFourDigitList")
    private List<String> jointCardsLastFourDigitList = new ArrayList<String>();

    public LinkedHashMap<String, CardAccount> getCardAccountsMap() {
        return cardAccountsMap;
    }

    public void setCardAccountsMap(List<CardAccount> cardAccountsList) {
        if (null != cardAccountsList && cardAccountsList.size() > 0) {
            for (CardAccount cardAcc : cardAccountsList) {
                this.cardAccountsMap.put(cardAcc.getAcctKey(), cardAcc);
            }
        }
    }

    public CardAccount getCardAccountsMapOnEDSKey(String edsKey) {
        return cardAccountsMap.get(edsKey);
    }

    public LinkedHashMap<Integer, LoanAccount> getLoanAccountsMap() {
        return loanAccountsMap;
    }

    public void setLoanAccountsMap(List<LoanAccount> loanAccountsList) {
        if (null != loanAccountsList && loanAccountsList.size() > 0) {
            for (LoanAccount loanAcc : loanAccountsList) {
                this.loanAccountsMap.put(loanAcc.getIndex(), loanAcc);
            }
        }
    }

    public LoanAccount getLoanAccountsMapOnIndex(int index) {
        return loanAccountsMap.get(index);
    }

    public LinkedHashMap<Integer, DepositAccount> getDepositAccountsMap() {
        return depositAccountsMap;
    }

    public void setDepositAccountsMap(List<DepositAccount> depositAccountsList) {
        if (null != depositAccountsList && depositAccountsList.size() > 0) {
            for (DepositAccount depositAcc : depositAccountsList) {
                this.depositAccountsMap.put(depositAcc.getIndex(), depositAcc);
            }
        }
    }

    public DepositAccount getDepositAccountsMapOnIndex(Integer index) {
        return depositAccountsMap.get(index);
    }

    public LinkedHashMap<Integer, IraPlan> getIraPlansMap() {
        return iraPlansMap;
    }

    public void setIraPlansMap(List<IraPlan> iraPlansList) {
        if (null != iraPlansList && iraPlansList.size() > 0) {
            for (IraPlan iraPlan : iraPlansList) {
                this.iraPlansMap.put(iraPlan.getIndex(), iraPlan);
            }
        }
    }

    public IraPlan getIraPlansMapOnIndex(Integer index) {
        return iraPlansMap.get(index);
    }

    public String getBankSummaryStatus() {
        /**start fix for 7.8 Regression Defect# 445 */
        if (null != bankSummaryStatus)
            return bankSummaryStatus;
        else
            return "";
        /**end fix for 7.8 Regression Defect# 445 */
    }

    public void setBankSummaryStatus(String bankSummaryStatus) {
        this.bankSummaryStatus = bankSummaryStatus;
    }

    public boolean isSSOUser() {
        return isSSOUser;
    }

    public void setSSOUser(boolean isSSOUser) {
        this.isSSOUser = isSSOUser;
    }

    public String getPayLoadSSOText() {
        return payLoadSSOText;
    }

    public void setPayLoadSSOText(String payLoadSSOText) {
        this.payLoadSSOText = payLoadSSOText;
    }

    public Boolean isEDSFiltered() {
        return isEDSFiltered;
    }

    public void setIsEDSFiltered(Boolean isEDSFiltered) {
        this.isEDSFiltered = isEDSFiltered;
    }

    public Boolean isMergeEligible() {
        return isMergeEligible;
    }

    public void setIsMergeEligible(Boolean isMergeEligible) {
        this.isMergeEligible = isMergeEligible;
    }

    public List<String> getJointCardsLastFourDigitList() {
        return jointCardsLastFourDigitList;
    }

    public void setJointCardsLastFourDigitList(List<String> jointCardsLastFourDigitList) {
        this.jointCardsLastFourDigitList = jointCardsLastFourDigitList;
    }

    /** end newly added field for US48093 changes */

    public DynamicProperties getDynamicProperties() {
        return dynamicProperties;
    }

    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public boolean isErrorRetrievingCardData() {
        return errorRetrievingCardData;
    }

    public void setErrorRetrievingCardData(boolean errorRetrievingCardData) {
        this.errorRetrievingCardData = errorRetrievingCardData;
    }

    public boolean isErrorRetrievingBankData() {
        return errorRetrievingBankData;
    }

    public void setErrorRetrievingBankData(boolean errorRetrievingBankData) {
        this.errorRetrievingBankData = errorRetrievingBankData;
    }

    public boolean isUserIdAvailable() {
        return isUserIdAvailable;
    }

    public void setUserIdAvailable(boolean isUserIdAvailable) {
        this.isUserIdAvailable = isUserIdAvailable;
    }

    public void deleteAll() {
        cardAccountsMap.clear();
        loanAccountsMap.clear();
        depositAccountsMap.clear();
        iraPlansMap.clear();
    }

    public void deleteCardAccounts() {
        // TODO: In future we have to change implementation.
        deleteAll();
    }

    public void deleteBankAccounts() {
        // TODO: In future we have to change implementation.
        deleteAll();
    }

    public void deleteCardAcct(String edsKey) {
        if (this.cardAccountsMap.containsKey(edsKey)) {
            this.cardAccountsMap.remove(edsKey);
        }
    }

    public void deleteLoanAcct(String index) {
        if (this.loanAccountsMap.containsKey(index)) {
            this.loanAccountsMap.remove(index);
        }
    }

    public void deleteDepositAcct(String index) {
        if (this.depositAccountsMap.containsKey(index)) {
            this.depositAccountsMap.remove(index);
        }
    }

    public void deleteIraPlans(String index) {
        if (this.iraPlansMap.containsKey(index)) {
            this.iraPlansMap.remove(index);
        }
    }

    public boolean isCardAccountExist(String edsKey) {
        return this.cardAccountsMap.containsKey(edsKey);
    }

    public boolean isLoanAccountExist(String index) {
        return this.loanAccountsMap.containsKey(index);
    }

    public boolean isDepositAccountExist(String index) {
        return this.depositAccountsMap.containsKey(index);
    }

    public boolean isIraPlanExist(String index) {
        return this.iraPlansMap.containsKey(index);
    }

    public String getCustomerFirstName() {
        return customerFirstName;
    }

    public void setCustomerFirstName(String customerFirstName) {
        this.customerFirstName = customerFirstName;
    }

    public String getGatewayOauthURL() {
        return gatewayOauthURL;
    }

    public void setGatewayOauthURL(String gatewayOauthURL) {
        this.gatewayOauthURL = gatewayOauthURL;
    }

    // US126324 Changes - start
    public boolean isInitialSkipAttempt() {
        return isInitialSkipAttempt;
    }

    public void setInitialSkipAttempt(boolean initialSkipAttempt) {
        this.isInitialSkipAttempt = initialSkipAttempt;
    }
    // US126324 Changes - end
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
