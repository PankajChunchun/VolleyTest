package com.discover.mobile.common.onboardwiz.utils;

/**
 * Created this interface to handle onboarding service classes success and failure scenarios
 */

import android.content.Context;

public interface BankOnBoardingCallBack {
    // Service success call back handler
    void success(Context mContext);

    // Failure success call back handler
    void failure(Context mContext);

    //Function call back based on device bind/unbind
    void deviceAlreadyBinded(Context mContext);

    //Helpful to make decision either to display error modal or not
    boolean showErrorModal();

}
