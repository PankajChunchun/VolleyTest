package com.discover.mobile.common.liveperson;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.discover.mobile.common.R;
import com.discover.mobile.common.net.cookie.SessionCookieManager;
import com.discover.mobile.common.push.receive.XtifyEventReceiver;
import com.liveperson.messaging.sdk.api.LivePerson;

/**
 * Created by 436645 on 3/16/2017.
 */
public class LPPushNotificationImpl implements LPPushNotification {

    public LPPushNotificationImpl(){};


    @Override
    public void registerLPPushNotification(Context context, String edsKey) {
        Intent intent = new Intent(context, LPRegistrationService.class);
        intent.putExtra(LivePersonConstants.KEY_EDSKEY, edsKey);
        context.startService(intent);
    }

    @Override
    public void unRegisterLPPushNotification() {
        LivePerson.unregisterLPPusher(LivePersonConstants.brandID, LivePersonConstants.appID);
    }


    @Override
    public void handlePush(String title, String contentText,
                           String payload, int notificationId, Context context) {

        sendNotification(title, contentText, payload, notificationId, context);
    }

    private void sendNotification(String title, String contentText,
                                  String payload, int notificationId, Context context) {
        try {

            NotificationManager mNotificationManager = (NotificationManager) context
                    .getSystemService(Context.NOTIFICATION_SERVICE);

            Intent notificationIntent = new Intent();
            notificationIntent
                    .setAction("com.xtify.sdk.EVENT_NCK");

            notificationIntent.putExtra("data.customKey", payload);
            notificationIntent.putExtra("com.xtify.sdk.NOTIFICATION_TITLE", title);
            notificationIntent.putExtra("com.discover.mobile.notificationId",
                    notificationId);
            PendingIntent contentIntent = PendingIntent.getBroadcast(context,
                    (int) System.currentTimeMillis(), notificationIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);

            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                    context)

                    .setSmallIcon(R.drawable.discove_mobile_icn)
                    .setContentTitle(title)
                    .setContentText(contentText)
                    .setDefaults(Notification.DEFAULT_ALL)
                    //We shoudl not comment out and this is needed for avoid duplicate at Watch side notification.
                    .setLocalOnly(true)
                    .setDeleteIntent(
                            createOnDismissedIntent(context, notificationId, payload, title))
                    // requires
                    // VIBRATE
                    // permission

                    .setContentIntent(contentIntent);

            mBuilder.setAutoCancel(true);
            mBuilder.setContentIntent(contentIntent);
            /*Defect Fixed: 10249*/
            if (SessionCookieManager.getInstance().getSecToken() != null && !SessionCookieManager.getInstance().getSecToken().equalsIgnoreCase("")) {
                mBuilder.setPriority(Notification.PRIORITY_HIGH);
            }
            mNotificationManager.notify(notificationId, mBuilder.build());
            Log.d("TAG", "Notification sent successfully.");
        } catch (Exception e) {

        }

    }

    private PendingIntent createOnDismissedIntent(Context context,
                                                  int notificationId, String payload, String title) {
        Intent intent = new Intent(context, XtifyEventReceiver.class);
        intent.setAction("com.discover.mobile.notificationdismiss");
        intent.putExtra("com.discover.mobile.notificationId", notificationId);
        intent.putExtra("data.customKey", payload);
        intent.putExtra("com.xtify.sdk.NOTIFICATION_TITLE", title);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context.getApplicationContext(), notificationId, intent, 0);

        return pendingIntent;
    }
}
