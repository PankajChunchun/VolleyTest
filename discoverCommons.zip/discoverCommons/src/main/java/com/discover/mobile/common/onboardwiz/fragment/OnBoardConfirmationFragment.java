package com.discover.mobile.common.onboardwiz.fragment;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.service.OnBoardServiceClass;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.image.FileDownloader;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.uiwidget.CmnButton;
import com.discover.mobile.common.uiwidget.CmnTextView;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.HashMap;

/**
 * Created by 494005 on 5/3/2016.
 */
public class OnBoardConfirmationFragment extends Fragment implements View.OnClickListener {
    private final static String mConfirmationText = "onboard_confirmation_text";
    private View view, devider, alertSection;
    private CmnButton yesButton, homeButton, exitButton, notNowTxt;
    private CmnTextView mSuccessmessge;
    private Context mContext;
    private View onboard_alret_dp_layout, onboard_androidpay_dp_layout;
    private CmnButton getStartedBtn, notNowAnBtn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        int resourceToInflate;
        if (Globals.isBankLoginSelected()) {
            resourceToInflate = R.layout.onboard_confirmation_bank;
        } else {
            resourceToInflate = R.layout.onboard_confirmation;
        }
        view = inflater.inflate(resourceToInflate, null);
        init(view);
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    (R.string.bank_analytics_onboard_confirmation_pg));

        }
        //US53334 End
        //US53328-START
        if (Globals.isFromCardSide()) {
            TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_CONFIRMATION_SCREEN_PAGE_NAME, null);
        }
        //ends

        return view;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    private void init(View view) {
        if (Globals.isBankLoginSelected()) {
            homeButton = (CmnButton) view.findViewById(R.id.homeButton);
            homeButton.setOnClickListener(this);
        }
        onboard_alret_dp_layout = view.findViewById(R.id.onboard_alret_dp_layout);
        onboard_androidpay_dp_layout = view.findViewById(R.id.onboard_androidpay_dp_layout);
        mSuccessmessge = (CmnTextView) view.findViewById(R.id.confirmationText);
        CommonUtils.setDisplayText(mSuccessmessge, mConfirmationText, getResources().getString(R.string.onboard_confirmation));
    }

    /*Start Changes US139848*/
    private void showAndroidPayPrompt(View view) {
        onboard_alret_dp_layout.setVisibility(View.GONE);
        onboard_androidpay_dp_layout.setVisibility(View.VISIBLE);
        exitButton = (CmnButton) view.findViewById(R.id.btn_exit);
        getStartedBtn = (CmnButton) onboard_androidpay_dp_layout.findViewById(R.id.getStartedBtn);
        notNowAnBtn = (CmnButton) onboard_androidpay_dp_layout.findViewById(R.id.notNowBtn);
        exitButton.setOnClickListener(this);
        getStartedBtn.setOnClickListener(this);
        notNowAnBtn.setOnClickListener(this);
    }
     /*End Changes US139848*/

     private void showManageAlretPrompt(View view){
         onboard_alret_dp_layout.setVisibility(View.VISIBLE);
         onboard_androidpay_dp_layout.setVisibility(View.GONE);
         ImageView alertsImage = (ImageView) view.findViewById(R.id.imageView);
         Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_alerts);
         CommonUtils.setBitmapImage(alertsImage, ImageDir.DIR_ENUM.ONBOARDING, "onboard_alerts.png", defaultBitmap);

         exitButton = (CmnButton) view.findViewById(R.id.btn_exit);
         yesButton = (CmnButton) view.findViewById(R.id.yesbutton);
         notNowTxt = (CmnButton) view.findViewById(R.id.notnowbutton);
         exitButton.setOnClickListener(this);
         yesButton.setOnClickListener(this);
         notNowTxt.setOnClickListener(this);
     }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.yesbutton) {
            //US53328-START
            if (Globals.isFromCardSide()) {
                analyticsForYesButton();
            }
            //ends
            if (getActivity() instanceof OnBoardActivity) {
                FacadeFactory.getCardOnBoardFacadeImpl().launchPushAlerts(getActivity());
                //for defect : 243856 --STARTS
                //OnBoardHelper.navigateToCardOrBankHome();

                ((OnBoardActivity) (DiscoverActivityManager.getActiveActivity())).navToCardWithoutLogo();

                //ENDS

            }

        } else if (v.getId() == R.id.notnowbutton) {
            //US53328-STARTED
            if (Globals.isFromCardSide()) {
                analyticsForNotNowButton();
            }
            //ENDS

            OnBoardHelper.navigateToCardOrBankHome();

        } else if (v.getId() == R.id.btn_exit) {
            if (getActivity() instanceof OnBoardActivity) {

                //US53328-STARTS
                if (Globals.isFromCardSide()) {
                    analyticsOnExitSetup();
                    //ENDS
                }
                OnBoardHelper.navigateToCardOrBankHome();
            }

        } else if (v.getId() == R.id.homeButton) {
            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_home_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_confirmation_pg));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
            //US53334 End
            OnBoardHelper.navigateToCardOrBankHome();

        } else if (v.getId() == R.id.btn_exit) {
            //US53328-STARTS
            if (Globals.isFromCardSide()) {
                analyticsOnExitSetup();
            }
            //ENDS
            OnBoardHelper.navigateToCardOrBankHome();
        } else if (v.getId() == R.id.notNowBtn) {
            //Navigate to AC Home Page
            OnBoardHelper.navigateToCardOrBankHome();
            /*Start Changes for US139848*/
        } else if (v.getId() == R.id.getStartedBtn) {
            //Navigate to Android Pay Provisioning Flow
            FacadeFactory.getCardOnBoardFacadeImpl().launchEwalletFlow(mContext);
            ((OnBoardActivity) (DiscoverActivityManager.getActiveActivity())).navToCardWithoutLogo();
        }
          /*End Changes for US139848*/
        FileDownloader.getInstance().flushImages(ImageDir.DIR_ENUM.ONBOARDING);
    }

    //US53328-START


    public void analyticsForYesButton() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PROP13);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_YES_BUTTON_PEV1);


        TrackingHelper.trackCardPage(null, extras);


    }

    public void analyticsForNotNowButton() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PROP13);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_NOT_NOW_LINK_PEV1);


        TrackingHelper.trackCardPage(null, extras);


    }

    /**
     * Called when the Fragment is visible to the user.  This is generally
     * tied to {@link Activity#onStart() Activity.onStart} of the containing
     * Activity's lifecycle.
     */
    @Override
    public void onStart() {
        super.onStart();
        if (Globals.isFromCardSide()) {
            if (FacadeFactory.getWalletHelperFacade().isDeviceAndroidPayEligibile(mContext)) {
                OnBoardServiceClass onBoardServiceClass = new OnBoardServiceClass(mContext);
                onBoardServiceClass.getEwalletEligiblityService(mContext, new NetworkRequestListener() {
                    @Override
                    public void onSuccess(Object data) {
                        if (FacadeFactory.getWalletHelperFacade().isUserAndroidPayEligible(mContext)) {
                            showAndroidPayPrompt(view);
                        } else {
                            showManageAlretPrompt(view);
                        }
                    }

                    @Override
                    public void onError(Object data) {
                        showManageAlretPrompt(view);
                    }
                });
            } else {
                showManageAlretPrompt(view);
            }
        }
    }

    public void analyticsOnExitSetup() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_CONFIRMATION_SCREEN_PAGE_NAME);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PEV1);
        extras.put(getActivity().getString(R.string.evar35), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_VAR35);


        TrackingHelper.trackCardPage(null, extras);
    }

}
