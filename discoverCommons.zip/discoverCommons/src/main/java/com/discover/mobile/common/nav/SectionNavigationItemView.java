package com.discover.mobile.common.nav;

import com.discover.mobile.common.R;
import com.discover.mobile.common.nav.section.ComponentInfo;
import com.discover.mobile.common.shared.utils.StringUtility;

import android.view.View;
import android.widget.TextView;

/**
 * Class representing a section item in the menu
 *
 * @author jthornton
 */
public final class SectionNavigationItemView extends NavigationItemView {

    /** Component info associated with this view */
    private final ComponentInfo info;

    /**
     * Constructor for the class
     *
     * @param componentInfo - component info to associate with the class
     */
    public SectionNavigationItemView(final ComponentInfo componentInfo) {
        super(R.layout.navigation_menu_section_item, componentInfo);
        info = componentInfo;
    }

    @Override
    int getViewType() {
        return NavigationItemAdapter.TYPE_SECTION;
    }

    @Override
    void customizeView(final View view, final TextView titleView, final boolean selected) {
        if (selected) {
            titleView.setTextColor(view.getResources().getColor(R.color.orange));
        } else {
            titleView.setTextColor(view.getResources().getColor(R.color.white));
        }

        //If the badge needs to be displayed show it
        if (info instanceof BadgeGroupComponentInfo) {
            final TextView badgeView = (TextView) view.findViewById(R.id.push_countTV);
            final BadgeGroupComponentInfo component = (BadgeGroupComponentInfo) info;
            final boolean expanded = component.isExpanded();

            //Display the badge if it needs to be
            if (expanded && component.shouldShowBadgeWhileExpanded()) {
                badgeView.setVisibility(View.VISIBLE);
                badgeView.setText(component.getBadgeValue());
            } else if (!expanded && component.shouldBadgeBeDisplayed()) {
                badgeView.setVisibility(View.VISIBLE);
                badgeView.setText(component.getBadgeValue());
            } else {
                badgeView.setVisibility(View.INVISIBLE);
                badgeView.setText(StringUtility.EMPTY);
            }

            //Set a special click listener if it needs to be set
            if (component.doesSpecialOnClick()) {
                badgeView.setOnClickListener(component.getSpecialOnClick());
            } else {
                badgeView.setOnClickListener(null);
            }
        }
    }

}
