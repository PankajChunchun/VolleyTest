package com.discover.mobile.common.net.cookie;


import com.discover.mobile.common.Utils;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.CookieStore;
import java.net.HttpCookie;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CookieManagerProxy extends CookieManager {

    private static final String TAG = CookieManagerProxy.class.getSimpleName();
    private static final List<String> PERSIST_COOKIES;
    private static final String PERSIST_DOMAIN = ".discovercard.com";

    static {
        PERSIST_COOKIES = new ArrayList<String>();
        PERSIST_COOKIES.add("PMData".toLowerCase());
        PERSIST_COOKIES.add("dfsedskey".toLowerCase());

    }

    private final String PERSIST_URL = "http://mapi.discovercard.com/";
    private Context context = null;
    private CookieStore cookieStore = null;

//    public CookieManagerProxy(Context context) {
//        this(null, null,context);
//    }

//    public CookieManagerProxy() {
//        this(null, null);
//    }

//    public CookieManagerProxy(CookieStore store, CookiePolicy cookiePolicy) {
//        this(null, null, null);
//    }

    public CookieManagerProxy() {
        /**
         * When network service call is started from service class then getActiveActivity() will be null
         * In that case we will get the  getDiscoverApplicationContext which is set from the GeofenceBroadcastReceiver. which can be used for network service call.
         */
        if (DiscoverActivityManager.getActiveActivity() == null) {
            this.context = DiscoverActivityManager.getDiscoverApplicationContext();
        } else {
            this.context = DiscoverActivityManager.getActiveActivity();
        }
        this.cookieStore = new CookieStoreProxy(this);

        //Known android issue with chromium webkit in Android 5.x.x OS # 745
        try {
            android.webkit.CookieSyncManager.createInstance(context);
            android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        }catch(Exception e){
            e.printStackTrace();
        }

        clearAllCookies();
    }

    @Override
    public Map<String, List<String>> get(URI uri,
                                         Map<String, List<String>> requestHeaders) throws IOException {

        Map<String, List<String>> result = new HashMap<String, List<String>>();
        String cookies = android.webkit.CookieManager.getInstance().getCookie(
                uri.toString());
        if (cookies != null) {
            result.put("Cookie", Arrays.asList(cookies));
        }

        return result;
    }

    @Override
    public void put(URI uri, Map<String, List<String>> responseHeaders)
            throws IOException {
        if (uri == null || responseHeaders == null) {
            return;
        }

        String url = uri.toString();
        for (String headerKey : responseHeaders.keySet()) {
            if (headerKey == null
                    || !(headerKey.equals("Set-Cookie2") || headerKey
                    .equals("Set-Cookie"))) {
                continue;
            }

            for (String cookie : responseHeaders.get(headerKey)) {
                android.webkit.CookieManager.getInstance().setCookie(url,
                        cookie);

                try {
                    persistCookie(uri, cookie);
                } catch (Exception e) {
                    // Never let persisting cookies cause a crash
                    Utils.log(TAG, "Failed to persist cookies.");
                }
            }
        }
    }

    @Override
    public void setCookiePolicy(CookiePolicy cookiePolicy) {
        // Do nothing. This is handled by the webkit cookie manager.
    }

    @Override
    public CookieStore getCookieStore() {
        return cookieStore;
    }

    public void clearAllCookies() {
        /*
         * Commented by vpant Reason - We(offshore Card Team) were trying to
		 * access all the cookies with RetroFitSessionCookieManager But , while
		 * instantiating CookieManagerProxy class , all the cookies were bieng
		 * removed.Thus all the non-persisted cookies were being cleared , thus
		 * we were getting a 401 unAuthorized error.
		 */
        // hkakadi sitedrift issues
        android.webkit.CookieManager.getInstance().removeAllCookie();
        try {
            restorePersistedCookies();
        } catch (Exception e) {
            // Never let failing to reload cookies cause a crash
            Utils.log(TAG, "Error restoring cookies");
        }
    }

    /**
     * A function to get the respective cookie value from
     * RetroSessionCookieManager.java Done so that SessionCookieManager is
     * completely skipped in retro-fit calls.
     *
     * @param uri        - the Uri to retrieve cookies from.
     * @param cookieName - the cookie to be retrieved.
     * @return - the cookie value.
     */
    public String getCookieValue(URI uri, String cookieName) {
        // TODO Auto-generated method stub

        try {
            Map<String, List<String>> cookies = get(uri, null);

            if (cookies == null || cookies.get("Cookie") == null
                    || cookies.get("Cookie").size() == 0) {
                // No cookies, return null
                Utils.log(TAG, "getCookieValue: No cookues retrieved for "
                        + uri.toURL());
                return null;
            }


            for (String cookieRaw : cookies.get("Cookie")) {
                for (String cookieSplit : cookieRaw.split(";")) {
                    String[] cookie = cookieSplit.split("=", 2);
                    Utils.log(TAG, "getCookieValue: Cookie " + cookie[0].trim()
                            + " === " + cookie[1].trim());
                    if (cookie[0].trim().equalsIgnoreCase(cookieName)) {
                        return cookie[1].trim();
                    }
                }
            }

            return null;
        } catch (IOException e) {
            return null;
        }

    }

    /*
     * All cookies to be stored are passed to this method. If we find
     * interesting ones, we save them to a database to be reloaded the nxt time
     * the app starts.
     */
    private void persistCookie(URI uri, String cookieString) {
//        if (context == null) {
//            Utils.log(TAG,
//                    "No context available.  The object was probably instantiated incorrectly.");
//            return;
//        }

        final String simpleUrl = uri.getScheme() + "://" + uri.getHost() + "/";

        List<HttpCookie> cookieList = HttpCookie.parse(cookieString);
        Map<String, String> stored = null;

        for (HttpCookie cookie : cookieList) {
            if (PERSIST_COOKIES.contains(cookie.getName().toLowerCase())
                    && HttpCookie.domainMatches(cookie.getDomain(),
                    uri.getHost())) {

                if (stored == null) {
                    stored = getStoredCookies();
                }

                String key = cookie.getDomain() + ":" + cookie.getName();
                if (stored.containsKey(key)) {
                    stored.remove(key);
                }

                stored.put(key, cookieToString(simpleUrl, cookie));
            }
        }

        HashSet<String> toStore = new HashSet<String>(stored.values());

        SharedPreferences sharedPref = context.getSharedPreferences(
                "DISCOVER_CARD_PREF", Context.MODE_PRIVATE);
        sharedPref.edit().putStringSet("COOKIES", toStore).commit();
    }

    private String cookieToString(String url, HttpCookie cookie) {

        StringBuilder sb = new StringBuilder();

        sb.append(cookie.getDomain()).append(":");
        sb.append(cookie.getName()).append(";");

        sb.append(url).append(";");

        sb.append(cookie.getName()).append("=").append(cookie.getValue())
                .append(";");
        sb.append("domain=").append(cookie.getDomain()).append(";");
        sb.append("path=").append(cookie.getPath());

        if (cookie.getMaxAge() > 0) {
            Date expires = new Date();
            expires.setTime(expires.getTime() + (cookie.getMaxAge() * 1000));
            sb.append(";expires=" + expires.toGMTString());
        }

        if (cookie.getSecure()) {
            sb.append(";Secure");
        }

        return sb.toString();
    }

    private void restorePersistedCookies() {
        restoreOldPMData();

        for (String cookie : getStoredCookies().values()) {
            String[] split = cookie.split(";", 3);
            android.webkit.CookieManager.getInstance().setCookie(split[1],
                    split[2]);
        }
    }

    /*
     * returns a list in the format of: key: [cookieDomain]:[cookieName] value:
     * [cookieUrl]&[set-cookie header format]
     */
    private Map<String, String> getStoredCookies() {
//        if (context == null) {
//            Utils.log(TAG,
//                    "No context available, you probably instantiated this class incorrectly.");
//            return new HashMap<String, String>();
//        }

        SharedPreferences sharedPref = context.getSharedPreferences(
                "DISCOVER_CARD_PREF", Context.MODE_PRIVATE);
        Set<String> cookies = sharedPref.getStringSet("COOKIES", null);

        if (cookies == null) {
            return new HashMap<String, String>();
        }

        HashMap<String, String> cookieMap = new HashMap<String, String>();
        for (String cookie : cookies) {
            String[] split = cookie.split(";", 3);
            cookieMap.put(split[0], cookie);
        }

        return cookieMap;
    }

    private void restoreOldPMData() {
        // Old versions of the app store PMData separately. We restore it here,
        // then clear the old value.

        if (context == null) {
            Utils.log(TAG,
                    "No context available, you probably instantiated this class incorrectly.");
            return;
        }

        final String KEY = "PMDATA_COOKIE";

        SharedPreferences sharedPref = context.getSharedPreferences(
                "DISCOVER_CARD_PREF", Context.MODE_PRIVATE);
        String storedPMData = sharedPref.getString(KEY, null);
        sharedPref.edit().remove(KEY).commit();

        if (storedPMData == null) {
            return;
        }

        Date time = new Date();
        time.setTime(time.getTime() + (3600 * 24 * 365 * 1000)); // one year
        // (-ish)
        String newCookie = "PMData=" + storedPMData + ";Expires="
                + time.toGMTString() + ";Domain=" + PERSIST_DOMAIN
                + ";Path=/;Secure";
        android.webkit.CookieManager.getInstance().setCookie(PERSIST_URL,
                newCookie);

    }
}
