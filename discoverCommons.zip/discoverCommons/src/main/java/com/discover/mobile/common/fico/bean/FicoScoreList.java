package com.discover.mobile.common.fico.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * @author slende
 */
public class FicoScoreList implements Serializable {

    private static final long serialVersionUID = 419682318885845456L;

    @SerializedName("currentScore")
    private int currentScore;

    @SerializedName("scoreDate")
    private String scoreDate; //MM/DD/YYYY

    @SerializedName("negativeKeyFactors")
    private List<NegativeKeyFactor> negativeKeyFactors;

    @SerializedName("positiveKeyFactors")
    private List<PositiveKeyFactor> positiveKeyFactors;

    @SerializedName("tips")
    private List<Tip> tips;

    @SerializedName("hasScore")
    private boolean hasScore;

    @SerializedName("displayKeyString")
    private String displayKeyString;

    @SerializedName("informationMessage")
    private String informationMessage;

    /** start newly added attributes for fico-score -V3 version upgrade */

    @SerializedName("finAgreementTypeCode")
    private String finAgreementTypeCode;

    @SerializedName("creditReportSeqNumber")
    private String creditReportSeqNumber;

    @SerializedName("tradeCount")
    private String tradeCount;

    @SerializedName("openRvlTradeCount")
    private String openRvlTradeCount;

    @SerializedName("openInstTradeCount")
    private String openInstTradeCount;

    @SerializedName("oldestTradeMonthCount")
    private String oldestTradeMonthCount;

    @SerializedName("inquiryCount")
    private String inquiryCount;

    @SerializedName("openRvlUtilizationPct")
    private String openRvlUtilizationPct;

    @SerializedName("totalRvlBalAmt")
    private String totalRvlBalAmt;

    @SerializedName("missedPaymentsInLastyear")
// Change tradeOver30Count to missedPaymentsInLastyear as per new ICD For FICO Credit Scorecard
    private String missedPaymentsInLastyear;

    @SerializedName("totalMissedPymt")
    private String totalMissedPymt;

    /** Start New fields are added for collapsed & expanded boxes US121087 & US121912 */

    @SerializedName("totalAccountRatingCode")
    private String totalAccountRatingCode;
    @SerializedName("totalAccountRatingEffDate")
    private String totalAccountRatingEffDate;  // YYYYMMDD format e.g. "2017-05-12"
    @SerializedName("totalAccountRating")
    private String totalAccountRating;
    @SerializedName("totalAccountRateMessage")
    private String totalAccountRateMessage;

    @SerializedName("lengthOfCreditRatingCode")
    private String lengthOfCreditRatingCode;
    @SerializedName("lengthOfCreditRatingEffDate")
    private String lengthOfCreditRatingEffDate; // YYYYMMDD format e.g. "2017-05-12"
    @SerializedName("lengthOfCreditRating")
    private String lengthOfCreditRating;
    @SerializedName("lengthOfCreditRateMessage")
    private String lengthOfCreditRateMessage;

    @SerializedName("inquiriesRatingCode")
    private String inquiriesRatingCode;
    @SerializedName("inquiriesRatingEffDate")
    private String inquiriesRatingEffDate; // YYYYMMDD format e.g. "2017-05-12"
    @SerializedName("inquiriesRating")
    private String inquiriesRating;
    @SerializedName("inquiriesRateMessage")
    private String inquiriesRateMessage;

    @SerializedName("revolvingUtilizationRatingCode")
    private String revolvingUtilizationRatingCode;
    @SerializedName("revolvingUtilizationRatingEffDate")
    private String revolvingUtilizationRatingEffDate; // YYYYMMDD format e.g. "2017-05-12"
    @SerializedName("revolvingUtilizationRating")
    private String revolvingUtilizationRating;
    @SerializedName("revolvingUtilizationRateMessage")
    private String revolvingUtilizationRateMessage;

    @SerializedName("missedPaymentsRatingCode")
    private String missedPaymentsRatingCode;
    @SerializedName("missedPaymentsRatingEffDate")
    private String missedPaymentsRatingEffDate; // YYYYMMDD format e.g. "2017-05-12"
    @SerializedName("missedPaymentsRating")
    private String missedPaymentsRating;
    @SerializedName("missedPaymentsRateMessage")
    private String missedPaymentsRateMessage;

    /** End New fields are added for collapsed & expanded boxes US121087 & US121912 */

    public String getFinAgreementTypeCode() {
        return finAgreementTypeCode;
    }

    public void setFinAgreementTypeCode(String finAgreementTypeCode) {
        this.finAgreementTypeCode = finAgreementTypeCode;
    }

    public String getCreditReportSeqNumber() {
        return creditReportSeqNumber;
    }

    public void setCreditReportSeqNumber(String creditReportSeqNumber) {
        this.creditReportSeqNumber = creditReportSeqNumber;
    }

    public String getTradeCount() {
        return tradeCount;
    }

    public void setTradeCount(String tradeCount) {
        this.tradeCount = tradeCount;
    }

    public String getOpenRvlTradeCount() {
        return openRvlTradeCount;
    }

    public void setOpenRvlTradeCount(String openRvlTradeCount) {
        this.openRvlTradeCount = openRvlTradeCount;
    }

    public String getOpenInstTradeCount() {
        return openInstTradeCount;
    }

    public void setOpenInstTradeCount(String openInstTradeCount) {
        this.openInstTradeCount = openInstTradeCount;
    }

    public String getOldestTradeMonthCount() {
        return oldestTradeMonthCount;
    }

    public void setOldestTradeMonthCount(String oldestTradeMonthCount) {
        this.oldestTradeMonthCount = oldestTradeMonthCount;
    }

    public String getInquiryCount() {
        return inquiryCount;
    }

    public void setInquiryCount(String inquiryCount) {
        this.inquiryCount = inquiryCount;
    }

    public String getOpenRvlUtilizationPct() {
        return openRvlUtilizationPct;
    }

    public void setOpenRvlUtilizationPct(String openRvlUtilizationPct) {
        this.openRvlUtilizationPct = openRvlUtilizationPct;
    }

    public String getTotalRvlBalAmt() {
        return totalRvlBalAmt;
    }

    public void setTotalRvlBalAmt(String totalRvlBalAmt) {
        this.totalRvlBalAmt = totalRvlBalAmt;
    }

    public String getMissedPaymentsInLastyear() {
        return missedPaymentsInLastyear;
    }

    public void setMissedPaymentsInLastyear(String missedPaymentsInLastyear) {
        this.missedPaymentsInLastyear = missedPaymentsInLastyear;
    }

    public String getTotalMissedPymt() {
        return totalMissedPymt;
    }

    public void setTotalMissedPymt(String totalMissedPymt) {
        this.totalMissedPymt = totalMissedPymt;
    }

    /** end newly added attributes for fico-score -V3 version upgrade */

    public int getCurrentScore() {
        return currentScore;
    }

    public void setCurrentScore(int currentScore) {
        this.currentScore = currentScore;
    }

    public String getScoreDate() {
        return scoreDate;
    }

    public void setScoreDate(String scoreDate) {
        this.scoreDate = scoreDate;
    }

    public List<NegativeKeyFactor> getNegativeKeyFactors() {
        return negativeKeyFactors;
    }

    public void setNegativeKeyFactors(List<NegativeKeyFactor> negativeKeyFactors) {
        this.negativeKeyFactors = negativeKeyFactors;
    }

    public List<PositiveKeyFactor> getPositiveKeyFactors() {
        return positiveKeyFactors;
    }

    public void setPositiveKeyFactors(List<PositiveKeyFactor> positiveKeyFactors) {
        this.positiveKeyFactors = positiveKeyFactors;
    }

    public List<Tip> getTips() {
        return tips;
    }

    public void setTips(List<Tip> tips) {
        this.tips = tips;
    }

    public String getInformationMessage() {
        return informationMessage;
    }

    public void setInformationMessage(String informationMessage) {
        this.informationMessage = informationMessage;
    }

    public boolean isHasScore() {
        return hasScore;
    }

    public void setHasScore(boolean hasScore) {
        this.hasScore = hasScore;
    }

    public String getDisplayKeyString() {
        return displayKeyString;
    }

    public void setDisplayKeyString(String displayKeyString) {
        this.displayKeyString = displayKeyString;
    }

    public String getTotalAccountRatingCode() {
        return totalAccountRatingCode;
    }

    public void setTotalAccountRatingCode(String totalAccountRatingCode) {
        this.totalAccountRatingCode = totalAccountRatingCode;
    }

    public String getTotalAccountRatingEffDate() {
        return totalAccountRatingEffDate;
    }

    public void setTotalAccountRatingEffDate(String totalAccountRatingEffDate) {
        this.totalAccountRatingEffDate = totalAccountRatingEffDate;
    }

    public String getTotalAccountRating() {
        return totalAccountRating;
    }

    public void setTotalAccountRating(String totalAccountRating) {
        this.totalAccountRating = totalAccountRating;
    }

    public String getTotalAccountRateMessage() {
        return totalAccountRateMessage;
    }

    public void setTotalAccountRateMessage(String totalAccountRateMessage) {
        this.totalAccountRateMessage = totalAccountRateMessage;
    }

    public String getLengthOfCreditRatingCode() {
        return lengthOfCreditRatingCode;
    }

    public void setLengthOfCreditRatingCode(String lengthOfCreditRatingCode) {
        this.lengthOfCreditRatingCode = lengthOfCreditRatingCode;
    }

    public String getLengthOfCreditRatingEffDate() {
        return lengthOfCreditRatingEffDate;
    }

    public void setLengthOfCreditRatingEffDate(String lengthOfCreditRatingEffDate) {
        this.lengthOfCreditRatingEffDate = lengthOfCreditRatingEffDate;
    }

    public String getLengthOfCreditRating() {
        return lengthOfCreditRating;
    }

    public void setLengthOfCreditRating(String lengthOfCreditRating) {
        this.lengthOfCreditRating = lengthOfCreditRating;
    }

    public String getLengthOfCreditRateMessage() {
        return lengthOfCreditRateMessage;
    }

    public void setLengthOfCreditRateMessage(String lengthOfCreditRateMessage) {
        this.lengthOfCreditRateMessage = lengthOfCreditRateMessage;
    }

    public String getInquiriesRatingCode() {
        return inquiriesRatingCode;
    }

    public void setInquiriesRatingCode(String inquiriesRatingCode) {
        this.inquiriesRatingCode = inquiriesRatingCode;
    }

    public String getInquiriesRatingEffDate() {
        return inquiriesRatingEffDate;
    }

    public void setInquiriesRatingEffDate(String inquiriesRatingEffDate) {
        this.inquiriesRatingEffDate = inquiriesRatingEffDate;
    }

    public String getInquiriesRating() {
        return inquiriesRating;
    }

    public void setInquiriesRating(String inquiriesRating) {
        this.inquiriesRating = inquiriesRating;
    }

    public String getInquiriesRateMessage() {
        return inquiriesRateMessage;
    }

    public void setInquiriesRateMessage(String inquiriesRateMessage) {
        this.inquiriesRateMessage = inquiriesRateMessage;
    }

    public String getRevolvingUtilizationRatingCode() {
        return revolvingUtilizationRatingCode;
    }

    public void setRevolvingUtilizationRatingCode(String revolvingUtilizationRatingCode) {
        this.revolvingUtilizationRatingCode = revolvingUtilizationRatingCode;
    }

    public String getRevolvingUtilizationRatingEffDate() {
        return revolvingUtilizationRatingEffDate;
    }

    public void setRevolvingUtilizationRatingEffDate(String revolvingUtilizationRatingEffDate) {
        this.revolvingUtilizationRatingEffDate = revolvingUtilizationRatingEffDate;
    }

    public String getRevolvingUtilizationRating() {
        return revolvingUtilizationRating;
    }

    public void setRevolvingUtilizationRating(String revolvingUtilizationRating) {
        this.revolvingUtilizationRating = revolvingUtilizationRating;
    }

    public String getRevolvingUtilizationRateMessage() {
        return revolvingUtilizationRateMessage;
    }

    public void setRevolvingUtilizationRateMessage(String revolvingUtilizationRateMessage) {
        this.revolvingUtilizationRateMessage = revolvingUtilizationRateMessage;
    }

    public String getMissedPaymentsRatingCode() {
        return missedPaymentsRatingCode;
    }

    public void setMissedPaymentsRatingCode(String missedPaymentsRatingCode) {
        this.missedPaymentsRatingCode = missedPaymentsRatingCode;
    }

    public String getMissedPaymentsRatingEffDate() {
        return missedPaymentsRatingEffDate;
    }

    public void setMissedPaymentsRatingEffDate(String missedPaymentsRatingEffDate) {
        this.missedPaymentsRatingEffDate = missedPaymentsRatingEffDate;
    }

    public String getMissedPaymentsRating() {
        return missedPaymentsRating;
    }

    public void setMissedPaymentsRating(String missedPaymentsRating) {
        this.missedPaymentsRating = missedPaymentsRating;
    }

    public String getMissedPaymentsRateMessage() {
        return missedPaymentsRateMessage;
    }

    public void setMissedPaymentsRateMessage(String missedPaymentsRateMessage) {
        this.missedPaymentsRateMessage = missedPaymentsRateMessage;
    }
}
