package com.discover.mobile.common.productpage.request;


import com.discover.mobile.common.productpage.beans.ProductsContent;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Headers;

public interface ProductRequestInterface {
    @Headers("Content-Type: application/json")
    @GET("/json/ProductsContent.json")
    void getProductRequest(Callback<ProductsContent> getProductRequest);
}
