package com.discover.mobile.common.push.receive;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;

import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.liveperson.LPPushNotification;
import com.discover.mobile.common.liveperson.LPPushNotificationImpl;
import com.discover.mobile.common.liveperson.LivePersonConstants;
import com.xtify.sdk.api.XtifyBroadcastReceiver;
import com.xtify.sdk.api.XtifySDK;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * This is the broadcast receiver for the Xtifty push notifications. It will
 * receiver the notifications and then utilize them accordingly. Meaning that
 * the notifications will be displayed in the notification tray.
 *
 * @author CTS
 */
public class XtifyNotifier extends XtifyBroadcastReceiver {

    //PUSH_XID identifier
    public static final String PUSH_XID = "xid";
    public static final String PUSH_BANK = "BANK";
    /** Tag to identify the class for debugging */
    private static final String TAG = XtifyNotifier.class.getName();
    Context context;
    JSONObject data;
    int notificationId = 0;
    //boolean useful to differentiate card/bank notifications
    private boolean isCardPushNotification = true;

    /**
     * When a message is received from Xtify
     *
     * @param context   - application context
     * @param msgExtras - bundle containing the message extras
     */
    @Override
    public void onMessage(final Context context, final Bundle msgExtras) {

        this.context = context;
        Log.d("Notification Received on Message", "Received");
        notificationId = (int) System.currentTimeMillis();


        String payload = msgExtras.getString("data.customKey");
        String notificationIdentifier = msgExtras.getString("data.assignFor");

        if (payload != null && payload.contains("bank")) {
            notificationIdentifier = PUSH_BANK;
        } else {
            notificationIdentifier = "";
        }

        if (payload != null) {
            Log.d("Notification Received on Message", payload);
          /*  for (String temp : msgExtras.keySet()) {
                Log.d("============== hope fully I am extracting the bundle Key ===========",
                        msgExtras.get(temp).toString());

                payload = (String) msgExtras.get(temp); //can be removed not used.
            }*/

            data = new JSONObject();

            try {
                Log.d("notification subject",
                        msgExtras.get("com.xtify.sdk.NOTIFICATION_TITLE")
                                .toString());
                //sendCardNotification function defined on CardPushFacadeImpl.java class
                /*FacadeFactory.getBankPushNotificationFacade().sendCardNotification(msgExtras.get("com.xtify.sdk.NOTIFICATION_TITLE")
						.toString(), msgExtras.get("com.xtify.sdk.NOTIFICATION_CONTENT")
						.toString(), msgExtras.get("data.customKey")
						.toString(), notificationId, context);*/
                //TODO:: Have to check why this loop is not working properly although notificationIdentifier as BANK.
                if(payload.contains(LivePersonConstants.PAGE_CODE)){
                    LPPushNotification lpPushNotification = new LPPushNotificationImpl();
                    lpPushNotification.handlePush(msgExtras.get("com.xtify.sdk.NOTIFICATION_TITLE")
                            .toString(), msgExtras.get("com.xtify.sdk.NOTIFICATION_CONTENT")
                            .toString(), msgExtras.get("data.customKey")
                            .toString(), notificationId, context);
                }else if (!notificationIdentifier.equalsIgnoreCase(PUSH_BANK)){

                    FacadeFactory.getCardPushNotificationFacade().sendCardNotification(msgExtras.get("com.xtify.sdk.NOTIFICATION_TITLE")
                                .toString(), msgExtras.get("com.xtify.sdk.NOTIFICATION_CONTENT")
                                .toString(), msgExtras.get("data.customKey")
                                .toString(), notificationId, context);

                } else {
                    FacadeFactory.getBankPushNotificationFacade().sendBankNotification(msgExtras.get("com.xtify.sdk.NOTIFICATION_TITLE")
                                .toString(), msgExtras.get("com.xtify.sdk.NOTIFICATION_CONTENT")
                                .toString(), msgExtras.get("data.customKey")
                                .toString(), notificationId, notificationIdentifier, context);

                }

                data.put("notificationID", notificationId);
                data.put("customKey", msgExtras.get("data.customKey"));
                data.put("message",
                        msgExtras.get("com.xtify.sdk.NOTIFICATION_CONTENT"));
                data.put("subject",
                        msgExtras.get("com.xtify.sdk.NOTIFICATION_TITLE"));
                data.put("subjectType",
                        msgExtras.get("com.xtify.sdk.NOTIF_ACTION_TYPE"));

            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (!notificationIdentifier.equalsIgnoreCase(PUSH_BANK)) {
                //cardNavigations function defined on CardPushFacadeImpl.java class
                FacadeFactory.getCardPushNotificationFacade().cardPushNavigations(data, notificationId, context);

                //processCardNotificationExtras function defined on CardPushFacadeImpl.java class
                FacadeFactory.getCardPushNotificationFacade().processCardNotificationExtras(context, msgExtras);
            }

        }

        //Following condition will be useful to differentiate card/bank notification
        if (isCardPushNotification) {
            //TODO: perform card  notifications
        } else {
            //TODO: perform bank  notifications
        }
    }


    /**
     * Called when the device is registered with Xtify
     *
     * @param context - activity context
     */
    @Override
    public void onRegistered(final Context context) {
        //	Utils.log(TAG, "XID is: " + XtifySDK.getXidKey(context));
        Log.i(TAG, "XID is: " + XtifySDK.getXidKey(context));
		
		/*
		 * Toast.makeText(context, XtifySDK.getXidKey(context),
		 * Toast.LENGTH_LONG) .show();
		 */

        SharedPreferences pushSharedPrefs = context.getSharedPreferences(
                "PUSH_PREF", // TODO: Push
                Context.MODE_PRIVATE);

        Editor editor = pushSharedPrefs.edit();
        editor.putString(PUSH_XID,
                XtifySDK.getXidKey(context));
        editor.commit();

//		Utils.log(
//				TAG,
//				"XID is:Pref "
//						+ pushSharedPrefs.getString(PushConstant.pref.PUSH_XID,
//								"0"));

        Log.i(TAG, "XID is:Pref " + pushSharedPrefs.getString(PUSH_XID, "0"));

        //Following condition will be useful to differentiate card/bank notification
        if (isCardPushNotification) {
            // TODO: perform card notifications
        } else {
            // TODO: perform bank notifications
        }

    }


    /**
     * Called when there is a C2dm Error
     *
     * @param context - application context
     * @param errorId - error id
     */
    @Override
    public void onC2dmError(final Context context, final String errorId) {
        //Utils.log(TAG, "ErrorId: " + errorId); //$NON-NLS-1$
        Log.i(TAG, "ErrorId: " + errorId);

    }


	/*
	 * @Override public void onReceive(final Context context, final Intent
	 * intent) {
	 * 
	 * Toast.makeText(context, "MY MSG", Toast.LENGTH_LONG).show();
	 * Log.d("Notification Receive$$$$$$", "Received"); for (String temp :
	 * intent.getBundleExtra(name)) {
	 * Log.d("============== hope fully I am extracting the bundle Key ==========="
	 * , msgExtras.get(temp).toString()); payload = (String)
	 * msgExtras.get(temp); }
	 * 
	 * //Log.d("bundle",intent.getBundleExtra("payload").toString()); final
	 * Intent in = new Intent(context, MyService.class);
	 * in.putExtra("isForWear", true); in.putExtra("notificationPayload",
	 * readFromAssetFile("payloadformat.txt", context));
	 * context.startService(in);
	 * 
	 * NotificationsPreference.setIcon(context, R.drawable.discove_mobile_icn);
	 * }
	 */

}
