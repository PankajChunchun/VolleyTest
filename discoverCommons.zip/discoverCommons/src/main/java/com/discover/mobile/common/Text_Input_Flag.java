package com.discover.mobile.common;

import android.support.design.widget.TextInputLayout;

/**
 * Created by pdesai2 on 7/8/2016.
 *
 * Flag to check if the edit text was used
 */
public class Text_Input_Flag {
    Boolean currentState;

    public Text_Input_Flag(){}

    public void setCurrentState(Boolean state)
    {
        this.currentState=state;
    }

    public Boolean getCurrentState()
    {
        return currentState;
    }

}
