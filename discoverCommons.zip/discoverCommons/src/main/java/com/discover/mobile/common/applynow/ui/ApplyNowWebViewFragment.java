package com.discover.mobile.common.applynow.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.discover.mobile.common.BaseFragment;
import com.discover.mobile.common.R;

/**
 * Created by 473708 on 9/19/2017.
 */

public class ApplyNowWebViewFragment extends BaseFragment {
    private static final String EXTRA_URL_TO_SHOW = "url_to_show";
    private WebView mWebView;
    private ProgressBar mProgressBar;
    private Context mContext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.apply_now_webview_layout, null);

        mWebView = (WebView) view.findViewById(R.id.apply_now_webview);
        mProgressBar = (ProgressBar) view.findViewById(R.id.apply_now_webview_progress);
        String url = getArguments().getString(EXTRA_URL_TO_SHOW, "");

        WebSettings webSettings = mWebView.getSettings();
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setJavaScriptEnabled(true);

        mWebView.clearFormData();
        webSettings.setSaveFormData(false);

        final WebViewClient client = new WebViewClient();
        mWebView.setWebViewClient(client);
        mWebView.loadUrl(url);

        mWebView.requestFocus();
        mWebView.requestFocusFromTouch();
        mWebView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                mProgressBar.setProgress(progress);
                if (progress == 100) {
                    mProgressBar.setVisibility(View.GONE);
                } else {
                    mProgressBar.setVisibility(View.VISIBLE);
                }
            }
        });

        return view;
    }

    @Override
    public int getActionBarTitle() {
        return R.string.apply_now_banner_title;
    }

    @Override
    public int getGroupMenuLocation() {
        return 0;
    }

    @Override
    public int getSectionMenuLocation() {
        return 0;
    }
}
