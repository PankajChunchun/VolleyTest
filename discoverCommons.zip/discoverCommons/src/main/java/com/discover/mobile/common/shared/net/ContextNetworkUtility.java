package com.discover.mobile.common.shared.net;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;

import com.discover.mobile.common.shared.utils.CommonUtils;

import java.util.HashMap;
import java.util.Map;

import static com.discover.mobile.common.shared.ThreadUtility.isMainThread;


/**
 *
 */
final public class ContextNetworkUtility {

    // This should only ever be mutated on the main thread
    @SuppressLint("UseSparseArrays")
    private static Map<Integer, String> keyValuePairs = new HashMap<Integer, String>();

    private ContextNetworkUtility() {
        throw new UnsupportedOperationException("This class is non-instantiable");
    }

    /**
     * Loads resource only one time
     */
    public static synchronized String getStringResource(final Context currentContext, final int id) {
        CommonUtils.checkState(isMainThread(), "getBaseUrl() must be called from the main thread");
        String value = null;
        if (!keyValuePairs.containsKey(id)) {
            value = currentContext.getString(id);
            keyValuePairs.put(id, value);
            CommonUtils.checkNotNull(value, "String resource was null when retrieving from resources:" + id);
        } else {
            value = keyValuePairs.get(id);
        }
        return value;

    }

    public static boolean isActiveNetworkConnected(final Context context) {
        //CrashLytics fix 941
        boolean isConnected = false;
        try {
            final ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
            // test for connection
            if (networkInfo != null && networkInfo.isConnected()) {
                isConnected = true;
            }
        } catch(Exception e) {
            isConnected = false;
        }
        return isConnected;
    }

    /**
     * Method used to fetch a unique identifier for the device. Returns
     * telephony device id, if not available returns the ANDROID_ID. Note, the
     * ANDROID_ID is not available
     */
    public static String getUUID(final Context context) {
        String identifier = "";

        // # US63017 android id to be taken from Secure api instead of Telephony manager from Marshmallow onwards.
        if (android.os.Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1) {
            final TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

            if (telephonyManager != null)
               identifier = telephonyManager.getDeviceId();
        }
        else
            identifier = null;
        // # US63017 android id to be taken from Secure api instead of Telephony manager from Marshmallow onwards.

        if (CommonUtils.isNullOrEmpty(identifier) || identifier.length() == 0)
            identifier = Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);

        return identifier;
    }

}
