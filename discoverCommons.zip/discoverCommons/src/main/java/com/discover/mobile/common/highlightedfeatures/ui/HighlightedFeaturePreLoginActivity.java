package com.discover.mobile.common.highlightedfeatures.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.highlightedfeatures.utils.HFConstants;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.nav.StatusBarFragment;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

/**
 * An {@link android.app.Activity} which handles Highlighted features.
 *
 * This activity acts as a container of {@link HighlightedFeaturesLandingFragment} and this activity
 * should be
 * called when caller needs to launch an Activity either from post-login or pre-login.
 *
 * If the caller is an Activity and does not need to show another activity then use {@link
 * HighlightedFeaturesLandingFragment}.
 *
 * @author pkuma13
 */
public class HighlightedFeaturePreLoginActivity extends DiscoverBaseActivity implements ErrorHandlerUi {
    private Bundle extras;
    private HFConstants.LoginType mLoginType;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if(com.discover.mobile.common.Utils.checkPermissionTampering(this)){
            return;
        }
        /**Defect:1268 end**/

        extras = getIntent().getExtras();
        this.mLoginType = (HFConstants.LoginType) extras.getSerializable(HFConstants.Args.LOGIN_TYPE);
        setContentView(NO_LAYOUT);
       /* setBehindContentView(getBehindContentView());
        disableMenu();*/
        /*showBackX();
        getSupportActionBar().hide();*/

        DiscoverActivityManager.setActiveActivity(this);
       /* hideStatusBarFragment();*/

        HighlightedFeaturesLandingFragment fragment = new HighlightedFeaturesLandingFragment();
        Bundle args = extras;
        fragment.setArguments(args);
        makeFragmentVisible(fragment);
    }


    @Override
    public void onResume() {
        super.onResume();
       /* disableMenu();*/
        //  showBackX();

    }


    @Override
    public void onBackPressed() {
        navigateToRoot();
    }


    public void navigateToRoot() {
        if (this.mLoginType == HFConstants.LoginType.CARD) {
            FacadeFactory.getHighlightedFeaturesFacade().navigateToCardHome(HighlightedFeaturePreLoginActivity.this, extras);
        } else if (this.mLoginType == HFConstants.LoginType.BANK) {
            FacadeFactory.getBankLoginFacade().navigateToBankHomePage();
        } else if (this.mLoginType == HFConstants.LoginType.SSO) {
            PortalUtils.navToPortalActivity();
        } else {
            FacadeFactory.getHighlightedFeaturesFacade().navigateToCardHome(HighlightedFeaturePreLoginActivity.this, extras);
        }
        finish();
    }

    private void hideStatusBarFragment() {
        StatusBarFragment statusBarFragment = (StatusBarFragment) getSupportFragmentManager().findFragmentById(R.id.status_bar);
        final FragmentTransaction fragmentTransaction = this.getSupportFragmentManager().beginTransaction();
        fragmentTransaction.hide(statusBarFragment);
        fragmentTransaction.commit();
    }


    @Override
    public TextView getErrorLabel() {
        return null;
    }

    @Override
    public List<EditText> getInputFields() {
        return null;
    }

    @Override
    public void showCustomAlert(AlertDialog alert) {

    }

    @Override
    public void showOneButtonAlert(int title, int content, int buttonText) {

    }

    @Override
    public void showDynamicOneButtonAlert(int title, String content, int buttonText) {

    }

    @Override
    public Context getContext() {
        return null;
    }

    @Override
    public int getLastError() {
        return 0;
    }

    @Override
    public void setLastError(int errorCode) {

    }

    @Override
    public ErrorHandler getErrorHandler() {
        return null;
    }
}