package com.discover.mobile.common;

//import roboguice.RoboGuice;

import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.nav.DrawerBaseActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;

/**
 * Base fragment that all of the fragments in the app should extend
 *
 * @author jthornton
 */
public abstract class BaseFragment extends Fragment {

    /** Static int used to signify that the logo should be shown and the title should not be shown */
    public static final int NO_TITLE = -1;
    private Context mContext;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    /**
     * Create the fragment
     *
     * @param savedInstanceState - bundle containing saved state of the fragment
     */
    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         /* US59153 : set Fragment name for error enhanced modal*/
        // TrackingHelper.currentPageName = null;
        Fragment fragment = null;
        final DiscoverBaseActivity activity = (DiscoverBaseActivity) this.getActivity();
        if (null != activity)
            fragment = activity.getSupportFragmentManager().findFragmentById(R.id.contentView);
       // if (null != fragment) TrackingHelper.currentPageName = fragment.getClass().getSimpleName();// Commenting this code to avoaid master fraggment name in Current Page Name

        //RoboGuice.getInjector(getActivity()).injectMembersWithoutViews(this);
    }

    /**
     * Create the view
     *
     * @param view               - view of the fragment
     * @param savedInstanceState - bundle containing saved state of the fragment
     */
    @Override
    public void onViewCreated(final View view, final Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //RoboGuice.getInjector(getActivity()).injectViewMembers(this);
    }

    /**
     * When the app resumes, make sure the fragment shows the same
     */
    @Override
    public void onResume() {
        super.onResume();
        if (this.getActivity() instanceof ActionBarBaseActivity) {
            final ActionBarBaseActivity activity = (ActionBarBaseActivity) this.getActivity();
            activity.setCurrentFragment(this);
            if (null != activity.getCurrentFragment()) {
                if (activity.getCurrentFragment() instanceof BaseFragment)
                    setActionBarTitle(((BaseFragment) activity.getCurrentFragment()).getActionBarTitle(), false);
            } else {
                setActionBarTitle(getActionBarTitle(), false);
            }
        }
//		activity.highlightMenuItems(getGroupMenuLocation(), getSectionMenuLocation());

    }

    @Override
    public void onPause() {
        super.onPause();
    }

    /**
     * Show the logout alert dialog
     */
    public void showCustomAlertDialog(final AlertDialog modal) {
        final DiscoverBaseActivity activity = (DiscoverBaseActivity) this
                .getActivity();
        activity.showCustomAlert(modal);
    }

    /**
     * Make the fragment visible
     *
     * @param fragment - fragment to be made visible
     */
    public void makeFragmentVisible(final BaseFragment fragment) {
        final DiscoverBaseActivity activity = (DiscoverBaseActivity) this.getActivity();
        activity.makeFragmentVisible(fragment);
    }

    public void makeFragmentVisible(final BaseFragment fragment, final boolean addToHistory) {
        final DiscoverBaseActivity activity = (DiscoverBaseActivity) this.getActivity();
        activity.makeFragmentVisible(fragment, addToHistory);
    }

    /**
     * Set the title in the action bar for display
     *
     * @param title - title to show in the display
     */
    public void setActionBarTitle(final int title, boolean fromChildFragments) {
        if (NO_TITLE == title || mContext.getResources().getString(title).equalsIgnoreCase("")) {
            this.showActionBarLogo();
        } else {
            final ActionBarBaseActivity activity = (ActionBarBaseActivity) this.getActivity();
            this.hideActionBarLogo();

            //Should show prelogin header name.
            if (title == R.string.prelogin_card_deals) {
                SharedPreferences sharedPref = activity.getSharedPreferences(getString(R.string.post_login_username), Context.MODE_PRIVATE);
                String name = sharedPref.getString(getString(R.string.username), "");
                name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
                activity.setActionBarTitle(name + getResources().getString(R.string.apostrophe) + " Deals ", false);
            } else {
                activity.setActionBarTitle(activity.getResources().getString(title), false);
            }
        }

        if (fromChildFragments) {
            ((DrawerBaseActivity) this.getActivity()).changeLHNMenuHighlighting(title);

        }
    }

    /**
     * Hides the TextView on the ActionBar and instead shows the Discover logo.
     */
    public void showActionBarLogo() {
        final ActionBarBaseActivity activity = (ActionBarBaseActivity) this
                .getActivity();
        activity.setLogoInCenter();
    }

    /**
     * Set the visibility of the status bar
     */
//	public void setStatusBarVisibility() {
//		final LoggedInRoboActivity activity = (LoggedInRoboActivity) this
//				.getActivity();
//		activity.setStatusBarVisbility();
//	}

    /**
     * Hides the Logo on the ActionBar and instead shows the TextView.
     */
    public void hideActionBarLogo() {
        final ActionBarBaseActivity activity = (ActionBarBaseActivity) this
                .getActivity();
        if(activity!=null) {
            activity.setTitle("");
        }
    }

    /**
     * Get the resource id of the string that should be shown in the action bar
     *
     * @return the resource id of the string that should be shown in the action
     * bar
     */
    public abstract int getActionBarTitle();

    /**
     * Sets the title of teaction bar from any child fragment (called when some different module's
     * fragment is called from some other master fragment
     */
    public void setActionBarTitle(final int title) {
        setActionBarTitle(title, true);
        final DrawerBaseActivity activity = (DrawerBaseActivity) this.getActivity();
        activity.changeLHNMenuHighlighting(title);
    }

    /**
     * Get the group that should be highlighted when the fragment is shown
     */
    public abstract int getGroupMenuLocation();

    /**
     * Get the sub section location under the group
     */
    public abstract int getSectionMenuLocation();

    /**
     * Used to show the provide feedback fragment
     *
     * NOTE: This has not been implemented yet, because the provide feedback
     * fragment has not been created
     */
//	public void showProvideFeedback() {
//		// TODO: Implement this
//	}

    /**
     * Used by a fragment when it's additionally using the
     * {@code ExtendingScrollView}. Implement when you need to perform an action
     * upon reaching the bottom of this scroll view.
     */
    public void scrollViewBottomReached() {
        // DO NOTHING, fragments *must* override this.
    }
}
