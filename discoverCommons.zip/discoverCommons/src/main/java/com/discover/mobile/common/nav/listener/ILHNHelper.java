package com.discover.mobile.common.nav.listener;

import com.discover.mobile.common.nav.utils.Launcher;

/**
 * Created by 468195 on 4/28/2016.
 */
public interface ILHNHelper {

    public Launcher getLHNItemLauncher(String componentKey);
}
