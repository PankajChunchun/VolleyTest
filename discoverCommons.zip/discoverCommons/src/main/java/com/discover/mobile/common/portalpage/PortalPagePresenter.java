package com.discover.mobile.common.portalpage;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;
import com.discover.mobile.common.shared.utils.PasscodeUtils;

import java.util.List;
import java.util.Map;

/**
 * Created by 436645 on 1/27/2017.
 */
interface PortalPagePresenter {

    void handlePortalItemClick(PortalBoxInterface dataItem, PortalAccountType accountType);
    void handleBadStatusAccounts(PortalBoxInterface dataItem, PasscodeUtils passcodeUtils, PortalAccountType accountType, boolean anrKillSwitchStatus);
    void handleDeeplink(PortalBoxInterface dataItem, PortalAccountType accountType, boolean isLeftDeeplink);
    void encrypt(String data);
    void decrypt(String data);
    List<PortalBoxInterface> getSortedPortalList(Map<String, PortalBoxInterface> originalPortalList);
    void saveUpdatedPortalListOrder(List<PortalBoxInterface> updatedPortalList);
}
