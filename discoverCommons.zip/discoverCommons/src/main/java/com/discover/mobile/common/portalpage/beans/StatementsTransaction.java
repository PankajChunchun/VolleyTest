package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class StatementsTransaction implements Serializable {
    private static final long serialVersionUID = -7602312727849947642L;

    @SerializedName("transactionAmount")
    private String transactionAmount;

    @SerializedName("transactionDate")
    private String transactionDate;

    @SerializedName("transactionDescription")
    private String transactionDescription;

    /**
     * @return The transactionAmount
     */
    public String getTransactionAmount() {
        return transactionAmount;
    }

    /**
     * @param transactionAmount The transactionAmount
     */
    public void setTransactionAmount(String transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    /**
     * @return The transactionDate
     */
    public String getTransactionDate() {
        return transactionDate;
    }

    /**
     * @param transactionDate The transactionDate
     */
    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    /**
     * @return The transactionDescription
     */
    public String getTransactionDescription() {
        return transactionDescription;
    }

    /**
     * @param transactionDescription The transactionDescription
     */
    public void setTransactionDescription(String transactionDescription) {
        this.transactionDescription = transactionDescription;
    }

}
