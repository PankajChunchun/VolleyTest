package com.discover.mobile.common.appmessaging.helper;

/**
 * Class to maintain App Level wink details
 */
public class WinkDetail {

    public static final int WITHOUT_WINK_AND_BADGE = 0;
    public static final int WITH_BADGE = 1;
    public static final int WITH_WINK = 2;
    private boolean isWinkAvilable;
    private int badgeCount;

    public boolean isWinkAvilable() {
        return isWinkAvilable;
    }

    public void setIsWinkAvilable(boolean isWinkAvilable) {
        this.isWinkAvilable = isWinkAvilable;
    }

    public int getBadgeCount() {
        return badgeCount;
    }

    public void setBadgeCount(int badgeCount) {
        this.badgeCount = badgeCount;
    }

    /**
     * Method to return view type for LHN generation
     */
    public int getViewType() {

        if (badgeCount > 0) {
            return WITH_BADGE;
        } else if (isWinkAvilable) {
            return WITH_WINK;
        }

        return WITHOUT_WINK_AND_BADGE;
    }
}
