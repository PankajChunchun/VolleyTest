package com.discover.mobile.common.permission.listener;

import com.discover.mobile.common.permission.utils.PermissionConstant;

/**
 * Permission listener interface. Child of {@link com.discover.mobile.common.nav.DiscoverBaseActivity}
 * or {@link com.discover.mobile.common.BaseChildFragment} can implement it, to listen
 * {@link PermissionListener#onPermissionDenied(PermissionConstant.Permissions)} or
 * {@link PermissionListener#onPermissionGranted(PermissionConstant.Permissions)}.
 * <p/>
 * <p/>
 * Created by pkuma13 on 8/24/2016.
 */
public interface PermissionListener {

    /**
     * Callback to listen if requested permission has been granted.
     *
     * @param permission {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions},
     *                          which can be used to know that which permission has been granted. Caller should always check it before doing
     *                          further task on permission granted.
     */
    void onPermissionGranted(PermissionConstant.Permissions permission);

    /**
     * Callback to listen if requested permission has not been granted.
     *
     * @param permission {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions},
     *                         which can be used to know that which permission has not been granted. Sometime a permission can be optional,
     *                         like you can show a page without having that permission having other features. So by checking which permission
     *                         has not been granted you can proceed further.
     */
    void onPermissionDenied(PermissionConstant.Permissions permission);
}
