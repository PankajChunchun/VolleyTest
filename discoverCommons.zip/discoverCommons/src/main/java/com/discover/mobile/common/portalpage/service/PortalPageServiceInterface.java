package com.discover.mobile.common.portalpage.service;

import com.discover.mobile.common.portalpage.beans.PortalAccountDetails;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Headers;
import retrofit.http.POST;

/**
 * Interface for request type used in Retro-fit for Portal Page services.
 *
 * @author slende
 */
public interface PortalPageServiceInterface {
    @Headers("Content-Type: application/json")
    @GET("/cardsvcs/acs/acct/v4/account")
    void getPortalAccountV4Details(Callback<PortalAccountDetails> portalAccountDetailsCallback);

    @Headers("Content-Type: application/json")
    @GET("/cardsvcs/acs/acct/v3/account")
    void getPortalAccountV3Details(Callback<PortalAccountDetails> portalAccountDetailsCallback);

    @Headers("Content-Type: application/json")
    @POST("/cardsvcs/acs/session/v1/delete")
    void logoutUser(Callback<Object> logoutEventListener);

    @Headers("Content-Type: application/json")
    @POST("/cardsvcs/acs/acct/v1/skipmerge")
    void skipMergeIntercept(Callback<Object> skipMergeCallback);
}
