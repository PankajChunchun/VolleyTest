package com.discover.mobile.common;

import com.discover.mobile.common.nav.DrawerBaseActivity;
import com.discover.mobile.common.nav.listener.IFragmentOnBackPressed;
import com.discover.mobile.common.widget.FragmentTransactions;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;

import java.lang.reflect.Field;

public abstract class BaseMasterFragment extends BaseFragment implements
        IFragmentOnBackPressed {

    private final String CHILD_FRAGMENT_MGR = "mChildFragmentManager";

    private final float MIN_PANEL_SIZE = 1.0f, DEFAULT_LEFT_AREA = 0.6f;
    private final float MAX_PANEL_SIZE = 0.0f, DEFAULT_RIGHT_AREA = 0.4f;
    protected Constants.MASTER_LAYOUT_TYPE master_layout_type = Constants.MASTER_LAYOUT_TYPE.WITHOUT_HEADER;
    /**
     * Start
     * boolean: "isBottomNavigationBarNeeded" to add bottom margin to accommodate bottom navigation submenu for SMC, Notification
     * & Messaging features
     */
    protected boolean isBottomNavigationBarNeeded = false;
    private int SUBMENU_BOTTOM_MARGING = 58;
    private LinearLayout leftRightContainerLL;
    /** End */

    View mainView;
    float leftSize, rightSize;

    abstract public int getSectionMenuLocationName();

    abstract public int getGroupMenuLocationName();

    @Override
    abstract public int getActionBarTitle();

    /*
     * Do Service calls or launch landing or first fragment of the module.
    */
    abstract public void init();

    public void initialize() {
        if (null != getActivity()) {
            init();
        } else {
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    initialize();
                }
            }, 100);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
        switch (master_layout_type) {

            case WITH_HEADER:
                mainView = inflater.inflate(R.layout.master_fragment_with_header, null);
                //added for US89215 - Messaging App SDK Integration
                leftRightContainerLL = (LinearLayout) mainView.findViewById(R.id.left_right_frag_container);
                break;

            case WITHOUT_HEADER:

                mainView = inflater.inflate(R.layout.master_fragment, null);
                //added for US89215 - Messaging App SDK Integration
                leftRightContainerLL = (LinearLayout) mainView.findViewById(R.id.withHeader);

                break;
        }


        // Resize the Frames as per Platform
        leftSize = MAX_PANEL_SIZE;
        rightSize = MIN_PANEL_SIZE;

        if (enableSplitView() && !Utils.isRunningOnHandset(getActivity())) {
            leftSize = getLeftFrameArea();
            rightSize = getRightFrameArea();
        }

        //not sure why mainView was null - caused null pointer issue when returned from Authenticated webviews
        if (mainView != null) {
            LayoutParams param = new LayoutParams(
                    LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, leftSize);
            FrameLayout leftFrame = (FrameLayout) mainView
                    .findViewById(R.id.left_frame);
            leftFrame.setLayoutParams(param);

            LayoutParams param1 = new LayoutParams(
                    LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, rightSize);
            FrameLayout rightFrame = (FrameLayout) mainView
                    .findViewById(R.id.right_frame);
            rightFrame.setLayoutParams(param1);

            //added for US89215 - Messaging App SDK Integration
            setFragmentContainerMargin();
        }
        return mainView;
    }

    public float getLeftFrameArea() {
        return DEFAULT_LEFT_AREA;
    }

    public float getRightFrameArea() {
        return DEFAULT_RIGHT_AREA;
    }

    public void showInLeftFrame(final Fragment frag) {
        showInLeftFrame(frag, true);
    }

    public void showInRightFrame(final Fragment frag) {
        showInRightFrame(frag, true);
    }

    public void showInLeftFrame(final Fragment frag, boolean addToHistory) {
        pushFragment(frag, R.id.left_frame, addToHistory);
    }

    public void showInRightFrame(final Fragment frag, boolean addToHistory) {
        pushFragment(frag, R.id.right_frame, addToHistory);
    }

    protected void pushFragment(Fragment frag, int iFrameID, boolean addToHistory) {
        // Fix for IllegalStateException - Fabric START
        Activity act = com.discover.mobile.common.shared.DiscoverActivityManager.getActiveActivity();
        if (act instanceof DrawerBaseActivity && ((DrawerBaseActivity) act).isActivityPaused)
        {
            FragmentTransactions ft = new FragmentTransactions(frag, iFrameID, addToHistory, this.getClass().getSimpleName());
            ((DrawerBaseActivity)act).addOperation(ft);
            return;
        }
        // Fix for IllegalStateException - Fabric END
        FragmentTransaction fragmentTransaction = getChildFragmentManager()
                .beginTransaction().replace(iFrameID, frag,
                        frag.getClass().getSimpleName());
        if (addToHistory)
            fragmentTransaction.addToBackStack(frag.getClass().getSimpleName());
        fragmentTransaction.commitAllowingStateLoss();
    }

    // Fix for IllegalStateException - Fabric START
    public void pushFragmentFromAct(Fragment frag, int iFrameID, boolean addToHistory) {
        pushFragment(frag, iFrameID, addToHistory);
    }
    // Fix for IllegalStateException - Fabric END

    @Override
    public int getGroupMenuLocation() {
        return 0;
    }

    @Override
    public int getSectionMenuLocation() {
        return 0;
    }


    @Override
    public boolean onBackPressed() {
        int iBackCount = getChildFragmentManager().getBackStackEntryCount();

        if (iBackCount > 1) {
            // Fix for IllegalStateException - Fabric START
            Activity act = com.discover.mobile.common.shared.DiscoverActivityManager.getActiveActivity();
            if (act instanceof DrawerBaseActivity && ((DrawerBaseActivity) act).isActivityPaused)
            {
                FragmentTransactions ft = new FragmentTransactions(FragmentTransactions.TransactionType.BACK_PRESSED_MF, this.getClass().getSimpleName());
                ((DrawerBaseActivity)act).addOperation(ft);
                return true;
            }
            // Fix for IllegalStateException - Fabric END
            getChildFragmentManager().popBackStackImmediate();
            return true;
        }
        return false;
    }

    /**
     * @param strFragTag  : Fragment getSimpleName()
     * @param isInclusive : True if want to remove fragment and false if want to keep fragment in
     *                    stack
     */
    public boolean onBackPressed(String strFragTag, Boolean isInclusive) {
        if (getChildFragmentManager().getBackStackEntryCount() > 1) {
            // Fix for IllegalStateException - Fabric START
            Activity act = com.discover.mobile.common.shared.DiscoverActivityManager.getActiveActivity();
            if (act instanceof DrawerBaseActivity && ((DrawerBaseActivity) act).isActivityPaused)
            {
                FragmentTransactions ft = new FragmentTransactions(strFragTag, isInclusive, this.getClass().getSimpleName());
                ((DrawerBaseActivity)act).addOperation(ft);
                return true;
            }
            // Fix for IllegalStateException - Fabric END
            if (isInclusive) {
                getChildFragmentManager().popBackStackImmediate(strFragTag,
                        FragmentManager.POP_BACK_STACK_INCLUSIVE);
            } else {
                getChildFragmentManager().popBackStackImmediate(strFragTag, 0);
            }

            return true;
        }
        return false;
    }

    public void clearingChildFragments() {
        // Fix for IllegalStateException - Fabric START
        Activity act = com.discover.mobile.common.shared.DiscoverActivityManager.getActiveActivity();
        if (act instanceof DrawerBaseActivity && ((DrawerBaseActivity) act).isActivityPaused)
        {
            FragmentTransactions ft = new FragmentTransactions(FragmentTransactions.TransactionType.CLEAR_CHILDS, this.getClass().getSimpleName());
            ((DrawerBaseActivity)act).addOperation(ft);
            return;
        }
        // Fix for IllegalStateException - Fabric END
        int childCount = getChildFragmentManager().getBackStackEntryCount();
        if (childCount >= 1 && isVisible()) {
            for (int i = 0; i < childCount; i++) {
                getChildFragmentManager().popBackStackImmediate();
            }
        }
    }

    /**
     * Method to add bottom marging to Fragment container
     * Method added for US89215 - Messaging App SDK Integration
     */
    public void setFragmentContainerMargin() {
        if (isBottomNavigationBarNeeded && null != leftRightContainerLL && null != getHost()) {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            RelativeLayout.LayoutParams leftRightContainerParams = (RelativeLayout.LayoutParams) leftRightContainerLL.getLayoutParams();
            leftRightContainerParams.bottomMargin = Utils.dpToPx(SUBMENU_BOTTOM_MARGING, displayMetrics);
        }
    }

    /**
     * Method to remove bottom marging to Fragment container
     * Method added for US89215 - Messaging App SDK Integration
     */
    public void reSetFragmentContainerMargin() {
        if (isBottomNavigationBarNeeded && null != leftRightContainerLL && null != getHost()) {
            RelativeLayout.LayoutParams leftRightContainerParams = (RelativeLayout.LayoutParams) leftRightContainerLL.getLayoutParams();
            leftRightContainerParams.bottomMargin = 0;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            Field childFragmentManager = Fragment.class
                    .getDeclaredField("mChildFragmentManager");
            if(childFragmentManager!=null) {
                childFragmentManager.setAccessible(true);
                childFragmentManager.set(this, null);
            }
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean enableSplitView() {
        return false;
    }

    public boolean isOrientationHandled() {
        return false;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        // Resize the Frames as per Platform
        leftSize = MAX_PANEL_SIZE;
        rightSize = MIN_PANEL_SIZE;

        if (enableSplitView() && !Utils.isRunningOnHandset(getActivity())) {
            leftSize = getLeftFrameArea();
            rightSize = getRightFrameArea();
        }
        if (mainView != null) {
            LayoutParams param = new LayoutParams(
                    LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, leftSize);
            FrameLayout leftFrame = (FrameLayout) mainView
                    .findViewById(R.id.left_frame);
            leftFrame.setLayoutParams(param);

            LayoutParams param1 = new LayoutParams(
                    LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, rightSize);
            FrameLayout rightFrame = (FrameLayout) mainView
                    .findViewById(R.id.right_frame);
            rightFrame.setLayoutParams(param1);

            //added for US89215 - Messaging App SDK Integration
            setFragmentContainerMargin();
        }
        super.onConfigurationChanged(newConfig);
    }

    public void setFrameSize(boolean isSplit) {
        leftSize = MAX_PANEL_SIZE;
        rightSize = MIN_PANEL_SIZE;

        if (isSplit && !Utils.isRunningOnHandset(getActivity())) {
            leftSize = getLeftFrameArea();
            rightSize = getRightFrameArea();
        }

        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, leftSize);
        FrameLayout leftFrame = (FrameLayout) mainView
                .findViewById(R.id.left_frame);
        leftFrame.setLayoutParams(param);

        LinearLayout.LayoutParams param1 = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, rightSize);
        FrameLayout rightFrame = (FrameLayout) mainView
                .findViewById(R.id.right_frame);
        rightFrame.setLayoutParams(param1);

        //added for US89215 - Messaging App SDK Integration
        setFragmentContainerMargin();
    }

    public View getParentView() {
        return mainView;
    }
}
