package com.discover.mobile.common.nav;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;

import java.util.List;

/**
 * Responder controls a group of sub-items.
 */
public class GroupNavigationItem extends NavigationItem {

    /** List of children available */
    private final List<NavigationItem> children;
    /** true when this item's ComponentInfo has set its own listener. */
    private final boolean overrideClick;
    /** State of the view */
    private boolean expanded;

    /**
     * Constructor for the class
     *
     * @param navigationItemAdapter - adapter displaying the view
     * @param view                  - this view
     * @param children              - the children items
     * @param absoluteIndex         - absolute index
     */
    public GroupNavigationItem(final NavigationItemAdapter navigationItemAdapter, final NavigationItemView view,
                               final List<NavigationItem> children, final int absoluteIndex) {

        super(navigationItemAdapter, view, absoluteIndex);
        this.children = children;
        overrideClick = NavigationItem.section.get(absoluteIndex).getPushClick() != null;
    }

    @Override
    void onClick(final ListView listView, final View clickedView) {

        // Determine if click listener was overridden
        if (overrideClick) {
            onClickOverride(clickedView);
            adapter.notifyDataSetChanged();
            return;
        }

        // Use default expand/collapse commands
        if (expanded) {
            collapse();
        } else {
            expand();
        }

        if (view.getComponentInfo() instanceof BadgeGroupComponentInfo) {
            ((BadgeGroupComponentInfo) view.getComponentInfo()).setExpanded(expanded);
        }
    }

    /**
     * Performs the onClick method associated with the ComponentInfo and updates the adapter
     * accordingly.
     */
    private void onClickOverride(final View clickedView) {
        if (!expanded && adapter.getSelectedItem() instanceof GroupNavigationItem) {
            // Another group is expanded -- collapse it
            ((GroupNavigationItem) adapter.getSelectedItem()).collapse();
        }

        // Initiate the click listener associated with the ComponentInfo.
        final OnClickListener groupListener = NavigationItem.section.get(absoluteIndex).getPushClick();
        groupListener.onClick(clickedView);

        // Update the index and adapter
        NavigationIndex.setIndex(absoluteIndex);
        adapter.setSelectedItem(this);
    }

    /**
     * Expand the the item
     */
    public void expand() {
        if (expanded) {
            return;
        }
        final NavigationItem selectedItem = adapter.getSelectedItem();
        if (selectedItem instanceof GroupNavigationItem) {
            ((GroupNavigationItem) selectedItem).collapse();
        }

        for (final NavigationItem child : children) {
            child.show();
        }
        expanded = true;
        NavigationIndex.setIndex(absoluteIndex);
        adapter.setSelectedItem(this);
    }

    /**
     * Collapse the item
     */
    public void collapse() {
        if (!expanded) {
            return;
        }
        for (final NavigationItem child : children) {
            child.hide();
        }

        adapter.setSelectedItem(null);

        // Save the current group section being highlighted
        final int mainIndex = NavigationIndex.getMainIndex();

        // Set Index to -1 to store the current state of the menu into the previous state of the menu
        // So when the menu is expanded it will be restored to the previous state.
        NavigationIndex.setIndex(-1);

        // Set the mainIndex so the group section is still highlighted when collapsed
        NavigationIndex.setIndex(mainIndex);
        expanded = false;
    }

}
