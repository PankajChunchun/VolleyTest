package com.discover.mobile.common.shared;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.shared.utils.StringUtility;

import java.util.Observable;
import java.util.Observer;

/**
 * Utility class used to keep a reference of the active activity for the application. Base classes
 * such as
 * BaseActivity, BaseFragmentActivity, and NotLoggedInRoboActivity all call setActiveActivity
 * onResume().
 * This class allows to keep a single reference of the activity in focus to be used by all other
 * classes
 * that may need to interact with
 * the active activity
 *
 * @author henryoyuela
 */
public final class DiscoverActivityManager extends Observable {
    /**
     * Singleton instance of DiscoverActivityManager
     */
    private static final DiscoverActivityManager instance = new DiscoverActivityManager();
    /**
     * Reference to the application's active activity set via setActiveActivity()
     */
    private static Activity mActivity;
    private static Activity loginActivityInstance;
    private static Context discoverApplicationContext;
    /**
     * Holds the class type of the previous activity that was the active activity
     */
    private Class<?> mPrevActivityClass;
    /**
     * This holds the current active activity which must be instance of AppCompactActivity.
     * Implementation of this attribute is not similar to get-setActiveActivity().
     *
     * You should use this attribute only to avoid typecasting context.
     */
    private static AppCompatActivity mAppCompatActivity;

    private DiscoverActivityManager() {
    }

    /**
     * @return Returns a reference to the active activity set via setActiveActivity
     */
    public static Activity getActiveActivity() {
       // Defect #2013. Fixed as part of 7.9 release regression phase.
        if(instance != null){
            return instance.mActivity;
        }else {
            return null;
        }
    }

    /**
     * @param activity - Set to the current activity for the application
     */
    public static void setActiveActivity(final Activity activity) {
        /**
         * Store the class type of the current active activity as the previous active activity,
         * if it is not null and the new active activity is different from current active activity.
         */
        if (null != instance.mActivity && activity.getClass() != instance.mActivity.getClass()) {
            instance.mPrevActivityClass = mActivity.getClass();
        }

        if (activity.getClass().equals(LoginActivity.class))
            instance.loginActivityInstance = activity;

        instance.mActivity = activity;

        instance.setChanged();

        instance.notifyObservers(activity);
    }


    public static Activity getLoginActivity() {
        return instance.loginActivityInstance;
    }

    /**
     * @return Returns the class type of the previous Active Activity
     */
    public static Class<?> getPreviousActiveActivity() {
        return instance.mPrevActivityClass;
    }

    /**
     * Used to clear the previsou active activity class type stored.
     */
    public static void clearPreviousActiveActivity() {
        instance.mPrevActivityClass = null;
    }


    /**
     * Adds an observer to the set of observers for this object, provided
     * that it is not the same as some observer already in the set. This
     * Observer will be called whenever the active Activity is changed
     * via this class using the method setActiveActivity().
     *
     * @param o an observer to be added.
     */
    public static void addListener(final Observer o) {
        instance.addObserver(o);
    }

    /**
     * Deletes an observer from the set of observers of this object.
     *
     * @param o an observer to be Remvoed.
     */
    public static void removeListener(final Observer o) {
        instance.deleteObserver(o);
    }

    public static String getString(final int resourceID) {
        /**
         * Changes made for US34562 -rjagdal
         * Using application context instead of active activity
         *
         */
        Context context = DiscoverApplication.getGlobalContext();
        if (context == null) {
            return StringUtility.SPACE;
        } else {
            return context.getString(resourceID);
        }
    }

    /**
     * @return current activity instance. You should only use to avoid typecasting of activity
     * context.
     * <p/>
     * <b>This is not replacement of {@link DiscoverActivityManager#getActiveActivity()}</b>
     */
    public static AppCompatActivity getActiveAppCompatActivity() {
        return mAppCompatActivity;
    }

    /**
     * Sets the AppCompatActivity. This must be called only from
     * {@link com.discover.mobile.common.nav.DiscoverBaseActivity}.
     * <p/>
     * <b>This is not replacement of {@link DiscoverActivityManager#setActiveActivity(Activity)}</b>
     *
     * @param activity
     */
    public static void setActiveAppCompatActivity(final AppCompatActivity activity) {
        mAppCompatActivity = activity;
    }

    /**
     * @return current context which will be used by CookieManagerProxy for network service call. when service is started by GeofenceBroadcastReceiver.
     * context.
     * <p/>
     */

    public static Context getDiscoverApplicationContext() {
        if (null != getActiveActivity())
            return getActiveActivity();

        if (null != instance.discoverApplicationContext)
            return instance.discoverApplicationContext;

        return DiscoverApplication.getGlobalContext();

    }

    /**
     *
     * @param applicationContext Service context when service is started by GeofenceBroadcastReceiver.
     */
    public static void setDiscoverApplicationContext(Context applicationContext) {
        instance.discoverApplicationContext = applicationContext;
    }
}

