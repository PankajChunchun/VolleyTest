package com.discover.mobile.common.appmessaging.ui;

import com.discover.mobile.common.R;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * This Level 3 app messaging dialog displays a title, Image content, sub title, body text followed
 * by a
 * and contains two buttons. The dialog will be cetered and will resize based on the dialog content
 **/
public class Level3AppMessagingDialog extends AlertDialog {

    /** Declarations**/

    /**
     * Level Message Button holder
     */
    private LinearLayout mButtonHolder;

    /**
     * /*Action Buttons in the Message Dialog
     */
    Button mCloseButton, mDynamicButtonOne;
    /*AppMessaging Content Layout*/
    RelativeLayout mModalLayout;
    /**
     * Root view that is to be inflated in the dialog
     **/
    private View mView;
    /**
     * Dialog Title Text View
     **/
    private TextView mMessageTitle;
    /**
     * Dialog SubTitle Text View
     **/
    private TextView mMessageSubTitle;
    /**
     * Dialog Body Text View
     **/
    private TextView mMessageBody;
    /**
     * Dialog Image View
     **/
    private ImageView mMessageImageView;
    /**
     * To save the context received from the parent of the dialog
     **/
    private Context mContext;

    /**
     * Dialog constructor. Gets context and message's key as arguments.
     **/
    public Level3AppMessagingDialog(final Context context) {
        super(context);
        mView = getLayoutInflater().inflate(
                R.layout.level3_app_messaging_dialog, null);

        /** Arguments received from implementation class **/
        this.mContext = context;

        /** Initializing views**/
        mModalLayout = (RelativeLayout) mView.findViewById(R.id.modal_layout);
        mMessageTitle = (TextView) mView.findViewById(R.id.message_title);
        mMessageSubTitle = (TextView) mView.findViewById(R.id.message_sub_title);
        mMessageBody = (TextView) mView.findViewById(R.id.message_body_text);
        mMessageImageView = (ImageView) mView.findViewById(R.id.message_imageview);
        mButtonHolder = (LinearLayout)mView.findViewById(R.id.lvl_msg_button_holder);
        mCloseButton = (Button) mView.findViewById(R.id.close_button);
        mDynamicButtonOne = (Button) mView.findViewById(R.id.deeplink_button_one);

    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(mView);
    }

    public void setMessageTitleText(String messageTitle) {
        mMessageTitle.setText(messageTitle);
        mMessageTitle.setContentDescription(messageTitle);
    }

    public void setMessageSubTitleText(String messageSubTitle) {
        mMessageSubTitle.setText(messageSubTitle);
        mMessageSubTitle.setContentDescription(messageSubTitle);
    }

    public void setMessageBodyText(String messageBody) {
        mMessageBody.setText(messageBody);
        mMessageBody.setContentDescription(messageBody);
    }

    public void setCloseButtonText(String closeButtonText) {
        mCloseButton.setText(closeButtonText);
    }


    public Button getCloseButton() {
        return mCloseButton;
    }

    public Button getDynamicButtonOne() {
        return mDynamicButtonOne;
    }

    public void setDynamicButtonOne(String dynamicButtonOne) {
        mDynamicButtonOne.setText(dynamicButtonOne);
    }

    public ImageView getMessageImageView() {
        return mMessageImageView;
    }

    public void setMessageImageView(Bitmap bitmap) {
        mMessageImageView.setImageBitmap(bitmap);
    }

    /**
     * Method to set the button alignment based on button character length
     * US72800 - Level 3 Button Arrangement
     */
    public void setButtonAlignment(){

        if(mDynamicButtonOne!=null && mCloseButton!=null){
            int lineCount = mDynamicButtonOne.getLineCount();

            if(lineCount>1){

                //Set the button in vertical alignment
                //Set vertical orientation
                mButtonHolder.setOrientation(LinearLayout.VERTICAL);

                //Set height as wrap content
                RelativeLayout.LayoutParams buttonHolderParams = (RelativeLayout.LayoutParams) mButtonHolder.getLayoutParams();
                buttonHolderParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                mButtonHolder.setLayoutParams(buttonHolderParams);

                //Remove and add the primary button as first child
                mButtonHolder.removeView(mDynamicButtonOne);
                mButtonHolder.addView(mDynamicButtonOne,0);

                //Close button parameter
                LinearLayout.LayoutParams closeBtnParams = (LinearLayout.LayoutParams) mCloseButton.getLayoutParams();
                mCloseButton.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);

                //Set the close button margin for vertical alignment
                int topInDB = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 16, mContext.getResources().getDisplayMetrics());
                int bottomInDB = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 4, mContext.getResources().getDisplayMetrics());

                closeBtnParams.setMargins(0,topInDB,0,bottomInDB);
            }

        }

    }

}

