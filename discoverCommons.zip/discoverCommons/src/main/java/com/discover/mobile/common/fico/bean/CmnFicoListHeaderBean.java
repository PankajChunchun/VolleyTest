package com.discover.mobile.common.fico.bean;

import com.discover.mobile.common.fico.interfaces.CmnFicoListItemInterface;

/**
 * Class to hold List Header data
 *
 * @author slende
 */
public class CmnFicoListHeaderBean implements CmnFicoListItemInterface {

    private String column1Title;
    private String column2Title;
    private String column3Title;

    public String getColumn1Title() {
        return column1Title;
    }

    public void setColumn1Title(String column1Title) {
        this.column1Title = column1Title;
    }

    public String getColumn2Title() {
        return column2Title;
    }

    public void setColumn2Title(String column2Title) {
        this.column2Title = column2Title;
    }

    public String getColumn3Title() {
        return column3Title;
    }

    public void setColumn3Title(String column3Title) {
        this.column3Title = column3Title;
    }
}
