package com.discover.mobile.common.fico.bean;

/**
 * Created by 451769 on 5/10/2017.
 */

public class FicoCollapsedDetails {

    private String collapsedBoxTitle;
    private String collapsedBoxValue;
    private String expandedViewValueOne;
    private String expandedViewValueTwo;
    private String expandedViewValueThree;
    private int ratingColorValue;
    private String boxRating;
    private boolean isBoxExpansionDisabled;

    public boolean isBoxExpansionDisabled() {
        return isBoxExpansionDisabled;
    }

    public void setBoxExpansionDisabled(boolean boxExpansionDisabled) {
        isBoxExpansionDisabled = boxExpansionDisabled;
    }

    public FicoCollapsedDetails(String collapsedBoxTitle, String collapsedBoxValue, String expandedViewValueTwo, String expandedViewValueOne, String expandedViewValueThree, int colorInt, String boxRating, boolean isBoxExpansionDisabled) {
        this.collapsedBoxTitle = collapsedBoxTitle;
        this.collapsedBoxValue = collapsedBoxValue;
        this.expandedViewValueOne = expandedViewValueOne;
        this.expandedViewValueTwo = expandedViewValueTwo;
        this.expandedViewValueThree = expandedViewValueThree;
        this.ratingColorValue = colorInt;

        this.boxRating = boxRating;
        this.isBoxExpansionDisabled = isBoxExpansionDisabled;
    }

    public String getBoxRating() {
        return boxRating;
    }

    public void setBoxRating(String boxRating) {
        this.boxRating = boxRating;
    }

    public String getCollapsedBoxTitle() {

        return collapsedBoxTitle;
    }

    public String getExpandedViewValueThree() {
        return expandedViewValueThree;
    }

    public void setExpandedViewValueThree(String expandedViewValueThree) {
        this.expandedViewValueThree = expandedViewValueThree;
    }

    public void setCollapsedBoxTitle(String collapsedBoxTitle) {
        this.collapsedBoxTitle = collapsedBoxTitle;
    }

    public String getCollapsedBoxValue() {
        return collapsedBoxValue;
    }

    public void setCollapsedBoxValue(String collapsedBoxValue) {
        this.collapsedBoxValue = collapsedBoxValue;
    }

    public String getExpandedViewValueOne() {
        return expandedViewValueOne;
    }

    public void setExpandedViewValueOne(String expandedViewValueOne) {
        this.expandedViewValueOne = expandedViewValueOne;
    }

    public String getExpandedViewValueTwo() {
        return expandedViewValueTwo;
    }

    public void setExpandedViewValueTwo(String expandedViewValueTwo) {
        this.expandedViewValueTwo = expandedViewValueTwo;
    }

    public int getRatingColorValue() {
        return ratingColorValue;
    }
}
