package com.discover.mobile.common.nav;

import com.discover.mobile.common.nav.section.ClickComponentInfo;

import android.view.View.OnClickListener;

/**
 * Click component info that has the ability to show the badge
 *
 * @author jthornton
 */
public abstract class BadgeClickComponentInfo extends ClickComponentInfo {

    /** Listener to apply to the badge */
    private OnClickListener badgeListener;

    /**
     * Constructor for the class
     *
     * @param titleResource - resource string to display
     * @param listener      - listener to apply to this section
     */
    public BadgeClickComponentInfo(final int titleResource, final OnClickListener listener) {
        super(titleResource, listener);
    }

    /**
     * Constructor for the class
     *
     * @param titleResource - resource string to display
     * @param isUrl         - true if this take the user out of the app
     * @param listener      - listener to apply to this section
     */
    public BadgeClickComponentInfo(final int titleResource, final boolean isUrl,
                                   final OnClickListener listener) {
        super(titleResource, isUrl, listener);
    }

    /**
     * Constructor for the class
     *
     * @param titleResource - resource string to display
     * @param isUrl         - true if this takes the user out of the app
     * @param listener      - listener to apply to this section
     * @param badgeListener - listener to apply to the badge
     */
    public BadgeClickComponentInfo(final int titleResource, final boolean isUrl,
                                   final OnClickListener listener, final OnClickListener badgeListener) {
        super(titleResource, isUrl, listener);
        this.badgeListener = badgeListener;
    }

    /**
     * @return true if the badge should be displayed
     */
    public abstract boolean shouldBadgeBeDisplayed();

    /**
     * @return return the string value that should be displayed
     */
    public abstract String getBadgeValue();

    /**
     * @return if the badge has a special on click
     */
    public boolean doesSpecialOnClick() {
        return null != badgeListener;
    }

    /**
     * @return the listner of that the badge should execute
     */
    public OnClickListener getSpecialOnClick() {
        return badgeListener;
    }

}
