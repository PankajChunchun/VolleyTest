package com.discover.mobile.common.net.cookie;

import com.discover.mobile.common.facade.FacadeFactory;

import android.content.Context;
import android.util.Log;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import retrofit.client.Response;

/**
 * Class used to manage the secToken , dfsKey , V1st etc .provided via cookies .
 * After the secToken dfsKey and V1st are extracted from the cookies it is
 * stored in this class which follows a Singleton design pattern. This class can
 * be used to clear the secToken.
 *
 * @author Mayank G
 */

public final class BankSessionCookieManager {

    private static final String TAG = BankSessionCookieManager.class
            .getSimpleName();
    private static BankSessionCookieManager sessionCookieManager;
    private URI baseUri;
    private BankCookieManagerProxy cookieManager;
    private List<String> cookiesList;

    /**
     * Follows a singleton design pattern. Therefore this constructor is made
     * private
     */

    private BankSessionCookieManager(final Context context) {

        cookieManager = new BankCookieManagerProxy(context);
    }

    public static synchronized BankSessionCookieManager getInstance(
            final Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Invalid context argument");
        }

        if (sessionCookieManager == null) {
            sessionCookieManager = new BankSessionCookieManager(context);
        }
        return sessionCookieManager;
    }

    public List<String> getCookiesList() {
        return getCookieList();
    }

    private List<String> getCookieList() {

        URI uri = getBaseUri();

        try {

            Map<String, List<String>> cookies = cookieManager.get(uri, null);

            if (cookies == null || cookies.get("Cookie") == null
                    || cookies.get("Cookie").size() == 0) {
                // No cookies, return null
                Log.d(TAG,
                        "getCookieValue: No cookues retrieved for "
                                + uri.toURL());
                return null;
            }

            List<String> cList = cookies.get("Cookie");

            return cList;

        } catch (IOException e) {
            return null;
        }

    }

    public void putCookiesList(Map<String, List<String>> headers) {

        URI uri = getBaseUri();

        try {
            cookieManager.put(uri, headers);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void putCookiesListRetrofit(Response arg1) {

        String uri = getBaseUri().toString();

        try {
            cookieManager.putCookiesRetrofit(uri, arg1);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public URI getBaseUri() {

        if (null == baseUri) {

            String url = FacadeFactory.getBankLoginFacade().getBankBaseURL();

            try {
                baseUri = new URI(url);
            } catch (final URISyntaxException e) {
                // This is pretty bad, since the URL should always be parseable.
                throw new IllegalArgumentException(
                        "Environment base url not parseable as URI: " + url);
            }
        }
        return baseUri;
    }

    /**
     * This method will clear the current cookies stored in cookiemanager
     */
    public void clearAllCookie() {
        try {

            cookieManager.clearAllCookies();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public BankCookieManagerProxy getCookieManager() {
        return cookieManager;
    }
}
