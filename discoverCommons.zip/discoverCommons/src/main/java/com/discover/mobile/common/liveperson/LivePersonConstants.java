package com.discover.mobile.common.liveperson;

/**
 * Created by 436645 on 3/16/2017.
 */
public interface LivePersonConstants {

    /** brandID from Live Persons Portal for Discover App */
    String brandID = "3824612"; // Test: 26375413 // Prod: 3824612

    /** appID registered to Live Persons Portal for Discover App */
    String appID = "com.discoverfinancial.mobile";

    String xidKey = "xid";
    String lpNotificationKey = "lpNotification";
    String lpNotificationValue = "fromLPPushNotification";
    String PAGE_CODE = "linktomessaging";
    String KEY_EDSKEY = "edsKey";
    String gatewayOauthURL = "https://api.discover.com/dfs/auth/oauth/v2/authorize?response_type=code&scope=openid%20LivePerson_USER_INFO&client_id=l7xx4b2ae4a4d6dc46c19ef6588fceebd303&redirect_uri=https://liveperson.net&state=openidconnect_state";
}

