package com.discover.mobile.common.fico.fragments;

import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.fico.adapter.CmnFicoKeyFactorsListAdapter;
import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.bean.FicoScoreList;
import com.discover.mobile.common.fico.bean.NegativeKeyFactor;
import com.discover.mobile.common.fico.bean.PositiveKeyFactor;
import com.discover.mobile.common.fico.utils.FicoCreditScoreConstants;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.nav.DrawerBaseActivity;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.widget.FragmentTransactions;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * DialogFragment class which designed for common dialog for FICO  Credit Scorecard
 * US135898
 */

public class CmnFicoKeyFactorAlertDialog extends DialogFragment {

    // Common attributes
    private AppCompatActivity mActivity;
    private View mDialogParentView;
    private boolean mCancelable = true;
    private boolean mCanceledOnTouchOutside = true;
    private DialogInterface.OnCancelListener mOnCancelListener;
    private DialogInterface.OnShowListener mShownListener;
    private DialogInterface.OnDismissListener mOnDismissListener;
    private DialogInterface.OnKeyListener mOnKeyListener;
    private boolean isShowFullScreenDialog;
    public int TABLET_FIXED_DIALOG_WIDTH_IN_DP = 64;
    private final int HANDSET_TOP_MARGIN = 24;
    private final int HANDSET_TOP_MARGIN_ABOVE_L = 48;
    private final int HANDSET_BOTTOM_MARGIN = 34;
    private final int HANDSET_LEFT_MARGIN = 16;
    private final int HANDSET_RIGHT_MARGIN = 16;
    private boolean modalSizing = false;

    /** start Key-factors changes */
    private int posExpListGroupHeight = 0;
    private int negExpListGroupHeight = 0;
    private int posExpListGroupSelected = -11;
    private int negExpListGroupSelected = -11;
    private int LIST_RENDERING_DELAY_INMISEC = 200;
    public ImageButton listLeftNavImgModelBtn, listRightNavImgModelBtn;
    private CmnFicoKeyFactorAlertDialog.OnBackPressedListener mOnBackPressedListener;
    private View cmnFicoKeyFactorsModalContainer;
    private Button ficoCancelBtn;
    private ExpandableListView positiveKeyFactorsListView;
    private ExpandableListView nagavtiveKeyFactorsListView;
    private View cmnFicoPosKeyFactorsSep,cmnFicoPosKeyFactorsSepBottom,cmnFicoNegKeyFactorsSep;
    private RelativeLayout positiveKeyFactorsRoot;
    private RelativeLayout negativeKeyFactorsRoot;
    /** end Key-factors changes */
    private TextView ficoScoreModalTxt, ficoScoreBoxModalTitleTxt, ficoScoreValueText, ficoScoreRangeModalText, scoreTotalAccountValueTxt, scoreLengthOfCreditValueTxt, scoreInquiresValueTxt, scoreRevolvingValueTxt, scoreMissedPayValueTxt;
    private View scoreModalColorView, scoreTotalAccountColorView, scoreLengthOfCreditColorView, scoreInquiresColorView, scoreRelvovingColorView, scoreMissedPayColorView;
    private TextView keyFactorDesTxtV;
    private FicoCreditScore mFicoCreditScore;
    private FicoScoreList mFicoScoreListItem;
    private Context mContext;
    private int mSelectedListIndex = -1;
    private int LIST_MIN_INDEX = -1;
    private int LIST_COUNT;
    private LinearLayout ficoScoreLayout, ficoCollapseBoxLayout;
    private RelativeLayout scoreDataContainerLayout;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Handle orientation change.
        setRetainInstance(true);
        Bundle dataBundle = getArguments();
        if (null != dataBundle) {
            if (null != dataBundle.getSerializable(FicoCreditScoreConstants.FICO_CREDIT_SCORE)) {
                mFicoCreditScore = (FicoCreditScore) dataBundle.getSerializable(FicoCreditScoreConstants.FICO_CREDIT_SCORE);
                if (null != mFicoCreditScore && null != mFicoCreditScore.getFicoScoreList()) {
                    LIST_COUNT = mFicoCreditScore.getFicoScoreList().size();
                }
            }
            if (null != dataBundle.getSerializable(FicoCreditScoreConstants.FICO_SELECTED_LIST_ITEM)) {
                mFicoScoreListItem = (FicoScoreList) dataBundle.getSerializable(FicoCreditScoreConstants.FICO_SELECTED_LIST_ITEM);
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        mDialogParentView = inflater.inflate(R.layout.cmn_fico_credit_score_keyfactor_new_modal, container, false);
        initDialogView();
        setupListeners();
        if (null != mFicoScoreListItem) {
            setScoreBoxDetails(mFicoScoreListItem);
            showKeyfactors(mFicoScoreListItem.getPositiveKeyFactors(), mFicoScoreListItem.getNegativeKeyFactors());
            setSelectedListIndex();
            setUpListNavigator();
        }
        return mDialogParentView;
    }

    private void setScoreBoxDetails(FicoScoreList ficoScoreList) {
        String limitedAuthUserError = null, noRevolvingTradeError = null, ficoTotalError = null;
        boolean areKeyFactorsUnavailable = false;
        boolean setGreyClrForTotalAccounts = false, setGreyClrForCreditLength = false, setGreyClrForInquiries = false, setGreyClrForRevUti = false, setGreyClrForMissedPayments = false;
        limitedAuthUserError = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.CMN_FICO_lIMITED_AUTHOR_USER_ERROR); //-0999999998
        noRevolvingTradeError = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.CMN_FICO_NO_REVOLVING_TRADE_ERROR); //-0999999989
        ficoTotalError = InfoMessageUtils.Instance().getErrorMessage(FicoCreditScoreConstants.FicoInfoMsg.CMN_FICO_TOTAL_ERROR);
        if (ficoScoreList != null) {
            ficoScoreModalTxt.setText(CommonUtils.getHtmlFormattedText(mActivity.getResources().getString(R.string.cmn_fico_month_score_modal_des)));
            if (ficoScoreList.getScoreDate() != null) {
                ficoScoreBoxModalTitleTxt.setText("As of " + ficoScoreList.getScoreDate());
            }
            if (ficoScoreList.getCurrentScore() != 0) {
                ficoScoreValueText.setText(String.valueOf(ficoScoreList.getCurrentScore()));
                ficoScoreRangeModalText.setText(FicoUtils.getFicoScoreRangeValue(ficoScoreList.getCurrentScore()));
            }

            //Total Account
            if (ficoScoreList.getTradeCount() == null || ficoScoreList.getTradeCount().equals(ficoTotalError)) {
                scoreTotalAccountValueTxt.setText(CommonUtils.getHtmlFormattedText(mActivity.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                setGreyClrForTotalAccounts = true;
            } else if (ficoScoreList.getTradeCount() != null) {
                scoreTotalAccountValueTxt.setText(ficoScoreList.getTradeCount());

            }
            //Length Of Credit
            if (ficoScoreList.getOldestTradeMonthCount() == null || ficoScoreList.getOldestTradeMonthCount().equals(limitedAuthUserError)) {
                scoreLengthOfCreditValueTxt.setText(CommonUtils.getHtmlFormattedText(mActivity.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                setGreyClrForCreditLength = true;
            } else if (ficoScoreList.getOldestTradeMonthCount() != null) {
                scoreLengthOfCreditValueTxt.setText(FicoUtils.getLengthOfCredit(Integer.parseInt(ficoScoreList.getOldestTradeMonthCount()), mContext));
            }
            //Inquires
            if (ficoScoreList.getInquiryCount() == null || ficoScoreList.getInquiryCount().equals(limitedAuthUserError)) {
                scoreInquiresValueTxt.setText(CommonUtils.getHtmlFormattedText(mActivity.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                setGreyClrForInquiries = true;
            } else if (ficoScoreList.getInquiryCount() != null) {
                scoreInquiresValueTxt.setText(ficoScoreList.getInquiryCount());
            }
            //Revolving Utilization
            if ((ficoScoreList.getOpenRvlUtilizationPct() == null || (ficoScoreList.getOpenRvlUtilizationPct().equals(limitedAuthUserError) || ficoScoreList.getOpenRvlUtilizationPct().equals(noRevolvingTradeError)))) {
                scoreRevolvingValueTxt.setText(CommonUtils.getHtmlFormattedText(mActivity.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                setGreyClrForRevUti = true;
            } else if (ficoScoreList.getOpenRvlUtilizationPct() != null) {
                scoreRevolvingValueTxt.setText(ficoScoreList.getOpenRvlUtilizationPct()+"%");
            }
            //Missed Payment
            if ((ficoScoreList.getTotalMissedPymt() == null || ficoScoreList.getTotalMissedPymt().equals(limitedAuthUserError))) {
                scoreMissedPayValueTxt.setText(CommonUtils.getHtmlFormattedText(mActivity.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                setGreyClrForMissedPayments = true;
            } else if (ficoScoreList.getTotalMissedPymt() != null) {
                scoreMissedPayValueTxt.setText(ficoScoreList.getTotalMissedPymt());
            }

            //Score Color View
            int ficoScoreRangeColor = FicoUtils.getColorCodeFromScoreValue(ficoScoreList.getCurrentScore());
            if (ficoScoreRangeColor != 0) {
                scoreModalColorView.setBackgroundColor(mActivity.getResources().getColor(ficoScoreRangeColor));
            }

            //Collapse Boxed Color views
            int totalAccRangeColor = FicoUtils.getColorBasedOnRatingCode(ficoScoreList.getTotalAccountRatingCode(), mActivity);
            if (setGreyClrForTotalAccounts) {
                scoreTotalAccountColorView.setBackgroundColor((ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color)));
            } else if (totalAccRangeColor != 0) {
                scoreTotalAccountColorView.setBackgroundColor(totalAccRangeColor);
            }

            int totalLengthRangeColor = FicoUtils.getColorBasedOnRatingCode(ficoScoreList.getLengthOfCreditRatingCode(), mActivity);
            if (setGreyClrForCreditLength) {
                scoreLengthOfCreditColorView.setBackgroundColor((ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color)));
            } else if (totalLengthRangeColor != 0) {
                scoreLengthOfCreditColorView.setBackgroundColor(totalLengthRangeColor);
            }

            int totalInquiresRangeColor = FicoUtils.getColorBasedOnRatingCode(ficoScoreList.getInquiriesRatingCode(), mActivity);
            if (setGreyClrForInquiries) {
                scoreInquiresColorView.setBackgroundColor((ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color)));
            } else if (totalAccRangeColor != 0) {
                scoreInquiresColorView.setBackgroundColor(totalInquiresRangeColor);
            }

            int totalRevolvingRangeColor = FicoUtils.getColorBasedOnRatingCode(ficoScoreList.getRevolvingUtilizationRatingCode(), mActivity);
            if (setGreyClrForRevUti) {
                scoreRelvovingColorView.setBackgroundColor((ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color)));
            } else if (totalAccRangeColor != 0) {
                scoreRelvovingColorView.setBackgroundColor(totalRevolvingRangeColor);
            }
            int totalMissedPayRangeColor = FicoUtils.getColorBasedOnRatingCode(ficoScoreList.getMissedPaymentsRatingCode(), mActivity);
            if (setGreyClrForMissedPayments) {
                scoreMissedPayColorView.setBackgroundColor((ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color)));
            } else if (totalAccRangeColor != 0) {
                scoreMissedPayColorView.setBackgroundColor(totalMissedPayRangeColor);
            }
        }
        if ((ficoScoreList.getPositiveKeyFactors() == null && ficoScoreList.getNegativeKeyFactors() == null) || (
                null != ficoScoreList.getPositiveKeyFactors() && ficoScoreList.getPositiveKeyFactors().isEmpty() && null != ficoScoreList.getPositiveKeyFactors() && ficoScoreList.getPositiveKeyFactors().isEmpty())) {
            areKeyFactorsUnavailable = true;
        }
        if (setGreyClrForTotalAccounts && setGreyClrForCreditLength && setGreyClrForInquiries && setGreyClrForMissedPayments && setGreyClrForRevUti && !areKeyFactorsUnavailable) {
            ficoCollapseBoxLayout.setVisibility(View.GONE);
            scoreDataContainerLayout.setGravity(Gravity.CENTER);
            /*Start Changes for US153320*/
            ficoScoreValueText.setTextSize(TypedValue.COMPLEX_UNIT_PX, mContext.getResources().getDimension(R.dimen.cmn_fico_no_attribute_textsize));
            /*End Changes for US153320*/
        } else {
            ficoCollapseBoxLayout.setVisibility(View.VISIBLE);
            scoreDataContainerLayout.setGravity(Gravity.CENTER_VERTICAL);
            /*Start Changes for US153320*/
            ficoScoreValueText.setTextSize(TypedValue.COMPLEX_UNIT_PX, mContext.getResources().getDimension(R.dimen.cmn_fico_default_attribute_txt_size));
            /*End Changes for US153320*/
        }

    }



    @Override
    public void onDestroyView() {
        if (getDialog() != null && getRetainInstance()) {
            getDialog().setDismissMessage(null);
        }
        super.onDestroyView();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!isShowFullScreenDialog) {
            setUpDialogSize();
        }
    }

    private void setUpDialogSize() {
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams params = getDialog().getWindow().getAttributes();
        DisplayMetrics dm = new DisplayMetrics();
        window.getWindowManager().getDefaultDisplay().getMetrics(dm);
        FrameLayout.LayoutParams dialogFragmentLayoutParams = (FrameLayout.LayoutParams) getView().getLayoutParams();
        // Set fixed width for tablet
        if (!Utils.isRunningOnHandset(getContext())) {
            //params.width = (Utils.dpToPx(TABLET_FIXED_DIALOG_WIDTH_IN_DP , dm)* 6);
            params.width = dm.widthPixels;
            dialogFragmentLayoutParams.width = (Utils.dpToPx(TABLET_FIXED_DIALOG_WIDTH_IN_DP, dm) * 6);
            dialogFragmentLayoutParams.gravity = Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL;
            //Start: US95284: Android: Bank: Dev Only: DPL Payments UI Updates: Important Information Modal
            if (modalSizing) {
                int orientation = DiscoverActivityManager.getActiveActivity()
                        .getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    params.height = params.width - Utils.dpToPx(HANDSET_TOP_MARGIN, dm) - Utils.dpToPx(HANDSET_BOTTOM_MARGIN, dm) - Utils.dpToPx(getStatusBarHeight(), dm);
                }
            }
            //End: US95284: Android: Bank: Dev Only: DPL Payments UI Updates: Important Information Modal
        } else {
            int width = dm.widthPixels;
            params.width = width;
        }

        int left = Utils.dpToPx(HANDSET_LEFT_MARGIN, dm);
        int right = Utils.dpToPx(HANDSET_RIGHT_MARGIN, dm);
        int top = Utils.dpToPx(HANDSET_TOP_MARGIN, dm);
        int bottom = Utils.dpToPx(HANDSET_BOTTOM_MARGIN, dm);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            top = Utils.dpToPx(HANDSET_TOP_MARGIN_ABOVE_L, dm);
        }
        dialogFragmentLayoutParams.setMargins(left, top, right, bottom);

        getView().setLayoutParams(dialogFragmentLayoutParams);
        getView().setBackgroundResource((R.drawable.cmn_dialog_background));
        getDialog().getWindow().setDimAmount(.6f);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setAttributes(params);
        window.setGravity(Gravity.CENTER);

    }

    private int getStatusBarHeight() {
        Rect rectangle = new Rect();
        Window window = getActivity().getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(rectangle);
        int statusBarHeight = rectangle.top;
        int contentViewTop = window.findViewById(Window.ID_ANDROID_CONTENT).getTop();
        int titleBarHeight = contentViewTop - statusBarHeight;
        return titleBarHeight;

    }

    /**
     * Initialise dialog attributes.
     */
    private void initDialogView() {
        keyFactorDesTxtV = (TextView) mDialogParentView.findViewById(R.id.cmnFicoKeyFactorsDes);
        cmnFicoKeyFactorsModalContainer = (View) mDialogParentView.findViewById(R.id.cmnFicoKeyFactorsModalContainer);
        ficoCancelBtn = (Button) mDialogParentView.findViewById(R.id.ficoCancelBtn);
        positiveKeyFactorsListView = (ExpandableListView) mDialogParentView.findViewById(R.id.cmnFicoPosKeyFactorsList);
        nagavtiveKeyFactorsListView = (ExpandableListView) mDialogParentView.findViewById(R.id.cmnFicoNegKeyFactorsList);
        positiveKeyFactorsRoot = (RelativeLayout) mDialogParentView.findViewById(R.id.cmnFicoPosKeyFactoryRoot);
        negativeKeyFactorsRoot = (RelativeLayout) mDialogParentView.findViewById(R.id.cmnFicoNegFactoryRoot);
        listLeftNavImgModelBtn = (ImageButton) mDialogParentView.findViewById(R.id.cmnFicoListModel_LeftNav);
        listRightNavImgModelBtn = (ImageButton) mDialogParentView.findViewById(R.id.cmnFicoListModel_RightNav);
        listLeftNavImgModelBtn.setContentDescription(mContext.getResources().getString(R.string.prev_button_tap_desc));
        listRightNavImgModelBtn.setContentDescription(mContext.getResources().getString(R.string.next_button_tap_desc));
        /*Start Header views*/
        ficoScoreModalTxt = (TextView) mDialogParentView.findViewById(R.id.ficoScoreModalTxt);
        ficoScoreBoxModalTitleTxt = (TextView) mDialogParentView.findViewById(R.id.ficoScoreBoxModalTitleTxt);
        ficoScoreValueText = (TextView) mDialogParentView.findViewById(R.id.ficoScoreValueText);
        scoreDataContainerLayout = (RelativeLayout)mDialogParentView.findViewById(R.id.scoreDataContainerLayout);
        ficoCollapseBoxLayout = (LinearLayout) mDialogParentView.findViewById(R.id.ficoCollapseBoxLayout);
        ficoScoreLayout = (LinearLayout) mDialogParentView.findViewById(R.id.ficoPerImageLayout);
        ficoScoreRangeModalText = (TextView) mDialogParentView.findViewById(R.id.ficoScoreRangeModalText);
        scoreTotalAccountValueTxt = (TextView) mDialogParentView.findViewById(R.id.scoreTotalAccountValueTxt);
        scoreLengthOfCreditValueTxt = (TextView) mDialogParentView.findViewById(R.id.scoreLengthOfCreditValueTxt);
        scoreInquiresValueTxt = (TextView) mDialogParentView.findViewById(R.id.scoreInquiresValueTxt);
        scoreRevolvingValueTxt = (TextView) mDialogParentView.findViewById(R.id.scoreRevolvingValueTxt);
        scoreMissedPayValueTxt = (TextView) mDialogParentView.findViewById(R.id.scoreMissedPayValueTxt);
        //Color Views
        scoreModalColorView = (View) mDialogParentView.findViewById(R.id.scoreModalColorView);
        scoreTotalAccountColorView = (View) mDialogParentView.findViewById(R.id.scoreTotalAccountColorView);
        scoreLengthOfCreditColorView = (View) mDialogParentView.findViewById(R.id.scoreLengthOfCreditColorView);
        scoreInquiresColorView = (View) mDialogParentView.findViewById(R.id.scoreInquiresColorView);
        scoreRelvovingColorView = (View) mDialogParentView.findViewById(R.id.scoreRelvovingColorView);
        scoreMissedPayColorView = (View) mDialogParentView.findViewById(R.id.scoreMissedPayColorView);
       /*End Header views*/
        cmnFicoPosKeyFactorsSep = (View) mDialogParentView.findViewById(R.id.cmnFicoPosKeyFactorsSep);
        cmnFicoNegKeyFactorsSep = (View) mDialogParentView.findViewById(R.id.cmnFicoNegKeyFactorsSep);
        cmnFicoPosKeyFactorsSepBottom = mDialogParentView.findViewById(R.id.cmnFicoPosKeyFactorsSepBottom);
        cmnFicoPosKeyFactorsSep.setVisibility(View.GONE);
        cmnFicoNegKeyFactorsSep.setVisibility(View.GONE);
        cmnFicoPosKeyFactorsSepBottom.setVisibility(View.GONE);

    }

    private View.OnClickListener postiveButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            getDialog().dismiss();
        }
    };

    private View.OnClickListener listRightNavImgModelBtnListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            boolean isDataAvailable = false;
            FicoScoreList tempFicoScoreListItem;
            if (null != mFicoCreditScore && null != mFicoCreditScore.getFicoScoreList() && mSelectedListIndex < LIST_COUNT) {
                mSelectedListIndex++;
                for (int listIndex = mSelectedListIndex; listIndex < LIST_COUNT; listIndex++) {
                    mSelectedListIndex = listIndex;
                    tempFicoScoreListItem = mFicoCreditScore.getFicoScoreList().get(listIndex);
                    if (null != tempFicoScoreListItem && tempFicoScoreListItem.isHasScore()) {
                        mFicoScoreListItem = mFicoCreditScore.getFicoScoreList().get(listIndex);
                        isDataAvailable = true;
                        break;
                    }
                }
            }
            if (isDataAvailable) {
                setScoreBoxDetails(mFicoScoreListItem);
                showKeyfactors(mFicoScoreListItem.getPositiveKeyFactors(), mFicoScoreListItem.getNegativeKeyFactors());
            }

            setUpListNavigator();
        }
    };

    private View.OnClickListener listLeftNavImgModelBtnListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            boolean isDataAvailable = false;
            FicoScoreList tempFicoScoreListItem;
            if (null != mFicoCreditScore && null != mFicoCreditScore.getFicoScoreList() && mSelectedListIndex > LIST_MIN_INDEX) {
                mSelectedListIndex--;
                for (int listIndex = mSelectedListIndex; listIndex > LIST_MIN_INDEX; listIndex--) {
                    mSelectedListIndex = listIndex;
                    tempFicoScoreListItem = mFicoCreditScore.getFicoScoreList().get(listIndex);
                    if (null != tempFicoScoreListItem && tempFicoScoreListItem.isHasScore()) {
                        mFicoScoreListItem = mFicoCreditScore.getFicoScoreList().get(listIndex);
                        isDataAvailable = true;
                        break;
                    }
                }
            }
            if (isDataAvailable) {
                setScoreBoxDetails(mFicoScoreListItem);
                showKeyfactors(mFicoScoreListItem.getPositiveKeyFactors(), mFicoScoreListItem.getNegativeKeyFactors());
            }

            setUpListNavigator();
        }
    };

    private void setupListeners() {
        setCancelable(mCancelable);
        getDialog().setCanceledOnTouchOutside(mCanceledOnTouchOutside);
        getDialog().setOnShowListener(mShownListener);
        getDialog().setOnCancelListener(mOnCancelListener);
        getDialog().setOnDismissListener(mOnDismissListener);
        getDialog().setOnKeyListener(mOnKeyListener);
        getDialog().setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                if (i == KeyEvent.KEYCODE_BACK) {
                    if (mOnBackPressedListener != null) {
                        mOnBackPressedListener.onBackPressedListener();
                        return false;
                    }
                }
                return false;
            }
        });

        //Setting Listeners
        ficoCancelBtn.setOnClickListener(postiveButtonListener);
        listRightNavImgModelBtn.setOnClickListener(listRightNavImgModelBtnListener);
        listLeftNavImgModelBtn.setOnClickListener(listLeftNavImgModelBtnListener);
    }


    /**
     * Set DialogInterface.OnCancelListener for Dialog cancel.
     */
    public void setOnCancelListener(DialogInterface.OnCancelListener onCancelListener) {
        this.mOnCancelListener = onCancelListener;
        if (getDialog() != null) {
            getDialog().setOnCancelListener(onCancelListener);
        }
    }

    /**
     * Set DialogInterface.OnDismissListener for Dialog dismiss callback.
     */
    public void setOnDismissListener(DialogInterface.OnDismissListener onDismissListener) {
        this.mOnDismissListener = onDismissListener;
        if (getDialog() != null) {
            getDialog().setOnDismissListener(onDismissListener);
        }
    }

    /**
     * Set DialogInterface.OnKeyListener for Dialog onKey listener.
     */
    public void setOnKeyListener(DialogInterface.OnKeyListener onKeyListener) {
        this.mOnKeyListener = onKeyListener;
        if (getDialog() != null) {
            getDialog().setOnKeyListener(onKeyListener);
        }
    }

    /**
     * Set dialog can be cancalable on back press, outside touch or not. This is same as
     * DialogFragment#setCancelable().
     */
    public CmnFicoKeyFactorAlertDialog setCanCancelable(boolean cancelable) {
        super.setCancelable(cancelable);
        mCancelable = cancelable;
        return this;
    }

    /**
     * Set if dialog can be cancelable while touching outside of modal.
     */
    public CmnFicoKeyFactorAlertDialog setCanceledOnTouchOutside(boolean cancelable) {
        mCanceledOnTouchOutside = cancelable;
        return this;
    }

    /**
     * Show dialog.
     */
    public CmnFicoKeyFactorAlertDialog show(AppCompatActivity activity) {
        // Fix for IllegalStateException - Fabric START
        Activity act = DiscoverActivityManager.getActiveActivity();
        if (act instanceof DrawerBaseActivity && ((DrawerBaseActivity) act).isActivityPaused) {
            FragmentTransactions ft = new FragmentTransactions(this, FragmentTransactions.TransactionType.DIALOG_SHOW);
            ((DrawerBaseActivity) act).addOperation(ft);
            return this;
        }
        // Fix for IllegalStateException - Fabric END
        mActivity = activity;
        //fix for crashlytics defect 334
        if (mActivity != null && !mActivity.isFinishing() && !isAdded()) {
            FragmentManager fm = mActivity.getSupportFragmentManager();
            CmnFicoKeyFactorAlertDialog.this.show(fm, CmnFicoKeyFactorAlertDialog.class.getSimpleName());
        }
        return this;
    }

    @Override
    public void dismiss() {
        // Fix for IllegalStateException - Fabric START
        Activity act = DiscoverActivityManager.getActiveActivity();
        if (act instanceof DrawerBaseActivity && ((DrawerBaseActivity) act).isActivityPaused) {
            FragmentTransactions ft = new FragmentTransactions(this, FragmentTransactions.TransactionType.DIALOG_DISMISS);
            ((DrawerBaseActivity) act).addOperation(ft);
            return;
        }
        // Fix for IllegalStateException - Fabric END
        super.dismiss();
    }


    /*
    This interface is used to handle back button functionality of the device.
     */
    public interface OnBackPressedListener {

        void onBackPressedListener();
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getDialog().getWindow()
                .getAttributes().windowAnimations = R.style.AppAuditDialogAnimation;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //Start - Fix added for defect #1507
        setUpDialogSize();
        //End - Fix added for defect #1507
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (mOnDismissListener != null) {
            mOnDismissListener.onDismiss(dialog);
        }
    }

    /**
     * Method to check list index & depending on it hide / show Left & Right Navigation bar
     */
    private void setUpListNavigator() {

        if (mSelectedListIndex != LIST_MIN_INDEX && !isRightDataAvaialable()) {
            listRightNavImgModelBtn.setVisibility(View.GONE);
        } else {
            listRightNavImgModelBtn.setVisibility(View.VISIBLE);
        }

        if (mSelectedListIndex != LIST_MIN_INDEX && !isLeftDataAvaialable()) {
            listLeftNavImgModelBtn.setVisibility(View.GONE);
        } else {
            listLeftNavImgModelBtn.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Method to check if left side (previous months) data available or not
     */
    private boolean isLeftDataAvaialable() {
        boolean isDataAvailable = false;
        FicoScoreList tempFicoScoreListItem;
        if (null != mFicoCreditScore && null != mFicoCreditScore.getFicoScoreList() && mSelectedListIndex > LIST_MIN_INDEX) {
            for (int listIndex = mSelectedListIndex - 1; listIndex > LIST_MIN_INDEX; listIndex--) {
                tempFicoScoreListItem = mFicoCreditScore.getFicoScoreList().get(listIndex);
                if (null != tempFicoScoreListItem && tempFicoScoreListItem.isHasScore()) {
                    isDataAvailable = true;
                    break;
                }
            }
        }
        return isDataAvailable;
    }

    /**
     * Method to check if right side (next months) data available or not
     */
    private boolean isRightDataAvaialable() {
        boolean isDataAvailable = false;
        FicoScoreList tempFicoScoreListItem;
        if (null != mFicoCreditScore && null != mFicoCreditScore.getFicoScoreList() && mSelectedListIndex < LIST_COUNT) {
            for (int listIndex = mSelectedListIndex + 1; listIndex < LIST_COUNT; listIndex++) {
                tempFicoScoreListItem = mFicoCreditScore.getFicoScoreList().get(listIndex);
                if (null != tempFicoScoreListItem && tempFicoScoreListItem.isHasScore()) {
                    isDataAvailable = true;
                    break;
                }
            }
        }
        return isDataAvailable;
    }

    /**
     * Method to get index for selected list item
     */
    private void setSelectedListIndex() {
        if (null != mFicoCreditScore && null != mFicoCreditScore.getFicoScoreList() && null != mFicoScoreListItem) {

            String currentScoreDate = mFicoScoreListItem.getScoreDate();
            if (!PortalUtils.isStrFieldEmpty(currentScoreDate)) {
                currentScoreDate = currentScoreDate.trim();
            } else {
                currentScoreDate = "";
            }

            String listItemScoreDate;
            int listCounter = -1;

            for (FicoScoreList listItem : mFicoCreditScore.getFicoScoreList()) {
                listCounter++;
                listItemScoreDate = listItem.getScoreDate();
                if (!PortalUtils.isStrFieldEmpty(listItemScoreDate)) {
                    listItemScoreDate = listItemScoreDate.trim();
                    if (listItemScoreDate.equalsIgnoreCase(currentScoreDate)) {
                        mSelectedListIndex = listCounter;
                        break;
                    }
                }
            }
        }
    }

    /**
     * Method to show Key-facotrs
     */
    public void showKeyfactors(List<PositiveKeyFactor> mPositiveKeyFactorList, List<NegativeKeyFactor> mNegativeKeyFactorList) {
        if ((null == mPositiveKeyFactorList && null == mNegativeKeyFactorList) || (
                null != mPositiveKeyFactorList && mPositiveKeyFactorList.isEmpty() && null != mNegativeKeyFactorList && mNegativeKeyFactorList.isEmpty())) {
            //hide key-factors container
            keyFactorDesTxtV.setText(mContext.getResources().getString(R.string.cmn_fico_keyfactors_unavailable_msg));
            positiveKeyFactorsRoot.setVisibility(View.GONE);
            negativeKeyFactorsRoot.setVisibility(View.GONE);
        } else {
            keyFactorDesTxtV.setText(mContext.getResources().getString(R.string.cmn_fico_keyfactors_des)+":");
            showPositiveKeyFactors(mContext, mPositiveKeyFactorList);
            showNegativeKeyFactors(mContext, mNegativeKeyFactorList);
        }
    }

    /**
     * Method to display whats helping key-factors
     */
    private void showPositiveKeyFactors(Context mContext, List<PositiveKeyFactor> positiveKeyFactorList) {

        if (null != positiveKeyFactorList && !positiveKeyFactorList.isEmpty()) {

            positiveKeyFactorsRoot.setVisibility(View.VISIBLE);

            List<String> posListDataGroup = new ArrayList<>();
            HashMap<String, List<String>> posListDataChild = new HashMap<>();

            for (PositiveKeyFactor posKeyFacItem : positiveKeyFactorList) {
                posListDataGroup.add(posKeyFacItem.getShortDesc());
                List<String> childList = new ArrayList<>();
                childList.add(posKeyFacItem.getLongDesc());
                posListDataChild.put(posKeyFacItem.getShortDesc(), childList); // Header, Child data
            }

            CmnFicoKeyFactorsListAdapter listAdapter = new CmnFicoKeyFactorsListAdapter(mContext, posListDataGroup, posListDataChild);
            positiveKeyFactorsListView.setAdapter(listAdapter);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    posExpListGroupHeight = FicoUtils.getExpandableListGroupViewsHeight(positiveKeyFactorsListView);
                    FicoUtils.setExpandableListViewHeight(positiveKeyFactorsListView, posExpListGroupHeight);
                    positiveKeyFactorsListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

                        @Override
                        public void onGroupExpand(int groupPosition) {
                            // Also collapse Negative Key-factors list expanded item if any
                            if (null != nagavtiveKeyFactorsListView && null != nagavtiveKeyFactorsListView.getAdapter() && nagavtiveKeyFactorsListView.isGroupExpanded(negExpListGroupSelected)) {
                                nagavtiveKeyFactorsListView.collapseGroup(negExpListGroupSelected);
                            }
                            if (groupPosition != posExpListGroupSelected) {
                                positiveKeyFactorsListView.collapseGroup(posExpListGroupSelected);
                            }
                            posExpListGroupSelected = groupPosition;
                            int expandedChildsHeight = FicoUtils.getExpandableListChildViewsHeight(positiveKeyFactorsListView, groupPosition);
                            expandedChildsHeight += posExpListGroupHeight;
                            FicoUtils.setExpandableListViewHeight(positiveKeyFactorsListView, expandedChildsHeight);

                        }
                    });

                    positiveKeyFactorsListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
                        @Override
                        public void onGroupCollapse(int groupPosition) {
                            // If same group is collapsed then reset size of list
                            if (posExpListGroupSelected == groupPosition) {
                                FicoUtils.setExpandableListViewHeight(positiveKeyFactorsListView, posExpListGroupHeight);
                            }
                        }
                    });

                }
            }, LIST_RENDERING_DELAY_INMISEC);

        } else {
            positiveKeyFactorsRoot.setVisibility(View.GONE);
        }
    }

    /**
     * Method to display whats hurting key-factors
     */
    private void showNegativeKeyFactors(Context mContext, List<NegativeKeyFactor> negativeKeyFactorList) {

        if (null != negativeKeyFactorList && !negativeKeyFactorList.isEmpty()) {

          //  cmnFicoPosKeyFactorsSepBottom.setVisibility(View.VISIBLE);
            negativeKeyFactorsRoot.setVisibility(View.VISIBLE);

            List<String> negListDataGroup = new ArrayList<>();
            HashMap<String, List<String>> negListDataChild = new HashMap<>();

            for (NegativeKeyFactor negKeyFacItem : negativeKeyFactorList) {
                negListDataGroup.add(negKeyFacItem.getShortDesc());
                List<String> childList = new ArrayList<>();
                childList.add(negKeyFacItem.getLongDesc());
                negListDataChild.put(negKeyFacItem.getShortDesc(), childList); // Header, Child data
            }

            CmnFicoKeyFactorsListAdapter listAdapter = new CmnFicoKeyFactorsListAdapter(mContext, negListDataGroup, negListDataChild);
            nagavtiveKeyFactorsListView.setAdapter(listAdapter);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    negExpListGroupHeight = FicoUtils.getExpandableListGroupViewsHeight(nagavtiveKeyFactorsListView);
                    FicoUtils.setExpandableListViewHeight(nagavtiveKeyFactorsListView, negExpListGroupHeight);
                    nagavtiveKeyFactorsListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

                        @Override
                        public void onGroupExpand(int groupPosition) {
                            // Also collapse Positive Key-factors list expanded item if any
                            if (null != positiveKeyFactorsListView && null != positiveKeyFactorsListView.getAdapter() && positiveKeyFactorsListView.isGroupExpanded(posExpListGroupSelected)) {
                                positiveKeyFactorsListView.collapseGroup(posExpListGroupSelected);
                            }
                            if (groupPosition != negExpListGroupSelected) {
                                nagavtiveKeyFactorsListView.collapseGroup(negExpListGroupSelected);
                            }
                            negExpListGroupSelected = groupPosition;
                            int expandedChildsHeight = FicoUtils.getExpandableListChildViewsHeight(nagavtiveKeyFactorsListView, groupPosition);
                            expandedChildsHeight += negExpListGroupHeight;
                            FicoUtils.setExpandableListViewHeight(nagavtiveKeyFactorsListView, expandedChildsHeight);

                        }
                    });
                    nagavtiveKeyFactorsListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
                        @Override
                        public void onGroupCollapse(int groupPosition) {
                            // If same group is collapsed then reset size of list
                            if (negExpListGroupSelected == groupPosition) {
                                FicoUtils.setExpandableListViewHeight(nagavtiveKeyFactorsListView, negExpListGroupHeight);
                            }
                        }
                    });

                }
            }, LIST_RENDERING_DELAY_INMISEC);

        } else {
            //cmnFicoPosKeyFactorsSepBottom.setVisibility(View.INVISIBLE);
            negativeKeyFactorsRoot.setVisibility(View.GONE);
        }
    }

}