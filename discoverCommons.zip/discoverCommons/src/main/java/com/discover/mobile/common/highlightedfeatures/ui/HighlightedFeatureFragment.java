package com.discover.mobile.common.highlightedfeatures.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.highlightedfeatures.adapter.HighlightedFeatureAdaptor;
import com.discover.mobile.common.highlightedfeatures.beans.FeatureContent;
import com.discover.mobile.common.highlightedfeatures.utils.HFConstants;
import com.discover.mobile.common.highlightedfeatures.utils.HFUtils;
import com.discover.mobile.common.navigation.NoSwipeOpenMenu;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.image.ImageLoader;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.HashMap;

public class HighlightedFeatureFragment extends Fragment implements NoSwipeOpenMenu {

    public static final String ITEM = "item";
    public static final String WHATS_NEW_TO_SHOW = "isForWhatsNew";
    public static final String IS_CARD_SELECTED = "iscardselected";
    private static final String Highlighted_Features = "Highlighted Features";
    private static final String WHATS_NEW = "Whats New";
    private ViewGroup view = null;
    private ImageLoader loader;
    private Context mContext;
    private Bundle mArguments;
    private boolean isCardSelected;
    private HighlightedFeatureClickHandler clickHandler;
    private  int tagCount=0;
    private static final String VIEWTAG="view";
    private static final String CLOSEBUTTONTAG="closebutton";
    private static final String BUTTONLAYOUTTAG="buttonlayout";
    private static final String TITLETAG="title";
    private static final String CONTENTTAG="content";
    private static final String CONTENTHEADINGTAG="contentheading";
    private static final String BUTTONTAG="button";
    private static Integer id =0;

    public void setImgLoader(ImageLoader imgLoader) {
        loader = imgLoader;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mContext = activity;
    }

    public void setFeatureClickHandler(HighlightedFeatureClickHandler clickHandler) {
        this.clickHandler = clickHandler;
    }

    /**
     * Create the view and inflate the layout
     *
     * @param inflater           - inflater used to inflate the view
     * @param container          - container containing the fragment
     * @param savedInstanceState - saved state of the fragment
     */
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
        /*if(Utils.isRunningOnHandset(DiscoverActivityManager.getActiveActivity())){
            Utils.lockDeviceOrientation(getActivity(), true);
		}
*/
        view = (ViewGroup) inflater.inflate(R.layout.highlighted_feature_whatsnew_layout, null);
        initUI();
        return view;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        if (view != null) {
            initUI();
        }
    }


    private boolean isEmpty(String s) {
        return (s == null || s.trim().equals(""));
    }

    @Override
    public void onDetach() {
        super.onDetach();

        try {
            Field field = Fragment.class.getDeclaredField("mChildFragmentManager");
            field.setAccessible(true);
            field.set(this, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    public void initUI() {
         int tagIdCount=0;

        int ot = getResources().getConfiguration().orientation;


        String currentOrienation = null;
        switch (ot) {
            case Configuration.ORIENTATION_LANDSCAPE:
                currentOrienation = HFConstants.Orientation.LANDSCAPE;
                break;

            case Configuration.ORIENTATION_PORTRAIT:
                currentOrienation = HFConstants.Orientation.PORTRAIT;
                break;
        }

        final LinearLayout closeButtonLayout = (LinearLayout) view.findViewById(R.id.button_close_layout);
        final ImageButton closeButton = (ImageButton) view.findViewById(R.id.button_close);
        final ImageView image = (ImageView) view.findViewById(R.id.whatsnew_hf_image);
        final TextView title = (TextView) view.findViewById(R.id.whatnew_hf_content_label);
        final TextView content = (TextView) view.findViewById(R.id.whatsnew_hf_content_heading_description);
        final Button button = (Button) view.findViewById(R.id.whatnew_hf_requestnow_btn);
        /**Button text is all-caps by default when using the Material (or DeviceDefault with API 21+) theme
         * start Fix for defect# 6114 */
        button.setTransformationMethod(null);
        /** end Fix for defect# 6114*/
        //start changes by asaraf2
        final TextView content_heading = (TextView) view.findViewById(R.id.whatsnew_hf_content_heading);
        //end changes by asaraf2
        closeButtonLayout.post(getTouchDelegateAction(closeButtonLayout,
                closeButton, 150, 150, 150, 150));
        mArguments = getArguments();
        int tagId=mArguments.getInt(HighlightedFeatureAdaptor.TAG);
        closeButtonLayout.setTag(VIEWTAG+tagId+tagIdCount);
        image.setTag(VIEWTAG+tagId+(++tagIdCount));
        closeButton.setTag(VIEWTAG+tagId+(++tagIdCount));
        title.setTag(VIEWTAG+tagId+(++tagIdCount));
        content.setTag(VIEWTAG+tagId+(++tagIdCount));
        button.setTag(VIEWTAG+tagId+(++tagIdCount));
        content_heading.setTag(VIEWTAG+tagId+(++tagIdCount));

        Log.v("HFTag",closeButtonLayout.getTag().toString());
        Log.v("HFCloseButtonTag",closeButton.getTag().toString());
        Log.v("HFImageTag",image.getTag().toString());
        Log.v("HFTitleTag",title.getTag().toString());
        Log.v("HFContentTag", content.getTag().toString());
        Log.v("HFButtonTag", button.getTag().toString());
        Log.v("HFcontentHeadingTag",content_heading.getTag().toString());


        final FeatureContent item = (FeatureContent) mArguments.getSerializable(ITEM);
        final boolean isForWhatsNew = mArguments.getBoolean(WHATS_NEW_TO_SHOW, false);
        if (isForWhatsNew) {
            Drawable closeDrawable = getResources().getDrawable(R.drawable.hf_whatsnew_close_btn).mutate();
            closeButton.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            closeButton.setVisibility(View.VISIBLE);

        } else {
            closeButton.setVisibility(View.GONE);
        }
        isCardSelected = mArguments.getBoolean(IS_CARD_SELECTED, true);
        String imageUrl = HFUtils.getImageUrl(mContext, item, currentOrienation, isCardSelected);


        /** start : slende fix for defect# 157112 */
        if (null == loader) {
            loader = new ImageLoader(getActivity());
        }
        loader.DisplayImage(imageUrl, image,true);

        image.setMinimumHeight(image.getHeight());

        String titleText = item.getTitle();
        titleText = titleText.replace("\\", "");
        title.setText(Html.fromHtml(titleText));
        //start changes by asaraf2
        content_heading.setText(item.getAccountHeaderLabel());
        //end changes by asaraf2

        // Accessibility feature neglecting web-view to read its content for whole selected page
        /**start : fix for defect# 195369 # 195373 - slende*/
        title.setFocusable(false);
        title.setClickable(false);
        String titleStr = Html.fromHtml(titleText).toString();
        title.setContentDescription(titleStr);
        /**start : fix for defect# 195369 # 195373 - slende*/
        //Changes for accessibility

        if (item.getContent().contains("<ul><li>")) {
            String[] contentDescription = item.getContent().split("</li><li>");
            StringBuilder desc = new StringBuilder();
            for (String contentDesc : contentDescription) {
                desc.append("�  ").append(contentDesc).append("\n");
            }
            String finalContent = desc.toString().replace("<ul><li>", "");
            finalContent = finalContent.replace("</li></ul>", "");
            content.setText(Html.fromHtml(finalContent));
        } else {
            content.setText(Html.fromHtml(item.getContent()));
        }
        // Wrap the text in a <font> tag that sets the font-face and color, dump
        // the HTML
        // into the web view, set the font size, and adjust the background color
        // so that we have
        // something resembling transparency.

        content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);

        if ((Activity) getActivity() instanceof HighlightedFeaturePreLoginActivity) {
            image.setContentDescription(WHATS_NEW);
        } else {
            image.setContentDescription(Highlighted_Features);
        }
        content.setContentDescription(Html.fromHtml(item.getContent().toString()));
        //Changes for accessibility
        if (!item.getShowDeepLink() || isEmpty(item.getDeepLinkCode()) || isEmpty(item.getDeepLinkText())) {
            button.setVisibility(View.GONE);
        } else {
            if ((Activity) getActivity() instanceof HighlightedFeaturePreLoginActivity) {
                if (item.getWhatsNewText() != null) {
                    button.setText(Html.fromHtml(item.getWhatsNewText()));
                }
                //button.setText(Html.fromHtml(item.getDeepLinkText()));
            } else {
                if (item.getWhatsNewText() != null) {
                    button.setText(Html.fromHtml(item.getDeepLinkText()));
                }

            }
            button.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    //if (clickHandler != null) {

                    clickHandler.featureClicked(item);
                    if(item.getDeepLinkText().equals("linktoSamsungPay")){
                        HashMap<String, Object> extras = new HashMap<String, Object>();
                        extras.put("my.prop1", AnalyticsPage.SAMSUNG_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN);
                        extras.put("pe", AnalyticsPage.SAMSUNG_PAY_LNK_O);
                        extras.put("pev1", AnalyticsPage.SAMSUNG_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN);
                        TrackingHelper.trackCardPage(null, extras);
                    }
                    //}
                }
            });
        }

        // Close button listener.
        closeButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                /*US113465 : OverDraft Whatsnew Sitcat*/
                if (!item.isApplyToCardSide()){
                    HashMap<String, Object> extras= FacadeFactory.getBankHFDeeplinkFacade().getHashMap() ;
                    extras.put(AnalyticsPage.PROP1,AnalyticsPage.WHATS_NEW_X_BUTTON_MYPROP);
                    if(Globals.isSSOUser())
                    {
                        extras.put(TrackingHelper.CONTEXT_USER_PROP, TrackingHelper.CUSTOMER);
                        extras.put(TrackingHelper.CONTEXT_USER_VAR, TrackingHelper.CUSTOMER);
                    }
                    TrackingHelper.trackBankClickEvents(AnalyticsPage.WHATS_NEW_X_BUTTON_MYPROP ,null, AnalyticsPage.LINK_TYPE_O,extras);
                }
                clickHandler.featureClosed();
            }
        });
    }



    /**
     * Method to increase the touch area for What's new close button
     */
    private Runnable getTouchDelegateAction(final View parent,
                                            final View delegate, final int topPadding, final int bottomPadding,
                                            final int leftPadding, final int rightPadding) {
        return new Runnable() {
            @Override
            public void run() {


                // Construct a new Rectangle and let the Delegate set its values
                Rect touchRect = new Rect();
                delegate.getHitRect(touchRect);

                // Modify the dimensions of the Rectangle
                // Padding values below zero are replaced by zeros
                touchRect.top -= Math.max(0, topPadding);
                touchRect.bottom += Math.max(0, bottomPadding);
                touchRect.left -= Math.max(0, leftPadding);
                touchRect.right += Math.max(0, rightPadding);

                // construct the TouchDelegate
                TouchDelegate touchDelegate = new TouchDelegate(touchRect,
                        delegate);

                // And set it on the parent
                parent.setTouchDelegate(touchDelegate);
            }
        };
    }
}
