package com.discover.mobile.common.androidwear;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.DataApi;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

import com.discover.mobile.common.R;
import com.discover.mobile.common.shared.Globals;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;

import java.io.ByteArrayOutputStream;

public class AndroidWearConnectivity implements
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {
    private static final String TAG = AndroidWearConnectivity.class.getName();
    private static GoogleApiClient mGoogleApiClient;
    private static AndroidWearConnectivity myObj;
    private static boolean isFirstime = false;
    private final long CONNECTION_TIME_OUT_MS = 1000;
    Context context = null;
    String response = null;
    String payload = null;
    String path = null;
    int notificationId = 0;
    boolean isWear = false;
    boolean isTogglingCardOrBank = false;

    public AndroidWearConnectivity(Context context) {
        this.context = context;
    }

    public static AndroidWearConnectivity getInstance(Context context) {
        if (myObj == null) {
            myObj = new AndroidWearConnectivity(context);
        }
        return myObj;
    }

    private static Asset createAssetFromBitmap(Bitmap bitmap) {
        final ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteStream);
        return Asset.createFromBytes(byteStream.toByteArray());
    }

    @Override
    public void onConnectionFailed(ConnectionResult arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onConnected(Bundle arg0) {
        // TODO Auto-generated method stub
        Log.d("AndroidWearConnectivity", "connected");
        //Fix for getting notification while logout / open the application on Phone.
        if (!isFirstime) {
            sendingDatatoWear(response, payload, path, notificationId, isWear,
                    isTogglingCardOrBank);
            isFirstime = true;
        } else {
            Log.d("AndroidWearConnectiviy", "Wear will not get notification while logout");
        }
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        // TODO Auto-generated method stub

    }

    public void getConnect(Context context) {
        if (mGoogleApiClient == null)
            mGoogleApiClient = new GoogleApiClient.Builder(context)
                    .addApi(Wearable.API).addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this).build();

        if (!mGoogleApiClient.isConnected()) {
            mGoogleApiClient.connect();
        }
    }

    public void sendMessage(final String response, final String payload,
                            final String path, final int notificationId, final boolean isWear,
                            final boolean isTogglingCardOrBank) {
        this.response = response;
        this.payload = payload;
        this.path = path;
        this.notificationId = notificationId;
        this.isWear = isWear;
        this.isTogglingCardOrBank = isTogglingCardOrBank;
        Log.d("sendMessage >", "Ravi Push called sendmesaage" + "Response--"
                + response + "path --" + path);

        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {

            sendingDatatoWear(response, payload, path, notificationId, isWear,
                    isTogglingCardOrBank);
        } else {

            getConnect(context);
            Log.d(TAG, "mGoogleApiClient not connected  ");
        }
    }

    private void sendingDatatoWear(String response, String payload,
                                   String path, int notificationId, boolean isWear,
                                   boolean isTogglingCardOrBank) {
        if (path != null) {
            Log.d("sendMessage >", "Ravi Push called sendmesaage"
                    + "Response--" + response + "path --" + path);
            PutDataMapRequest putDataMapRequest = PutDataMapRequest
                    .create(path);
            putDataMapRequest.getDataMap().putBoolean(
                    WearRequestTypes.KEY_IS_CARD_CHECKED,
                    !Globals.isBankLoginSelected());
            putDataMapRequest.getDataMap().putBoolean(
                    WearRequestTypes.KEY_ISTOGGLECARDORBANK,
                    isTogglingCardOrBank);
            putDataMapRequest.getDataMap().putString(
                    WearRequestTypes.KEY_TITLE, response);
            putDataMapRequest.getDataMap().putString(
                    WearRequestTypes.SUB_TITLE, payload);
            putDataMapRequest.getDataMap().putBoolean(
                    WearRequestTypes.KEY_ISWEARSETTINGSENABLED, isWear);
            putDataMapRequest.getDataMap().putInt(
                    WearRequestTypes.KEY_NOTIFICATION_ID, notificationId);
            putDataMapRequest.getDataMap().putString(
                    WearRequestTypes.KEY_TIMESTAMP,
                    String.valueOf(System.currentTimeMillis()));

            Bitmap icon = BitmapFactory.decodeResource(context.getResources(),
                    R.drawable.ic_launcher);
            Asset asset = createAssetFromBitmap(icon);
            putDataMapRequest.getDataMap().putAsset(WearRequestTypes.KEY_IMAGE,
                    asset);

            PutDataRequest request = putDataMapRequest.asPutDataRequest();
            Log.d(TAG, "sending response data to wear");
            Wearable.DataApi.putDataItem(mGoogleApiClient, request)
                    .setResultCallback(
                            new ResultCallback<DataApi.DataItemResult>() {
                                @Override
                                public void onResult(
                                        DataApi.DataItemResult dataItemResult) {
                                    Log.d(TAG,
                                            "response data sent :: putDataItem status: "
                                                    + dataItemResult
                                                    .getStatus()
                                                    .toString());
                                }
                            });
        }
    }

}
