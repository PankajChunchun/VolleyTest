package com.discover.mobile.common.onboardwiz.fragment.passcode;


import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.service.OnBoardServiceClass;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.TokenUtil;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.uiwidget.CmnButton;
import com.discover.mobile.common.uiwidget.CmnTextView;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import java.util.HashMap;

/**
 * Created by 482127 on 4/25/2016.
 */
public class OnBoardEnablePasscodeFragment extends Fragment implements View.OnClickListener {
    // Animation constant value
    private final static long PASSCODE_FADE_OUT_TIME = 100;
    private final static String mPasscodeLandingHeader = "onboard_passcode_landing_label";
    private final static String mPasscodeLandingSubHeader = "onboard_passcode_landing_body";
    // Animation objects declaration related for fade out animation
    Animation mFadeOutAnimation = null;
    private View mView;
    private Context mContext;
    private CmnTextView mSetupPasscode, mPasscodeText;
    private CmnButton btnEnable;
    private String mDeviceToken;
    private ImageView mImageView;
    private OnBoardServiceClass onBoardServiceClass;
    private static final String PASSCODEIMGENABLETAG="passcodeImageEnable";

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onStart() {
        super.onStart();
        hideKeyboard();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mView = LayoutInflater.from(mContext).inflate(R.layout.onboard_passcode_landing, null);
        ///US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    R.string.bank_analytics_onboard_passcode_intro_pge);

        }
        //US53334 End
        onBoardServiceClass = new OnBoardServiceClass(mContext);
        initUI();
        //US53328-START
        if (Globals.isFromCardSide()) {
            TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PAGE_NAME, null);
        }
        //END
        OnBoardHelper.visiblityForExitButton(getActivity(), true);

        if (!Globals.isBankLoginSelected())
            FacadeFactory.getCardFacade().updateReminderCount(mContext, "Passcode");

        OnBoardPasscodeContainerFragment.updateState(OnBoardConstant.PASSCODE_PAGE_STATE.ENABLE_PAGE);
        return mView;
    }

    private void initUI() {
        mSetupPasscode = (CmnTextView) mView.findViewById(R.id.setup_passcode_text);
        btnEnable = (CmnButton) mView.findViewById(R.id.buttonEnable);
        mImageView = (ImageView) mView.findViewById(R.id.image_onboard);
        mImageView.setTag(PASSCODEIMGENABLETAG);
        setUpImageForPasscode();
        mPasscodeText = (CmnTextView) mView.findViewById(R.id.txtPasscode);
        btnEnable.setOnClickListener(this);

        CommonUtils.setDisplayText(mPasscodeText, mPasscodeLandingSubHeader, getResources().getString(R.string.onboard_enable_view_description_new                                                                                      ));
        CommonUtils.setDisplayText(mSetupPasscode, mPasscodeLandingHeader, getResources().getString(R.string.onboard_enable_view_title_new));
        // mSetupPasscode.setText(R.string.onboard_enable_view_title);

        // get passcode container fragment object to access anim variable
        /**start US83286  - Android Fingerprint - Kill-switch */
        Activity currentActivity = DiscoverActivityManager.getActiveActivity();
        boolean isFingerprintOnboardItemToShow = OnBoardHelper.isFPOnboardItemToShow(currentActivity);
        OnBoardPasscodeContainerFragment fragment = (OnBoardPasscodeContainerFragment) OnBoardHelper.getVehicles(isFingerprintOnboardItemToShow).get(0);
        /**start US83286  - Android Fingerprint - Kill-switch */
        if (fragment.mAnim) {
            //after perfom animation dissable animation flag
            fragment.mAnim = false;
            //loding view animation
            android.view.animation.Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.possocde_slide_in_right);
            //start view animation
            mImageView.startAnimation(animation);
            mSetupPasscode.setVisibility(View.INVISIBLE);
            mPasscodeText.setVisibility(View.INVISIBLE);
            btnEnable.setVisibility(View.INVISIBLE);

            mSetupPasscode.postDelayed(new Runnable() {
                @Override
                public void run() {

                    mSetupPasscode.setVisibility(View.VISIBLE);
                    mPasscodeText.setVisibility(View.VISIBLE);
                    btnEnable.setVisibility(View.VISIBLE);
                }
            }, 300);

        }

        SpannableString spannableString = new SpannableString(
                mSetupPasscode.getText());
        spannableString.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.cmn_orange)), 9,
                26, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        mSetupPasscode.setText(spannableString);
        mDeviceToken = TokenUtil.genClientBindingToken();
    }

    private void setUpImageForPasscode() {
        Bitmap defaultBitmap = null;
        String imageName = null;
        if (Globals.isBankLoginSelected()) {
            //bank login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_passcode_bank);
            imageName = "onboard_passcode_bank.png";
        } else {
            //card login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_landing);
            imageName = "onboard_landing.png";
        }
        CommonUtils.setBitmapImage(mImageView, ImageDir.DIR_ENUM.ONBOARDING, imageName, defaultBitmap);

        //  Drawable passcodeDrawable = ResourcesCompat.getDrawable(getResources(), Globals.isBankLoginSelected() ? R.drawable.onboard_passcode_bank : R.drawable.onboard_landing, null);
        // mImageView.setImageDrawable(passcodeDrawable);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_exit) {
            if (mContext instanceof OnBoardActivity) {
                OnBoardHelper.navigateToCardOrBankHome();
            }
        } else if (v.getId() == R.id.buttonEnable) {
            //US53328
            if (Globals.isFromCardSide()) {
                analyticsForEnableBtn();
            }
            //ENDS

            getPasscodeStatus();
            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passcode_enable));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_passcode_intro_pge));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }//US53334 ENd
        }
    }

    //US53328
    private void analyticsForEnableBtn() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PROP1);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PEV1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PROP13);
        TrackingHelper.trackCardPage(null, extras);


    }

    //ENDS
    private void getPasscodeStatus() {
        if (Globals.isBankLoginSelected)
            onBoardServiceClass.getPasscodeStatusBank(mContext, this);
        else
            onBoardServiceClass.getPasscodeStatusCard(mContext, mDeviceToken, this);
    }

    private void hideKeyboard() {
        View view = getActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void navTo(OnBoardConstant.PASSCODE_PAGE_STATE toFragment) {
        if (toFragment == OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE) {
            ((OnBoardPasscodeContainerFragment) getParentFragment()).setIsPasscodeEnabled(false);
        } else {
            ((OnBoardPasscodeContainerFragment) getParentFragment()).setIsPasscodeEnabled(true);
        }
        Fragment navTo = new OnBoardBasePasscodeFragment();
        Bundle args = new Bundle();
        args.putSerializable(OnBoardConstant.PASSCODE_STATE_KEY, toFragment);
        navTo.setArguments(args);
        ((OnBoardPasscodeContainerFragment) getParentFragment()).pushFragment(navTo, true);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mContext = null;
        mView = null;
        mImageView = null;
        //Clear the Animation objects
        if (mFadeOutAnimation != null) {
            mFadeOutAnimation.setAnimationListener(null);
        }
        mFadeOutAnimation = null;
    }

    /**
     * Performs the Fade out animation after tapping on enable button
     * Pascode & setup text will get hidden with animation effect
     */
    public void PasscodeFadeOutAnimation() {
        //Initialize AlphaAnimation object
        mFadeOutAnimation = new AlphaAnimation(1.0f, 0.0f);
        //set animation duration
        mFadeOutAnimation.setDuration(PASSCODE_FADE_OUT_TIME);
        //set animation listener
        mFadeOutAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                //On Animation complete hiding this text
                mSetupPasscode.setVisibility(View.GONE);
                //On Animation complete hiding this text
                mPasscodeText.setVisibility(View.GONE);
                //On Animation complete hiding this button
                btnEnable.setVisibility(View.GONE);

                //On Animation complete, navigate to the create pass code page
                navTo(OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        //set pascode text animation
        mPasscodeText.startAnimation(mFadeOutAnimation);
        //set setup text animation
        mSetupPasscode.startAnimation(mFadeOutAnimation);
        //set setup button animation
        btnEnable.startAnimation(mFadeOutAnimation);
    }

    /**
     * Performs the Fade out and Fade in  animation on the passcode success Text View.
     * To be called after the passcode is typed in the fourth edit text
     */
    public void PasscodeFadeInFadeOutAnimation() {
        final Animation fadeOutAnimation = new AlphaAnimation(1.0f, 0.0f);
        fadeOutAnimation.setDuration(100);
        fadeOutAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mSetupPasscode.setVisibility(View.GONE);
                mPasscodeText.setVisibility(View.GONE);
                navTo(OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });

        mPasscodeText.startAnimation(fadeOutAnimation);
        mSetupPasscode.startAnimation(fadeOutAnimation);
    }


}
