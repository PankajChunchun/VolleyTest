package com.discover.mobile.common.shared.utils;

import com.discover.mobile.common.shared.utils.image.Utils;

import android.content.Context;
import android.util.Base64;

import java.security.SecureRandom;

public class TokenUtil {

    public static final String TOKEN_FORMAT_VERSION_2 = "2"; // VERSION_DYNA_KEY_ENC

    public static String genClientBindingToken() {
        SecureRandom scrRndm = new SecureRandom();
        byte[] random = new byte[64];// 64 byte per INFO SEC
        scrRndm.nextBytes(random);
        return new String(Base64.encodeToString(random, Base64.NO_WRAP));
    }

    public static String parseAndDecryptToken(Context context, String tokenStr) throws Exception {

        if (tokenStr != null && tokenStr.indexOf("{") >= 0
                && tokenStr.indexOf("}") >= 0) {
            return convertToVOAndDecrypt(context, tokenStr);
        } else {
            return SecurityUtil.decrypt(tokenStr);
        }
    }

    public static String parseAndDecryptTokenSupportClear(Context context, String tokenStr)
            throws Exception {
        if (tokenStr != null && tokenStr.indexOf("{") >= 0
                && tokenStr.indexOf("}") >= 0) {
            return convertToVOAndDecrypt(context, tokenStr);
        } else {
            return tokenStr;
        }
    }

    private static String convertToVOAndDecrypt(Context context, String tokenStr)
            throws Exception {

        TokenVO tokenVO = (TokenVO) Utils.getObjectFromJSONString(tokenStr, TokenVO.class);
        if (TOKEN_FORMAT_VERSION_2.equals(tokenVO.getFormatVer()))
            return SecurityUtil.decrypt(tokenVO.getValue());
        else
            throw new Exception(
                    "TokenUtil.convertToVOAndDecrypt():  unsupported token format version of "
                            + tokenVO.getFormatVer() + "!");

    }

    public static String encryptAndJsonifyToken(Context context, String clearToken)
            throws Exception {
        String encToken = SecurityUtil.encrypt(clearToken);
        return "{\"value\": \"" + encToken + "\", \"formatVer\": \""
                + TOKEN_FORMAT_VERSION_2 + "\"}";
    }

    /**
     * App data was lost due to encryption method is changed in 7.9 app version.
     * To save app cache after version upgrade we have written below functions to get old value encrypted value and decrypt with old key and encrypt with new key so that app data is preserved after app upgrade from 7.8 to 7.9.
     * below mentioned functions can be removed once all the customers are updated to 7.9 version.
     * 1. parseAndDecryptTokenSupportClearFromLogin
     * 2. convertToVOAndDecryptFromLogin
     **/

    public static String parseAndDecryptTokenSupportClearFromLogin(Context context, String tokenStr)
            throws Exception {
        if (tokenStr != null && tokenStr.indexOf("{") >= 0
                && tokenStr.indexOf("}") >= 0) {
            return convertToVOAndDecryptFromLogin(context, tokenStr);
        } else {
            return tokenStr;
        }
    }

    private static String convertToVOAndDecryptFromLogin(Context context, String tokenStr)
            throws Exception {

        TokenVO tokenVO = (TokenVO) Utils.getObjectFromJSONString(tokenStr, TokenVO.class);
        if (TOKEN_FORMAT_VERSION_2.equals(tokenVO.getFormatVer()))
            return LagacyEncryptionUtil.decryptTokenWithDynaFromLogin(context, tokenVO.getValue());
        else
            throw new Exception(
                    "TokenUtil.convertToVOAndDecrypt():  unsupported token format version of "
                            + tokenVO.getFormatVer() + "!");

    }
}
