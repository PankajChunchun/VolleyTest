package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by slende on 2/24/2017.
 * Added this class for US89215 - Messaging App SDK Integration
 */

public class MessagingFlags implements Serializable {

    @SerializedName("showChatContactUS")
    private Boolean showChatContactUS;

    @SerializedName("showChatInBellIcon")
    private Boolean showChatInBellIcon;

    @SerializedName("showChatACHome")
    private Boolean showChatACHome;

    public Boolean getShowChatContactUS() {
        return showChatContactUS;
    }

    public void setShowChatContactUS(Boolean showChatContactUS) {
        this.showChatContactUS = showChatContactUS;
    }

    public Boolean getShowChatInBellIcon() {
        return showChatInBellIcon;
    }

    public void setShowChatInBellIcon(Boolean showChatInBellIcon) {
        this.showChatInBellIcon = showChatInBellIcon;
    }

    public Boolean getShowChatACHome() {
        return showChatACHome;
    }

    public void setShowChatACHome(Boolean showChatACHome) {
        this.showChatACHome = showChatACHome;
    }


}
