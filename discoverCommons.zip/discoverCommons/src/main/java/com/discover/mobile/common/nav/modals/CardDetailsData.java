package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class CardDetailsData implements Serializable {
    @SerializedName("MenuItems")
    private ArrayList<NavigationMenuItem> menuItems;


    public ArrayList<NavigationMenuItem> getMenuItems() {
        return menuItems;
    }

    public void setMenuItems(ArrayList<NavigationMenuItem> cardMenuItems) {
        this.menuItems = cardMenuItems;
    }

}
