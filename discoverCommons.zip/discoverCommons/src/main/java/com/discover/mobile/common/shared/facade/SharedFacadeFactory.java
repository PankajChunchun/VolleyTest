package com.discover.mobile.common.shared.facade;

import java.util.HashMap;
import java.util.Map;

public class SharedFacadeFactory {
    /**
     * The private map to store the singleton objects
     */
    private static Map<String, Object> singletons = new HashMap<String, Object>();

    /**
     * @return CardShareDataStore facade
     */
    public static CardShareDataStoreFacade getCardShareDataStoreFacade() {
        return (CardShareDataStoreFacade) getImplClass("com.discover.mobile.card.facade.CardShareDataStoreImpl");
    }

    /**
     * Loads the impl class, expecting to find it in the classloader.
     *
     * Expects the facade class to have a single, unparameterized constructor
     */
    private static synchronized Object getImplClass(final String fullyQualifiedClassName) {
        Object facade = singletons.get(fullyQualifiedClassName);
        if (facade == null) {
            try {

                facade = Class.forName(fullyQualifiedClassName).getConstructors()[0].newInstance(null);

                singletons.put(fullyQualifiedClassName, facade);
            } catch (final Exception e) {
                throw new RuntimeException("FACADE BOOTSTRAP FAILED: Unable to find facade impl class:"
                        + fullyQualifiedClassName + "\n" + e.toString());
            }
        }
        return facade;
    }
}
