package com.discover.mobile.common.shared.utils.image;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.shared.utils.CommonUtils;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by skrish1 on 5/2/2016.
 */
public class FileDownloader {

    private static FileDownloader instance;
    private static ExecutorService fileDownloader;
    private static Context mContext;
    private FileCache fileCache;
    private MemoryCache memoryCache = new MemoryCache();

    public static FileDownloader getInstance() {
        if (instance == null) {
            instance = new FileDownloader();
            fileDownloader = Executors.newFixedThreadPool(10);
            mContext = DiscoverApplication.getGlobalContext();
        }
        return instance;
    }

    public void downloadFile(String[] filesToDownload, ImageDir.DIR_ENUM dirEnum, ImageDir.FILE_TYPE fileEnum) {
        String dirName = dirEnum.toString();
        if (CommonUtils.isNullOrEmpty(dirName) || filesToDownload == null || filesToDownload.length == 0) {
            //invalid details to download
            return;
        }
        //create a folder with the module specific name
        fileCache = new FileCache(mContext, dirName);
        //download all the files to the mentioned dirName with key as filename
        //create a loop and submit the task
        String relativeUrl = null;
        if (ImageDir.FILE_TYPE.IMAGE == fileEnum)
            relativeUrl = CommonUtils.getAbsoluteImageUrl(mContext, dirEnum);
        else
            relativeUrl = CommonUtils.getAbsoluteMediaUrl(mContext, dirEnum);

        StringBuilder urlBuilder = null;
        for (String fileName : filesToDownload) {
            //construct the full url
            urlBuilder = new StringBuilder();
            urlBuilder.append(relativeUrl);
            urlBuilder.append(fileName);
            fileDownloader.execute(new FileDownload(urlBuilder.toString(), dirName, fileName));
        }
        // shutDownService();
    }

    public Bitmap getBitmap(ImageDir.DIR_ENUM dirEnum, String fileName) {
        fileCache = new FileCache(mContext, dirEnum.toString());
        String path = fileCache.getCacheDir().getAbsolutePath() + File.separator + dirEnum.toString();
        File f = new File(path, fileName);
        Bitmap b = com.discover.mobile.common.Utils.decodeFile(f);
        if (b != null) {
            Log.e("Sundeep", "Loading bitmap from card");
            return b;
        }
        return null;
    }

    public Uri getMediaFileURI(ImageDir.DIR_ENUM dirName, String fileName) {
        //create a folder with the module specific name
        fileCache = new FileCache(mContext, dirName.toString());
        String path = fileCache.getCacheDir().getAbsolutePath() + File.separator + dirName.toString();
        File f = new File(path, fileName);
        return Uri.parse(f.getAbsoluteFile().toString());
    }

    public void flushImages(ImageDir.DIR_ENUM dirEnum) {
        //  memoryCache.clearFileCache();
        if (fileCache != null) {
            fileCache.flushDirectory(dirEnum.toString());
        }
    }

    public void shutDownService() {
        if (fileDownloader != null)
            fileDownloader.shutdown();
    }

    public class FileDownload implements Runnable {
        private String url;
        private String dirName;
        private String fileName;

        FileDownload(String url, String dirName, String fileName) {
            this.url = url;
            this.dirName = dirName;
            this.fileName = fileName;
        }

        @Override
        public void run() {
            try {
                String path = fileCache.getCacheDir().getAbsolutePath() + File.separator + dirName;
                File file = new File(path, fileName);

                URL imageUrl = new URL(this.url);
                HttpURLConnection conn = (HttpURLConnection) imageUrl.openConnection();
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(30000);
                conn.setInstanceFollowRedirects(true);
                InputStream is = conn.getInputStream();
                OutputStream os = new FileOutputStream(file);
                Utils.CopyStream(is, os);
                os.close();
                conn.disconnect();

                //    memoryCache.put(this.url, file);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
