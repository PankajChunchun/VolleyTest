package com.discover.mobile.common.portalpage.beans;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.utils.PortalConstants;

import java.io.Serializable;

//Added serializable to avoid crash, on selecting phone number on portal page bank error box.
public class BankVerifyAccount implements PortalBoxInterface, Serializable {
    private static final long serialVersionUID = 2803421668447076588L;

    @Override
    public String getSortId() {
        return PortalConstants.VERIFY_ACCOUNT_BOX_ID;
    }
}
