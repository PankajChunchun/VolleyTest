package com.discover.mobile.common.fico.interfaces;

import com.discover.mobile.common.fico.fragments.CmnFicoCreditScoreMasterFragment;
import com.discover.mobile.network.error.bean.ErrorBean;

/**
 * Created by slende on 5/17/2017.
 * Interface for Hosting activity- CardDrawerActivity, BankDrawerActivity to handle "Privacy &
 * Terms click", "Card or Bank specific error handling"
 */

public interface FicoCreditScoreHostInterface {

    /**
     * UI click events that needs to handle either Card specific or Bank specific only
     */
    enum FICOCreditScoreUIEvents {
        PRIVACY_AND_TERMS_CLICK_EVENT,
        PROVIDE_FEEDBACK_CLICK_EVENT,
        FICO_SCORE_FAQ_ClICK_EVENT
    }

    /**
     * Method to handle error scenarios for "v3/ficoscore" end point on Card or Bank specific
     */
    void handleFICOCreditScoreAPIErrorScenarios(ErrorBean ficoErrorBean, CmnFicoCreditScoreMasterFragment cmnFicoMasterFragment);

    /**
     * Method to handle UI click events that needs to handle either Card specific or Bank specific
     * only
     */
    void handleFICOCreditScoreUIEvents(FICOCreditScoreUIEvents uiClickEvent);
}
