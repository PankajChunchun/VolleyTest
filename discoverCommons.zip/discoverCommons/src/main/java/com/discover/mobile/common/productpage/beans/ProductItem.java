package com.discover.mobile.common.productpage.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Class which defines each title and details with respective link on product
 * page.
 *
 * @author pkuma13
 */
public class ProductItem {

    private static final String KEY_CREDIT_CARD = "Credit Cards";
    private static final String KEY_BANKING = "Banking";
    private static final String KEY_LOAN = "Loans";

    private String label;
    private String url;

    public ProductItem(String label, String url) {
        super();
        this.label = label;
        this.url = url;
    }

    public static final HashMap<String, List<ProductItem>> getData() {
        HashMap<String, List<ProductItem>> productListDetails = new HashMap<String, List<ProductItem>>();

        List<ProductItem> creditCardUrls = new ArrayList<ProductItem>();
        creditCardUrls.add(new ProductItem("Cash Credit Card", "https://www.discover.com/credit-cards/"));
        creditCardUrls.add(new ProductItem("Miles Credit Card", "https://www.discover.com/credit-cards/miles/"));
        creditCardUrls.add(new ProductItem("NHL Credit Card", "https://www.discover.com/credit-cards/affinity/nhl.html"));
        creditCardUrls.add(new ProductItem("Student Credit Card", "https://www.discover.com/credit-cards/student/"));
        List<ProductItem> bankUrls = new ArrayList<ProductItem>();
        bankUrls.add(new ProductItem("Cashback Checking", "https://www.discover.com/online-banking/checking/"));
        bankUrls.add(new ProductItem("Online Savings", "https://www.discover.com/online-banking/savings-account/"));
        bankUrls.add(new ProductItem("Money Market", "https://www.discover.com/online-banking/money-market/"));
        bankUrls.add(new ProductItem("CDs", "https://www.discover.com/online-banking/cd/"));
        bankUrls.add(new ProductItem("IRA CDs", "https://www.discover.com/online-banking/ira-cd/"));
        List<ProductItem> loanUrls = new ArrayList<ProductItem>();
        loanUrls.add(new ProductItem("Home Loans", "https://www.discover.com/home-loans/"));
        loanUrls.add(new ProductItem("Home Equity Loans", "https://www.discover.com/home-equity-loans/"));
        loanUrls.add(new ProductItem("Student Loans", "https://www.discover.com/student-loans/"));
        loanUrls.add(new ProductItem("Personal Loans", "https://www.discover.com/personal-loans/"));

        productListDetails.put(KEY_CREDIT_CARD, creditCardUrls);
        productListDetails.put(KEY_BANKING, bankUrls);
        productListDetails.put(KEY_LOAN, loanUrls);
        return productListDetails;
    }

    public static final ArrayList<String> getTitles() {
        // Used separate list to remember order of titles.
        ArrayList<String> titles = new ArrayList<String>(3);
        titles.add(KEY_CREDIT_CARD);
        titles.add(KEY_BANKING);
        titles.add(KEY_LOAN);
        return titles;
    }

    public final String getLabel() {
        return label;
    }

    public final String getUrl() {
        return url;
    }
}