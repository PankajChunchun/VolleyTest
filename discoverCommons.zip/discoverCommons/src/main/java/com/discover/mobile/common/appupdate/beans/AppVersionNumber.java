package com.discover.mobile.common.appupdate.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Model class which is used for application's version number. This class will
 * be used to parse json for updated version name on server. Same class can be
 * used to create a object with current version name of application from device.
 * Both instances can be used to check if latest version is available on server
 * or not.
 *
 * @author pkuma13
 */
public class AppVersionNumber implements Serializable,
        Comparable<AppVersionNumber> {

    private static final long serialVersionUID = 7056103004090484759L;

    @SerializedName("version_number")
    private String version_number;

    public String getVersion_number() {
        return version_number;
    }

    public void setVersion_number(String version_number) {
        this.version_number = version_number;
    }

    public AppVersionNumber getClone() {
        AppVersionNumber clonedObject = new AppVersionNumber();
        clonedObject.setVersion_number(this.version_number);
        return clonedObject;
    }

    /**
     * Check if given version name is applicable for application's version name
     * or not.
     *
     * @return <code>true</code> if {@link AppVersionNumber#version_number} can
     * be version of an application, otherwise it returns
     * <code>false</code>
     */
    public boolean isValidVersionName() {
        boolean result = false;
        if ((this.version_number != null)
                && (this.version_number.matches("[0-9]+(\\.[0-9]+)*"))) {
            result = true;
        }
        return result;
    }

    @Override
    public int compareTo(AppVersionNumber that) {
        if (that == null || (!that.isValidVersionName()))
            return -1;
        String[] thisParts = this.version_number.split("\\.");
        String[] thatParts = that.getVersion_number().split("\\.");
        int length = Math.max(thisParts.length, thatParts.length);
        for (int i = 0; i < length; i++) {
            int thisPart = i < thisParts.length ? Integer
                    .parseInt(thisParts[i]) : 0;
            int thatPart = i < thatParts.length ? Integer
                    .parseInt(thatParts[i]) : 0;
            if (thisPart < thatPart)
                return -1;
            if (thisPart > thatPart)
                return 1;
        }
        return 0;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that)
            return true;
        if (that == null)
            return false;
        if (this.getClass() != that.getClass())
            return false;
        return this.compareTo((AppVersionNumber) that) == 0;
    }

    @Override
    public String toString() {
        return "AppVersionNumber [version_number=" + version_number + "]";
    }
}

