package com.discover.mobile.common.shared.utils;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PhotoUtil {

    private static final String FILE_SUFFIX = ".jpg";

    /**
     * Take screenshot of view
     */
    public static Bitmap captureScreenshot(View v1) {
        v1.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
        v1.setDrawingCacheEnabled(false);
        // bitmap
        return bitmap;
    }

    public static boolean isWriteable() {
        boolean externalStorageAvailable = false;
        boolean externalStorageWriteable = false;
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            //we can read and write media
            externalStorageAvailable = externalStorageWriteable = true;
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            externalStorageAvailable = true;
            externalStorageWriteable = false;
        } else {
            //something else is wrong
            externalStorageAvailable = externalStorageWriteable = false;
        }
        return externalStorageWriteable;
    }

    /**
     * Saves bitmap to Discover gallery
     */
    public static File saveBitmap(Bitmap bitmap, String album, String fileName, Context c) throws IOException {
        if (!isWriteable()) {
            throw new IOException();
        }
        album = URLEncoder.encode(album, "utf-8");
        fileName = URLEncoder.encode(fileName, "utf-8");

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 40, bytes);

        createAlbumIfNotExists(album, c);

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File f = new File(c.getExternalFilesDir(Environment.DIRECTORY_PICTURES), album + "/" + fileName + "_" + timeStamp + FILE_SUFFIX);
//		File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), album + "/" + fileName + "_" + timeStamp + FILE_SUFFIX);
        f.createNewFile();
        FileOutputStream fo = new FileOutputStream(f);
        fo.write(bytes.toByteArray());
        fo.close();
        return f.getAbsoluteFile();
    }


    private static void createAlbumIfNotExists(String albumName, Context c) {
//		File storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), albumName);
        File storageDir = new File(c.getExternalFilesDir(Environment.DIRECTORY_PICTURES), albumName);
        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }
    }

    /**
     * Adds image file to the photo gallery
     */
    public static void addToGallery(File f, Context c) {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        c.sendBroadcast(mediaScanIntent);
    }

    /**
     * Opens an image from the file system
     */
    public static void openImage(File fileName, Context c) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        Log.v("File", fileName.toString());
        intent.setDataAndType(Uri.parse("file://" + fileName), "image/*");
        c.startActivity(intent);
    }
}
