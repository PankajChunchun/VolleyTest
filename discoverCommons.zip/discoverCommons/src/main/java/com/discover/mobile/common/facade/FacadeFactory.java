/**
 * \ * Copyright Solstice-Mobile 2013
 */
package com.discover.mobile.common.facade;

import com.discover.mobile.common.framework.Conductor;
import com.discover.mobile.common.shared.AccountType;
import com.discover.mobile.common.shared.facade.CardShareDataStoreFacade;

import java.util.HashMap;
import java.util.Map;


/**
 * A factory used to get an appropriate facade for child project code.
 *
 * @author ekaram
 *
 */
public final class FacadeFactory {

    /**
     * The private map to store the singleton objects
     */
    private static Map<String, Object> singletons = new HashMap<String, Object>();

    /**
     * This is a utility class and should not have a public or default constructor.
     */
    private FacadeFactory() {
        throw new UnsupportedOperationException();
    }

    /**
     * The logout facade
     * @return
     */
    public static LogoutFacade getLogoutFacade() {
        return (LogoutFacade) getImplClass("com.discover.mobile.common.facade.LogoutFacadeImpl");
    }

    /**
     * The BANK logout facade
     * @return
     */
    public static BankLogoutFacade getBankLogoutFacade() {
        return (BankLogoutFacade) getImplClass("com.discover.mobile.bank.facade.BankLogoutFacadeImpl");
    }

    /**
     * The card logout facade
     * @return
     */
    public static CardLogoutFacade getCardLogoutFacade() {
        return (CardLogoutFacade) getImplClass("com.discover.mobile.card.logout.facade.CardLogoutFacadeImpl");
    }

    /**
     * The login facade
     * @return
     */
    public static LoginActivityFacade getLoginFacade() {
        return (LoginActivityFacade) getImplClass("com.discover.mobile.bank.facade.LoginActivityFacadeImpl");
    }
    /**
     * Customer service resides in bank code, but is shared
     * @return
     */
    /*public static CustomerServiceFacade getCustomerServiceFacade(){
		return (CustomerServiceFacade) getImplClass("com.discover.mobile.bank.facade.CustomerServiceFacadeImpl");
	}*/

    /**
     * Customer service resides in bank code, but is shared
     * @return
     */
	/*public static PushFacade getPushFacade(){
		return (PushFacade) getImplClass("com.discover.mobile.card.facade.PushFacadeImpl");
	}*/


    /**
     * Common card navigation
     * @return
     */
    public static CardFacade getCardFacade() {
        return (CardFacade) getImplClass("com.discover.mobile.card.facade.CardFacadeImpl");
    }

    /**
     * Common bank navigation
     * @return
     */
    public static BankFacade getBankFacade() {
        return (BankFacade) getImplClass("com.discover.mobile.bank.facade.BankFacadeImpl");
    }

    /**
     * Common card navigation
     * @return
     */
    public static CardLoginFacade getCardLoginFacade() {
        return (CardLoginFacade) getImplClass("com.discover.mobile.card.facade.CardLoginFacadeImpl");
    }

    /**
     * Common card navigation
     * @return
     */
    public static BankLoginFacade getBankLoginFacade() {
        return (BankLoginFacade) getImplClass("com.discover.mobile.bank.facade.BankLoginFacadeImpl");
    }

    /**
     * Keep Alive facade for Bank
     * @return
     */
    public static BankKeepAliveFacade getBankKeepAliveFacade() {
        return (BankKeepAliveFacade) getImplClass("com.discover.mobile.bank.facade.BankKeepAliveFacadeImpl");
    }

    /**
     * Keep Alive facade for Card
     * @return
     */
    public static CardKeepAliveFacade getCardKeepAliveFacade() {
        return (CardKeepAliveFacade) getImplClass("com.discover.mobile.card.facade.CardKeepAliveFacadeImpl");
    }

    /**
     * Returns the conductor facade
     * @param accountType
     * @return
     */
    public static Conductor getConductorFacade(final AccountType accountType) {
        if (accountType == AccountType.CARD_ACCOUNT) {
            return (Conductor) getImplClass("com.discover.mobile.card.facade.CardConductorFacadeImpl");
        } else {
            return (Conductor) getImplClass("com.discover.mobile.card.facade.BankConductorFacadeImpl");
        }
    }

	/*
	 * Changes start for Whats new Reminder
	 */

    public static WhatsNewReminderFacade getWhatsNewReminderFacade() {
        return (WhatsNewReminderFacade) getImplClass("com.discover.mobile.card.facade.WhatsNewReminderFacadeImpl");
    }
	
	/*
	 * Changes end for Whats new Reminder
	 */

    /**
     *
     * @return CardShareDataStore facade
     */
    public static CardShareDataStoreFacade getCardShareDataStoreFacade() {
        return (CardShareDataStoreFacade) getImplClass("com.discover.mobile.card.facade.CardShareDataStoreImpl");
    }

    public static HighlightedFeaturesFacade getHighlightedFeaturesFacade() {
        return (HighlightedFeaturesFacade) getImplClass("com.discover.mobile.card.facade.HighlightedFeaturesFacadeImpl");
    }


    /**
     * @return ResourceDownloader facade
     */
	/*public static ResourceDownloaderFacade getResourceDownloaderFacade(){
		return (ResourceDownloaderFacade) getImplClass("com.discover.mobile.card.facade.ResourceDownloaderImpl");
	}*/

    /**
     * @return WDAFacade facade
     */
    public static WDAFacade getWDAFacade() {
        return (WDAFacade) getImplClass("com.discover.mobile.card.facade.WDAFacadeImpl");
    }

    // Start-15.4 Updated for threat matrix- rsharm9
    // returns LocationServiceFacade
    public static LocationServiceFacade getLocationFacade() {
        return (LocationServiceFacade) getImplClass("com.discover.mobile.card.geofence.LocationFacade");
    }

    // End-15.4 Updated for threat matrix- rsharm9

    /**
     * Loads the impl class, expecting to find it in the classloader.
     *
     * Expects the facade class to have a single, unparameterized constructor
     *
     * @param fullyQualifiedClassName
     * @return
     */
    private static synchronized Object getImplClass(final String fullyQualifiedClassName) {
        Object facade = singletons.get(fullyQualifiedClassName);
        if (facade == null) {
            try {

                facade = Class.forName(fullyQualifiedClassName).getConstructors()[0].newInstance(null);

                singletons.put(fullyQualifiedClassName, facade);
            } catch (final Exception e) {
                throw new RuntimeException("FACADE BOOTSTRAP FAILED: Unable to find facade impl class:"
                        + fullyQualifiedClassName + "\n" + e.toString());
            }
        }
        return facade;
    }


    /**
     * @return CardProductFacade
     */
    public static CardProductFacade getCardProductFacade() {
        return (CardProductFacade) getImplClass("com.discover.mobile.common.productpage.facade.CardProductFacadeImpl");
    }

    /**
     * Common card navigation 
     * @return
     */
    public static OOBFacade getOOBFacade() {
        return (OOBFacade) getImplClass("com.discover.mobile.card.facade.OOBFacadeImpl");
    }

    //US21899 start

    /**
     * Common card navigation
     * @return
     */
    public static CardPushNotificationFacade getCardPushNotificationFacade() {
        return (CardPushNotificationFacade) getImplClass("com.discover.mobile.card.facade.CardPushNotificationFacadeImpl");
    }

    /**
     * Common bank navigation
     * @return
     */
    public static BankPushNotificationFacade getBankPushNotificationFacade() {
        return (BankPushNotificationFacade) getImplClass("com.discover.mobile.bank.facade.BankPushNotificationFacadeImpl");
    }

    //US21899 end
    // Added for 6.7 Portal Release
    public static PortalPageFacade getPortalPageFacade() {
        return (PortalPageFacade) getImplClass("com.discover.mobile.card.facade.PortalPageFacadeImpl");
    }
	
/*	// Added for 6.7 Portal Release
	public static UtilPageFacade getUtilPageFacade(){
		return (UtilPageFacade) getImplClass("com.discover.mobile.card.facade.UtilPageImpl");
	}*/

    //US29136 changes start
    public static PortalPageBankFacade getPortalPageBankFacade() {
        return (PortalPageBankFacade) getImplClass("com.discover.mobile.bank.facade.PortalPageBankFacadeImpl");
    }
    //US29136 changes end

    public static HighlightedFeatureDeeplinkCardFacade getCardHFDeeplinkFacade() {
        return (HighlightedFeatureDeeplinkCardFacade) getImplClass("com.discover.mobile.card.facade.HFDeeplinkCardFacadeImpl");
    }

    public static HighlightedFeatureDeeplinkBankFacade getBankHFDeeplinkFacade() {
        return (HighlightedFeatureDeeplinkBankFacade) getImplClass("com.discover.mobile.bank.facade.WhatsNewDeeplinkFacadeImpl");
    }

    public static HighlightedFeatureDeeplinkSSOFacade getCardSSODeeplinkFacade() {
        return (HighlightedFeatureDeeplinkSSOFacade) getImplClass("");
    }

    /**
     * Function Added to call BankOnBoardActivityFacade service classses from bank project
     * @return - BankOnBoardActivityFacadeImpl
     */
    public static BankOnBoardActivityFacade getBankOnBoardActivityFacade() {
        return (BankOnBoardActivityFacade) getImplClass("com.discover.mobile.bank.facade.BankOnBoardActivityFacadeImpl");
    }

    public static CardOnBoardFacade getCardOnBoardFacadeImpl() {
        return (CardOnBoardFacade) getImplClass("com.discover.mobile.card.facade.CardOnBoardFacadeImpl");
    }

    public static WalletHelperFacade getWalletHelperFacade() {
        return (WalletHelperFacade) getImplClass("com.discover.mobile.card.facade.WalletHelperFacadeImpl");
    }
}
