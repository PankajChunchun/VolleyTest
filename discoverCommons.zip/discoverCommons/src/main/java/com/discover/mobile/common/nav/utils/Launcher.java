package com.discover.mobile.common.nav.utils;

/**
 * Created by 468195 on 4/28/2016.
 */
public class Launcher {

    /**
     * This is the object if the Class that is to be launched on click of the LHN item.
     */
    private Object mObject;

    /**
     * This is the method name in case the method is to be invoked instead of the
     * Activity or the fragment
     */
    private String mMethodName;


    public Object getmObject() {
        return mObject;
    }

    public void setmObject(Object mObject) {
        this.mObject = mObject;
    }

    public String getmMethodName() {
        return mMethodName;
    }

    public void setmMethodName(String mMethodName) {
        this.mMethodName = mMethodName;
    }
}
