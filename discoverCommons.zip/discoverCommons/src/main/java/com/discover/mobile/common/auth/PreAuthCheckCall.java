package com.discover.mobile.common.auth;

import com.discover.mobile.common.Utils.Type;
import com.discover.mobile.common.auth.PreAuthCheckCall.PreAuthResult;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.login.beans.PreAuthbean;
import com.discover.mobile.common.shared.Struct;
import com.discover.mobile.common.shared.callback.AsyncCallback;
import com.discover.mobile.common.shared.net.NetworkServiceCall;
import com.discover.mobile.common.shared.net.ServiceCallParams;
import com.discover.mobile.common.shared.net.ServiceCallParams.GetCallParams;
import com.discover.mobile.common.shared.net.StrongReferenceHandler;
import com.discover.mobile.common.shared.net.TypedReferenceHandler;
import com.discover.mobile.common.shared.utils.image.Utils;

import android.content.Context;
import android.util.Log;

import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Preauth call that is used to determine if the application is out of date and if
 * the application can be used.
 *
 * @author jthornton
 */
public class PreAuthCheckCall extends NetworkServiceCall<PreAuthResult> {

    /** Parameters that need to be applied to the service call */
    private static final ServiceCallParams OARAMS = new GetCallParams(FacadeFactory.getCardFacade().getPreAuthUrl()) {{
        requiresSessionForRequest = false;
    }};
    private static final String ANIMATION_PROPERTY_KEY = "AnimationDelay";
    private static final String ANIMATION_DELAY_PROPERTY = "androidAnimationLag";
    /** Reference handler for the request */
    private final TypedReferenceHandler<PreAuthResult> handler;
    private Context context;


    /**
     * Constructor for the call
     *
     * @param context  - context used to make the call
     * @param callback - callbak used to make the call
     */
    public PreAuthCheckCall(final Context context, final AsyncCallback<PreAuthResult> callback) {
        super(context, OARAMS, FacadeFactory.getCardFacade().getPreAuthBaseUrl());
        this.context = context;
        handler = new StrongReferenceHandler<PreAuthResult>(callback);
    }

    @Override
    protected TypedReferenceHandler<PreAuthResult> getHandler() {
        return handler;
    }

    @Override
    protected PreAuthResult parseSuccessResponse(final int status, final Map<String, List<String>> headers,
                                                 final InputStream responseStream) {

        return new PreAuthResult() {{
            statusCode = status;
            final List<String> descriptions = headers.get("VersionInfo");

            if (descriptions != null && !descriptions.isEmpty()) {
                upgradeDescription = descriptions.get(0);
            }

            //Response Body Handling
            //convert the response stream to string
            String response = convertStreamToString(responseStream);
            try {
                //convert the string to PreAuthBean json
                PreAuthbean bean = (PreAuthbean) Utils.getObjectFromJSONString(response, PreAuthbean.class);

                /**
                 * This will add the dynamic properties to the Utils
                 */
                if (bean != null) {
                    Utils.setDynamicProperties(bean);
                    Map<String, Object> properties = bean.getDynamicPropertiesMap();

                    Iterator<Entry<String, Object>> iterator = properties.entrySet().iterator();

                    while (iterator.hasNext()) {
                        Entry<String, Object> entry = iterator.next();
                        Log.e("Sundeep", "Key: " + entry.getKey() + "     Value: " + entry.getValue());
                    }


                    if (!properties.isEmpty() && properties.containsKey(ANIMATION_DELAY_PROPERTY)) {
                        com.discover.mobile.common.Utils.saveToPreference(context, ANIMATION_PROPERTY_KEY, Long.valueOf(bean.getDynamicProperties(ANIMATION_DELAY_PROPERTY).toString()), Type.LONG,"");
                    }

                }

                //handle the kill switch
                handlePreLoginkillSwitch(bean);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }};
    }

    /**
     * This method sends call to add the kill-switch to utils
     */
    private void handlePreLoginkillSwitch(PreAuthbean mPreAuthBean) {
        if (mPreAuthBean.getHideScreens() != null)
            FacadeFactory.getCardLoginFacade().addPreloginKillSwitch(context, mPreAuthBean.getHideScreens());
    }

    @Override
    protected String getBaseUrl() {
        return FacadeFactory.getCardFacade().getPreAuthBaseUrl();
    }

    private String convertStreamToString(java.io.InputStream is) {
        java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
//		return new String ("{\"hideScreens\":[\"ESIGN\",\"EXTRAS_PRELOGIN\",\"PRELOGIN_ESIGN\"],\"dynamicProperties\":{\"ranjeet\":\"15\",\"androidAnimationLag\":\"4\",\"iOSAnimationLag\":\"4\",\"whatsNewReminder\":\"45\",\"remindMeLater\":\"2\",\"pages\":[{\"achpageId\":\"763986501\",\"areas\":[{\"achAreaId\":\"905157801\",\"reporterAreaId\":\"375160402\"}]}]}}");
    }

    @Struct
    public static class PreAuthResult {
        public int statusCode;
        public String upgradeDescription = null;
    }

}
