package com.discover.mobile.common.onboardwiz.interfaces;

import android.content.Context;

/**
 * Created by 436645 on 11/1/2016.
 */
public interface OnBoardFingerPrintUI {

    void showRibbenMessage();
    void showPage(int typePage);
    int getCurrentPageState();
    int getPreviousPageState();
}
