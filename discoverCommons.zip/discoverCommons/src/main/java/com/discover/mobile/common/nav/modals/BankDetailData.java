package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by 465241 on 3/4/2016.
 */
public class BankDetailData implements Serializable {
    @SerializedName("BankMenuItems")
    private ArrayList<NavigationMenuItem> BankMenuItems;

    public ArrayList<NavigationMenuItem> getBankMenuItems() {
        return BankMenuItems;
    }

    public void setBankMenuItems(ArrayList<NavigationMenuItem> bankMenuItems) {
        this.BankMenuItems = bankMenuItems;
    }

}
