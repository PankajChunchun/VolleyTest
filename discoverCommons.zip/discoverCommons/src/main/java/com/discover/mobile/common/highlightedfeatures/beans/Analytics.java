package com.discover.mobile.common.highlightedfeatures.beans;

import com.google.gson.annotations.SerializedName;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * {@link com.discover.mobile.common.highlightedfeatures.beans.Analytics} details for a {@link
 * FeatureContent}.
 *
 * @author pkuma13
 */
public class Analytics implements Serializable, Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Analytics> CREATOR = new Parcelable.Creator<Analytics>() {
        @Override
        public Analytics createFromParcel(Parcel in) {
            return new Analytics(in);
        }

        @Override
        public Analytics[] newArray(int size) {
            return new Analytics[size];
        }
    };
    @SerializedName("HFAnalyticsTagPageView")
    private String hfAnalyticsTagPageView;
    @SerializedName("WNAnalyticsTagPageView")
    private String wnAnalyticsTagPageView;
    @SerializedName("WNAnalyticsTagButtonClick")
    private String wnAnalyticsTagButtonClick;
    @SerializedName("HFAnalyticsTagButtonClick")
    private String hfAnalyticsTagButtonClick;
    @SerializedName("WNAnalyticsTagCloseClick")
    private String wnAnalyticsTagCloseClick;

    // ***********************************************************
    // ******* PARCELABLE Codes starts
    // ***********************************************************
    protected Analytics(Parcel in) {
        hfAnalyticsTagPageView = in.readString();
        wnAnalyticsTagPageView = in.readString();
        wnAnalyticsTagButtonClick = in.readString();
        hfAnalyticsTagButtonClick = in.readString();
        wnAnalyticsTagCloseClick = in.readString();
    }

    public final String getHfAnalyticsTagPageView() {
        return hfAnalyticsTagPageView;
    }

    public final void setHfAnalyticsTagPageView(String hfAnalyticsTagPageView) {
        this.hfAnalyticsTagPageView = hfAnalyticsTagPageView;
    }

    public final String getWnAnalyticsTagPageView() {
        return wnAnalyticsTagPageView;
    }

    public final void setWnAnalyticsTagPageView(String wnAnalyticsTagPageView) {
        this.wnAnalyticsTagPageView = wnAnalyticsTagPageView;
    }

    public final String getWnAnalyticsTagButtonClick() {
        return wnAnalyticsTagButtonClick;
    }

    public final void setWnAnalyticsTagButtonClick(
            String wnAnalyticsTagButtonClick) {
        this.wnAnalyticsTagButtonClick = wnAnalyticsTagButtonClick;
    }

    public final String getHfAnalyticsTagButtonClick() {
        return hfAnalyticsTagButtonClick;
    }

    public final void setHfAnalyticsTagButtonClick(
            String hfAnalyticsTagButtonClick) {
        this.hfAnalyticsTagButtonClick = hfAnalyticsTagButtonClick;
    }

    /*US113465 : OverDraft Whatsnew Sitcat*/
    public final String getWnAnalyticsTagCloseClick() {
        return wnAnalyticsTagCloseClick;
    }

    public final void setWnAnalyticsTagCloseClick(
            String wnAnalyticsTagCloseClick) {
        this.wnAnalyticsTagCloseClick = wnAnalyticsTagCloseClick;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(hfAnalyticsTagPageView);
        dest.writeString(wnAnalyticsTagPageView);
        dest.writeString(wnAnalyticsTagButtonClick);
        dest.writeString(hfAnalyticsTagButtonClick);
        dest.writeString(wnAnalyticsTagCloseClick);
    }
    // ***********************************************************
    // ******* PARCELABLE Codes end
    // ***********************************************************
}