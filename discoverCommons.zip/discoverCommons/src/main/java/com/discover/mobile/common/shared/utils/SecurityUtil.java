package com.discover.mobile.common.shared.utils;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.encryption.LegacySecureRandom;
import com.discover.mobile.common.encryption.SHA1PRNG_SecureRandomImpl;

import android.content.Context;
import android.provider.Settings;
import android.util.Base64;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * Utility for Encrypting and Decrypting data based on dynamic key.
 *
 * Dynamic key generates based on ANDROID_ID.
 *
 */
public class SecurityUtil {

    /**
     * Generates the dynamic key based on ANDROID_ID and returns the key bytes.
     * @return
     * @throws Exception
     */
    private static byte[] getDynaKey() throws Exception {
        Context mContext = DiscoverApplication.getGlobalContext();
        String SEED4KEY = Settings.Secure.getString(mContext.getContentResolver(), Settings.Secure.ANDROID_ID);

        byte[] seedBytes = SEED4KEY.getBytes();
        KeyGenerator kgen = KeyGenerator.getInstance("AES");

        SecureRandom sr = new LegacySecureRandom(new SHA1PRNG_SecureRandomImpl(), null);
        sr.setSeed(seedBytes);
        kgen.init(256, sr); // 192 and 256 bits may not be available
        SecretKey skey = kgen.generateKey();
        byte[] keyBytes = skey.getEncoded();
        return keyBytes;
    }

    /**
     * Encrptes the plain bytes based on use dyna value and returns encrypted bytes.
     * if useDyna is true then with dynamic key
     * else without dynamic key
     * @param clearBytes
     * @return
     * @throws Exception
     */
    private static byte[] encrypt(byte[] clearBytes) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(getDynaKey(), "AES");

        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);

        byte[] encryptedBytes = cipher.doFinal(clearBytes);

        return encryptedBytes;
    }

    /**
     * Encrypts the plain string based on value of useDyna
     * if useDyna is true then with dynamic key
     * else without dynamic key
     * @param clearStr
     * @return
     * @throws Exception
     */
    public static String encrypt(String clearStr) throws Exception {
        //byte[] clearBytes = clearStr.getBytes();
        byte[] clearBytes = Base64.encode(clearStr.getBytes(), Base64.DEFAULT);
        byte[] encryptedBytes = encrypt(clearBytes);
        //return new String(encryptedBytes);
        return new String(Base64.encodeToString(encryptedBytes, Base64.NO_WRAP | Base64.NO_PADDING));
    }

    /**
     * Decrypts the encrypted bytes based on use dyna value and returns plain bytes.
     * if useDyna is true then with dynamic key
     * else without dynamic key
     * @param encryptedBytes
     * @return
     * @throws Exception
     */
    private static byte[] decrypt(byte[] encryptedBytes) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(getDynaKey(), "AES");

        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);

        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        return decryptedBytes;
    }

    /**
     * Decrypts the encrypted string to plain string based on useDyna value
     * if useDyna is true then with dynamic key
     * else without dynamic key
     * @param encryptedStr
     * @return
     * @throws Exception
     */
    public static String decrypt(String encryptedStr) throws Exception {
        //byte[] encryptedBytes = encryptedStr.getBytes();
        byte[] encryptedBytes = Base64.decode(encryptedStr, Base64.DEFAULT);
        byte[] clearBytes = decrypt(encryptedBytes);
        //return new String(clearBytes);
        return new String(Base64.decode(clearBytes, Base64.NO_WRAP | Base64.NO_PADDING));
    }

}