package com.discover.mobile.common.login;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.net.SessionTokenManager;


public class ApplinkActivity extends Activity {

    private static final String TAG = "ApplinkActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent() != null) {

            Intent deeplinkIntent = getIntent();

            String intentSendExtra = deeplinkIntent.getStringExtra(Intent.EXTRA_TEXT);
            Uri deepLinkUri = deeplinkIntent.getData();
            Log.d(TAG, "Deeplink URI: " + deepLinkUri);

            if (null != deepLinkUri && (null != deepLinkUri.getQueryParameter("deeplink")
                            || (Uri.parse(deepLinkUri.toString().replace("#", "").toString()).getQueryParameter("rdlink")) != null)
                    || intentSendExtra != null) {
                //Us152632
                if (SessionTokenManager.getToken() != null && !SessionTokenManager.getToken().equalsIgnoreCase("")) {
                    FacadeFactory.getBankFacade().navigateToDeepLinkFromWebLink(DiscoverApplication.getGlobalContext(),deepLinkUri.getQueryParameter("deeplink"));
                }else {
                    Intent intent = new Intent(ApplinkActivity.this, LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                    intent.setData(deepLinkUri);
                    if (intentSendExtra != null) {
                        intent.putExtra(Intent.EXTRA_TEXT, intentSendExtra);
                    }
                    startActivity(intent);
                }
            } else {
                Log.d(TAG, "Navigating to Chrome");
                Intent intent = new Intent(Intent.ACTION_VIEW, deepLinkUri);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setPackage("com.android.chrome");
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException ex) {
                    Log.d(TAG, "Navigating to Amazon Cloud9");
                    // Chrome browser presumably not installed and open Kindle Browser
                    intent.setPackage("com.amazon.cloud9");
                    startActivity(intent);
                }
            }
            finish();
        }

    }
}
