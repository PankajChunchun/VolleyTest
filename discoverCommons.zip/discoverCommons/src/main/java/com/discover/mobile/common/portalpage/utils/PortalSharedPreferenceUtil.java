package com.discover.mobile.common.portalpage.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.portalpage.beans.User;
import com.discover.mobile.common.shared.utils.SecurityUtil;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 436645 on 2/1/2017.
 */
public class PortalSharedPreferenceUtil {

    private static final String PORTAL_LIST = "portal_list";
    private static final String PORTAL_LIST_KEY = "users";
    private static PortalSharedPreferenceUtil mPortalSharedPreferenceUtil;
    private final SharedPreferences mSharedPreferences;

    private PortalSharedPreferenceUtil(){

        mSharedPreferences = DiscoverApplication.getGlobalContext().getSharedPreferences(PORTAL_LIST, Context.MODE_PRIVATE);
    }

    public static PortalSharedPreferenceUtil getInstance(){

        if(mPortalSharedPreferenceUtil == null)
            mPortalSharedPreferenceUtil = new PortalSharedPreferenceUtil();

        return mPortalSharedPreferenceUtil;
    }

    public void saveOrderToUserSharedPref(){
        try {
            final SharedPreferences.Editor editor = this.mSharedPreferences.edit();
            String savedValue = this.mSharedPreferences.getString(PORTAL_LIST_KEY, "");
            String encrytedValue;
            if(savedValue.isEmpty()){
                final List<User> users = new ArrayList<>();
                users.add(User.getInstance());
                encrytedValue = SecurityUtil.encrypt(PortalUtils.convertToString(users));

            }else{
                final String decryptedValue = SecurityUtil.decrypt(savedValue);
                final List<User> list = (new Gson()).fromJson(decryptedValue, new TypeToken<List<User>>(){}.getType());
                boolean newUser = false;

                for (User user : list) {
                    final String passcode = user.getPasscodeToken();
                    final String userId = user.getUserId();
                    if ((userId != null && userId.equalsIgnoreCase(User.getInstance().getUserId())) || (passcode != null && passcode.equalsIgnoreCase(User.getInstance().getPasscodeToken()))) {
                        user.setOrder(User.getInstance().getOrder());
                        newUser = false;
                        break;
                    }else
                        newUser = true;

                }
                if(newUser)
                    list.add(User.getInstance());

                encrytedValue = SecurityUtil.encrypt(PortalUtils.convertToString(list));
            }
            editor.putString(PORTAL_LIST_KEY, encrytedValue);
            editor.commit();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveOrUpdatePasscodeToUserSharedPref(){

        final SharedPreferences.Editor editor = this.mSharedPreferences.edit();
        final String savedValue = this.mSharedPreferences.getString(PORTAL_LIST_KEY, "");
        try {
            String decryptedValue = SecurityUtil.decrypt(savedValue);
            final List<User> list = (new Gson()).fromJson(decryptedValue, new TypeToken<List<User>>(){}.getType());
            for (User user : list) {
                final String passcode = user.getPasscodeToken();
                final String userId = user.getUserId();

                if ((passcode != null  && passcode.equalsIgnoreCase(User.getInstance().getPasscodeToken()) )
                        || (userId != null && userId.equalsIgnoreCase(User.getInstance().getUserId())) ){
                    user.setPasscodeToken(User.getInstance().getPasscodeToken());
                }else {
                    user.setPasscodeToken("");
                }
            }
            final String encrytedValue = SecurityUtil.encrypt(PortalUtils.convertToString(list));
            editor.putString(PORTAL_LIST_KEY, encrytedValue);
            editor.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public User getUserFromSharedPref() {
        try {
            final String value = this.mSharedPreferences.getString(PORTAL_LIST_KEY, "");
            if (!value.isEmpty()) {

                String decryptedValue = SecurityUtil.decrypt(value);
                final List<User> list = (new Gson()).fromJson(decryptedValue, new TypeToken<List<User>>(){}.getType());

                for (User user : list) {
                    final String passcode = user.getPasscodeToken();
                    final String userId = user.getUserId();
                    if (userId != null && user.getUserId().equalsIgnoreCase(User.getInstance().getUserId())
                            ||(passcode != null && user.getPasscodeToken().equalsIgnoreCase(User.getInstance().getPasscodeToken()))) {
                        return user;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
