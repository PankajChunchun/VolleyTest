package com.discover.mobile.common.nav;

import com.discover.mobile.common.nav.section.FragmentComponentInfo;
import com.discover.mobile.common.shared.utils.CommonUtils;

import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.ListView;

import java.lang.ref.SoftReference;

import static com.discover.mobile.common.shared.ReferenceUtility.safeGetReferenced;


/**
 * Responder handles showing a {@link Fragment} when selected.
 */
final class FragmentNavigationItem extends NavigationItem {

    private final FragmentComponentInfo fragmentInfo;

    private SoftReference<Fragment> fragmentRef;

    FragmentNavigationItem(final FragmentComponentInfo fragmentInfo, final NavigationItemAdapter adapter,
                           final NavigationItemView view, final int absoluteIndex) {

        super(adapter, view, absoluteIndex);

        this.fragmentInfo = fragmentInfo;
    }

    @Override
    void onClick(final ListView listView, final View clickedView) {
        NavigationIndex.setSubIndex(absoluteIndex);
        adapter.notifyDataSetChanged();
        makeVisible();
    }

    private void makeVisible() {
        adapter.getNavigationRoot().makeFragmentVisible(getCachedOrCreateFragment());
    }

    Fragment getCachedOrCreateFragment() {
        Fragment fragment = safeGetReferenced(fragmentRef);

        if (fragment == null) {
            try {
                fragment = fragmentInfo.getFragmentClass().newInstance();
            } catch (final Exception e) {
                try {
                    throw CommonUtils.propagate(e);
                } catch (Throwable e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
            fragmentRef = new SoftReference<Fragment>(fragment);
        }

        return fragment;
    }

}
