package com.discover.mobile.common.nav;

import com.discover.mobile.common.nav.section.ComponentInfo;
import com.discover.mobile.common.nav.section.GroupComponentInfo;

import android.view.View.OnClickListener;

/**
 * Group component info that has the ability to show the message badge
 *
 * @author jthornton
 */
public abstract class BadgeGroupComponentInfo extends GroupComponentInfo {

    /** Listener to set on the badge if it has a special one */
    private OnClickListener badgeListener;

    private boolean isExpanded = false;

    /**
     * Constructor for the class
     *
     * @param titleResource - resource to set as title
     * @param subSections   - sub sections to put associate with the group
     */
    public BadgeGroupComponentInfo(final int titleResource, final ComponentInfo... subSections) {
        super(titleResource, subSections);
    }

    /**
     * Constructor for the class
     *
     * @param titleResource - resource to set as title
     * @param clickListener - listener to put on the view
     * @param subSections   - sub sections to put associate with the group
     */
    public BadgeGroupComponentInfo(final int titleResource, final OnClickListener clickListener, final ComponentInfo... subSections) {
        super(titleResource, clickListener, subSections);
    }

    /**
     * Constructor for the class
     *
     * @param titleResource - resource to set as title
     * @param clickListener - listener to put on the view
     * @param badgeListener - listener to put on the badge
     * @param subSections   - sub sections to put associate with the group
     */
    public BadgeGroupComponentInfo(final int titleResource, final OnClickListener clickListener,
                                   final OnClickListener badgeListener, final ComponentInfo... subSections) {
        super(titleResource, clickListener, subSections);
        this.badgeListener = badgeListener;
    }

    /**
     * Return true if the badge should be shown
     *
     * @return true if the badge should be shown
     */
    public abstract boolean shouldBadgeBeDisplayed();

    /**
     * Get string that should be shown in the badge
     *
     * @return string that should be shown in the badge
     */
    public abstract String getBadgeValue();

    /**
     * @return true if the badge has a special on click listener
     */
    public boolean doesSpecialOnClick() {
        return null != badgeListener;
    }

    /**
     * @return the special badge on click listener
     */
    public OnClickListener getSpecialOnClick() {
        return badgeListener;
    }

    /**
     * @return true if the badge should be shown while the group is expanded
     */
    public abstract boolean shouldShowBadgeWhileExpanded();

    /**
     * @return the isExpanded
     */
    public boolean isExpanded() {
        return isExpanded;
    }

    /**
     * @param isExpanded the isExpanded to set
     */
    public void setExpanded(final boolean isExpanded) {
        this.isExpanded = isExpanded;
    }

}
