package com.discover.mobile.common.login.service;

import com.discover.mobile.common.facade.FacadeFactory;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.highlightedfeatures.beans.HighlightedFeaturesData;
import com.discover.mobile.common.highlightedfeatures.utils.HFPref;
import com.discover.mobile.common.highlightedfeatures.utils.HFUtils;
import com.discover.mobile.common.login.beans.InfoJsonData;
import com.discover.mobile.common.login.beans.PreAuthbean;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.facade.CardShareDataStoreFacade;
import com.discover.mobile.common.shared.facade.SharedFacadeFactory;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.network.AdapterProvider;
import com.discover.mobile.network.CommonAdapterProvider;
import com.discover.mobile.network.CommonRequestInterceptor;
import com.discover.mobile.network.ServiceGenerator;
import com.discover.mobile.network.error.GenericErrorResponseParser;
import com.discover.mobile.network.error.bean.ErrorBean;
import com.discover.mobile.network.error.bean.PreAuthErrorResponseDetails;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;

import java.util.HashMap;
import java.util.Iterator;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;


/**
 * Created by 427669 on 2/5/2016.
 */
public class LoginServiceClass {

    public static final String VERSION_INFO = "VersionInfo";
    protected static final String TAG = LoginServiceClass.class.getSimpleName();
    private Context mContext = null;

    public LoginServiceClass(Context context) {
        this.mContext = context;
    }

    public void getErrorListJSON() {

        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext,
                null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        LoginServiceInterface errorJSONServiceProxy = ServiceGenerator
                .createService(LoginServiceInterface.class, adapterProvider);

        errorJSONServiceProxy.getErrorListJSON(new Callback<JsonObject>() {

            @Override
            public void success(JsonObject statusResponse, Response arg1) {
                Log.d(TAG, statusResponse.toString());
                JSONObject jObject = null;
                try {
                    jObject = new JSONObject(statusResponse.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(mContext, jObject);
            }

            @Override
            public void failure(RetrofitError retrofitError) {
                String response = CommonUtils.loadJSONFromRaw(mContext, "error.json");

                JSONObject jObject = null;
                try {
                    jObject = new JSONObject(response.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(mContext, jObject);

                Log.e(TAG,
                        "error in getErrorListJSON()",
                        retrofitError);
            }

        });
    }



    public void getInfoMessageJson(final NetworkRequestListener infoMessageListener) {
        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext,
                null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        LoginServiceInterface infoMessageServiceProxy = ServiceGenerator
                .createService(LoginServiceInterface.class,
                        adapterProvider);
        infoMessageServiceProxy.getInfoMessageJson(new Callback<JsonObject>() {

            @Override
            public void success(JsonObject infoMessageResponse, Response arg1) {
                HashMap<String, String> infoMessageHashMap = new HashMap<String, String>();
                JSONObject jObject;

                try {
                    jObject = new JSONObject(infoMessageResponse.toString());
                    Iterator<?> keys = jObject.keys();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        String value = jObject.getString(key);

                        infoMessageHashMap.put(key, value);
                    }

                    final CardShareDataStoreFacade cardShareDataStoreObj = SharedFacadeFactory.getCardShareDataStoreFacade();
                    cardShareDataStoreObj.storeToAppCache(mContext, jObject, mContext.getResources().getString(R.string.json_file_info_key));

                } catch (JSONException e) {
                    Log.d(TAG, "error in getInfoMessageJson()");
                }

                InfoMessageUtils instance = InfoMessageUtils.Instance();
                instance.setInfoMessageHashMap(infoMessageHashMap);

                //check for onboard killswitch
                try {
                    boolean wizardEnabled = Boolean.valueOf(InfoMessageUtils.Instance().getErrorMessage("shouldShowWizard"));
                    if (!wizardEnabled) {
                        Log.e("Sundeep", "Hide Wizard..hidden from infoJson");
                        new HFPref(mContext).setWizardShown(true);
                    }
                } catch (Exception e) {
                    Log.e("Sundeep", "" + e.getMessage());
                    new HFPref(mContext).setWizardShown(true);
                }

                if (!Utils.isRunningOnHandset(mContext)) {
                    String value = (infoMessageHashMap.get("isUniversalLaunched"));
                    if (null != value && value.equalsIgnoreCase("true")) {
                        InfoJsonData infoJsonData;

                        infoJsonData = (InfoJsonData) Utils.getObjectFromJSONString(infoMessageResponse.toString(), InfoJsonData.class);
                        if (null != infoJsonData) {
                            Log.d("Log", infoJsonData + "");


                            infoMessageListener.onSuccess(infoJsonData);


                        }

                    }
                }
            }

            @Override
            public void failure(RetrofitError retrofitError) {
                Log.e(TAG, "error in getInfoMessageJson()", retrofitError);

                String response = CommonUtils.loadJSONFromRaw(mContext, "infomessage.json");
                HashMap<String, String> infoMessageHashMap = new HashMap<String, String>();
                JSONObject jObject = null;
                try {
                    jObject = new JSONObject(response.toString());
                    Iterator<?> keys = jObject.keys();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        String value = jObject.getString(key);

                        infoMessageHashMap.put(key, value);
                    }
                    final CardShareDataStoreFacade cardShareDataStoreObj = SharedFacadeFactory.getCardShareDataStoreFacade();
                    cardShareDataStoreObj.storeToAppCache(mContext, jObject, mContext.getResources().getString(R.string.json_file_info_key));

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                InfoMessageUtils instance = InfoMessageUtils.Instance();
                instance.setInfoMessageHashMap(infoMessageHashMap);
            }
        });
    }

    public void startPreAuthCheck(final NetworkRequestListener preAuthListner) {
        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext,
                null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        LoginServiceInterface preAuthCheckServiceProxy = ServiceGenerator
                .createService(LoginServiceInterface.class, adapterProvider);
        preAuthCheckServiceProxy.startPreAuthCheck(new Callback<PreAuthbean>() {
            @Override
            public void success(PreAuthbean preAuthbean, Response response) {
                if (Log.isLoggable(TAG, Log.DEBUG)) {
                    Log.d(TAG, "Pre-auth status ::" + response.getStatus());
                }
                if (preAuthbean != null) {
                    PortalUtils.getVersionInfo(response.getHeaders(), mContext, preAuthbean);
                    preAuthListner.onSuccess(preAuthbean);
                }
            }

            @Override
            public void failure(RetrofitError retrofitError) {
                Log.e(TAG, "Pre auth check failure..." + retrofitError.getMessage());
                //TODO need to implement force upgrade scenarios.
                GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(
                        mContext, retrofitError, new PreAuthErrorResponseDetails());
                ErrorBean errorbean = genericErrorResponseParser
                        .handleCardErrorforResponse();
                preAuthListner.onError(errorbean);
            }
        });
    }

    /**
     * Helper function to initiate wallet eligibility call
     */
    public void  initWalletEligibilityCheckInBackground(){
        FacadeFactory.getCardFacade().initWalletEligibilityCheck();
    }


    /**
     * Get HighlightedFeature/ What's New JSON from server, on failure of
     * service it will read json from Assets directory.
     * <p/>
     * It overwrites json, stored into shared-prefs.
     */
    public void getHighlightedFeatures(final NetworkRequestListener listnr) {

        // This method is designed to call from LoginActivity, where we need not to show
        // progress dialog for this service call.

        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext,
                null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        LoginServiceInterface highLightedFeatureProxy = ServiceGenerator
                .createService(LoginServiceInterface.class, adapterProvider);

        highLightedFeatureProxy.getHighlightedFeatures(HFUtils.getFileNameOnServer(mContext),
                new Callback<HighlightedFeaturesData>() {

                    @Override
                    public void success(HighlightedFeaturesData response, Response arg1) {
                        // Store in cache
                        HFPref pref = new HFPref(mContext);
                        if(!response.version.equals(pref.getWhatsNewJsonVersion())){
                            pref.resetLoginCount();
                            pref.setWhatsNewJsonVersion(response.version);
                        }
                        pref.setJsonString(new Gson().toJson(response));
                        //HFUtils.handleServiceErrorOfHFjson(mContext);
                        // to start the highlightedfeature status check - skrish1
                        listnr.onSuccess(null);
                    }

                    @Override
                    public void failure(RetrofitError retrofitError) {
                        // Read JSON from ASSETS
                        HFUtils.handleServiceErrorOfHFjson(mContext);
                        // to start the highlightedfeature status check - skrish1
                        listnr.onSuccess(null);
                    }
                });
    }

    // backlog US57795 fix start adeshm2
    public void getRandomizationJson() {

        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext,
                null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        LoginServiceInterface randomJSONServiceProxy = ServiceGenerator
                .createService(LoginServiceInterface.class, adapterProvider);

        randomJSONServiceProxy.getRandomizationJSON(new Callback<JsonObject>() {

            @Override
            public void success(JsonObject jsonObject, Response response) {
                Log.d(TAG, response.toString());
                JSONObject jObject = null;
                try {
                    jObject = new JSONObject(jsonObject.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(mContext, jObject, "randomvalues");
            }

            @Override
            public void failure(RetrofitError retrofitError) {
                String response = CommonUtils.loadJSONFromRaw(mContext, "randomvalues.json");

                JSONObject jObject = null;
                try {
                    jObject = new JSONObject(response.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(mContext, jObject, "randomvalues");

                Log.e(TAG, "error in RandomJSON()", retrofitError);
            }
        });
    }
    // backlog US57795 fix end adeshm2


}
