package com.discover.mobile.common.shared.net;

import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class NetworkTrafficExecutorHolder {

    private static final String TAG = NetworkTrafficExecutorHolder.class.getSimpleName();

    // TODO consider externalizing if there's a good reason
    private static final int NETWORK_THREAD_COUNT = 3;

    static final ExecutorService networkTrafficExecutor = createNetworkTrafficExecutor();

    private NetworkTrafficExecutorHolder() {
        throw new UnsupportedOperationException("This class is non-instantiable");
    }

    private static ExecutorService createNetworkTrafficExecutor() {
        Log.d(TAG, "Creating networkTrafficExecutor");

        return Executors.newFixedThreadPool(NETWORK_THREAD_COUNT);
    }

}
