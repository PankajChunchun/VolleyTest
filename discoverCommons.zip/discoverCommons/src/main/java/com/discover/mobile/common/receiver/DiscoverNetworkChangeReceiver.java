package com.discover.mobile.common.receiver;

import com.discover.mobile.common.Constants;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

/**
 * Created by 465002 on 3/31/2017.
 */

public class DiscoverNetworkChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo ni = connectivityManager.getActiveNetworkInfo();
        if (ni != null && ni.isConnected()) {
            context.sendBroadcast(new Intent(Constants.ACTION_NETWORK_CHANGE));
        }
    }
}
