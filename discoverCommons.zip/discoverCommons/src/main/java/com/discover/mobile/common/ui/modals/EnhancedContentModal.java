package com.discover.mobile.common.ui.modals;

import com.discover.mobile.common.R;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.network.error.ErrorUtility;
import com.discover.mobile.network.error.bean.ErrorBean;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Parcel;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.URLSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.regex.Matcher;

/**
 * 2013 Discover Bank
 *
 * Modal dialog for showing error message
 *
 * @author CTS
 * @version 1.0
 */
public class EnhancedContentModal extends SimpleContentModal implements ErrorUtility {

    Context mContext;
    private Runnable backAction = null;
    private Runnable clickTracking = null;

    public EnhancedContentModal(final Context context, final int title,
                                final int content, final int buttonText) {
        this(context, title, content, buttonText, null, null);
        mContext = context;

    }

    public EnhancedContentModal(final Context context, final int title,
                                final int content, final int buttonText, final Runnable buttonAction) {
        this(context, title, content, buttonText, buttonAction, null);
        mContext = context;

    }

    public EnhancedContentModal(final Context context, final int title,
                                final int content, final int buttonText,
                                final Runnable buttonAction, final Runnable backButtonAction) {
        super(context);
        mContext = context;
        setTitleHtml(title);
        setContentHtml(content);
        setButtonText(buttonText);
        setOkButton(buttonAction);
        backAction = backButtonAction;

    }

    public EnhancedContentModal(final Context context, final String title, final String content, final int buttonText) {
        super(context);
        mContext = context;
        setTitle(title);
        setContentHtml(content, true);
        setButtonText(buttonText);
        setOkButton(null);
        backAction = null;
    }

    public EnhancedContentModal(final Context context, final String title, final String content, final int buttonText,
                                final Runnable buttonAction, final Runnable backButtonAction) {
        super(context);
        mContext = context;
        setTitle(title);
        setContentHtml(content, true);
        setButtonText(buttonText);
        setOkButton(buttonAction);
        backAction = backButtonAction;
    }

    public EnhancedContentModal(final Context context, final String title, final String content, final int buttonText,
                                final Runnable buttonAction, final boolean isTitleHtml, final Runnable backButtonAction) {
        super(context);
        mContext = context;
        setTitleHtml(title);
        setContentHtml(content, true);
        setButtonText(buttonText);
        setOkButton(buttonAction);
        backAction = backButtonAction;
    }

    public EnhancedContentModal(final Context context, final String title, final String content, final int buttonText,
                                final Runnable buttonAction, final Runnable backButtonAction, final boolean isAccountRegister) {
        super(context);
        mContext = context;
        setTitle(title);
        if (isAccountRegister)
            setContentHtml(content);
        else
            setContentHtml(content, true);

        setButtonText(buttonText);
        setOkButton(buttonAction);
        backAction = backButtonAction;
    }

    /**
     * Launches the android native phone dialer with a given telephone number,
     * and awaits user's action to initiate the call.
     *
     * @param number         - a String representation of a phone number to dial.
     * @param callingContext - When calling this method, pass it the context/activity that
     *                       called this method.
     */
    public final static void dialNumber(final String number,
                                        final Context callingContext) {
        if (number != null && callingContext != null) {
            final Intent dialNumber = new Intent(Intent.ACTION_DIAL);

            dialNumber.setData(Uri.parse("tel:" + number));

            callingContext.startActivity(dialNumber);
        }
        return;

    }

    public static SpannableStringBuilder addClickablePart(String str,
                                                          final Context context) {
        SpannableStringBuilder ssb = new SpannableStringBuilder(str);
        final ArrayList<String> autoDetectList = getAutoDetectList(str);
        for (int i = 0; i < autoDetectList.size(); i++)

        {
            final String word = autoDetectList.get(i);
            int idx1 = str.indexOf(word);
            int idx2 = word.length();

            ssb.setSpan(new ClickableSpan() {

                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:" + word));
                    context.startActivity(intent);
                }
            }, idx1, (idx1 + idx2), 0);
        }
        return ssb;
    }

    public static ArrayList<String> getAutoDetectList(String data) {
        ArrayList<String> autoDetectList = new ArrayList<String>();

        Log.d("**************************DATA************", data);
        String[] words = data.split("(?=[,.])|\\s+");

        if (words != null) {
            for (int i = 0; i < words.length; i++) {
                if (android.util.Patterns.PHONE.matcher(words[i]).matches()
                        || android.util.Patterns.EMAIL_ADDRESS
                        .matcher(words[i]).matches()) {
                    autoDetectList.add(words[i]);
                }
            }
        }

        return autoDetectList;
    }

    public void setClickTracking(Runnable clickTracking) {
        this.clickTracking = clickTracking;
    }

    public void setOkButton(final Runnable okAction) {
        getButton().setOnClickListener(new MyClickListener(okAction));
    }

    public void setOrangeTitle() {
        ((TextView) view.findViewById(R.id.modal_alert_title))
                .setTextColor(getContext().getResources().getColor(
                        R.color.orange));
    }

    public void setTitleHtml(final int title) {
        ((TextView) view.findViewById(R.id.modal_alert_title)).setText(Html
                .fromHtml(getContext().getResources().getString(title)));
    }

    public void setTitleHtml(final String title) {
        ((TextView) view.findViewById(R.id.modal_alert_title)).setText(Html
                .fromHtml(title));
    }

    public void setGrayButton() {
        getButton().setBackgroundColor(
                getContext().getResources()
                        .getColor(R.color.action_button_gray));
        getButton().setTextColor(
                getContext().getResources().getColor(R.color.black));
    }

    public void setContentHtml(final int content) {
        setContentHtml(getContext().getResources().getString(content), true);
    }

    public void setContentHtml(String content) {
        TextView tv = ((TextView) view.findViewById(R.id.modal_alert_text));
        tv.setText(Html.fromHtml(content));
        //US50433
//        CommonUtils.linkifyNumber(getContext(), tv, false);
        CommonUtils.handlePhoneNumberClick(getContext(),null,tv,tv.getText().toString());
    }

    public void setContentHtml(final String content, boolean stripUnderlinesBool) {

        TextView tv = (TextView) view.findViewById(R.id.modal_alert_text);
        //tv.setText(Html.fromHtml(content));

		/*
         Linkify.addLinks(tv, Linkify.WEB_URLS);
		 Linkify.addLinks(tv, Patterns.PHONE, "tel:", new Linkify.MatchFilter() {
			public final boolean acceptMatch(CharSequence s, int start, int end) {
				int digitCount = 0;

				for (int i = start; i < end; i++) {
					if (Character.isDigit(s.charAt(i))) {
						digitCount++;
						if (digitCount > 5) {
							return true;
						}
					}
				}
				return false;
			}
		}, Linkify.sPhoneNumberTransformFilter);

		/*Linkify.addLinks(tv, Linkify.PHONE_NUMBERS);
		Linkify.addLinks(tv, Linkify.WEB_URLS);*/
        // start : slende : US12001 6.2 - Golden - Discover Deals - Shop Now
        // Error Modal

        int spanStartpoint = 0;
        int spanEndPoint = 0;
        String url = "";
        String phoneNumber = "";

        String startsWithHttp = "http";
        String startsWithHttps = "https";
        String validUrlStarts = "https://";

        SpannableString spanaSpannablelearnDuration = new SpannableString(Html.fromHtml(content));
        Matcher matcher = android.util.Patterns.WEB_URL.matcher(Html.fromHtml(content));
        while (matcher.find()) {
            url = matcher.group(1);
            if ((!url.startsWith(startsWithHttp) || !url.startsWith(startsWithHttps))) {
                url = validUrlStarts + url;
            }
            spanStartpoint = matcher.start();
            spanEndPoint = matcher.end();
            spanaSpannablelearnDuration.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.blue_link)), spanStartpoint, spanEndPoint, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spanaSpannablelearnDuration.setSpan(new onClickOpenBrowser(url), spanStartpoint, spanEndPoint, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        if (CommonUtils.isRunningOnHandset(mContext)) {
            matcher = android.util.Patterns.PHONE.matcher(Html.fromHtml(content));
            while (matcher.find()) {
                phoneNumber = matcher.group(1);
                spanStartpoint = matcher.start();
                spanEndPoint = matcher.end();
                if (null == phoneNumber) {
                    phoneNumber = content.substring(spanStartpoint, spanEndPoint);
                }
                spanaSpannablelearnDuration.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.blue_link)), spanStartpoint, spanEndPoint, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                spanaSpannablelearnDuration.setSpan(new onClickOpenDialer(phoneNumber), spanStartpoint, spanEndPoint, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

        tv.setText(spanaSpannablelearnDuration);
        tv.setMovementMethod(LinkMovementMethod.getInstance());

		/*if (stripUnderlinesBool)
			stripUnderlines(tv);*/
    }

    public void setContentHtmlInWebview(final String content) {
        TextView tv = (TextView) view.findViewById(R.id.modal_alert_text);
        tv.setVisibility(View.GONE);
        WebView webView = (WebView) view
                .findViewById(R.id.modal_alert_text_webview);
        webView.setVisibility(View.VISIBLE);
        webView.loadDataWithBaseURL(null, content, "text/html", "utf-8", null);
    }

    public void setContentHtmlInWebviewWithContentDescription(
            final String content, final String contentDescription) {
        TextView tv = (TextView) view.findViewById(R.id.modal_alert_text);
        tv.setVisibility(View.GONE);
        WebView webView = (WebView) view
                .findViewById(R.id.modal_alert_text_webview);
        webView.setVisibility(View.VISIBLE);
        webView.setFocusable(true);
        webView.setClickable(true);
        webView.setContentDescription(contentDescription);
        webView.loadDataWithBaseURL(null, content, "text/html", "utf-8", null);
    }

    /**
     * Loads the given URL.
     *
     * @param url          Url to load
     * @param localContent Fallback local string HTML content to be loaded
     */
    public void setContentHtmlInWebview(final String url,
                                        final String localContent) {
        TextView tv = (TextView) view.findViewById(R.id.modal_alert_text);
        tv.setVisibility(View.GONE);
        final WebView webView = (WebView) view
                .findViewById(R.id.modal_alert_text_webview);
        webView.setVisibility(View.VISIBLE);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode,
                                        String description, String failingUrl) {
                webView.loadDataWithBaseURL(null, localContent, "text/html",
                        "utf-8", null);
            }

            @Override
            public void onReceivedSslError(WebView view,
                                           SslErrorHandler handler, SslError error) {
                handler.proceed();
            }

        });
        if (url != null) {
            webView.loadUrl(url);
        } else {
            webView.loadDataWithBaseURL(null, localContent, "text/html",
                    "utf-8", null);
        }
    }

    /**
     * Loads the given URL.
     *
     * @param url          Url to load
     * @param localContent Fallback local string HTML content to be loaded
     */
    @SuppressLint("SetJavaScriptEnabled")
    public void setContentHtmlInWebviewWithPhoneNumber(final String url,
                                                       final String localContent, final Context context) {
        TextView tv = (TextView) view.findViewById(R.id.modal_alert_text);
        tv.setVisibility(View.GONE);
        final WebView webView = (WebView) view
                .findViewById(R.id.modal_alert_text_webview);
        webView.setVisibility(View.VISIBLE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
                                     @Override
                                     public void onReceivedError(WebView view, int errorCode,
                                                                 String description, String failingUrl) {
                                         webView.loadDataWithBaseURL(null, localContent, "text/html",
                                                 "utf-8", null);
                                     }

                                     @Override
                                     public boolean shouldOverrideUrlLoading(WebView wv, String url) {
                                         if (url.startsWith(WebView.SCHEME_TEL)) {
                                             Intent intent = new Intent(Intent.ACTION_DIAL);
                                             intent.setData(Uri.parse(url));
                                             context.startActivity(intent);
                                             return true;
                                         }
                                         return false;
                                     }
                                 }

        );
        if (url != null) {
            webView.loadUrl(url);
        } else {
            webView.loadDataWithBaseURL(null, localContent, "text/html",
                    "utf-8", null);
        }
    }

    public void setErrorIconVisibility(boolean isVisible) {
        if (isVisible)
            view.findViewById(R.id.error_icon).setVisibility(View.VISIBLE);
        else
            view.findViewById(R.id.error_icon).setVisibility(View.GONE);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (backAction != null) {
            backAction.run();
        }
    }

    public void setEditContentHtml(final String content) {

        TextView tv = (TextView) view.findViewById(R.id.modal_alert_text);
        tv.setText(Html.fromHtml(content));

    }

    @Override
    public String getMessageforErrorCode(Context context,
                                         String httpAndErrorStatus) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTitleforErrorCode(Context context,
                                       String httpAndErrorStatus) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getHttpAndErrorStatus(ErrorBean errorBean) {
        // TODO Auto-generated method stub
        return null;
    }

    class onClickOpenBrowser extends ClickableSpan {
        String url = "";

        public onClickOpenBrowser(String url) {
            this.url = url;
        }

        public void onClick(View tv) {
            final Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            mContext.startActivity(i);
        }

        public void updateDrawState(TextPaint ds) {// override updateDrawState
            ds.setUnderlineText(false); // set to false to remove underline
        }
    }

    class onClickOpenDialer extends ClickableSpan {
        String phoneNumber = "";

        public onClickOpenDialer(String number) {
            this.phoneNumber = number;
        }

        public void onClick(View tv) {
            dialNumber(phoneNumber, mContext);
        }

        public void updateDrawState(TextPaint ds) {// override updateDrawState
            ds.setUnderlineText(false); // set to false to remove underline
        }
    }

    public class NoUnderlineSpan extends UnderlineSpan {
        public NoUnderlineSpan() {
        }

        public NoUnderlineSpan(Parcel src) {
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            ds.setUnderlineText(false);
        }
    }

    private class URLSpanNoUnderlineWithLinkTracking extends URLSpan {
        public URLSpanNoUnderlineWithLinkTracking(final String url) {
            super(url);
        }

        @Override
        public void updateDrawState(final TextPaint ds) {
            super.updateDrawState(ds);
            ds.setUnderlineText(false);
        }

        public void onClick(View tv) {
            super.onClick(tv);
            if (clickTracking != null) {
                clickTracking.run();
            }
        }
    }

    // regular button
    private class MyClickListener implements View.OnClickListener {

        private Runnable action;

        public MyClickListener(final Runnable action) {
            this.action = action;
        }

        public Runnable getAction() {
            return action;
        }

        @Override
        public void onClick(final View v) {
            if (getAction() != null) {
                getAction().run();
            }
            dismiss();
        }
    }

}
