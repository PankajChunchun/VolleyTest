package com.discover.mobile.common.fico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.discover.mobile.common.R;
import com.discover.mobile.common.fico.bean.FicoCollapsedDetails;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.fico.views.FicoBoxView;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;
import com.discover.mobile.common.portalpage.view.PortalAccountBox;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by 451769 on 5/3/2017.
 * Adapter Class for the Fico Dashboard boxes listview.
 */

public class FicoBoxAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private Context mContext;
    ArrayList<FicoCollapsedDetails> ficoCollapsedDetails;
    private FicoUtils.FicoBoxType ficoBoxType = FicoUtils.FicoBoxType.NONE;
    private static final String FICO_BOX_ROW_PREFIX = "fico_page_row_";
    private boolean isExpandDisabled;

    public FicoBoxAdapter(Context context, ArrayList<FicoCollapsedDetails> ficoCollapsedDetails, FicoUtils.FicoBoxType ficoBoxType,boolean isExpandDisabled) {
        mContext = context;
        this.ficoBoxType = ficoBoxType;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.ficoCollapsedDetails = ficoCollapsedDetails;
        this.isExpandDisabled = isExpandDisabled;

    }

    @Override
    public int getViewTypeCount() {
        return ficoCollapsedDetails.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public int getCount() {
        return ficoCollapsedDetails.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = new FicoBoxView(mContext, position);
            if (ficoBoxType != null) {
                switch (ficoBoxType) {
                    case ACCOUNT_DETAILS_BOX_COLLAPSED:
                        ((FicoBoxView) convertView).mapViewWithData(FicoUtils.FicoBoxType.ACCOUNT_DETAILS_BOX_COLLAPSED, position, ficoCollapsedDetails,isExpandDisabled);
                        break;
                }
            }
            RelativeLayout collapseParentView = (RelativeLayout) convertView.findViewById(R.id.collapse_parent_layout);
            FicoUtils.setPaddingForTabletPort(collapseParentView, mContext, 24);
            convertView.setTag(FICO_BOX_ROW_PREFIX + position);
        }

        return convertView;
    }
}





