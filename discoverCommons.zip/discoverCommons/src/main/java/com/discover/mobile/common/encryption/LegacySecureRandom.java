package com.discover.mobile.common.encryption;

import java.security.Provider;
import java.security.SecureRandom;
import java.security.SecureRandomSpi;

/**
 * This class allows Constructor for SecureRandom to be accessible since the Crypto Provider was
 * removed
 * in Android N. This is a temporary fix until we migrate to a newer implementation
 *
 * Created by gherrma on 6/10/2016.
 */
@Deprecated
public class LegacySecureRandom extends SecureRandom {

    public LegacySecureRandom(SecureRandomSpi secureRandomSpi, Provider provider) {
        super(secureRandomSpi, provider);
    }

}
