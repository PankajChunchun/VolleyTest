/**
 *
 */
package com.discover.mobile.common.nav;

import android.view.View.OnClickListener;

/**
 * @author 328073
 */
public class OverFlowBeans {
    private String nameOfMenu;
    private OnClickListener clickListener;

    public String getNameOfMenu() {
        return nameOfMenu;
    }

    public void setNameOfMenu(String nameOfMenu) {
        this.nameOfMenu = nameOfMenu;
    }

    public OnClickListener getClickListener() {
        return clickListener;
    }

    public void setClickListener(OnClickListener clickListener) {
        this.clickListener = clickListener;
    }
}
