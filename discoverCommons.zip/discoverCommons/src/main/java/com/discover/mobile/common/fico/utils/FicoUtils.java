package com.discover.mobile.common.fico.utils;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.fico.bean.CmnFicoListHeaderBean;
import com.discover.mobile.common.fico.bean.CmnFicoListItemBean;
import com.discover.mobile.common.fico.bean.FicoCollapsedDetails;
import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.bean.FicoScoreList;
import com.discover.mobile.common.fico.bean.NegativeKeyFactor;
import com.discover.mobile.common.fico.bean.PositiveKeyFactor;
import com.discover.mobile.common.fico.interfaces.CmnFicoListItemInterface;
import com.discover.mobile.common.portalpage.utils.PortalUtils;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.TextPaint;
import android.text.style.URLSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import static android.content.Context.ACCESSIBILITY_SERVICE;
import static android.view.View.MeasureSpec;

/**
 * Created by 451769 on 5/8/2017.
 */

public class FicoUtils {

    public static String deepLinkFicoFaqActionCode = "linktoficofaq";
    public static String deepLinkNoScoreFicoFaqActionCode = "linktonoscoreficofaq";
    public static String EXCEPTIONAL_RATING = "Exceptional";
    public static String VERY_GOOD_RATING = "Very Good";
    public static String GOOD_RATING = "Good";
    public static String FAIR_RATING = "Fair";
    public static String POOR_RATING = "Poor";
    public static final int SHOWOLDFICO = 0;
    public static final int SHOW_FICO_SCORECARD = 1;
    public static final int SHOWNOFICO = 2;
    public static final String OLD_FICO_KILL_SWITCH_CONSTANT = "FICO";
    public static final String NEW_FICO_KILL_SWITCH_CONSTANT = "FICO_SCORECARD";
    public static final int NEW_FICO_SCORECARD_TITLEINDEX = 31;
    public static final int NEW_FICO_NOSCORECARD_TITLEINDEX= 32;
    public static final int OLD_FICO_TITLEINDEX = 6;

    public static final int TOTAL_ACCOUNT = 0;
    public static final int LENGH_OF_CREDIT = 1;
    public static final int INQUIRES = 2;
    public static final int REVOLVING_UTILIZATION = 3;
    public static final int MISSED_PAYMENT = 4;
    public static boolean isTalkBackEnabledCalled = false;



    public enum FicoBoxType {
        NONE,
        SCORE_BOX,
        ACCOUNT_DETAILS_BOX_COLLAPSED,
        ACCOUNT_DETAILS_BOX_EXPANDED,
        BOTTOM_VIEW
    }

    /*method to round off length of credit in months and year on header textview*/
    public static String getLengthOfCredit(int iMonths, Context context) {
        String lengthOfCredit;
        if (iMonths < 12) {
            lengthOfCredit = iMonths +" "+context.getResources().getString(R.string.fico_month_header);
            if (iMonths > 1) {
                lengthOfCredit += context.getResources().getString(R.string.month_year_plural);
            }
        } else {
            int iYears = (iMonths / 12);
            lengthOfCredit = iYears +" " +context.getResources().getString(R.string.fico_year_header);
            if (iYears>1)
                lengthOfCredit += context.getResources().getString(R.string.month_year_plural);
        }
        return lengthOfCredit;
    }


    // method to round off length of credit in months and years
    public static String getLengthOfCreditInMonthsYears(int n) {
        String monthText = null;
        int years, months;
        years = n / 12;
        months = n % 12;
        if(months==1){
            monthText = " month";
        }else{
            monthText = " months";
        }
        if (n % 12 == 0) {
            if (years == 1) {
                return years + " year";
            } else {
                return years + " years";
            }
        } else if (years == 0) {
                return months + monthText;
        } else {
            if (years == 1) {
                return years + " year, " + months + monthText;
            } else {
                return years + " years, " + months + monthText;
            }
        }
    }

    public static String getFormattedAmount(String amountToFormat) {
        String formattedString = null;
        if (amountToFormat != null) {
            double amount = Double.parseDouble(amountToFormat);
            DecimalFormat formatter = new DecimalFormat("#,###,###");
            formattedString = formatter.format(amount);
        }
        return formattedString;
    }

    /**
     * This method is to scroll  list view item to top position
     *
     * @param view
     * @param position
     */
    public static void smoothScrollToPositionFromTop(final AbsListView view, final int position, final Context context) {
        final int EXPANDING_TIME = 300;
        final int OFFSET_EXPAND_BOX = 100;
        View child = getChildAtPosition(view, position);


        view.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(final AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE) {
                    view.setOnScrollListener(null);

                }
            }

            @Override
            public void onScroll(final AbsListView view, final int firstVisibleItem, final int visibleItemCount,
                                 final int totalItemCount) {
            }
        });

        new Handler().post(new Runnable() {
            @Override
            public void run() {
                int orientation = context.getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    view.smoothScrollToPositionFromTop(position, 0, EXPANDING_TIME);
                } else {
                    view.smoothScrollToPositionFromTop(position, OFFSET_EXPAND_BOX, EXPANDING_TIME);
                }
            }
        });

    }

    public static View getChildAtPosition(final AdapterView view, final int position) {
        final int index = position - view.getFirstVisiblePosition();
        if ((index >= 0) && (index < view.getChildCount())) {
            return view.getChildAt(index);
        } else {
            return null;
        }
    }

    /**
     * This method animates the horizontal color view
     *
     * @param horizontalView
     * @return
     */
    public static Animation inFromLeftAnimation(final View horizontalView) {
        Animation inFromLeft = new TranslateAnimation(
                Animation.RELATIVE_TO_PARENT, -1.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f);
        inFromLeft.setDuration(200);
        inFromLeft.setInterpolator(new AccelerateInterpolator());
        inFromLeft.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                horizontalView.clearAnimation();
                horizontalView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        return inFromLeft;
    }

    /**
     * This method animate the color views
     *
     * @param verticalColorView
     * @param height
     * @param horizontalColorView
     * @param ficoScoreListView
     * @param position
     */
    public static void animateColorViews(final View verticalColorView, final int height, final View horizontalColorView, final AbsListView ficoScoreListView, final int position, Context context) {
        final int initialHeight = height;
        Animation inFromBottom = new TranslateAnimation(
                Animation.RELATIVE_TO_PARENT, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f,
                Animation.RELATIVE_TO_PARENT, 0.0f,
                Animation.RELATIVE_TO_PARENT, -1.0f);

        FicoUtils.smoothScrollToPositionFromTop(ficoScoreListView, position, context);
        inFromBottom.setDuration(100);
        inFromBottom.setInterpolator(new AccelerateInterpolator());
        verticalColorView.startAnimation(inFromBottom);
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                verticalColorView.setVisibility(View.GONE);
                verticalColorView.clearAnimation();
                horizontalColorView.startAnimation(inFromLeftAnimation(horizontalColorView));
            }
        }, 100);
    }


    /**
     * This Method return date in MMM DD, yyyy format
     *
     * @param oldDate
     * @return
     */
    public static String getFicoScoreDateFormat(String oldDate) {
        String newDate = "";
        if (!PortalUtils.isStrFieldEmpty(oldDate)) {
            SimpleDateFormat inDateFormater = new SimpleDateFormat("MM/dd/yyyy");
            Date inFormattedDate = null;
            try {
                inFormattedDate = inDateFormater.parse(oldDate.trim());
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
                newDate = sdf.format(inFormattedDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return newDate != null ? newDate : oldDate;
    }


    /**
     * This Method return dp value in pixel value
     *
     * @param dp
     * @param context
     * @return
     */
    public static int dpToPx(int dp, Context context) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    /**
     * This method set padding for Tablet Potrait View
     *
     * @param view
     * @param context
     * @param dp
     */
    public static void setPaddingForTabletPort(View view, Context context, int dp) {
        int orientation = context.getResources().getConfiguration().orientation;
        if (!com.discover.mobile.common.Utils.isRunningOnHandset(context)) {
            if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                view.setPadding(FicoUtils.dpToPx(dp, context), 0, FicoUtils.dpToPx(dp, context), 0);
            }
        }
    }

    /**
     * This Method return date in MMM, yyyy format
     */
    public static String getFicoScoreDateForGraph(String inDateStr) {
        String finalString = null;

        if (!PortalUtils.isStrFieldEmpty(inDateStr)) {

            SimpleDateFormat inDateFormater = new SimpleDateFormat("MM/dd/yyyy");
            Date inFormattedDate = null;
            try {
                inFormattedDate = inDateFormater.parse(inDateStr);
                SimpleDateFormat sdf = new SimpleDateFormat("MMM, yyyy");
                finalString = sdf.format(inFormattedDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return finalString != null ? finalString : inDateStr;
    }


    /**
     * It loop through FICO service list and get data in format to map to FICO graph
     */
    public static String[][] getGraphData(FicoCreditScore ficoCreditScore) {

        String[][] array = null;

        if (null != ficoCreditScore && null != ficoCreditScore.getFicoScoreList()) {

            int scoreListSizeInt = ficoCreditScore.getFicoScoreList().size();
            array = new String[scoreListSizeInt][4];
            int count = 0;
            String scoreDate;

            for (int i = 0; i < scoreListSizeInt; i++) {

                if (ficoCreditScore.getFicoScoreList().get(i) != null) {

                    array[count][0] = FicoUtils.getFicoScoreDateForGraph(ficoCreditScore.getFicoScoreList().get(i)
                            .getScoreDate()); // Formatted Date
                  /*  array[count][0] = ficoCreditScore.getFicoScoreList().get(i)
                            .getDisplayKeyString();*/

                    if (ficoCreditScore.getFicoScoreList().get(i).isHasScore()) {
                        array[count][1] = Integer.toString((ficoCreditScore
                                .getFicoScoreList().get(i).getCurrentScore()));
                        array[count][2] = ficoCreditScore.getFicoScoreList().get(i)
                                .getScoreDate(); // In original form
                        array[count][3] = FicoUtils.getFicoScoreRangeValue(ficoCreditScore
                                .getFicoScoreList().get(i).getCurrentScore());
                    } else {
                        array[count][1] = "";
                        array[count][2] = "";
                        array[count][3] = "";
                    }
                }
                count++;
            }
        }

        return array;
    }

    /**Start changes for US117369*/
    /**
     * This method return previous month of current month
     *
     * @param currentMonth
     * @return
     */
    public static String getPreviousMonthFromCurrentMonth(String currentMonth) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yyyy", Locale.getDefault());
        Date date = null;
        try {
            date = dateFormat.parse(currentMonth);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        if (date != null) {
            calendar.setTime(date);
        }
        calendar.add(Calendar.MONTH, -1);
        String previousMonthDate = dateFormat.format(calendar.getTime());
        return previousMonthDate;
    }

    /**
     * This method return month and year value by splitting current date
     *
     * @param mDate
     * @return
     */
    public static String getFicoMonthValue(String mDate) {
        String[] dateArr = mDate.split("/");
        String month = dateArr[0];
        String date = dateArr[1];
        String year = dateArr[2];
        return month + "/" + year;
    }

    /**
     * This method return diffrence between two Fico Score
     *
     * @param currentScore
     * @param previousScore
     * @return
     */
    public static String getFicoScoreDiff(int currentScore, int previousScore) {
        int scoreDiff = 0;
        scoreDiff = currentScore - previousScore;
        return String.valueOf(Math.abs(scoreDiff));
    }

    /**
     * This method return Range Value as per Current Score
     *
     * @param currentScore
     * @return
     */
    public static String getFicoScoreRangeValue(int currentScore) {
        String rangeValue = "";
        if (currentScore >= 800) {
            rangeValue = EXCEPTIONAL_RATING;
        } else if (currentScore >= 740) {
            rangeValue = VERY_GOOD_RATING;
        } else if (currentScore >= 670) {
            rangeValue = GOOD_RATING;
        } else if (currentScore >= 580) {
            rangeValue = FAIR_RATING;
        } else if (currentScore < 580) {
            rangeValue = POOR_RATING;
        }
        return rangeValue;
    }

    /**
     * This method return color code as per current score value
     *
     * @param currentScore
     * @return
     */
    public static int getColorCodeFromScoreValue(int currentScore) {
        int colorCode = R.color.white;
        if (currentScore >= 670) {
            return R.color.cmn_fico_score_green_color;
        } else if (currentScore >= 580) {
            return R.color.cmn_fico_score_yellow_color;
        } else if (currentScore >= 300) {
            return R.color.cmn_fico_score_red_color;
        }
        return colorCode;
    }

    /**End changes for US117369*/

    /**
     * Get rating based on credit score
     */
    public static CreditScoreStrengths getScoreStrength(int currentScoreInt) {
        CreditScoreStrengths retSrengths = null;
        if (currentScoreInt >= 800) {
            retSrengths = CreditScoreStrengths.EXCEPTIONAL_RATING;
        } else if (currentScoreInt >= 740) {
            retSrengths = CreditScoreStrengths.VERY_GOOD_RATING;
        } else if (currentScoreInt >= 670) {
            retSrengths = CreditScoreStrengths.GOOD_RATING;
        } else if (currentScoreInt >= 580) {
            retSrengths = CreditScoreStrengths.FAIR_RATING;
        } else if (currentScoreInt < 580) {
            retSrengths = CreditScoreStrengths.POOR_RATING;
        }
        return retSrengths;
    }

    private static class URLSpanNoUnderline extends URLSpan {
        public URLSpanNoUnderline(String url) {
            super(url);
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            super.updateDrawState(ds);
            ds.setUnderlineText(false);
        }
    }

    public static void removeUnderlines(TextView textView) {
        // #9690 -  FICO_App is crashing on tapping of Credit Scorecard in LHN
        // for unconditioned fico data in Handset (OS Version- 6 and below)
        if (!(textView.getText() instanceof Spannable)) {
            return;
        }
        Spannable s = (Spannable) textView.getText();
        URLSpan[] spans = s.getSpans(0, s.length(), URLSpan.class);
        for (URLSpan span : spans) {
            int start = s.getSpanStart(span);
            int end = s.getSpanEnd(span);
            s.removeSpan(span);
            span = new URLSpanNoUnderline(span.getURL());
            s.setSpan(span, start, end, 0);
        }
        textView.setText(s);
    }

    public static int FICO_LIST_SIZE_LIMIT = 6;

    public static LinkedHashMap<String, ArrayList<CmnFicoListItemInterface>> getFicoListMap(FicoCreditScore ficoCreditScore, Context mContext) {

        LinkedHashMap<String, ArrayList<CmnFicoListItemInterface>> ficoScoresMap = new LinkedHashMap<>();

        if (null != ficoCreditScore && null != ficoCreditScore.getFicoScoreList() && null != mContext) {

            String FICO_LIST_KEY = mContext.getResources().getString(R.string.cmn_fico_collection_list_key);

            List<FicoScoreList> ficoScoreList = new ArrayList<>(ficoCreditScore.getFicoScoreList());
            Collections.reverse(ficoScoreList);

            int listItemCounter = 0;
            int listKeyCounter = 0;
            ArrayList<CmnFicoListItemInterface> ficoList = new ArrayList<>();
            CmnFicoListHeaderBean ficoListHeaderBean;
            CmnFicoListItemBean ficoListItemBean;

            for (FicoScoreList listItem : ficoScoreList) {

                //Add Header for list of FICO_LIST_SIZE_LIMIT (6) items
                if (listItemCounter == 0) {
                    ficoListHeaderBean = new CmnFicoListHeaderBean();
                    ficoListHeaderBean.setColumn1Title(mContext.getResources().getString(R.string.cmn_fico_list_header_date));
                    ficoListHeaderBean.setColumn2Title(mContext.getResources().getString(R.string.cmn_fico_list_header_score));
                    ficoListHeaderBean.setColumn3Title(mContext.getResources().getString(R.string.cmn_fico_list_header_rating));
                    ficoList.add(ficoListHeaderBean);
                }

                ficoListItemBean = new CmnFicoListItemBean();
                ficoListItemBean.setFicoScore(listItem.getCurrentScore());
                ficoListItemBean.setFicoScoreDate(listItem.getScoreDate());
                ficoListItemBean.setHasScore(listItem.isHasScore());
                ficoListItemBean.setFicoScoreListItem(listItem);
                ficoList.add(ficoListItemBean);

                listItemCounter++;

                if (listItemCounter == FICO_LIST_SIZE_LIMIT) {
                    listKeyCounter++;
                    ficoScoresMap.put(FICO_LIST_KEY + listKeyCounter, new ArrayList<>(ficoList));
                    ficoList.clear();
                    listItemCounter = 0;
                }
            }
        }

        return ficoScoresMap;
    }

    public static int showOldOrNewFico() {
        return PortalUtils.checkforFicoKillSwitch();
    }

    /**
     * It calculates list item size & sets to list
     */
    public static void setListViewSize(ListView myListView) {

        ListAdapter listAdapter = myListView.getAdapter();
        if (listAdapter == null) {
            //do nothing return null
            return;
        }

        /**set listAdapter in loop for getting final size*/
        int totalHeight = 0;
        for (int size = 0; size < listAdapter.getCount(); size++) {
            View listItem = listAdapter.getView(size, null, myListView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        /**setting list-view item in adapter*/
        ViewGroup.LayoutParams params = myListView.getLayoutParams();
        params.height = totalHeight + (myListView.getDividerHeight() * (listAdapter.getCount() - 1));
        myListView.setLayoutParams(params);
    }

    /**
     * It returns the height of all Group Views from ExpandableListView
     */
    public static int getExpandableListGroupViewsHeight(ExpandableListView expandableListView) {

        int totalHeight = 0;

        if (null != expandableListView) {

            BaseExpandableListAdapter adapter = (BaseExpandableListAdapter) expandableListView.getExpandableListAdapter();
            if (adapter == null) {
                return totalHeight;
            }

            /**start Defect fixes 14532, 15256 */
            //Width is necessary to pass to calculate height of view based on their content
            int desiredWidth = MeasureSpec.makeMeasureSpec(expandableListView.getWidth(), MeasureSpec.AT_MOST);

            totalHeight = expandableListView.getPaddingTop() + expandableListView.getPaddingBottom();

            for (int i = 0; i < adapter.getGroupCount(); i++) {
                /**Calculate height of Group View */
                View groupItem = adapter.getGroupView(i, false, null, expandableListView);
                if (null != groupItem) {
                    groupItem.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT));
                    groupItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
                    totalHeight += groupItem.getMeasuredHeight();
                }
            }
            /**end Defect fixes 14532, 15256 */
        }

        return totalHeight;
    }

    /**
     * Method to return height of expanded groups child
     */
    public static int getExpandableListChildViewsHeight(ExpandableListView expandableListView, int expandedGroupIndex) {
        int totalHeight = 0;

        if (null != expandableListView) {

            BaseExpandableListAdapter adapter = (BaseExpandableListAdapter) expandableListView.getExpandableListAdapter();
            if (adapter == null) {
                return totalHeight;
            }

            //Width is necessary to pass to calculate height of view based on their content
            int desiredWidth = MeasureSpec.makeMeasureSpec(expandableListView.getWidth(), MeasureSpec.AT_MOST);

            /**Calculate height of Child's View */
            if (expandableListView.isGroupExpanded(expandedGroupIndex)) {
                for (int childIndex = 0; childIndex < adapter.getChildrenCount(expandedGroupIndex); childIndex++) {
                    View listItem = adapter.getChildView(expandedGroupIndex, childIndex, false, null, expandableListView);
                    if (null != listItem) {
                        // This next line is needed before you call measure or else you won't get measured height at all. The listItem needs to be drawn first to know the height.
                        listItem.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT));
                        listItem.measure(desiredWidth, MeasureSpec.UNSPECIFIED);
                        totalHeight += listItem.getMeasuredHeight();
                    }
                }
            }
        }
        return totalHeight;
    }

    /**
     * It sets height of ExpandableListView
     */
    public static void setExpandableListViewHeight(ExpandableListView expandableListView, int resizedHeight) {
        if (null != expandableListView) {
            BaseExpandableListAdapter adapter = (BaseExpandableListAdapter) expandableListView.getExpandableListAdapter();
            if (adapter == null) {
                return;
            }

            ViewGroup.LayoutParams params = expandableListView.getLayoutParams();
            int height = resizedHeight + expandableListView.getDividerHeight() * (adapter.getGroupCount() - 1);
            params.height = height;
            expandableListView.setLayoutParams(params);
            expandableListView.requestLayout();
        }
    }

    /**
     * Method to return size of positive & negative key-factors depending on scredit score
     */
    public static ArrayList<Integer> getKeyFactorsSizeLimit(FicoScoreList ficoScoreListItem, int creditScoreInt) {
        ArrayList<Integer> keyFactorsSizeList = null;
        if (null != ficoScoreListItem) {
            CreditScoreStrengths strengthType = FicoUtils.getScoreStrength(creditScoreInt);
            if (null == strengthType) {
                return keyFactorsSizeList;
            }
            keyFactorsSizeList = new ArrayList<>();
            switch (strengthType) {

                case EXCEPTIONAL_RATING:
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.POSITIVE_KEY_INDEX, 2);
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.NAGATIVE_KEY_INDEX, 0);
                    break;

                case VERY_GOOD_RATING:
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.POSITIVE_KEY_INDEX, 2);
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.NAGATIVE_KEY_INDEX, 1);
                    break;

                case GOOD_RATING:
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.POSITIVE_KEY_INDEX, 1);
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.NAGATIVE_KEY_INDEX, 1);
                    break;

                case FAIR_RATING:
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.POSITIVE_KEY_INDEX, 1);
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.NAGATIVE_KEY_INDEX, 2);
                    break;

                case POOR_RATING:
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.POSITIVE_KEY_INDEX, 0);
                    keyFactorsSizeList.add(FicoCreditScoreConstants.FicoKeyfactors.NAGATIVE_KEY_INDEX, 2);
                    break;

                default:
                    break;
            }
        }
        return keyFactorsSizeList;
    }

    /**
     * Method ot return postive key-factors list
     */
    public static List<PositiveKeyFactor> getPositiveKeyFactorsList(FicoScoreList ficoScoreListItem, int listSize) {
        List<PositiveKeyFactor> positiveKeyFactorsList = null;

        if (null != ficoScoreListItem && null != ficoScoreListItem.getPositiveKeyFactors()) {

            positiveKeyFactorsList = new ArrayList<>();
            for (PositiveKeyFactor positiveKeyFactor : ficoScoreListItem.getPositiveKeyFactors()) {
                if (positiveKeyFactorsList.size() < listSize) {
                    positiveKeyFactorsList.add(positiveKeyFactor);
                } else {
                    break;
                }

            }
        }
        return positiveKeyFactorsList;
    }

    /**
     * Method ot return negative key-factors list
     */
    public static List<NegativeKeyFactor> getNegativeKeyFactorsList(FicoScoreList ficoScoreListItem, int listSize) {
        List<NegativeKeyFactor> negativeKeyFactorsList = null;

        if (null != ficoScoreListItem && null != ficoScoreListItem.getNegativeKeyFactors()) {

            negativeKeyFactorsList = new ArrayList<>();
            for (NegativeKeyFactor negativeKeyFactor : ficoScoreListItem.getNegativeKeyFactors()) {
                if (negativeKeyFactorsList.size() < listSize) {
                    negativeKeyFactorsList.add(negativeKeyFactor);
                } else {
                    break;
                }

            }
        }
        return negativeKeyFactorsList;
    }

    /**
     * Method to select FICOScoreList Item based on ScoreDate comparison
     */
    public static FicoScoreList getFicoScoreListItem(List<FicoScoreList> ficoScoreList, String scoreDate) {
        FicoScoreList retFicoScoreList = null;

        if (null != ficoScoreList && !PortalUtils.isStrFieldEmpty(scoreDate)) {
            scoreDate = scoreDate.trim();
            String listItemScoreDate;
            for (FicoScoreList listItem : ficoScoreList) {
                listItemScoreDate = listItem.getScoreDate();
                if (!PortalUtils.isStrFieldEmpty(listItemScoreDate)) {
                    listItemScoreDate = listItemScoreDate.trim();
                    if (listItemScoreDate.equalsIgnoreCase(scoreDate)) {
                        retFicoScoreList = listItem;
                        break;
                    }
                }
            }
        }

        return retFicoScoreList;
    }

    /**
     * Method to get color background to view for collapsed & expanded view based category rating
     * code value
     */
    public static int getColorBasedOnRatingCode(String ratingCodeStr, Context mContext) {

        int ratingCode = 0;
        int colorValueInt = 0;

        if (!PortalUtils.isStrFieldEmpty(ratingCodeStr)) {
            ratingCode = Integer.parseInt(ratingCodeStr);
        }

        if (null != mContext) {

            switch (ratingCode) {
                case 1:
                    colorValueInt = ContextCompat.getColor(mContext, R.color.cmn_fico_score_red_color);
                    break;

                case 2:
                    colorValueInt = ContextCompat.getColor(mContext, R.color.cmn_fico_score_yellow_color);
                    break;

                case 3:
                    colorValueInt = ContextCompat.getColor(mContext, R.color.cmn_fico_score_green_color);
                    break;

                case 4:
                    colorValueInt = ContextCompat.getColor(mContext, R.color.cmn_fico_score_green_color);
                    break;

                case 5:
                    colorValueInt = ContextCompat.getColor(mContext, R.color.cmn_fico_score_green_color);
                    break;

                default:
                    colorValueInt = ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color);
                    break;
            }
        }

        return colorValueInt;
    }

    /*Start Changes for US121913*/
    public static void trackFicoCreditScorPage(Context mContext, String ratingValue, String previousScoreChange, ArrayList<String> helpingHurtigList, boolean is90DaysFlag) {
        HashMap<String, Object> extras = new HashMap<String, Object>();
        extras.put(mContext.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_RATING + ratingValue);
        extras.put(mContext.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_RATING + ratingValue);
        if (!is90DaysFlag) {
            extras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_RATING + previousScoreChange + AnalyticsPage.FICO_CREDITSCORE_WITH_GAP);
        } else {
            extras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_RATING + previousScoreChange + AnalyticsPage.FICO_CREDITSCORE_WITHOUT_GAP);
        }
        String mylistStr = helpingHurtigList.toString().replace("[", "").replace("]", "");
        extras.put(mContext.getResources().getString(R.string.mylist1), mylistStr);
        TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_PG, extras);
    }


    public static void trackCreditScorecardOnBoxClick(String ratingValue, Context context) {
        HashMap<String, Object> extras = new HashMap<String, Object>();
        extras.put(context.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_RATING + ratingValue);
        extras.put(context.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_RATING + ratingValue);
        TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_DETAILS_PG, extras);
    }

    public static void trackFicoBoxesExapandTags(Context mContext, int postion, FicoCollapsedDetails ficoCollapsedDetails) {
        String boxRating = "Not Available";
        if (ficoCollapsedDetails.getBoxRating() != null) {
            boxRating = ficoCollapsedDetails.getBoxRating();
        }
        switch (postion) {
            case TOTAL_ACCOUNT:
                HashMap<String, Object> totalAccountExtras = new HashMap<String, Object>();
                if (ficoCollapsedDetails.getExpandedViewValueOne() != null) {
                    totalAccountExtras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_TOTAL_ACCOUNT_WITH_CHANGE);
                } else {
                    totalAccountExtras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_TOTAL_ACCOUNT_WITHOUT_CHANGE);
                }

                totalAccountExtras.put(mContext.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_TOTAL_ACCOUNT_RATING + boxRating);
                totalAccountExtras.put(mContext.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_TOTAL_ACCOUNT_RATING + boxRating);
                TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_TOTALACCOUNTS_PG, totalAccountExtras);
                break;

            case LENGH_OF_CREDIT:
                HashMap<String, Object> lenghtCreditExtras = new HashMap<String, Object>();
                lenghtCreditExtras.put(mContext.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_LENGTH_OF_CREDIT_RATING + boxRating);
                lenghtCreditExtras.put(mContext.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_LENGTH_OF_CREDIT_RATING + boxRating);
                TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_LENGHTOFCREDIT_PG, lenghtCreditExtras);
                break;

            case INQUIRES:
                HashMap<String, Object> inquiresExtras = new HashMap<String, Object>();
                if (ficoCollapsedDetails.getCollapsedBoxValue() != null) {
                    inquiresExtras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_INQUIRIES_WITH_CHANGE);
                } else {
                    inquiresExtras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_INQUIRIES_WITHOUT_CHANGE);
                }
                inquiresExtras.put(mContext.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_INQUIRIES_RATING + boxRating);
                inquiresExtras.put(mContext.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_INQUIRIES_RATING + boxRating);
                TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_INQUIRIES_PG, inquiresExtras);
                break;

            case REVOLVING_UTILIZATION:
                HashMap<String, Object> revolvingExtras = new HashMap<String, Object>();
                revolvingExtras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION);
                revolvingExtras.put(mContext.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION_RATING + boxRating);
                revolvingExtras.put(mContext.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION_RATING + boxRating);
                TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION_PG, revolvingExtras);
                break;

            case MISSED_PAYMENT:
                HashMap<String, Object> missedExtras = new HashMap<String, Object>();
                if (ficoCollapsedDetails.getExpandedViewValueTwo() != null) {
                    missedExtras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_MISSEDPAYMENTS_WITH_CHANGE);
                } else {
                    missedExtras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_MISSEDPAYMENTS_WITHOUT_CHANGE);
                }
                missedExtras.put(mContext.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_MISSEDPAYMENTS_RATING + boxRating);
                missedExtras.put(mContext.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_MISSEDPAYMENTS_RATING + boxRating);
                TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_MISSEDPAYMENTS_PG, missedExtras);

                break;

            default:
                break;
        }

    }

    public static void trackRevolvingUtilizationUnavailableTags(Context mContext) {
        HashMap<String, Object> extras = new HashMap<String, Object>();
        extras.put(mContext.getResources().getString(R.string.prop44), AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION);
        extras.put(mContext.getResources().getString(R.string.evar5), AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION_UNAVAILABLE);
        extras.put(mContext.getResources().getString(R.string.prop5), AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION_UNAVAILABLE);
        TrackingHelper.trackCardPage(AnalyticsPage.FICO_CREDITSCORE_REVOLVINGUTILIZATION_PG, extras);

    }

    public static void trackFicoClickEvent(Context mContext, String pagename) {
        HashMap<String, Object> extras = new HashMap<String, Object>();
        extras.put(mContext.getResources().getString(R.string.prop1), pagename);
        TrackingHelper.trackClickEvents(pagename, null, AnalyticsPage.LINK_TYPE_O, extras);

    }
/*End Changes for US121913*/

    /**
     * Get Date Month format
     */
    public static String getFormattedDateMonth(String oldDateStr) {
        String newDateStr = "";
        if (!PortalUtils.isStrFieldEmpty(oldDateStr)) {
            SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
            Date newDate = null;
            try {
                newDate = format.parse(oldDateStr.trim());
                format = new SimpleDateFormat("MMMM");
                newDateStr = format.format(newDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return newDateStr != null ? newDateStr : oldDateStr;
    }

    /**
     * This method return True when Talkback(ADA) is ON.
     */
    public static boolean isTalkBackEnabled(Context mContext) {
        AccessibilityManager am = (AccessibilityManager) mContext.getSystemService(ACCESSIBILITY_SERVICE);
        boolean isAccessibilityEnabled = am.isEnabled();
        boolean isExploreByTouchEnabled = am.isTouchExplorationEnabled();

        return isExploreByTouchEnabled;
    }

    public static boolean isCardEligibleForFico(String cardType) {
        if (PortalUtils.isStrFieldEmpty(cardType)) {
            return true;
        }
        if (cardType.equalsIgnoreCase("CRP") || cardType.equalsIgnoreCase("DBC") || cardType.equalsIgnoreCase(("DBM")) || cardType.equalsIgnoreCase(("ESN")) || cardType.equalsIgnoreCase(("ESF"))) {
            return false;
        } else {
            return true;
        }
    }
}