package com.discover.mobile.common.shared.utils;

import android.content.Context;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;

public class DeviceUtils {

    public static String getDeviceId(Context context) {
        // # US63017 android id to be taken from Secure api instead of Telephony manager from Marshmallow onwards.
        String did;

        if (android.os.Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1) {

            final TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

            did = telephonyManager.getDeviceId();
        }
        else
            did = null;
        // # US63017 android id to be taken from Secure api instead of Telephony manager from Marshmallow onwards.

        if (did == null) {
            did = Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);
        }
        return did;
    }
}
