package com.discover.mobile.common.portalpage.utils;

public class PortalConstants {

    public class Misc {
        public static final String PORTAL_ACCOUNT_LIST_SORTED_KEY = "portal_account_list_sorted";
        public static final String PORTAL_ACCOUNT_CLOSED_KEY = "portal_account_closed_key";
        public static final String JOINT_CARD_REGISTRATION_TITLE = "joint_card_registration_title";
        public static final String JOINT_CARD_REGISTRATION_MESSAGE = "joint_card_registration_message";
        /** Added new constants for US47049 */
        public static final String LINKTO_CLA_MERGE = "linktoclamerge";
        public static final String LINKTO_PORTAL_CARD_MERGE = "linktoclacardverify?selAcct=";
        public static final String LINKTO_PORTAL_BANK_MERGE = "linktoclabankverify";
        //client side key to identify that user is invoking BBredirect for CLA merge
        public static final String BBREDIRECT_DEEPLINK_IDENTIFIER = "bbredirect_deeplink_identifier";
        public static final String BBREDIRECT_DEEPLINK_IDENTIFIER_CLA = "CLA_MERGE";
        public static final int CLA_MERGE_SUCCESS_REQUEST_CODE = 100;
        public static final String CLA_MERGE_CUSTOMER_FIRSTNAME = "customerFirstName";
        public static final String CLA_MERGE_ISFORCEMERGE = "isForceMerge";
        public static final String PUSH_OFFLINE = "pushOffline";
        public static final String PUSH_PREF = "PUSH_PREF";
        public static final String DEEP_LINK_KEY = "deepLinks";
        public static final String LOGIN_PAGE_NAVIGATION_ACTION = "loginpage";
        public static final String ACCOUNT_HOME_NAVIGATION_ACTION = "accounthome";

        /** End changes for US47049*/
        public static final String FRAUD_DIALOG_PREF = "FRAUD_DIALOG_PREF";
        public static final String FRAUD_DIALOG_STATUS = "FRAUD_DIALOG_STATUS";

        // US126324 Changes - start
        public static final String CLA_MERGE_ISINITIAL_SKIPATTEMPT = "isInitialSkipAttempt";
        // US126324 Changes - end
    }

    public class Error {
        /**
         * Added for US50152 Prevent Joint Card Toggle login
         * If user has bank accounts & all card accounts are closed & no remaining open card account
         * then redirect user to Bank side - (auto login)
         */
        public static final String JOIN_CARD_ACCOUNT_LOGIN_ATTEMPT2_ERROR = "4032122";
        public static final String JOINT_ACCOUNT_LOGIN_ERROR_CODE = "4011116";

        public static final String MERGE_ELIGIBLE_BANK_ERROR_CODE = "4032125";
        public static final String FORCE_MERGE_BANK_ERROR_CODE = "4032126";
        public static final String NON_MERGE_ELIGIBLE_BANK_ERROR_CODE = "4032129";
        /*Web lockout error code for US66298*/
        public static final String WEB_LOCKOUT_ERROR_CODE = "4012127";

    }

    /**
     * Class to add Constant keys that needs to send in the request body of any service class for
     * Portal - Module
     * Added from 7.10 fingerprint release
     */
    public class RequestConstant {
        /**
         * Added for 7.10 fingerprint release
         */
        public static final String FINGER_PRINT_LOGIN_ID = "TCHD"; // Ket is Touch ID on iOS & service is also refering touch ID for android finfer print too
    }
    /**
     * Class to hold constants related with gateway between LP-SDK & Discover Server
     * Added for US89215 - Messaging App SDK Integration
     */
    public class AppMessagingRequestParams {

        public static final String RESPONSE_TYPE = "response_type";
        public static final String SCOPE = "scope";
        public static final String CLIENT_ID = "client_id";
        public static final String REDIRECT_URI = "redirect_uri";
        public static final String STATE = "state";

    }
    public static final String BANK_ERROR_BOX_ID = "BANK_ERROR_BOX";
    public static final String CARD_ERROR_BOX_ID = "CARD_ERROR_BOX";
    public static final String VERIFY_ACCOUNT_BOX_ID = "VERIFY_ACCOUNT_BOX";
}
