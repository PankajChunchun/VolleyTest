package com.discover.mobile.common.androidwear;

import com.discover.mobile.common.shared.utils.TokenUtil;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class BankAndroidWearUtils {

    public static final String WEAR_PREFS_TOKEN = "token";
    private static final String WEAR_BANK_SHARED_PREFS = "AndroidWearUtils"; // Name of the file -.xml
    private static final String WEAR_LOGGED_IN = "WearLoggedIn";
    private static final String WEAR_IS_BANKLOGIN_SELECTED = "WearIsBankLoginSelected";
    public static String clearWearToken;
    private static Editor _wear_prefsEditor;
    private static SharedPreferences _wear_sharedPrefs;

    public BankAndroidWearUtils(Context context) {
        _wear_sharedPrefs = context.getSharedPreferences(
                WEAR_BANK_SHARED_PREFS, Context.MODE_PRIVATE);
        _wear_prefsEditor = _wear_sharedPrefs.edit();
    }

    /**
     * It creates the token and save it in preferences
     */
    public static void createWearToken(Context context, String token) throws Exception {
        if (_wear_sharedPrefs.contains(WEAR_PREFS_TOKEN)) {
            // TODO can't write token when one already exists
            return;
        }
        // write token to shared preference "token"
        _wear_prefsEditor.putString(WEAR_PREFS_TOKEN,
                TokenUtil.encryptAndJsonifyToken(context, token));
        _wear_prefsEditor.commit();


    }

    /**
     * Gets current device token
     */
    public static String getClearWearToken(Context context) throws Exception {
        String tokenStr = _wear_sharedPrefs.getString(WEAR_PREFS_TOKEN,
                null);

        clearWearToken = TokenUtil
                .parseAndDecryptTokenSupportClear(context, tokenStr);

        return clearWearToken;
    }

    public static void setLoggedIn(Context context, boolean flag) {
        if (null == _wear_sharedPrefs) {
            _wear_sharedPrefs = context.getSharedPreferences(
                    WEAR_BANK_SHARED_PREFS, Context.MODE_PRIVATE);
            _wear_prefsEditor = _wear_sharedPrefs.edit();
        }

        _wear_prefsEditor.putBoolean(WEAR_LOGGED_IN, flag);
        _wear_prefsEditor.commit();
    }

    public static void setBankLoginSelected(Context context, boolean flag) {
        if (null == _wear_sharedPrefs) {
            _wear_sharedPrefs = context.getSharedPreferences(
                    WEAR_BANK_SHARED_PREFS, Context.MODE_PRIVATE);
            _wear_prefsEditor = _wear_sharedPrefs.edit();
        }

        _wear_prefsEditor.putBoolean(WEAR_IS_BANKLOGIN_SELECTED, flag);
        _wear_prefsEditor.commit();
    }

    public static String getWearToken(Context context) throws Exception {
        if (null == _wear_sharedPrefs) {
            _wear_sharedPrefs = context.getSharedPreferences(
                    WEAR_BANK_SHARED_PREFS, Context.MODE_PRIVATE);
            _wear_prefsEditor = _wear_sharedPrefs.edit();
        }

        String tokenStr = _wear_sharedPrefs.getString(WEAR_PREFS_TOKEN, null);

        System.out.println("getWearViewToken() token string ::: " + tokenStr);

        return tokenStr;
    }

    /**
     * Returns boolean whether device token exist or not
     */
    public boolean doesWearDeviceTokenExist() {
        return (_wear_sharedPrefs.contains(WEAR_PREFS_TOKEN));
    }

    /**
     * Deletes current device token
     */
    public void deleteWearToken() {
        try {
            _wear_prefsEditor.remove(WEAR_PREFS_TOKEN);
            _wear_prefsEditor.commit();
        } catch (Exception e) {
        }
    }

    public boolean getLoggedIn() {
        return _wear_sharedPrefs.getBoolean(WEAR_LOGGED_IN, false);
    }

    public boolean getBankLoginSelected() {
        return _wear_sharedPrefs.getBoolean(WEAR_IS_BANKLOGIN_SELECTED, false);
    }


}