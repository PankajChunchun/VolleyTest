package com.discover.mobile.common.onboardwiz.fragment.fingerprint;

import android.content.Context;
import android.support.annotation.NonNull;

import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.onboardwiz.interfaces.OnBoardFingerPrintInteractor;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.PasscodeUtils;

/**
 * Created by 436645 on 11/1/2016.
 */
public class OnBoardFingerPrintInteractorImpl implements OnBoardFingerPrintInteractor {

    private @NonNull Context mContext;

    public OnBoardFingerPrintInteractorImpl(Context context){
        mContext = context;
    }

    @Override
    public boolean isFingerprintHardwareAvailable() {
        return FingerPrintUtils.isFingerprintHardwareAvailable(this.mContext);
    }

    @Override
    public boolean isFingerPrintRegisteredOnDevice() {
        return FingerPrintUtils.isFingerprintRegistered(this.mContext);
    }

    @Override
    public boolean isPassCodeEnabled() {
        PasscodeUtils passcodeUtils;
        String deviceToken = null;

        if(Globals.isBankLoginSelected())
            passcodeUtils = new PasscodeUtils(this.mContext, false);
        else
            passcodeUtils = new PasscodeUtils(this.mContext, true);

        try {
            if (passcodeUtils.doesDeviceTokenExist())
                deviceToken = passcodeUtils.getClearPasscodeToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (deviceToken != null)
            return true;
        else
            return false;

    }

    @Override
    public void exitSetUp() {
        OnBoardHelper.navigateToCardOrBankHome();
    }

    @Override
    public boolean enableFingerPrint() {
        final FingerPrintUtils fingerPrintUtils = new FingerPrintUtils(mContext);
        fingerPrintUtils.setFingerPrintStatus(true);
        FacadeFactory.getCardFacade().updateProfileSettingFingerPrintStatus(true, fingerPrintUtils.getUserId(mContext), mContext);
        return fingerPrintUtils.getFingerPrintStatus()? true : false;
    }
}
