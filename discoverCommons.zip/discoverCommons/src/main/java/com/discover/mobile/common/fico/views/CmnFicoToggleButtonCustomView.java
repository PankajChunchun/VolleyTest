package com.discover.mobile.common.fico.views;


import com.discover.mobile.common.R;
import com.discover.mobile.common.ui.table.TableButtonGroup;
import com.discover.mobile.common.ui.table.TableHeaderButton;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;


/*This is common class for Fico Toggle Button */

public class CmnFicoToggleButtonCustomView extends RelativeLayout {

    /** Indexes of the buttons in the table header, used to return references to buttons */
    private final static int GRAPH_BUTTON = 0;
    private final static int LIST_BUTTON = 1;
    /*
     * Header button view that will be inflated
     */
    private final View view;
    /** Button group that contains the buttons to nav to graph/sent messages */
    private final TableButtonGroup group;
    /** Boolean to keep track if the graph button is selected or not */
    private boolean isGraphSelected;
    private Context mContext;


    public CmnFicoToggleButtonCustomView(Context context, final AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        view = LayoutInflater.from(context).inflate(R.layout.cmn_fico_toggle_button_layout, null);
        group = (TableButtonGroup) view.findViewById(R.id.header_buttons);
        group.getButton(0).hideDivider();
        group.getButton(1).hideDivider();
        group.getButton(0).setBackgroundDrawable(context.getResources().getDrawable(R.drawable.custom_tab_background));
        group.getButton(1).setBackgroundDrawable(context.getResources().getDrawable(R.drawable.custom_tab_background));
        group.getButton(0).setTag("button_text_" +GRAPH_BUTTON );
        group.getButton(1).setTag("button_text_" +LIST_BUTTON);
        group.getButton(0).setContentDescription(context.getResources().getString(R.string.graph_tab_desc));
        group.getButton(1).setContentDescription(context.getResources().getString(R.string.list_tab_desc));
        addView(view);
    }

    /**
     * Set the observers to the group
     *
     * @param observer - observer of the buttons
     */
    public void setGroupObserver(final OnClickListener observer) {
        group.addObserver(observer);
    }

    /**
     * Returns a the graph button
     *
     * @return graph button
     */
    public TableHeaderButton getGraphButton() {
        return group.getButton(GRAPH_BUTTON);
    }

    /**
     * Returns the sentbox button
     *
     * @return sent button
     */
    public TableHeaderButton getSentBoxButton() {
        return group.getButton(LIST_BUTTON);
    }

    /**
     * Notify the button group that observer has stopped
     * listening
     */
    public void removeListeners() {
        group.removeObserver();
    }

    /** set the Sent button selected */
    public void setGraphSelected() {
        setIsGraphSelected(false);
        group.setButtonSelected(GRAPH_BUTTON);
        setButtonTypeFace(0, Typeface.DEFAULT_BOLD, true);

        setButtonTypeFace(1, Typeface.DEFAULT, false);
    }

    /** set the graph button to selected */
    public void setListSelected() {
        setIsGraphSelected(true);
        group.setButtonSelected(LIST_BUTTON);

        setButtonTypeFace(0, Typeface.DEFAULT, false);

        setButtonTypeFace(1, Typeface.DEFAULT_BOLD, true);
    }

    /**
     * Set flag to determine if the user is on graph
     */
    public void setIsGraphSelected(boolean selected) {
        isGraphSelected = selected;
    }

    /**
     * @return true if user is currently viewing graph
     */
    public boolean getGraphSelected() {
        return isGraphSelected;
    }

    private void setButtonTypeFace(int buttonid, Typeface tf, boolean isSelected) {
        TableHeaderButton tableHeaderButton = (TableHeaderButton) group.getButton(buttonid);
        TextView toggleTextV = ((TextView) ((RelativeLayout) tableHeaderButton.getChildAt(0)).getChildAt(0));
        if (null != toggleTextV) {
            toggleTextV.setTypeface(tf);
            if (isSelected) {
                toggleTextV.setTextColor(ContextCompat.getColor(mContext, R.color.orange_gradient_dark));
            } else {
                toggleTextV.setTextColor(ContextCompat.getColor(mContext, R.color.sub_copy));
            }
        }
    }
}
