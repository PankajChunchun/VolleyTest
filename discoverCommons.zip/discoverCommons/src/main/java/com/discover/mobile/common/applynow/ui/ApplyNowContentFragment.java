package com.discover.mobile.common.applynow.ui;

/**
 * Created by 467649 on 9/13/2017.
 */

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import java.util.HashMap;

public class ApplyNowContentFragment extends Fragment {
    private static final String EXTRA_PAGE_NUMBER = "current_page_to_show";

    private static final String[] pageTitleArray = {"apply_now_discover_it_card_page_title",
            "apply_now_online_banking_card_page_title", "apply_now_dpl_card_page_title"};
    private static final String[] pageHeaderArray ={"apply_now_discover_it_card_header",
            "apply_now_online_banking_card_header", "apply_now_dpl_card_header"};
    private static final String[] pageDescriptionArray ={"apply_now_discover_it_card_description",
            "apply_now_online_banking_card_description", "apply_now_dpl_card_description"};
    private static final String[] pageButtonArray ={"apply_now_discover_it_card_button",
            "apply_now_online_banking_card_button", "apply_now_dpl_card_button"};
    private static final String[] urlArray ={"apply_now_discover_it_card_url",
            "apply_now_online_banking_card_url", "apply_now_dpl_card_url"};
    private static final int[] pageImageArray ={R.drawable.promo_it_card,  R.drawable.apply_now_ob, R.drawable.apply_now_pl };

    private static final int[] pageTitleStringArray = {R.string.apply_now_discover_it_card_page_title,
            R.string.apply_now_online_banking_card_page_title, R.string.apply_now_dpl_card_page_title};
    private static final int[] pageHeaderStringArray ={R.string.apply_now_discover_it_card_header,
            R.string.apply_now_online_banking_card_header, R.string.apply_now_dpl_card_header};
    private static final int[] pageDescriptionStringArray ={R.string.apply_now_discover_it_card_description,
            R.string.apply_now_online_banking_card_description, R.string.apply_now_dpl_card_description};
    private static final int[] pageButtonStringArray ={R.string.apply_now_discover_it_card_button,
            R.string.apply_now_online_banking_card_button, R.string.apply_now_dpl_card_button};
    private static final int[] urlStringArray ={R.string.apply_now_discover_it_card_url,
            R.string.apply_now_online_banking_card_url, R.string.apply_now_dpl_card_url};
    private int mCurrentPos = 0;
    private ImageButton mCloseBtn;
    private static View.OnClickListener mOnCloseBtnClickListener;
    private Context mContext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.apply_now_content_layout, container, false);
        Bundle mBundle = getArguments();
        if(mBundle != null){
            mCurrentPos = mBundle.getInt(EXTRA_PAGE_NUMBER,0);
        }
        TextView pageTitle = (TextView)view.findViewById(R.id.heading_tv);
        TextView pageHeader = (TextView)view.findViewById(R.id.apply_now_txt);
        TextView pageDescription = (TextView)view.findViewById(R.id.apply_now_sub_txt);
        ImageView pageImage = (ImageView)view.findViewById(R.id.apply_now_img);
        Button applyNowButton = (Button)view.findViewById(R.id.apply_now_button);
        TextView bottomText = (TextView)view.findViewById(R.id.apply_now_bottom_text);
        String mTitle = InfoMessageUtils.Instance().getErrorMessage(pageTitleArray[mCurrentPos]);
        if(mCurrentPos == 2){
            bottomText.setVisibility(View.VISIBLE);
        }
        if(!TextUtils.isEmpty(mTitle)){
            pageTitle.setText(CommonUtils.getHtmlFormattedText(mTitle));
        }else{
            pageTitle.setText(getResources().getString(pageTitleStringArray[mCurrentPos]));
        }
        String mHeader = InfoMessageUtils.Instance().getErrorMessage(pageHeaderArray[mCurrentPos]);
        if(!TextUtils.isEmpty(mHeader)){
            pageHeader.setText(CommonUtils.getHtmlFormattedText(mHeader));
        }else{
            pageHeader.setText(CommonUtils.getHtmlFormattedText(getResources().getString(pageHeaderStringArray[mCurrentPos])));
        }
        String mDescription = InfoMessageUtils.Instance().getErrorMessage(pageDescriptionArray[mCurrentPos]);
        if(!TextUtils.isEmpty(mDescription)){
            pageDescription.setText(mDescription);
        }else{
            if(mCurrentPos == 0){
                pageDescription.setVisibility(View.GONE);
            }else{
                pageDescription.setText(getResources().getString(pageDescriptionStringArray[mCurrentPos]));
            }

        }
        String buttonText =InfoMessageUtils.Instance().getErrorMessage(pageButtonArray[mCurrentPos]);
        if(!TextUtils.isEmpty(buttonText)){
            applyNowButton.setText(buttonText);
        }else{
            applyNowButton.setText(getResources().getString(pageButtonStringArray[mCurrentPos]));
        }
        pageImage.setImageDrawable(getResources().getDrawable(pageImageArray[mCurrentPos]));
        mCloseBtn = (ImageButton) view.findViewById(R.id.bb_redirect_close_button);
        mCloseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mOnCloseBtnClickListener != null) {
                    mOnCloseBtnClickListener.onClick(v);
                }
            }
        });
        mCurrentPos = getArguments().getInt(EXTRA_PAGE_NUMBER, 0);
        applyNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = InfoMessageUtils.Instance().getErrorMessage(urlArray[mCurrentPos]);
                if(TextUtils.isEmpty(url)){
                    url = getResources().getString(urlStringArray[mCurrentPos]);
                }

                HashMap<String, Object> extras = new HashMap<>();
                extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.APPLY_NOW_PROP1_ARRAY[mCurrentPos]);
                TrackingHelper.trackClickEvents(AnalyticsPage.APPLY_NOW_PEV1_ARRAY[mCurrentPos], null, AnalyticsPage.LINK_TYPE_O, extras);
                ApplyNowWebviewActivity.show(mContext,url );
            }
        });



        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    public static ApplyNowContentFragment newInstance(int currentPage) {

        Bundle args = new Bundle();
        args.putInt(EXTRA_PAGE_NUMBER, currentPage);


        ApplyNowContentFragment fragment = new ApplyNowContentFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public void setCloseButtonClickListener(View.OnClickListener closeButtonClickListener) {
        this.mOnCloseBtnClickListener = closeButtonClickListener;
    }
}
