package com.discover.mobile.common.shared.utils;

import android.content.Context;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Base64;

import com.discover.mobile.common.encryption.LegacySecureRandom;
import com.discover.mobile.common.encryption.SHA1PRNG_SecureRandomImpl;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class LagacyEncryptionUtil {

    private static final String SEED4KEY = "EoeBcwiahT5CxacQsaWI0e16p9lb+wQs0KFJdmzSTEo=";
    private static final String SEED4KEY_LEGACY_TOKEN = "yqTVTYIzevAbCMqejjaOlhMsV14Te1irqPKWhW0e/4s=";
    private static String strDID = null, strOID = null;

    private static byte[] getKey() throws Exception {
        return getKey(SEED4KEY);
    }

    private static byte[] getKey(String seed) throws Exception {
        byte[] seedBytes = seed.getBytes();
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        // Note: need to add the second parameter for this to work on Android 4.2 or greater.
        SecureRandom sr = new LegacySecureRandom(new SHA1PRNG_SecureRandomImpl(), null);
        sr.setSeed(seedBytes);
        kgen.init(128, sr); // 192 and 256 bits may not be available
        SecretKey skey = kgen.generateKey();
        byte[] keyBytes = skey.getEncoded();
        return keyBytes;
    }

    private static byte[] getDynaKey(Context context) throws Exception {
        String SEED4KEY = "", DID, OID;
        // # US63017 android id to be taken from Secure api instead of Telephony manager from Marshmallow onwards.
        DID = Secure.getString(context.getContentResolver(),
                Secure.ANDROID_ID);
        OID = DID;
        // # US63017 android id to be taken from Secure api instead of Telephony manager from Marshmallow onwards.

        if (null != DID && DID.length() > 0)
            SEED4KEY += DID;
        if (null != OID && OID.length() > 0)
            SEED4KEY += OID;

        byte[] seedBytes = SEED4KEY.getBytes();
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        // Note: need to add the second parameter for this to work on Android
        // 4.2 or greater.


        SecureRandom sr = new LegacySecureRandom(new SHA1PRNG_SecureRandomImpl(), null);
        sr.setSeed(seedBytes);
        kgen.init(128, sr); // 192 and 256 bits may not be available
        SecretKey skey = kgen.generateKey();
        byte[] keyBytes = skey.getEncoded();
        return keyBytes;
    }

    public static String encryptTokenWithDyna(Context context, String clearStr) throws Exception {
        return encryptToken(context, clearStr, true);
    }

    public static String decryptTokenWithDyna(Context context, String encryptedStr) throws Exception {
        return decryptToken(context, encryptedStr, true);
    }

    protected static String decryptTokenWithoutDyna(String encryptedStr) throws Exception {
        return decryptToken(null, encryptedStr, false);
    }

    // use for passcode, quickview, mop token on card side, hlin0, 1/21/14
    private static String encryptToken(Context context, String clearStr, boolean useDynaKey) throws Exception {
        byte[] clearBytes = Base64.decode(clearStr, Base64.DEFAULT);
        byte[] encryptedBytes = encrypt(context, clearBytes, useDynaKey, SEED4KEY_LEGACY_TOKEN);
        return new String(Base64.encodeToString(encryptedBytes, Base64.NO_WRAP));
    }

    // use for passcode, quickview, mop token on card side, hlin0, 1/21/14
    private static String decryptToken(Context context, String encryptedStr, boolean useDynaKey) throws Exception {
        byte[] encryptedBytes = Base64.decode(encryptedStr, Base64.DEFAULT);
        byte[] clearBytes = decrypt(context, encryptedBytes, useDynaKey, SEED4KEY_LEGACY_TOKEN);
        return new String(Base64.encodeToString(clearBytes, Base64.NO_WRAP));
    }

    // bank's legacy method, preserve the original base64 encode/decode treatment, hlin0, 1/21/14
    public static String encrypt(String clearStr) throws Exception {
        byte[] clearBytes = Base64.encode(clearStr.getBytes(), Base64.DEFAULT);
        byte[] encryptedBytes = encrypt(null, clearBytes, false, null);
        return new String(Base64.encodeToString(encryptedBytes, Base64.NO_WRAP | Base64.NO_PADDING));
    }

    private static byte[] encrypt(Context context, byte[] clearBytes, boolean useDynaKey, String prvdSeed) throws Exception {
        SecretKeySpec skeySpec = null;
        if (useDynaKey)
            skeySpec = new SecretKeySpec(getDynaKey(context), "AES"); //14.2 mop/qv/pc tokens
        else if (prvdSeed != null)
            skeySpec = new SecretKeySpec(getKey(prvdSeed), "AES"); // prior to 14.2 qv tokens
        else skeySpec = new SecretKeySpec(getKey(), "AES"); //bank usage
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encryptedBytes = cipher.doFinal(clearBytes);
        return encryptedBytes;
    }

    // bank's legacy method, preserve the original base64 encode/decode treatment, hlin0, 1/21/14
    public static String decrypt(String encryptedStr) throws Exception {
        byte[] encryptedBytes = Base64.decode(encryptedStr, Base64.DEFAULT);
        byte[] clearBytes = decrypt(null, encryptedBytes, false, null);
        return new String(Base64.decode(clearBytes, Base64.NO_WRAP | Base64.NO_PADDING));

    }

    private static byte[] decrypt(Context context, byte[] encryptedBytes, boolean useDynaKey, String prvdSeed) throws Exception {
        SecretKeySpec skeySpec = null;
        if (useDynaKey)
            skeySpec = new SecretKeySpec(getDynaKey(context), "AES"); //14.2 mop/qv/pc tokens
        else if (prvdSeed != null)
            skeySpec = new SecretKeySpec(getKey(prvdSeed), "AES"); // prior to 14.2 qv tokens
        else skeySpec = new SecretKeySpec(getKey(), "AES"); //bank usage
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return decryptedBytes;
    }

    /**
     * App data was lost due to encryption method is changed in 7.9 app version.
     * To save app cache after version upgrade we have written below functions to get old value
     * encrypted value and decrypt with old key and encrypt with new key so that app data is
     * preserved after app upgrade from 7.8 to 7.9.
     * below mentioned functions can be removed once all the customers are updated to 7.9 version.
     * 1. decryptTokenWithDynaFromLogin
     * 2. decryptTokenFromLogin
     * 3. decryptFromLogin
     * 4. getDynaKeyFromLogin
     */
    public static String decryptTokenWithDynaFromLogin(Context context, String encryptedStr) throws Exception {
        return decryptTokenFromLogin(context, encryptedStr, true);
    }

    private static String decryptTokenFromLogin(Context context, String encryptedStr, boolean useDynaKey) throws Exception {
        byte[] encryptedBytes = Base64.decode(encryptedStr, Base64.DEFAULT);
        byte[] clearBytes = decryptFromLogin(context, encryptedBytes, useDynaKey, SEED4KEY_LEGACY_TOKEN);
        return new String(Base64.encodeToString(clearBytes, Base64.NO_WRAP));
    }

    private static byte[] decryptFromLogin(Context context, byte[] encryptedBytes, boolean useDynaKey, String prvdSeed) throws Exception {
        SecretKeySpec skeySpec = null;
        if (useDynaKey)
            skeySpec = new SecretKeySpec(getDynaKeyFromLogin(context), "AES"); //14.2 mop/qv/pc tokens
        else if (prvdSeed != null)
            skeySpec = new SecretKeySpec(getKey(prvdSeed), "AES"); // prior to 14.2 qv tokens
        else skeySpec = new SecretKeySpec(getKey(), "AES"); //bank usage
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return decryptedBytes;
    }


    private static byte[] getDynaKeyFromLogin(Context context) throws Exception {
        String SEED4KEY = "", DID, OID;
        final TelephonyManager telephonyManager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        DID = telephonyManager.getDeviceId();
        OID = Secure.getString(context.getContentResolver(),
                Secure.ANDROID_ID); // Will be same as phonegap
        if (null != DID && DID.length() > 0)
            SEED4KEY += DID;
        if (null != OID && OID.length() > 0)
            SEED4KEY += OID;

        byte[] seedBytes = SEED4KEY.getBytes();
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        // Note: need to add the second parameter for this to work on Android
        // 4.2 or greater.


        SecureRandom sr = new LegacySecureRandom(new SHA1PRNG_SecureRandomImpl(), null);
        sr.setSeed(seedBytes);
        kgen.init(128, sr); // 192 and 256 bits may not be available
        SecretKey skey = kgen.generateKey();
        byte[] keyBytes = skey.getEncoded();
        return keyBytes;
    }
}
