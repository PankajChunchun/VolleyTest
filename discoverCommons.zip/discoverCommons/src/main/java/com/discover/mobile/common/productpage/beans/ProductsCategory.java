package com.discover.mobile.common.productpage.beans;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProductsCategory implements Serializable {

    private static final long serialVersionUID = -9126629351996816405L;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("links")
    @Expose
    private List<ProductsLink> links = new ArrayList<ProductsLink>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ProductsLink> getLinks() {
        return links;
    }

    public void setLinks(List<ProductsLink> links) {
        this.links = links;
    }
}