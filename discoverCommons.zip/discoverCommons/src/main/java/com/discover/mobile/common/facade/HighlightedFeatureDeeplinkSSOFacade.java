package com.discover.mobile.common.facade;

/**
 * Deeplink facade for Highlighted-features and WhatsNew, which handles SSO deeplinks
 * for prelogin or postlogin.
 *
 * @author pkuma13
 */

public interface HighlightedFeatureDeeplinkSSOFacade extends HighlightedFeatureDeeplinkFacade {
}
