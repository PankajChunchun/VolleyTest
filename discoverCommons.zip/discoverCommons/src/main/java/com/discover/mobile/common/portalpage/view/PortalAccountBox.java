package com.discover.mobile.common.portalpage.view;

import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.beans.DepositAccount;
import com.discover.mobile.common.portalpage.beans.IraAccount;
import com.discover.mobile.common.portalpage.beans.IraPlan;
import com.discover.mobile.common.portalpage.beans.LoanAccount;
import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

/**
 * This common custom Account Box for Both "Card" & "Bank" types of account
 *
 * @author slende
 */
public class PortalAccountBox extends LinearLayout {

    public final String BANKSUMMARYSTATUSINVALID = "invalid";
    public final String BANKSUMMARYSTATUSERROR = "error";
    private Context mContext;
    private PortalAccountListItemViewHolder viewHolder;
    private Resources resources;
    private int tagId = 0;
    public final String BANK_CBB_NEW_FLOW = "Checking ";

    public PortalAccountBox(Context context, int tag) {
        super(context);
        mContext = context;
        tagId = tag;
        resources = mContext.getResources();
        inItUI();

    }

    private void inItUI() {
        inflate(mContext, R.layout.porta_account_box_card_view, this);
        setUpViewHolder();
    }

    private void setUpViewHolder() {
        viewHolder = new PortalAccountListItemViewHolder();
        viewHolder.portalAccountBoxRootRL = (RelativeLayout) findViewById(R.id.portalAccountBox_RootId);

        viewHolder.portalBoxHeaderContainer = (RelativeLayout) findViewById(R.id.portal_box_headerContainerID);

        viewHolder.portalBoxFooterContainer = (RelativeLayout) findViewById(R.id.portal_box_footerContainerID);

        viewHolder.cardBankErrorBox = (RelativeLayout) findViewById(R.id.cardBankErrorBoxView);

        viewHolder.portalBoxContentContainer1 = (RelativeLayout) findViewById(R.id.portal_box_headerContainer_row1);

        viewHolder.portalBoxContentContainer2 = (RelativeLayout) findViewById(R.id.portal_box_headerContainer_row2);

        viewHolder.portalBoxContentContainer3 = (RelativeLayout) findViewById(R.id.portal_box_headerContainer_row3);

        viewHolder.portalBoxContentContainer4 = (RelativeLayout) findViewById(R.id.portal_box_headerContainer_row4);

        viewHolder.accountTypeLabel = (TextView) findViewById(R.id.account_type);


        viewHolder.accountTypeLabel = (TextView) findViewById(R.id.account_type);
        viewHolder.accountLast4DigitLabel = (TextView) findViewById(R.id.idlastFourDigits);

        viewHolder.accountAmoutLabel = (TextView) findViewById(R.id.amount);

        viewHolder.accountTypeCaption = (TextView) findViewById(R.id.portal_page_account_caption);

        viewHolder.accountFooterLeft = (TextView) findViewById(R.id.portal_page_account_box_footer_left);

        viewHolder.accountFooterRight = (TextView) findViewById(R.id.portal_page_account_box_footer_right);

        viewHolder.accountContentLabel = (TextView) findViewById(R.id.box_item_labelText);


        viewHolder.accountContentLabel = (TextView) findViewById(R.id.box_item_labelText);
        viewHolder.accountContentValue = (TextView) findViewById(R.id.box_item_valueText);

        viewHolder.accountContentLabel1 = (TextView) findViewById(R.id.box_item_labelText1);


        viewHolder.accountContentLabel1 = (TextView) findViewById(R.id.box_item_labelText1);
        viewHolder.accountContentValue1 = (TextView) findViewById(R.id.box_item_valueText1);

        viewHolder.accountContentLabel2 = (TextView) findViewById(R.id.box_item_labelText2);


        viewHolder.accountContentLabel2 = (TextView) findViewById(R.id.box_item_labelText2);
        viewHolder.accountContentValue2 = (TextView) findViewById(R.id.box_item_valueText2);

        viewHolder.accountContentLabel3 = (TextView) findViewById(R.id.box_item_labelText3);


        viewHolder.accountContentLabel3 = (TextView) findViewById(R.id.box_item_labelText3);
        viewHolder.accountContentValue3 = (TextView) findViewById(R.id.box_item_valueText3);

        viewHolder.cardBankDataErrorTextView = (TextView) findViewById(R.id.card_bank_data_error_text);
        viewHolder.cardBankDataErrorImage = (ImageView) findViewById(R.id.card_bank_data_error_image);

        viewHolder.bankDataErrorMessageTitle = (TextView) findViewById(R.id.bank_data_error_message_title);

        viewHolder.bankDataErrorMessageSubTitle = (TextView) findViewById(R.id.bank_data_error_message_subtitle);

        viewHolder.view_row1 = (View) findViewById(R.id.view_row1);


        viewHolder.view_row1 = (View) findViewById(R.id.view_row1);
        viewHolder.view_row2 = (View) findViewById(R.id.view_row2);

        // #US43080 initialize account verify box item
        viewHolder.accountVerifyTextView = (TextView) findViewById(R.id.box_item_accountVerifyText);

        viewHolder.portalBoxImageView = (ImageView) findViewById(R.id.portal_box_item_ImageView);

        viewHolder.view_account_verify = (View) findViewById(R.id.view_account_verify);

        viewHolder.mFraudView = (RelativeLayout) findViewById(R.id.portalAccountBox_fraud);

        // For the defect 7430 and 7461 , the following fix will work fine
        if(viewHolder.mFraudView!=null) {
            viewHolder.mFraudView.setVisibility(View.GONE);
        }


        viewHolder.mFraudAccountNo = (TextView) findViewById(R.id.idlastFourDigits_fraud);

        viewHolder.mFraudCardTitle = (TextView) findViewById(R.id.account_type_fraud);

    }
//CrahLytics fix 1476
    private void setupTagForAutomation(int tagId, String mListName) {
        setViewTagForAutomation(tagId,mListName,viewHolder.portalAccountBoxRootRL);
        setViewTagForAutomation(tagId,mListName,viewHolder.portalBoxHeaderContainer);
        setViewTagForAutomation(tagId,mListName,viewHolder.portalBoxFooterContainer);
        setViewTagForAutomation(tagId,mListName,viewHolder.cardBankErrorBox);
        setViewTagForAutomation(tagId,mListName,viewHolder.portalBoxContentContainer1);
        setViewTagForAutomation(tagId,mListName,viewHolder.portalBoxContentContainer2);
        setViewTagForAutomation(tagId,mListName,viewHolder.portalBoxContentContainer3);
        setViewTagForAutomation(tagId,mListName,viewHolder.portalBoxContentContainer4);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountTypeLabel);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountLast4DigitLabel);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountAmoutLabel);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountTypeCaption);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountFooterLeft);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountFooterRight);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentLabel);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentValue);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentLabel1);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentValue1);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentLabel2);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentValue2);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentLabel3);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountContentValue3);
        setViewTagForAutomation(tagId,mListName,viewHolder.cardBankDataErrorTextView);
        setViewTagForAutomation(tagId,mListName,viewHolder.cardBankDataErrorImage);
        setViewTagForAutomation(tagId,mListName,viewHolder.bankDataErrorMessageTitle);
        setViewTagForAutomation(tagId,mListName,viewHolder.bankDataErrorMessageSubTitle);
        setViewTagForAutomation(tagId,mListName,viewHolder.view_row1);
        setViewTagForAutomation(tagId,mListName,viewHolder.view_row2);
        setViewTagForAutomation(tagId,mListName,viewHolder.accountVerifyTextView);
        setViewTagForAutomation(tagId,mListName,viewHolder.portalBoxImageView);
        setViewTagForAutomation(tagId,mListName,viewHolder.view_account_verify);
        setViewTagForAutomation(tagId,mListName,viewHolder.mFraudView);
        setViewTagForAutomation(tagId,mListName,viewHolder.mFraudAccountNo);
        setViewTagForAutomation(tagId,mListName,viewHolder.mFraudCardTitle);
    }

    void setViewTagForAutomation(int tagId, String mListName,View view){
        if(view!=null && mListName!=null && tagId!=0)
            view.setTag(mListName + "_" + view.getId() + "_" + tagId);
    }



/*    private void setupTagForAutomation(int tagId, String mListName) {
        viewHolder.portalAccountBoxRootRL.setTag(mListName + "_" + viewHolder.portalAccountBoxRootRL.getId() + "_" + tagId);
        viewHolder.portalBoxHeaderContainer.setTag(mListName + "_" + viewHolder.portalBoxHeaderContainer.getId() + "_" + tagId);
        viewHolder.portalBoxFooterContainer.setTag(mListName + "_" + viewHolder.portalBoxFooterContainer.getId() + "_" + tagId);
        viewHolder.cardBankErrorBox.setTag(mListName + "_" + viewHolder.cardBankErrorBox.getId() + "_" + tagId);
        viewHolder.portalBoxContentContainer1.setTag(mListName + "_" + viewHolder.portalBoxContentContainer1.getId() + "_" + tagId);
        viewHolder.portalBoxContentContainer2.setTag(mListName + "_" + viewHolder.portalBoxContentContainer2.getId() + "_" + tagId);
        viewHolder.portalBoxContentContainer3.setTag(mListName + "_" + viewHolder.portalBoxContentContainer3.getId() + "_" + tagId);
        viewHolder.portalBoxContentContainer4.setTag(mListName + "_" + viewHolder.portalBoxContentContainer4.getId() + "_" + tagId);
        viewHolder.accountTypeLabel.setTag(mListName + "_" + viewHolder.accountTypeLabel.getId() + "_" + tagId);
        viewHolder.accountLast4DigitLabel.setTag(mListName + "_" + viewHolder.accountLast4DigitLabel.getId() + "_" + tagId);
        viewHolder.accountAmoutLabel.setTag(mListName + "_" + viewHolder.accountAmoutLabel.getId() + "_" + tagId);
        viewHolder.accountTypeCaption.setTag(mListName + "_" + viewHolder.accountTypeCaption.getId() + "_" + tagId);
        viewHolder.accountFooterLeft.setTag(mListName + "_" + viewHolder.accountFooterLeft.getId() + "_" + tagId);
        viewHolder.accountFooterRight.setTag(mListName + "_" + viewHolder.accountFooterRight.getId() + "_" + tagId);
        viewHolder.accountContentLabel.setTag(mListName + "_" + viewHolder.accountContentLabel.getId() + "_" + tagId);
        viewHolder.accountContentValue.setTag(mListName + "_" + viewHolder.accountContentValue.getId() + "_" + tagId);
        viewHolder.accountContentValue.setTag(mListName + "_" + viewHolder.accountContentValue.getId() + "_" + tagId);
        viewHolder.accountContentValue1.setTag(mListName + "_" + viewHolder.accountContentValue1.getId() + "_" + tagId);
        viewHolder.accountContentValue1.setTag(mListName + "_" + viewHolder.accountContentValue1.getId() + "_" + tagId);
        viewHolder.accountContentValue1.setTag(mListName + "_" + viewHolder.accountContentValue1.getId() + "_" + tagId);
        viewHolder.accountContentLabel3.setTag(mListName + "_" + viewHolder.accountContentLabel3.getId() + "_" + tagId);
        viewHolder.accountContentValue3.setTag(mListName + "_" + viewHolder.accountContentValue3.getId() + "_" + tagId);
        viewHolder.cardBankDataErrorTextView.setTag(mListName + "_" + viewHolder.cardBankDataErrorTextView.getId() + "_" + tagId);
        viewHolder.cardBankDataErrorImage.setTag(mListName + "_" + viewHolder.cardBankDataErrorImage.getId() + "_" + tagId);
        viewHolder.bankDataErrorMessageTitle.setTag(mListName + "_" + viewHolder.bankDataErrorMessageTitle.getId() + "_" + tagId);
        viewHolder.bankDataErrorMessageSubTitle.setTag(mListName + "_" + viewHolder.bankDataErrorMessageSubTitle.getId() + "_" + tagId);
        viewHolder.view_row1.setTag(mListName + "_" + viewHolder.view_row1.getId() + "_" + tagId);
        viewHolder.view_row2.setTag(mListName + "_" + viewHolder.view_row2.getId() + "_" + tagId);
        viewHolder.accountVerifyTextView.setTag(mListName + "_" + viewHolder.accountVerifyTextView.getId() + "_" + tagId);
        viewHolder.portalBoxImageView.setTag(mListName + "_" + viewHolder.portalBoxImageView.getId() + "_" + tagId);
        viewHolder.view_account_verify.setTag(mListName + "_" + viewHolder.view_account_verify.getId() + "_" + tagId);
        viewHolder.mFraudView.setTag(mListName + "_" + viewHolder.mFraudView.getId() + "_" + tagId);
        viewHolder.mFraudAccountNo.setTag(mListName + "_" + viewHolder.mFraudAccountNo.getId() + "_" + tagId);
        viewHolder.mFraudCardTitle.setTag(mListName + "_" + viewHolder.mFraudCardTitle.getId() + "_" + tagId);
        viewHolder.accountContentLabel2.setTag(mListName + "_" + viewHolder.accountContentLabel2.getId() + "_" + tagId);
        viewHolder.accountContentLabel1.setTag(mListName + "_" + viewHolder.accountContentLabel1.getId() + "_" + tagId);
        viewHolder.accountContentValue2.setTag(mListName + "_" + viewHolder.accountContentValue2.getId() + "_" + tagId);
    }*/

    /**
     * Function to map Account data
     */
    public void mapViewWithData(PortalAccountType accountType, PortalBoxInterface dataItem, int position, String mList) {
        resetAccountBox();

        if(mList.equalsIgnoreCase("closed")){
            setClosedAccounts();
        }else {
            switch (accountType) {

                case ACCOUNT_CHECKING:
                    setupTagForAutomation(position, mList);
                    DepositAccount checkingAccountBean = (DepositAccount) dataItem;

                    // #US43080: if account is not verified then show account verify portal box.
                    if (!checkingAccountBean.getIsVerified()) {
                        setVerifyAccountPortalBox();
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(checkingAccountBean.getAcctNickName()))
                            viewHolder.accountTypeLabel.setText(checkingAccountBean.getAcctNickName());
                        else
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_checking_txt));

                        // Lst 4 digit account no
                        viewHolder.accountLast4DigitLabel.setText("(" + checkingAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                        // end of #US43080
                    } else {
                        //start of #US43080
                        resetVerifyAccountPortalBox();
                        // end of US43080
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(checkingAccountBean.getAcctNickName()))
                            viewHolder.accountTypeLabel.setText(checkingAccountBean.getAcctNickName());
                        else
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_checking_txt));

                        // Lst 4 digit account no
                        viewHolder.accountLast4DigitLabel.setText("(" + checkingAccountBean.getLastFourAcctNbr() + ")");

                        // Available balance
                        viewHolder.accountAmoutLabel.setText(PortalUtils.getAmountInFormmated(checkingAccountBean.getAvailableBalance()));
                        viewHolder.accountTypeCaption.setText(resources.getString(R.string.portal_box_available_balance_txt));

                        // Current Balance
                        viewHolder.accountContentLabel.setText(resources.getString(R.string.portal_box_current_balance_label_txt));
                        viewHolder.accountContentValue.setText(PortalUtils.getAmountInFormmated(checkingAccountBean.getCurrentBalance()));

                    // Cashback Bonus Balance
                    /*if(FacadeFactory.getPortalPageBankFacade().isBankNewCbbFlow()){*/
                        //US146267 CBB new UI with end point
                        viewHolder.accountContentLabel1.setText(Html.fromHtml(BANK_CBB_NEW_FLOW+resources.getString(R.string.portal_cashback_bonus_balance_txt)));
                    /*}else{
                        viewHolder.accountContentLabel1.setText(Html.fromHtml(resources.getString(R.string.portal_cashback_bonus_balance_txt)));
                    }*/

                    viewHolder.accountContentValue1.setText(PortalUtils.getAmountInFormmated(checkingAccountBean.getCashbackBonusBal()));

                        viewHolder.portalBoxContentContainer3.setVisibility(GONE);
                        viewHolder.portalBoxContentContainer4.setVisibility(GONE);

                        viewHolder.accountFooterLeft.setText(resources.getString(R.string.portal_deposit_a_check_link));
                        //US99424 Code start Portal Enhancements :Quicklinks:Add TransferMoney
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_transfer_money_link));
                        //US99424 Code End Portal Enhancements :Quicklinks:Add TransferMoney

                        viewHolder.view_row1.setVisibility(VISIBLE);
                        viewHolder.view_row2.setVisibility(VISIBLE);
                        viewHolder.portalBoxFooterContainer.setVisibility(VISIBLE);
                    }
                    break;

                case ACCOUNT_SAVINGS:
                    setupTagForAutomation(position, mList);
                    DepositAccount savingsAccountBean = (DepositAccount) dataItem;
                    // start of US43080
                    if (!savingsAccountBean.getIsVerified()) {
                        setVerifyAccountPortalBox();
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(savingsAccountBean.getAcctNickName()))
                            viewHolder.accountTypeLabel.setText(savingsAccountBean.getAcctNickName());
                        else
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_money_market_txt));

                        // Lst 4 digit account no
                        viewHolder.accountLast4DigitLabel.setText("(" + savingsAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                        // end of US43080
                    } else {
                        // start of US43080
                        resetVerifyAccountPortalBox();
                        // end of US43080
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(savingsAccountBean.getAcctNickName()))
                            viewHolder.accountTypeLabel.setText(savingsAccountBean.getAcctNickName());
                        else
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_money_market_txt));

                        // Lst 4 digit account no
                        viewHolder.accountLast4DigitLabel.setText("(" + savingsAccountBean.getLastFourAcctNbr() + ")");

                        // Available balance
                        viewHolder.accountAmoutLabel.setText(PortalUtils.getAmountInFormmated(savingsAccountBean.getAvailableBalance()));
                        viewHolder.accountTypeCaption.setText(resources.getString(R.string.portal_box_available_balance_txt));

                        // Current Balance
                        viewHolder.accountContentLabel.setText(resources.getString(R.string.portal_box_current_balance_label_txt));
                        viewHolder.accountContentValue.setText(PortalUtils.getAmountInFormmated(savingsAccountBean.getCurrentBalance()));

                        // Start - US86803	Android: Portal Page: Replace 'APY' with 'Interest YTD'
                        // Commenting out Current APY
                        //viewHolder.accountContentLabel1.setText(resources.getString(R.string.portal_box_current_apy_label_txt));
                        //viewHolder.accountContentValue1.setText(PortalUtils.getAPYInFormmated(savingsAccountBean.getApy()));

                        // Adding Interest YTD
                        viewHolder.accountContentLabel1.setText(resources.getString(R.string.portal_account_interest_YTD_txt));
                        viewHolder.accountContentValue1.setText(savingsAccountBean.getInterestYearToDate());
                        // End - US86803	Android: Portal Page: Replace 'APY' with 'Interest YTD'

                        viewHolder.portalBoxContentContainer3.setVisibility(GONE);
                        viewHolder.portalBoxContentContainer4.setVisibility(GONE);

                        viewHolder.accountFooterLeft.setText(resources.getString(R.string.portal_deposit_a_check_link));
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_transfer_money_link));

                        viewHolder.view_row1.setVisibility(VISIBLE);
                        viewHolder.view_row2.setVisibility(VISIBLE);
                        viewHolder.portalBoxFooterContainer.setVisibility(VISIBLE);
                    }
                    break;

                case ACCOUNT_MONEY_MARKET:
                    setupTagForAutomation(position, mList);
                    DepositAccount mmAccountBean = (DepositAccount) dataItem;
// start of US43080
                    if (!mmAccountBean.getIsVerified()) {
                        setVerifyAccountPortalBox();
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(mmAccountBean.getAcctNickName()))
                            viewHolder.accountTypeLabel.setText(mmAccountBean.getAcctNickName());
                        else
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_money_market_txt));

                        // Lst 4 digit account no
                        viewHolder.accountLast4DigitLabel.setText("(" + mmAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                        // end of US43080
                    } else {
                        // start of US43080
                        resetVerifyAccountPortalBox();
                        // end of US43080
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(mmAccountBean.getAcctNickName()))
                            viewHolder.accountTypeLabel.setText(mmAccountBean.getAcctNickName());
                        else
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_money_market_txt));

                        // Lst 4 digit account no
                        viewHolder.accountLast4DigitLabel.setText("(" + mmAccountBean.getLastFourAcctNbr() + ")");

                        // Available balance
                        viewHolder.accountAmoutLabel.setText(PortalUtils.getAmountInFormmated(mmAccountBean.getAvailableBalance()));
                        viewHolder.accountTypeCaption.setText(resources.getString(R.string.portal_box_available_balance_txt));

                        // Current Balance
                        viewHolder.accountContentLabel.setText(resources.getString(R.string.portal_box_current_balance_label_txt));
                        viewHolder.accountContentValue.setText(PortalUtils.getAmountInFormmated(mmAccountBean.getCurrentBalance()));

                        // Current APY
                        viewHolder.accountContentLabel1.setText(resources.getString(R.string.portal_box_current_apy_label_txt));
                        viewHolder.accountContentValue1.setText(PortalUtils.getAPYInFormmated(mmAccountBean.getApy()));

                        viewHolder.portalBoxContentContainer3.setVisibility(GONE);
                        viewHolder.portalBoxContentContainer4.setVisibility(GONE);

                        viewHolder.accountFooterLeft.setText(resources.getString(R.string.portal_deposit_a_check_link));
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_transfer_money_link));

                        viewHolder.view_row1.setVisibility(VISIBLE);
                        viewHolder.view_row2.setVisibility(VISIBLE);
                        viewHolder.portalBoxFooterContainer.setVisibility(VISIBLE);
                    }
                    break;

                case ACCOUNT_CD:
                    setupTagForAutomation(position, mList);
                    DepositAccount cdAccountBean = (DepositAccount) dataItem;
// start of US43080
                    if (!cdAccountBean.getIsVerified()) {
                        setVerifyAccountPortalBox();
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(cdAccountBean.getAcctNickName())) {
                            viewHolder.accountTypeLabel.setText(cdAccountBean.getAcctNickName());
                        } else {
                            viewHolder.accountTypeLabel.setText(cdAccountBean.getAcctTypeDesc());
                        }
                        // end of US43080
                        // Last 4/3 digit of account number
                        viewHolder.accountLast4DigitLabel.setText("(" + cdAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                    } else {
                        // start of US43080
                        resetVerifyAccountPortalBox();
                        // end of US43080
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(cdAccountBean.getAcctNickName())) {
                            viewHolder.accountTypeLabel.setText(cdAccountBean.getAcctNickName());
                        } else {
                            viewHolder.accountTypeLabel.setText(cdAccountBean.getAcctTypeDesc());
                        }

                        // Last 4/3 digit of account number
                        viewHolder.accountLast4DigitLabel.setText("(" + cdAccountBean.getLastFourAcctNbr() + ")");

                        // Available balance amount
                        viewHolder.accountAmoutLabel.setText(PortalUtils.getAmountInFormmated(cdAccountBean.getAvailableBalance()));
                        viewHolder.accountTypeCaption.setText(resources.getString(R.string.portal_box_available_balance_txt));

                        // Interest APR
                        viewHolder.accountContentLabel.setText(resources.getString(R.string.portal_account_interest_APY_txt));
                        viewHolder.accountContentValue.setText(PortalUtils.getAPYInFormmated(cdAccountBean.getApy()));

                        // Interest YTD
                        viewHolder.accountContentLabel1.setText(resources.getString(R.string.portal_account_interest_YTD_txt));
                        viewHolder.accountContentValue1.setText(cdAccountBean.getInterestYearToDate());

                        viewHolder.portalBoxContentContainer3.setVisibility(GONE);
                        viewHolder.portalBoxContentContainer4.setVisibility(GONE);

                        viewHolder.accountFooterLeft.setVisibility(GONE);
                        viewHolder.accountFooterRight.setVisibility(GONE);

                        viewHolder.view_row1.setVisibility(VISIBLE);
                        viewHolder.view_row2.setVisibility(GONE);
                        viewHolder.portalBoxFooterContainer.setVisibility(GONE);
                    }
                    break;

                case ACCOUNT_IRA:
                    setupTagForAutomation(position, mList);
                    IraPlan IraPlanbean = (IraPlan) dataItem;
// start of US43080
                    if (!IraPlanbean.getIsVerified()) {
                        setVerifyAccountPortalBox();
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(IraPlanbean.getAcctNickName())) {
                            viewHolder.accountTypeLabel.setText(IraPlanbean.getAcctNickName());
                        } else {
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_IRA_txt));
                        }
                        viewHolder.accountLast4DigitLabel.setText("(" + IraPlanbean.getIraAccounts().get(0).getLastFourAcctNbr() + ")");
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                        // end of US43080
                    } else {
                        // start of US43080
                        resetVerifyAccountPortalBox();
                        // end of US43080
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(IraPlanbean.getAcctNickName())) {
                            viewHolder.accountTypeLabel.setText(IraPlanbean.getAcctNickName());
                        } else {
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_IRA_txt));
                        }

                        // Last 4/3 digit of account number
                        if (IraPlanbean.getIraAccounts().size() == 1) {
                            /**start added for US46912 */
                            IraAccount iraAccountItem = IraPlanbean.getIraAccounts().get(0);
                            if (null != iraAccountItem && null != iraAccountItem.getIsVerified() && iraAccountItem.getIsVerified()) {
                                viewHolder.accountLast4DigitLabel.setText("(" + IraPlanbean.getIraAccounts().get(0).getLastFourAcctNbr() + ")");
                            } else {
                                viewHolder.accountLast4DigitLabel.setText(" ");
                            }
                            /**end added for US46912 */
                        } else {
                            viewHolder.accountLast4DigitLabel.setText(" ");
                        }

                        // Available balance amount
                        viewHolder.accountAmoutLabel.setText(PortalUtils.getAmountInFormmated(IraPlanbean.getTotalAvailableBalance()));
                        viewHolder.accountTypeCaption.setText(resources.getString(R.string.portal_box_available_balance_txt));

                        // Interest YTD
                        viewHolder.accountContentLabel.setText(resources.getString(R.string.portal_account_interest_YTD_txt));
                        viewHolder.accountContentValue.setText(IraPlanbean.getTotalInterestYearToDate());

                        viewHolder.portalBoxContentContainer2.setVisibility(GONE);
                        viewHolder.portalBoxContentContainer3.setVisibility(GONE);
                        viewHolder.portalBoxContentContainer4.setVisibility(GONE);

                        viewHolder.accountFooterLeft.setVisibility(GONE);
                        viewHolder.accountFooterRight.setVisibility(GONE);

                        viewHolder.view_row2.setVisibility(VISIBLE);
                        viewHolder.view_row1.setVisibility(GONE);
                        viewHolder.portalBoxFooterContainer.setVisibility(GONE);
                    }
                    break;

                case ACCOUNT_CREDIT_CARD:
                    setupTagForAutomation(position, mList);
                    CardAccount cardAccountBean = (CardAccount) dataItem;
// start of US43080
                    if (!cardAccountBean.getIsVerified()) {
                        setVerifyAccountPortalBox();
                        viewHolder.accountTypeLabel.setText(cardAccountBean.getCardTypeName());

                        viewHolder.accountLast4DigitLabel.setText("(" + cardAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                        // end of US43080
                    } else if (cardAccountBean.getExternalStatus().equalsIgnoreCase("A")) {
                        viewHolder.portalAccountBoxRootRL.setVisibility(View.GONE);
                        viewHolder.mFraudView.setVisibility(View.VISIBLE);
                        viewHolder.mFraudAccountNo.setText("(" + cardAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.mFraudCardTitle.setText(cardAccountBean.getCardTypeName());

                    /*TYracking Fraud Card Account for the SSO User*/
                        HashMap<String, Object> portalPageFraudAcc = new HashMap<String, Object>();
                        portalPageFraudAcc.put("my.prop10", getResources().getString(R.string.fraud_portal_tile_text));
                        portalPageFraudAcc.put("my.list1", getResources().getString(R.string.fraud_portal_tile_text));
                        //      TrackingHelper.trackCardPage(AnalyticsPage.ANDROID_HS_CLI_ENTER_INFORMATION, portalPageFraudAcc);
                    } else {
                        // start of US43080
                        resetVerifyAccountPortalBox();
                        // end of US43080
                        viewHolder.accountTypeLabel.setText(cardAccountBean.getCardTypeName());

                        viewHolder.accountLast4DigitLabel.setText("(" + cardAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.accountAmoutLabel.setText(PortalUtils.getAmountInFormmated(cardAccountBean.getCurrentBalance()));
                        viewHolder.accountTypeCaption.setText(resources.getString(R.string.portal_current_balance_txt));

                        viewHolder.accountContentLabel.setText(resources.getString(R.string.portal_credit_available_txt));
                        String totalCreditLineString = formatAmountWithoutDecimal(cardAccountBean.getAvailableCredit())
                                + " of " + formatAmountWithoutDecimal(cardAccountBean.getCreditLimit());
                        viewHolder.accountContentValue.setText(totalCreditLineString);

                        viewHolder.accountContentLabel1.setText(resources.getString(R.string.portal_payment_recieved_txt) + " " + getPaymentDateInForamt(cardAccountBean.getLastPaymentDate()));
                        viewHolder.accountContentValue1.setTextColor(resources.getColor(R.color.portal_box_payment_value_green_color));
                        viewHolder.accountContentValue1.setText(PortalUtils.getAmountInFormmated(cardAccountBean.getLastPaymentAmount()));

                        viewHolder.accountContentLabel2.setText(resources.getString(R.string.portal_payment_due_txt) + " " + getPaymentDateInForamt(cardAccountBean.getPaymentDueDate()));
                        viewHolder.accountContentValue2.setText(PortalUtils.getAmountInFormmated(cardAccountBean.getMinimumPaymentDue()));

                        if (isCardMiles(cardAccountBean.getCardProductGroupCode())) {
                            viewHolder.accountContentLabel3.setText(Html.fromHtml(resources.getString(R.string.portal_miles_balance_txt)));
                            String milesBalance = PortalUtils.getMilesBalanceFormmated(cardAccountBean.getEarnRewardAmount());
                            viewHolder.accountContentValue3.setText(milesBalance);
                        } else {
                            viewHolder.accountContentLabel3.setText(Html.fromHtml(resources.getString(R.string.portal_cashback_bonus_balance_txt)));
                            viewHolder.accountContentValue3.setText(PortalUtils.getAmountInFormmated(cardAccountBean.getEarnRewardAmount()));
                        }

                        //moved it to PortalPageListFragment - US70118
                        AccountV2Details accountV2Details = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
                        if (accountV2Details != null && !(accountV2Details.getCardAccountsMap().size() == 1)) {
                            if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOWOLDFICO) {
                                viewHolder.accountFooterLeft.setText(Html.fromHtml(resources.getString(R.string.portal_fico_credit_score_link)));
                            } else if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOW_FICO_SCORECARD) {
                                viewHolder.accountFooterLeft.setVisibility(View.GONE);
                            } else if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOWNOFICO) {
                                viewHolder.accountFooterLeft.setVisibility(View.GONE);
                            }
                        } else {
                            viewHolder.accountFooterLeft.setVisibility(View.GONE);
                        }
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_make_a_payment_link));

                        viewHolder.view_row1.setVisibility(VISIBLE);
                        viewHolder.view_row2.setVisibility(VISIBLE);
                        viewHolder.portalBoxFooterContainer.setVisibility(VISIBLE);
                    }
                    break;

                case ACCOUNT_LOAN:
                    setupTagForAutomation(position, mList);
                    LoanAccount loanAccountBean = (LoanAccount) dataItem;
// start of US43080
                    if (!loanAccountBean.getIsVerified()) {
                        setVerifyAccountPortalBox();
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(loanAccountBean.getAcctNickName()))

                            viewHolder.accountTypeLabel.setText(loanAccountBean.getAcctNickName());
                        else {
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_personal_loan_txt));
                        }

                        // Last 4 digit of account number
                        viewHolder.accountLast4DigitLabel.setText("(" + loanAccountBean.getLastFourAcctNbr() + ")");
                        viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                        // end of US43080
                    } else {
                        // start of US43080
                        resetVerifyAccountPortalBox();
                        // end of US43080
                        // Account Name
                        if (!PortalUtils.isStrFieldEmpty(loanAccountBean.getAcctNickName()))

                            viewHolder.accountTypeLabel.setText(loanAccountBean.getAcctNickName());
                        else {
                            viewHolder.accountTypeLabel.setText(resources.getString(R.string.portal_account_personal_loan_txt));
                        }

                        // Last 4 digit of account number
                        viewHolder.accountLast4DigitLabel.setText("(" + loanAccountBean.getLastFourAcctNbr() + ")");

                        // balance amount in header
                        viewHolder.accountAmoutLabel.setText(PortalUtils.getAmountInFormmated(loanAccountBean.getCurrentBalance()));
                        viewHolder.accountTypeCaption.setText(resources.getString(R.string.portal_box_current_balance_label_txt).toLowerCase(Locale.getDefault()));

                        // Balance as a row item
                        viewHolder.accountContentLabel.setText(resources.getString(R.string.portal_box_minimum_payment_txt));
                        viewHolder.accountContentValue.setText(PortalUtils.getAmountInFormmated(loanAccountBean.getCurrentAmountDue()));

                        // Payment Received
                        viewHolder.accountContentLabel1.setText(resources.getString(R.string.portal_box_payment_due_date_txt));
                        viewHolder.accountContentValue1.setText(getPaymentDateInForamt(loanAccountBean.getNextPymtDueDate()));

                        viewHolder.portalBoxContentContainer3.setVisibility(GONE);
                        viewHolder.portalBoxContentContainer4.setVisibility(GONE);

                        viewHolder.accountFooterLeft.setText(resources.getString(R.string.portal_pay_loans_link));
                        viewHolder.accountFooterRight.setVisibility(GONE);

                        viewHolder.view_row1.setVisibility(VISIBLE);
                        viewHolder.view_row2.setVisibility(VISIBLE);
                        viewHolder.portalBoxFooterContainer.setVisibility(VISIBLE);
                    }
                    break;

                case ACCOUNT_CREDIT_CARD_ERROR:
                    setupTagForAutomation(position, mList);
                    viewHolder.portalAccountBoxRootRL.setVisibility(View.GONE);
                    viewHolder.cardBankErrorBox.setVisibility(View.VISIBLE);
                    String cardBoxErrorText = InfoMessageUtils.Instance().getErrorMessage("card_box_error_text");
                /*Defect fixed: 7606*/
                    if (!CommonUtils.isNullOrEmpty(cardBoxErrorText)) {
                        viewHolder.cardBankDataErrorTextView.setText(cardBoxErrorText);
                    } else {
                        viewHolder.cardBankDataErrorTextView.setText(mContext.getString(R.string.portal_page_card_data_error_text));
                    }
                    break;
                case ACCOUNT_BANK_ERROR:
                    setupTagForAutomation(position, mList);
                    viewHolder.portalAccountBoxRootRL.setVisibility(View.GONE);
                    viewHolder.cardBankErrorBox.setVisibility(View.VISIBLE);

                    AccountV2Details accountV2Details = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
                    if (!accountV2Details.isErrorRetrievingBankData() &&
                            (accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSINVALID) || (accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSERROR)))) {

                        if (CommonUtils.isRunningOnHandset(mContext)) {

                            displayBankErrorMessagePortal();

                        } else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                            if (accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSINVALID) || (accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSERROR))) {

                                viewHolder.cardBankDataErrorImage.setVisibility(View.GONE);
                                viewHolder.bankDataErrorMessageTitle.setVisibility(View.VISIBLE);
                                viewHolder.bankDataErrorMessageSubTitle.setVisibility(View.VISIBLE);
                                viewHolder.cardBankDataErrorTextView.setVisibility(View.GONE);

                                viewHolder.bankDataErrorMessageSubTitle.setText(R.string.portal_page_bank_data_bad_customer_text);
                            }
                        } else {
                            displayBankErrorMessagePortal();
                        }

                    } else {
                        String bankBoxErrorText = InfoMessageUtils.Instance().getErrorMessage("bank_box_error_text");
                        if (!CommonUtils.isNullOrEmpty(bankBoxErrorText)) {
                            viewHolder.cardBankDataErrorTextView.setText(bankBoxErrorText);
                        } else {
                            viewHolder.cardBankDataErrorTextView.setText(mContext.getString(R.string.portal_page_bank_data_error_text));
                        }
                    }

                    break;
                case ACCOUNT_BANK_VERIFY:
                    setupTagForAutomation(position, mList);
                    setVerifyAccountPortalBox();
                    viewHolder.accountTypeLabel.setText("Discover Bank");
                    viewHolder.accountLast4DigitLabel.setText("");
                    viewHolder.accountFooterRight.setText(resources.getString(R.string.portal_box_account_verify_link));
                    break;
                default:
                    break;
            }
        }
    }

    private void setClosedAccounts(){
        viewHolder.accountLast4DigitLabel.setVisibility(View.GONE);
        viewHolder.accountAmoutLabel.setVisibility(View.GONE);
        viewHolder.accountTypeCaption.setVisibility(View.GONE);
        viewHolder.accountFooterRight.setVisibility(View.GONE);
        viewHolder.portalBoxImageView.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer1.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer2.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer3.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer4.setVisibility(View.GONE);
        viewHolder.portalAccountBoxRootRL.setVisibility(View.VISIBLE);
        viewHolder.accountTypeLabel.setVisibility(View.VISIBLE);
        viewHolder.portalBoxFooterContainer.setVisibility(View.VISIBLE);
        viewHolder.portalBoxHeaderContainer.setVisibility(View.VISIBLE);
        viewHolder.accountFooterLeft.setVisibility(View.VISIBLE);

        //Start - US146278	Portal page UI alignment
        RelativeLayout.LayoutParams layoutParams =
                (RelativeLayout.LayoutParams) viewHolder.accountTypeLabel.getLayoutParams();
        layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        viewHolder.accountTypeLabel.setLayoutParams(layoutParams);
        //End - US146278	Portal page UI alignment

        viewHolder.accountTypeLabel.setText(R.string.portal_page_closed_acct_txt);
        viewHolder.accountFooterLeft.setText(R.string.portal_page_closed_acct_nav_txt);
    }

    /*
     set UI for account verify portal box #US43080
     */
    private void setVerifyAccountPortalBox() {
        setVerifyAccountContactLink();
        viewHolder.accountVerifyTextView.setContentDescription(mContext.getString(R.string.portal_box_account_verify_txt));
        viewHolder.accountVerifyTextView.setVisibility(View.VISIBLE);
        viewHolder.view_account_verify.setVisibility(View.VISIBLE);
        viewHolder.portalBoxImageView.setVisibility(View.INVISIBLE);
        viewHolder.portalBoxFooterContainer.setVisibility(VISIBLE);
        viewHolder.accountAmoutLabel.setVisibility(View.GONE);
        viewHolder.accountTypeCaption.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer1.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer2.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer3.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer4.setVisibility(View.GONE);
        // Landscape mode login app crashing
        if(viewHolder.mFraudView!=null) {
            viewHolder.mFraudView.setVisibility(View.GONE);
        }
        viewHolder.accountFooterLeft.setVisibility(View.GONE);
    }

    /*
     set contact link in description for account verify portal box. #US43080
     */
    private void setVerifyAccountContactLink() {
        if (Utils.isRunningOnHandset(mContext)) {
            SpannableString str = new SpannableString(mContext.getString(R.string.portal_box_account_verify_txt));
            viewHolder.accountVerifyTextView.setBackgroundColor(getResources().getColor(R.color.transparent));
            int fullLength = (mContext.getString(R.string.portal_box_account_verify_txt)).length();
            str.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.verify_account_contact_link)), 122, fullLength - 1, 0);
            viewHolder.accountVerifyTextView.setText(str);
            viewHolder.accountVerifyTextView.setLinkTextColor(mContext.getResources().getColor(R.color.blue_link));
            Linkify.addLinks(viewHolder.accountVerifyTextView, Linkify.PHONE_NUMBERS);
            viewHolder.accountVerifyTextView.setMovementMethod(LinkMovementMethod.getInstance());
            stripUnderlines();
            String[] bits = viewHolder.accountVerifyTextView.getText().toString().split(" ");
            final String lastOne = bits[bits.length - 1];
            ClickableSpan clickableSpan = new ClickableSpan() {
                @Override
                public void onClick(View view) {
                    CommonUtils.dialNumber(lastOne, mContext);
                }
            };

            str.setSpan(clickableSpan, 122, fullLength - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        } else {
            viewHolder.accountVerifyTextView.setText(mContext.getString(R.string.portal_box_account_verify_txt));
        }


    }

    /**
     * Removes Underline of hyperlinked TextView
     *
     * @param textView TextView to remove underline
     */
    private void stripUnderlines() {
        if (!(viewHolder.accountVerifyTextView.getText() instanceof Spannable)) {
            return;
        }
        Spannable s = (Spannable) viewHolder.accountVerifyTextView.getText();
        URLSpan[] spans = s.getSpans(0, s.length(), URLSpan.class);
        for (URLSpan span : spans) {
            int start = s.getSpanStart(span);
            int end = s.getSpanEnd(span);
            s.removeSpan(span);
            span = new URLSpanNoUnderline(span.getURL());
            s.setSpan(span, start, end, 0);
        }
        viewHolder.accountVerifyTextView.setText(s);
    }

    /*
     reset UI items for account verify and other portal box #US43080
     */
    private void resetVerifyAccountPortalBox() {
        setAccountPortalBoxViewVisibility(viewHolder.accountVerifyTextView, View.GONE);
        setAccountPortalBoxViewVisibility(viewHolder.view_account_verify, View.GONE);
        setAccountPortalBoxViewVisibility(viewHolder.portalBoxImageView, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.accountAmoutLabel, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.accountTypeCaption, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.portalBoxContentContainer1, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.portalBoxContentContainer2, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.portalBoxContentContainer3, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.portalBoxContentContainer4, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.accountFooterLeft, View.VISIBLE);
        setAccountPortalBoxViewVisibility(viewHolder.mFraudView, View.GONE);

    }

    void setAccountPortalBoxViewVisibility(View view, int visibility) {
        if (view != null)
            view.setVisibility(visibility);
    }

    public boolean isCardMiles(String cardProductGroupCode) {
        if (!PortalUtils.isStrFieldEmpty(cardProductGroupCode)) {
            if (cardProductGroupCode.equalsIgnoreCase("MLS") || cardProductGroupCode.equalsIgnoreCase("DIM"))
                return true;
            else
                return false;
        } else
            return false;
    }

    public void resetAccountBox() {
        // reset color first
        viewHolder.accountContentValue1.setTextColor(resources.getColor(R.color.portal_box_item_label_color));

        viewHolder.portalAccountBoxRootRL.setVisibility(View.VISIBLE);
        viewHolder.cardBankErrorBox.setVisibility(View.GONE);
        viewHolder.portalBoxContentContainer1.setVisibility(View.VISIBLE);
        viewHolder.portalBoxContentContainer2.setVisibility(View.VISIBLE);
        viewHolder.portalBoxContentContainer3.setVisibility(View.VISIBLE);
        viewHolder.portalBoxContentContainer4.setVisibility(View.VISIBLE);

        viewHolder.accountFooterLeft.setVisibility(View.VISIBLE);
        viewHolder.accountFooterRight.setVisibility(View.VISIBLE);

        viewHolder.cardBankDataErrorImage.setVisibility(View.VISIBLE);
        viewHolder.bankDataErrorMessageTitle.setVisibility(View.GONE);
        viewHolder.bankDataErrorMessageSubTitle.setVisibility(View.GONE);
        viewHolder.cardBankDataErrorTextView.setVisibility(View.VISIBLE);
    }

    /**
     * Method to convert date from format (MMddyyyy) & mm/dd/yy to "Mon dd"
     * format
     */
    @SuppressLint("SimpleDateFormat")
    public String getPaymentDateInForamt(String inDateStr) {
        if (!PortalUtils.isStrFieldEmpty(inDateStr)) {
            if (inDateStr.contains("/"))
                inDateStr = inDateStr.replace("/", "");

            String month = inDateStr.substring(0, 2);
            String day = inDateStr.substring(2, 4);
            String year = inDateStr.substring(4, inDateStr.length());

            String properdate = month + "/" + day + "/" + year;
            @SuppressWarnings("deprecation")
            Date date = new Date(properdate);
            SimpleDateFormat formatter = new SimpleDateFormat("MMM dd");
            String finaldate = formatter.format(date);
            return finaldate;
        }
        return "";
    }

    public TextView getLeftDeepLink() {
        if (null != viewHolder.accountFooterLeft && viewHolder.accountFooterLeft.getVisibility() == View.VISIBLE)
            return viewHolder.accountFooterLeft;
        else
            return null;
    }

    public TextView getRightDeepLink() {
        if (null != viewHolder.accountFooterRight && viewHolder.accountFooterRight.getVisibility() == View.VISIBLE)
            return viewHolder.accountFooterRight;
        else
            return null;
    }

    public RelativeLayout getAccountBoxRoot() {
         RelativeLayout viewToBeClicked = null;
        /*Case when the account is a normal account*/
        if(viewHolder.portalAccountBoxRootRL.getVisibility()== View.VISIBLE)
        {
            viewToBeClicked = viewHolder.portalAccountBoxRootRL;
        }
        /*Case when the account is a fraud account*/
        else if(viewHolder.mFraudView.getVisibility() == View.VISIBLE)
            viewToBeClicked = viewHolder.mFraudView;

        return viewToBeClicked;
    }

    /**
     * Method to set text on the bank box on portal page.
     */
    private void displayBankErrorMessagePortal() {
        viewHolder.cardBankDataErrorImage.setVisibility(View.GONE);
        viewHolder.bankDataErrorMessageTitle.setVisibility(View.VISIBLE);
        viewHolder.bankDataErrorMessageSubTitle.setVisibility(View.VISIBLE);
        viewHolder.cardBankDataErrorTextView.setVisibility(View.GONE);

        String errorString = getResources().getString(R.string.portal_page_bank_data_bad_customer_text);
        SpannableString errorSpannableString = new SpannableString(errorString);
        if (Utils.isRunningOnHandset(mContext)) {
            final String phoneNumber = errorString.substring(errorString.length() - 15, errorString.length()-1);

            ClickableSpan clickableTextSpan = new ClickableSpan() {
                @Override
                public void onClick(View textView) {
                    CommonUtils.dialNumber(phoneNumber, mContext);
                }
            };
            errorSpannableString.setSpan(clickableTextSpan, (errorSpannableString.length() - 15), errorSpannableString.length()-1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            viewHolder.bankDataErrorMessageSubTitle.setMovementMethod(LinkMovementMethod.getInstance());
        }
        viewHolder.bankDataErrorMessageSubTitle.setText(errorSpannableString);
    }

    public static class PortalAccountListItemViewHolder {
        public RelativeLayout portalAccountBoxRootRL;
        public RelativeLayout portalBoxHeaderContainer;
        public RelativeLayout portalBoxContentContainer1;
        public RelativeLayout portalBoxFooterContainer;
        public RelativeLayout cardBankErrorBox;

        public RelativeLayout portalBoxContentContainer2;
        public RelativeLayout portalBoxContentContainer3;
        public RelativeLayout portalBoxContentContainer4;

        // Header item initialization
        public TextView accountTypeLabel;
        public TextView accountLast4DigitLabel;
        public TextView accountAmoutLabel;
        public TextView accountTypeCaption;

        // Footer item initialization
        public TextView accountFooterLeft;
        public TextView accountFooterRight;

        public TextView accountContentLabel;
        public TextView accountContentValue;

        public TextView accountContentLabel1;
        public TextView accountContentValue1;

        public TextView accountContentLabel2;
        public TextView accountContentValue2;

        public TextView accountContentLabel3;
        public TextView accountContentValue3;

        public TextView cardBankDataErrorTextView;
        public ImageView cardBankDataErrorImage;
        public TextView bankDataErrorMessageTitle;
        public TextView bankDataErrorMessageSubTitle;

        public View view_row1;
        public View view_row2;

        //#US43080 item initialization for account verify portal box
        public TextView accountVerifyTextView;
        public ImageView portalBoxImageView;
        public View view_account_verify;
        public RelativeLayout mFraudView;
        public TextView mFraudAccountNo;
        public TextView mFraudCardTitle;
    }

    /**
     * Span Class to not display underline
     * #US43080
     */
    private class URLSpanNoUnderline extends URLSpan {

        public URLSpanNoUnderline(String url) {
            super(url);
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            ds.setUnderlineText(false);
        }
    }

    private String formatAmountWithoutDecimal(String source) {
        if (!TextUtils.isEmpty(source)) {

            DecimalFormat numberFormatter = new DecimalFormat("#,###");
            numberFormatter.setMinimumFractionDigits(0);
            if (source.contains("$")) {
                source = source.replace("$", "");
            }
            if (source.contains(",")) {
                source = source.replace(",", "");
            }
            source = numberFormatter.format(Double.parseDouble(source));
            source = "$" + source;
        } else {
            source = "--";
        }

        return source;
    }
}
