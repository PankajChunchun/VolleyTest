package com.discover.mobile.common.login.helper;

import com.discover.mobile.common.services.PushNotificationService;

import android.content.Context;

/**
 * A helper class to start the PushNotificationService w which in turn will receive the Push alerts
 * Moved from a facade call to a helper class . Since the facade call was being made from common and
 * PushNotificationService
 * is also in common so there is no need for a facade implementation.
 */
public class PushServiceHelper {

    public static void startXtifySDK(final Context callingActivity) {
        new PushNotificationService().start(callingActivity);

    }
}
