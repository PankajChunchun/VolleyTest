package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by 467649 on 3/27/2017.
 */

public class DynamicBannerMessagesTMRest extends DynamicMessageBean implements Serializable {


}
