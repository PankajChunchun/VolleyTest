package com.discover.mobile.common.help;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.appupdate.ui.ShowHighlightedFeatureActivity;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.highlightedfeatures.utils.HFConstants;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class HelpActivity extends ActionBarBaseActivity implements
        OnClickListener, ErrorHandlerUi {


    private static final String SHOW_HIGHLIGHTED = "SHOW_HIGHLIGHTED";
    public static boolean iscardReRegartionModel = false;
    public TextView privacy_terms;
    public TextView provide_feedback_button;
    public TextView customer_service_register_now;
    public TextView customer_service_menu_contact;
    public TextView customer_service_menu_features;
    public TextView help_footer;
    TextView provideFeedback;
    TextView privacyTerms;
    //Added in 7.1 - George -start
    private View dividerBelowHightlight;
    //Added in 7.1 - George -end
    private boolean cardMode;
    private boolean highlightedFeatureAvailable;
    private boolean showHighlightedFeatures = false, isSSOAndPasscodeEnabled = false;
    private Bundle bundle;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if(com.discover.mobile.common.Utils.checkPermissionTampering(this)){
            return;
        }
        /**Defect:1268 - End**/
        bundle = getIntent().getExtras();
        cardMode = getIntent().getBooleanExtra("IS_CARD_SELECTED", true);
        highlightedFeatureAvailable = getIntent().getBooleanExtra("HIGHLIGHTED_FEATURE_AVAILABLE", true);
        isSSOAndPasscodeEnabled = getIntent().getBooleanExtra("SSO_AND_PASSCODE_ENABLED", false);
//		setBehindContentView(getBehindContentView());

        setContentView(R.layout.help_menu_layout);
//		disableMenu();
        showBackX();

        DiscoverActivityManager.setActiveActivity(this);
        setUpButton();
        setupMenu();

    }

    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }

    @Override
    protected void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        //US50217 : Show Highlighted features for sso user with passcode enabled and for non-sso user in card toggle
        if (isSSOAndPasscodeEnabled || (highlightedFeatureAvailable && cardMode)) {
            customer_service_menu_features.setVisibility(View.VISIBLE);
            //Added in 7.1 - George
            dividerBelowHightlight.setVisibility(View.VISIBLE);
        }
        //US50217 : Remove HighlightedFeature for non-sso user in Bank toggle
        else {
            customer_service_menu_features.setVisibility(View.GONE);
            //Added in 7.1 - George
            dividerBelowHightlight.setVisibility(View.GONE);
        }
    }


    private void setUpButton() {
        // TODO Auto-generated method stub
        customer_service_register_now = (TextView) findViewById(R.id.customer_service_register_now);
        customer_service_menu_contact = (TextView) findViewById(R.id.customer_service_menu_contact);
        customer_service_menu_features = (TextView) findViewById(R.id.customer_service_menu_features);
        provideFeedback = (TextView) findViewById(R.id.provide_feedback_button);
        provideFeedback.setOnClickListener(this);
        privacyTerms = (TextView) findViewById(R.id.privacy_terms);
        privacyTerms.setOnClickListener(this);
        //Added in 7.1 - George
        dividerBelowHightlight = findViewById(R.id.customer_service_menu_features_divider);
        //Added in 7.1 - George
    }

    // All menu items will be handled by a single listener
    private void setupMenu() {
        LinearLayout menu = (LinearLayout) findViewById(R.id.customer_service_menu_list);
        for (int i = 0; i < menu.getChildCount(); i++) {
            menu.getChildAt(i).setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.customer_service_menu_contact) {
            // Send the user to the contacts fragment
            //BankConductor.navigateToContactUs(ContactUsType.ALL, cardMode);
            FacadeFactory.getBankLoginFacade().navigateToContactUs(
                    cardMode);

        } else if (id == R.id.customer_service_register_now) {
            final Activity currentActivity = DiscoverActivityManager.getActiveActivity();
            FacadeFactory.getCardFacade().navToRegisterFromHelp((DiscoverBaseActivity) currentActivity);
        } else if (id == R.id.customer_service_menu_features) {
            final Activity currentActivity = DiscoverActivityManager.getActiveActivity();
            TrackingHelper.trackCardPageProp1(AnalyticsPage.HF_CS_MENU_CLICK, AnalyticsPage.HF_CS_MENU_CLICK);
            // US45209 Changes starts
            // FacadeFactory.getHighlightedFeaturesFacade().getPreloginHighlightedFeaturesActivity(currentActivity, null, null);
            final Intent intent = new Intent(currentActivity, ShowHighlightedFeatureActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt(HFConstants.Args.PAGER_LOCATION, 0);
            bundle.putBoolean(HFConstants.Args.WHATS_NEW_FLAG, false);
            bundle.putBoolean(HFConstants.Args.PRE_LOGIN_FLAG, true);
            bundle.putSerializable(HFConstants.Args.LOGIN_TYPE, HFConstants.LoginType.CARD);
            bundle.putBoolean(ShowHighlightedFeatureActivity.GO_BACK_TO_LOGIN, false);
            bundle.putBoolean(ShowHighlightedFeatureActivity.GO_BACK_TO_LOGIN, false);
            intent.putExtras(bundle);
            currentActivity.startActivity(intent);
            // US45209 Changes end

        } else if (id == R.id.provide_feedback_button) {
            startFeedbackView();
        } else if (id == R.id.privacy_terms) {
            if (cardMode) {
                FacadeFactory.getCardFacade().navToPrivacyTerms(HelpActivity.this);
            } else {
                FacadeFactory.getBankLoginFacade().openPrivacyAndTerms();
            }
        }

    }


    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putBoolean(SHOW_HIGHLIGHTED, showHighlightedFeatures);
    }

    @Override
    public void onResume() {
        super.onResume();
//		disableMenu();
        setActionBarTitle(R.string.customer_service_menu_help_title, false);
        showBackX();
        if (iscardReRegartionModel) {
            finish();
            iscardReRegartionModel = false;
        }
    }

    @Override
    public TextView getErrorLabel() {
        return null;
    }

    @Override
    public List<EditText> getInputFields() {
        return null;
    }

    @Override
    public void showCustomAlert(AlertDialog alert) {

    }

    @Override
    public void showOneButtonAlert(int title, int content, int buttonText) {

    }

    @Override
    public void showDynamicOneButtonAlert(int title, String content, int buttonText) {

    }

    @Override
    public Context getContext() {
        return null;
    }

    @Override
    public int getLastError() {
        return 0;
    }

    @Override
    public void setLastError(int errorCode) {

    }

    @Override
    public ErrorHandler getErrorHandler() {
        return null;
    }

    /**
     * Commented as this was an overridden function from LoggedinRoboActivity.java
     * which is not extending this class
     */
/*
    @Override
	public int getBehindContentView() {
		return R.layout.default_content_view;
	}
*/
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private void startFeedbackView() {
        TrackingHelper.trackCardPageProp1(
                AnalyticsPage.HF_CUSTOMER_SERVICE_CLICK,
                AnalyticsPage.HF_CUSTOMER_SERVICE_CLICK);

        // TODO need to check if it is card or bank

        if (cardMode) {
            FacadeFactory.getCardFacade().navToProvideFeedback(
                    DiscoverActivityManager.getActiveActivity());
        } else {
            FacadeFactory.getBankLoginFacade().navigateToFeedback();
        }
        // Call to bank side

        // Call to card side

    }

    public void showBackX() {
        setActionbarBackNavigation(null);
		/*backButton.setVisibility(View.VISIBLE);
		navigationToggle.setVisibility(View.GONE);
		gradientLine.setVisibility(View.VISIBLE);*/
    }

}
