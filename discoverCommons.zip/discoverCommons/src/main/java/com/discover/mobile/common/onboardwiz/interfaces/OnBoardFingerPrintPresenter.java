package com.discover.mobile.common.onboardwiz.interfaces;

/**
 * Created by 436645 on 11/1/2016.
 */
public interface OnBoardFingerPrintPresenter {

    void enableFingerPrint();
    void exitSetUp();
    void onPageChanged();
}

