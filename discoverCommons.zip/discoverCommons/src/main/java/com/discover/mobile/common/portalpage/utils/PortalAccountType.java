package com.discover.mobile.common.portalpage.utils;

/**
 * Used to identify different types of account's used on portal page
 *
 * @author slende
 */
public enum PortalAccountType {
    ACCOUNT_CHECKING,
    ACCOUNT_SAVINGS,
    ACCOUNT_MONEY_MARKET,
    ACCOUNT_CD,
    ACCOUNT_CREDIT_CARD,
    ACCOUNT_IRA,
    ACCOUNT_LOAN,
    ACCOUNT_CREDIT_CARD_ERROR,
    ACCOUNT_BANK_ERROR,
    ACCOUNT_BANK_VERIFY
}
