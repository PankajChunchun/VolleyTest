package com.discover.mobile.common.fico.bean;

import com.discover.mobile.common.fico.interfaces.CmnFicoListItemInterface;

/**
 * Class to hold data for Fico list item
 *
 * @author slende
 */
public class CmnFicoListItemBean implements CmnFicoListItemInterface {

    private String ficoScoreDate;
    private int ficoScore;
    private boolean hasScore;
    private FicoScoreList ficoScoreListItem;

    public String getFicoScoreDate() {
        return ficoScoreDate;
    }

    public void setFicoScoreDate(String ficoScoreDate) {
        this.ficoScoreDate = ficoScoreDate;
    }

    public int getFicoScore() {
        return ficoScore;
    }

    public void setFicoScore(int ficoScore) {
        this.ficoScore = ficoScore;
    }

    public boolean isHasScore() {
        return hasScore;
    }

    public void setHasScore(boolean hasScore) {
        this.hasScore = hasScore;
    }

    public FicoScoreList getFicoScoreListItem() {
        return ficoScoreListItem;
    }

    public void setFicoScoreListItem(FicoScoreList ficoScoreListItem) {
        this.ficoScoreListItem = ficoScoreListItem;
    }


}
