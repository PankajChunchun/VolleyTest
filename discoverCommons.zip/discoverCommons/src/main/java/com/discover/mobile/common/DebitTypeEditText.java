package com.discover.mobile.common;

import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.StringUtility;

/**
 * US129546 Common component debit card 16 digit
 * This method is to  create text view for debit card details
 */
public class DebitTypeEditText implements EditTextStrategy {
    private static final int DEBIT_LENGTH = 19;
    private static final int DEBIT_FIRST = 4;
    private static final int DEBIT_SECOND = 8;
    private static final int DEBIT_THIRD = 12;
    private static final String DEBIT_CARD_NO = "6011";

    //returns the proper formatted string with hyphen if needed
    @Override
    public String textChange(String currentInput) {
        String formattedInput = "";
        formattedInput = CommonUtils.getDashlessString(currentInput);
        formattedInput = addHyphenAtIndex(formattedInput);
        return formattedInput;
    }

    @Override
    public String postTextChange(String currentInput) {
        return currentInput;
    }

    //adds a hyphen after the every four digit
    private String addHyphenAtIndex(String formattedInput) {
        if (formattedInput.length() > DEBIT_FIRST && formattedInput.length() <= DEBIT_SECOND) {
            formattedInput = formattedInput.substring(0, DEBIT_FIRST)
                    + StringUtility.DASH + formattedInput.substring(DEBIT_FIRST);
        } else if (formattedInput.length() > DEBIT_SECOND && formattedInput.length() <= DEBIT_THIRD) {
            formattedInput = formattedInput.substring(0, DEBIT_FIRST) + StringUtility.DASH
                    + formattedInput.substring(DEBIT_FIRST, DEBIT_SECOND) + StringUtility.DASH
                    + formattedInput.substring(DEBIT_SECOND);
        } else if (formattedInput.length() > DEBIT_THIRD) {
            formattedInput = formattedInput.substring(0, DEBIT_FIRST) + StringUtility.DASH
                    + formattedInput.substring(DEBIT_FIRST, DEBIT_SECOND) + StringUtility.DASH
                    + formattedInput.substring(DEBIT_SECOND, DEBIT_THIRD) + StringUtility.DASH
                    + formattedInput.substring(DEBIT_THIRD);
        }
        return formattedInput;
    }

    //checks if the length of the string is the right amount and text starts with 6011
    @Override
    public Boolean textCheck(int length, String currentInput) {
        if (length == DEBIT_LENGTH && currentInput.startsWith(DEBIT_CARD_NO)) {
            return true;
        } else {
            return false;
        }
    }
}
