package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.common.shared.Struct;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LoginErrorBean extends ErrorResponseDetails {
    private static final long serialVersionUID = 3948651484045640981L;
    @SerializedName("data")
    private List<Data> data = new ArrayList<Data>();

    /**
     * @return The data
     */
    public List<Data> getData() {
        return data;
    }

    /**
     * @param data The data
     */
    public void setData(List<Data> data) {
        this.data = data;
    }

    @Struct
    public static class Data implements Serializable {
        private static final long serialVersionUID = -2250939655848753565L;
        @SerializedName("isTempLocked")
        private boolean isTempLocked;

        public final boolean isTempLocked() {
            return isTempLocked;
        }

        public final void setTempLocked(boolean isTempLocked) {
            this.isTempLocked = isTempLocked;
        }

    }
}