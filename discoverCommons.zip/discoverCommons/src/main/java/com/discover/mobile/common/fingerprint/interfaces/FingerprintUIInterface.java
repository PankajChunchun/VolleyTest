package com.discover.mobile.common.fingerprint.interfaces;

/**
 * UI Interface implemented by {@link com.discover.mobile.common.fingerprint.ui.FingerPrintSetupFragment}
 * . used to get callbacks
 * to update the UI
 */
public interface FingerprintUIInterface {
    void updateUI(boolean toggleState);

    void updateUI(boolean isSuccess, String passcode);

    void onToggleStateChanged(boolean toggleState);

    void showDialog(int type);

    void showInvalidPasscodeBanner();

    void navigateTo(int type);
}
