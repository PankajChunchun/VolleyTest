package com.discover.mobile.common.ui.modals;

import com.discover.mobile.common.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.RelativeLayout;

/**
 * Custom single bottom button for a modal view.
 *
 * @author scottseward
 * @deprecated use a SimpleContentModal instead - these modals wrap the current method calls at the
 * moment.
 */
@Deprecated
public class ModalDefaultOneButtonBottomView extends RelativeLayout implements ModalBottomOneButtonView {

    /** The main call to action button in the bottom center of the dialog */
    private Button mainCallToActionButton;

    public ModalDefaultOneButtonBottomView(final Context context, final AttributeSet attrs) {
        super(context, attrs);

        final RelativeLayout buttonView = (RelativeLayout) LayoutInflater.from(context)
                .inflate(R.layout.modal_default_one_button_bottom, null);

        mainCallToActionButton = (Button) buttonView.findViewById(R.id.button);
        addView(buttonView);
    }

    /** Return the button so that a click listener can be added to it */
    @Override
    public Button getButton() {
        return mainCallToActionButton;
    }

    /**
     * Set the text of the button.
     *
     * @param resource - the string resource of the text to set the button to.
     */
    @Override
    public void setButtonText(final int resource) {
        mainCallToActionButton.setText(getResources().getString(resource));
    }

}
