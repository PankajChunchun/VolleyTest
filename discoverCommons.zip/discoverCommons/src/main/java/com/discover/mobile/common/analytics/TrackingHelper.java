package com.discover.mobile.common.analytics;

import android.app.Activity;
import android.util.Log;

import com.adobe.adms.measurement.ADMS_Measurement;
//import com.crashlytics.android.Crashlytics;
import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.net.ServiceCallSessionManager;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/**
 * A helper class for adobe site catalyst analytics
 *
 * @author ekaram
 */
public final class TrackingHelper {
    public static final Map<String, Object> bank_link_data = new HashMap<String, Object>();

    //Rlagu Critical fix for analytics rsid was coming " " no site cat was tracked. removed final from below tags
    /** Public tracking values */
    public static final String CONTEXT_EDS_PROP = DiscoverActivityManager.getString(R.string.context_eds_prop);
    public static final String CONTEXT_EDS_VAR = DiscoverActivityManager.getString(R.string.context_eds_var);
    public static final String CONTEXT_USER_PROP = DiscoverActivityManager.getString(R.string.context_user_prop);
    public static final String CONTEXT_USER_VAR = DiscoverActivityManager.getString(R.string.context_user_var);
    public static final String CUSTOMER = DiscoverActivityManager.getString(R.string.customer);
    public static final String PROSPECT = DiscoverActivityManager.getString(R.string.prospect);
    public static final String CONTEXT_VSTR_ID_PROP = DiscoverActivityManager.getString(R.string.context_vstr_id_prop);
    public static final String CONTEXT_VSTR_ID_VAR = DiscoverActivityManager.getString(R.string.context_vstr_id_var);
    /** SSO detailed tag */
    public static final String SSO_TAG = DiscoverActivityManager.getString(R.string.sso_tag);
    /** Account types Detailed tag */
    public static final String ACCOUNT_TAG = DiscoverActivityManager.getString(R.string.account_tag);
    /** Single Sign on Value */
    public static final String SINGLE_SIGN_ON_VALUE = DiscoverActivityManager.getString(R.string.single_sign_on_value);
    /** 14.1 fix for app ver and os ver */
    public static final String CONTEXT_MOBILE_APP_VER = DiscoverActivityManager.getString(R.string.context_mobile_app_version_var);
    public static final String CONTEXT_MOBILE_OS_VER = DiscoverActivityManager.getString(R.string.context_mobile_os_version_var);
    /*   Jail Broken session tag implementation */
    public static final String CONTEXT_JAIL_BROKEN_SESSION = DiscoverActivityManager.getString(R.string.context_Property_evar5);
    public static final String CONTEXT_PROPERTY_EVAR5 = DiscoverActivityManager.getString(R.string.context_Property_evar5);
    /*	MOP1D*/
    public static final String CONTEXT_PROPERTY_EVAR35 = DiscoverActivityManager.getString(R.string.context_Property_evar35);
    public static final String CONTEXT_PROPERTY_EVAR65 = DiscoverActivityManager.getString(R.string.context_Property_evar65);
    public static final String CONTEXT_PROPERTY_EVAR66 = DiscoverActivityManager.getString(R.string.context_Property_evar66);
    public static final String CONTEXT_PROPERTY_EVAR68 = DiscoverActivityManager.getString(R.string.context_Property_evar68);
    public static final String CONTEXT_PROPERTY_EVENTS = DiscoverActivityManager.getString(R.string.context_Property_events);
    public static final String CONTEXT_PROPERTY_LIST3 = DiscoverActivityManager.getString(R.string.context_Property_list3);
    private static final String TAG = TrackingHelper.class.getSimpleName();
    private static final String LOG_TAG = "Tracking Helper";
    /** Private tracking values */
    private static final String CONTEXT_PAGE_NAME = DiscoverActivityManager.getString(R.string.context_page_name);
    private static final String CONTEXT_RSID = DiscoverActivityManager.getString(R.string.context_rsid);
    private static final String CONTEXT_APP_NAME = DiscoverActivityManager.getString(R.string.context_app_name);
    private static final String APP_NAME = DiscoverActivityManager.getString(R.string.discover_app_name);
    //US69926-Account Activity: Add Site Cat Tag to New DPL Payment Button-Start
    private static final String APP_NAME_BANK = DiscoverActivityManager.getString(R.string.bank_app_name);
    //US69926-Account Activity: Add Site Cat Tag to New DPL Payment Button-End
    private static final String LOGIN_APP_NAME = DiscoverActivityManager.getString(R.string.discover_app_name_login);
    /** Bank Application Name */
    private static final String BANK_APP_NAME = DiscoverActivityManager.getString(R.string.bank_app_name);
    /*Bank tracking tags*/
    public static final String CONTEXT_PROPERTY_EVAR26 = DiscoverActivityManager.getString(R.string.context_Property_evar26);
    public static final String CONTEXT_PROPERTY_PROP13 = DiscoverActivityManager.getString(R.string.context_Property_prop13);
    public static boolean isAppForeground = false;
    public static boolean isAppBackground = false;
    /* US59153 : store the last valid page name which will be used for error enhanced modal*/
    public static String currentPageName = null;
    /*	   Jail Broken session tag implementation */
    private static String CARD_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.card_tracking_rsid);
    private static String BANK_TRACKING_RSID =  DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.bank_tracking_rsid);

    private static String TRACKING_SERVER = DiscoverActivityManager.getString(R.string.tracking_server);
    private static ADMS_Measurement measurement;
    /**
     * A private constructor to enforce static use of this class
     */
    private TrackingHelper() {
        throw new UnsupportedOperationException("This class is non-instantiable"); //$NON-NLS-1$
    }

    /**
     * Sample method provided by adobe; goes unused with our implementation
     */
    public static void startActivity(final Activity activity) {
        configureAppMeasurement(activity);
        measurement.startActivity(activity);
    }

    /**
     * Initializes measurement for site catalyst
     */
    private static void configureAppMeasurement(final Activity activity) {
        if (measurement == null) {
            measurement = ADMS_Measurement.sharedInstance(activity);
            measurement.setSSL(true);  // comment out if using Bloodhound
            measurement.setDebugLogging(false);
        }
    }
	/*	MOP1D*/

    /**
     * Sample method provided by adobe; goes unused with our implementation
     */
    public static void stopActivity() {
        if(measurement!=null) {
            measurement.stopActivity();
        }
    }

    /**
     * Track a bank page
     *
     * @param pageName - string value of the page that should be represented
     */
    public static void trackBankPage(final String pageName) {
        trackBankPageView(pageName, BANK_APP_NAME, null, BANK_TRACKING_RSID);
    }

    /**
     * Track a page with extra data
     */
    public static void trackBankPage(final String pageName, final Map<String, Object> extras) {

        if (pageName == null) {
            try {
                if (extras.get(AnalyticsPage.CONTEXT_PROPERTY_1) != null) {
                    extras.put("pev1", extras.get(AnalyticsPage.CONTEXT_PROPERTY_1));
                }
                extras.putAll(bank_link_data);
            } catch (Exception e) {
            }
        }else{
            //Crashlytics.log("Page tag :" + pageName);
        }
        trackBankPageView(pageName, BANK_APP_NAME, extras, BANK_TRACKING_RSID);

    }

    /**us81831
     * Used to track each page view in the app - Bank
     *
     * @param pageName - supply the page name according to the specification from Discover
     */
    private static void trackBankPageView(final String pageName, final String appName,
                                      final Map<String, Object> extras, final String rsid) {
        if (measurement == null) {
            return;
        }
        //Rlagu Critical fix for analytics rsid was coming " " no site cat was tracked.
        if (rsid.trim().isEmpty()) {
            TRACKING_SERVER = DiscoverActivityManager.getString(R.string.tracking_server);
        }

        CARD_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.card_tracking_rsid);
        BANK_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.bank_tracking_rsid);


        measurement.clearVars();
        final Hashtable<String, Object> contextData = new Hashtable<String, Object>();
        if((null != appName) && (null != CONTEXT_APP_NAME)) {
            contextData.put(CONTEXT_APP_NAME, appName);
        }

        // populate app version, 14.1 fix, hlin0
        Activity activeActivity = DiscoverActivityManager.getActiveActivity();
        String appVersion = "unknown";
        try {
            appVersion = activeActivity.getPackageManager().getPackageInfo(activeActivity.getPackageName(), 0).versionName;
        } catch (Exception e) {
            // do nothing, version will have "unknown" as value
        }
        if((null != appVersion) && (null != CONTEXT_MOBILE_APP_VER)) {
            contextData.put(CONTEXT_MOBILE_APP_VER, appVersion);
        }

        // populate os version, 14.1 fix, hlin0
        String osVersion = "Android " + android.os.Build.VERSION.RELEASE;
        if((null != osVersion) && (null != CONTEXT_MOBILE_OS_VER)) {
            contextData.put(CONTEXT_MOBILE_OS_VER, osVersion);
        }

        // Added below try / catch block to avoid crash while getting EDSKEY null occasionally

        try
        {
            if(FacadeFactory.getBankFacade().getPageTitle()!=null && !Utils.isNullorEmpty(FacadeFactory.getBankFacade().getPageTitle())){
                contextData.put(CONTEXT_PROPERTY_EVAR26, FacadeFactory.getBankFacade().getPageTitle());
                contextData.put(CONTEXT_PROPERTY_PROP13, FacadeFactory.getBankFacade().getPageTitle());
            }
            if (ServiceCallSessionManager.getEDSKey() != null) {
                if(null != CONTEXT_EDS_PROP) {
                    contextData.put(CONTEXT_EDS_PROP, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CONTEXT_EDS_VAR) {
                    contextData.put(CONTEXT_EDS_VAR, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CUSTOMER) {
                    if(null != CONTEXT_USER_PROP) {
                        contextData.put(CONTEXT_USER_PROP, CUSTOMER);
                    }
                    if(null != CONTEXT_USER_VAR) {
                        contextData.put(CONTEXT_USER_VAR, CUSTOMER);
                    }
                }
            } else if (appName == APP_NAME && null != PROSPECT) {
                if(null != CONTEXT_USER_PROP) {
                    contextData.put(CONTEXT_USER_PROP, PROSPECT);
                }
                if(null != CONTEXT_USER_VAR) {
                    contextData.put(CONTEXT_USER_VAR, PROSPECT);
                }
            }


        }catch(Exception ex)
        {

        }



        //if(null != extras){
        //contextData.putAll(extras);


        // Changes suggested by PD
        if (null != extras) {

            if (extras.containsKey("list2")) {
                String listValue = extras.get("list2").toString();
                measurement.setListVar(2, listValue);
            }
            //modified in 7.2 as "events" was sent twice - START
            if (extras.containsKey("events")) {
                String eventValue = extras.get("events").toString();
                measurement.setEvents(eventValue);
                extras.remove("events");
            }

            if (extras.containsKey("products")) {
                String productsValue = extras.get("products").toString();
                measurement.setProducts(productsValue);
                extras.remove("products");
            }

            if (extras.containsKey("eVar20")) {
                String eVar20 = extras.get("eVar20").toString();
                measurement.setEvar(20, eVar20);
                extras.remove("eVar20");
            }

            if (extras.containsKey("eVar19")) {
                String eVar19 = extras.get("eVar19").toString();
                measurement.setEvar(19, eVar19);
                extras.remove("eVar19");
            }

            //modified in 7.2 END

            if (extras.containsKey("list3")) {
                String listValue = extras.get("list3").toString();
                measurement.setListVar(3, listValue);
                extras.remove("list3");
            }

            if (extras.containsKey("list1")) {
                String listValue = extras.get("list1").toString();
                measurement.setListVar(1, listValue);
                extras.remove("list1");
            }
            //Crashlystics fix for #225 , #1502

            if(extras.containsKey("eVar41")){
                String eVar41 = extras.get("eVar41").toString();
                measurement.setEvar(41, eVar41);
                extras.remove("eVar41");
            }
            try {
                if (null != extras) {
                    contextData.putAll(extras);
                }
            }catch(Exception e) {
               e.printStackTrace();
            }
        }

        //	}

        if ((pageName != null) && (null != CONTEXT_PAGE_NAME)) {
            contextData.put(CONTEXT_PAGE_NAME, pageName);
            Log.d("pagename::", pageName);
        }
        if((rsid != null) && (null != CONTEXT_RSID)) {
            contextData.put(CONTEXT_RSID, rsid);
        }

        /*Bank tracking new tags*/

        Log.d(TAG, "Tracking: " + contextData);

        measurement.configureMeasurement(rsid, TRACKING_SERVER);
        if (pageName != null)
            measurement.setAppState(pageName);
        measurement.track(contextData);

//
        /*if (pageName != null) {
            contextData.put(CONTEXT_PAGE_NAME, pageName);
            Log.d("pagename::", pageName);
        }
        contextData.put(CONTEXT_RSID, globalrsid);

        Log.d(TAG, "Tracking: " + contextData);

        measurement.configureMeasurement(rsid, GLOBAL_TRACKING_SERVER);
            measurement.setAppState(pageName);
        measurement.track(contextData);*/

        /* US59153 : store the last valid page name which will be used for error enhanced modal*/
        if (pageName != null) {
            currentPageName = pageName;
        }

    }

    /**
     * Track the card pages
     *
     * @param pageName - string value of the page to track
     */
    public static void trackPageView(final String pageName) {
        if (DiscoverActivityManager.getActiveActivity() != null) {
            if (Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext()) != null) {
                HashMap<String, Object> extrasMap = new HashMap<String, Object>();
                extrasMap.put(TrackingHelper.SSO_TAG, ("Page Orientation :" + Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext())));
                trackPageView(pageName, APP_NAME, extrasMap, CARD_TRACKING_RSID);
            }
        }
    }

    /**
     * TO BE CHNAGED WHEN WE IMPLEMENT TAGS FOR WHOLE APP
     * Track the card pages
     *
     * @param pageName - string value of the page to track
     */
    public static void trackPageViewLogin(final String pageName) {
        trackPageView(pageName, LOGIN_APP_NAME, null, CARD_TRACKING_RSID);
    }

    /**
     * Track a page with extra data
     */
    public static void trackCardPage(final String pageName, final Map<String, Object> extras) {
        if (DiscoverActivityManager.getActiveActivity() != null) {
            if (Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext()) != null) {
                if (extras != null) {
                    extras.put(TrackingHelper.SSO_TAG, ("Page Orientation :" + Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext())));
                    trackPageView(pageName, APP_NAME, extras, CARD_TRACKING_RSID);
                } else {
                    HashMap<String, Object> extrasMap = new HashMap<String, Object>();
                    extrasMap.put(TrackingHelper.SSO_TAG, ("Page Orientation :" + Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext())));
                    trackPageView(pageName, APP_NAME, extrasMap, CARD_TRACKING_RSID);
                }
            }
        }
    }

    /**
     * Used to track each page view in the app
     *
     * @param pageName - supply the page name according to the specification from Discover
     */
    private static void trackPageView(final String pageName, final String appName,
                                      final Map<String, Object> extras, final String rsid) {
        if (measurement == null) {
            return;
        }
        //Rlagu Critical fix for analytics rsid was coming " " no site cat was tracked.
        if (rsid.trim().isEmpty()) {
            TRACKING_SERVER = DiscoverActivityManager.getString(R.string.tracking_server);
        }

        CARD_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.card_tracking_rsid);
        BANK_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.bank_tracking_rsid);


        measurement.clearVars();
        final Hashtable<String, Object> contextData = new Hashtable<String, Object>();
        if((null != appName) && (null != CONTEXT_APP_NAME)) {
            contextData.put(CONTEXT_APP_NAME, appName);
        }

        // populate app version, 14.1 fix, hlin0
        Activity activeActivity = DiscoverActivityManager.getActiveActivity();
        String appVersion = "unknown";
        try {
            appVersion = activeActivity.getPackageManager().getPackageInfo(activeActivity.getPackageName(), 0).versionName;
        } catch (Exception e) {
            // do nothing, version will have "unknown" as value
        }
        if((null != appVersion) && (null != CONTEXT_MOBILE_APP_VER)) {
            contextData.put(CONTEXT_MOBILE_APP_VER, appVersion);
        }

        // populate os version, 14.1 fix, hlin0
        String osVersion = "Android " + android.os.Build.VERSION.RELEASE;
        if((null != osVersion) && (null != CONTEXT_MOBILE_OS_VER)) {
            contextData.put(CONTEXT_MOBILE_OS_VER, osVersion);
        }

        // Added below try / catch block to avoid crash while getting EDSKEY null occasionally

        try
        {
            if(!Utils.isNullorEmpty(currentPageName)) {
                contextData.put(CONTEXT_PROPERTY_EVAR26, currentPageName);
                contextData.put(CONTEXT_PROPERTY_PROP13, currentPageName);
            }

            if (ServiceCallSessionManager.getEDSKey() != null) {
                if(null != CONTEXT_EDS_PROP) {
                    contextData.put(CONTEXT_EDS_PROP, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CONTEXT_EDS_VAR) {
                    contextData.put(CONTEXT_EDS_VAR, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CUSTOMER) {
                    if(null != CONTEXT_USER_PROP) {
                        contextData.put(CONTEXT_USER_PROP, CUSTOMER);
                    }
                    if(null != CONTEXT_USER_VAR) {
                        contextData.put(CONTEXT_USER_VAR, CUSTOMER);
                    }
                }
            } else if (appName == APP_NAME && null != PROSPECT) {
                if(null != CONTEXT_USER_PROP) {
                    contextData.put(CONTEXT_USER_PROP, PROSPECT);
                }
                if(null != CONTEXT_USER_VAR) {
                    contextData.put(CONTEXT_USER_VAR, PROSPECT);
                }
            }
        }catch(Exception ex)
        {

        }



        //if(null != extras){
        //contextData.putAll(extras);


        // Changes suggested by PD
        if (null != extras) {

            /** Start changes for US91075 : List2 tags required to fire outside the context data.
             * measurement.setListVar(2, listValue) : this method is required for List2 tag */
            if (extras != null && extras.containsKey("list2")) {
                String listValue = extras.get("list2").toString();
                measurement.setListVar(2, listValue);
                extras.remove("list2");
            }
        /*End changes for US91075 */
            //modified in 7.2 as "events" was sent twice - START
            if (extras.containsKey("events")) {
                String eventValue = extras.get("events").toString();
                measurement.setEvents(eventValue);
                extras.remove("events");
            }

            if (extras.containsKey("products")) {
                String productsValue = extras.get("products").toString();
                measurement.setProducts(productsValue);
                extras.remove("products");
            }

            if (extras.containsKey("eVar20")) {
                String eVar20 = extras.get("eVar20").toString();
                measurement.setEvar(20, eVar20);
                extras.remove("eVar20");
            }

            if (extras.containsKey("eVar19")) {
                String eVar19 = extras.get("eVar19").toString();
                measurement.setEvar(19, eVar19);
                extras.remove("eVar19");
            }

            //modified in 7.2 END

            if (extras.containsKey("list3")) {
                String listValue = extras.get("list3").toString();
                measurement.setListVar(3, listValue);
                extras.remove("list3");
            }
            if (extras.containsKey("list1")) {
                String listValue = extras.get("list1").toString();
                measurement.setListVar(1, listValue);
                extras.remove("list1");
            }
//           measurement.getAppSection();
            //Crashlytics fix for #225
            if (null != extras) {
                contextData.putAll(extras);
            }
        }

        //	}

        if ((pageName != null) && (null != CONTEXT_PAGE_NAME)) {
            contextData.put(CONTEXT_PAGE_NAME, pageName);
            Log.d("pagename::", pageName);
        }
        if((rsid != null) && (null != CONTEXT_RSID)) {
            contextData.put(CONTEXT_RSID, rsid);
        }

        Log.d(TAG, "Tracking: " + contextData);

        measurement.configureMeasurement(rsid, TRACKING_SERVER);
        if (pageName != null)
            measurement.setAppState(pageName);
        measurement.track(contextData);

//
        /*if (pageName != null) {
            contextData.put(CONTEXT_PAGE_NAME, pageName);
            Log.d("pagename::", pageName);
        }
        contextData.put(CONTEXT_RSID, globalrsid);

        Log.d(TAG, "Tracking: " + contextData);

        measurement.configureMeasurement(rsid, GLOBAL_TRACKING_SERVER);
            measurement.setAppState(pageName);
        measurement.track(contextData);*/

        /* US59153 : store the last valid page name which will be used for error enhanced modal*/
        if (pageName != null) {
            currentPageName = pageName;
        }

    }

    public static HashMap<String, Object> getProp10Error(String title, String errorMessage) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("my.prop10", title + "|" + getFirstXCharacters(errorMessage, 60));
        return map;
    }


    public static void trackCardPageProp10(String title, String errorMessage) {
        HashMap<String, Object> extras = new HashMap<String, Object>();
        extras.putAll(TrackingHelper.getProp10Error(title, errorMessage));
        TrackingHelper.trackCardPage(null, extras);
    }

    public static void trackCardPageProp1(String prop1, String pev1) {
        trackCardPageProp1(prop1, pev1, null);
    }

    public static void trackCardPageProp1(String prop1, String pev1, HashMap<String, Object> extras) {
        if (extras == null) {
            extras = new HashMap<String, Object>();
        }
        extras.put("my.prop1", prop1);
        extras.put("pe", "lnk_o");
        extras.put("pev1", pev1);
        TrackingHelper.trackCardPage(null, extras);
    }

    private static String getFirstXCharacters(String message, int length) {
        if (message != null && message.length() >= length) {
            return message.substring(0, length);
        }
        return message;
    }

    /**us81831
     * Used to track each click events in the app - for bank
     *
     * @param linkName - supply the link name according to the specification from Discover
     */
    private static void trackBankClickAction(final String linkUrl,final String linkName, final String appName, final Map<String, Object> extras, final String rsid, String linkType) {
        if (measurement == null) {
            return;
        }
        //Rlagu Critical fix for analytics rsid was coming " " no site cat was tracked.
        if (rsid.trim().isEmpty()) {
            CARD_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.card_tracking_rsid);
            BANK_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.bank_tracking_rsid);
            TRACKING_SERVER = DiscoverActivityManager.getString(R.string.tracking_server);

        }

        measurement.clearVars();
        final Hashtable<String, Object> contextData = new Hashtable<String, Object>();
        if((null != appName) && (null != CONTEXT_APP_NAME)) {
            contextData.put(CONTEXT_APP_NAME, appName);
        }

        // populate app version, 14.1 fix, hlin0
        Activity activeActivity = DiscoverActivityManager.getActiveActivity();
        String appVersion = "unknown";
        try {
            appVersion = activeActivity.getPackageManager().getPackageInfo(activeActivity.getPackageName(), 0).versionName;
        } catch (Exception e) {
            // do nothing, version will have "unknown" as value
        }
        if((null != appVersion) && (null != CONTEXT_MOBILE_APP_VER)) {
            contextData.put(CONTEXT_MOBILE_APP_VER, appVersion);
        }

        // populate os version, 14.1 fix, hlin0
        String osVersion = "Android " + android.os.Build.VERSION.RELEASE;
        if((null != osVersion) && (null != CONTEXT_MOBILE_OS_VER)) {
            contextData.put(CONTEXT_MOBILE_OS_VER, osVersion);
        }

        // Added below try / catch block to avoid crash while getting EDSKEY null occasionally

        try
        {
            if(FacadeFactory.getBankFacade().getPageTitle()!=null && !Utils.isNullorEmpty(FacadeFactory.getBankFacade().getPageTitle())){
                contextData.put(CONTEXT_PROPERTY_EVAR26, FacadeFactory.getBankFacade().getPageTitle());
                contextData.put(CONTEXT_PROPERTY_PROP13, FacadeFactory.getBankFacade().getPageTitle());
            }

            if (ServiceCallSessionManager.getEDSKey() != null) {
                if(null != CONTEXT_EDS_PROP) {
                    contextData.put(CONTEXT_EDS_PROP, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CONTEXT_EDS_VAR) {
                    contextData.put(CONTEXT_EDS_VAR, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CUSTOMER) {
                    if(null != CONTEXT_USER_PROP) {
                        contextData.put(CONTEXT_USER_PROP, CUSTOMER);
                    }
                    if(null != CONTEXT_USER_VAR) {
                        contextData.put(CONTEXT_USER_VAR, CUSTOMER);
                    }
                }
            } else if (appName == APP_NAME && null != PROSPECT) {
                if(null != CONTEXT_USER_PROP) {
                    contextData.put(CONTEXT_USER_PROP, PROSPECT);
                }
                if(null != CONTEXT_USER_VAR) {
                    contextData.put(CONTEXT_USER_VAR, PROSPECT);
                }
            }
        }catch(Exception ex)
        {

        }
        // }
        if (null != extras) {
            contextData.putAll(extras);
        }

        if((rsid != null) && (null != CONTEXT_RSID)) {
            contextData.put(CONTEXT_RSID, rsid);
        }

        Log.d(TAG, "Tracking links: " + contextData);

        measurement.configureMeasurement(rsid, TRACKING_SERVER);
        if (linkName != null)
            measurement.setAppState(linkName);

        measurement.trackLink(linkUrl, linkType, linkName, contextData, null);

    }


    /**
     * Used to track each click events in the app
     *
     * @param linkName - supply the link name according to the specification from Discover
     */
    private static void trackClickAction(final String linkUrl,final String linkName, final String appName, final Map<String, Object> extras, final String rsid, String linkType) {
        if (measurement == null) {
            return;
        }
        //Rlagu Critical fix for analytics rsid was coming " " no site cat was tracked.
        if (rsid.trim().isEmpty()) {
            CARD_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.card_tracking_rsid);
            BANK_TRACKING_RSID = DiscoverActivityManager.getString(R.string.global_tracking_rsid) + "," + DiscoverActivityManager.getString(R.string.bank_tracking_rsid);
            TRACKING_SERVER = DiscoverActivityManager.getString(R.string.tracking_server);

        }

        measurement.clearVars();
        final Hashtable<String, Object> contextData = new Hashtable<String, Object>();
        if((null != appName) && (null != CONTEXT_APP_NAME)) {
            contextData.put(CONTEXT_APP_NAME, appName);
        }


        /** Start changes for US91075 : List2 tags required to fire outside the context data.
         * measurement.setListVar(2, listValue) : this method is required for List2 tag */
        if (extras != null && extras.containsKey("list2")) {
            String listValue = extras.get("list2").toString();
            measurement.setListVar(2, listValue);
            extras.remove("list2");
        }
        if (extras.containsKey("events")) {
            String eventValue = extras.get("events").toString();
            measurement.setEvents(eventValue);
            extras.remove("events");
        }

        if (extras.containsKey("products")) {
            String productsValue = extras.get("products").toString();
            measurement.setProducts(productsValue);
            extras.remove("products");
        }
        /*End changes for US91075 */

        //as per requirement e.var22 is not required when tracking click actions
       /* if(null!=currentPageName)
        contextData.put(CONTEXT_PAGE_NAME, currentPageName);*/

        // populate app version, 14.1 fix, hlin0
        Activity activeActivity = DiscoverActivityManager.getActiveActivity();
        String appVersion = "unknown";
        try {
            appVersion = activeActivity.getPackageManager().getPackageInfo(activeActivity.getPackageName(), 0).versionName;
        } catch (Exception e) {
            // do nothing, version will have "unknown" as value
        }
        if((null != appVersion) && (null != CONTEXT_MOBILE_APP_VER)) {
            contextData.put(CONTEXT_MOBILE_APP_VER, appVersion);
        }

        // populate os version, 14.1 fix, hlin0
        String osVersion = "Android " + android.os.Build.VERSION.RELEASE;
        if((null != osVersion) && (null != CONTEXT_MOBILE_OS_VER)) {
            contextData.put(CONTEXT_MOBILE_OS_VER, osVersion);
        }

        // Added below try / catch block to avoid crash while getting EDSKEY null occasionally

        try
        {
            if(!Utils.isNullorEmpty(currentPageName)) {
                contextData.put(CONTEXT_PROPERTY_EVAR26, currentPageName);
                contextData.put(CONTEXT_PROPERTY_PROP13, currentPageName);
            }
            if (ServiceCallSessionManager.getEDSKey() != null) {
                if(null != CONTEXT_EDS_PROP) {
                    contextData.put(CONTEXT_EDS_PROP, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CONTEXT_EDS_VAR) {
                    contextData.put(CONTEXT_EDS_VAR, ServiceCallSessionManager.getEDSKey());
                }
                if(null != CUSTOMER) {
                    if(null != CONTEXT_USER_PROP) {
                        contextData.put(CONTEXT_USER_PROP, CUSTOMER);
                    }
                    if(null != CONTEXT_USER_VAR) {
                        contextData.put(CONTEXT_USER_VAR, CUSTOMER);
                    }
                }
            } else if (appName == APP_NAME && null != PROSPECT) {
                if(null != CONTEXT_USER_PROP) {
                    contextData.put(CONTEXT_USER_PROP, PROSPECT);
                }
                if(null != CONTEXT_USER_VAR) {
                    contextData.put(CONTEXT_USER_VAR, PROSPECT);
                }
            }
        }catch(Exception ex)
        {

        }
        // }

        if (extras.containsKey("list3")) {
            String listValue = extras.get("list3").toString();
            measurement.setListVar(3, listValue);
            extras.remove("list3");
        }
        if (extras.containsKey("list1")) {
            String listValue = extras.get("list1").toString();
            measurement.setListVar(1, listValue);
            extras.remove("list1");
        }
        if (null != extras) {
            contextData.putAll(extras);
        }

        if((rsid != null) && (null != CONTEXT_RSID)) {
            contextData.put(CONTEXT_RSID, rsid);
        }

        Log.d(TAG, "Tracking links: " + contextData);

        measurement.configureMeasurement(rsid, TRACKING_SERVER);
        if (linkName != null)
            measurement.setAppState(linkName);
        else
            measurement.setAppState("");



        measurement.trackLink(linkUrl, linkType, linkName, contextData, null);

    }

    /**
     * Track a link with extra data
     * @param linkName - Name of the click event/link name.
     * @param linkType - “o” (Custom Links) / “d” (File Downloads) / “e” (Exit Links).
     */
    public static void trackClickEvents(final String linkUrl,final String linkName, String linkType,final Map<String, Object> extras) {
        if (DiscoverActivityManager.getActiveActivity() != null) {
            if (Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext()) != null) {
                if (extras != null) {
                    extras.put(TrackingHelper.SSO_TAG, ("Page Orientation :" + Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext())));
                    trackClickAction(linkUrl,linkName, APP_NAME, extras, CARD_TRACKING_RSID, linkType);
                } else {
                    HashMap<String, Object> extrasMap = new HashMap<String, Object>();
                    extrasMap.put(TrackingHelper.SSO_TAG, ("Page Orientation :" + Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext())));
                    trackClickAction(linkUrl,linkName, APP_NAME, extrasMap, CARD_TRACKING_RSID, linkType);
                }
            }
        }
    }

    /**
     * Track a link with extra data
     * @param linkName - Name of the click event/link name.
     * @param linkType - “o” (Custom Links) / “d” (File Downloads) / “e” (Exit Links).
     */
    public static void trackBankClickEvents(final String linkUrl,final String linkName, String linkType,final Map<String, Object> extras) {
        if (DiscoverActivityManager.getActiveActivity() != null) {
            if (Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext()) != null) {
                if (extras != null) {

                    extras.put(TrackingHelper.SSO_TAG, ("Page Orientation :" + Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext())));
                    trackBankClickAction(linkUrl,linkName, APP_NAME_BANK, extras, BANK_TRACKING_RSID, linkType);
                } else {
                    HashMap<String, Object> extrasMap = new HashMap<String, Object>();
                    extrasMap.put(TrackingHelper.SSO_TAG, ("Page Orientation :" + Utils.getRotation(DiscoverActivityManager.getActiveActivity().getBaseContext())));
                    trackBankClickAction(linkUrl,linkName, APP_NAME_BANK, extrasMap, BANK_TRACKING_RSID, linkType);
                }
            }
        }
    }


}