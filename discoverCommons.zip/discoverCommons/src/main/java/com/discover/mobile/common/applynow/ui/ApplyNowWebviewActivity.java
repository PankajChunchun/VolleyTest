package com.discover.mobile.common.applynow.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import java.util.HashMap;

/**
 * Created by 473708 on 9/19/2017.
 */

public class ApplyNowWebviewActivity extends ActionBarBaseActivity {
    private static final String EXTRA_URL_TO_SHOW = "url_to_show";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // As per fix of defect:1268
        // Check if App Permissions are changed manually when app was running,If true Navigate to Login page
        /* Removing below code will result in crash while changing permissions manually and opening the app */
        if(Utils.checkPermissionTampering(this)){
            return;
        }

        ApplyNowWebViewFragment applyNowWebViewFragment = new ApplyNowWebViewFragment();

        if (getIntent().getExtras() != null && getIntent().getExtras().getString(EXTRA_URL_TO_SHOW) != null) {
            String url = getIntent().getExtras().getString(EXTRA_URL_TO_SHOW);
            Bundle b = new Bundle();
            b.putString(EXTRA_URL_TO_SHOW, url);
            applyNowWebViewFragment.setArguments(b);
        }

        setContentView(NO_LAYOUT);
        DiscoverActivityManager.setActiveActivity(this);
//        makeFragmentVisible(navToFragment, false);
        getSupportFragmentManager().beginTransaction().replace(R.id.contentView, applyNowWebViewFragment, applyNowWebViewFragment.getClass().getSimpleName()).commit();
    }

    private void showBackX() {
        setActionbarBackNavigation(new Runnable() {
            @Override
            public void run() {
                handleBackAction();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        showBackX();
    }

    @Override
    public void onBackPressed() {
        handleBackAction();
    }

    private void handleBackAction() {
        finish();
    }

    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }

    public static final void show(Context context, String url) {
        if (Utils.isNullorEmpty(url)) {
            return;
        }

        Intent intent = new Intent(context, ApplyNowWebviewActivity.class);
        intent.putExtra(EXTRA_URL_TO_SHOW, url+"?SCMobileOrigin=AndroidMobile");
        context.startActivity(intent);

    }
}
