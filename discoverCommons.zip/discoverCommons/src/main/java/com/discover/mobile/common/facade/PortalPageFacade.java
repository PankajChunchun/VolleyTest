package com.discover.mobile.common.facade;

import android.content.Context;

import com.discover.mobile.common.fico.fragments.CmnFicoCreditScoreMasterFragment;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreHostInterface;
import com.discover.mobile.common.interfaces.CmnEventHandler;
import com.discover.mobile.common.services.auth.registration.RegistrationConfirmationDetails;
import com.discover.mobile.network.error.bean.ErrorBean;

import java.util.ArrayList;

/**
 * @author nkaza
 */
public interface PortalPageFacade {


    /**
     * Navigate to card home
     *
     * @param portalPageActivity   : Calling activity
     * @param selectedAccountIndex : Selected index
     */
    void navToCardHome(Context portalPageActivity, String selectedAccountIndex);

    void navToFicoCreditScore(Context portalPageActivity, String selectedAccountIndex);

    void navToMakeAPayment(Context portalPageActivity, String selectedAccountIndex);

    void navToPortalActivity(RegistrationConfirmationDetails confirmationDetails);

    void handleErrorScenario(Context portalPageActivity, Object data);

    void set16DigitLogin(boolean b);

    void navigateToFicoPrivacyTerms(CmnEventHandler.CmnEvent mode, Context context,String strParameter);

    void handleFICOCreditScoreAPIErrorScenarios(ErrorBean ficoErrorBean, CmnFicoCreditScoreMasterFragment cmnFicoMasterFragment,Context context);

    void updateCardCache(Context portalPageActivity, String edsKey);

}
