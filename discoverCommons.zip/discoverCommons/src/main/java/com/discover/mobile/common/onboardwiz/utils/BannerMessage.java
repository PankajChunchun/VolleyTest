package com.discover.mobile.common.onboardwiz.utils;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ImageSpan;
import android.text.style.URLSpan;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.utils.CmnScaleAnimation;


public class BannerMessage implements View.OnClickListener {
    public static final int LENGTH_SHORT = 0;
    public static final int LENGTH_LONG = 1;
    public static final int ERROR = 0;
    public static final int SUCCESS = 1;
    public static final int WARNING = 2;
    public static final int WARNING_WITHOUT_ANIMATION=3;
    public static final int FICO_ATTRIBUTE_UNAVAILABLE_ERROR = 4;
    public static final int FICO_REVOLVING_UTIL_UNAVAILABLE_ERROR = 5;
    //Restart slide to top animation time for ribben message
    private final Handler mHandler = new Handler();

    public BannerMessage getBannerMessage() {
        return bannerMessage;
    }

    private BannerMessage bannerMessage = null;
    private LinearLayout bannerLayout;

    private View ribben;
    private int duration;
    public int TABLET_PORTRAIT_PADDING = 40, TABLET_LANDSCAPE_PADDING = 96, HANDSET_PORTRAIT_PADDING = 16;

    private TimeOutListener listener;
    private Context context = null;
    private static Fragment fragment;

    public int getType() {
        return type;
    }

    private int type = -1;
    private String message;
    private LinearLayout ribbenParent;

    public TextView getMessageTextView() {
        return messageTextView;
    }

    public void setMessageTextView(TextView messageTextView) {
        this.messageTextView = messageTextView;
    }

    private TextView messageTextView;
    public static final int ANIMATION_DURATION = 400;
    public static final int ERROR_ANIMATION_INTERVAL = 3000;
    private View rootView;
    private int holerId;
    private ImageView statusDrawable;


    public BannerMessage make(Context activity, View root,
                              int message, int type) {

        return make(activity, root, context.getString(message), type, null);
    }

    public BannerMessage make(Fragment fragment, View root,
                              int message, int type, TimeOutListener listener) {

        bannerMessage = make(fragment.getActivity(), root, context.getString(message), type, listener);
        bannerMessage.setFragment(fragment);

        return bannerMessage;
    }

    public BannerMessage make(Context activity, View root,
                              String message, int type) {

        return make(activity, root, message, type, null);
    }

    public BannerMessage make(final Context context, final View root,
                              String message, final int type, final TimeOutListener listener)
            throws RuntimeException {
        int errorSlidingParentId = R.id.withHeader;
        holerId = R.id.banner_container;
        this.rootView = root;

        if (bannerMessage == null) {
            if(type == BannerMessage.WARNING_WITHOUT_ANIMATION)
                bannerMessage=new BannerMessage(context,type);
            else
            bannerMessage = new BannerMessage(context);
            bannerMessage.setDuration(duration);
            bannerMessage.setTimeOutListener(listener);
            bannerMessage.setRibbenType(type);
            bannerMessage.setMessage(message);
            bannerMessage.messageTextView.setContentDescription(message);
            if (bannerMessage.getRibben().getParent() != root) {

                handleViewAdditionWithAnimation(root, context, type, holerId);

            } else {
                throw new RuntimeException(
                        "root layout isn't part of layout or may be null.");
            }
        } else {
            //remove the existing view and try again
            ((ViewGroup) root).removeView(bannerMessage.getRibben());
            bannerMessage = null;
            make(context, root, message, type, listener);
        }
        return bannerMessage;

    }

    /*US115912 : Reg D Count Bill Pay - Start*/
    public BannerMessage messageWithToolTip(Context activity, View root,
                                            String message, int type, int messageString, String acctype) {

        return messageWithToolTip(activity, root, message, type, null, messageString, acctype);
    }

    public BannerMessage messageWithToolTip(final Context context, final View root,
                              String message, final int type, final TimeOutListener listener, int messageString, String acctype)
            throws RuntimeException {
        //int errorSlidingParentId = R.id.withHeader;
        holerId = R.id.banner_container;
        this.rootView = root;

        if (bannerMessage == null) {
            if(type == BannerMessage.WARNING_WITHOUT_ANIMATION)
                bannerMessage=new BannerMessage(context,type);
            else
                bannerMessage = new BannerMessage(context);
            bannerMessage.setDuration(duration);
            bannerMessage.setTimeOutListener(listener);
            bannerMessage.setRibbenType(type);

            bannerMessage.setMessageWithToolTipIcon(message, messageString, acctype);
            bannerMessage.messageTextView.setContentDescription(message);
            if (bannerMessage.getRibben().getParent() != root) {

                handleViewAdditionWithAnimation(root, context, type, holerId);

            } else {
                throw new RuntimeException(
                        "root layout isn't part of layout or may be null.");
            }
        } else {
            //remove the existing view and try again
            ((ViewGroup) root).removeView(bannerMessage.getRibben());
            bannerMessage = null;
            make(context, root, message, type, listener);
        }

        return bannerMessage;

    }
    /*US115912 : Reg D Count Bill Pay - End*/
    private void handleViewAdditionWithAnimation(final View root, final Context context, final int type, final int holderId) {

        switch (type) {
            case FICO_REVOLVING_UTIL_UNAVAILABLE_ERROR:
            case FICO_ATTRIBUTE_UNAVAILABLE_ERROR:
                //remove the already added views
                if (((ViewGroup) (root).findViewById(holderId)).getChildCount() > 0) {
                    ((ViewGroup) root.findViewById(holderId)).removeAllViews();
                }
                try {
                    //remove any existing views
                    ((ViewGroup) root).removeView(bannerMessage.getRibben());
                    //add the actual ribben message view to the container
                    ((ViewGroup) root.findViewById(holderId)).addView(bannerMessage.getRibben());
                    final View containerView = ((ViewGroup) root.findViewById(holderId));
                    final ScrollView animationView = (ScrollView) containerView.getParent();
                    //set the container color to RED
                    containerView.setBackgroundResource(getColor(type));
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                        animationView.bringToFront();
                        animationView.setElevation(Utils.dpToPx(4, context.getResources().getDisplayMetrics()));
                    }
                    //set the innitial hight to 0 so that we dont see a jitter in the animation
                    ViewGroup.LayoutParams lps = animationView.getLayoutParams();
                    lps.height = 0;
                    animationView.setLayoutParams(lps);
                    //once we are all set with the pre conditions of the animation then we make the view visible and animate it

//                            animationView.setY(0);
//                            containerView.setVisibility(View.VISIBLE);
                    animationView.getChildAt(0).post(new Runnable() {
                        @Override
                        public void run() {
                            int animationViewHeight = animationView.getChildAt(0).getHeight();
                            //scale the scroll view
                            CmnScaleAnimation scale = new CmnScaleAnimation(animationView, animationViewHeight, 0);
                            scale.setDuration(ANIMATION_DURATION);
                            if (CommonUtils.isRunningOnHandset(context)) {
                                animationView.clearAnimation();
                            }
                            animationView.startAnimation(scale);
                            //translate animation to move the banner down
                            TranslateAnimation translate = new TranslateAnimation(0, 0, -animationViewHeight, 0);
                            translate.setDuration(ANIMATION_DURATION);
                            if (CommonUtils.isRunningOnHandset(context)) {
                                ((ViewGroup) root.findViewById(holderId)).clearAnimation();
                            }
                            ((ViewGroup) root.findViewById(holderId)).startAnimation(translate);
                        }
                    });
                } catch (ClassCastException e) {
                    //this exception will be if the parent added for the layout is not of type scrollview
                    //in this case we donot do anything and no animation will take place
                }
                break;
            case ERROR:
                //remove the already added views
                if (((ViewGroup) (root).findViewById(holderId)).getChildCount() > 0) {
                    ((ViewGroup) root.findViewById(holderId)).removeAllViews();
                }
                try {


                    //remove any existing views
                    ((ViewGroup) root).removeView(bannerMessage.getRibben());


                    //add the actual ribben message view to the container
                    ((ViewGroup) root.findViewById(holderId)).addView(bannerMessage.getRibben());

                    final View containerView = ((ViewGroup) root.findViewById(holderId));
                    final ScrollView animationView = (ScrollView) containerView.getParent();
                    //set the container color to RED
                    containerView.setBackgroundResource(getColor(type));

                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                        animationView.bringToFront();
                        animationView.setElevation(Utils.dpToPx(4,context.getResources().getDisplayMetrics()));
                    }


                    //set the innitial hight to 0 so that we dont see a jitter in the animation
                    ViewGroup.LayoutParams lps = animationView.getLayoutParams();
                    lps.height = 0;
                    animationView.setLayoutParams(lps);
                    //once we are all set with the pre conditions of the animation then we make the view visible and animate it

//                            animationView.setY(0);
//                            containerView.setVisibility(View.VISIBLE);
                    animationView.getChildAt(0).post(new Runnable() {
                        @Override
                        public void run() {
                            int animationViewHeight = animationView.getChildAt(0).getHeight();
                            //scale the scroll view
                            CmnScaleAnimation scale = new CmnScaleAnimation(animationView, animationViewHeight, 0);
                            scale.setDuration(ANIMATION_DURATION);
                            animationView.startAnimation(scale);
                            //translate animation to move the banner down
                            TranslateAnimation translate = new TranslateAnimation(0, 0, -animationViewHeight, 0);
                            translate.setDuration(ANIMATION_DURATION);
                            ((ViewGroup) root.findViewById(holderId)).startAnimation(translate);
                        }
                    });


                } catch (ClassCastException e) {
                    //this exception will be if the parent added for the layout is not of type scrollview
                    //in this case we donot do anything and no animation will take place
                }

                break;
            case SUCCESS:
            case WARNING:
                ((ViewGroup) root).removeView(bannerMessage.getRibben());
                //remove the already added views
                if (((ViewGroup) root.findViewById(holderId)).getChildCount() > 0) {
                    ((ViewGroup) root.findViewById(holderId)).removeAllViews();
//                   return;
                }
                ((ViewGroup) root).addView(bannerMessage.getRibben());


                View view = bannerMessage.getRibben();
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                view.setLayoutParams(layoutParams);

                //Sliding from top animation for the Ribben message
                Animation slideSuccess = AnimationUtils.loadAnimation(context, R.anim.slide_from_top);
                bannerMessage.getRibben().startAnimation(slideSuccess);

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Animation successUpAnimation = AnimationUtils.loadAnimation(context, R.anim.slide_to_top);
                        if (bannerMessage != null && bannerMessage.getRibben() != null) {
                            bannerMessage.getRibben().startAnimation(successUpAnimation);
                            successUpAnimation.setAnimationListener(new Animation.AnimationListener() {
                                @Override
                                public void onAnimationStart(Animation animation) {

                                }

                                @Override
                                public void onAnimationEnd(Animation animation) {
                                    ((ViewGroup) root).removeView(bannerMessage.getRibben());
                                }

                                @Override
                                public void onAnimationRepeat(Animation animation) {

                                }
                            });
                        }
                    }
                }, ERROR_ANIMATION_INTERVAL);


                break;
            /*
            * Case for warning banner without animation*/

            case WARNING_WITHOUT_ANIMATION:

                try {
                    //crashlytics fix

                    if (((ViewGroup) (root).findViewById(holderId)).getChildCount() > 0) {
                        ((ViewGroup) root.findViewById(holderId)).removeAllViews();
                    }

                    //remove any existing views
                    ((ViewGroup) root).removeView(bannerMessage.getRibben());


                    //add the actual ribben message view to the container
                    ((ViewGroup) root.findViewById(holderId)).addView(bannerMessage.getRibben());

                    final View containerView = ((ViewGroup) root.findViewById(holderId));
                    final ScrollView animationView = (ScrollView) containerView.getParent();
                    //set the container color to YELLOW
                    containerView.setBackgroundResource(getColor(type));

                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                        animationView.bringToFront();
                        animationView.setElevation(Utils.dpToPx(4,context.getResources().getDisplayMetrics()));
                    }


                    //set the innitial hight to 0 so that we dont see a jitter in the animation
                    ViewGroup.LayoutParams lps = animationView.getLayoutParams();
                    lps.height = 0;
                    animationView.setLayoutParams(lps);
                    //once we are all set with the pre conditions of the animation then we make the view visible and animate it

//                            animationView.setY(0);
//                            containerView.setVisibility(View.VISIBLE);
                    animationView.getChildAt(0).post(new Runnable() {
                        @Override
                        public void run() {
                            int animationViewHeight = animationView.getChildAt(0).getHeight();
                            //scale the scroll view
                            CmnScaleAnimation scale = new CmnScaleAnimation(animationView, animationViewHeight, 0);
                            scale.setDuration(ANIMATION_DURATION);
                            animationView.startAnimation(scale);
                            //translate animation to move the banner down
                            TranslateAnimation translate = new TranslateAnimation(0, 0, -animationViewHeight, 0);
                            translate.setDuration(ANIMATION_DURATION);
                            ((ViewGroup) root.findViewById(holderId)).startAnimation(translate);
                        }
                    });


                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    private void purge() {
        bannerMessage.removeHandlerCallback();
        bannerMessage = null;
    }


    //US54329: Feature Transitions code changes end
    public void setMessage(String message) {
        this.message = message;
        messageTextView.setText(CommonUtils.getHtmlFormattedText(message));
        messageTextView.setContentDescription(message);
        messageTextView.requestFocus();
    }
    /*US115912 : Reg D Count Bill Pay - Start*/
    public void setMessageWithToolTipIcon(String regDmessage, final int messageString, final String accType) {
        Html.ImageGetter getter = new Html.ImageGetter(){
            public Drawable getDrawable(String source){   // source is the resource name
                Drawable d = null;
                Integer id =  new Integer(0);
                id = messageString;
                d =  DiscoverApplication.getGlobalContext().getResources().getDrawable(id);

                if (d != null)
                    d.setBounds(0, -d.getIntrinsicHeight()/2 + 5, d.getIntrinsicWidth()-5, d.getIntrinsicHeight()/2);

                return d;
            }
        };
        String imgString = regDmessage + " <img src=\"verify_trial_deposit\"/>" + " ";
        Spannable htmlSpannable = (Spannable) Html.fromHtml(imgString, getter, null);
        for (ImageSpan span : htmlSpannable.getSpans(0, htmlSpannable.length(), ImageSpan.class)) {
            int flags = htmlSpannable.getSpanFlags(span);
            int start = htmlSpannable.getSpanStart(span);
            int end = htmlSpannable.getSpanEnd(span);

            htmlSpannable.setSpan(new URLSpan(span.getSource()) {
                @Override public void onClick(View v) {
                    FacadeFactory.getBankFacade().showCDModal(accType);

                }
            }, start, end, flags);
        }
        messageTextView.setText(htmlSpannable);
        messageTextView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public void setMessageWithToolTipIcon(String regDmessage, View view, int messageString, final String accType) {
        this.message = regDmessage;
        SpannableStringBuilder ssb_regdMsg = new SpannableStringBuilder(regDmessage.trim()+"   ");
        messageTextView.setMovementMethod(LinkMovementMethod.getInstance());
        messageTextView.setLineSpacing(-10f, 1.6f);
        /*Defect #9063 - Fixed*/
        Drawable tooltipIcon = context.getResources().getDrawable(messageString);
        //Start: US129547: RegD Tool Tip Changes
        if(!Utils.isRunningOnHandset(DiscoverActivityManager.getDiscoverApplicationContext())) {
            tooltipIcon.setBounds(0, 0, tooltipIcon.getIntrinsicWidth(), tooltipIcon.getIntrinsicHeight());
        }else{
            tooltipIcon.setBounds(0, 0, (int) (messageTextView.getLineHeight() * 0.8), (int) (messageTextView.getLineHeight() * 0.8));
        }
        //End: US129547: RegD Tool Tip Changes

        ImageSpan imageSpan = new ImageSpan(tooltipIcon, ImageSpan.ALIGN_BOTTOM) {
            public void draw(Canvas canvas, CharSequence text, int start,
                             int end, float x, int top, int y, int bottom,
                             Paint paint) {
                Drawable b = getDrawable();
                canvas.save();
                int transY = bottom - b.getBounds().bottom;
                //Start: US129547: RegD Tool Tip Changes
                if(!Utils.isRunningOnHandset(DiscoverActivityManager.getDiscoverApplicationContext())){
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        transY -= paint.getFontMetricsInt().descent / 2 - 4;
                    }else{
                        transY -= paint.getFontMetricsInt().descent * 2 + 2 ;
                    }
                }else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        transY -= paint.getFontMetricsInt().descent / 2 - 6;
                    }else{
                        transY -= paint.getFontMetricsInt().descent * 2 + 6;
                    }
                }
                //End: US129547: RegD Tool Tip Changes
                canvas.translate(x, transY);
                b.draw(canvas);
                canvas.restore();
            }
        };
        ssb_regdMsg.setSpan(imageSpan, ssb_regdMsg.length()-2, ssb_regdMsg.length()-1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); //US129547: RegD Tool Tip Changes

        ssb_regdMsg.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                //Tool Tip Clcik Fun
                FacadeFactory.getBankFacade().showCDModal(accType);
            }
        },ssb_regdMsg.length()-2,ssb_regdMsg.length()-1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        messageTextView.setText( ssb_regdMsg, TextView.BufferType.SPANNABLE );
        messageTextView.setContentDescription(regDmessage);
        messageTextView.requestFocus();
    }
    /*US115912 : Reg D Count Bill Pay - End*/

    private void setFragment(Fragment fragment) {
        this.fragment = fragment;
    }


    public BannerMessage(Context context) {
        createBannerView(context);
        messageTextView.setEllipsize(null);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP)
            ribben.setElevation(Utils.dpToPx(4,context.getResources().getDisplayMetrics()));;
    }


    /*
    * Constructor with type as a parameter for assigning ellipses
    */
    public BannerMessage(Context context,int type) {
        createBannerView(context);
        messageTextView.setOnClickListener(this);
            if (type == BannerMessage.WARNING_WITHOUT_ANIMATION) {
                messageTextView.setEllipsize(TextUtils.TruncateAt.END);
            } else {
                messageTextView.setEllipsize(null);
            }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP)
            ribben.setElevation(Utils.dpToPx(4,context.getResources().getDisplayMetrics()));;
    }

    /*
    * Method to create banner
    * */
    private void createBannerView(final Context context){
        this.context = context;
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ribben = inflater.inflate(R.layout.messge_banner, null);
        bannerLayout = (LinearLayout)ribben.findViewById(R.id.message_container_ll);
        bannerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type==FICO_ATTRIBUTE_UNAVAILABLE_ERROR){
                    final DiscoverAlertDialog ficoAttributUnavailableDialog = new DiscoverAlertDialog();
                    ficoAttributUnavailableDialog.setMessage(context.getResources().getString(R.string.cmn_fico_no_attribute_banner_message));
                    ficoAttributUnavailableDialog.setTitle(context.getResources().getString(R.string.cmn_fico_no_attribute_modal_title));
                    ficoAttributUnavailableDialog.setPositiveButton("Close", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ficoAttributUnavailableDialog.dismiss();
                        }
                    });
                    ficoAttributUnavailableDialog.setCanCancelable(true);
                    ficoAttributUnavailableDialog.show((AppCompatActivity)context);
                    ficoAttributUnavailableDialog.setCanceledOnTouchOutside(false);
                     /* Start Changes for 121913*/
                    TrackingHelper.trackPageView(AnalyticsPage.FICO_CREDITSCORE_ATTRIBUTE_UNAVAIL_MODAL_PG);
                   /* End Changes for 121913*/
                }
            }
        });
        ribben.requestFocus();
        messageTextView = (TextView) ribben.findViewById(R.id.messsage);
        statusDrawable = (ImageView) ribben.findViewById(R.id.banner_status_indicator);
        ribbenParent = (LinearLayout) ribben.findViewById(R.id.parentLayoutRibben);
        messageTextView.requestFocus();
    }

    public void show() {
        invalidate();
        bannerMessage.setVisibility(View.VISIBLE);
        bannerMessage.messageTextView.announceForAccessibility(bannerMessage.messageTextView.getText().toString());
        bannerMessage.messageTextView.sendAccessibilityEvent(AccessibilityEvent.TYPE_ANNOUNCEMENT);
        mHandler.removeCallbacks(mHide);
    }


    public void setRibbenType(int type) {
        this.type = type;
//        messageTextView.setCompoundDrawablesWithIntrinsicBounds(getDrawable(type), null, null, null);
        statusDrawable.setBackgroundDrawable(getDrawable(type));
        //here we check if the type is not error as the color handling for Error is done during the animation
        if (!(type == ERROR || type==FICO_ATTRIBUTE_UNAVAILABLE_ERROR || type==FICO_REVOLVING_UTIL_UNAVAILABLE_ERROR))
            ribbenParent.setBackgroundColor(messageTextView.getResources().getColor(getColor(type)));
    }

    private int getColor(int type) {
        int rValue;
        switch (type) {
            case SUCCESS:
                rValue = R.color.onboard_bannr_success_color;
                break;
            case ERROR:
                rValue = R.color.onboard_bannr_error_color;
                break;
            case WARNING:
                rValue = R.color.onboard_banner_warning;
                break;
            case WARNING_WITHOUT_ANIMATION:
                rValue = R.color.onboard_banner_warning;
                break;
            case FICO_REVOLVING_UTIL_UNAVAILABLE_ERROR:
            case FICO_ATTRIBUTE_UNAVAILABLE_ERROR:
                rValue = R.color.fico_banner_warning;
                break;
            default:
                rValue = R.color.onboard_bannr_success_color;
                break;
        }
        return rValue;
    }

    private Drawable getDrawable(int type) {
        Drawable rValue;
        switch (type) {
            case SUCCESS:
                rValue = context.getResources().getDrawable(R.drawable.onboard_success_global);
                break;
            case ERROR:
                rValue = context.getResources().getDrawable(R.drawable.onboard_error);
                break;
            case WARNING:
                rValue = context.getResources().getDrawable(R.drawable.warning_icon);
                break;
            case WARNING_WITHOUT_ANIMATION:
                rValue = context.getResources().getDrawable(R.drawable.warning_icon);
                break;
            case FICO_REVOLVING_UTIL_UNAVAILABLE_ERROR:
            case FICO_ATTRIBUTE_UNAVAILABLE_ERROR:
                rValue = context.getResources().getDrawable(R.drawable.new_info_icon);
                break;
            default:
                rValue = context.getResources().getDrawable(R.drawable.onboard_success_global);
                break;
        }
        return rValue;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    private long getDurationInMillisec() {
        long millies;
        switch (duration) {
            case BannerMessage.LENGTH_SHORT:
                millies = 2000L;
                break;
            case BannerMessage.LENGTH_LONG:
                millies = 90000L;
                break;
            default:
                millies = 3000L;
                break;
        }
        return millies;
    }

    public View getRibben() {
        return ribben;
    }


    public void setVisibility(int visibility) {
        ribben.setVisibility(visibility);
    }

    public int getVisibility() {
        return ribben.getVisibility();
    }

    private Runnable mHide = new Runnable() {

        @Override
        public void run() {
            ribben.setVisibility(View.GONE);
            if (listener != null && ((fragment != null && fragment.isVisible() && fragment.isMenuVisible()) || (fragment == null
                    && context != null && !((Activity) context).isFinishing()))) {
                //Sliding out to top animation for the Ribben message
                Animation animation = AnimationUtils.loadAnimation(fragment.getActivity(), R.anim.slide_to_top);

                animation.setAnimationListener(new Animation.AnimationListener() {

                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {

                        listener.onTimeOut();
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });

                getRibben().startAnimation(animation);

            }
        }
    };

    public void dismiss() {
        //check if the ERROR banner is shown
        if (((ViewGroup) rootView.findViewById(holerId)).getChildCount() > 0) {
            //remove the ERROR banner
//            ((ViewGroup) rootView.findViewById(holerId)).setVisibility(View.GONE);
            removeErrorBannerWithAnimation();

        } else if (((ViewGroup) rootView) == bannerMessage.getRibben().getParent())// check if the Success or Warning banner is shown
        {
            //remove the banner
            bannerMessage.getRibben().clearAnimation();
            dismissBannerWithAnimation();
        }

    }

    private void removeErrorBannerWithAnimation() {

        ScrollView animationView = (ScrollView) this.rootView.findViewById(holerId).getParent();
        int animationViewHeight = ((ViewGroup) rootView.findViewById(holerId)).getHeight();

        //scale the scroll view
        CmnScaleAnimation scale = new CmnScaleAnimation(animationView, 0, animationViewHeight);
        scale.setDuration(ANIMATION_DURATION);
        animationView.startAnimation(scale);
        //translate animation to move the banner down
        TranslateAnimation translate = new TranslateAnimation(0, 0, 0, -animationViewHeight);
        translate.setDuration(ANIMATION_DURATION);
        ((ViewGroup) rootView.findViewById(holerId)).startAnimation(translate);

        scale.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ((ViewGroup) rootView.findViewById(holerId)).removeAllViews();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

    }

    /**
     * This method will dismiss the banner that is shown and with reverse animation
     */
    private void dismissBannerWithAnimation() {
        Animation successUpAnimation = AnimationUtils.loadAnimation(context, R.anim.slide_to_top);
        if (bannerMessage != null && bannerMessage.getRibben() != null) {
            bannerMessage.getRibben().startAnimation(successUpAnimation);
            successUpAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    ((ViewGroup) rootView).removeView(bannerMessage.getRibben());
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
        }
    }

    private void removeHandlerCallback() {
        mHandler.removeCallbacks(mHide);
    }

    /*public void destroyRibben() {
        if (bannerMessage != null && bannerMessage.getRibben() != null) {
            bannerMessage.getRibben().setVisibility(View.GONE);

            bannerMessage.purge();
        }

    }*/

    /**
     * Method to remove added baner, added for Defect# 18153
     */
    public void dismissBannerWithoutAnimation() {
        if (bannerMessage != null && rootView != null && ((ViewGroup) rootView) == bannerMessage.getRibben().getParent()) {
            //remove the banner
            bannerMessage.getRibben().clearAnimation();
            ((ViewGroup) rootView).removeView(bannerMessage.getRibben());
        }
    }

    public void setTimeOutListener(TimeOutListener listener) {
        this.listener = listener;
    }

    //US54329: Feature Transitions code changes start
    //Function to get the ribben message listener
    public TimeOutListener getTimeOutListener() {
        return listener;
    }

    /*
    * Method for click listener for message textview
    * */
    @Override
    public void onClick(View view) {
        if (type == BannerMessage.WARNING_WITHOUT_ANIMATION){
            if(view.getId()== R.id.messsage){
               FacadeFactory.getBankFacade().showCDModal();
            }
        }
    }


    //US54329: Feature Transitions code changes end

    public interface TimeOutListener {
        public void onTimeOut();
    }

    /**
     * This method will adjust the banner padding depending on the orientation and also the device type
     * Call this on orientation change to handle the appropriate padding in tablet.No need to use this in handset
     */
    public void invalidate() {
        //check the orientation of the banner
        boolean isLandscape = context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;

        if (!Utils.isRunningOnHandset(context)) {
            if (((ViewGroup) rootView.findViewById(holerId)).getChildCount() > 0 || ((ViewGroup) rootView) == bannerMessage.getRibben().getParent()) {
                if (isLandscape) {
                    /**
                     * We handle the landscape mode for the tablet
                     */
                    if (((ViewGroup) rootView) == bannerMessage.getRibben().getParent()) //succeess message
                        bannerMessage.getRibben().setPadding(dpToPx(TABLET_LANDSCAPE_PADDING), dpToPx(0), dpToPx(0), dpToPx(0));
                    else//error message
                        ((ViewGroup) rootView.findViewById(R.id.banner_container)).setPadding(dpToPx(TABLET_LANDSCAPE_PADDING), dpToPx(0), dpToPx(TABLET_LANDSCAPE_PADDING), dpToPx(0));
                } else {
                    if (((ViewGroup) rootView) == bannerMessage.getRibben().getParent()) //success message
                        bannerMessage.getRibben().setPadding(dpToPx(TABLET_PORTRAIT_PADDING), dpToPx(0), dpToPx(0), dpToPx(0));
                    else//error message
                        ((ViewGroup) rootView.findViewById(R.id.banner_container)).setPadding(dpToPx(TABLET_PORTRAIT_PADDING), dpToPx(0), dpToPx(TABLET_PORTRAIT_PADDING), dpToPx(0));
                }

            }
        } else {
            //here we take care of the padding for the handset
            if (((ViewGroup) rootView) == bannerMessage.getRibben().getParent()) //check if the banner is added for Success type
                bannerMessage.getRibben().setPadding(dpToPx(HANDSET_PORTRAIT_PADDING), dpToPx(0), dpToPx(0), dpToPx(0));
            else//this is for the error message
                ((ViewGroup) rootView.findViewById(R.id.banner_container)).setPadding(dpToPx(HANDSET_PORTRAIT_PADDING), dpToPx(0), dpToPx(HANDSET_PORTRAIT_PADDING), dpToPx(0));

        }

    }

    /**
     * This method will convert the DO to appropriate value of pixel
     *
     * @param dp Value in DP
     * @return pixel value of the DP
     */
    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private class CustomOutline extends ViewOutlineProvider {

        int width;
        int height;

        CustomOutline(int width, int height) {
            this.width = width;
            this.height = height;
        }

        @Override
        public void getOutline(View view, Outline outline) {
            outline.setRect(0, 0, width, height);
        }
    }

}