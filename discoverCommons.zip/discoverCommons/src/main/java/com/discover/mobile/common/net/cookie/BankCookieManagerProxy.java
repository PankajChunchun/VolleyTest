package com.discover.mobile.common.net.cookie;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.CookieStore;
import java.net.HttpCookie;
import java.net.URI;
import java.sql.Date;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit.client.Header;
import retrofit.client.Response;

public class BankCookieManagerProxy extends CookieManager {

    private static final String TAG = BankCookieManagerProxy.class
            .getSimpleName();

    private static final String DISCOVER_BANK_PREF = "DiscoverBankPref";
    private static final String PERSIST_DOMAIN = ".discoverbank.com";

    private final String PERSIST_URL = "URI";
    private final String PMDATA = "pmdata";

    private Context context = null;
    private CookieStore cookieStore = null;

    public BankCookieManagerProxy() {
        this(null, null);
    }

    public BankCookieManagerProxy(Context context) {
        this(null, null, context);
    }

    public BankCookieManagerProxy(CookieStore store, CookiePolicy cookiePolicy) {
        this(null, null, null);
    }

    public BankCookieManagerProxy(CookieStore store, CookiePolicy cookiePolicy,
                                  Context context) {
        this.context = context;
        this.cookieStore = new BankCookieStoreProxy(this);
        android.webkit.CookieSyncManager.createInstance(context);
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);

        clearAllCookies();
    }

    @Override
    public Map<String, List<String>> get(URI uri,
                                         Map<String, List<String>> requestHeaders) throws IOException {

        Map<String, List<String>> result = new HashMap<String, List<String>>();
        String cookies = android.webkit.CookieManager.getInstance().getCookie(
                uri.toString());

        if (cookies != null) {
            result.put("Cookie", Arrays.asList(cookies));
        }

        return result;
    }

    @Override
    public void put(URI uri, Map<String, List<String>> responseHeaders)
            throws IOException {
        if (uri == null || responseHeaders == null) {
            return;
        }

        String url = uri.toString();
        for (String headerKey : responseHeaders.keySet()) {
            if (headerKey == null
                    || !(headerKey.equals("Set-Cookie2") || headerKey
                    .equals("Set-Cookie"))) {

                continue;
            }

            for (String cookie : responseHeaders.get(headerKey)) {

                android.webkit.CookieManager.getInstance().setCookie(url,
                        cookie);
                try {
                    persistPMCookie(url, cookie);
                } catch (Exception e) {
                    // Never let persisting cookies cause a crash
                    // Utils.log(TAG, "Failed to persist cookies.");
                }

            }
        }
    }

    /**
     * Method extracts cookie string from retrofit headers
     */
    public void putCookiesRetrofit(String uri, Response response) {
        if (uri == null || response.getHeaders() == null) {
            return;
        }
        for (Header header : response.getHeaders()) {

            if (header.getName() == null
                    || !(header.getName().equals("Set-Cookie2") || header
                    .getName().equals("Set-Cookie"))) {
                continue;
            }

            if (null != header.getName()) {

                android.webkit.CookieManager.getInstance().setCookie(uri,
                        header.getValue());

                try {
                    persistPMCookie(uri, header.getValue());
                } catch (Exception e) {
                    // Never let persisting cookies cause a crash
                    // Utils.log(TAG, "Failed to persist cookies.");
                }

            }
        }

    }

    @Override
    public void setCookiePolicy(CookiePolicy cookiePolicy) {
        // Do nothing. This is handled by the webkit cookie manager.
    }

    @Override
    public CookieStore getCookieStore() {
        return cookieStore;
    }


    public void clearAllCookies() {

        android.webkit.CookieManager.getInstance().removeAllCookie();
        restoreOldPMData();
    }

    /*
     * All cookies to be stored are passed to this method. If we find
     * interesting ones, we save them to a database to be reloaded the nxt time
     * the app starts.
     */
    private void persistPMCookie(String uri, String cookieString) {
        List<HttpCookie> cookieList = HttpCookie.parse(cookieString);
        for (HttpCookie cookie : cookieList) {
            if (PMDATA.contains(cookie.getName().toLowerCase())) {
                SharedPreferences sharedPref = context.getSharedPreferences(
                        DISCOVER_BANK_PREF, Context.MODE_PRIVATE);
                sharedPref.edit().putString(PMDATA, cookie.getValue()).commit();
                sharedPref.edit().putString(PERSIST_URL, uri).commit();
            }
        }

    }

    private void restoreOldPMData() {
        if (context == null) {
            return;
        }

        String storedPMData = readPMDataFromPreferance();
        if (storedPMData.equalsIgnoreCase("")) {
            return;
        }


        Date time = new Date(System.currentTimeMillis());
        time.setTime(time.getTime() + (3600 * 24 * 365 * 1000)); // one year
        // (-ish)
        String newCookie = "PMData=" + storedPMData + ";Expires="
                + time.toGMTString() + ";Domain=" + PERSIST_DOMAIN
                + ";Path=/;Secure;HttpOnly";
        android.webkit.CookieManager.getInstance().setCookie(readURIFromPreferance(),
                newCookie);


    }

    /**
     * Added method to read PM data cookie from preferences.
     * This will use for BB redirect for CLA merge interception.
     *
     * @return PMdata from preferences
     */
    public String readPMDataFromPreferance() {
        SharedPreferences sharedPref = context.getSharedPreferences(
                DISCOVER_BANK_PREF, Context.MODE_PRIVATE);
        String storedPMData = sharedPref.getString(PMDATA, null);
        String storedURI = sharedPref.getString(PERSIST_URL, null);
        if (storedPMData == null) {
            storedPMData = "";
        }
        return storedPMData;

    }

    /**
     * Added method to read PM data cookie from preferences.
     * This will use for BB redirect for CLA merge interception.
     *
     * @return PMdata from preferences
     */
    public String readURIFromPreferance() {
        SharedPreferences sharedPref = context.getSharedPreferences(
                DISCOVER_BANK_PREF, Context.MODE_PRIVATE);
        String storedPMData = sharedPref.getString(PMDATA, null);
        String storedURI = sharedPref.getString(PERSIST_URL, null);
        if (storedURI == null) {
            storedURI = "";
        }
        return storedURI;

    }

}