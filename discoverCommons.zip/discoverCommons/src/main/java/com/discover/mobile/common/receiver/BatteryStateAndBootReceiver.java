package com.discover.mobile.common.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by hlin0 on 3/3/2016.
 */
public class BatteryStateAndBootReceiver extends BroadcastReceiver {

    String TAG = this.getClass().getSimpleName();

    /**
     * Responds to
     * GPS toggle on/off
     * Battery change to low or okay state
     * Device boot complete	 *
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "onReceive()...intent.getAction(): " + intent.getAction());
        //TODO: Service calls should happen only for pilot/targetted users. But now it is being invoked for all users. This is increasing service calls.
        //TODO: Method commented to avoid Geofence service calls. Revisit in upcoming sprints.
//        if (Intent.ACTION_BATTERY_LOW.matches(intent.getAction())) {
//            FacadeFactory.getCardFacade().callGeofenceServiceToRemove(context);
//        } else if (Intent.ACTION_BATTERY_OKAY.matches(intent.getAction())) {
//            FacadeFactory.getCardFacade().callGeofenceServiceToAdd(context);
//        } else {
//            Log.d(TAG, "onReceive()...else: " + intent.getAction());
//            //FacadeFactory.getCardFacade().callGeofenceServiceToAdd(context);
////            Intent intent = new Intent(context.getApplicationContext(), GeofenceTransitionsService.class);
////            intent.putExtra(GeofenceTransitionsService.REG_MODE_KEY, GeofenceTransitionsService.REG_MODE_REG);
////            context.startService(intent);
//        }

    }


}
