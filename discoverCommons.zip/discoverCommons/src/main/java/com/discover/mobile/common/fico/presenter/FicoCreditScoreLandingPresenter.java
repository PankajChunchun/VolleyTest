package com.discover.mobile.common.fico.presenter;

import android.os.Bundle;

/**
 * Created by 436645 on 3/27/2017.
 */
public interface FicoCreditScoreLandingPresenter {

    void getFicoScoreListData(Bundle bundle);

}
