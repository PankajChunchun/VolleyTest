package com.discover.mobile.common.onboardwiz.fragment.quickview;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.fragment.IPopFragment;
import com.discover.mobile.common.onboardwiz.fragment.OnBoardNavigationListener;
import com.discover.mobile.common.onboardwiz.service.OnBoardServiceClass;
import com.discover.mobile.common.onboardwiz.utils.CustomModal;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.onboardwiz.utils.RibbenMessage;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.ui.modals.EnhancedContentModal;
import com.discover.mobile.common.uiwidget.CmnButton;
import com.discover.mobile.common.uiwidget.CmnTextView;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;

/**
 * Created by 482127 on 4/25/2016.
 */
public class OnBoardEnableQuickViewFragment extends Fragment implements View.OnClickListener, RibbenMessage.TimeOutListener, IPopFragment {
    private final static String mQVLandingHeaderText = "onboard_qv_landing_body";
    private final static String mQVLandingBodyText = "onboard_qv_landing_label";
    private final static String mQVConfirmationSubHeader2 = "onboard_passcode_post_confirmation";
    private final static String mQVConfirmationSubHeader1 = "onboard_qv_enabled_confirmation";
    private final static String mQVModalContent = "onboard_qv_enable_modal";
    public static OnBoardConstant.QUICKVIEW_PAGE_STATE quickview_page_state = OnBoardConstant.QUICKVIEW_PAGE_STATE.ENABLE_PAGE;
    private static boolean isQuickViewEnabled = false;
    CustomModal modal;
    private View mView;
    private Context mContext;
    private CmnTextView mSetupPasscode, mQuickViewInfo, mQuickViewMsg;
    private Button btnEnable;
    private AlertDialog qvEnablementModal;
    private ImageView mQuickViewImage;
    private static final String CONFIRMTAGS="confirmQV";
    private static final String SUCCESSTAGS="successQV";
    private static final String QUICKVIEWENABLETAGS="QVenableimage";


    /**
     * Handler for webservice request made from enable modal accept button click.
     */
    NetworkRequestListener requestHandler = new NetworkRequestListener() {
        @Override
        public void onSuccess(Object data) {
            showConfirmationPage();
        }

        @Override
        public void onError(Object data) {
            handleError(data.toString());
        }
    };
    private ImageView mCheckMark;
    private boolean isTimeout = false;
    private OnBoardServiceClass onBoardServiceClass;

    public static boolean getCurrentState() {
        return isQuickViewEnabled;
    }

    public static void updateState(OnBoardConstant.QUICKVIEW_PAGE_STATE quickView_stat) {
        quickview_page_state = quickView_stat;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mContext = activity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mView = LayoutInflater.from(mContext).inflate(R.layout.onboard_quickview_landing, null);
        initUI();
      /*  //US53328-START
        TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_INTRO_PAGE_NAME, null);
         //ENDS*/
        OnBoardHelper.visiblityForExitButton(getActivity(), true);

        onBoardServiceClass = new OnBoardServiceClass(mContext);
        return mView;
    }

    public void updateUI() {
        if (OnBoardHelper.mQuickvieweAnim) {
            OnBoardHelper.mQuickvieweAnim = false;
            mSetupPasscode.setVisibility(View.INVISIBLE);
            btnEnable.setVisibility(View.INVISIBLE);
            mQuickViewInfo.setVisibility(View.INVISIBLE);
            mQuickViewMsg.setVisibility(View.INVISIBLE);
            btnEnable.setVisibility(View.INVISIBLE);
            android.view.animation.Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.possocde_slide_in_right);
            //start view animation
            mView.findViewById(R.id.qv_success_view).startAnimation(animation);

            mSetupPasscode.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mSetupPasscode.setVisibility(View.VISIBLE);
                    btnEnable.setVisibility(View.VISIBLE);
                    mQuickViewInfo.setVisibility(View.VISIBLE);
//                    mQuickViewMsg.setVisibility(View.VISIBLE);
                    // btnEnable.setVisibility(View.VISIBLE);

                }
            }, 300);
        }
    }

    private void initUI() {
        mSetupPasscode = (CmnTextView) mView.findViewById(R.id.setup_qv_text);
        btnEnable = (Button) mView.findViewById(R.id.qvEnable);
        mQuickViewInfo = (CmnTextView) mView.findViewById(R.id.text_quickview);
        mQuickViewImage = (ImageView) mView.findViewById(R.id.imageView2);
        mQuickViewImage.setTag(QUICKVIEWENABLETAGS);
        Log.v("QuickViewEnablePage",mQuickViewImage.getTag().toString());


        mCheckMark = (ImageView) mView.findViewById(R.id.check_mark);
        mQuickViewMsg = (CmnTextView) mView.findViewById(R.id.txt_qv_msg);
        btnEnable.setOnClickListener(this);

        Bitmap defaultBitmap = null;
        String imageName = null;
        if (Globals.isBankLoginSelected()) {
            //bank login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_quick_enable_bank);
            imageName = "onboard_quick_enable_bank.png";
        } else {
            //card login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_quickview);
            imageName = "onboard_quickview.png";
        }
        CommonUtils.setBitmapImage(mQuickViewImage, ImageDir.DIR_ENUM.ONBOARDING, imageName, defaultBitmap);
        // Drawable passcodeDrawable = ResourcesCompat.getDrawable(getResources(), Globals.isBankLoginSelected() ? R.drawable.onboard_quick_enable_bank : R.drawable.onboard_quickview, null);
        // mQuickViewImage.setImageDrawable(passcodeDrawable);

        mQuickViewImage.setContentDescription(getString(R.string.quickview_enable_img_content_desc));


        CommonUtils.setDisplayText(mQuickViewInfo, mQVLandingBodyText, getResources().getString(R.string.onboard_qv_pre_enable_msg));
        CommonUtils.setDisplayText(mSetupPasscode, mQVLandingHeaderText, getResources().getString(R.string.onboard_quickview_landing_text));

        String displayText = InfoMessageUtils.Instance().getErrorMessage(mQVLandingHeaderText);
        if (CommonUtils.isNullOrEmpty(displayText)) {
            displayText = getResources().getString(R.string.onboard_quickview_landing_text);
        }
        setTextWithSpan(mSetupPasscode, displayText, "Quick View", new ForegroundColorSpan(getResources().getColor(R.color.cmn_orange)));
    }

    void setTextWithSpan(TextView textView, String text, String spanText, ForegroundColorSpan style) {
        SpannableStringBuilder sb = new SpannableStringBuilder(text);
        int start = text.indexOf(spanText);
        int end = start + spanText.length();
        sb.setSpan(style, start, end, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        textView.setText(sb);
    }

    private void showEnableQuickViewModel() {

        View v = getActivity().getLayoutInflater().inflate(R.layout.onboard_quickview_enable_model, null);

        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    (R.string.bank_analytics_onboard_quickview_enable_modal));

        }
        modal = new CustomModal(getActivity(), v);
        modal.setCancelable(true);
        modal.setCanceledOnTouchOutside(true);
        //US53334 End

        //added to fetch the contents from info json
        CmnTextView quickViewDesc = (CmnTextView) v.findViewById(R.id.text_enable_description);
        CommonUtils.setDisplayText(quickViewDesc, mQVModalContent, getResources().getString(R.string.onboard_quickview_model_description));
        quickViewDesc.setContentDescription(getResources().getString(R.string.onboard_quickview_model_description));

        Button btnAccept = (Button) v.findViewById(R.id.button_accept);
        CmnButton btnCancel = (CmnButton) v.findViewById(R.id.button_cancel);
        btnAccept.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        modal.show();

        //US53328-START
        if (Globals.isFromCardSide()) {
            TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_MODAL_PAGE_NAME, null);
        }
        //ENDS
    }

    private void dismissEnableModelView() {
        if (modal != null && modal.isShowing()) {
            modal.dismiss();
            modal = null;
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_exit) {
            /*//US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                    *//*extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.onboard_paperless_tag));*//*
                TrackingHelper.trackBankPage(null, extras);
            }
            //US53334 End*/
            if (mContext instanceof OnBoardActivity) {
                OnBoardHelper.navigateToCardOrBankHome();
            }
        } else if (v.getId() == R.id.qvEnable) {
            if (Globals.isFromCardSide()) {
                //US53328-STARTS
                analyticsForEnableButton();
                //ENDS
            }
            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_quickview_enable_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_quickview_into));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
            //US53334 End
            showEnableQuickViewModel();
        } else if (v.getId() == R.id.button_accept) {
            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1,
                        getResources().getString(R.string.bank_analytics_onboard_quickview_accept_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_quickview_enable_modal));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
            //US53334 End
            dismissEnableModelView();
            if (Globals.isFromCardSide()) {
                //US53328-START
                analyticsForAcceptButton();
                //ends

            }

            onBoardServiceClass.enableQuickView(requestHandler);
            android.view.animation.Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.fade_out_animation);
            //start view animation
            mSetupPasscode.startAnimation(animation);
            mQuickViewImage.startAnimation(animation);
            mQuickViewInfo.startAnimation(animation);
            btnEnable.startAnimation(animation);
        } else if (v.getId() == R.id.button_cancel) {
            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1,
                        getResources().getString(R.string.bank_analytics_onboard_quickview_cancel_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_quickview_enable_modal));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
            //US53334 End
            dismissEnableModelView();

            //US53328-START
            if (Globals.isFromCardSide()) {
                analyticsForCancelButton();
                trackPageFromCancel();
            }
            //ends
        }
    }

    public void showConfirmationPage() {
        mSetupPasscode.setTag(CONFIRMTAGS+"ConfirmSetuppasscodeTextview");
        btnEnable.setTag(CONFIRMTAGS+"ConfirmbtnEnable");
        mQuickViewInfo.setTag(CONFIRMTAGS+"ConfirmqvInfo");
        mQuickViewMsg.setTag(CONFIRMTAGS+"ConfirmqvMsg");
        mCheckMark.setTag(CONFIRMTAGS+"ConfirmCheckMark");
        mView.setTag(CONFIRMTAGS+"parentConfirm");

        if (Globals.isFromCardSide()) {

            //US53328
            TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_SUCCESS_PAGE_NAME, null);

            //END
        }
        updateState(OnBoardConstant.QUICKVIEW_PAGE_STATE.CONFIRMATION_PAGE);
        OnBoardHelper.visiblityForExitButton(getActivity(), false);
        isQuickViewEnabled = true;
        CommonUtils.setDisplayText(mQuickViewInfo, mQVConfirmationSubHeader1, getResources().getString(R.string.onboard_qv_enable_msg));
        mSetupPasscode.setVisibility(View.INVISIBLE);

        Bitmap defaultBitmap = null;
        String imageName = null;
        if (Globals.isBankLoginSelected()) {
            //bank login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_quick_success_bank);
            imageName = "onboard_quick_success_bank.png";
        } else {
            //card login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_quickview_success);
            imageName = "onboard_quickview_success.png";
        }
        CommonUtils.setBitmapImage(mQuickViewImage, ImageDir.DIR_ENUM.ONBOARDING, imageName, defaultBitmap);
        mQuickViewImage.setTag(CONFIRMTAGS+"confirmImage");
        Log.v("QuickView Confirm",mQuickViewImage.getTag().toString());

        //   Drawable passcodeDrawable = ResourcesCompat.getDrawable(getResources(), Globals.isBankLoginSelected() ? R.drawable.onboard_quick_success_bank : R.drawable.onboard_quickview_success, null);
        // mQuickViewImage.setImageDrawable(passcodeDrawable);

        btnEnable.setVisibility(View.GONE);
        mQuickViewImage.setContentDescription(getString(R.string.quickview_enabled_img_content_desc));
        //mQuickViewImage.setImageDrawable(getResources().getDrawable(R.drawable.onboard_quickview_success));
        android.view.animation.Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.fade_in_fade_out_animation);
        //start view animation
        mQuickViewImage.startAnimation(animation);
        mQuickViewInfo.startAnimation(animation);
        // mCheckMark.startAnimation(animation);
        showRibbenMessage();

    }

    void showSuccessPage() {
        mSetupPasscode.setTag(SUCCESSTAGS+"SetuppasscodeTextview");
        btnEnable.setTag(SUCCESSTAGS+"ConfirmbtnEnable");
        mQuickViewInfo.setTag(SUCCESSTAGS+"SuccessqvInfo");
        mQuickViewMsg.setTag(SUCCESSTAGS+"SuccessqvMsg");
        mCheckMark.setTag(SUCCESSTAGS+"SuccessCheckMark");
        mView.setTag(SUCCESSTAGS+"parentSuccess");
        mQuickViewImage.setTag(SUCCESSTAGS+"Image");

        Log.v("QV success",mQuickViewImage.getTag().toString());

        mSetupPasscode.setVisibility(View.VISIBLE);
        updateState(OnBoardConstant.QUICKVIEW_PAGE_STATE.QUICKVIEW_DONE_PAGE);
        mSetupPasscode.setContentDescription(getString(R.string.onboard_qv_enable));
        mCheckMark.setVisibility(View.VISIBLE);
        btnEnable.setVisibility(View.GONE);
        CommonUtils.setDisplayText(mQuickViewMsg, mQVConfirmationSubHeader2, getResources().getString(R.string.onboard_qv_info));
        mQuickViewMsg.setVisibility(View.VISIBLE);
        OnBoardHelper.visiblityForExitButton(getActivity(), true);
        handleReminderVisibility();

        setTextWithSpan(mSetupPasscode, getString(R.string.onboard_qv_enable), "Quick View", new ForegroundColorSpan(getResources().getColor(R.color.cmn_orange)));


        // mQuickViewImage.startAnimation(animation);
        // mQuickViewMsg.startAnimation(animation);


    }

    private void handleReminderVisibility() {
        FacadeFactory.getWhatsNewReminderFacade().isAllowQuickViewAccess(mContext, true);
    }

    private void showRibbenMessage() {
        OnBoardHelper.hideExitButton(getActivity());
        FrameLayout layout = (FrameLayout) mView.findViewById(R.id.qv_main_view);
        RibbenMessage.make(this, layout, R.string.onboard_ribben_qv_enable, RibbenMessage.LENGTH_EXTRA_LONG, RibbenMessage.SUCCESS, this).show();
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    (R.string.bank_analytics_onboard_quickview_success_confirmation));

        }
        //US53334 End
    }

    @Override
    public void onTimeOut() {
        Fragment fragment = OnBoardHelper.getCurrentChildFragment(getActivity().getSupportFragmentManager().findFragmentById(R.id.contentView));
        if (fragment instanceof OnBoardNavigationListener) {
            OnBoardHelper.mPaperlessAnim = true;
            ((OnBoardNavigationListener) fragment).moveToNextPage();
        }
        showSuccessPage();
    }

    @Override
    public boolean popBackStack() {
        Fragment fragment = OnBoardHelper.getCurrentChildFragment(getActivity().getSupportFragmentManager().findFragmentById(R.id.contentView));
        if (fragment instanceof OnBoardNavigationListener) {
            ((OnBoardNavigationListener) fragment).moveToPreviousPage();
        }
        return true;
    }

    @Override
    public void updateCurrentPage() {
        //settimeouttoNull
        OnBoardHelper.visiblityForExitButton(getActivity(), true);
        if (isQuickViewEnabled) {

            RibbenMessage.destroyRibben();
            showSuccessPage();
            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        (R.string.bank_analytics_onboard_quickview_enabled_pg));

            }
            //US53334 End

        }


    }

    public void handleError(String errorCode) {

        EnhancedContentModal modal = new EnhancedContentModal(mContext, R.string.E_T_4031102, R.string.E_500_common, R.string.close_text, null, null);
        modal.hideNeedHelpFooter();
        modal.setErrorIconVisibility(true);
        com.discover.mobile.common.Utils.showCustomAlert(modal);

    }

    //US53328-STARTS

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (!Globals.isBankLoginSelected())
                FacadeFactory.getCardFacade().updateReminderCount(mContext, OnBoardConstant.QUICKVIEW_REMINDER);
        }
    }

    public void analyticsForAcceptButton() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PROP13);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ACCEPT_BUTTON_PEV1);


        TrackingHelper.trackCardPage(null, extras);
    }

    public void analyticsForCancelButton() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PROP13);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_CANCEL_BUTTON_PEV1);


        TrackingHelper.trackCardPage(null, extras);
    }

    public void analyticsForEnableButton() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PROP13);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_ENABLE_BUTTON_PEV1);


        TrackingHelper.trackCardPage(null, extras);
    }

    public boolean isQuickViewEnabled() {
        return isQuickViewEnabled;
    }

    public void trackPageFromCancel() {
        boolean qvState = OnBoardEnableQuickViewFragment.getCurrentState();
        if (qvState) {

            TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_STEP_COMPLETE_PAGE_NAME, null);


        } else {
            TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_INTRO_PAGE_NAME, null);

        }
    }

    //ends
}
