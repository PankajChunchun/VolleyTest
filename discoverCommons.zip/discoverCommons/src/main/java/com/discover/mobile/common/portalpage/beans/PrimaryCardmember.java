package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class PrimaryCardmember implements Serializable {

    private static final long serialVersionUID = -2201585732168514440L;

    @SerializedName("nameOnCard")
    private String nameOnCard;

    @SerializedName("emailAddress")
    private String emailAddress;

    /**
     * @return The nameOnCard
     */
    public String getNameOnCard() {
        return nameOnCard;
    }

    /**
     * @param nameOnCard The nameOnCard
     */
    public void setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
    }

    /**
     * @return The emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * @param emailAddress The emailAddress
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

}
