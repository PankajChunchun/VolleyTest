package com.discover.mobile.common.fico.service;

import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.interactor.FicoCreditScoreInteractor;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.network.AdapterProvider;
import com.discover.mobile.network.CommonAdapterProvider;
import com.discover.mobile.network.CommonRequestInterceptor;
import com.discover.mobile.network.ServiceGenerator;
import com.discover.mobile.network.error.GenericErrorResponseParser;
import com.discover.mobile.network.error.bean.ErrorBean;

import android.content.Context;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by slende on 5/4/2017.
 * Fico credit score service class
 */
public class FicoCreditScoreServiceClass implements FicoCreditScoreInteractor {

    private Context mContext = null;

    public FicoCreditScoreServiceClass() {
    }

    @Override
    public void getFicoCreditScore(final NetworkRequestListener listener) {

        // mContext is not needed
        AdapterProvider adapterProvider = new CommonAdapterProvider(mContext, null, new CommonRequestInterceptor(null, mContext));
        adapterProvider.createRestAdapter();

        FicoCreditScoreServiceInterface ficoCreditServiceProxy = ServiceGenerator.createService(FicoCreditScoreServiceInterface.class, adapterProvider);
        ficoCreditServiceProxy.getFicoCreditDetails(new Callback<FicoCreditScore>() {

            @Override
            public void failure(RetrofitError retrofitError) {

                GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(mContext, retrofitError, null);
                ErrorBean errorbean = genericErrorResponseParser.handleCardErrorforResponse();
                listener.onError(errorbean);

            }

            @Override
            public void success(FicoCreditScore statusResponse, Response response) {
                listener.onSuccess(statusResponse);
            }
        });

    }
}
