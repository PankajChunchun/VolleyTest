package com.discover.mobile.common.portalpage;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.discover.mobile.common.DiscoverModalManager;
import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fico.CmnFicoCreditScoreActivity;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.portalpage.adapters.PortalPageListAdapter;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.beans.BankErrorAccount;
import com.discover.mobile.common.portalpage.beans.BankVerifyAccount;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.beans.CardErrorAccount;
import com.discover.mobile.common.portalpage.beans.DepositAccount;
import com.discover.mobile.common.portalpage.beans.IraPlan;
import com.discover.mobile.common.portalpage.beans.LoanAccount;
import com.discover.mobile.common.portalpage.beans.User;
import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.listener.PortalListAnimationListener;
import com.discover.mobile.common.portalpage.listener.PortalListItemClickInterface;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalConstants;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.portalpage.view.PortalAccountBox;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.ui.modals.EnhancedContentModal;
import com.discover.mobile.common.uiwidget.CmnTextView;
import com.discover.mobile.common.uiwidget.dynamiclist.CmnDraggableListActionListener;
import com.discover.mobile.common.uiwidget.dynamiclist.CmnDraggableListAdapterListener;
import com.discover.mobile.common.uiwidget.dynamiclist.CmnDraggableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.discover.mobile.common.portalpage.utils.PortalConstants.Misc.PORTAL_ACCOUNT_CLOSED_KEY;
import static com.discover.mobile.common.portalpage.utils.PortalConstants.Misc.PORTAL_ACCOUNT_LIST_SORTED_KEY;

public class PortalPageListFragment extends Fragment implements CmnDraggableListAdapterListener, PortalPageUIInterface, ListView.OnItemClickListener, CmnDraggableListActionListener, PortalListAnimationListener{

    private final String TAG = PortalPageListFragment.class.getSimpleName();

    public final String BANKSUMMARYSTATUSINVALID = "invalid";
    public final String BANKSUMMARYSTATUSERROR = "error";
    TextView terms, termsLand;
    TextView feedback, feedbackLand;
    private CmnDraggableListView portalListV1, portalListV2;
    private RelativeLayout bank_error_card_image_view;
    private RelativeLayout bank_data_error_layout;
    //US50216
    private ImageView bank_data_error_image, bankDataErrorImageLandscape;
    private TextView bankDataBadCustomerErrorStatusMsgPortrait, bankDataBadCustomerErrorStatusMsgLandscape;
    private TextView bandBadcustomerErrorMsgTitlePortrait, bandBadcustomerErrorMsgTitleLandscape;
    /** Collection of account list in a Order given as per requirement */
    private List<PortalBoxInterface> mSortedPortalAccounList = null;
    private Bundle portalListBundle = null;
    private View view;
    private RelativeLayout footerLayout;
    private LinearLayout ficoContainer;
    private CmnTextView ficoTitleText;
    private List<PortalBoxInterface> mUpdatedPortalAccountList;
    private PortalPagePresenter mPortalPagePresenter;
    private Context mContext;
    private boolean isPortalListOrderChanged = false;
    private CmnDraggableListActionListener mCmnDraggableListActionListener;
    private boolean isInDraggingState;
    private int mDraggingItemPosition;
    private boolean closedAccount;


    /**
     * Method for Setting the Height of the ListView dynamically. Fix the issue
     * of not showing all the items of the ListView when placed inside a
     * ScrollView
     */
    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null)
            return;

        int desiredWidth = MeasureSpec.makeMeasureSpec(listView.getWidth(),
                MeasureSpec.UNSPECIFIED);
        int totalHeight = 0;
        View view = null;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            view = listAdapter.getView(i, view, listView);
            if (i == 0)
                view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth,
                        LayoutParams.WRAP_CONTENT));

            view.measure(desiredWidth, MeasureSpec.UNSPECIFIED);
            totalHeight += view.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        User.getInstance().setUserId(Globals.getCurrentUser());


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        mPortalPagePresenter = new PortalPagePresenterImpl(this, this);
        view = inflater.inflate(R.layout.portal_page_list_fragment, null);
        bank_error_card_image_view = (RelativeLayout) inflater.inflate(R.layout.bank_data_error_layout, null);
        //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- Start- Alex
        footerLayout = (RelativeLayout) inflater.inflate(R.layout.portal_footer, null);
        //Crashlytics--209--Adding fix for handling a scenario when running on handset--This crash was reproducible and its fixed
        if (CommonUtils.isRunningOnHandset(mContext)) {
            terms = (TextView) footerLayout.findViewById(R.id.privacy_terms_portal);
            feedback = (TextView) footerLayout.findViewById(R.id.provide_feedback_button_portal);
        }
        else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            termsLand = (TextView) view.findViewById(R.id.privacy_terms_portal_land);
            feedbackLand = (TextView) view.findViewById(R.id.provide_feedback_button_portal_land);
        } else {

            terms = (TextView) footerLayout.findViewById(R.id.privacy_terms_portal);
            feedback = (TextView) footerLayout.findViewById(R.id.provide_feedback_button_portal);

        }
        //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- End- Alex
        //US50216: Display error card for bad status bank customer in Portal page
        bank_data_error_image = (ImageView) bank_error_card_image_view.findViewById(R.id.bank_data_error_image);
        bandBadcustomerErrorMsgTitlePortrait = (TextView) bank_error_card_image_view.findViewById(R.id.bank_data_error_message_title);
        bankDataBadCustomerErrorStatusMsgPortrait = (TextView) bank_error_card_image_view.findViewById(R.id.bank_data_error_message);
        initUI(view);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
        if(context instanceof CmnDraggableListActionListener) {
            mCmnDraggableListActionListener = (CmnDraggableListActionListener) context;
        }
    }

    @SuppressWarnings("unchecked")
    private void initUI(View view) {
        bank_data_error_layout = (RelativeLayout) view.findViewById(R.id.bank_data_error_layout);
        //US50216: Display error card for bad status bank customer in Portal page
//		bankDataErrorImageLandscape = (ImageView) view.findViewById(R.id.bank_data_error_image);
//		bankDataBadCustomerErrorStatusMsgLandscape = (TextView) view.findViewById(R.id.bank_data_error_message);
//		bandBadcustomerErrorMsgTitleLandscape = (TextView) view.findViewById(R.id.bank_data_error_message_title);
        //US50216: End


        portalListV1 = (CmnDraggableListView) view
                .findViewById(R.id.portal_account_listview1);
        portalListV2 = (CmnDraggableListView) view
                .findViewById(R.id.portal_account_listview2);

        portalListV1.setOnItemClickListener(this);
        portalListV2.setOnItemClickListener(this);

        portalListV1.setFocusable(true);
        portalListV2.setFocusable(true);

        if(this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            portalListV1.enableDragAndDrop();
            portalListV2.enableDragAndDrop();
            portalListV1.setListener(this);
        }else {
            portalListV1.disableDragAndDrop();
            portalListV2.disableDragAndDrop();
        }

        portalListBundle = getArguments();

        if (null != portalListBundle) {
            if (null != portalListBundle
                    .getSerializable(PORTAL_ACCOUNT_LIST_SORTED_KEY))
                mSortedPortalAccounList = (ArrayList<PortalBoxInterface>) portalListBundle
                        .getSerializable(PORTAL_ACCOUNT_LIST_SORTED_KEY);
            final List<PortalBoxInterface> sortedList = this.mPortalPagePresenter.getSortedPortalList(this.getPortalAccountsInMap());
            if(sortedList != null)
                mSortedPortalAccounList = sortedList;

            if(portalListBundle.getBoolean(PORTAL_ACCOUNT_CLOSED_KEY))
            {
                closedAccount=true;
            }

            if (null != mSortedPortalAccounList) {
                PortalUtils.fireSiteTagsWithListOfAccounts(mSortedPortalAccounList);
                showPortalList(mSortedPortalAccounList);
                if(this.shouldDisableDragAndDrop())
                    portalListV1.disableDragAndDrop();

            } else {
                // show empty list
            }
        }
        ficoContainer = (LinearLayout) view.findViewById(R.id.fico_container);
        ficoTitleText = (CmnTextView) view.findViewById(R.id.fico_title);
        if(FicoUtils.showOldOrNewFico()!=FicoUtils.SHOWNOFICO) {
            showFicoAtTop();
        }
        else{
            ficoContainer.setVisibility(View.GONE);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        /**start Added for defect#11560 */
        savePortalCustomOrder();
        /**end Added for defect#11560 */
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        populateViewForOrientation(inflater, (ViewGroup) getView());

        if(this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            portalListV1.enableDragAndDrop();
            portalListV2.enableDragAndDrop();
            portalListV1.setListener(this);
        }else {
            portalListV1.disableDragAndDrop();
            portalListV2.disableDragAndDrop();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        /**start Added for defect#11560 */
        savePortalCustomOrder();
        /**end Added for defect#11560 */
    }

    /**
     * Method to save portal custom order 1. On orientation change 2. On fragment destroy 3. On
     * portal page logout click
     * Added for defect#11560
     */
    public void savePortalCustomOrder() {
        if (isPortalListOrderChanged) {
            this.mPortalPagePresenter.saveUpdatedPortalListOrder(this.mSortedPortalAccounList);
            isPortalListOrderChanged = false;
        }
    }


    private void populateViewForOrientation(LayoutInflater inflater, ViewGroup viewGroup) {
        viewGroup.removeAllViewsInLayout();
        view = inflater.inflate(R.layout.portal_page_list_fragment, viewGroup);
        initUI(view);
    }

    private void showPortalList(List<PortalBoxInterface> portalAccounList) {
        /*
            Sets the animation on list1 and list2
         */
        animateView(portalListV2,PortalListAnimationListener.DELAY_DURATION);
        animateView(portalListV1,PortalListAnimationListener.DELAY_DURATION);

        AccountV2Details accountV2Details = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
        String listname;
        if(closedAccount){
            listname= getResources().getString(R.string.bank_data_bad_customer_closed_status);

            FacadeFactory.getPortalPageBankFacade().trackPageTagsWithProperties(AnalyticsPage.PORTAL_CLOSED_ACCOUNTS_PG, "","", "event73",  true);
        }else {
            listname= "list1";
        }
        //Removed conditions and moved to PortalAccountBox.java file.
        //We have changed, to display card error box in between Bank boxes.
        if (CommonUtils.isRunningOnHandset(this.mContext)) {
            portalListV2.setVisibility(View.GONE);
            portalListV1.setVisibility(View.VISIBLE);
            portalListV1.addFooterView(footerLayout);
            PortalPageListAdapter portalPageListAdapter = new PortalPageListAdapter(portalAccounList, listname, this, this);
            portalListV1.setAdapter(portalPageListAdapter);

            //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- Start- Alex

            terms.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    ((PortalPageActivity) getActivity()).navigateToPrivacyTerms();

                }
            });
            feedback.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    ((PortalPageActivity) getActivity()).navigateToFeedback();

                }
            });
            //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- end- Alex
            portalListV1.setCacheColorHint(Color.TRANSPARENT);
            portalListV2.setCacheColorHint(Color.TRANSPARENT);
        } else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {

            portalListV2.setVisibility(View.VISIBLE);
            portalListV1.setVisibility(View.VISIBLE);

            /**start fixes for defect# 10366*/
            portalListV1.setAdapter(new PortalPageListAdapter(PortalUtils.getOddEvenSortedList(portalAccounList, 0), listname, this, this));
            portalListV2.setAdapter(new PortalPageListAdapter(PortalUtils.getOddEvenSortedList(portalAccounList, 1), listname, this, this));
            /**start fixes for defect# 10366*/

            setListViewHeightBasedOnChildren(portalListV1);
            setListViewHeightBasedOnChildren(portalListV2);
            portalListV1.setCacheColorHint(Color.TRANSPARENT);
            portalListV2.setCacheColorHint(Color.TRANSPARENT);

            //US50216: Display error card for bad status bank customer in Portal page
            if (accountV2Details.isErrorRetrievingBankData() ||
                    ((!accountV2Details.isErrorRetrievingBankData()) && (accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSINVALID) || accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSERROR)))) {

                if (((ScrollView) view.findViewById(R.id.scrollviewPortal)) != null) {
                    ((ScrollView) view.findViewById(R.id.scrollviewPortal)).scrollTo(bank_data_error_layout.getTop(), bank_data_error_layout.getTop());
                }
            }
            //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- Start- Alex
            termsLand = (TextView) view.findViewById(R.id.privacy_terms_portal_land);
            feedbackLand = (TextView) view.findViewById(R.id.provide_feedback_button_portal_land);
            if(termsLand!=null)
                termsLand.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        ((PortalPageActivity) getActivity()).navigateToPrivacyTerms();

                    }
                });
            if(feedbackLand!=null)
                feedbackLand.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        ((PortalPageActivity) getActivity()).navigateToFeedback();

                    }
                });

            //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- End- Alex

        } else {
            portalListV2.setVisibility(View.GONE);
            portalListV1.setVisibility(View.VISIBLE);
            //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- Start- Alex
            portalListV1.addFooterView(footerLayout);
            PortalPageListAdapter portalPageListAdapter = new PortalPageListAdapter(portalAccounList, listname, this, this);
            portalListV1.setAdapter(portalPageListAdapter);


            terms = (TextView) footerLayout.findViewById(R.id.privacy_terms_portal);
            feedback = (TextView) footerLayout.findViewById(R.id.provide_feedback_button_portal);
            terms.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    if(motionEvent.getAction()==MotionEvent.ACTION_UP) {
                        ((PortalPageActivity) getActivity()).navigateToPrivacyTerms();
                    }
                    return true;
                }
            });
            feedback.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    if(motionEvent.getAction()==MotionEvent.ACTION_UP) {
                        ((PortalPageActivity) getActivity()).navigateToFeedback();
                    }
                    return true;
                }
            });
            //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions- end- Alex
            portalListV1.setCacheColorHint(Color.TRANSPARENT);
            portalListV2.setCacheColorHint(Color.TRANSPARENT);
            // nkaza : us28647 - end
        }
    }

    private ArrayList<PortalBoxInterface> getOddSequence(ArrayList<PortalBoxInterface> portalAccounList) {
        ArrayList<PortalBoxInterface> oddportalAccounList = new ArrayList<PortalBoxInterface>();
        for (int i = 1; i < portalAccounList.size(); i += 2) {

            oddportalAccounList.add(portalAccounList.get(i));

        }
        return oddportalAccounList;
    }

    private ArrayList<PortalBoxInterface> getEvenSequence(ArrayList<PortalBoxInterface> portalAccounList) {
        ArrayList<PortalBoxInterface> evenportalAccounList = new ArrayList<PortalBoxInterface>();
        for (int i = 0; i < portalAccounList.size(); i += 2) {
            evenportalAccounList.add(portalAccounList.get(i));
        }
        return evenportalAccounList;
    }

    //US50216 : Display error card for bad status bank customer in Portal page
    private void badStatusCustomer() {

        AccountV2Details accountV2Details = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
        if (accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSINVALID) || (accountV2Details.getBankSummaryStatus().equalsIgnoreCase(BANKSUMMARYSTATUSERROR))) {
            portalListV1.addHeaderView(bank_error_card_image_view);
            bank_data_error_image.setVisibility(View.GONE);
            bandBadcustomerErrorMsgTitlePortrait.setVisibility(View.VISIBLE);
            String errorString = getResources().getString(R.string.portal_page_bank_data_bad_customer_text);
            SpannableString errorSpannableString = new SpannableString(errorString);
            if (Utils.isRunningOnHandset(mContext)) {
                final String phoneNumber = errorString.substring(errorString.length() - 14, errorString.length());
                ClickableSpan clickableTextSpan = new ClickableSpan() {
                    @Override
                    public void onClick(View textView) {
                        CommonUtils.dialNumber(phoneNumber, mContext);
                    }
                };
                errorSpannableString.setSpan(clickableTextSpan, (errorSpannableString.length() - 14), errorSpannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                bankDataBadCustomerErrorStatusMsgPortrait.setMovementMethod(LinkMovementMethod.getInstance());
            }
            bankDataBadCustomerErrorStatusMsgPortrait.setText(errorSpannableString);

        }
    }
    //US50216 : End

    //update for US70118 - START
    private void showFicoAtTop() {
        final AccountV2Details accountV2Details = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
        //#US82770
        // #1194
        if (accountV2Details != null && accountV2Details.getCardAccountsMap().size() == 1 /*&& (accountV2Details.getDepositAccountsMap().size() > 0 || accountV2Details.getLoanAccountsMap().size() > 0 || accountV2Details.getIraPlansMap().size() > 0)*/) {
            ficoContainer.setVisibility(View.VISIBLE);
            if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOWOLDFICO) {
                ficoTitleText.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.fico_portal_title)));
            } else if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOW_FICO_SCORECARD) {
                ficoTitleText.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.credit_scorecard_actionbar_title)));
            }
            ficoContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    trackFicoAnalytics();
                    if (!accountV2Details.getCardAccountsMap().isEmpty()) {
                        String cardKey = (String) accountV2Details.getCardAccountsMap().keySet().toArray()[0];
                        animateView(PortalListAnimationListener.DELAY_DURATION);
                        if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOWOLDFICO) {
                            FacadeFactory.getPortalPageFacade().navToFicoCreditScore(mContext, cardKey);
                        } else if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOW_FICO_SCORECARD) {
                            Intent ficoStartIntent = new Intent(mContext, CmnFicoCreditScoreActivity.class);
                            startActivity(ficoStartIntent);
                        }

                    }
                }
            });
            Animation rotateAnim = AnimationUtils.loadAnimation(this.mContext, R.anim.slide_from_left);
            final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim);
            ficoContainer.setLayoutAnimation(animController);
        } else if (accountV2Details != null && accountV2Details.getCardAccountsMap().size() > 1) {
            if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOW_FICO_SCORECARD) {
                ficoContainer.setVisibility(View.VISIBLE);
                ficoTitleText.setText(CommonUtils.getHtmlFormattedText(getResources().getString(R.string.credit_scorecard_actionbar_title)));
                ficoContainer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        trackFicoAnalytics();

                        Intent ficoStartIntent = new Intent(mContext, CmnFicoCreditScoreActivity.class);
                        startActivity(ficoStartIntent);
                    }
                });
                Animation rotateAnim = AnimationUtils.loadAnimation(this.mContext, R.anim.slide_from_left);
                final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim);
                ficoContainer.setLayoutAnimation(animController);
            }
        }
    }




    //update for US70118 - END



    // Modal is added to fix the modal delay issue on portal page
    @Override
    public void displayProgressModal() {
        if (!DiscoverModalManager.hasActiveModal()) {
            DiscoverModalManager.setActiveModal(ProgressDialog.show(
                    DiscoverActivityManager.getActiveActivity(), "Discover",
                    "Loading...", true));
            DiscoverModalManager.setProgressDialogCancelable(false);
            DiscoverModalManager.getActiveModal().setCanceledOnTouchOutside(
                    false);
            DiscoverModalManager.getActiveModal().setOnCancelListener(
                    new DialogInterface.OnCancelListener() {

                        @Override
                        public void onCancel(final DialogInterface dialog) {

                        }
                    });
            DiscoverModalManager.setAlertShowing(true);
        } else {
            if (Log.isLoggable(TAG, Log.WARN)) {
                Log.w(TAG,
                        "Activity does not have a dialog associated with it!");
            }
        }
    }

    @Override
    public void navigateToCardAccount(PortalListItemClickInterface.PortalPageClickType portalPageClickType, String edsKey) {
        switch (portalPageClickType) {
            case CARD_ACCOUNT_SELECTED:
                FacadeFactory.getPortalPageFacade().navToCardHome(this.mContext, edsKey);
                break;
            case CARD_FICO_CREDIT_SCORE_LINK:
                FacadeFactory.getPortalPageFacade().navToFicoCreditScore(this.mContext, edsKey);
                break;
            case CARD_MAKE_A_PAYMENT_LINK:
                FacadeFactory.getPortalPageFacade().navToMakeAPayment(this.mContext, edsKey);
                break;

            default:
                break;
        }
    }

    @Override
    public void navigateToBankAccount(PortalListItemClickInterface.PortalPageClickType portalPageClickType, int accountIndexKey, PortalAccountType portalAccountType) {
        if(closedAccount){
            FacadeFactory.getPortalPageBankFacade().trackLinkTagWithProperties(AnalyticsPage.PORTAL_CLOSED_ACCT_STMT_TAX_DOC_LNK,
                    "","",AnalyticsPage.PORTAL_CLOSED_ACCT_STMT_TAX_DOC_LNK, true, "");
            FacadeFactory.getPortalPageBankFacade().navToStatements(this.mContext, "" + accountIndexKey);
        }else {
            switch (portalPageClickType) {

                case BANK_ACCOUNT_SELECTED:
                    FacadeFactory.getPortalPageBankFacade().navToViewActivity(this.mContext, "" + accountIndexKey, portalAccountType);
                    break;

                case BANK_MAKE_A_PAYMENT_LINK:
                    // FacadeFactory.getPortalPageBankFacade().navToMakeAPayment(mcontext,
                    // ""+accountIndexKey);
                    break;

                case BANK_DEPOSIT_A_CHECK_LINK:
                    FacadeFactory.getPortalPageBankFacade().navToDepositCheck(this.mContext, "" + accountIndexKey);
                    break;

                case BANK_PAY_BILLS_LINK:
                    FacadeFactory.getPortalPageBankFacade().navToPayBills(this.mContext, "" + accountIndexKey);
                    break;

                case BANK_TRANSFER_LINK:
                /* US113743-Android: Portal Enhancements: Quick Links: Transfer Money Analytics -
                   Passing account type so that analytics logic can be handled at Bank side code */
                    FacadeFactory.getPortalPageBankFacade().navToTransferMoney(this.mContext, "" + accountIndexKey, portalAccountType);
                    break;

                case BANK_VIEW_ACTIVITY_LINK:
                    FacadeFactory.getPortalPageBankFacade().navToViewActivity(this.mContext, "" + accountIndexKey, portalAccountType);
                    break;

                case BANK_PAY_LOANS_LINK:
                    FacadeFactory.getPortalPageBankFacade().navToPayLoans(this.mContext, "" + accountIndexKey);
                    break;

                default:
                    break;

            }
        }
    }

    @Override
    public void onClickRightDeepLinkOfPortalBox(PortalBoxInterface dataItem, PortalAccountType accountType, String rightDeepLinkString) {

        PortalUtils.isDeeplinkClicked = true;
        //Called to Animate whole list when user clicks the portal element
        //Added if condition for fix for defect# 11873
        if (PortalUtils.isAllowPortalAnimation(dataItem)) {
            animateView(PortalListAnimationListener.DELAY_DURATION);
        }

        if (!TextUtils.isEmpty(rightDeepLinkString) && rightDeepLinkString.equalsIgnoreCase(this.mContext.getResources().getString(R.string.portal_box_account_verify_link))) {
            if (null != dataItem && dataItem instanceof CardAccount) {
                String deepLinkCode = PortalConstants.Misc.LINKTO_PORTAL_CARD_MERGE + ((CardAccount) dataItem).getAcctKey();
                FacadeFactory.getCardFacade().invokeBBRedirect(this.mContext, deepLinkCode);
            } else {
                FacadeFactory.getCardFacade().invokeBBRedirect(this.mContext, PortalConstants.Misc.LINKTO_PORTAL_BANK_MERGE);
            }
        } else {
            if (null != dataItem && dataItem instanceof CardAccount) {
                String externalStatus = ((CardAccount) dataItem).getExternalStatus();
                if (PortalUtils.isStrFieldEmpty(externalStatus)) {
                    this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, false);
                } else if (externalStatus.equalsIgnoreCase("Z") || externalStatus.equalsIgnoreCase("B") || externalStatus.equalsIgnoreCase("U") || externalStatus.equalsIgnoreCase("L")) {
                    boolean isANRKillSwitchDisabled = FacadeFactory.getCardFacade().isKillSwitchDisabled(mContext.getString(R.string.anr_kill_switch));
                    this.mPortalPagePresenter.handleBadStatusAccounts(dataItem, new PasscodeUtils(this.mContext), accountType,isANRKillSwitchDisabled);
                } else if (externalStatus.equalsIgnoreCase("A")) {
                    this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, false);
                } else {

                    this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, false);
                }
            } else {
                this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, false);
            }
        }
    }

    @Override
    public void onClickLeftDeepLinkOfPortalBox(PortalBoxInterface dataItem, PortalAccountType accountType) {


        PortalUtils.isDeeplinkClicked = true;
        //Called to Animate whole list when user clicks the portal element
        //Added if condition for fix for defect# 11873
        if (PortalUtils.isAllowPortalAnimation(dataItem)) {
            animateView(PortalListAnimationListener.DELAY_DURATION);
        }

        if (null != dataItem && dataItem instanceof CardAccount) {
            String externalStatus = ((CardAccount) dataItem).getExternalStatus();

            if (PortalUtils.isStrFieldEmpty(externalStatus)) {
                this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, true);
            } else if (externalStatus.equalsIgnoreCase("Z") || externalStatus.equalsIgnoreCase("B") || externalStatus.equalsIgnoreCase("U") || externalStatus.equalsIgnoreCase("L")) {
                boolean isANRKillSwitchDisabled = FacadeFactory.getCardFacade().isKillSwitchDisabled(mContext.getString(R.string.anr_kill_switch));
                this.mPortalPagePresenter.handleBadStatusAccounts(dataItem, new PasscodeUtils(this.mContext), accountType, isANRKillSwitchDisabled);
            } else if (externalStatus.equalsIgnoreCase("A")) {
                this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, false);
            } else {

                this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, true);
            }
        } else {
            this.mPortalPagePresenter.handleDeeplink(dataItem, accountType, true);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

        final PortalBoxInterface dataItem = (PortalBoxInterface) adapterView.getAdapter().getItem(position);
        final PortalAccountType accountType = getAccountType(dataItem);
        final PasscodeUtils passcodeUtils = new PasscodeUtils(this.mContext);
        this.trackPortalBoxClickAnalytics(accountType);

        PortalUtils.isDeeplinkClicked = true;

        //Called to Animate whole list when user clicks the portal element



        final String rightDeepLinkString = getRightDeepLink(view);
        if ((!TextUtils.isEmpty(rightDeepLinkString) && rightDeepLinkString.equalsIgnoreCase(this.getResources().getString(R.string.portal_box_account_verify_link))) || (dataItem.getSortId().equalsIgnoreCase(PortalConstants.CARD_ERROR_BOX_ID)) || dataItem.getSortId().equalsIgnoreCase(PortalConstants.BANK_ERROR_BOX_ID)) {
            // do nothing
        } else {
            if (null != dataItem && dataItem instanceof CardAccount) {
               boolean isANRKillSwitchDisabled = FacadeFactory.getCardFacade().isKillSwitchDisabled(mContext.getString(R.string.anr_kill_switch));
                this.mPortalPagePresenter.handleBadStatusAccounts(dataItem, passcodeUtils, accountType,isANRKillSwitchDisabled);
            } else {
                this.mPortalPagePresenter.handlePortalItemClick(dataItem, accountType);
            }
        }
    }

    @Override
    public PortalAccountType getAccountType(PortalBoxInterface dataItem) {
        PortalAccountType accountType = null;

        if (null != dataItem) {
            if (dataItem instanceof DepositAccount) {
                DepositAccount depositAccount = (DepositAccount) dataItem;
                if (!PortalUtils.isStrFieldEmpty(depositAccount.getAcctType())) {
                    if (depositAccount.getAcctType().equalsIgnoreCase("001")) {
                        accountType = PortalAccountType.ACCOUNT_SAVINGS;
                    } else if (depositAccount.getAcctType().equalsIgnoreCase("002")) {
                        accountType = PortalAccountType.ACCOUNT_CHECKING;
                    } else if (depositAccount.getAcctType().equalsIgnoreCase("003")) {
                        accountType = PortalAccountType.ACCOUNT_MONEY_MARKET;
                    } else if (depositAccount.getAcctType().equalsIgnoreCase("004")) {
                        accountType = PortalAccountType.ACCOUNT_CD;
                    }
                }
            } else if (dataItem instanceof CardAccount) {
                accountType = PortalAccountType.ACCOUNT_CREDIT_CARD;
            } else if (dataItem instanceof IraPlan) {
                accountType = PortalAccountType.ACCOUNT_IRA;
            } else if (dataItem instanceof LoanAccount) {
                accountType = PortalAccountType.ACCOUNT_LOAN;
            } else if (dataItem instanceof CardErrorAccount) {
                accountType = PortalAccountType.ACCOUNT_CREDIT_CARD_ERROR;
            } else if (dataItem instanceof BankErrorAccount) {
                accountType = PortalAccountType.ACCOUNT_BANK_ERROR;
            } else if (dataItem instanceof BankVerifyAccount) {
                accountType = PortalAccountType.ACCOUNT_BANK_VERIFY;
            }
        }

        return accountType;
    }

    /**
     * changes by asaraf2 for US47001
     * Here getting the messages from the Api in the form of title and content for ZULB error
     * messages
     */
    @Override
    public void displayZULBErrorModalFromApi(String title, String contentDescription) {
        EnhancedContentModal zulbEnhancedContentModal = new EnhancedContentModal(this.mContext, title, contentDescription, R.string.close_text);
        if (null != title && !title.isEmpty() && null != contentDescription && !contentDescription.isEmpty()) {
            //Replacing the \n with the <br/>
            if (contentDescription.contains("\n")) {
                contentDescription = contentDescription.replace("\n", "<br/>");
            }
            zulbEnhancedContentModal.setTitle(title);
            zulbEnhancedContentModal.setContentHtml(contentDescription, true);

        }

        zulbEnhancedContentModal.hideNeedHelpFooter();
        showAlertNavToLogin(zulbEnhancedContentModal);
    }
    //end changes by asaraf2

    public void showAlertNavToLogin(AlertDialog modal) {
        showCustomAlert(modal);
    }

    /**
     * Show a custom modal alert dialog for the activity
     *
     * @param alert - the modal alert to be shown
     */
    public void showCustomAlert(final AlertDialog alert) {
        alert.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alert.show();
        alert.getWindow().setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT);
    }

    @Override
    public void trackFicoAnalytics() {

        HashMap<String, Object> extras = new HashMap<>();
        extras.put(this.mContext.getResources().getString(R.string.prop1), AnalyticsPage.PORTAL_SSO_FICO_CREDIT_SCORE_LNK);
        extras.put(this.mContext.getResources().getString(R.string.evar35), AnalyticsPage.PORTAL_SSO_FICO_CREDIT_SCORE_LNK);

        TrackingHelper.trackClickEvents(AnalyticsPage.PORTAL_SSO_FICO_CREDIT_SCORE_LNK, null, AnalyticsPage.PORTAL_LNK_O_PE, extras);
    }

    @Override
    public boolean isInDraggingState() {
        return this.isInDraggingState;
    }

    @Override
    public int getDraggingItemPosition() {
        return this.mDraggingItemPosition;
    }


    private void trackPortalBoxClickAnalytics(PortalAccountType accountType){

        final String tag = PortalUtils.getMatchingTag(accountType);
        if(tag != null) {
            final String accType = AnalyticsPage.PORTAL_ACCT_.concat(tag);
            final HashMap<String, Object> extras = new HashMap<>();
            extras.put(this.mContext.getResources().getString(R.string.prop1), accType);
            extras.put(this.mContext.getResources().getString(R.string.evar35), accType);

            TrackingHelper.trackClickEvents(accType, null, AnalyticsPage.PORTAL_LNK_O_PE, extras);
        }
    }

    private void trackListDragAndDropEventAnalytics(PortalAccountType accountType){

        final String tag = PortalUtils.getMatchingTag(accountType);
        if(tag != null) {
            final String accType = AnalyticsPage.PORTAL_ACCT_DRAG_DROP_.concat(tag);
            final HashMap<String, Object> extras = new HashMap<>();
            extras.put(this.mContext.getResources().getString(R.string.prop1), accType);
            extras.put(this.mContext.getResources().getString(R.string.evar35), accType);

            TrackingHelper.trackClickEvents(accType, null, AnalyticsPage.PORTAL_LNK_O_PE, extras);
        }
    }

    @Override
    public void notifyDraggingStart(Object draggedItem) {

        if(draggedItem instanceof PortalBoxInterface) {
            final PortalBoxInterface dataItem = (PortalBoxInterface) draggedItem;
            final PortalAccountType accountType = getAccountType(dataItem);
            this.trackListDragAndDropEventAnalytics(accountType);
        }
    }

    @Override
    public void notifyAdapterChange(List newData) {
        isPortalListOrderChanged = true;
    }


    private void animateView(final ViewGroup view, float delay){
        /*
         Animate the list from left to right
         */
        Animation rotateAnim = AnimationUtils.loadAnimation(mContext, R.anim.slide_from_left);
        rotateAnim.setStartOffset(PortalListAnimationListener.ANIMATE_DURATION);
        final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim, delay);
        view.setLayoutAnimation(animController);
        rotateAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                //clearAnimation() removes the animation from list view
                view.clearAnimation();

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    @Override
    public void animateView(float delay) {

        /*
          Animate the Greeting layout of Portal page
         */
        if(mContext instanceof PortalListAnimationListener){
            ((PortalListAnimationListener)mContext).animateView(0);
        }

        if(ficoContainer.getVisibility() == View.VISIBLE){
             /*
                Animate the list from right to left
             */
            Animation rotateAnim = AnimationUtils.loadAnimation(mContext, R.anim.slide_from_right);
            final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim);
            rotateAnim.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    animation.setFillAfter(false);
                    ficoContainer.setVisibility(View.INVISIBLE);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {
                }
            });
            ficoContainer.setLayoutAnimation(animController);
            ficoContainer.startLayoutAnimation();
        }
        /*
        Animate first Portal List
         */
        if (portalListV1.getVisibility() == View.VISIBLE) {
            /*
                Animate the list from right to left
             */
            Animation rotateAnim = AnimationUtils.loadAnimation(mContext, R.anim.slide_from_right);
            rotateAnim.setStartOffset(PortalListAnimationListener.ANIMATE_DURATION);
            final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim, delay);
            rotateAnim.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    /*
                        If Animation is completed for all child then set the visibility as INVISIBLE
                     */
                    if(animController.isDone()){
                        animation.setFillAfter(false);
                        portalListV1.clearAnimation();
                        portalListV1.setVisibility(View.INVISIBLE);
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });

            portalListV1.setLayoutAnimation(animController);
            //Below line start the animation for list view
            portalListV1.startLayoutAnimation();

        }
         /*
        Animate second Portal List
         */
        if (portalListV2.getVisibility() == View.VISIBLE) {

            /*
                Animate the list from right to left
             */
            Animation rotateAnim = AnimationUtils.loadAnimation(mContext, R.anim.slide_from_right);
            rotateAnim.setStartOffset(PortalListAnimationListener.ANIMATE_DURATION);
            final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim, delay);
            rotateAnim.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                     /*
                        If Animation is completed for all child then set the visibility as INVISIBLE
                     */
                    if(animController.isDone()){
                        animation.setFillAfter(false);
                        portalListV2.clearAnimation();
                        portalListV2.setVisibility(View.INVISIBLE);
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });

            portalListV2.setLayoutAnimation(animController);
            //Below line start the animation for list view
            portalListV2.startLayoutAnimation();
        }
    }

    private String getRightDeepLink(View convertView) {
        String rightDeepLinkString = "";
        if (null != convertView && null != ((PortalAccountBox) convertView).getRightDeepLink()) {
            rightDeepLinkString = ((PortalAccountBox) convertView).getRightDeepLink().getText().toString();
        }
        return rightDeepLinkString;
    }

    @Override
    public void onStartDragging(int pos) {
        this.isPortalListOrderChanged = true;
        this.isInDraggingState = true;
        this.mDraggingItemPosition = pos;
        final int count = portalListV1.getChildCount();
        for(int i = 0; i < count ; i++){
            if(i != pos)
                portalListV1.getChildAt(i).setAlpha(0.8f);
        }
    }

    @Override
    public void onStopDragging() {
        this.isInDraggingState = false;
        final int count = portalListV1.getChildCount();
        for(int i = 0; i < count ; i++){
            portalListV1.getChildAt(i).setAlpha(1.0f);
        }

    }

    @Override
    public boolean shouldDisableDragAndDrop() {
        return this.mCmnDraggableListActionListener.shouldDisableDragAndDrop();
    }

    private Map<String, PortalBoxInterface> getPortalAccountsInMap(){

        final Map<String, PortalBoxInterface> portalAccountMap = new LinkedHashMap<>();
        for (PortalBoxInterface portalAccount : this.mSortedPortalAccounList) {
            portalAccountMap.put(portalAccount.getSortId(), portalAccount);
        }
        return portalAccountMap;
    }

}
