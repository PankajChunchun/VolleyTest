package com.discover.mobile.common.onboardwiz.fragment;

import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by 482127 on 4/25/2016.
 */
public class OnBoardPagerAdapter extends FragmentPagerAdapter {

    public OnBoardPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        /**start US83286  - Android Fingerprint - Kill-switch */
        Activity currentActivity = DiscoverActivityManager.getActiveActivity();
        boolean isFingerprintOnboardItemToShow = OnBoardHelper.isFPOnboardItemToShow(currentActivity);
        return OnBoardHelper.getVehicles(isFingerprintOnboardItemToShow).get(i);
        /**end US83286  - Android Fingerprint - Kill-switch */
    }

/*    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        Fragment fragment = (Fragment) super.instantiateItem(container, position);
        registeredFragments.put(position, fragment);
        return fragment;
    }

    */

    /**
     * Remove the saved reference from our Map on the Fragment destroy
     *//*
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        registeredFragments.remove(position);
        super.destroyItem(container, position, object);
    }*/
    @Override
    public int getCount() {
        /**start US83286  - Android Fingerprint - Kill-switch */
        Activity currentActivity = DiscoverActivityManager.getActiveActivity();
        boolean isFingerprintOnboardItemToShow = OnBoardHelper.isFPOnboardItemToShow(currentActivity);
        return OnBoardHelper.getVehicles(isFingerprintOnboardItemToShow).size();
        /**end US83286  - Android Fingerprint - Kill-switch */
    }

   /* public Fragment getRegisteredFragment(int position) {
        return registeredFragments.get(position);
    }
*/
}
