package com.discover.mobile.common.onboardwiz.fragment.paperless;

import com.discover.mobile.common.R;
import com.discover.mobile.common.shared.utils.StringUtility;
import com.discover.mobile.common.uiwidget.CmnSwitch;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * This class is a custom layout that represents a single row containing
 * account name, account ending number and toggle switch.
 * This is to be inflated inside the paperless landing page for each account
 **/
public class OnBoardingPaperlessAccountRow extends LinearLayout {

    /** Holds the reference for the switch view **/
    private CmnSwitch mEnableToggle;
    /** Holds the reference account name view **/
    private TextView mAccountName;
    /** Holds the reference account number view **/
    private TextView mAccountNumber;

    /**
     * This constructor inflates the UI of each row and initializes the required views
     **/
    public OnBoardingPaperlessAccountRow(Context context) {
        super(context);
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.onboarding_paperless_account_row,
                OnBoardingPaperlessAccountRow.this, true);
        mEnableToggle = (CmnSwitch) view.findViewById(R.id.enable_switch);
        mAccountName = (TextView) view.findViewById(R.id.account_name);
        mAccountNumber = (TextView) view.findViewById(R.id.account_number);
        ViewTreeObserver vto = mAccountName.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                dynamicWrapping();
            }
        });
    }

    /**
     * Below method is to wrap the account account name if it is too long. Call this once the row
     * view is added to the UI.
     **/
    public void dynamicWrapping() {
        Rect accNumberRect = new Rect();
        RelativeLayout accountLayout = (RelativeLayout) mAccountNumber.getParent();
        accountLayout.getHitRect(accNumberRect);
        if (!(mAccountName.getText().toString().equals(mAccountName.getLayout().getText().toString()) && mAccountNumber.getText().toString().equals(mAccountNumber.getLayout().getText().toString())/*&&mAccountNumber.getLocalVisibleRect(accNumberRect)*/)) {

            RelativeLayout.LayoutParams params;
            params = (RelativeLayout.LayoutParams) mAccountName.getLayoutParams();
            params.addRule(RelativeLayout.LEFT_OF, mAccountNumber.getId());
            mAccountName.setLayoutParams(params);
            RelativeLayout.LayoutParams params1;
            params1 = (RelativeLayout.LayoutParams) mAccountNumber.getLayoutParams();
            params1.addRule(RelativeLayout.RIGHT_OF, 0);
            mAccountNumber.setLayoutParams(params1);

        }

    }


    /**
     * Getter method to get the reference of the switchToggle button
     **/
    public CmnSwitch getEnableToggle() {
        return mEnableToggle;
    }

    /**
     * Function to display a line item on onboarding paperless screen
     *
     * @param nickname  - customer nick name
     * @param paperless - paperless state
     */
    public void setAccountsAndToggle(String nickname, String accountNumber, Boolean paperless) {
        //set account name to the textview
        mAccountName.setText(nickname);
        //set account number to the textview
        mAccountNumber.setText(StringUtility.SPACE + accountNumber);
        //condition check to the paperless enable/disable state
        if (paperless) {
            //paperless enabled
            mEnableToggle.setChecked(true);
        } else {
            //paperless disabled
            mEnableToggle.setChecked(false);
        }

    }
}
