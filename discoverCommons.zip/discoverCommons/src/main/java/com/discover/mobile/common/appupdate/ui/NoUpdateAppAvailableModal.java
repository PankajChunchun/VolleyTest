package com.discover.mobile.common.appupdate.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.highlightedfeatures.ui.HighlightedFeaturesLandingFragment;
import com.discover.mobile.common.highlightedfeatures.utils.HFConstants;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.nav.DrawerBaseActivity;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

/**
 * A {@link com.discover.mobile.common.ui.modals.EnhancedContentModal} class which is used to show
 * noupdate
 * available.
 *
 * @author amahaja
 */
public class NoUpdateAppAvailableModal extends DialogFragment {

    /** View of the modal */
    private View view;
    private Context mContext;
    private Button closeBtn;
    private TextView noUpdateAvailableText;
    private boolean isCancelable = false;
    private String hdeepLinkHighlightedFeatureActionCode = "linkToHighlightesFeatures";
    private boolean isCard;

    public NoUpdateAppAvailableModal() {
    }
//        super(context);
//        view = getLayoutInflater().inflate(
//                R.layout.app_update_not_available_layout, null);
//        mContext = context;
//        closeBtn = (Button) view.findViewById(R.id.modal_alert_cancel);
//
//        noUpdateAvailableText = (TextView)view.findViewById(R.id.app_noupdate_modal_summary);
//
//        if (LoginActivity.isCardChecked) {
//            isCard = true;
//        } else {
//            isCard = false;
//        }
//        if(isCard){
//            noUpdateAvailableText.setVisibility(View.VISIBLE);
//        }else{
//            noUpdateAvailableText.setVisibility(View.GONE);
//        }
//
//        // Clickable highlighted feature
//        String textString = noUpdateAvailableText.getText().toString();
//        SpannableString builder = new SpannableString(textString);
//
//        ClickableSpan clickableSpan = new ClickableSpan() {
//
//            @Override
//            public void onClick(View widget) {
//                // US20350 : sshar13 :- version number analytics
//                showHighlightedFeature();
//                dismiss();
//            }
//
//            @Override
//            public void updateDrawState(TextPaint ds) {
//                ds.setUnderlineText(false);
//            }
//
//        };
//        builder.setSpan(clickableSpan, 0, 25, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
////        builder.setSpan(new ForegroundColorSpan(mContext.getResources()
////                        .getColor(R.color.card_footer_color)), 0, 25,
////                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
//
//        builder.setSpan(new ForegroundColorSpan(Color.parseColor("#267bb1")),0, 25,
//                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
//
//        noUpdateAvailableText.setText(builder);
//        noUpdateAvailableText.setMovementMethod(LinkMovementMethod
//                .getInstance());
//    }

//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        this.setContentView(view);
//        setUpButton();
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.app_update_not_available_layout,
                container);

        closeBtn = (Button) view.findViewById(R.id.modal_alert_cancel);

        noUpdateAvailableText = (TextView) view.findViewById(R.id.app_noupdate_modal_summary);

        if (LoginActivity.isCardChecked) {
            isCard = true;
        } else {
            isCard = false;
        }
        if (isCard) {
            noUpdateAvailableText.setVisibility(View.VISIBLE);
        } else {
            noUpdateAvailableText.setVisibility(View.GONE);
        }

        // Clickable highlighted feature
        String textString = noUpdateAvailableText.getText().toString();
        SpannableString builder = new SpannableString(textString);

        ClickableSpan clickableSpan = new ClickableSpan() {

            @Override
            public void onClick(View widget) {
                // US20350 : sshar13 :- version number analytics
                showHighlightedFeature();
                dismiss();
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(false);
            }

        };
        builder.setSpan(clickableSpan, 0, 25, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);


        builder.setSpan(new ForegroundColorSpan(Color.parseColor("#267bb1")), 0, 25,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        noUpdateAvailableText.setText(builder);
        noUpdateAvailableText.setMovementMethod(LinkMovementMethod
                .getInstance());

        closeBtn.setText(R.string.update_app_cancel_lable);
        closeBtn.setOnClickListener(new VersionUpdateCloseListener());
        getDialog().setCancelable(isCancelable);
        return view;
    }

//    @Override
//    public Button getButton() {
//        return closeBtn;
//    }
//
//    @Override
//    public void setButtonText(int resource) {
//        closeBtn.setText((mContext.getString(resource)));
//    }
//
//    @Override
//    public void setContent(int arg0) {
//
//    }
//
//    @Override
//    public void setContent(String arg0) {
//
//    }
//
//    @Override
//    public void setTitle(String arg0) {
//
//    }

//    private void setUpButton() {
//        closeBtn.setText((((LoginActivity)mContext).getString(R.string.update_app_cancel_lable)));
//        closeBtn.setOnClickListener(new VersionUpdateCloseListener());
//    }

    private void showHighlightedFeature() {
        final Activity currentActivity = DiscoverActivityManager.getActiveActivity();
        if (getActivity() instanceof DrawerBaseActivity) {

            // US45209 Changes starts.
            HighlightedFeaturesLandingFragment fragment = new HighlightedFeaturesLandingFragment();
            // Defect #242778
            Bundle bundle = fragment.getHFArguments(0, false, false, HFConstants.LoginType.CARD);
            fragment.setArguments(bundle);
            ((DrawerBaseActivity) currentActivity).makeFragmentVisible(fragment);
            /*FacadeFactory.getHighlightedFeaturesFacade().getPreloginHighlightedFeaturesFragment(currentActivity,null, new NetworkRequestListener() {
                @Override
                public void onSuccess(Object data) {
                    Fragment fragment = (Fragment)data;
                    ((NavigationRootActivity) currentActivity).makeFragmentVisible(fragment);
                }

                @Override
                public void onError(Object data) {
                    // TODO Show an error message here.
                }
            });*/
            // US45209 Changes end.

        } else {
//            DeeplinkHelper.executeActionCodePreLogin(mContext, hdeepLinkHighlightedFeatureActionCode);

//            FacadeFactory.getHighlightedFeaturesFacade().executeActionCodePreLoginDeeplinkHelper(mContext, hdeepLinkHighlightedFeatureActionCode);
//            FacadeFactory.getHighlightedFeaturesFacade().getPreloginHighlightedFeaturesActivity(currentActivity, null, null);
            final Intent intent = new Intent(currentActivity,
                    ShowHighlightedFeatureActivity.class);

            Bundle bundle = new Bundle();
            bundle.putInt(HFConstants.Args.PAGER_LOCATION, 0);
            bundle.putBoolean(HFConstants.Args.WHATS_NEW_FLAG, false);
            bundle.putBoolean(HFConstants.Args.PRE_LOGIN_FLAG, true);
            bundle.putSerializable(HFConstants.Args.LOGIN_TYPE, HFConstants.LoginType.CARD);
            bundle.putBoolean(ShowHighlightedFeatureActivity.GO_BACK_TO_LOGIN, true);
            intent.putExtras(bundle);
            currentActivity.startActivity(intent);

        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        return dialog;
    }


    private class VersionUpdateCloseListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            dismiss();
        }
    }
}
