package com.discover.mobile.common.fico.views;

import com.discover.mobile.common.R;
import com.discover.mobile.common.fico.bean.CmnFicoListHeaderBean;
import com.discover.mobile.common.fico.bean.CmnFicoListItemBean;
import com.discover.mobile.common.fico.interfaces.CmnFicoListItemInterface;
import com.discover.mobile.common.fico.utils.FicoUtils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import static com.discover.mobile.common.fico.utils.FicoCreditScoreConstants.FicoScoreList.VIEW_TYPE_LIST_HEADER;
import static com.discover.mobile.common.fico.utils.FicoCreditScoreConstants.FicoScoreList.VIEW_TYPE_LIST_ITEM;

/**
 * Created by slende
 * Custom view for FICO list item
 */

public class CmnCreditscoreListItemView extends LinearLayout {

    private Context mcontext;
    private CmnCreditscoreListItem viewHolder;
    private String noScoreValue = "--";

    public CmnCreditscoreListItemView(Context context) {
        super(context);
        this.mcontext = context;
        inIt();
    }

    public CmnCreditscoreListItemView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mcontext = context;
        inIt();
    }

    public CmnCreditscoreListItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mcontext = context;
        inIt();
    }

    private void inIt() {
        inflate(mcontext, R.layout.cmn_creditscore_list_item, this);
        setUpViewHolder();
    }

    /**
     * Initializes view holder
     */
    private void setUpViewHolder() {
        viewHolder = new CmnCreditscoreListItem();
        viewHolder.ficoListRootLL = (LinearLayout) findViewById(R.id.cmnFicoListRootId);
        viewHolder.cmnFicoListHeaderLL = (LinearLayout) findViewById(R.id.cmnFicoList_HeaderRoot);
        viewHolder.cmnFicoListItemLL = (LinearLayout) findViewById(R.id.cmnFicoList_ItemRoot);
        viewHolder.cmnFicoListDateLabel = (TextView) findViewById(R.id.cmnFicoList_dateLabelId);
        viewHolder.cmnFicoListScoreLabel = (TextView) findViewById(R.id.cmnFicoList_scoreLabelId);
        viewHolder.cmnFicoListRatingLabel = (TextView) findViewById(R.id.cmnFicoList_ratingLabelId);
        viewHolder.cmnFicoListDateValue = (TextView) findViewById(R.id.cmnFicoList_dateValueId);
        viewHolder.cmnFicoListScoreValue = (TextView) findViewById(R.id.cmnFicoList_scoreValueId);
        viewHolder.cmnFicoListRatingValue = (TextView) findViewById(R.id.cmnFicoList_ratingValueId);
        viewHolder.ficoListItemSep = findViewById(R.id.cmnFicoList_item_sep_Id);
    }

    /**
     * Viewholder class
     */
    public static class CmnCreditscoreListItem {
        public LinearLayout ficoListRootLL;
        public LinearLayout cmnFicoListHeaderLL;
        public LinearLayout cmnFicoListItemLL;
        public TextView cmnFicoListDateLabel;
        public TextView cmnFicoListRatingLabel;
        public TextView cmnFicoListScoreLabel;
        public TextView cmnFicoListDateValue;
        public TextView cmnFicoListScoreValue;
        public TextView cmnFicoListRatingValue;
        public View ficoListItemSep;
    }

    /**
     * Method to map data to list item
     */
    public void mapViewWithData(int listType, CmnFicoListItemInterface dataItem) {

        switch (listType) {

            case VIEW_TYPE_LIST_HEADER:
                viewHolder.cmnFicoListHeaderLL.setVisibility(View.VISIBLE);
                viewHolder.cmnFicoListItemLL.setVisibility(View.GONE);
                if (dataItem instanceof CmnFicoListHeaderBean) {
                    viewHolder.cmnFicoListDateLabel.setText(((CmnFicoListHeaderBean) dataItem).getColumn1Title());
                    viewHolder.cmnFicoListScoreLabel.setText(((CmnFicoListHeaderBean) dataItem).getColumn2Title());
                    viewHolder.cmnFicoListRatingLabel.setText(((CmnFicoListHeaderBean) dataItem).getColumn3Title());
                }
                break;

            case VIEW_TYPE_LIST_ITEM:
                viewHolder.cmnFicoListHeaderLL.setVisibility(View.GONE);
                viewHolder.cmnFicoListItemLL.setVisibility(View.VISIBLE);
                viewHolder.ficoListItemSep.setVisibility(View.VISIBLE);
                if (dataItem instanceof CmnFicoListItemBean) {
                    CmnFicoListItemBean litItemData = ((CmnFicoListItemBean) dataItem);
                    String ficoScoreDate = litItemData.getFicoScoreDate();
                    int ficoScoreInt = litItemData.getFicoScore();
                    String scoreValue = "";
                    if (null != ficoScoreDate) {
                        //Removed date format as per US124309
                        viewHolder.cmnFicoListDateValue.setText(ficoScoreDate);
                    }
                    if (litItemData.isHasScore()) {
                        scoreValue = String.valueOf(ficoScoreInt);
                        viewHolder.cmnFicoListScoreValue.setText(scoreValue);
                        viewHolder.cmnFicoListRatingValue.setText(FicoUtils.getFicoScoreRangeValue(ficoScoreInt));
                    } else {
                        viewHolder.cmnFicoListScoreValue.setText(noScoreValue);
                        viewHolder.cmnFicoListRatingValue.setText(noScoreValue);
                    }
                }
                break;

            default:
                break;
        }
    }

    public void hideDivider() {
        if (null != viewHolder.ficoListItemSep) {
            viewHolder.ficoListItemSep.setVisibility(View.GONE);
        }
    }

    public LinearLayout getListItemRoot() {
        return viewHolder.ficoListRootLL;
    }
}
