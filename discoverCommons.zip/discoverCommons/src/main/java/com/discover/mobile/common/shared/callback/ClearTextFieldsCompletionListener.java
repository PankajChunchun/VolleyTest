package com.discover.mobile.common.shared.callback;

import com.discover.mobile.common.shared.callback.GenericCallbackListener.CompletionListener;
import com.discover.mobile.common.shared.net.NetworkServiceCall;

import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Set;


class ClearTextFieldsCompletionListener implements CompletionListener {

    private final Set<WeakReference<TextView>> textViewRefs;

    ClearTextFieldsCompletionListener(final TextView[] textViews) {
        textViewRefs = new HashSet();
        for (final TextView textView : textViews) {
            textViewRefs.add(new WeakReference<TextView>(textView));
        }
    }

    @Override
    public CallbackPriority getCallbackPriority() {
        return CallbackPriority.MIDDLE;
    }

    @Override
    public void complete(final NetworkServiceCall<?> sender, final Object result) {
        for (final WeakReference<TextView> textViewRef : textViewRefs) {
            final TextView textView = textViewRef.get();
            if (textView != null) {
                textView.setText("");
            }
        }
    }

}
