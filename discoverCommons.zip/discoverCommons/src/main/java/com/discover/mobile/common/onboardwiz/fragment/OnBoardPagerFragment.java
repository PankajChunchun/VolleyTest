package com.discover.mobile.common.onboardwiz.fragment;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.fragment.fingerprint.OnBoardFingerprintFragment;
import com.discover.mobile.common.onboardwiz.fragment.paperless.OnBoardPaperlessFragment;
import com.discover.mobile.common.onboardwiz.fragment.passcode.OnBoardPasscodeContainerFragment;
import com.discover.mobile.common.onboardwiz.fragment.quickview.OnBoardEnableQuickViewFragment;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.onboardwiz.utils.RibbenMessage;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.image.FileDownloader;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.ui.widgets.CirclePageIndicator;
import com.discover.mobile.common.uiwidget.CmnButton;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

import java.util.HashMap;


/**
 * Created by 482127 on 4/25/2016.
 */
public class OnBoardPagerFragment extends Fragment implements OnBoardNavigationListener {

    // To restrict the paperless tag to fire only once
    private static boolean isPaperless = true;
    private static boolean isQuickView = true;
    public static boolean isFingerPrint= true;
    private View mView;
    private Context mContext;
    private ViewPager mViewPager;
    private OnBoardPagerAdapter mPagerAdapter;
    private CirclePageIndicator mPagerIndicator;
    private Button mPagerButton;
    private CmnButton mDoneButton;
    private int previousItem = 0;
    private CmnButton exitLink;
    //us53328
    private boolean isQuickViewEnabled = false;
    private boolean isPasscodeEnabled = false;
    public OnBoardFingerprintFragment onBoardFingerprintFragment;
    //US54329: Feature Transitions code changes end
    //US54329: Feature Transitions code changes start
    //variable helps to identify the respective Fragment loaded on pager
    private Fragment currentFragment;
    private static final String INDICATORTAG="Indicator";
    private static final String ARROWTAG="Arrow";




    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mContext = activity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = LayoutInflater.from(mContext).inflate(R.layout.onboarding_view_pager, null);
        exitLink = (CmnButton) mView.findViewById(R.id.btn_exit);
        exitLink.clearFocus();
        // mView.requestFocus();
        mViewPager = (ViewPager) mView.findViewById(R.id.view_pager_onboarding);
        mPagerIndicator = (CirclePageIndicator) mView.findViewById(R.id.indicator);
        mPagerIndicator.setTag(INDICATORTAG+"mainpage");

        Log.v("Indicator",mPagerIndicator.getTag().toString());

        mPagerIndicator.setFillColor(getResources().getColor(R.color.onboarding_selector_color));
        mPagerIndicator.setPageColor(getResources().getColor(R.color.onboarding_unselector_color));
        mPagerButton = (Button) mView.findViewById(R.id.button_arrow);
        mPagerButton.setTag(ARROWTAG+"mainPage");
        Log.v("Arrow Tag",mPagerButton.getTag().toString());

        mPagerIndicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
                mPagerIndicator.setTag(INDICATORTAG+i);
                mPagerButton.setTag(ARROWTAG+i);

            }

            @Override
            public void onPageSelected(int i) {
                mPagerIndicator.setId(i);
//                Toast.makeText(mContext,"----Rakesh----"+i,Toast.LENGTH_LONG).show();
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

        mPagerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Globals.isFromCardSide()) {
                    //US53328
                    Fragment currentFragment = mPagerAdapter.getItem(previousItem);

                    trackAnalyticsForwordButton(currentFragment);
                    //ENDS
                }
                moveToNextPage();
            }
        });
        mDoneButton = (CmnButton) mView.findViewById(R.id.doneBtn);
        mDoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start: US53564 - Onboarding Wizard: Paperless Enable Site Catalyst Tags

                if (Globals.isBankLoginSelected() && !OnBoardHelper.isBankAllaccountsEnroll()) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, DiscoverActivityManager.getActiveActivity().getResources().getString(R.string.onboard_paperless_done_link));
                    extras.put("my.eVar35", getResources().getString(R.string.onboard_paperless_done_link));
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.onboard_paperless_tag));
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                } else {
                    // End
                    //Us53328--starts
                    Fragment currentFragment = mPagerAdapter.getItem(previousItem);
                    trackDoneBtnLink(currentFragment);
                    //ends
                }

                moveToNextPage();
            }
        });
        mPagerAdapter = new OnBoardPagerAdapter(getActivity().getSupportFragmentManager());
        mViewPager.setAdapter(mPagerAdapter);
        //Set the first page fragment as default one.
        setCurrentFragment(mPagerAdapter.getItem(0));

        exitLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //US53334 Start-OnBoarding analytics
                int currentItem = mViewPager.getCurrentItem();
                //Start: US72282: FingerPrint Analytics
                //Have replaced currentItem == OnBoardConstant.QUICKVIEW_PAGE with the following line, So we refer
                //current item with its fragment
                if (mPagerAdapter.getItem(currentItem) instanceof OnBoardEnableQuickViewFragment) {
                //End: US72282: FingerPrint Analytics
                    if (Globals.isBankLoginSelected()) {
                        HashMap<String, Object> extras = new HashMap<String, Object>();
                        extras.put(
                                AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                        //Start: US72282: FingerPrint Analytics
                        extras.put(mContext.getString(R.string.evar35),getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                        //End: US72282: FingerPrint Analytics
                        extras.put(
                                AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_quickview_into));
                        extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                        TrackingHelper.trackBankPage(null, extras);
                    }
                } else if (mPagerAdapter.getItem(currentItem) instanceof OnBoardPasscodeContainerFragment) {
                    if (Globals.isBankLoginSelected()) {
                        HashMap<String, Object> extras = new HashMap<String, Object>();
                        extras.put(
                                AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                        //Start: US72282: FingerPrint Analytics
                        extras.put(mContext.getString(R.string.evar35),getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                        //End: US72282: FingerPrint Analytics
                        extras.put(
                                AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_passcode_intro_pge));
                        extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                        TrackingHelper.trackBankPage(null, extras);
                    }
                    //Start: US72282: FingerPrint Analytics
                }else if(mPagerAdapter.getItem(currentItem) instanceof OnBoardFingerprintFragment) {
                    if(Globals.isBankLoginSelected()){
                        HashMap<String,Object> extras=FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                        extras.put(AnalyticsPage.CONTEXT_PROPERTY_1,getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                        extras.put(mContext.getString(R.string.evar35),getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                        extras.put(AnalyticsPage.CONTEXT_PROPERTY_13,AnalyticsPage.FINGER_PRINT_INTRO_PG);
                        TrackingHelper.trackBankClickEvents(getResources().getString(R.string.bank_analytics_onboard_exit_btn),null,AnalyticsPage.LINK_TYPE_O,extras);
                    }
                    //End: US72282: FingerPrint Analytics
                }else if (mPagerAdapter.getItem(currentItem) instanceof OnBoardPaperlessFragment && Globals.isBankLoginSelected()) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                    //Start: US72282: FingerPrint Analytics
                    extras.put(mContext.getString(R.string.evar35),getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                    //End: US72282: FingerPrint Analytics
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.onboard_paperless_tag));
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                }
                //US53334 End
                if (Globals.isFromCardSide()) {
                    //US53328-START
                    Fragment currentFragment = mPagerAdapter.getItem(previousItem);

                    trackExitSetup(currentFragment);
                    //ENDS
                }
                if (mContext instanceof OnBoardActivity) {
                    OnBoardHelper.navigateToCardOrBankHome();
                }

                FileDownloader.getInstance().flushImages(ImageDir.DIR_ENUM.ONBOARDING);

                /**US79241- start*/
                final FingerPrintUtils fingerPrintUtils = new FingerPrintUtils(mContext);
                if (!fingerPrintUtils.getFingerPrintStatus())
                    fingerPrintUtils.removeFingerprintPasscode();
                /**US79241- end*/
            }
        });
        mViewPager.addOnPageChangeListener(
                new ViewPager.SimpleOnPageChangeListener() {
                    @Override
                    public void onPageSelected(int currentItem) {

                        if (currentItem == mPagerAdapter.getCount() - 1) {
                            mDoneButton.setVisibility(View.VISIBLE);
                            mPagerButton.setVisibility(View.GONE);
                            mDoneButton.setText(mContext.getString(R.string.onboard_done));
                            mDoneButton.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                        } else {
                            mDoneButton.setVisibility(View.GONE);
                            mPagerButton.setVisibility(View.VISIBLE);
                            mPagerButton.setText("");
                            mPagerButton.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.onboard_right_arrow, 0);

                        }
                        //When page got changed, remove the Ribben message
                        RibbenMessage.destroyRibben();
                        //Get the previous fragment
                        Fragment previousFragment = mPagerAdapter.getItem(previousItem);
                        //Update the current fragment from pagerView
                        setCurrentFragment(mPagerAdapter.getItem(currentItem));

                        if (previousFragment instanceof IPopFragment) {
                            // lets see if the currentFragment or any of its childFragment can handle onBackPressed
                            ((IPopFragment) previousFragment).updateCurrentPage();
                        }

                        if (Globals.isFromCardSide()) {
                            trackAnalytics(mPagerAdapter.getItem(currentItem));
                        }
                        previousItem = currentItem;

                        //Start: US72282: FingerPrint Analytics
                        if(mPagerAdapter.getItem(currentItem) instanceof OnBoardFingerprintFragment){
                            if (Globals.isBankLoginSelected() && (isFingerPrint)) {
                                FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_INTRO_PG);
                                isFingerPrint=false;
                            }
                        }
                        //End: US72282: FingerPrint Analytics

                        if (mPagerAdapter.getItem(currentItem) instanceof OnBoardEnableQuickViewFragment) {
                            if (Globals.isBankLoginSelected() && (isQuickView)) {
                                FacadeFactory.getBankLoginFacade().forceTrackPage(R.string.bank_analytics_onboard_quickview_into);
                                isQuickView = false;
                            }

                            //End

                        }else if (mPagerAdapter.getItem(currentItem) instanceof OnBoardPaperlessFragment) {
                            // Start: US53564 - Onboarding Wizard: Paperless Enable Site Catalyst Tags
                            if (Globals.isBankLoginSelected()) {
                                //condition to restrict page tag to fire only once.
                                if (isPaperless) {
                                    FacadeFactory.getBankLoginFacade().forceTrackPage(R.string.onboard_paperless_tag);
                                    isPaperless = false;
                                }
                                if (getCurrentFragment() instanceof OnBoardPaperlessFragment) {
                                    //Hide the spacing view, added to fix defect #242843
                                    ((OnBoardPaperlessFragment) getCurrentFragment()).hideSpacingView();
                                }

                            }
                            //End
                        }else if(mPagerAdapter.getItem(currentItem) instanceof OnBoardFingerprintFragment){

                            if (previousFragment instanceof IPopFragment)
                               ((IPopFragment) mPagerAdapter.getItem(currentItem)).updateCurrentPage();
                        }
                    }
                }
        );
        mPagerIndicator.setViewPager(mViewPager);
        mPagerButton.setText("");
        mPagerButton.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.onboard_right_arrow, 0);
        mViewPager.setOffscreenPageLimit(mPagerAdapter.getCount());
        return mView;
    }

    //US53328-STARTS
    private void trackDoneBtnLink(Fragment currentFragment) {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_DONE_LNK_PROP1);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_DONE_LNK_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_DONE_LNK_PEV1);
        extras.put(getActivity().getString(R.string.evar35), AnalyticsPage.ONBOARDWIZ_DONE_LNK_VAR35);

        if (currentFragment instanceof OnBoardEnableQuickViewFragment) {
            //TODO write code for Quickview page state
            if (OnBoardEnableQuickViewFragment.quickview_page_state == OnBoardConstant.QUICKVIEW_PAGE_STATE.ENABLE_PAGE) {
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_INTRO_PAGE_NAME);

            } else if (OnBoardEnableQuickViewFragment.quickview_page_state == OnBoardConstant.QUICKVIEW_PAGE_STATE.CONFIRMATION_PAGE) {
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_SUCCESS_PAGE_NAME);

            } else if (OnBoardEnableQuickViewFragment.quickview_page_state == OnBoardConstant.QUICKVIEW_PAGE_STATE.QUICKVIEW_DONE_PAGE) {
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_STEP_COMPLETE_PAGE_NAME);

            }

        }
        TrackingHelper.trackCardPage(null, extras);


    }
    //ENDS

    //us53328-STARTS
    private void trackExitSetup(Fragment currentFragment) {
        if (currentFragment instanceof OnBoardPasscodeContainerFragment) {
            {
                HashMap<String, Object> extras = new HashMap<String, Object>();

                extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PROP1);
                extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PE);
                extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PEV1);
                extras.put(getActivity().getString(R.string.evar35), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_VAR35);
                if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.ENABLE_PAGE) {
                    extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PAGE_NAME);
                } else if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.PASSCODE_DONE_PAGE) {
                    extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_SETUP_COMPLETE_PAGE_NAME);

                }

                TrackingHelper.trackCardPage(null, extras);
            }
        } else if (currentFragment instanceof OnBoardEnableQuickViewFragment) {
            boolean qvState = OnBoardEnableQuickViewFragment.getCurrentState();

            HashMap<String, Object> extras = new HashMap<String, Object>();

            extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PROP1);
            extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PE);
            extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PEV1);
            extras.put(getActivity().getString(R.string.evar35), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_VAR35);
            if (qvState) {
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_STEP_COMPLETE_PAGE_NAME);

            } else {
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_INTRO_PAGE_NAME);
            }

            TrackingHelper.trackCardPage(null, extras);

        } else if (currentFragment instanceof OnBoardFingerprintFragment) {

            onBoardFingerprintFragment = new OnBoardFingerprintFragment();
            int fp_state = onBoardFingerprintFragment.getCurrentPageState();
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put(mContext.getString(R.string.prop1), AnalyticsPage.EXIT_SETUP_LNK);
            extras.put(mContext.getString(R.string.evar35), AnalyticsPage.EXIT_SETUP_LNK);

            if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_ENABLED) {
                extras.put(mContext.getString(R.string.prop13), AnalyticsPage.FINGER_PRINT_SUCCESS_CONFIRMATION_PG);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_REGISTERED) {
                extras.put(mContext.getString(R.string.prop13), AnalyticsPage.FINGER_PRINT_SETUP_DEVICE_PG);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.PASSCODE_NOT_ENABLED) {
                extras.put(mContext.getString(R.string.prop13), AnalyticsPage.FINGER_PRINT_SETUP_PASSCODE_PG);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED) {
                extras.put(mContext.getString(R.string.prop13), AnalyticsPage.FINGERPRINT_ENABLED_PG);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED) {
                extras.put(mContext.getString(R.string.prop13), AnalyticsPage.FINGER_PRINT_INTRO_PG);
            }
            TrackingHelper.trackClickEvents(AnalyticsPage.EXIT_SETUP_LNK,null, AnalyticsPage.ONBOARDWIZ_FINGERPRINT_LINK_O_PG,extras);



        }
        }





    //ENDS

    //US53328-START
    private void trackAnalytics(Fragment currentFragment) {
        if (currentFragment instanceof OnBoardPasscodeContainerFragment) {
            if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.ENABLE_PAGE) {
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PAGE_NAME, null);

            } else if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.PASSCODE_DONE_PAGE) {
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_PASSCODE_SETUP_COMPLETE_PAGE_NAME, null);
            }

        } else if (currentFragment instanceof OnBoardEnableQuickViewFragment) {

            boolean qvState = OnBoardEnableQuickViewFragment.getCurrentState();
            if (qvState) {

                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_STEP_COMPLETE_PAGE_NAME, null);


            } else {
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_QUICK_VIEW_INTRO_PAGE_NAME, null);

            }
        } else if (currentFragment instanceof OnBoardFingerprintFragment) {

            onBoardFingerprintFragment = new OnBoardFingerprintFragment();
            int fp_state = onBoardFingerprintFragment.getCurrentPageState();
            if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_ENABLED) {
                TrackingHelper.trackCardPage(AnalyticsPage.FINGER_PRINT_SUCCESS_CONFIRMATION_PG, null);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_REGISTERED) {
                TrackingHelper.trackCardPage(AnalyticsPage.FINGER_PRINT_SETUP_DEVICE_PG, null);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.PASSCODE_NOT_ENABLED) {
                TrackingHelper.trackCardPage(AnalyticsPage.FINGER_PRINT_SETUP_PASSCODE_PG, null);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED) {
                TrackingHelper.trackCardPage(AnalyticsPage.FINGERPRINT_ENABLED_PG, null);
            } else if (fp_state == OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED) {
                TrackingHelper.trackCardPage(AnalyticsPage.FINGER_PRINT_INTRO_PG, null);
                OnBoardFingerprintFragment.isFpIntroPageEnable=true;
            }
            //TODO Bank Tema can include PaperLess tracking for Bank support
        }
    }

//END

    /**
     * Retrieve the currently visible Fragment and propagate the onBackPressed callback
     *
     * @return true = if this fragment and/or one of its associates Fragment can handle the
     * backPress
     */
    public boolean onBackPressed() {
        int currentItem = mViewPager.getCurrentItem();
        //US53334 Start-OnBoarding analytics
        if (mPagerAdapter.getItem(currentItem) instanceof OnBoardEnableQuickViewFragment) {
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passcode_back_btn));
                extras.put("my.eVar35", getResources().getString(R.string.bank_analytics_onboard_passcode_back_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_quickview_into));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
        } else if (mPagerAdapter.getItem(currentItem) instanceof OnBoardPasscodeContainerFragment) {
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passcode_back_btn));
                extras.put("my.eVar35", getResources().getString(R.string.bank_analytics_onboard_passcode_back_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_passcode_intro_pge));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
        }
        //US53334 END

        // currently visible tab Fragment
        Fragment currentFragment = mPagerAdapter.getItem(mViewPager.getCurrentItem());

        if (currentFragment instanceof IPopFragment) {
            // lets see if the currentFragment or any of its childFragment can handle onBackPressed
            return ((IPopFragment) currentFragment).popBackStack();
        }
        // this Fragment couldn't handle the onBackPressed call
        return false;

    }

    @Override
    public void moveToNextPage() {
        int currentItem = mViewPager.getCurrentItem();
        if (currentItem == mPagerAdapter.getCount() - 1) {
            ((OnBoardMasterFragment) getParentFragment()).showInLeftFrame(new OnBoardConfirmationFragment());
        } else {
            mViewPager.setCurrentItem(currentItem + 1, true);
            Fragment currentFragment = mPagerAdapter.getItem(mViewPager.getCurrentItem());


            if (currentFragment instanceof OnBoardEnableQuickViewFragment) {

                ((OnBoardEnableQuickViewFragment) currentFragment).updateUI();
            } else if (currentFragment instanceof OnBoardPaperlessFragment) {
                ((OnBoardPaperlessFragment) currentFragment).updateUI();
            } else if (currentFragment instanceof OnBoardFingerprintFragment) {
                ((OnBoardFingerprintFragment) currentFragment).updateCurrentPage();
            }
        }
        //US53334 Start-OnBoarding analytics
        if (mPagerAdapter.getItem(currentItem) instanceof OnBoardEnableQuickViewFragment) {
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passcode_forward_btn));
                extras.put("my.eVar35", getResources().getString(R.string.bank_analytics_onboard_passcode_forward_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_quickview_into));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
        } else if (mPagerAdapter.getItem(currentItem) instanceof OnBoardPasscodeContainerFragment) {
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passcode_forward_btn));
                extras.put("my.eVar35", getResources().getString(R.string.bank_analytics_onboard_passcode_forward_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_passcode_intro_pge));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
        }
        //US53334 End
    }

    //US53328

    private void trackAnalyticsForwordButton(Fragment currentFragment) {
        if (currentFragment instanceof OnBoardPasscodeContainerFragment) {
            HashMap<String, Object> extras = new HashMap<String, Object>();

            extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_FORWORD_BUTTON_PROP1);
            extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_FORWORD_BUTTON_PE);
            extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_FORWORD_BUTTON_PEV1);
            extras.put(getActivity().getString(R.string.evar35), AnalyticsPage.ONBOARDWIZ_FORWORD_BUTTON_VAR35);


            if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.ENABLE_PAGE) {

                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_ENABLE_PAGE_NAME);


            } else if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.EXISTING_PAGE) {
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_ENTER_PASSCODE_PAGE_NAME);
            } else if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE) {

                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_CREATE_PASSCODE_PAGE_NAME);
            } else if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.VERIFY_PAGE) {

                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_VERIFY_PASSCODE_PAGE_NAME);

            } else if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.CONFIRMATION_PAGE) {

                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_SUCCESS_PAGE_NAME);
            } else if (OnBoardPasscodeContainerFragment.passcode_state == OnBoardConstant.PASSCODE_PAGE_STATE.PASSCODE_DONE_PAGE) {
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_SETUP_COMPLETE_PAGE_NAME);

            }

            TrackingHelper.trackCardPage(null, extras);

        }
    }

    //ENDS
    @Override
    public void moveToPreviousPage() {
        int currentItem = mViewPager.getCurrentItem();
        if (currentItem == 0) {
            //no action
        } else {
            mViewPager.setCurrentItem(currentItem - 1, true);
        }
    }

    public void controlVisibilityExitSetupLink(boolean isVisible) {

        exitLink.setVisibility(isVisible ? View.VISIBLE : View.INVISIBLE);
    }

    public RelativeLayout getView() {
        return ((RelativeLayout) mView.findViewById(R.id.parent_view));
    }

    public void hideExitSetupLink() {
        exitLink.setVisibility(View.GONE);

    }

    //US54329: Feature Transitions code changes start

    /**
     * Function helps to get the current fragment which loaded on page Viewer
     *
     * @return - fragment name which loaded on PageView
     */
    public Fragment getCurrentFragment() {
        return currentFragment;
    }

    /**
     * Function which will hold the fragment name which loaded on PageView
     *
     * @param currentFragment - Current page
     */
    public void setCurrentFragment(Fragment currentFragment) {
        this.currentFragment = currentFragment;
    }
    //US54329: Feature Transitions code changes end
}
