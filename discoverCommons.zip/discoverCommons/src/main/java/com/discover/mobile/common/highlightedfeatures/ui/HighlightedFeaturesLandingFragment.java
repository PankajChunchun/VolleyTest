package com.discover.mobile.common.highlightedfeatures.ui;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.discover.mobile.common.BaseFragment;
import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.highlightedfeatures.adapter.HighlightedFeatureAdaptor;
import com.discover.mobile.common.highlightedfeatures.beans.Analytics;
import com.discover.mobile.common.highlightedfeatures.beans.FeatureContent;
import com.discover.mobile.common.highlightedfeatures.beans.HighlightedFeaturesData;
import com.discover.mobile.common.highlightedfeatures.utils.HFConstants;
import com.discover.mobile.common.highlightedfeatures.utils.HFUtils;
import com.discover.mobile.common.liveperson.LPPushNotification;
import com.discover.mobile.common.nav.DrawerBaseActivity;
import com.discover.mobile.common.navigation.NoSwipeOpenMenu;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.ui.widgets.CirclePageIndicator;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Main fragment which is responsible to fetch highlighted data form Cache and show for either
 * WhatsNew or Highlighted-feature.
 *
 * @author pkuma13
 */
// HighlightedFeatureMainFragment
public class HighlightedFeaturesLandingFragment extends BaseFragment implements HighlightedFeatureClickHandler, NoSwipeOpenMenu {
    public static final String TAG = HighlightedFeaturesLandingFragment.class.getSimpleName();
    /**
     * Bolean for Customer service from card. This flag is basically moved from
     * com.discover.mobile.card.customerservice.CustomerServiceLandingFragment
     */
    public static boolean isClickHandled = false;
    private ArrayList<FeatureContent> mFeatureList = null;
    private  boolean isForWhatsNew; //US113465: Whatsnew Sitecat Defect fix
    private boolean isPreLogin = false;
    private HFConstants.LoginType mLoginType;
    private int mCurrentIndex = 0;
    private ViewPager mViewPager;
    private CirclePageIndicator mIndicator;
    private View mMainView = null;
    private Activity mContext;
    private Bundle mArguments;
    private String cardType;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getActivity() instanceof DrawerBaseActivity) {
            //((DrawerBaseActivity) getActivity()).setBa;
        }

        // Read Arguments and initialise required data.
        readArguments();
        resetHfContents();

        mMainView = inflater.inflate(R.layout.highlighted_whatsnew_main_view_pager_layout, null);
        // boolean isKillSwitchEnabled = Utils.hideScreensInApp.contains(getResources().getString(R.string.sub_section_title_android_pay));

        /*if (isKillSwitchEnabled == true) {
            deleteAndroidPayJson(getActivity());
        }*/
        initPager();

        return mMainView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mContext = getActivity();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        if (mViewPager != null) {
            mCurrentIndex = mViewPager.getCurrentItem();
        }

        if (mMainView != null) {
            initPager();
        }

        if (mViewPager != null) {
            mViewPager.setCurrentItem(mCurrentIndex);
        }
    }


    public void initPager() {
        mViewPager = (ViewPager) mMainView.findViewById(R.id.pager);

        mIndicator = (CirclePageIndicator) mMainView.findViewById(R.id.indicator);


        boolean isCardSelected = true;
        if (mLoginType == HFConstants.LoginType.CARD) {
            isCardSelected = true;
        } else {
            isCardSelected = false;
        }


        HighlightedFeatureAdaptor adapter = new HighlightedFeatureAdaptor(getActivity(), getChildFragmentManager(), mFeatureList, isForWhatsNew, isCardSelected, this);
        mViewPager.setAdapter(adapter);

        if (mFeatureList.size() >= 1) {
//			setUpIndicators(features.size(), currentIndex, view);
            mViewPager.setCurrentItem(mCurrentIndex);
            mIndicator.setViewPager(mViewPager);
        }
        // Added fix for showing white screen while whatsNew feature not avaialble for one of the SSO Card type.
        else
        {
            getActivity().onBackPressed();
        }
        mCurrentIndex = mViewPager.getCurrentItem();
        cardType = Globals.getCardType(getActivity());

        // Defect 232943/232985 fix start
        // OnPageChangeListener should be set to CirclePageIndicator, not to ViewPager.
        mIndicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i2) {

            }

            @Override
            public void onPageSelected(int i) {
                // Track the current page
                trackView(mFeatureList.get(i));
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
        // Defect 232943/232985 fix end
    }

    private void readArguments() {
        mArguments = getArguments();
        if (mArguments == null || (mArguments.containsKey(HFConstants.Args.PRE_LOGIN_FLAG) == false)
                || (mArguments.containsKey(HFConstants.Args.LOGIN_TYPE) == false)) {
            throw new IllegalArgumentException("Required arguments ARGS_PRE_LOGIN_FLAG, ARGS_LOGIN_TYPE must be set fragment's arguments.");
        }

        this.isPreLogin = mArguments.getBoolean(HFConstants.Args.PRE_LOGIN_FLAG);
        this.mLoginType = (HFConstants.LoginType) mArguments.getSerializable(HFConstants.Args.LOGIN_TYPE);
        /**
         * 410 start - return true if the sso user has seen what's new page
         */
        if(this.mLoginType.equals(HFConstants.LoginType.SSO)){
            Globals.isSsoUserSeenWhatsNew=true;
        }
        /**
         * 410 end
         */
        this.isForWhatsNew = mArguments.getBoolean(HFConstants.Args.WHATS_NEW_FLAG, false);
        this.mCurrentIndex = mArguments.getInt(HFConstants.Args.PAGER_LOCATION, 0);
        this.mFeatureList = mArguments.getParcelableArrayList(HFConstants.Args.HF_LIST);

    }

    private void resetHfContents() {
        if (mFeatureList == null) {
            HighlightedFeaturesData hfData = HFUtils.getHFFeatureFromPref(getActivity());
            if (isForWhatsNew == true) {
                if (mLoginType == HFConstants.LoginType.CARD) {
                    mFeatureList = HFUtils.getWhatsNewFeaturesList(getActivity(), HFConstants.LoginType.CARD);
                } else if (mLoginType == HFConstants.LoginType.BANK) {
                    mFeatureList = HFUtils.getWhatsNewFeaturesList(getActivity(), HFConstants.LoginType.BANK);
                } else if (mLoginType == HFConstants.LoginType.SSO) {
                    mFeatureList = HFUtils.getWhatsNewFeaturesList(getActivity(), HFConstants.LoginType.SSO);
                } else {
                    // Default will show card user whats-new
                    mFeatureList = HFUtils.getWhatsNewFeaturesList(getActivity(), HFConstants.LoginType.CARD);
                }
            } else {
                mFeatureList = HFUtils.getHighlightedFeaturesList(getActivity(), hfData, this.mLoginType, isPreLogin);
            }

            if (hfData != null) {
                // Fix for defect # 195068, # 195087
                HFUtils.deleteOldHFImages(mFeatureList, getActivity());
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mFeatureList.size() > 0)
            trackView(mFeatureList.get(0));

    }

    /**
     * Save the state of the activity.
     *
     * @param outState - bundle to save the state the activity
     */
    @Override
    public void onSaveInstanceState(final Bundle outState) {
        if (mViewPager != null) {
            outState.putInt(HFConstants.Args.PAGER_LOCATION, mViewPager.getCurrentItem());
        }
        outState.putBoolean(HFConstants.Args.WHATS_NEW_FLAG, isForWhatsNew);
        outState.putBoolean(HFConstants.Args.PRE_LOGIN_FLAG, isPreLogin);
        outState.putSerializable(HFConstants.Args.LOGIN_TYPE, mLoginType);
        outState.putParcelableArrayList(HFConstants.Args.HF_LIST, mFeatureList);

        super.onSaveInstanceState(outState);
    }

    /**
     * Return the integer value of the string that needs to be displayed in the
     * title
     */
    @Override
    public int getActionBarTitle() {
        return R.string.common_highlighted_features_title;
    }

    /**
     * Return GrupMenuLocation
     */
    @Override
    public int getGroupMenuLocation() {
        //if (this.isPreLogin == false) {
        //return CardMenuItemLocationIndex.getInstance(getActivity()).getMenuGroupLocation(R.string.sub_section_title_highlighted_features);
        //} else {
        return 0;
        //}
    }

    /**
     * Return selected Menu Location
     */
    @Override
    public int getSectionMenuLocation() {
        //if (this.isPreLogin == false) {
        //return CardMenuItemLocationIndex.getInstance(getActivity()).getMenuSectionLocation(R.string.sub_section_title_highlighted_features);
        //} else {
        return 0;
        //}
    }

    @Override
    public void featureClicked(FeatureContent feature) {

        if (feature.getDeepLinkCode().equals("linktoAndroidPay")) {
            if (isForWhatsNew) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put("my.prop1", AnalyticsPage.ANDROID_PAY_WHATS_NEW_GET_STARTED_BTN);
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                extras.put("pev1", AnalyticsPage.ANDROID_PAY_WHATS_NEW_GET_STARTED_BTN);
                TrackingHelper.trackCardPage(null, extras);
            } else {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put("my.prop1", AnalyticsPage.ANDROID_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN);
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                extras.put("pev1", AnalyticsPage.ANDROID_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN);
                TrackingHelper.trackCardPage(null, extras);
            }
        }else if(feature.getDeepLinkCode().equals("linktoSamsungPay")) {
            if (!isForWhatsNew) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put("my.prop1", AnalyticsPage.SAMSUNG_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN);
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                extras.put("pev1", AnalyticsPage.SAMSUNG_PAY_HIGHLIGHTED_FEATURE_GET_STARTED_BTN);
                TrackingHelper.trackCardPage(null, extras);
            }
        }
        else if(feature.getDeepLinkCode().equals("linktotouchid")){

            if(isForWhatsNew){
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_WHATS_NEW_ENABLE_FINGERPRINT_BTN);
                TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_WHATS_NEW_ENABLE_FINGERPRINT_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
            }else{
                if(mLoginType == HFConstants.LoginType.CARD){
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_HIGHLIGHTED_FEATURE_ENABLE_FINGERPRINT_BTN);
                    TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_HIGHLIGHTED_FEATURE_ENABLE_FINGERPRINT_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                }
            }
            /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/

            //Start: US72282: FingerPrint Analytics
        } else if(feature.getDeepLinkCode().equals(getResources().getString(R.string.deeplink_value_touchid))) {
            HashMap<String, Object> extras= FacadeFactory.getBankHFDeeplinkFacade().getHashMap() ;
            extras.put(AnalyticsPage.PROP1,AnalyticsPage.FINGER_PRINT_WHATS_NEW_ENABLE_FINGERPRINT_BTN);
            TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_WHATS_NEW_ENABLE_FINGERPRINT_BTN ,null, AnalyticsPage.LINK_TYPE_O,extras);
        }
           //End: US72282: FingerPrint Analytics
        else if(feature.getDeepLinkCode().equals(LPPushNotification.LINK_TO_MESSAGING)) {
            if (isForWhatsNew) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.APP_MESSAGING_WHATSNEW_GOTO_MSG_BTN);
                TrackingHelper.trackClickEvents(AnalyticsPage.APP_MESSAGING_WHATSNEW_GOTO_MSG_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
            } else {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(mContext.getResources().getString(R.string.prop1), AnalyticsPage.APP_MESSAGING_HF_GOTO_MSG_BTN);
                TrackingHelper.trackClickEvents(AnalyticsPage.APP_MESSAGING_HF_GOTO_MSG_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
            }
            /*US113465 : OverDraft Whatsnew Sitcat*/
        }else {
            if (!feature.isApplyToCardSide()) {
                bankClick(feature);
            } else {
                trackClick(feature);
            }
        }
        if (this.isPreLogin == true) {
            handlePreloginClick(feature.getDeepLinkCode(), mArguments);
        } else {
            handlePostloginClick(feature);
        }
    }


    @Override
    public void featureClosed() {
        if (getActivity() instanceof HighlightedFeaturePreLoginActivity) {
            ((HighlightedFeaturePreLoginActivity) getActivity()).navigateToRoot();
        }
    }

    private void trackView(FeatureContent feature) {
        String tag = "";

        //US48045 - What's New Analytics
        if (isForWhatsNew) {

            if(feature.getDeepLinkCode().equals(LPPushNotification.LINK_TO_MESSAGING)) {
                TrackingHelper.trackPageView(AnalyticsPage.APP_MESSAGING_WHATSNEW_PG);
                return;
            }

            /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
            if (feature.getDeepLinkCode().equals(FingerPrintUtils.fpSetupDeeplinkCode)) {
                TrackingHelper.trackCardPage(AnalyticsPage.FINGER_PRINT_WHATSNEW_PG, null);
                /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                //Start: US72282: FingerPrint Analytics
            }else if(feature.getDeepLinkCode().equals(getResources().getString(R.string.deeplink_value_touchid))) {
                FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_WHATSNEW_PG);
            }
            else
                //End: US72282: FingerPrint Analytics
            {
                tag += feature.getAnalytics().getWnAnalyticsTagPageView();
                //
                 FacadeFactory.getBankLoginFacade().forceTrackPage(tag,Globals.isSSOUser());

            }


        } else {

            if(feature.getDeepLinkCode().equals(LPPushNotification.LINK_TO_MESSAGING)) {
                TrackingHelper.trackPageView(AnalyticsPage.CUSTOMERSERVICEHFMESSAGING);
                return;
            }

            if (isPreLogin) {
                tag += "PRE_" + feature.getAnalytics().getHfAnalyticsTagPageView();
                TrackingHelper.trackPageView(tag);
            } else {

                /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                if(feature.getDeepLinkCode().equals("linktoSamsungPay")) {

                    TrackingHelper.trackCardPage(AnalyticsPage.SAMSUNG_PAY_HF_PAGENAME, null);
                }
                else if(feature.getDeepLinkCode().equals("linktoAndroidPay")) {

                    TrackingHelper.trackCardPage(AnalyticsPage.ANDROID_PAY_HIGHLIGHTED_PG, null);
                }
                else if(feature.getDeepLinkCode().equals(FingerPrintUtils.fpSetupDeeplinkCode)) {
                    if(mLoginType == HFConstants.LoginType.CARD){
                        TrackingHelper.trackCardPage(AnalyticsPage.CUSTOMERSERVICEFP, null);
                    }
                    TrackingHelper.trackPageView(tag);
                    /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                }else if(feature.getDeepLinkCode().equals("authview_linktodisplayalertterms")){
                    TrackingHelper.trackCardPage(AnalyticsPage.CUSTOMERSERVICEHFMANAGEALERTS, null);
                }else if(feature.getDeepLinkCode().equals("linktoraf")) {
                    TrackingHelper.trackCardPage(AnalyticsPage.CUSTOMERSERVICEHFRAF, null);
                }else if(feature.getDeepLinkCode().equals("linktofico")) {
                    TrackingHelper.trackCardPage(AnalyticsPage.CUSTOMERSERVICEHFFICOCREDIT, null);
                }else if(feature.getDeepLinkCode().equals("linktoPayWithCBB")) {
                    TrackingHelper.trackCardPage(AnalyticsPage.CUSTOMERSERVICEMAPCBB, null);
                } else{
                    tag += "POST_" + feature.getAnalytics().getHfAnalyticsTagPageView();
                    TrackingHelper.trackPageView(tag);
                }
            }

        }
    }

    /*US113465 : OverDraft Whatsnew Sitcat*/
    private void bankClick(FeatureContent feature) {
        HashMap<String, Object> extras= FacadeFactory.getBankHFDeeplinkFacade().getHashMap() ;
        if(Globals.isSSOUser())
        {
            extras.put(TrackingHelper.CONTEXT_USER_PROP, TrackingHelper.CUSTOMER);
            extras.put(TrackingHelper.CONTEXT_USER_VAR, TrackingHelper.CUSTOMER);
        }
        extras.put(AnalyticsPage.PROP1,feature.getAnalytics().getHfAnalyticsTagButtonClick());
        TrackingHelper.trackBankClickEvents(feature.getAnalytics().getHfAnalyticsTagButtonClick() ,null, AnalyticsPage.LINK_TYPE_O,extras);
    }

    private void trackClick(FeatureContent feature) {
        String tag = "";

        //US48045 - What's New Analytics

        if (isForWhatsNew) {
            //fetch the whats new tags
            tag += feature.getAnalytics().getWnAnalyticsTagButtonClick();
            FacadeFactory.getBankLoginFacade().forceTrackPage(tag);
        } else {
            //fetch the HF tags
            if (isPreLogin) {
                tag += "PRE_" + feature.getAnalytics().getHfAnalyticsTagButtonClick();
            } else {
                tag += "POST_" + feature.getAnalytics().getHfAnalyticsTagButtonClick();
            }
            TrackingHelper.trackCardPageProp1(tag, tag);
        }
    }


    private void handlePostloginClick(FeatureContent feature) {
        if (feature.isApplyToCardSide()) {
            // This is CARD deeplink
            FacadeFactory.getCardHFDeeplinkFacade().handlePostLoginClick(getActivity(), feature.getDeepLinkCode());
        } else {
            // This is BANK deeplink
            FacadeFactory.getBankHFDeeplinkFacade().handlePostLoginClick(getActivity(), feature.getDeepLinkCode());
        }
    }

    private void handlePreloginClick(String deeplinkCode, Bundle extras) {
        if (mLoginType == HFConstants.LoginType.CARD) {
            FacadeFactory.getCardHFDeeplinkFacade().handlePreLoginClick(getActivity(), extras, deeplinkCode);
        } else if (mLoginType == HFConstants.LoginType.BANK) {
            FacadeFactory.getBankHFDeeplinkFacade().handlePreLoginClick(getActivity(), extras, deeplinkCode);
        }
        // For Prelogin we only need to check for either bank or card.
    }

    @Override
    public void onDetach() {
        super.onDetach();

        /*try {
            Field field = Fragment.class.getDeclaredField("mChildFragmentManager");
            field.setAccessible(true);
            field.set(this, null);
//			mViewPager.setAdapter(null);
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }

    /* Locks view in portrait mode */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    /**
     * Sets argument to bundle using {@link android.support.v4.app.Fragment#setArguments(android.os.Bundle)}.
     * Caller may not use this method, depends on requirement.
     *
     * @param pagerIndex - Selected mViewPager index. Default should be <code>0</code>.
     * @param isWhatsNew - <code>true</code> if request is for What's new. <code>false</code> for
     *                   Highlighted-feature.
     * @param isPreLogin - <code>true</code> if page requested from prelogin. <code>false</code> for
     *                   post-login.
     * @param loginType  - {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     */
    public Bundle getHFArguments(int pagerIndex, boolean isWhatsNew,
                                 boolean isPreLogin, HFConstants.LoginType loginType) {
        Bundle bundle = new Bundle();
        bundle.putInt(HFConstants.Args.PAGER_LOCATION, pagerIndex);
        bundle.putBoolean(HFConstants.Args.WHATS_NEW_FLAG, isWhatsNew);
        bundle.putBoolean(HFConstants.Args.PRE_LOGIN_FLAG, isPreLogin);
        bundle.putSerializable(HFConstants.Args.LOGIN_TYPE, loginType);
        return bundle;
    }
}