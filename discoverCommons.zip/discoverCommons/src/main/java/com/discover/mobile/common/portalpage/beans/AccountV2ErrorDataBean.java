package com.discover.mobile.common.portalpage.beans;

import com.discover.mobile.common.shared.Struct;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;

import java.io.Serializable;
import java.util.List;

public class AccountV2ErrorDataBean extends ErrorResponseDetails {
    private static final long serialVersionUID = 8468456670129818112L;
    public List<Data> data;

    public List<Data> getData() {
        return data;
    }

    @Struct
    public static class Data implements Serializable {

        private static final long serialVersionUID = -9036250320326393394L;
        public String errorCode = null;
        public String errorMessage = null;
        public String errorTitle = null;
        public String isAppError = null;
        public String footerStatus = null;

        public String questionId = null;
        public String questionText = null;

        public String isSSOUidDLinkable = null;
        public String isSSOUser = null;
        public String isSSNMatched = null;
        public String isTempLocked = null;

        public String status = null;
        public String phoneNumber = null;
        /* Prod Issue- While Bank server down for SSO */
        public String bankSummaryStatus = null;
    /* Prod Issue- While Bank server down for SSO */

        public String cardTypeIndicator = null;

        public String acctLast4;
        public String email;
        public String userId;
        public String isSuccessfulTempPass = null;
    }

    ;

}
