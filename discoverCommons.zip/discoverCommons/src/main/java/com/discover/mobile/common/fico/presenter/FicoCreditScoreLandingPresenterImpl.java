package com.discover.mobile.common.fico.presenter;

import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.bean.FicoScoreList;
import com.discover.mobile.common.fico.bean.NegativeKeyFactor;
import com.discover.mobile.common.fico.bean.PositiveKeyFactor;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreLandingUIInterface;
import com.discover.mobile.common.fico.utils.FicoCreditScoreConstants;
import com.discover.mobile.common.fico.utils.FicoUtils;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by 526158 on 05/05/2017.
 */
public class FicoCreditScoreLandingPresenterImpl implements FicoCreditScoreLandingPresenter {

    private final FicoCreditScoreLandingUIInterface mFicoCreditScoreUI;
    private List<PositiveKeyFactor> positiveKeyFactorList;
    private List<NegativeKeyFactor> negativeKeyFactorList;

    public FicoCreditScoreLandingPresenterImpl(FicoCreditScoreLandingUIInterface appMessagingUIInterface) {
        mFicoCreditScoreUI = appMessagingUIInterface;
    }

    @Override
    public void getFicoScoreListData(Bundle bundle) {
        if (bundle != null) {
            boolean isFicoScoreAvailable = bundle.getBoolean(FicoCreditScoreConstants.IS_FICO_SCORE_AVAILABLE, true);
            if (isFicoScoreAvailable) {
                FicoCreditScore ficoCreditScore = (FicoCreditScore) bundle.getSerializable(FicoCreditScoreConstants.FICO_CREDIT_SCORE);
                mFicoCreditScoreUI.setTabletLandViewData(ficoCreditScore);
                /**start code optimization for CreditScore Box */
                FicoScoreList mFicoScoreListItem = null;
                boolean isNoScoreAvailableFor90Days = ficoCreditScore.isScoreTooOld();
                if (!isNoScoreAvailableFor90Days) {
                    //Latest score available
                    mFicoScoreListItem = FicoUtils.getFicoScoreListItem(ficoCreditScore.getFicoScoreList(), ficoCreditScore.getScoreDate());
                } else {
                    if (ficoCreditScore.getFicoScoreList().size() != 0) {
                        List<FicoScoreList> ficoScoreList = new ArrayList<>(ficoCreditScore.getFicoScoreList());
                        Collections.reverse(ficoScoreList);
                        for (FicoScoreList listItem : ficoScoreList) {
                            if (listItem.isHasScore()) {
                                mFicoScoreListItem = listItem;
                                break;
                            }
                        }
                    }
                }
                initKeyfactorsList(mFicoScoreListItem);
                mFicoCreditScoreUI.showFicoDashboard(ficoCreditScore, mFicoScoreListItem, positiveKeyFactorList, negativeKeyFactorList);
               /* mFicoCreditScoreUI.showFicoCollapseListView(mFicoScoreListItem);*/
                /**end code optimization for CreditScore Box */

            } else {
                mFicoCreditScoreUI.showNoFicoScoreAvailableScreen();
            }
        }
    }

    /**
     * Method to initialize Positive, Negative Key-factors
     */
    private void initKeyfactorsList(FicoScoreList ficoScoreListItem) {
        if (null != ficoScoreListItem) {
            int creditScoreInt = ficoScoreListItem.getCurrentScore();
            ArrayList<Integer> keyFactorsSizeList = FicoUtils.getKeyFactorsSizeLimit(ficoScoreListItem, creditScoreInt);
            if (null != keyFactorsSizeList) {
                int posListSize = keyFactorsSizeList.get(FicoCreditScoreConstants.FicoKeyfactors.POSITIVE_KEY_INDEX);
                positiveKeyFactorList = FicoUtils.getPositiveKeyFactorsList(ficoScoreListItem, posListSize);
                int negListSize = keyFactorsSizeList.get(FicoCreditScoreConstants.FicoKeyfactors.NAGATIVE_KEY_INDEX);
                negativeKeyFactorList = FicoUtils.getNegativeKeyFactorsList(ficoScoreListItem, negListSize);
            }
        }
    }
}
