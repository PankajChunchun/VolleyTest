package com.discover.mobile.common.onboardwiz.utils;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.fragment.OnBoardPagerFragment;
import com.discover.mobile.common.onboardwiz.fragment.fingerprint.OnBoardFingerprintFragment;
import com.discover.mobile.common.onboardwiz.fragment.paperless.OnBoardPaperlessFragment;
import com.discover.mobile.common.onboardwiz.fragment.passcode.OnBoardPasscodeContainerFragment;
import com.discover.mobile.common.onboardwiz.fragment.quickview.OnBoardEnableQuickViewFragment;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.TokenUtil;
import com.discover.mobile.common.ui.modals.EnhancedContentModal;
import com.discover.mobile.common.ui.modals.SimpleTwoButtonModal;
import com.discover.mobile.network.error.bean.ErrorBean;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;

import android.app.AlertDialog;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static com.discover.mobile.common.analytics.AnalyticsPage.ONBOARDWIZ_PASSCODE_GUIDELINE_MODAL_PAGE_NAME;

/**
 * Helper to support onBoarding process execution.
 * Created by 494005 on 4/25/2016.
 */
public class OnBoardHelper {
    public static final long HOME_PAGE_ENTRY_DURATION = 600;
    public static final long ACTION_BAR_ITEMS_ANIM_OFFSET = 300;
    public static final long ACTION_BAR_ITEMS_ANIM_DURATION = 500;
    public static final String ON_BOARD_LOLLIPOP_KEY = "onBoard_lollipop";
    public static boolean mQuickvieweAnim;
    public static boolean mPaperlessAnim;
    public static boolean sOnBoardAnimation = false;
    public static boolean exitFromPasscodePage;
    static List<Fragment> vehicles = null;
    //BankOnBoardPaperlessHelper object will hold the paperless information
    private static BankOnBoardingInfo sBankOnBoardingInfo = null;
    /**
     * disposes all vehicles after use.
     */
    public static void disposeVehicles() {
        vehicles = null;
    }

    /*r
     * Returns the available vehicles/feature to display for on boarding process.
     *
     * @return
     */
    public static List<Fragment> getVehicles(boolean isFingerprintOnboardItemToShow) {

        if (vehicles == null) {
            vehicles = new ArrayList<Fragment>();
            vehicles.add(new OnBoardPasscodeContainerFragment());

            /**start US83286  - Android Fingerprint - Kill-switch */
            if (isFingerprintOnboardItemToShow)
                vehicles.add(new OnBoardFingerprintFragment());
            /**end US83286  - Android Fingerprint - Kill-switch */

            vehicles.add(new OnBoardEnableQuickViewFragment());
            //Condition to check whether all paperless is true or paperlist is empty. Both the cases we never display paperless page.
            if (!isBankAllaccountsEnroll()) {
                //Incase of banklogin Add OnBoardPaperlessFragment. This will display only to the bank user.
                vehicles.add(new OnBoardPaperlessFragment());
            }
        }
        return vehicles;
    }

    public static String toTitleCase(String input) {
        StringBuilder titleCase = new StringBuilder();
       /* String formatName = input.substring(0, 1)
                .toUpperCase((Locale.getDefault())) + input.substring(1);
        titleCase.append(" "+formatName);*/
        boolean nextTitleCase = true;

        for (char c : input.toCharArray()) {
            if (Character.isSpaceChar(c)) {
                nextTitleCase = true;
            } else if (nextTitleCase) {
                c = Character.toTitleCase(c);
                nextTitleCase = false;
            }

            titleCase.append(c);
        }
        return titleCase.toString();
    }

    /**
     * shows passcode guideline dialog
     */
    public static AlertDialog showGuidelines(Context context) {
        View v = LayoutInflater.from(context).inflate(R.layout.onboard_passcode_guidelines, null);

        //changing it to custom modal to fix a defect related to ADA - rsharm9
        final CustomModal modal = new CustomModal(context, v);
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage((R.string.bank_analytics_onboard_passcode_guide_modal));
        }
        //US53334 End
        if (Globals.isBankLoginSelected()) {
            v.findViewById(R.id.bank_additional_row).setVisibility(View.VISIBLE);
            String str = context.getString(R.string.onboard_passcode_guideline_bank_debit);
            String passcodeString = context.getString(R.string.onboard_bank_passcode_guidelines);
            TextView textView = (TextView) v.findViewById(R.id.tvCleaningFifth);
            textView.setText(str);
            TextView textView1 = (TextView) v.findViewById(R.id.tvCleaningSeventh);
            textView1.setText(passcodeString);
        }
        if (Globals.isFromCardSide()) {
            //US53328-START
            TrackingHelper.trackCardPage(ONBOARDWIZ_PASSCODE_GUIDELINE_MODAL_PAGE_NAME, null);
            //ENDS
        }
        modal.setCancelable(true);
        modal.setCanceledOnTouchOutside(true);
        modal.show();

        Button btnCLose = (Button) v.findViewById(R.id.btn_close);
        btnCLose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissGuidelineModelView(modal);
            }
        });
        return modal;
    }

    /**
     * dismisses passcode guideline dialog
     */
    public static void dismissGuidelineModelView(AlertDialog passcodeGuideLineModal) {
        if (passcodeGuideLineModal != null && passcodeGuideLineModal.isShowing()) {
            passcodeGuideLineModal.dismiss();
            passcodeGuideLineModal = null;
        }
    }

    /**
     * shows keyboard soon after fragment launche
     * NOTE : need to find out some better way. it's a temp.
     */
    public static void showKeyBoardWithDelayOnView(final View mView) {
        mView.postDelayed(new Runnable() {
            @Override
            public void run() {
                mView.requestFocus();
                mView.performClick();
                showKeyboard(mView.getContext(), mView);
            }
        }, 250);
    }


    /**
     * shows keyboard
     */
    public static void showKeyboard(Context context, View view) {
        if (context != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
//            View view = context.getWindow().getCurrentFocus();
            imm.showSoftInput(view, 0);
        }
    }

    /*
     * Method to hide keyboard
     * @param context
	 */
    public static void hideKeyboard(Context context, View view) {
        if (context != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
//            View view = context.getWindow().getCurrentFocus();
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public static boolean isPasscodeValidLocally(String passcode) {
        // i.e. 1,2,3,4
        if (isNumberSequential(0, passcode, 1)) {
            return false;
        }
        // i.e. 4,3,2,1
        if (isNumberSequential(0, passcode, -1)) {
            return false;
        }
        // i.e. 2,2,2,2
        if (isNumberSequential(0, passcode, 0)) {
            return false;
        }
        if ("6011".equals(passcode)) {
            return false;
        }
        return true;
    }

    private static boolean isNumberSequential(int position, String s, int step) {
        if (position >= s.length() - 1) {
            return true;
        }
        int n1 = Character.getNumericValue(s.charAt(position));
        int n2 = Character.getNumericValue(s.charAt(position + 1));
        if (n1 + step != n2) {
            return false;
        } else {
            return isNumberSequential(position + 1, s, step);
        }
    }

    public static String getHttpAndErrorStatus(final ErrorBean errorBean) {
        final StringBuilder errCode = new StringBuilder();
        if (errorBean != null) {
            errCode.append(errorBean.getHttpStatus());
            if (null != errorBean.getErrorResponseHolder()
                    && null != ((ErrorResponseDetails) errorBean.getErrorResponseHolder()).status)
                errCode.append(((ErrorResponseDetails) errorBean.getErrorResponseHolder()).status);

            return errCode.toString();
        } else {
            return "";
        }
    }

    public static int dpToPx(Context context, float dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int px = Math.round(dp * (displayMetrics.density));
        return px;
    }

    public static void visiblityForExitButton(FragmentActivity activity, boolean isVisible) {

        Fragment parentFragment = activity.getSupportFragmentManager().findFragmentById(R.id.contentView);

        if (getCurrentChildFragment(parentFragment) instanceof OnBoardPagerFragment) {
            ((OnBoardPagerFragment) getCurrentChildFragment(parentFragment)).controlVisibilityExitSetupLink(isVisible);
        }
    }

    public static void hideExitButton(FragmentActivity activity) {
        Fragment parentFragment = activity.getSupportFragmentManager().findFragmentById(R.id.contentView);

        if (getCurrentChildFragment(parentFragment) instanceof OnBoardPagerFragment) {
            ((OnBoardPagerFragment) getCurrentChildFragment(parentFragment)).hideExitSetupLink();
        }
    }


    public static Fragment getCurrentChildFragment(Fragment parentFragment) {
        if (parentFragment == null)
            return null;
        Fragment fragment = parentFragment.getChildFragmentManager().findFragmentById(R.id.left_frame);

        if (fragment instanceof OnBoardPagerFragment) {
            return fragment;
        }
        return null;

    }

   /* public static void hideArrowButton(FragmentActivity activity){
        Fragment fragment = activity.getSupportFragmentManager().findFragmentById(R.id.contentView);
        if (fragment instanceof OnBoardPagerFragment){
            ((OnBoardPagerFragment)fragment).hidePagerArrowButton();
        }
    }*/

   /* public static void showArrowButton(FragmentActivity activity){
        Fragment fragment = activity.getSupportFragmentManager().findFragmentById(R.id.contentView);
        if (fragment instanceof OnBoardPagerFragment){
            ((OnBoardPagerFragment)fragment).showPagerArrowButton();
        }
    }*/

    public static String getDeviceToken() {
        String str = TokenUtil.genClientBindingToken();
        return str;
    }

    /**
     * Function helps to get onboarding paperless data from the BankOnBoardPaperlessHelper object
     *
     * @return - BankOnBoardPaperlessHelper object will be return.
     */
    public static BankOnBoardingInfo getsBankOnBoardingInfo() {
        return sBankOnBoardingInfo;
    }

    /**
     * Function to store the data on OnBoardHelper BankOnBoardPaperlessHelper object
     *
     * @param bankOnBoardingInfo - set the BankOnBoardPaperlessHelper object inorder to display
     *                           paperless data on onboarding wizard
     */
    public static void setsBankOnBoardingInfo(BankOnBoardingInfo bankOnBoardingInfo) {
        OnBoardHelper.sBankOnBoardingInfo = bankOnBoardingInfo;
    }

    public static EnhancedContentModal showErrorModal(Context mContext) {
        EnhancedContentModal modal = null;
        modal = new EnhancedContentModal(mContext, R.string.E_T_UnknownHostException, R.string.E_UnknownHostException, R.string.close_text, null, null);
        modal.hideNeedHelpFooter();
        modal.setErrorIconVisibility(true);
        com.discover.mobile.common.Utils.showCustomAlert(modal);
        return modal;
    }

    /**
     * This method will iterate to list of all bank accounts and check paperless statements are
     * enabled .
     * Based on this we will load paperless page in  wizard. and we will change animation images.
     * Incase the paper list has no items we wont load paperless page in  wizard.
     *
     * @return boolean false- when all bank accounts have enabled paperless, only bank and paperless
     * list is empty.
     */
    public static boolean isBankAllaccountsEnroll() {
        //boolean to check whether need to display paperless page or not
        boolean paperlessDisplay = true;
        //Condition check to user login from either from bank or card side
        if (Globals.isBankLoginSelected()) {
            // Read paperless data from bundle
            BankOnBoardingInfo bankOnBoardingInfo = OnBoardHelper.getsBankOnBoardingInfo();

            //Condition check to verify BankOnBoardPaperlessHelper object value
            if (bankOnBoardingInfo != null) {
                if (bankOnBoardingInfo.mPaperlessAccountlist != null) {
                    //paperless count from the onboard helper paperless list
                    int paperlessCount = bankOnBoardingInfo.mPaperlessAccountlist.size();
                    if (paperlessCount != 0) {
                        for (int pcount = 0; pcount < paperlessCount; pcount++) {
                            BankOnBoardingInfo.PaperlessDetails paperlessDetails = bankOnBoardingInfo.mPaperlessAccountlist.get(pcount);
                            if (!paperlessDetails.mPaperlessState) {
                                //all the paperless accounts state is true
                                paperlessDisplay = false;
                            }
                            //clear paperlessDetails object
                            paperlessDetails = null;
                        }
                    }
                }
            }
            //clear bankOnBoardPaperlessHelper
            bankOnBoardingInfo = null;
        }
        return paperlessDisplay;
    }

    /**
     * This method will be called from exit set up on each fragments of on boarding wizard.
     * based on card or bank login it will navigate you tio there respective home pages.
     */
    public static void navigateToCardOrBankHome() {
        //Crashlytics fix #533
        if(DiscoverActivityManager.getActiveActivity() instanceof  OnBoardActivity) {
            ((OnBoardActivity) (DiscoverActivityManager.getActiveActivity())).navigateToRoot();
        }
    }

    //Function to clear all the BankOnBoardingInfo object contents
    public static void clearBankOnBoardingInfo() {
        if (sBankOnBoardingInfo != null) {
            sBankOnBoardingInfo = null;
        }
    }

    /**
     * Method to check whether to show Fingerprint onboard Item or not  based on FP Hardware & FP-
     * Kill-switch constant
     * Added for US83286  - Android Fingerprint - Kill-switch
     */
    public static boolean isFPOnboardItemToShow(Context currentActivity) {
        boolean isFingerprintOnboardItemToShow = false;
        if (null != currentActivity) {
            boolean isFPKillSwitchDisabled = FacadeFactory.getCardFacade().isKillSwitchDisabled(currentActivity.getString(R.string.fingerprint_kill_switch_constant));
            isFingerprintOnboardItemToShow = isFPKillSwitchDisabled && FingerPrintUtils.isFingerprintHardwareAvailable(currentActivity);
        }
        return isFingerprintOnboardItemToShow;
    }

    public static void showTempPasscodeModal(Context context){
        SimpleTwoButtonModal twoButtonModal;
        twoButtonModal = FacadeFactory.getCardOnBoardFacadeImpl().showTempLockModal(context);
        if(twoButtonModal!=null) {
            twoButtonModal.hideNeedHelpFooter();
            twoButtonModal.setCanceledOnTouchOutside(false);
            twoButtonModal.setCancelable(false);
            twoButtonModal.showErrorIcon();
            twoButtonModal.show();
        }
    }

}
