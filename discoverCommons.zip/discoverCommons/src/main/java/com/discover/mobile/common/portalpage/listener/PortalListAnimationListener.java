package com.discover.mobile.common.portalpage.listener;

/**
 *interface for portal animation
 */
public interface PortalListAnimationListener {

    void animateView(float delay);
    //this variable defines the duration of animation for view
    int ANIMATE_DURATION =250;
    //this variable defines the duration of animation for each child elements.
    float DELAY_DURATION = 0.25f;
}
