package com.discover.mobile.common;

/**
 * Created by pdesai2 on 7/8/2016.
 *
 * CmnEditTextType is the Context of Strategy pattern
 *      and EditTextStrategy is the interface of it.
 */

public class CmnEditTextType {
    private EditTextStrategy editTextType;                  //sets the interface

    public CmnEditTextType(EditTextStrategy editTextType){
        this.editTextType= editTextType;
    }

    //executes the strategy methods
    public String executeTextChange(String currentInput)
    {
        return editTextType.textChange(currentInput);
    }

    public String executePostTextChange(String currentInput)
    {
        return editTextType.postTextChange(currentInput);
    }

    public Boolean executeTextCheck(int length, String currentInput)
    {
        return editTextType.textCheck(length,currentInput);
    }
}

