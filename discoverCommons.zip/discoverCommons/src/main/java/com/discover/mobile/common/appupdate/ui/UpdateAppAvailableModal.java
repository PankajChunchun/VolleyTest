package com.discover.mobile.common.appupdate.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.ui.modals.ModalAlertWithTwoButtons;
import com.discover.mobile.common.ui.modals.ModalBottomTwoButtonView;
import com.discover.mobile.common.ui.modals.ModalTopView;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spanned;
import android.view.OrientationEventListener;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * A {@link com.discover.mobile.common.ui.modals.ModalAlertWithTwoButtons} class which is used to
 * show update
 * available.
 *
 * @author amahaja
 */
public class UpdateAppAvailableModal extends ModalAlertWithTwoButtons implements
        ModalTopView, ModalBottomTwoButtonView {

    private static final String PLAY_URL_PREFIX = "market://details?id=";
    private static final String PACKAGE_FOR_TABLET = "com.discoverfinancial.tablet";

    /** View of the modal */
    private View view;
    private Context mContext;

    public UpdateAppAvailableModal(final Context context) {
        super(context);
        view = getLayoutInflater().inflate(R.layout.update_app_available_modal,
                null);
        mContext = context;
    }

    /**
     * Create the modal alert and add the views to be displayed.
     *
     * @param savedInstanceState - saved state of the modal
     */
    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(view);
        setupButtons();
    }

    @Override
    public ModalTopView getTop() {
        return this;
    }

    @Override
    public ModalBottomTwoButtonView getBottom() {
        return this;
    }

    /**
     * Set the text in the title view
     *
     * @param text - String with text to be displayed as the title
     */
    @Override
    public void setTitle(final String title) {
        ((TextView) view.findViewById(R.id.app_update_modal_title_text))
                .setText(title);
    }

    /**
     * Set the text in the title view
     *
     * @param text - int with text to be displayed as the title
     */
    @Override
    public void setTitle(final int title) {
        ((TextView) view.findViewById(R.id.app_update_modal_title_text))
                .setText(title);
    }

    /**
     * Set the text in the content view
     *
     * @param content - String with text to be displayed as the message
     */
    @Override
    public void setContent(final String content) {
        ((TextView) view.findViewById(R.id.app_update_modal_sub_title))
                .setText(content);
    }

    /**
     * Set the text in the content view
     *
     * @param content - int with text to be displayed as the message
     */
    @Override
    public void setContent(final int content) {
        ((TextView) view.findViewById(R.id.app_update_modal_sub_title))
                .setText(content);
    }

    /**
     * Set the text in the content view
     *
     * @param content - int with text to be displayed as the message
     */
    public void setContent(final Spanned content) {
        ((TextView) view.findViewById(R.id.app_update_modal_sub_title))
                .setText(content);
    }

    /**
     * Set the text in the content view
     *
     * @param content - int with text to be displayed as the message
     */
    public TextView getContentView() {
        return (TextView) view.findViewById(R.id.app_update_modal_sub_title);
    }

    /**
     * @return the button on the modal
     */
    @Override
    public Button getOkButton() {
        return (Button) view.findViewById(R.id.modal_ok_button);
    }

    /**
     * Set the text in the button
     *
     * @param text - text to display
     */
    @Override
    public void setOkButtonText(final int text) {
        ((Button) view.findViewById(R.id.modal_ok_button)).setText(text);
    }

    /**
     * Set the text in the button
     *
     * @param text - text to display
     */
    public void setOkButtonText(final String text) {
        ((Button) view.findViewById(R.id.modal_ok_button)).setText(text);
    }

    /**
     * @return the button on the modal
     */
    @Override
    public Button getCancelButton() {
        return (Button) view.findViewById(R.id.modal_alert_cancel);
    }

    /**
     * Set the text in the button
     *
     * @param text - text to display
     */
    @Override
    public void setCancelButtonText(final int text) {
        ((Button) view.findViewById(R.id.modal_alert_cancel)).setText(text);
    }

    /**
     * Set the text in the button
     *
     * @param text - text to display
     */
    public void setCancelButtonText(final String text) {
        ((Button) view.findViewById(R.id.modal_alert_cancel)).setText(text);
    }

    @Override
    protected void initUI() {
    }

    /**
     * Create the orientation changed listener
     *
     * @return the orientation changed listener
     */
    @Override
    public OrientationEventListener createOrientationListener() {
        return null;
    }

    /**
     * Display the layout with the correct layout.
     */
    @Override
    public void display() {
    }

    private void setupButtons() {
        setOkButtonText(mContext.getString(R.string.update_app_lable));
        setCancelButtonText(mContext
                .getString(R.string.update_app_cancel_lable));
        getOkButton().setOnClickListener(new VersionUpdateListener());
        getCancelButton().setOnClickListener(new VersionUpdateCloseListener());
    }

    private void showAppOnMarket() {
        try {
            Intent viewIntent = new Intent("android.intent.action.VIEW",
                    Uri.parse(PLAY_URL_PREFIX + PACKAGE_FOR_TABLET));
            mContext.startActivity(viewIntent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class VersionUpdateListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            showAppOnMarket();
        }
    }

    private class VersionUpdateCloseListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            dismiss();
        }
    }
}
