/**
 * Copyright Solstice-Mobile 2013
 */
package com.discover.mobile.common.facade;

import com.discover.mobile.common.auth.KeepAlive;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.nav.NavigationItemAdapter;
import com.discover.mobile.common.shared.AccountType;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

/**
 * @author ekaram
 */
public class LogoutFacadeImpl implements LogoutFacade {
    public static final String COPY_TEXT_LABEL = "view account numbers";
    final String EMPTY_STRING = "";

    @Override
    public void logout(Activity fromActivity, ErrorHandlerUi errorUi, AccountType accountType) {
        KeepAlive.setBankAuthenticated(false);
        KeepAlive.setCardAuthenticated(false);
        //PasscodeUtils.ssouser=false;

        NavigationItemAdapter.resetInstance();
        /**
         * Code to clear the clip board for account & routing numbers
         */
        final Activity activity = DiscoverActivityManager.getActiveActivity();
        ClipboardManager clipboard = (ClipboardManager) activity.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
        // Creates a new text clip to put on the clip board
        ClipData clip = ClipData.newPlainText(COPY_TEXT_LABEL, EMPTY_STRING);
        // Set the clipboard's primary clip.
        clipboard.setPrimaryClip(clip);

        switch (accountType) {
            case CARD_ACCOUNT:
                FacadeFactory.getCardLogoutFacade().logout(fromActivity, errorUi);
                break;
            case BANK_ACCOUNT:
                FacadeFactory.getBankLogoutFacade().logout(fromActivity, errorUi);
                break;
        }
        return;

    }

}
