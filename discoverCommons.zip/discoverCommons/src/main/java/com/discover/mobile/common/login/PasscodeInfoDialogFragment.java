package com.discover.mobile.common.login;

import com.discover.mobile.common.R;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;

/**
 * A dialog fragment which can be used to show alerts into login screen. This
 * needs some enhancemnts to use this to other modules also.
 * <p/>
 * Main reason is to use {@link DialogFragment} is to persist dialog while
 * orientation change.
 *
 * @author pkuma13
 */
public class PasscodeInfoDialogFragment extends DialogFragment {

    private PasscodeInfoDialogListener mDialogListener;
    private Button mButtonOk;
    private Button mButtonCancel;
    private boolean isCancelable = false;

    public PasscodeInfoDialogFragment() {

    }

   /* public PasscodeInfoDialogFragment(PasscodeInfoDialogListener dialogListener) {
        mDialogListener = dialogListener;
    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.passcode_prelogin_modal,
                container);
        mButtonOk = (Button) view.findViewById(R.id.modal_ok_button);
        mButtonCancel = (Button) view.findViewById(R.id.modal_alert_cancel);
        mButtonCancel.setTransformationMethod(null);
        mButtonOk.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                mDialogListener.doPositiveClick();
                dismiss();
            }
        });
        mButtonCancel.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                mDialogListener.doNegativeClick();
                dismiss();
            }
        });
        getDialog().setCancelable(isCancelable);
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mDialogListener = (PasscodeInfoDialogListener) activity;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        return dialog;
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        // mDialogListener.doNegativeClick();
    }

    /**
     * Dialog listener class.
     *
     * @author pkuma13
     */
    public static interface PasscodeInfoDialogListener {
        void doPositiveClick();

        void doNegativeClick();
    }
}