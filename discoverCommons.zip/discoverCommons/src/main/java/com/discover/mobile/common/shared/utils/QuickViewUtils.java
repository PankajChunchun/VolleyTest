package com.discover.mobile.common.shared.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class QuickViewUtils {

    public static final String QUICK_PREFS_TOKEN = "token";
    public static final String QUICK_FLAG = "tokenstaus";
    private static final String TAG = "QuickViewUtils";
    private static final String QUICK_VIEW_BANK_SHARED_PREFS = "QuickViewUtils"; // Name of the file -.xml
    public static String clearQuickToken;
    public static int CURRENTDEEPLINK = -1;// 1.VIEW ACTIVIT 2.DEPOSIT A CHECK 3.LOG IN 4.MAKE A PAYMENT 5.ENABLE QUICK VIEW;
    private static Editor _quick_prefsEditor;
    private static SharedPreferences _quick_sharedPrefs;

    public QuickViewUtils(Context context) {
        _quick_sharedPrefs = context.getSharedPreferences(
                QUICK_VIEW_BANK_SHARED_PREFS, Context.MODE_PRIVATE);
        _quick_prefsEditor = _quick_sharedPrefs.edit();
    }

    public static void createQuickviewToken(Context context, String token) throws Exception {
        if (_quick_sharedPrefs.contains(QUICK_PREFS_TOKEN)) {
            // TODO can't write token when one already exists
            return;
        }
        // write token to shared preference "token"
        _quick_prefsEditor.putString(QUICK_PREFS_TOKEN,
                TokenUtil.encryptAndJsonifyToken(context, token));
        _quick_prefsEditor.commit();


    }

    public static String getClearQuickToken(Context context) throws Exception {
        if (clearQuickToken == null) {
            String tokenStr = _quick_sharedPrefs.getString(QUICK_PREFS_TOKEN,
                    null);

            clearQuickToken = TokenUtil
                    .parseAndDecryptTokenSupportClear(context, tokenStr);

        }
        System.out.println("clearQuickToken" + clearQuickToken);
        return clearQuickToken;
    }

    public static String getQuickViewToken(Context context) throws Exception {
        if (null == _quick_sharedPrefs) {
            _quick_sharedPrefs = context.getSharedPreferences(
                    QUICK_VIEW_BANK_SHARED_PREFS, Context.MODE_PRIVATE);
            _quick_prefsEditor = _quick_sharedPrefs.edit();
        }

        String tokenStr = _quick_sharedPrefs.getString(QUICK_PREFS_TOKEN, null);

        //System.out.println("getQuickViewToken() token string ::: " + tokenStr);

        return tokenStr;
    }

    public boolean doesQuickViewDeviceTokenExist() {
        return (_quick_sharedPrefs.contains(QUICK_PREFS_TOKEN));
    }

    public void identifyQuickSatus(boolean token) throws Exception {
        if (_quick_sharedPrefs.contains(QUICK_FLAG)) {
            // TODO can't write token when one already exists
            return;
        }
        // write token to shared preference "token"
        _quick_prefsEditor.putBoolean(QUICK_FLAG, token);
        _quick_prefsEditor.commit();

    }

    public void deleteQuickFlagStaus() {
        try {
            _quick_prefsEditor.putBoolean(QUICK_FLAG, false);
            _quick_prefsEditor.commit();


        } catch (Exception e) {
        }
    }

    public void deleteQuickViewToken() {
        try {
            _quick_prefsEditor.remove(QUICK_PREFS_TOKEN);
            _quick_prefsEditor.commit();
        } catch (Exception e) {
        }
    }

    public void storeQVSet(Boolean hideToggle, String token) {
        _quick_prefsEditor.putString(QUICK_PREFS_TOKEN, token);
        _quick_prefsEditor.commit();
        _quick_prefsEditor.putBoolean(QUICK_FLAG, hideToggle);
        _quick_prefsEditor.commit();
    }

}