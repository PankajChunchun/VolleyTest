package com.discover.mobile.common.ui.chipView;

public interface Chip {
    /**
     * Return the Chip text
     *
     * @return String
     */
    String getText();

    int getType();
}
