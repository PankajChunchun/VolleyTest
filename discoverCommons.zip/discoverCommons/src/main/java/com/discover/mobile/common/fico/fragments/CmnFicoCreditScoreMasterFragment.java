package com.discover.mobile.common.fico.fragments;

import com.discover.mobile.common.AlertDialogParent;
import com.discover.mobile.common.BaseMasterFragment;
import com.discover.mobile.common.R;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.bean.FicoScoreList;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreMasterFragUIInterface;
import com.discover.mobile.common.fico.presenter.FicoCreditScoreMasterFragPresenterImpl;
import com.discover.mobile.common.fico.service.FicoCreditScoreServiceClass;
import com.discover.mobile.common.fico.utils.FicoCreditScoreConstants;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.interfaces.CmnEventHandler;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.network.error.bean.ErrorBean;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by slende on 5/4/2017.
 * Its FICO credit score Master fragment for both Card & Bank
 */

public class CmnFicoCreditScoreMasterFragment extends BaseMasterFragment implements FicoCreditScoreMasterFragUIInterface {

    Context mContext;
    FicoCreditScoreMasterFragPresenterImpl masterFragPresenterImpl = null;
    CmnEventHandler cmnEventHandler = null;
    private boolean isCardEligible = true;

    public CmnFicoCreditScoreMasterFragment(boolean isCardEligible) {
        this.isCardEligible = isCardEligible;
    }
    public CmnFicoCreditScoreMasterFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View mainView = super.onCreateView(inflater, container, savedInstanceState);
        return mainView;
    }

    @Override
    public int getSectionMenuLocationName() {
        return 0;
    }

    @Override
    public int getGroupMenuLocationName() {
        return 0;
    }

    @Override
    public int getActionBarTitle() {
        return R.string.credit_scorecard_actionbar_title;
    }

    @Override
    public void init() {
        if(isCardEligible) {
            if (getChildFragmentManager().getBackStackEntryCount() > 0) {
                getChildFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            }
            callFicoScoreApiEndPoint();
        }
    }

    /**
     * Method to call FICO score API service call
     */
    public void callFicoScoreApiEndPoint() {
        if (null == masterFragPresenterImpl) {
            masterFragPresenterImpl = new FicoCreditScoreMasterFragPresenterImpl(this, new FicoCreditScoreServiceClass());
        }
        masterFragPresenterImpl.getFicoCreditScoreData();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
        if (context instanceof CmnEventHandler) {
            cmnEventHandler = (CmnEventHandler) context;
        }
    }

    @Override
    public void showSpinner() {
        PortalUtils.showSpinner(mContext);
    }

    @Override
    public void hideSpinner() {
        PortalUtils.hideSpinner(mContext);
    }

    @Override
    public void ficoScoreOnSuccess(Object data) {
        if (null != data && data instanceof FicoCreditScore) {
            FicoCreditScore ficoCreditScore = (FicoCreditScore) data;
            Collections.reverse(ficoCreditScore.getFicoScoreList());
            launchFicoLandingFragment(ficoCreditScore);
        }
    }

      @Override
    public void ficoScoreOnError(Object data) {

        if (data instanceof ErrorBean) {
            ErrorBean ficoErrorBean = (ErrorBean) data;
            String errorCode = PortalUtils.getHttpAndErrorStatus(ficoErrorBean);
            //Feature specific error handling should be done in Master Fragmenet itself
            if (Arrays.asList(FicoCreditScoreConstants.ErrorCodes.NO_FICO_SCORE).contains(errorCode)) {
                //Load landing fragment with error message
                showFicoLandingFragWithNoScore();

            }/*else if(ficoCreditScoreHostInterface.handleEvent(APIError, "4031101|||Error Message From API")){
                return;
            }*/ else{
                // Generic error handling via Facade call; USe card side generic error handling for both Card & Bank
                FacadeFactory.getPortalPageFacade().handleFICOCreditScoreAPIErrorScenarios(ficoErrorBean,this,mContext);
            }

        }
    }

    @Override
    public void launchFicoLandingFragment(FicoCreditScore ficoCreditScore) {

        boolean isNoScoreAvailable = false; // false means we have valid FICO Score data

        List<FicoScoreList> ficoScoreLists = ficoCreditScore.getFicoScoreList();
        if (ficoScoreLists != null && ficoScoreLists.size() > 0) {
            for (FicoScoreList ficoListItem:ficoScoreLists) {
                if (ficoListItem.isHasScore()) {
                    isNoScoreAvailable = false;
                    break;
                } else {
                    isNoScoreAvailable = true;
                }
            }
        } else {
            isNoScoreAvailable = true;
        }

        if (isNoScoreAvailable) {
            showFicoLandingFragWithNoScore();
        } else {
            showFicoLandingFragWithScore(ficoCreditScore);
        }
    }

    @Override
    public void showFicoLandingFragWithNoScore() {
            CmnFicoNoScoreFragment ficoLandingFragment = new CmnFicoNoScoreFragment();
            showInLeftFrame(ficoLandingFragment);

    }

    @Override
    public void showFicoLandingFragWithScore(FicoCreditScore ficoCreditScore) {
        if (null != ficoCreditScore) {
            Bundle bundle = new Bundle();
            bundle.putSerializable(FicoCreditScoreConstants.FICO_CREDIT_SCORE, ficoCreditScore);
            CmnFicoCreditScoreLandingFragment ficoLandingFragment = new CmnFicoCreditScoreLandingFragment();
            ficoLandingFragment.setArguments(bundle);
            showInLeftFrame(ficoLandingFragment);
        }
    }

    @Override
    public void handlePrivacyAndTermsClick() {
        if (null != cmnEventHandler) {
            cmnEventHandler.handleEvent(CmnEventHandler.CmnEvent.PRIVACY_AND_TERMS_CLICK_EVENT,"");
        }
    }

    @Override
    public void handleProvideFeedbackClick() {
        if (null != cmnEventHandler) {
            cmnEventHandler.handleEvent(CmnEventHandler.CmnEvent.PROVIDE_FEEDBACK_CLICK_EVENT,"score_card-pg");
        }
    }

    @Override
    public void handleFicoScoreFAQClick() {
        if (null != cmnEventHandler) {
            cmnEventHandler.handleEvent(CmnEventHandler.CmnEvent.FAQ_EVENT, FicoUtils.deepLinkFicoFaqActionCode);
        }
    }

    /*Start changes for US12232*/
    @Override
    public void handleNoScoreFicoFAQClick() {
        if (null != cmnEventHandler) {
            cmnEventHandler.handleEvent(CmnEventHandler.CmnEvent.FAQ_NO_SCORE_EVENT, FicoUtils.deepLinkNoScoreFicoFaqActionCode);
        }
    }
     /*End changes for US12232*/
}