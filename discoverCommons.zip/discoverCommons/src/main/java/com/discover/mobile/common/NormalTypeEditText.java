package com.discover.mobile.common;

/**
 * Created by pdesai2 on 7/19/2016.
 *  Implements the methods of the EditTextStrategy for normal text input
 */
public class NormalTypeEditText implements EditTextStrategy {

    //returns the proper formatted string
    @Override
    public String textChange(String currentInput) {
        return currentInput;
    }

    @Override
    public String postTextChange(String currentInput) {
        return currentInput;
    }

    //checks if the length of the string is the right amount
    @Override
    public Boolean textCheck(int length, String currentInput) {
        if (!currentInput.equals("")) {
            return true;
        }
        return false;
    }
}
