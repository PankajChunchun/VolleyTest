package com.discover.mobile.common.onboardwiz.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

/**
 * Created by 409992 on 6/16/2016.
 */
public class CustomModal extends AlertDialog {

    private final View view;

    public CustomModal(Context context, View v) {
        super(context);
        this.view = v;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(view);
    }
}
