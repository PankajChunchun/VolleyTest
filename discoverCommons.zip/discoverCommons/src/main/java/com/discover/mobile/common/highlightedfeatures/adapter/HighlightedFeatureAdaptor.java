package com.discover.mobile.common.highlightedfeatures.adapter;

import com.discover.mobile.common.highlightedfeatures.beans.FeatureContent;
import com.discover.mobile.common.highlightedfeatures.ui.HighlightedFeatureClickHandler;
import com.discover.mobile.common.highlightedfeatures.ui.HighlightedFeatureFragment;
import com.discover.mobile.common.shared.utils.image.ImageLoader;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.List;

/**
 * Common adapter for Highlighted feature and Whatsnew feature.
 */
public class HighlightedFeatureAdaptor extends FragmentStatePagerAdapter {

    List<FeatureContent> features;
    boolean isForWhatsNew = false;
    HighlightedFeatureClickHandler clickHandler;
    boolean isCardSelected;
    ImageLoader loader;
    public static final String TAG="tag";

    /**
     * Constructor for the class
     *
     * @param context - context to get resources from
     * @param fm      - fragment manager used to display the different pages
     *                <p/>
     *                The warning is suppressed because in this case the array cannot be garbage
     *                collected
     *                because the reference to the array needs to be maintained so that pages can
     *                be
     *                rendered correctly.
     */
    @SuppressLint("Recycle")
    public HighlightedFeatureAdaptor(final Context context, final FragmentManager fm, List<FeatureContent> features,
                                     final boolean isForWhatsNew, final boolean isCardSelected,
                                     HighlightedFeatureClickHandler clickHandler) {
        super(fm);
        this.isForWhatsNew = isForWhatsNew;
        this.features = features;
        this.isCardSelected = isCardSelected;
        this.loader = new ImageLoader(context);
        this.clickHandler = clickHandler;
    }

    /**
     * Get the fragment item
     *
     * @param position - position to get the item
     */
    @Override
    public Fragment getItem(final int position) {
        final Bundle bundle = new Bundle();
        int tag=position;

        FeatureContent item = features.get(position);
        bundle.putInt(TAG,position);
        bundle.putSerializable(HighlightedFeatureFragment.ITEM, item);
        bundle.putBoolean(HighlightedFeatureFragment.WHATS_NEW_TO_SHOW, isForWhatsNew);
        bundle.putBoolean(HighlightedFeatureFragment.IS_CARD_SELECTED, isCardSelected);
        final HighlightedFeatureFragment fragment = new HighlightedFeatureFragment();
        fragment.setFeatureClickHandler(this.clickHandler);
        fragment.setImgLoader(loader);
        fragment.setArguments(bundle);
        return fragment;
    }

    /**
     * Get the count of total pages in the view pager.
     *
     * @return the number of pages
     */
    @Override
    public int getCount() {
        return features.size();
    }

    @Override
    public void restoreState(Parcelable arg0, ClassLoader arg1) {
    }
}
