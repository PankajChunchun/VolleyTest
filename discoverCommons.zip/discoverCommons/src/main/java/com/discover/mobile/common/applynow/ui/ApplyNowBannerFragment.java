package com.discover.mobile.common.applynow.ui;


import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 */
public class ApplyNowBannerFragment extends Fragment {

    private final String STMT_APPLY_NOW_BANER_FIRST_TEXT = "apply_now_msg";
    private final String STMT_APPLY_NOW_BANER_SECOND_TEXT = "apply_now_learn_more";
    public ApplyNowBannerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_apply_now_banner, container, false);
        TextView applynowFirstLineText = (TextView)view.findViewById(R.id.apply_now_first_line_text);
        TextView applynowSecondLineText = (TextView)view.findViewById(R.id.apply_now_second_line_text);
        String firstLineText = InfoMessageUtils.Instance().getErrorMessage(STMT_APPLY_NOW_BANER_FIRST_TEXT);
        String secondLineText = InfoMessageUtils.Instance().getErrorMessage(STMT_APPLY_NOW_BANER_SECOND_TEXT);
        if(!TextUtils.isEmpty(firstLineText)){
            applynowFirstLineText.setText(firstLineText);
        }
        if(!TextUtils.isEmpty(secondLineText)){
            applynowSecondLineText.setText(secondLineText);
        }

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((LoginActivity)getActivity()).showApplyNowDialog();

                HashMap<String, Object> extras = new HashMap<>();
                extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.APPLY_NOW_BANNER_PAGE_PROP1);
                TrackingHelper.trackClickEvents(AnalyticsPage.APPLY_NOW_BANNER_PAGE_PEV1, null, AnalyticsPage.LINK_TYPE_O, extras);
            }
        });

        //US156994. As part of this story only once below tag should be fired ( i.e while app launch )

        if(!Globals.isAlreadyApplyNowBannerLaunched())
        {
            Globals.setAlreadyApplyNowBannerLaunched(true);
            TrackingHelper.trackCardPage(AnalyticsPage.APPLY_NOW_BANNER_PAGE_NAME, null);

        }

        return view;
    }

}
