package com.discover.mobile.common.portalpage.utils;

import com.discover.mobile.common.fico.utils.FicoUtils;
import com.google.gson.Gson;

import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.login.beans.PreAuthbean;
import com.discover.mobile.common.login.service.LoginServiceClass;
import com.discover.mobile.common.portalpage.PortalMergeInterceptActivity;
import com.discover.mobile.common.portalpage.PortalPageActivity;
import com.discover.mobile.common.portalpage.PortalPagePresenterImpl;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.beans.BankVerifyAccount;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.beans.DepositAccount;
import com.discover.mobile.common.portalpage.beans.IraPlan;
import com.discover.mobile.common.portalpage.beans.LoanAccount;
import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.service.PortalPageServiceClass;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.facade.SharedFacadeFactory;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.net.SessionTokenManager;
import com.discover.mobile.common.ui.modals.CommonTwoButtonModal;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.network.constants.RequestResponseHeaders;
import com.discover.mobile.network.error.ErrorUtilityImplCommon;
import com.discover.mobile.network.error.bean.ErrorBean;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.Surface;
import android.view.View;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import retrofit.client.Header;

/**
 * Utils class for portal page
 *
 * @author slende
 */
public class PortalUtils {
    private static final String ID_PREFIX = "%&(()!12["; //$NON-NLS-1$
    //Intentionally provided space after Bearer to avoid creation of another string object.
    private final static String authorizationBearer = "Bearer ";
    public static ProgressDialog progressBar;
    //commented out by hlin0 2015.10.06, BaseRequestInterceptor takes care of these.
    //private static DeviceIdentifiers deviceIdentifiers = null;
    public static boolean isBankLogin;

    public static String PORTAL_PG = "PORTAL_PG";
    public static String PORTAL_ACCOUNT = "PORTAL_ACCT";

    public static String CHECKING_TAG = "CHECKING";
    public static String SAVINGS_TAG = "SAVINGS";
    public static String CARD_TAG = "CARD";
    public static String CD_TAG = "CD";
    public static String MM_Tag = "MONEY_MARKET";
    public static String IRA_Tag = "IRA";
    public static String LOAN_TAG = "LOAN";
    public static boolean isDeeplinkClicked = false;
    public static boolean isPasscodeLogin;
    public static boolean isUnifiedSessionEnabled = false;
    public static boolean isBankPasscodeLogin;
    public static boolean isJointCardErrorModelShow = false;
    //This web lockout flag for US66298
    public static boolean isFromAUFlow = false;
    // 6.7 portal
    public static boolean showPortalPage = false;
    private static String fieldSep = "|";

    //Added for US38219 CLA merge intercept page
    public static String LINKTO_CLA_MERGE = "linktoclamerge";
    //Added for US38224 CLA merge skip for now modal
    public static String CLA_MERGE_SKIP_FOR_NOW_MODAL_TITLE = "cla_merge_skip_for_now_modal_title";
    public static String CLA_MERGE_SKIP_FOR_NOW_MODAL_MESSAGE = "cla_merge_skip_for_now_modal_message";
    private static boolean isFingerprintLogin = false;
    private static Set<String> sUnVerifiedAccountIds;


    /**
     * Method to fire site tags on Portal Screen load
     */
    public static void fireSiteTagsWithListOfAccounts(
            List<PortalBoxInterface> sortedPortalAccounList) {
            int count = 0;
            StringBuilder sb = new StringBuilder();

        if (null != sortedPortalAccounList) {
            StringBuffer accountStrBuffer = new StringBuffer();

            for (Iterator<PortalBoxInterface> iterator = sortedPortalAccounList
                    .iterator(); iterator.hasNext(); ) {
                PortalBoxInterface dataItem = (PortalBoxInterface) iterator
                        .next();

                if (null != dataItem) {
                    if (dataItem instanceof DepositAccount) {
                        DepositAccount depositAccount = (DepositAccount) dataItem;
                        if (!PortalUtils.isStrFieldEmpty(depositAccount
                                .getAcctType())) {
                            if (depositAccount.getAcctType().equalsIgnoreCase(
                                    "001")) {
                                accountStrBuffer.append(SAVINGS_TAG + fieldSep);
                            } else if (depositAccount.getAcctType()
                                    .equalsIgnoreCase("002")) {
                                accountStrBuffer
                                        .append(CHECKING_TAG + fieldSep);
                            } else if (depositAccount.getAcctType()
                                    .equalsIgnoreCase("003")) {
                                accountStrBuffer.append(MM_Tag + fieldSep);
                            } else if (depositAccount.getAcctType()
                                    .equalsIgnoreCase("004")) {
                                accountStrBuffer.append(CD_TAG + fieldSep);
                            }
                        }
                    } else if (dataItem instanceof CardAccount) {
                        if (((CardAccount) dataItem).getExternalStatus().equalsIgnoreCase("A")) {
                            if (count == 0) {
                                sb.append(DiscoverActivityManager.getActiveActivity().getResources().getString(R.string.fraud_portal_tile_text));
                            } else {
                                sb.append(":").append(DiscoverActivityManager.getActiveActivity().getResources().getString(R.string.fraud_portal_tile_text));
                            }
                            count++;
                        }
                        accountStrBuffer.append(CARD_TAG + fieldSep);
                    } else if (dataItem instanceof IraPlan) {
                        accountStrBuffer.append(IRA_Tag + fieldSep);
                    } else if (dataItem instanceof LoanAccount) {
                        accountStrBuffer.append(LOAN_TAG + fieldSep);
                    }
                }
            }

            HashMap<String, Object> accountListMap = new HashMap<String, Object>();
            accountListMap.put("my.prop5",
                    PORTAL_PG + "_" + accountStrBuffer.toString());
            accountListMap.put("my.eVar5",
                    PORTAL_PG + "_" + accountStrBuffer.toString());
            if (!sb.toString().equals("")) {
                accountListMap.put("my.list1", sb);
                accountListMap.put("my.prop10", sb);

            }

            TrackingHelper.trackCardPage(AnalyticsPage.PORTAL_PAGE,
                    accountListMap);
        }
    }

    public static String getMatchingTag(PortalAccountType accountType){

        String accounTypeTag = null;
        switch (accountType) {

            case ACCOUNT_CREDIT_CARD:
                accounTypeTag = CARD_TAG;
                break;

            case ACCOUNT_CHECKING:
                accounTypeTag = CHECKING_TAG;
                break;

            case ACCOUNT_SAVINGS:
                accounTypeTag = SAVINGS_TAG;
                break;

            case ACCOUNT_MONEY_MARKET:
                accounTypeTag = MM_Tag;
                break;

            case ACCOUNT_CD:
                accounTypeTag = CD_TAG;
                break;

            case ACCOUNT_IRA:
                accounTypeTag = IRA_Tag;
                break;

            case ACCOUNT_LOAN:
                accounTypeTag = LOAN_TAG;
                break;

            default:
                break;
        }

        return accounTypeTag;
    }

    /**
     * Method to fire site tag when Card/Bank account is selected by user
     */
    public static void fireSiteTagsFroAccountBoxClick(
            PortalAccountType accountType) {

        final String accounTypeTag = getMatchingTag(accountType);
        HashMap<String, Object> accountClickMap = new HashMap<String, Object>();
        accountClickMap.put("my.prop1", PORTAL_ACCOUNT + "_" + accounTypeTag);
        accountClickMap.put("my.eVar35", PORTAL_ACCOUNT + "_" + accounTypeTag);
        accountClickMap.put("pe", AnalyticsPage.PORTAL_LNK_O_PE);
        accountClickMap.put("pev1", PORTAL_ACCOUNT + "_" + accounTypeTag);
        TrackingHelper.trackCardPage(null, accountClickMap);
    }

    /**
     * This is old method to call Account service with No - Finger print option, for finger print use
     * below method with one more boolean as parameter
     */
    public static void getPortalAccountDetails(Context context,
                                               String username, String password, NetworkRequestListener nrl,
                                               boolean isPasscodeLogin) {
        PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(
                context);
        setPasscodeLogin(isPasscodeLogin);
        portalPageServiceClass.fetchPortalAccountDetails(username, password,
                nrl, isPasscodeLogin, false); // With this method parameter - "isFingerPrintLogin" is always false - Added for 7.10 finger print release
        // Set passcodelogin status
        setPasscodeLogin(isPasscodeLogin);

        setFingerprintLogin(false);
    }

    /**
     * Method added for Finger print log in with extra boolean as parameter
     * Added for 7.10 finger print release
     */
    public static void getPortalAccountDetails(Context context,
                                               String username, String password, NetworkRequestListener nrl,
                                               boolean isPasscodeLogin, boolean isFingerPrintLogin) {
        PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(
                context);
        setPasscodeLogin(isPasscodeLogin);
        portalPageServiceClass.fetchPortalAccountDetails(username, password,
                nrl, isPasscodeLogin, isFingerPrintLogin);
        // Set passcodelogin status
        setPasscodeLogin(isPasscodeLogin);

        setFingerprintLogin(isFingerPrintLogin);
    }

    /**
     * This method is fetch whole accounts details with request header
     * X-Override-UID for second time login attempt, after eds-key based refresh this method is
     * used
     * by Bank side only
     */
    public static void updatePortalAccountDetails(final Context context,
                                                  final NetworkRequestListener ntwEventListener,
                                                  final String strTitle, final String strMessage) {
        PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(
                context);
        portalPageServiceClass.updatePortalAccountDetails(context,
                ntwEventListener, strTitle, strMessage);
    }

    /**
     * Method to refresh selected card account based on eds-key, card side only
     *
     * @param selectedCardEdsKey Added for US48093 changes
     */
    public static void refreshCardAccountDetails(final Context context,
                                                 final NetworkRequestListener ntwEventListener,
                                                 final String strTitle, final String strMessage, final String selectedCardEdsKey) {

        PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(
                context);
        portalPageServiceClass.refreshCardAccountDetails(context,
                ntwEventListener, strTitle, strMessage, selectedCardEdsKey);

    }

    /**
     * Method to return Base URL
     */
    public static String getBaseUrl() {
        return FacadeFactory.getCardFacade().getCardBaseUrl();
    }

    /**
     * get the Authorization string for the given username and password
     *
     * @return Authorization string
     */
    public static String getAuthorizationString(final String username,
                                                final String password) {
        if (Globals.isBankLoginSelected) {
            isBankLogin = false;
            String concatenatedBankCreds = "DCRDSSO " + username + ": :"
                    + password;
            return concatenatedBankCreds;
        } else {
            String concatenatedCardCreds = username + ": :" + password;
            return "DCRDBasic "
                    + Base64.encodeToString(concatenatedCardCreds.getBytes(),
                    Base64.NO_WRAP);
        }
    }

    /**
     * Creates the authorization string (used in Authorization header) using the
     * passcode scheme and device token and passcode as credentials.
     *
     * @param passcode Authorization string
     */
    public static String getPasscodeAuthorizationString(
            final String deviceToken, final String passcode) {
        final String concatenatedCreds = deviceToken + ": :" + passcode;
        return "DCRDPasscode "
                + Base64.encodeToString(concatenatedCreds.getBytes(),
                Base64.NO_WRAP);
    }

    public static String getAuthorization_TestingString(final String password) {
        final String cred_one = "mstoira125" + ": :" + password;
        final String encrypted1 = "DCRDBasic "
                + Base64.encodeToString(cred_one.getBytes(), Base64.NO_WRAP);
        final String cred_two = "mobdpl32" + ": :" + password;
        final String encrypted2 = "DCRDBasic "
                + Base64.encodeToString(cred_two.getBytes(), Base64.NO_WRAP);
        final String cred_three = "bankmst000" + ": :" + password;
        final String encrypted3 = "DCRDBasic "
                + Base64.encodeToString(cred_three.getBytes(), Base64.NO_WRAP);
        final String concatenatedString = encrypted1 + ":" + encrypted2 + ":"
                + encrypted3;
        return concatenatedString;

    }

    public static void navToPortalActivity() {

        // backlog US59072 fix start adeshm2
        Globals.setLoggedIn(true);
        // backlog US59072 fix end adeshm2

        Activity activity = DiscoverActivityManager.getActiveActivity();
        Intent intent = new Intent(activity, PortalPageActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        //intent.putExtra("navigationtype", "OnMenuClick"); //to-do
        activity.startActivity(intent);
        // 204798 Fix for second time crash in portal activity - Portal page finishing BankNavigationRootActivity
        FacadeFactory.getPortalPageBankFacade().finishBankNavigationRootActivity();
        //	Globals.setCLAuser(true);//us20958 - nkaza
    }

    public static boolean isStrFieldEmpty(String inputStr) {
        if (inputStr != null && !inputStr.trim().equals("")) {
            return false;
        }
        return true;
    }

    public static String getAmountInFormmated(String source) {
        if (!isStrFieldEmpty(source)) {

            DecimalFormat numberFormatter = new DecimalFormat("#,###.##");
            numberFormatter.setMinimumFractionDigits(2);
            if (source.contains("$")) {
                source = source.replace("$", "");
            }
            if (source.contains(",")) {
                source = source.replace(",", "");
            }
            source = numberFormatter.format(Double.parseDouble(source));
            source = "$" + source;
        } else {
            source = "--";
        }

        return source;
    }

    public static String getMilesBalanceFormmated(String source) {
        if (!isStrFieldEmpty(source)) {

            DecimalFormat numberFormatter = new DecimalFormat("#,###.##");
            if (source.contains("$")) {
                source = source.replace("$", "");
            }
            if (source.contains(",")) {
                source = source.replace(",", "");
            }
            source = numberFormatter.format(Double.parseDouble(source));

        } else {
            source = "--";
        }

        return source;
    }

    public static void hideSpinner(Context mContext) {

        if (null != progressBar) {

            if (progressBar.isShowing()) {
                try {
                    progressBar.dismiss();
                    // mgupta4 : Orientation is realeased when progress bar will
                    // be shown on screen
                    if (!isRunningOnHandset(mContext)) {
                        if (mContext != null && mContext instanceof Activity && !Utils.isRunningOnHandset(mContext)) {
                            ((Activity) mContext)
                                    .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
                        }
                    }
                } catch (Exception e) {
                }
            }

            progressBar = null;

        }
    }

    /**
     * This method show the progress dialog
     *
     * @param context    Activity Context
     * @param strTitle   Progress Dialog Title
     * @param strMessage Progress Dialog Message
     */
    public static void showSpinner(Context mContext) {
        if (mContext != null) {
            showSpinner(
                    mContext,
                    mContext.getResources().getString(
                            R.string.cd_default_dialogtitle),
                    mContext.getResources().getString(
                            R.string.cd_default_dialogmessage));
        }
    }

    public static boolean isRunningOnHandset(Context context) {
        boolean isHandset = (context.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK)
                < Configuration.SCREENLAYOUT_SIZE_LARGE;
        return isHandset;
    }

    /**
     * This method show the progress dialog
     *
     * @param context    Activity Context
     * @param strTitle   Progress Dialog Title
     * @param strMessage Progress Dialog Message
     */


    public static void showSpinner(Context context, final String strTitle,
                                   final String strMessage) {
        context = DiscoverActivityManager.getActiveActivity();
        if (context == null) {
            return;
        }
        if (null == progressBar && !((Activity)context).isFinishing()) {
            progressBar = new ProgressDialog(context);
            progressBar.setMessage(strMessage);
            progressBar.setTitle(strTitle);
            progressBar.setCancelable(false);
            progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            // mgupta4 : Orientation is locked when progress bar will be shown
            // on screen

            if (!isRunningOnHandset(context)) {
                if (context instanceof Activity) {
                    ((Activity) context).setRequestedOrientation(getScreenOrientation((Activity) context));
                }
            }
            progressBar.show();
        }

    }

    public static int getScreenOrientation(final Activity activity) {
        final int rotation = activity.getWindowManager().getDefaultDisplay()
                .getRotation();
        final int orientation = activity.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (rotation == Surface.ROTATION_0
                    || rotation == Surface.ROTATION_270) {
                return ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
            } else {
                return ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
            }
        } else if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (rotation == Surface.ROTATION_0
                    || rotation == Surface.ROTATION_90) {
                return ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
            } else {
                return ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
            }
        } else {
            return ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
        }
    }

    //commented out by hlin0 2015.10.06, BaseRequestInterceptor takes care of these.
//	private static class DeviceIdentifiers {
//		String did;
//		String sid;
//		String oid;
//	}

    //commented out by hlin0 2015.10.06, BaseRequestInterceptor takes care of these.
//	private static void setupDeviceIdentifiers(final Context context) {
//		deviceIdentifiers = new DeviceIdentifiers() {
//			{
//				final TelephonyManager telephonyManager = (TelephonyManager) context
//						.getSystemService(Context.TELEPHONY_SERVICE);
//				did = DeviceUtils.getDeviceId(context);
//				sid = telephonyManager.getSimSerialNumber();
//				if (null == sid) {
//					sid = "null";
//				}
//				if (null == did) {
//					did = "null";
//				}
//
//				oid = Secure.getString(context.getContentResolver(),
//						Secure.ANDROID_ID); // Will
//				// be
//				// same
//				// as
//				// phonegap
//			}
//		};
//	}

    private static String convertToHex(final byte[] data) {
        return String.format("%0" + data.length * 2 + 'x', new BigInteger(1,
                data));
    }

    public static String getSha256Hash(final String toHash)
            throws NoSuchAlgorithmException {
        final String safeToHash = toHash == null ? ID_PREFIX : ID_PREFIX
                + toHash;

        final MessageDigest digester = MessageDigest.getInstance("SHA-256");
        final byte[] preHash = safeToHash.getBytes();
        // specifying charset

        // Reset happens automatically after digester.digest() but we don't know
        // its state beforehand so call reset()
        digester.reset();
        final byte[] postHash = digester.digest(preHash);

        return convertToHex(postHash);
    }

    //commented out by hlin0 2015.10.06, BaseRequestInterceptor takes care of these.
//	public static String getIDs(String id, Context context) {
//		String idHeader = "";
//		if (PortalUtils.deviceIdentifiers == null) {
//			setupDeviceIdentifiers(context);
//		}
//		if (deviceIdentifiers != null) {
//			try {
//				if (id.equalsIgnoreCase(RequestResponseHeaders.DID)) {
//					idHeader = getSha256Hash(deviceIdentifiers.did);
//				} else if (id.equalsIgnoreCase(RequestResponseHeaders.SID)) {
//					idHeader = getSha256Hash(deviceIdentifiers.sid);
//				} else if (id.equalsIgnoreCase(RequestResponseHeaders.OID)) {
//					idHeader = getSha256Hash(deviceIdentifiers.oid);
//				}
//			} catch (NoSuchAlgorithmException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		return idHeader;
//	}

    public static int countofCardandBankAccounts(AccountV2Details acntv2) {
        int cardAndBankCount = 0;
        if (((acntv2.getDepositAccountsMap() != null && acntv2
                .getDepositAccountsMap().size() > 0)
                || (acntv2.getIraPlansMap() != null && acntv2.getIraPlansMap()
                .size() > 0) || (acntv2.getLoanAccountsMap() != null && acntv2
                .getLoanAccountsMap().size() > 0))) {
            cardAndBankCount = 1;
        }

        if ((acntv2.getCardAccountsMap() != null && acntv2.getCardAccountsMap()
                .size() > 0)) {
            if (cardAndBankCount == 1) {
                cardAndBankCount = 2;
            } else {
                cardAndBankCount = 3;
            }
        }
        return cardAndBankCount;
    }

    public static String setUserNickName(AccountV2Details accountdetails) {
        String name = null;

        if (accountdetails != null) {
            if (accountdetails.getDepositAccountsMap() != null
                    && accountdetails.getDepositAccountsMap().size() > 0) {
                Integer key = (Integer) accountdetails.getDepositAccountsMap()
                        .keySet().toArray()[0];
                name = accountdetails.getDepositAccountsMapOnIndex(key)
                        .getAcctNickName();

            } else if (accountdetails.getIraPlansMap() != null
                    && accountdetails.getIraPlansMap().size() > 0) {
                Integer key = (Integer) accountdetails.getDepositAccountsMap()
                        .keySet().toArray()[0];
                name = accountdetails.getIraPlansMap().get(key)
                        .getAcctNickName();
            } else if (accountdetails.getCardAccountsMap() != null
                    && accountdetails.getCardAccountsMap().size() > 0) {
                final StringBuilder namefromcard = new StringBuilder();
                String key = (String) accountdetails.getCardAccountsMap()
                        .keySet().toArray()[0];
                if (accountdetails.getCardAccountsMap().get(key)
                        .getMailingAddress() != null
                        && accountdetails.getCardAccountsMap().get(key)
                        .getMailingAddress().getFirstName() != null) {
                    String lowerCaseName = accountdetails.getCardAccountsMap()
                            .get(key).getMailingAddress().getFirstName()
                            .toLowerCase(Locale.getDefault());
                    String formatName = lowerCaseName.substring(0, 1)
                            .toUpperCase(Locale.getDefault())
                            + lowerCaseName.substring(1);
                    namefromcard.append("" + formatName);
                } else {

                    if (null != accountdetails.getCardAccountsMap().get(key)
                            .getPrimaryCardmember()) {
                        if (null != accountdetails.getCardAccountsMap()
                                .get(key).getPrimaryCardmember()
                                .getNameOnCard()) {
                            String lowerCaseName = accountdetails
                                    .getCardAccountsMap().get(key)
                                    .getPrimaryCardmember().getNameOnCard()
                                    .toLowerCase(Locale.getDefault());
                            String formatName = lowerCaseName.substring(0, 1)
                                    .toUpperCase(Locale.getDefault())
                                    + lowerCaseName.substring(1);
                            namefromcard.append(formatName);

                        }
                    }
                }
                name = namefromcard.toString();
            } else {
                name = "";
            }
        } else {
            name = "";
        }

        return name;

    }

    public static String getAPYInFormmated(String source) {
        if (!isStrFieldEmpty(source)) {
            DecimalFormat numberFormatter = new DecimalFormat("##.##");
            numberFormatter.setMinimumFractionDigits(2);

            if (source.contains("%"))
                source = source.replace("%", "");

            source = numberFormatter.format(Double.parseDouble(source));
        }
        source = source + "%";
        return source;
    }

    public static void bankSSOlogin(final Context context, String tokenValue,
                                    String hashedTokenValue) {

        NetworkRequestListener netReqListener = new NetworkRequestListener() {

            @Override
            public void onSuccess(Object data) {
                if (null != data) {
                    AccountV2Details accountDetailsFromCache = PortalCacheDataUtils
                            .getPortalCacheDataUtilsInstance()
                            .getAccountV2Details();
                    Globals.setSSOUser(accountDetailsFromCache.isSSOUser());
                    // US45209 Changes Starts
                    Activity activity = DiscoverActivityManager.getActiveActivity();

                    //-ma whats new bank flow
//                    if (HFUtils.shouldShowSSOWhatsNew(activity)) {
//                        HFUtils.showSSOWhatsNew(activity);
//                    } else {
//                        PortalUtils.navToPortalActivity();
//                    }

                    FacadeFactory.getBankLoginFacade().initiateBankflow();

                    // US45209 Changes ends
                }
            }

            @Override
            public void onError(Object data) {
                FacadeFactory.getPortalPageFacade().handleErrorScenario(
                        context, data);
            }
        };

        isBankLogin = true;
        PortalUtils.getPortalAccountDetails(context, tokenValue,
                hashedTokenValue, netReqListener, false);

    }

    /**
     * Function to refresh the bank payload
     */

    public static void getRefreshBankPayload(Context context) {

        if (SessionTokenManager.getToken() != null && !Globals.isForgotPasswordFlow()) { //For unified call customer summary and show home page every time

            if (isUnifiedSessionEnabled) {
                FacadeFactory.getBankLoginFacade().initiateBankflow();
                return;
            }
        }


        if (Globals.isBankLoginSelected && !isBankLogin) { //For Bank only:  customer has logged in from bank and coming from whats new //No need to call summary again
            FacadeFactory.getBankLoginFacade().navigateToBankHomePage();

        } else

        {
            //Legacy flow : from card tab  login > user comes to portal page and clicks on bank box/link.
            // create bank token from cardplayload and call oob>summary>home
            PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(context);
            portalPageServiceClass.getRefreshBankPayload();
        }

    }


    public static void getRefreshBankPayloadOLd(Context context) {

        if (SessionTokenManager.getToken() != null && !Globals.isForgotPasswordFlow()) {
            //For unified call customer summary and show home page every time
            if (isUnifiedSessionEnabled) {
                FacadeFactory.getBankLoginFacade().initiateBankflow();
            } else {
                //For pre unified : customer has logged in from bank and then go back to portal
                //call summary again
                PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(
                        context);
                portalPageServiceClass.getRefreshBankPayload();

            }
        } else {
            //Legacy flow : after login user comes to portal page and clicks on bank box/link.
            // create bank token from cardplayload and call oob>summary>home
            PortalPageServiceClass portalPageServiceClass = new PortalPageServiceClass(
                    context);
            portalPageServiceClass.getRefreshBankPayload();
        }
    }

    public static final boolean isPasscodeLogin() {
        return isPasscodeLogin;
    }

    public static final void setPasscodeLogin(boolean isPasscodeLogin) {
        PortalUtils.isPasscodeLogin = isPasscodeLogin;
    }


    /**
     * Added for US71614.
     * set status if we are authenticating via fingerprint.
     * @param isFingerprintLogin
     */
    public static final void setFingerprintLogin(boolean isFingerprintLogin) {
        PortalUtils.isFingerprintLogin = isFingerprintLogin;
    }

    /**
     * Added for US71614.
     * Check If fingerprint login.
     * @return
     */
    public static final boolean isFingerprintLogin() {
        return isFingerprintLogin;
    }


    /**
     * @param headers
     */
    public static void storeUnifiedTokenHeader(List<Header> headers, Context context) {
        if (headers != null) {
            final Iterator<Header> iterator = headers.iterator();
            while (iterator.hasNext()) {
                Header header = iterator.next();
                if (header.getName().equalsIgnoreCase(RequestResponseHeaders.XUsessTok)) {
                    //Store the unified token value in the common cache accessible by both card and bank.
                    SessionTokenManager.setToken(authorizationBearer + header.getValue());
                    PortalUtils.isUnifiedSessionEnabled = true;

                    PortalUtils.showTempToast("Unified session token received from server:: ", context);
                    break;
                }
            }
        }
    }

    public static void showTempToast(String message, Context context) {
        //Temporarily added toast. We have to remove.
        //	Toast.makeText(context, message+SessionTokenManager.getToken(),Toast.LENGTH_LONG).show();
    }

    /**
     * Resetting all unified flags to default values.
     * Added for few edge cases like if user did not complete any flow like login/forgot
     * passwrod/oob step1 step 2
     */
    public static void resetUnifiedFlags() {
        PortalUtils.isUnifiedSessionEnabled = false;
        PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setPortalPageShown(false);
        SessionTokenManager.clearToken();
    }


    /** Changes by asaraf2 for US50831 , to show joint card error model */
    public static void showJointCardAccountModal(final Context context) {

        final Runnable goToPortalPageRequestRunnable = new Runnable() {
            @Override
            public void run() {
                // V3 account call at this point or go to portal page
                PortalUtils.isJointCardErrorModelShow = false;
                // Toast.makeText(context,"Go to portal page",Toast.LENGTH_SHORT).show();

                NetworkRequestListener networkRequestListener = null;
                networkRequestListener = new NetworkRequestListener() {
                    @Override
                    public void onSuccess(Object data) {
                        PortalUtils.navToPortalActivity();
                    }

                    @Override
                    public void onError(Object data) {
                        FacadeFactory.getPortalPageFacade().handleErrorScenario(
                                context, data);
                    }
                };
                updatePortalAccountDetails(DiscoverActivityManager.getActiveActivity(), networkRequestListener, "Discover", "Loading...");

            }
        };
        Runnable registerJointAccountRequestRunnable = new Runnable() {
            @Override
            public void run() {
                // navigate to register flow
                /**start fix for defect# 240408 */
                if (context instanceof Activity)
                    FacadeFactory.getCardLogoutFacade().logout((Activity) context, true);
                /**end fix for defect# 240408 */
            }
        };
        Runnable backButtonRequestRunnable = new Runnable() {
            @Override
            public void run() {
                // V3 account call at this point or go to portal page
                PortalUtils.isJointCardErrorModelShow = false;
                goToPortalPageRequestRunnable.run();

            }
        };
        //Getting the error messages from infomessageutils
        String jointCardRegistrationTitle = InfoMessageUtils.Instance().getErrorMessage(PortalConstants.Misc.JOINT_CARD_REGISTRATION_TITLE);
        String jointCardRegistrationMessage = InfoMessageUtils.Instance().getErrorMessage(PortalConstants.Misc.JOINT_CARD_REGISTRATION_MESSAGE);
        if (null == jointCardRegistrationTitle || null == jointCardRegistrationMessage) {
            jointCardRegistrationTitle = String.valueOf(context.getResources().getString(R.string.joint_card_title));
            jointCardRegistrationMessage = String.valueOf(context.getResources().getString(R.string.joint_card_message));
        }
        //Calling the joint card error model here
        showJointCardAccountErrorModal(context, goToPortalPageRequestRunnable, registerJointAccountRequestRunnable, backButtonRequestRunnable, jointCardRegistrationTitle, jointCardRegistrationMessage);
    }

    /**
     * Method to show joint card account error modal
     * //US50831 & US50833 - joint card account error modal implemented.
     * By asaraf2
     */
    public static void showJointCardAccountErrorModal(Context context, Runnable goToPortalPageRequestRunnable, Runnable registerJointAccountRequestRunnable, Runnable backButtonRequestRunnable,
                                                      String jointCardRegistrationTitle, String jointCardRegistrationMessage) {

        CommonTwoButtonModal jointCardModel;
        jointCardModel = new CommonTwoButtonModal(context,
                jointCardRegistrationTitle,
                jointCardRegistrationMessage,
                R.string.joint_card_registration_button_text,
                R.string.joint_card_go_to_portal_button_text,
                registerJointAccountRequestRunnable, goToPortalPageRequestRunnable,
                backButtonRequestRunnable);
        jointCardModel.hideNeedHelpFooter();
        jointCardModel.show();
    }
    // end changes by asaraf2


    public static String getHttpAndErrorStatus(final ErrorBean errorBean) {
        final StringBuilder errCode = new StringBuilder();
        if (errorBean != null) {
            errCode.append(errorBean.getHttpStatus());
            if (null != errorBean.getErrorResponseHolder()
                    && null != ((ErrorResponseDetails) errorBean.getErrorResponseHolder()).status)
                errCode.append(((ErrorResponseDetails) errorBean.getErrorResponseHolder()).status);

            return errCode.toString();
        } else {
            return "";
        }
    }

    public static void getVersionInfo(List<Header> headers, Context context, PreAuthbean preAuthbean) {

        if (headers != null) {
            final Iterator<retrofit.client.Header> iterator = headers.iterator();
            while (iterator.hasNext()) {
                retrofit.client.Header header = iterator.next();
                if (header.getName().equalsIgnoreCase(LoginServiceClass.VERSION_INFO)) {
                    preAuthbean.setVersionInfo(header.getValue());
                    break;
                }
            }

        }
    }

    /**
     * Added for US38219 CLA merge intercept page
     */
    public static boolean isDeepLink() {

        boolean isDeepLink = FacadeFactory.getWDAFacade().isDeepLink(DiscoverActivityManager.getActiveActivity(), null);

        return isDeepLink;
    }

    /**
     * Added for US38219 CLA merge intercept page
     */
    public static boolean isPushDeepLink(Context context) {
        //Deep link for a single card and sso user. - US28600
        SharedPreferences pushSharedPrefs = context.getSharedPreferences(PortalConstants.Misc.PUSH_PREF, Context.MODE_PRIVATE);
        boolean isPushDeepLink = pushSharedPrefs.getBoolean(PortalConstants.Misc.PUSH_OFFLINE, false);

        return isPushDeepLink;
    }

    /**
     * Method to navigate to Portal Merge Intercept page
     * Added for US38219 CLA merge intercept page
     */
    public static void navToPortalMergeInterceptPage(String customerFirstName, boolean isForceMerge, boolean isInitialSkipAttempt) {
        Activity activity = DiscoverActivityManager.getActiveActivity();
        Intent intent = new Intent(activity, PortalMergeInterceptActivity.class);
        Bundle mergeDataBundle = new Bundle();
        mergeDataBundle.putString(PortalConstants.Misc.CLA_MERGE_CUSTOMER_FIRSTNAME, customerFirstName);
        mergeDataBundle.putBoolean(PortalConstants.Misc.CLA_MERGE_ISFORCEMERGE, isForceMerge);
        // US126324 Changes - start
        // Sending status of "initial skip attempt" to activity
        mergeDataBundle.putBoolean(PortalConstants.Misc.CLA_MERGE_ISINITIAL_SKIPATTEMPT, isInitialSkipAttempt);
        // US126324 Changes - end
        intent.putExtras(mergeDataBundle);
        activity.startActivity(intent);
    }

    /**
     * Method to show web lockout modal by asaraf2 for US66928
     */
    public static void showWebLockoutModal(final Context context) {
        String defualtErrorMessage = context.getResources().getString(R.string.default_msg);
        String defaultErrorTitle = context.getResources().getString(R.string.default_title);
        ErrorUtilityImplCommon errUtilImpl = ErrorUtilityImplCommon.getInstance();
        String errorMessage = errUtilImpl.getMessageforErrorCode(context, String.valueOf(PortalConstants.Error.WEB_LOCKOUT_ERROR_CODE));
        String errorTitle = errUtilImpl.getTitleforErrorCode(context, String.valueOf(PortalConstants.Error.WEB_LOCKOUT_ERROR_CODE));
        if (null != errorTitle && !errorTitle.isEmpty() && !errorTitle.equalsIgnoreCase(defaultErrorTitle) && null != errorMessage && !errorMessage.isEmpty() && !errorMessage.equalsIgnoreCase(defualtErrorMessage)) {
            createWebLockoutModel(context, errorTitle, errorMessage);
        } else {
            errorTitle = context.getString(R.string.E_T_4012127);
            errorMessage = context.getString(R.string.E_4012127);
            createWebLockoutModel(context, errorTitle, errorMessage);
        }
    }

    /** Creating the web lockout model for US66298 */
    public static void createWebLockoutModel(final Context context, String errorTitle, String errorMessage) {
        {

            final DiscoverAlertDialog showWebLockoutModalDialog = new DiscoverAlertDialog().
                    setTitle(errorTitle).
                    setMessage(errorMessage).
                    setPositiveButton(context.getString(R.string.web_lockout_model_close_btn), new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //This flag is true when user coming from AU Flow and OOB step
                            if (PortalUtils.isFromAUFlow) {
                                PortalUtils.isFromAUFlow = false;
                                FacadeFactory.getCardLogoutFacade().logout((Activity) context, false, false);
                            }

                        }
                    }).setCanCancelable(true).
                    show((AppCompatActivity) context);

            showWebLockoutModalDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
                @Override
                public boolean onKey(android.content.DialogInterface dialog, int keyCode, android.view.KeyEvent event) {
                    showWebLockoutModalDialog.getDialog().dismiss();

                    if ((keyCode == android.view.KeyEvent.KEYCODE_BACK)) {
                        //This flag is true when user coming from AU Flow and OOB step
                        if (PortalUtils.isFromAUFlow) {
                            PortalUtils.isFromAUFlow = false;
                            FacadeFactory.getCardLogoutFacade().logout((Activity) context, false, false);
                        }
                        return true;
                    } else
                        return false;
                }
            });
        }
    }


    /**
     * Added to store the state of the Fraud dialog - it has to be shown only once in a log-in
     * session
     */
    public static boolean isFraudDialogShown(Context context,String last4AccNum) {

        if (null == SharedFacadeFactory.getCardShareDataStoreFacade().getValueOfAppCache(PortalConstants.Misc.FRAUD_DIALOG_STATUS+ last4AccNum, context))
            return false;
        return (boolean) SharedFacadeFactory.getCardShareDataStoreFacade().getValueOfAppCache(PortalConstants.Misc.FRAUD_DIALOG_STATUS + last4AccNum, context);
    }

    /**
     * Sets the Fraud Alert flag status - true in PortalPageActivity and false while the
     * application
     * is logging out
     */
    public static void setFraudDialogShown(Context context, boolean status, String last4AccNum) {
        SharedFacadeFactory.getCardShareDataStoreFacade().storeToAppCache(context, status, PortalConstants.Misc.FRAUD_DIALOG_STATUS + last4AccNum);
      /*  SharedPreferences fraudPref = context.getSharedPreferences(PortalConstants.Misc.FRAUD_DIALOG_PREF, Context.MODE_PRIVATE);
        fraudPref.edit().putBoolean(PortalConstants.Misc.FRAUD_DIALOG_STATUS, status).commit();*/
    }

    /**
     * Return Portal list Order in String format
     * @param sortedPortalList
     * @return
     */
    public static String getOrderInString(List<PortalBoxInterface> sortedPortalList){

        final List sortedIDList = new ArrayList();
        for (PortalBoxInterface portalBox : sortedPortalList) {
            if(portalBox != null) {
                final String sortId = portalBox.getSortId();
                if (sortId != null && !(sortId.equalsIgnoreCase(PortalConstants.CARD_ERROR_BOX_ID) || sortId.equalsIgnoreCase(PortalConstants.BANK_ERROR_BOX_ID))) {
                    sortedIDList.add(sortId);
                }
            }
        }
        String orderedIDList = convertToString(sortedIDList);
        return  orderedIDList;
    }


    public static String convertToString(List list){
        final Gson gSon = new Gson();
        final String result = gSon.toJson(list);
        return  result;
    }

     /**
     * Sort the BAU Portal list as per the saved Custom order
     * @param portalList
     * @param savedPortalListOrder
     * @return
     */
    public static List<PortalBoxInterface> getSortedPortalList(Map<String, PortalBoxInterface> portalAccountMap, String savedPortalListOrder, PortalPagePresenterImpl.PortlistUpdateListener portlistUpdateListener) {

        List<PortalBoxInterface> tempList = new ArrayList();
        final String customOrder = savedPortalListOrder;
        final Map<String, PortalBoxInterface> map = portalAccountMap;

        if(customOrder != null && !customOrder.isEmpty()) {
            final Gson gson = new Gson();
            final List<String> orderList = gson.fromJson(customOrder, ArrayList.class);

                addErrorAccounts(map, tempList);
                sUnVerifiedAccountIds = addUnVerifiedAccounts(map, tempList);
                addNewAccounts(map, tempList, orderList);

                for (String sortId :  orderList) {
                    if(map.containsKey(sortId)) {
                        tempList.add( map.get(sortId));
                    }

                }
            return  tempList;
        }
        return  new ArrayList<>(map.values());
    }

    private static void addErrorAccounts(Map<String, PortalBoxInterface> portalAccountMap, List<PortalBoxInterface> list){

        //Adding Card Error Accounts
        PortalBoxInterface cardErrorAccount = portalAccountMap.get(PortalConstants.CARD_ERROR_BOX_ID);
        if(cardErrorAccount != null) {
            list.add(cardErrorAccount);
            portalAccountMap.remove(PortalConstants.CARD_ERROR_BOX_ID);
        }

        //Adding Bank Error Accounts
        PortalBoxInterface bankErrorAccount = portalAccountMap.get(PortalConstants.BANK_ERROR_BOX_ID);
        if(bankErrorAccount != null) {
            list.add(bankErrorAccount);
            portalAccountMap.remove(PortalConstants.BANK_ERROR_BOX_ID);
        }

    }

    private static Set<String> addUnVerifiedAccounts(Map<String, PortalBoxInterface> portalAccountMap, List<PortalBoxInterface> list){

        final Iterator iterator = portalAccountMap.entrySet().iterator();
        final Set<String> entriesToBeRemoved = new HashSet<>();
        while (iterator.hasNext()){
            final Map.Entry pair = (Map.Entry)iterator.next();
            final PortalBoxInterface unVerifiedAccount = portalAccountMap.get(pair.getKey());
            if(isUnverifiedAccount(unVerifiedAccount)){
                list.add(unVerifiedAccount);
                iterator.remove();
                entriesToBeRemoved.add((String) pair.getKey());
            }
        }

        return entriesToBeRemoved;

    }

    private static void addNewAccounts(Map<String, PortalBoxInterface> portalAccountMap, List<PortalBoxInterface> list, List<String> orderList){

        final Iterator iterator = portalAccountMap.entrySet().iterator();
        while (iterator.hasNext()){
            Map.Entry pair = (Map.Entry)iterator.next();
            boolean isNewAccountAdded = false;
            final String key = (String) pair.getKey();
            for (String sortId : orderList) {
                final PortalBoxInterface value = (PortalBoxInterface) pair.getValue();
                if(!key.equalsIgnoreCase(sortId) && !isUnverifiedAccount(value) && !isErrorAccount(value) && (sUnVerifiedAccountIds != null && sUnVerifiedAccountIds.size() > 0 && sUnVerifiedAccountIds.contains(key))){
                    //its a new account
                    isNewAccountAdded = true;
                }
                else {
                    isNewAccountAdded = false;
                    break;
                }
            }
            if(isNewAccountAdded){
                list.add((PortalBoxInterface) pair.getValue());
                iterator.remove();
            }
        }

    }

    private static boolean isUnverifiedAccount(PortalBoxInterface account){
        if(account != null){
            if(account instanceof BankVerifyAccount || ((account instanceof CardAccount) && !((CardAccount) account).getIsVerified())){
                return true;
            }
        }
        return false;

    }

    private static boolean isErrorAccount(PortalBoxInterface account){
        if(account != null){
            if((account.getSortId() != PortalConstants.BANK_ERROR_BOX_ID) || (account.getSortId() != PortalConstants.CARD_ERROR_BOX_ID)){
                return true;
            }
        }
        return false;

    }

    /**
     * Method to sort-out portal list item based on their odd / even position
     */
    public static List<PortalBoxInterface> getOddEvenSortedList(List<PortalBoxInterface> portalAccounList, int oddEvenIndex) {
        ArrayList<PortalBoxInterface> portalAccounListSorted = new ArrayList<PortalBoxInterface>();
        for (int i = 0; i < portalAccounList.size(); i++) {
            if (i % 2 == oddEvenIndex) {
                portalAccounListSorted.add(portalAccounList.get(i));
            }

        }
        return portalAccounListSorted;
    }

    /**
     * Checks whether the logged in user is a new SSO User
     * @return true/false
     */
    public static boolean isNewSSOUser(){

        final Set<String> edsKeys = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details().getCardAccountsMap().keySet();
        final Iterator iterator = edsKeys.iterator();
        boolean isNewUser = false;
        loop:{
            while (iterator.hasNext()) {
                if (!FacadeFactory.getCardFacade().isEDSKeyMatching((String) iterator.next())) {
                    isNewUser = true;
                } else {
                    isNewUser = false;
                    break loop;
                }
            }
        }
        return isNewUser;
    }

    public static boolean isMulticardUser(){
        if (!Globals.isSSOUser() && PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details() != null && PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details().getCardAccountsMap() != null) {
            final int count = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details().getCardAccountsMap().size();
            return count > 1 ? true : false;
        }
        return false;
    }

    /**
     * Method to check externalStatus for portal animation
     * Added for regression defect# 11873
     */
    public static boolean isAllowPortalAnimation(PortalBoxInterface dataItem) {

        String externalStatus = null;
        boolean allowAnimation = true; // By default animation should happen

        if (dataItem instanceof CardAccount) {
            externalStatus = ((CardAccount) dataItem).getExternalStatus();
        }

        if (!isStrFieldEmpty(externalStatus) && (externalStatus.equalsIgnoreCase("A") || externalStatus.equalsIgnoreCase("Z") ||
                externalStatus.equalsIgnoreCase("B") || externalStatus.equalsIgnoreCase("U") || externalStatus.equalsIgnoreCase("L"))) {
            allowAnimation = false;
        }

        return allowAnimation;
    }

    /**
     * Method to check if old or new Fico is kill switched
     * @return
     */
    public static int checkforFicoKillSwitch() {
        int showFico = FicoUtils.SHOWNOFICO;
        boolean hideOldFico = false;
        boolean hideNewFico = false;
        AccountV2Details accountDetailsFromCache = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
        if (accountDetailsFromCache != null) {
            CardAccount cardAccount = null;
            if (null != accountDetailsFromCache) {
                LinkedHashMap<String, CardAccount> cardAccountsMap = accountDetailsFromCache.getCardAccountsMap();
                String key = null; //Fabric 8.8.0, #693
                if (cardAccountsMap != null && cardAccountsMap.size() > 0) {
                    key = (String) accountDetailsFromCache
                            .getCardAccountsMap().keySet()
                            .toArray()[0];
                    if (key != null && cardAccountsMap.containsKey(key))
                        cardAccount = accountDetailsFromCache.getCardAccountsMap().get(key);

                    if (null!=cardAccount)
                    {
                        if (cardAccount.getHideScreens().contains(FicoUtils.OLD_FICO_KILL_SWITCH_CONSTANT)) {
                            hideOldFico = true;
                        }
                        if (cardAccount.getHideScreens().contains(FicoUtils.NEW_FICO_KILL_SWITCH_CONSTANT)) {
                            hideNewFico = true;
                        }
                    }
                }
                if ((!hideNewFico && !hideOldFico) || (hideNewFico && !hideOldFico)) {
                    showFico = FicoUtils.SHOWOLDFICO;
                } else if (!hideNewFico && hideOldFico) {
                    showFico = FicoUtils.SHOW_FICO_SCORECARD;
                } else {
                    showFico = FicoUtils.SHOWNOFICO;
                }
            }
        }

        return showFico;
    }

}