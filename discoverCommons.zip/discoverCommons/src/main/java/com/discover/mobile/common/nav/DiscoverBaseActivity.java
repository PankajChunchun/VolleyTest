package com.discover.mobile.common.nav;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.LayoutRes;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

//import com.crashlytics.android.Crashlytics;
//import com.crashlytics.android.answers.Answers;
import com.discover.mobile.common.AlertDialogParent;
import com.discover.mobile.common.BaseMasterFragment;
import com.discover.mobile.common.DiscoverModalManager;
import com.discover.mobile.common.R;
import com.discover.mobile.common.SyncedActivity;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.auth.KeepAlive;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.nav.listener.LHNHighlightingListener;
import com.discover.mobile.common.permission.listener.PermissionListener;
import com.discover.mobile.common.permission.utils.PermissionConstant;
import com.discover.mobile.common.permission.utils.PermissionPref;
import com.discover.mobile.common.shaketobug.ShaketobugConfig;
import com.discover.mobile.common.shaketobug.ShaketobugManager;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.common.ui.modals.SimpleContentModal;
import com.discover.mobile.common.widget.FragmentTransactions;
import com.discover.mobile.network.infomessage.InfoMessageUtils;

import java.util.List;

//import io.fabric.sdk.android.Fabric;

//import io.fabric.sdk.android.Fabric;

/**
 * Base class which implements basic functionality like forward and backward navigation,back press
 * logic .
 * All modules  which do not need the action bar and drawer implementation
 * (mostly pre log in) should have their container activities derived from this class.
 */
public abstract class DiscoverBaseActivity extends AppCompatActivity implements AlertDialogParent, ErrorHandlerUi, SyncedActivity, OnRequestPermissionsResultCallback

{

    public static final int NO_LAYOUT = -1;
    private static final String TAG = DiscoverBaseActivity.class.getSimpleName();
    /**
     * lock used to synchronize with threads attempting to update activity
     */
    private static final Object lock = new Object();
    protected DrawerLayout mDrawer;
    protected FrameLayout mContentView;
    protected Fragment mCurrentFragment;
    private Toolbar mToolbar;
    private ImageView mCenterLogo;
    private TextView mCenterTitle;
    private LHNHighlightingListener mHighlightingListener;
    //LeftLogo Added for OnBoarding to home shared image transition
    private ImageView mLeftLogo;
    /**
     * Contains the last error that occurred with the activity.
     * An object that holds a reference to an instance of BaseActivity can set its value by using
     * setLastError.
     */
    private int mLastError = 0;
    /**
     * Flag used to determine if the activity is in resumed state
     */
    private boolean resumed = false;

    /* Listener to be set to give a call back to the corresponding fragment for callbacks */
    private PermissionListener mPermissionListener;
    /* Type of permission that is being reg */
    private PermissionConstant.Permissions mPermission;

    /** start added for handling device root & remove registered FP scenarios */
    private FingerPrintUtils fingerPrintUtilsCard;
    private FingerPrintUtils fingerPrintUtilsBank;
    /** end added for handling device root & remove registered FP scenarios */

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //Fabric.with(this, new Crashlytics());
        //Fabric.with(this, new Answers());
        manageScreenOrientation();

        /** start added for handling device root & remove registered FP scenarios */
        fingerPrintUtilsCard = new FingerPrintUtils(this, true);
        fingerPrintUtilsBank = new FingerPrintUtils(this, false);
        /** end added for handling device root & remove registered FP scenarios */

        if(Globals.isShaketoBugEnabled){
            ShaketobugManager.getInstance().startListening(this);
            ShaketobugManager.getInstance().setConfig(setupConfig());
        }

    }

    public ShaketobugConfig setupConfig() {
        ShaketobugConfig config = new ShaketobugConfig();
        config.setActionbarColor(Color.RED);
        config.setActionbarTitle("Sample Title");
        config.setEmailSubjectField("Bug Report From User");
        config.setEmailToField("sathishthirumoorthy@discover.com");
        config.setPencilColor(Color.RED);
        config.setUseDarkIcons(false);
        //   config.setActionbarBackgrounDrawable(R.drawable.rounded_yellow_bar);
        return config;
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Load all application and user preferences from persistent storage
        Globals.loadPreferences(this);


        //Bank Only Code - common interfaces implementation - pchand2 - start
        //Set this activity as the active activity
        DiscoverActivityManager.setActiveActivity(this);

        DiscoverActivityManager.setActiveAppCompatActivity(this);

        //If a modal was showing show the modal
        if (DiscoverModalManager.isAlertShowing() && null != DiscoverModalManager.getActiveModal()) {
            if (DiscoverModalManager.getActiveModal() instanceof ProgressDialog) {
                startProgressDialog(DiscoverModalManager.isProgressDialogCancelable());
            } else {
                DiscoverModalManager.getActiveModal().show();
            }
            DiscoverModalManager.setAlertShowing(true);
        }
        //bank common implementation pchand2
        notifyResumed();
        //Bank Only Code - common interfaces implementation - pchand2 - end

        checkRootAndClearPasscode();
        checkDeviceFPSettingsAndClearFPData();
    }

    /**
     * Added for US76092
     * Check If device is rooted. If rooted clear pass-code from pref.
     */
    private void checkRootAndClearPasscode() {
        if (Utils.isRooted()) {
            clearCardBankFPData();
        }
    }

    /**
     * Added for defect #3586 & #81:
     * It checks FP registration on Android Device level. After enabling pass-code & FP on
     * Discover-App level & use logged out of app
     * & removes all registered FP from Device Settings then we have to handle it by removing all
     * FP related data from Discover app level.
     */
    private void checkDeviceFPSettingsAndClearFPData() {
        if (FingerPrintUtils.isFingerprintHardwareAvailable(this)) {
            if (!FingerPrintUtils.isFingerprintRegistered(this)) {
                clearCardBankFPData();
            }
        }
    }

    /**
     * Method to clear Card/Bank and SSO FP data on Device Root & if user removes all registered FP
     * from device
     */
    private void clearCardBankFPData() {
        if (fingerPrintUtilsCard == null) {
            fingerPrintUtilsCard = new FingerPrintUtils(this, true);
        }
        if (fingerPrintUtilsBank == null) {
            fingerPrintUtilsBank = new FingerPrintUtils(this, false);
        }
        fingerPrintUtilsCard.removeFingerprintPasscode();
        fingerPrintUtilsCard.resetProfileSettingFingerPrintStatus();
        fingerPrintUtilsCard.clearSSOFingerPrintStatus();
        fingerPrintUtilsBank.removeFingerprintPasscode();
    }

    /**
     * Used to handle user interaction across the application.
     *
     * @param ev The MotionEvent that was recognized.
     * @return True if consumed, false otherwise.
     */
    @Override
    public boolean dispatchTouchEvent(final MotionEvent ev) {
        super.dispatchTouchEvent(ev);

        KeepAlive.checkForRequiredSessionRefresh();

        return false;
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;

        //Save all application and user preferences from persistent storage
        if (DiscoverModalManager.hasActiveModal()) {
            if (DiscoverModalManager.getActiveModal() instanceof ProgressDialog) {
                DiscoverModalManager.getActiveModal().dismiss();
            } else {
                DiscoverModalManager.getActiveModal().hide();
            }
            DiscoverModalManager.setAlertShowing(true);
        } else {
            DiscoverModalManager.clearActiveModal();
        }

        Globals.savePreferences(this);
    }

    /**
     * This methods by default disables all the navigation and these are to be enabled by the child
     * as required.
     * This includes action bar and the navigation drawer
     */
    private void disableAllNavigation() {

        mToolbar.setVisibility(View.GONE);
        mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
    }

    /**
     * Initialize the views for page
     */
    private void initializeViews() {
        mToolbar = (Toolbar) findViewById(R.id.discover_toolbar);
        mDrawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        mContentView = (FrameLayout) findViewById(R.id.contentView);
        mCenterTitle = (TextView) findViewById(R.id.discover_title_center);
        mCenterLogo = (ImageView) findViewById(R.id.discover_title_logo);
        mLeftLogo = (ImageView) findViewById(R.id.discover_left_logo);
        setSupportActionBar(mToolbar);
    }

    /**
     * get the Default toolbar instance
     *
     * @return default instance of the toolbar (Action bar)
     */
    protected Toolbar getToolBar() {
        return this.mToolbar;
    }

    /**
     * Enable the Action bar
     */
    protected void enableActionbar() {
        mToolbar.setVisibility(View.VISIBLE);

    }

    /**
     * Enable the drawer
     */
    protected void enableDrawer() {
        if(mDrawer != null) {
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        }
    }

    /**
     * Disable/Hide the drawer
     */
    protected void disableDrawer() {
        if(mDrawer != null) {
            mDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        }
    }


    protected DrawerLayout getDrawerLayout() {
        return this.mDrawer;
    }

    /**
     * Make the fragment visible if the fragment is a non LHN item and does not require
     * highlighting
     *
     * @param fragment - fragment to be made visible
     */
    public void makeFragmentVisible(final Fragment fragment) {

        makeFragmentVisible(fragment, true, false);
    }

    /**
     * Function to be called from other makeFragmentVisible functions will be called explicitly for
     * all the modulea which are NOT opened from LHN
     *
     * @param fragment     - Fragment to invoke
     * @param addToHistory - whether fragment should be stored in backstack
     * @param isFromLHN    if the flow is from LHN or not (if fragment is not invoked from LHN we
     *                     trigger the code og Changeing the Highlighting.
     */
    public void makeFragmentVisible(Fragment fragment, boolean addToHistory, boolean isFromLHN) {
        // Fix for IllegalStateException - Fabric START
        Activity act = com.discover.mobile.common.shared.DiscoverActivityManager.getActiveActivity();
        if (act instanceof DrawerBaseActivity && ((DrawerBaseActivity) act).isActivityPaused)
        {
            FragmentTransactions ft = new FragmentTransactions(fragment, addToHistory, isFromLHN);
            ((DrawerBaseActivity)act).addOperation(ft);
            return;
        }
        // Fix for IllegalStateException - Fabric END

        if (!isFromLHN && null != mHighlightingListener) {
            mHighlightingListener.onHighlightingChanged(fragment);

        }

        if (mContentView != null) {
            {
                if (addToHistory) {
                    setVisibleFragment(fragment);
                } else {
                    setVisibleFragmentNoHistory(fragment);
                }

            }
        } else {
            throw new IllegalStateException("Leaf Nodes need to call setContentView,In case view is not required then setContentView(-1) should be called.");
        }

    }

    /**
     * Sets the fragment seen by the user
     *
     * @param fragment - fragment to be shown
     */
    private void setVisibleFragment(final Fragment fragment) {

        if (fragment.getClass().getSimpleName().equals("BankLevel2Fragment")) {
            setVisibleFragmentNow(fragment);
        } else {
            FragmentManager fragManager = this.getSupportFragmentManager();
            int stackCount = fragManager.getBackStackEntryCount();
            String fragmentName = "";
            if (stackCount > 1) {
                fragmentName = fragManager.getBackStackEntryAt(stackCount - 1).getName();
                if (fragmentName.equals("BankLevel2Fragment")) {
                    fragManager.popBackStack(fragmentName, fragManager.POP_BACK_STACK_INCLUSIVE);
                }
                /* US60516 - Start
            US60516 - We are clearing the backstack onclicking back button from Home screen.
            Since popBackStack is asynchronus it does not get executed right after it gets called,
            popBackStackImmediate performs operation immediately.*/
                if (fragment.getClass().getSimpleName().equals("HomeSummaryMasterFragment")) {
                    fragManager.popBackStackImmediate(null, android.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }
                /*
            US60516 - End
        */
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.contentView, fragment, fragment.getClass().getSimpleName())
                    .addToBackStack(fragment.getClass().getSimpleName()).commitAllowingStateLoss();
            if (fragment instanceof BaseMasterFragment) {
                ((BaseMasterFragment) fragment).initialize();
            }

        }


    }


    /**
     * Sets the fragment seen by the user, but does not add it to the history
     *
     * @param fragment - fragment to be shown
     */
    private void setVisibleFragmentNoHistory(final Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.contentView, fragment, fragment.getClass().getSimpleName()).commit();
        //getSupportFragmentManager().beginTransaction().remove(fragment).add(R.id.contentView, fragment, fragment.getClass().getSimpleName()).commit();

    }


    /**
     * Make the fragment visible
     *
     * @param fragment - fragment to be made visible
     */
    public void makeFragmentVisible(final Fragment fragment, boolean addToHistory) {

        makeFragmentVisible(fragment, addToHistory, true);
    }

    public Fragment getCurrentFragment() {
        return mCurrentFragment;
    }

    public void setCurrentFragment(Fragment mCurrentFragment) {
        this.mCurrentFragment = mCurrentFragment;
    }

    /**
     * This method must be called to set the layout.In case the layout is not required
     * for the activity then too this method must be called with NO_LAYOUT as parameter.
     *
     * @param layoutResID id of the layout to show
     */
    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        super.setContentView(R.layout.activity_base);
        initializeViews();
        disableAllNavigation();

        com.discover.mobile.common.shared.DiscoverActivityManager.setActiveActivity(this);

        mContentView.removeAllViews();
        if (layoutResID != NO_LAYOUT) {
            LayoutInflater inflater = LayoutInflater.from(this);
            View view = inflater.inflate(layoutResID, null);
            mContentView.addView(view);
        }
     /*   if(Utils.isRunningOnHandset(this)) {
        }*/
    }

    public void setHighlightingListener(LHNHighlightingListener highlightingListener) {
        mHighlightingListener = highlightingListener;
    }

    protected TextView getCenterTitle() {
        return mCenterTitle;
    }

    protected ImageView getCenterLogo() {
        return mCenterLogo;
    }

    @Override
    public void onBackPressed() {
        //DiscoverModalManager.clearActiveModal();
        super.onBackPressed();

    }

    protected ViewGroup getContainerView() {
        return this.mContentView;

    }

    protected void manageScreenOrientation() {
        CommonUtils.lockOrientationInPortrait(this);
    }

    //Bank Only Code - common interfaces implementation - pchand2 - start

    /**
     * @return Return a reference to the current dialog being displayed over this activity.
     */
    @Override
    public AlertDialog getDialog() {
        return DiscoverModalManager.getActiveModal();
    }

    /**
     * Allows to set the current dialog that is being displayed over this activity.
     */
    @Override
    public void setDialog(final AlertDialog dialog) {
        DiscoverModalManager.setActiveModal(dialog);
    }

    /**
     * Closes the current dialog this is being displayed over this activity. Requires
     * a call to setDialog to be able to use this function.
     */
    @Override
    public void closeDialog() {
        if (DiscoverModalManager.hasActiveModal() && DiscoverModalManager.isAlertShowing()) {
            DiscoverModalManager.clearActiveModal();
        } else {
            if (Log.isLoggable(TAG, Log.WARN)) {
                Log.w(TAG, "Activity does not have a dialog associated with it!");
            }
        }
    }

    /**
     * Starts a Progress dialog using this activity as the context. The ProgressDialog created
     * will be set at the active dialog.
     */
    @Override
    public void startProgressDialog(final boolean progressDialogIsCancelable) {
        if (!DiscoverModalManager.hasActiveModal()) {
            DiscoverModalManager.setActiveModal(ProgressDialog.show(DiscoverActivityManager.getActiveActivity(),
                    "Discover", "Loading...", true));
            DiscoverModalManager.setProgressDialogCancelable(progressDialogIsCancelable);
            DiscoverModalManager.getActiveModal().setCanceledOnTouchOutside(false);
            DiscoverModalManager.getActiveModal().setOnCancelListener(new DialogInterface.OnCancelListener() {

                @Override
                public void onCancel(final DialogInterface dialog) {
                    onCancelProgressDialog();
                }
            });
            DiscoverModalManager.setAlertShowing(true);
        } else {
            if (Log.isLoggable(TAG, Log.WARN)) {
                Log.w(TAG, "Activity does not have a dialog associated with it!");
            }
        }
    }

    public void onCancelProgressDialog() {

    }

    /**
     * Show a custom modal alert dialog for the activity
     *
     * @param alert - the modal alert to be shown
     */
    @Override
    public void showCustomAlert(final AlertDialog alert) {
        DiscoverModalManager.setActiveModal(alert);
        DiscoverModalManager.setAlertShowing(true);
        alert.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alert.show();
        alert.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    /**
     * Show the default one-button alert with a custom title, content an button text
     *
     * Uses the orange button
     *
     * @param title      - the resource id for title for the alert
     * @param content    - the resource id for content to display on the box
     * @param buttonText - the resource id for button text to display on the button
     */
    @Override
    public void showOneButtonAlert(final int title, final int content, final int buttonText) {
        showCustomAlert(new SimpleContentModal(this, title, content, buttonText));
    }

    /**
     * Show the default one-button alert with a custom title, content an button text
     *
     * Uses the orange button
     *
     * @param title      - the resource id for title for the alert
     * @param content    - the resource id for content to display on the box
     * @param buttonText - the resource id for button text to display on the button
     */
    @Override
    public void showDynamicOneButtonAlert(final int title, final String content, final int buttonText) {
        showCustomAlert(new SimpleContentModal(this, title, content, buttonText));
    }


    /*
     * Child classes should override this to implement error handling behavior
     * (non-Javadoc)
     * @see com.discover.mobile.ErrorHandlerUi#getErrorLabel()
     */
    @Override
    public TextView getErrorLabel() {
        return null;
    }

    /*
     * Child classes should override this to implement error handling behavior
     *  (non-Javadoc)
     * @see com.discover.mobile.ErrorHandlerUi#getInputFields()
     */
    @Override
    public List<EditText> getInputFields() {
        return null;
    }

    /* (non-Javadoc)
     * @see com.discover.mobile.ErrorHandlerUi#getContext()
     */
    @Override
    public Context getContext() {
        return this;
    }

    /* (non-Javadoc)
     * @see com.discover.mobile.ErrorHandlerUi#getLastError()
     */
    @Override
    public int getLastError() {
        return mLastError;
    }

    /* (non-Javadoc)
     * @see com.discover.mobile.ErrorHandlerUi#setLastError()
     */
    @Override
    public void setLastError(final int errorCode) {
        mLastError = errorCode;
    }

    @Override
    public ErrorHandler getErrorHandler() {
        return null;
    }

    @Override
    public boolean isReady() {
        return resumed;
    }

    @Override
    public boolean waitForResume(final int millis) {
        synchronized (lock) {
            /**
             * If activity is not resumed then wait for it to resume, this wait can be unlocked
             * via notifyResumed() which is called in the onResume of this activity.
             */
            if (!isReady()) {
                try {
                    if (millis >= 0) {
                        lock.wait(millis);
                    } else {
                        lock.wait();
                    }
                } catch (final InterruptedException e) {
                    if (Log.isLoggable(TAG, Log.ERROR)) {
                        Log.e(TAG, "An error occurred while waiting for activity to resume");
                    }
                }
            } else {
                if (Log.isLoggable(TAG, Log.WARN)) {
                    Log.w(TAG, "Activity is Ready!");
                }
            }
        }

        return isReady();
    }

    /**
     * Method utilize to unblock any thread blocking on waitForResume
     */
    private void notifyResumed() {
        synchronized (lock) {
            resumed = true;

            lock.notifyAll();
        }
    }

    public Fragment getCurrentContentFragment() {

        final FragmentManager fragMan = this.getSupportFragmentManager();
        final Fragment currentFragment = fragMan
                .findFragmentById(R.id.contentView);

        return currentFragment;
    }

    public void logout() {
        /** Used on pause to know when to set Globals isLoggedIn to false **/

        FacadeFactory.getLogoutFacade().logout(this, this,
                Globals.getCurrentAccount());
    }


    protected void setVisibleFragmentNoAnimationOrientation(final Fragment prevFragment, final Fragment currFragment) {
        //Crashlytics fix for #97
        try {
            getSupportFragmentManager().popBackStack(prevFragment.getClass().getSimpleName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.contentView, currFragment)
                    //Adds the class name and fragment to the back stack
                    .addToBackStack(currFragment.getClass().getSimpleName())
                    .commit();
        } catch(Exception e) {
            Log.w("DiscoverBaseActivity", "Unexptected Exception during FragmentManger popBackStach and addbackStack ");
            e.printStackTrace();
        }
        //hideSlidingMenuIfVisible();
    }

    /**
     * Fix added- infinite spinner after added the boolean as true in DiscoverBaseActivity in
     * OnPause method-Start
     * DiscoverModalManager.setAlertShowing(true);
     */
    @Override
    public void startActivity(Intent intent) {
        /**Clear any modal that may have been created during the life of the current activity*/
        DiscoverModalManager.clearActiveModal();
        super.startActivity(intent);
    }

    /**
     * Fix added- infinite spinner after added the boolean as true in DiscoverBaseActivity in
     * OnPause method-Start
     * DiscoverModalManager.setAlertShowing(true);
     */
    @Override
    public void startActivityForResult(final Intent intent, final int requestCode) {
        /**Clear any modal that may have been created during the life of the current activity*/
        DiscoverModalManager.clearActiveModal();

        super.startActivityForResult(intent, requestCode);
    }

    //Bank Only Code - common interfaces implementation - pchand2 - end

    /** Return the Left custom logo view - added for exit setup transition from OnboardActivity **/
    public ImageView getLeftLogo() {
        return mLeftLogo;
    }

    /*--------------------------------------------------Added by Pranjal temporary-----------------------------------------------*/
    private void setVisibleFragmentNow(final Fragment fragment) {
        getSupportFragmentManager().beginTransaction().add(R.id.contentView, fragment, fragment.getClass().getSimpleName()).addToBackStack(fragment.getClass().getSimpleName()).commit();
    }
    /*--------------------------------------------------Pranjal-----------------------------------------------*/

    /**
     * <p>{@link android.app.Activity} or {@link com.discover.mobile.common.BaseChildFragment} can call
     * this method to check if permission is granted to use the feature.</p>
     *
     * <p>This method does not return any thing. So caller should always pass {@link PermissionListener} as argument
     * to get result of permission result.</p>
     *
     * @param requestingPermission
     * {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions}
     * @param postRationaleMsg - Feature specific permission message. This message can be null and in that
     *                      case default message will be shown for requesting feature.
     *                         This message will be shown if system permission dialog is disabled by user.
     * @param listener {@link PermissionListener}
     */
    public void checkPermission(PermissionConstant.Permissions requestingPermission, String postRationaleMsg, PermissionListener listener) {
        boolean isRationalNeeded = true;
        checkPermission(requestingPermission, null, postRationaleMsg, listener,isRationalNeeded);
    }

    /**
     * <p>{@link android.app.Activity} or {@link com.discover.mobile.common.BaseChildFragment} can call
     * this method to check if permission is granted to use the feature.</p>
     *
     * <p></p>After first deny from OS permission dialog, This API will show a rationale dialog which gives
     * information about, why this permission is needed for Discover. If user cancel this dialog,
     * permission request will be canceled, and if user proceeds then OS permission request dialog
     * will be shown to user.</p>
     *
     * <p>This method does not return any thing. So caller should always pass {@link PermissionListener} as argument
     * to get result of permission result.</p>
     *
     * @param requestingPermission
     * {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions}
     * @param rationaleMsg - Feature specific permission message, which should be shown to user about why
     *                     application needed this permission.
     *                     This message will be shown to user on dialog from second request for
     *                     {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions}.
     * @param postRationaleMsg - Feature specific permission message. This message can be null and in that
     *                      case default message will be shown for requesting feature. This message will be
     *                         shown if system permission dialog is disabled by user.
     * @param listener {@link PermissionListener}
     */
    public void checkPermission(PermissionConstant.Permissions requestingPermission, String rationaleMsg, String postRationaleMsg, PermissionListener listener, boolean isRationalNeeded) {

        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            // Current device is running on the OS version before Marshmallow,
            // All permission will be granted to application at install time.
            // No need to check further.
            listener.onPermissionGranted(requestingPermission);
            return;
        }
        // Set requesting permission and callback listener
        this.mPermission = requestingPermission;
        this.mPermissionListener = listener;
        // Check if discover app has requesting-permission already.
        if (ContextCompat.checkSelfPermission(this, mPermission.toString()) == PackageManager.PERMISSION_GRANTED) {
            // Has permission. Notify the caller
            listener.onPermissionGranted(mPermission);
            doNullifyPermissionVariables();
        } else {
            // Check if rationale permission dialog should be shown
            boolean shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, mPermission.toString());
            // If rationaleMsg given by caller and shouldShowRationale is true, then show a dialog before asking for permission
            // This dialog will show the information that why Discover needs this particular permission.
            if (!TextUtils.isEmpty(rationaleMsg) && shouldShowRationale && isRationalNeeded) {
                String btnTxtPos = InfoMessageUtils.Instance().getErrorMessage(PermissionConstant.RATIONALE_DIALOG_BTN_POSITIVE);
                if (TextUtils.isEmpty(btnTxtPos)) {
                    btnTxtPos = getString(R.string.request_permission_btntxt_rationale_pos);
                }

                String btnTxtNeg = InfoMessageUtils.Instance().getErrorMessage(PermissionConstant.RATIONALE_DIALOG_BTN_NEGATIVE);
                if (TextUtils.isEmpty(btnTxtNeg)) {
                    btnTxtNeg = getString(R.string.request_permission_btntxt_rationale_neg);
                }
                new DiscoverAlertDialog()
                        .setMessage(rationaleMsg)
                        .setPositiveButton(btnTxtPos,
                                new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        ActivityCompat.requestPermissions(DiscoverBaseActivity.this, new String[]{mPermission.toString()}, mPermission.getRequestCode());
                                    }
                                }
                        )
                        .setNegativeButton(btnTxtNeg,
                                new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if(null!=mPermissionListener)
                                        mPermissionListener.onPermissionDenied(mPermission);
                                        doNullifyPermissionVariables();
                                    }
                                })
                        .setCanCancelable(false)
                        .show(DiscoverBaseActivity.this);
            } else if(PermissionPref.getInstance(this).isPermissionDialogBlocked(mPermission) && (!shouldShowRationale) && isRationalNeeded) {
                // If OS permission dialog blocked by user (By checking "Never Ask Again" and Denied), then show own descriptive dialog
                // to user from where user can goto to Application's settings page to enable a permission or can Cancel that permission request
                // dialog.
                showCustomPermissionDialog(mPermission, postRationaleMsg);
            } else {
                // Normal flow, OS will show its own permission modal.
                // Request for the permission
                ActivityCompat.requestPermissions(this, new String[]{mPermission.toString()}, mPermission.getRequestCode());
            }
        }
    }
    /*US72789- Atm Locator permission flow- Code change start*/
    public void setPermissionListener(PermissionConstant.Permissions requestingPermission, PermissionListener listener){
        this.mPermission = requestingPermission;
        this.mPermissionListener = listener;
    }
    /*US72789- Atm Locator permission flow- Code change end*/

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if(grantResults.length>0)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission Granted by the user. Notify to caller
                new android.os.Handler().post(new Runnable() {
                    public void run() {
                        // Callback after onresume
                        if(null!=mPermissionListener)
                        mPermissionListener.onPermissionGranted(mPermission);
                        doNullifyPermissionVariables();
                    }
                });
            } else {
                /**
                 * <p>
                 *    Permission denied by user.
                 *    In this case there will be three cases to handle this flow
                 *    1. To check if user denied permission request without ticked "Never Ask me Again".
                 *    2. To check if user denied permission request with ticked "Never Ask me Again".
                 *    3. To check if user previously ticked "Never Ask me Again" and denied
                 *    permission request.
                 *    In case of 1 and 2, callback will be send to caller about permission not granted.
                 *    But in case of case 3, user will be showing a custom dialog which can navigate
                 *    user to Settings Screen.
                 * </p>
                 * */
                boolean shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, mPermission.toString());
                if (shouldShowRationale) {
                    // Case1 and Case2
                    // Reset flag for custom dialog to false
                    PermissionPref.getInstance(this).resetPermissionDialogBlocked(mPermission, false);
                } else {
                    // Case3. To Show custom dialog with custom message set BLOCKED flag to true.
                    PermissionPref.getInstance(this).resetPermissionDialogBlocked(mPermission, true);
                }
                new android.os.Handler().post(new Runnable() {
                    public void run() {
                        // Callback after onresume
                        if (mPermissionListener!=null)
                             mPermissionListener.onPermissionDenied(mPermission);
                        doNullifyPermissionVariables();
                    }
                });
            }
        }

    }

    /**
     * Show custom permission dialog. This dialog will be shown to user in case when system does
     * not show own permission dialog (User blocked OS permission dialog).
     * This dialog can redirect user to Application's Settings screen.
     */
    private void showCustomPermissionDialog(PermissionConstant.Permissions permission, String message) {

        if (TextUtils.isEmpty(message)) {
            // Set default message to dialog
            message = InfoMessageUtils.Instance().getErrorMessage(PermissionConstant.DIALOG_MESSAGE[permission.getRequestCode()]);
        }

        String btnTxtPos = InfoMessageUtils.Instance().getErrorMessage(PermissionConstant.DIALOG_BTN_POSITIVE);
        if (TextUtils.isEmpty(btnTxtPos)) {
            btnTxtPos = getString(R.string.request_permission_btntxt_pos);
        }

        String btnTxtNeg = InfoMessageUtils.Instance().getErrorMessage(PermissionConstant.DIALOG_BTN_NEGATIVE);
        if (TextUtils.isEmpty(btnTxtNeg)) {
            btnTxtNeg = getString(R.string.request_permission_btntxt_neg);
        }

        final String dialogMsgFinal = message;
        final String btnTextPosFinal = btnTxtPos;
        final String btnTextNegFinal = btnTxtNeg;
        new android.os.Handler().post(new Runnable() {
            public void run() {
                new DiscoverAlertDialog()
                        .setMessage(dialogMsgFinal)
                        .setPositiveButton(btnTextPosFinal,
                                new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        doNullifyPermissionVariables();
                                        // Redirect user to Application Settings screen.
                                        // Where user can allow required permission.
                                        Intent intent = new Intent();
                                        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                        Uri uri = Uri.fromParts("package", getPackageName(), null);
                                        intent.setData(uri);
                                        startActivity(intent);
                                    }
                                }
                        )
                        .setNegativeButton(btnTextNegFinal, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(null!=mPermissionListener)
                                mPermissionListener.onPermissionDenied(mPermission);
                                doNullifyPermissionVariables();
                            }
                        })
                        .setCanCancelable(false)
                        .show(DiscoverBaseActivity.this);
            }
        });
    }

    private void doNullifyPermissionVariables() {
        mPermissionListener = null;
        mPermission = null;
    }
}


