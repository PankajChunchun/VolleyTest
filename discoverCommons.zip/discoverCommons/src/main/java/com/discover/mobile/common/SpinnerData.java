package com.discover.mobile.common;

/**
 * Created by pdesai2 on 6/28/2016.
 *
 * Keeps the spinnerData for the spinner.
 * It has 3 different constructors for the different types of spinners.
 * It also has getters to fetch and set the data to the spinner.
 */
public class SpinnerData {

    String lineOne, lineOneRight, lineTwo;

    public SpinnerData(String firstLine, String firstRightLine, String secondLine)
    {
        this.lineOne= firstLine;
        this.lineOneRight= "("+firstRightLine+")";
        this.lineTwo= secondLine;
    }
    public SpinnerData(String firstLine, String secondLine)
    {
        this.lineOne= firstLine;
        this.lineTwo= secondLine;
    }
    public SpinnerData(String firstLine)
    {
        this.lineOne= firstLine;
    }

    public String getLineOne(){
        return lineOne;
    }

    public String getLineOneRight(){
        return lineOneRight;
    }

    public String getLineTwo(){
        return lineTwo;
    }

}
