package com.discover.mobile.common.portalpage.listener;

/**
 * Interface to handle click on UI clicks on Portal Page list
 *
 * @author slende
 */
public interface PortalListItemClickInterface {
    /**
     * To handle Card Side click handling
     */
    //public void onPortalPageItemClick(Context mcontext, PortalPageClickType itemClickType, String edsKey);

    /**
     * To handle Bank side click handling
     */
    //public void onPortalPageItemClick(Context mcontext, PortalPageClickType itemClickType, int accountIndexKey, PortalAccountType portalAccountType);

    public enum PortalPageClickType {
        CARD_ACCOUNT_SELECTED,
        BANK_ACCOUNT_SELECTED,
        CARD_MAKE_A_PAYMENT_LINK,
        BANK_MAKE_A_PAYMENT_LINK,
        CARD_FICO_CREDIT_SCORE_LINK,
        BANK_DEPOSIT_A_CHECK_LINK,
        BANK_PAY_BILLS_LINK,
        BANK_TRANSFER_LINK,
        BANK_VIEW_ACTIVITY_LINK,
        BANK_PAY_LOANS_LINK
    }
}
