package com.discover.mobile.common.shared.utils.image;

/**
 * Created by skrish1 on 6/9/2016.
 */
public class ImageDir {

    public enum DIR_ENUM {

        ONBOARDING("onboard"),
        INTERNATIONAL_TRAVEL("international-travel"),
        RAF("raf");

        private final String text;

        /**
         * @param text
         */
        private DIR_ENUM(final String text) {
            this.text = text;
        }

        /* (non-Javadoc)
         * @see java.lang.Enum#toString()
         */
        @Override
        public String toString() {
            return text;
        }
    }

    public enum FILE_TYPE {

        MEDIA("media"),
        IMAGE("image");

        private final String text;

        /**
         * @param text
         */
        private FILE_TYPE(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
