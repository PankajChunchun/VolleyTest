package com.discover.mobile.common.facade;

import com.discover.mobile.common.appmessaging.helper.AppMessage;
import com.discover.mobile.common.appmessaging.helper.TrackAppMessage;

import android.content.Context;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * A facade for assisting with general bank activities.
 *
 * @author acurry
 */
public interface BankFacade {

    /**
     * Navigates to Card Privacy and Terms.
     */
    public void navToCardPrivacyTerms();

    // US45209 Changes starts
    public ArrayList<String> getNonSSOBankAccounts();
    // US45209 Changes end

    public void setBankBaseUrl(String aBankBaseUrl, String ipAddress);

    public Map<String, AppMessage> getAppMessageList();

    public void callTrackAppMessageService(Context context, TrackAppMessage trackAppMessage);

    public void updateWinkState(String refreshKey, boolean showWink);

    public void navigateViaDeeplink(String deepLinkKey);

    public void navigateToLevel2AppMessage(Context context, AppMessage appMessage);
    /*US81831*/
    public String getPageTitle();

    /*US91113*/
    public void makeBankFastCheckDataCall(Context context, String url,
                                          String bankToken, Serializable dataHolder,Object senderObject);

    /*US110732*/
    public void showCDModal();

    /*US115912*/
    public void showCDModal(String accType);

    public void triggerLinkTagForCheckImg(boolean isExpand);

    /*US152632- Support app link when user logged in and minimized app*/
    public void navigateToDeepLinkFromWebLink(Context context,String deepLinkValue);
}
