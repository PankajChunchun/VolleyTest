package com.discover.mobile.common.shared;

import java.lang.ref.Reference;

import javax.annotation.Nullable;

public final class ReferenceUtility {

    private ReferenceUtility() {
        throw new UnsupportedOperationException("This class is non-instantiable"); //$NON-NLS-1$
    }

    @SuppressWarnings("hiding")
    public static
    @Nullable
    <R> R safeGetReferenced(final @Nullable Reference<R> ref) {
        if (ref == null) {
            return null;
        }

        return ref.get();
    }

}
