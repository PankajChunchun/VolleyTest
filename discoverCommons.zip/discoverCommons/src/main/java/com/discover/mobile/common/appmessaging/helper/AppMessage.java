package com.discover.mobile.common.appmessaging.helper;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * Pojo class to hold App Level messaging details
 */
public class AppMessage implements Serializable {

    @SerializedName("id")
    private String id;

    @SerializedName("key")
    private String key;

    @SerializedName("messageType")
    private String messageType;

    @SerializedName("title")
    private String title;

    @SerializedName("message")
    private String message;

    @SerializedName("img")
    private String imgUrl;

    @SerializedName("subtitle")
    private String subTitle;
    /**
     * As per requirement, menu should be true by default
     */
    @SerializedName("menu")
    private boolean menu = true;

    @SerializedName("actions")
    private List<AppMessageAction> actionList;


    private boolean isLevelMsgViewed;

    private boolean isLevel1MessageTracked = false;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public boolean isMenu() {
        return menu;
    }

    public void setMenu(boolean menu) {
        this.menu = menu;
    }

    public List<AppMessageAction> getActionList() {
        return actionList;
    }

    public void setActionList(List<AppMessageAction> actionList) {
        this.actionList = actionList;
    }

    public boolean isLevelMsgViewed() {
        return isLevelMsgViewed;
    }

    public void setIsLevelMsgViewed(boolean isLevelMsgViewed) {
        this.isLevelMsgViewed = isLevelMsgViewed;
    }

    public boolean isLevel1MessageTracked() {
        return isLevel1MessageTracked;
    }

    public void setLevel1MessageTracked(boolean isLevel1MessageTracked) {
        this.isLevel1MessageTracked = isLevel1MessageTracked;
    }

}
