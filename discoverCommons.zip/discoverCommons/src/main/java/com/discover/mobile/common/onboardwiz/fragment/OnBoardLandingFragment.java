package com.discover.mobile.common.onboardwiz.fragment;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.utils.BankOnBoardingInfo;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.image.FileDownloader;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.uiwidget.CmnButton;
import com.discover.mobile.common.uiwidget.CmnTextView;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.VideoView;

import java.io.File;
import java.util.HashMap;
import java.util.Locale;

/**
 * Landing or Home fragment for OnBoarding process.
 * Created by 494005 on 4/25/2016.
 */
public class OnBoardLandingFragment extends Fragment implements View.OnClickListener {

    private final static String mLandingText = "onboard_landing_body";
    private CmnTextView txtUser;
    private View view;
    private CmnButton btnGetStarted, exitLink;
    private String mUserName = null;
    private AccountV2Details accountDetailsFromCache;
    private BankOnBoardingInfo bankOnBoardinginfo;
    private VideoView videoPlayerView = null;
    private String packagePath = null;

    private Context mContext;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mContext = activity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        view = inflater.inflate(R.layout.onboard_landing, null);
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    R.string.bank_analytics_onboard_welcome_page);

        }
        //US53334 End
        else {

            //US53328- START
            analyticsOnPageLoad();
            //END
        }
        initUI();
        //US53867 - start
        initVideo();
        //US53867 - end
        exitLink.setOnClickListener(this);
        btnGetStarted.setOnClickListener(this);
        return view;
    }

    //US53867 - start

    /**
     * Initializes and plays the video in loop for on boarding wizard
     */
    private void initVideo() {
        //Video view to play video
        videoPlayerView = (VideoView) view.findViewById(R.id.onboard_video_view);
        //sets as null as we don't need media controllers
        videoPlayerView.setMediaController(null);
        Uri videoURI = null;

        /**start Added for US83286  - Android Fingerprint - Kill-switch */
        boolean isFingerprintOnboardItemToShow = false;
        if (null != mContext) {
            isFingerprintOnboardItemToShow = OnBoardHelper.isFPOnboardItemToShow(mContext);
        }
        /**end Added for US83286  - Android Fingerprint - Kill-switch */

        /**start changes for US79254 On-boarding Fingerprint animation; it looks for downloaded video from device file system */
        if (!OnBoardHelper.isBankAllaccountsEnroll()) {
            if (isFingerprintOnboardItemToShow) {
                videoURI = FileDownloader.getInstance().getMediaFileURI(ImageDir.DIR_ENUM.ONBOARDING, "onboard_animation_with_paperless_fp.m4v");
            } else {
                videoURI = FileDownloader.getInstance().getMediaFileURI(ImageDir.DIR_ENUM.ONBOARDING, "onboard_animation_with_paperless.m4v");
            }
        } else if (Globals.isBankLoginSelected) {
            if (isFingerprintOnboardItemToShow) {
                videoURI = FileDownloader.getInstance().getMediaFileURI(ImageDir.DIR_ENUM.ONBOARDING, "onboard_animation_without_paperless_fp.m4v");
            } else {
                videoURI = FileDownloader.getInstance().getMediaFileURI(ImageDir.DIR_ENUM.ONBOARDING, "onboard_animation_without_paperless.m4v");
            }
        } else {
            if (isFingerprintOnboardItemToShow) {
                videoURI = FileDownloader.getInstance().getMediaFileURI(ImageDir.DIR_ENUM.ONBOARDING, "onboard_animation_card_fp.m4v");
            } else {
                videoURI = FileDownloader.getInstance().getMediaFileURI(ImageDir.DIR_ENUM.ONBOARDING, "onboard_animation_card.m4v");
            }
        }
        /**end changes for US79254 On-boarding Fingerprint animation; it looks for downloaded video from device file system */

        /**start changes for US79254 On-boarding Fingerprint animation;
         * it checks if file has content or not. There is scenario like, while downloading file from LoginActivity.java
         * from server, & if server returns FileNotFoundException then on device file is getting created with empty content, so in this case videoURI always has path to file like
         * "/data/user/0/com.discoverfinancial.mobile/cache/otherImagesDir/onboard/onboard_animation_card_fp.m4v" & on UI level it shows error "Can't play video". To avoid this
         * added below content check condition."*/
        boolean isFileContentAvailable = false;
        try {
            String path = videoURI.toString();
            File file = new File(path);
            if (null != file) {
                if (file.length() > 0) {
                    isFileContentAvailable = true;
                }
            }
        } catch (Exception e) {
            isFileContentAvailable = false;
        }

        if (isFileContentAvailable) {
            videoPlayerView.setVideoURI(videoURI);
        } else {
            packagePath = "android.resource://" + getActivity().getApplicationContext().getPackageName();
            if (Globals.isBankLoginSelected) {
                videoPlayerView.setVideoURI(Uri.parse(packagePath + "/" + R.raw.onboard_animation_without_paperless));
            } else {
                videoPlayerView.setVideoURI(Uri.parse(packagePath + "/" + R.raw.onboard_animation_card));
            }
        }

        /**end changes for US79254 On-boarding Fingerprint animation*/

        videoPlayerView.setBackgroundColor(Color.WHITE);
        videoPlayerView.setZOrderOnTop(true);
        videoPlayerView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                //Sets the looping true to make video play in infinite loop.
                try {
                    mediaPlayer.setLooping(true);
                    // Below boolean set as true for avoid black flicker at few devices.
                    videoPlayerView.setZOrderOnTop(true);
                    videoPlayerView.start();
                } catch (Exception e) {
                    // safe check
                    packagePath = "android.resource://" + getActivity().getApplicationContext().getPackageName();
                    //fallback mechanism just incase video is not downloaded
                    if (Globals.isBankLoginSelected)
                        videoPlayerView.setVideoURI(Uri.parse(packagePath + "/" + R.raw.onboard_animation_without_paperless));
                    else
                        videoPlayerView.setVideoURI(Uri.parse(packagePath + "/" + R.raw.onboard_animation_card));
                    // Below boolean set as true for avoid black flicker at few devices.
                    videoPlayerView.setZOrderOnTop(true);
                    videoPlayerView.start();
                }
            }
        });

        //Cleaning resources
        videoURI = null;
        //  packagePath = null;

    }
    //US53867 - end

    private void initUI() {
        accountDetailsFromCache = fetchCacheAccountDetails();
        exitLink = (CmnButton) view.findViewById(R.id.btn_exit);
        exitLink.setContentDescription(getString(R.string.onboard_landing_exit_content_desc));
        btnGetStarted = (CmnButton) view.findViewById(R.id.btnGetStarted);
        txtUser = (CmnTextView) view.findViewById(R.id.txt_user_name);

        CmnTextView landingScreenText = (CmnTextView) view.findViewById(R.id.landing_screen_verbage);
        CommonUtils.setDisplayText(landingScreenText, mLandingText, getResources().getString(R.string.passcode_detail_verbage));

        if (Globals.isBankLoginSelected()) {
            //crashlytics fix
            if(OnBoardHelper.getsBankOnBoardingInfo() != null) {
                String customerName = OnBoardHelper.toTitleCase(OnBoardHelper.getsBankOnBoardingInfo().mFormattedName.toLowerCase());
                mUserName = String.format(getString(
                        R.string.onboard_landing_user_name), customerName);

                txtUser.setText(mUserName);
            }
        } else if (accountDetailsFromCache != null) {
            String key = (String) accountDetailsFromCache.getCardAccountsMap()
                    .keySet().toArray()[0];
            String formattedUserName = accountDetailsFromCache.getCustomerFirstName()
                    .toLowerCase(Locale.getDefault());
            String name = OnBoardHelper.toTitleCase(formattedUserName.toLowerCase());
            mUserName = String.format(getString(
                    R.string.onboard_landing_user_name), name);
//            OnBoardHelper.toTitleCase(accountDetailsFromCache.getCustomerFirstName());
            txtUser.setText(mUserName);
            txtUser.setContentDescription(mUserName);
        }

    }

    private AccountV2Details fetchCacheAccountDetails() {
        return PortalCacheDataUtils.getPortalCacheDataUtilsInstance()
                .getAccountV2Details();
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_exit) {
            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_exit_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_welcome_page));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
            //US53334 End
            if (mContext instanceof OnBoardActivity) {
                //US53328--STARTED
                if (Globals.isFromCardSide()) {
                    analyticsOnExitSetup();
                }
                //ENDS

                OnBoardHelper.navigateToCardOrBankHome();
            }
            FileDownloader.getInstance().flushImages(ImageDir.DIR_ENUM.ONBOARDING);
        } else if (v.getId() == R.id.btnGetStarted) {
            //US53867 - start
            //stops playing the video
            videoPlayerView.stopPlayback();
            //US53867 - end
            if (Globals.isFromCardSide()) {//US53328 -START
                analyticsOnGetStarted();
                //END
            }
            OnBoardPagerFragment pagerFragment = new OnBoardPagerFragment();
            ((OnBoardMasterFragment) getParentFragment()).showInLeftFrame(pagerFragment);

            //US53334 Start-OnBoarding analytics
            if (Globals.isBankLoginSelected()) {
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_get_started_btn));
                extras.put(
                        AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.bank_analytics_onboard_welcome_page));
                extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                TrackingHelper.trackBankPage(null, extras);
            }
            //US53334 END

        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //US53867 - start
        //cleaning the resources
        videoPlayerView = null;
        //US53867 - end
    }

    //US53328-START
    public void analyticsOnPageLoad() {

        TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_LANDING_PAGE_NAME, null);
    }

    public void analyticsOnGetStarted() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_LANDING_GET_STARTED_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_LANDING_GET_STARTED_PROP13);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_LANDING_GET_STARTED_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_LANDING_PAGE_GET_STARTED_PEV1);


        TrackingHelper.trackCardPage(null, extras);

    }

    public void analyticsOnExitSetup() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PROP1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_LANDING_PAGE_NAME);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_PEV1);
        extras.put(getActivity().getString(R.string.evar35), AnalyticsPage.ONBOARDWIZ_LANDING_EXIT_LINK_VAR35);


        TrackingHelper.trackCardPage(null, extras);
    }
    //ENDS
}
