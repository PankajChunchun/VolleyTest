package com.discover.mobile.common.fingerprint.adapter;

import com.discover.mobile.common.Utils;
import com.discover.mobile.common.fingerprint.listener.DiscoverFingerPrintManager;
import com.discover.mobile.common.fingerprint.listener.FingerPrintListener;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.fingerprint.utils.GoogleFingerprintHelper;
import com.discover.mobile.common.fingerprint.utils.SamsungFingerPrintHelper;

import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;

/**
 * Adapter class to merge 2 functionality of fingerprint identification.
 * using Samsung API and Google API.
 */
public class FingerPrintAdapter implements DiscoverFingerPrintManager {

    private FingerPrintUtils.FPApiType availableFpApiType = null;
    private FingerPrintListener mFingerPrintListener;
    private DiscoverFingerPrintManager discoverFingerPrintManager = null;
    private FingerprintManager mFingerprintManager;
    private Context mContext;
    public static String TAG = FingerPrintAdapter.class.getSimpleName();

    public FingerPrintAdapter(Context context, FingerPrintUtils.FPApiType fpApiType, FingerPrintListener fingerPrintListener) {
        this.availableFpApiType = fpApiType;
        this.mFingerPrintListener = fingerPrintListener;
        this.mContext = context;
        init();
    }

    /**
     * Initialize helper class based on FP APIs available on device
     */
    private void init() {

        switch (this.availableFpApiType) {

            case DEFAULT_GOOGLE_API:
                Utils.log(TAG, "FingerPrintAdapter: DEFAULT_GOOGLE_API");
                mFingerprintManager = (FingerprintManager) mContext.getSystemService(Context.FINGERPRINT_SERVICE);
                discoverFingerPrintManager = new GoogleFingerprintHelper(mContext, mFingerprintManager, mFingerPrintListener);
                break;

            case SAMSUNG_PASS_API:
                Utils.log(TAG, "FingerPrintAdapter: SAMSUNG_PASS_API");
                discoverFingerPrintManager = new SamsungFingerPrintHelper(mContext, mFingerPrintListener);
                break;

            default:
                break;
        }
    }


    @Override
    public void startListening() {
        if (null != discoverFingerPrintManager)
            discoverFingerPrintManager.startListening();
    }

    @Override
    public void stopListening() {
        if (null != discoverFingerPrintManager)
            discoverFingerPrintManager.stopListening();
    }
}
