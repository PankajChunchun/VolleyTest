package com.discover.mobile.common.portalpage.listener;

/**
 * Interface for each account including Card & Bank accounts on Portal page
 *
 * @author slende
 */
public interface PortalBoxInterface {
    String getSortId();
}
