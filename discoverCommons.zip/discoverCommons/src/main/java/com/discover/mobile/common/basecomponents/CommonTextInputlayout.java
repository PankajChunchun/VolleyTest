package com.discover.mobile.common.basecomponents;

import com.discover.mobile.common.shared.utils.CommonUtils;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.design.widget.TextInputLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;


/**
 * Created by 468195 on 7/1/2016.
 */
public class CommonTextInputlayout extends TextInputLayout implements View.OnFocusChangeListener {


    private boolean isError = false;
    private final String HIGHLIGHT_COLOR="#FF0074B4";  //blue
    private final String ERROR_COLOR ="#FFE62622";  //red
    private final String DEFAULT_COLOR ="#757575" ; //dark grey
    private CharSequence errorText = null;
    private OnFocusChangeListener focusChangeListner = null;

    public CommonTextInputlayout(Context context) {
        super(context);

        initView();
    }

    public CommonTextInputlayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

   /* public CommonTextInputlayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }*/

    private void initView() {
        this.setHintAnimationEnabled(false);
        this.setFocusable(true);

        this.setOnFocusChangeListener(CommonTextInputlayout.this);
        this.post(new Runnable() {
            @Override
            public void run() {
                setupTextChangedListener();
                adjustTopMargin();
                invalidate();
                getEditText().setOnFocusChangeListener(CommonTextInputlayout.this);
                getEditText().getBackground().mutate().setColorFilter(Color.parseColor(DEFAULT_COLOR), PorterDuff.Mode.SRC_ATOP);
            }
        });

    }

    public void addFocusChangeListner(OnFocusChangeListener listner)
    {
        this.focusChangeListner = listner;
    }




    @Override
    public void onFocusChange(View view, boolean hasFocus) {
         if(!isError && hasFocus) {
            CommonTextInputlayout.this.setHint(" ");
            this.setErrorEnabled(false);
            this.setError(null);


        }else if(!isError && !hasFocus)
        {
            CommonTextInputlayout.this.getEditText().setHint(getEditText().getHint());
            clearErrors();
        }

        if(!isError){
            if(hasFocus)
            {
                /**
                 * We reach here when focus has changed and the field
                 * HAS error: false
                 */
                getEditText().getBackground().mutate().setColorFilter(Color.parseColor(HIGHLIGHT_COLOR), PorterDuff.Mode.SRC_ATOP);
                setErrorEnabled(false);
            }else
            {
                /**
                 * We reach here when focus has changed and the field
                 * HAS error: false
                 * Lost focus
                 *
                 */
                getEditText().getBackground().mutate().setColorFilter(Color.parseColor(DEFAULT_COLOR), PorterDuff.Mode.SRC_ATOP);
                setErrorEnabled(false);
            }}else
        {
            if(errorText != null) {
                // fix for defect 249, error message was not getting cleared on focus
//                clearErrors();
//                if (getEditText().hasFocus())
//                    getEditText().getBackground().mutate().setColorFilter(Color.parseColor(HIGHLIGHT_COLOR), PorterDuff.Mode.SRC_ATOP);
//                else
//                    getEditText().getBackground().mutate().setColorFilter(Color.parseColor(DEFAULT_COLOR), PorterDuff.Mode.SRC_ATOP);
                /**
                 * We reach here when focus has changed and the field
                 * HAS error: true
                 * HAS error content : true
                 */
                if(!hasFocus)
                    setError("");
                else
                    clearErrors();
            }else
            {
                /**
                 * We reach here when focus has changed and the field
                 * HAS error: true
                 * HAS error content : false
                 */
                clearErrors();
            }
        }

        if(focusChangeListner != null)
        {
            focusChangeListner.onFocusChange(view,hasFocus);
        }
    }

    public Editable getText()
    {
        return this.getEditText().getText();
    }

    public void setText(String text)
    {
        this.getEditText().setText(text);
    }


    protected void setupTextChangedListener() {

        this.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(final Editable s) {
                if (isValid()) {
                    clearErrors();
                }
                setErrorEnabled(false);
                if (getEditText().hasFocus())
                    getEditText().getBackground().mutate().setColorFilter(Color.parseColor(HIGHLIGHT_COLOR), PorterDuff.Mode.SRC_ATOP);
                else
                    getEditText().getBackground().mutate().setColorFilter(Color.parseColor(DEFAULT_COLOR), PorterDuff.Mode.SRC_ATOP);
            }

            @Override
            public void beforeTextChanged(final CharSequence s,
                                          final int start, final int count, final int after) {/*
                                                                         * Intentionally
                                                                         * Empty
                                                                         */

            }

            @Override
            public void onTextChanged(final CharSequence s, final int start,
                                      final int before, final int count) {
                setErrorEnabled(false);
                if (getEditText().hasFocus())
                    getEditText().getBackground().mutate().setColorFilter(Color.parseColor(HIGHLIGHT_COLOR), PorterDuff.Mode.SRC_ATOP);
                else
                    getEditText().getBackground().mutate().setColorFilter(Color.parseColor(DEFAULT_COLOR), PorterDuff.Mode.SRC_ATOP);
            }

        });
    }

    public void clearErrors() {
        this.setError(null);
    }


    public boolean isValid() {
        return !CommonUtils.isNullOrEmpty(this.getText().toString());
    }

    @Override
    public void setError(CharSequence error) {


        this.errorText = error;

        if(error != null && (error.toString().equalsIgnoreCase("") || error.toString().equalsIgnoreCase(" "))) {

            isError= true;
            this.setErrorEnabled(false);
            this.getEditText().getBackground().mutate().setColorFilter(Color.parseColor(ERROR_COLOR), PorterDuff.Mode.SRC_ATOP);

        }else if(error == null) {
            this.getEditText().getBackground().mutate().clearColorFilter();
            isError = false;
            if(!this.getEditText().hasFocus())
                this.getEditText().getBackground().mutate().setColorFilter(Color.parseColor(DEFAULT_COLOR), PorterDuff.Mode.SRC_ATOP);
            else
                this.getEditText().getBackground().mutate().setColorFilter(Color.parseColor(HIGHLIGHT_COLOR), PorterDuff.Mode.SRC_ATOP);
            setErrorEnabled(false);
            super.setError(error);

//            this.setErrorEnabled(false);
//            clearErrors();
//            super.setError(error);
        }else
        {
//            this.getEditText().getBackground().mutate().clearColorFilter();
            this.getEditText().getBackground().mutate().setColorFilter(Color.parseColor(ERROR_COLOR), PorterDuff.Mode.SRC_ATOP);
            //this is the case when we need to set the error text and change the line color
            setErrorEnabled(true);
            isError = true;
//            this.getEditText().getBackground().mutate().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);;
            super.setError(error);

        }
    }





    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        adjustTopMargin();
        super.onLayout(changed, left, top, right, bottom);
    }

    private void adjustTopMargin() {
        MarginLayoutParams margins = MarginLayoutParams.class.cast(getLayoutParams());
        int margin =-dpToPx(14);
        margins.topMargin = margin;
        setLayoutParams(margins);
        this.setPadding(-dpToPx(4), 0, 0, 0);
    }

    private int dpToPx(int dp)
    {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    public boolean hasFocusOnEditText() {
        return getEditText().hasFocus();
    }

}