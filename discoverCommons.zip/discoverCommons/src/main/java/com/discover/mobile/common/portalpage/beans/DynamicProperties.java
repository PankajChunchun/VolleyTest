package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DynamicProperties implements Serializable {

    private static final long serialVersionUID = -8457321122272872524L;

    @SerializedName("whatsNewReminder")
    private String whatsNewReminder;

    @SerializedName("remindMeLater")
    private String remindMeLater;

    @SerializedName("pages")
    private List<Page> pages = new ArrayList<Page>();

    /**
     * @return The whatsNewReminder
     */
    public String getWhatsNewReminder() {
        return whatsNewReminder;
    }

    /**
     * @param whatsNewReminder The whatsNewReminder
     */
    public void setWhatsNewReminder(String whatsNewReminder) {
        this.whatsNewReminder = whatsNewReminder;
    }

    /**
     * @return The remindMeLater
     */
    public String getRemindMeLater() {
        return remindMeLater;
    }

    /**
     * @param remindMeLater The remindMeLater
     */
    public void setRemindMeLater(String remindMeLater) {
        this.remindMeLater = remindMeLater;
    }

    /**
     * @return The pages
     */
    public List<Page> getPages() {
        return pages;
    }

    /**
     * @param pages The pages
     */
    public void setPages(List<Page> pages) {
        this.pages = pages;
    }

}
