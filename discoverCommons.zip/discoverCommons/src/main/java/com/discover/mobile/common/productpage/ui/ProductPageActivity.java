package com.discover.mobile.common.productpage.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.DrawerBaseActivity;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.productpage.adapters.ProductListAdapter;
import com.discover.mobile.common.productpage.beans.ProductsContent;
import com.discover.mobile.common.productpage.beans.ProductsLink;
import com.discover.mobile.common.productpage.request.ProductRequestService;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.ui.modals.EnhancedContentModal;
import com.discover.mobile.network.error.bean.ErrorBean;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.TextView;

import java.util.List;


/**
 * A {@link NavigationRootActivity}, shows products list. It downloads JSON from
 * server and shows.
 *
 * @author pkuma13
 */
public class ProductPageActivity extends ActionBarBaseActivity implements OnClickListener, NetworkRequestListener, ErrorHandlerUi {

    private static final String TAG = ProductPageActivity.class.getSimpleName();
    boolean isCardSelected;
    private ExpandableListView mProductsList;
    private TextView mPrivacyText;
    private TextView mProvideFeedbackText;
    private ProductListAdapter mProductListAdapter;
    private ProductsContent mProductsContent;
    private Context mContext;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if(com.discover.mobile.common.Utils.checkPermissionTampering(this)){
            return;
        }

        initUI();
        initListeners();

        ProductRequestService productRequestService = new ProductRequestService(ProductPageActivity.this);
        productRequestService.getProductRequestCall(ProductPageActivity.this);
    }

    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }

    private void initUI() {
        //setBehindContentView(getBehindContentView());
        setContentView(R.layout.product_page_layout);
        //disableMenu();
        showBackX();

        DiscoverActivityManager.setActiveActivity(this);
        mPrivacyText = (TextView) findViewById(R.id.privacy_terms);
        mProvideFeedbackText = (TextView) findViewById(R.id.provide_feedback_button);

        mPrivacyText.setClickable(true);
        mProvideFeedbackText.setClickable(true);
        mProductsList = (ExpandableListView) findViewById(R.id.product_list_view);
        isCardSelected = getIntent().getBooleanExtra("Card_SELECTED", true);
        mContext = ProductPageActivity.this;
        if (isCardSelected)
            TrackingHelper.trackPageView(AnalyticsPage.PRODUCTS_PAGE);
        else
            TrackingHelper.trackBankPage(AnalyticsPage.PRODUCTS_PAGE);
    }

    private void initListeners() {
        mProductsList.setOnGroupClickListener(new OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {

                String item = mProductListAdapter.getGroup(groupPosition).getName();
                // Unique visitor analytics fix. Product page tags not available for bank side. So tags firing only at card side.
                if (isCardSelected) {

                    if (parent.isGroupExpanded(groupPosition)) {
                        System.out.println("------collapsed-------" + item);

                        if (item.contains("Credit Cards")) {
                            TrackingHelper.trackCardPageProp1(
                                    AnalyticsPage.PRODUCTS_PG_CREDIT_CARD_COLLAPSE,
                                    AnalyticsPage.PRODUCTS_PG_CREDIT_CARD_COLLAPSE);
                        } else if (item.contains("Banking")) {
                            TrackingHelper.trackCardPageProp1(
                                    AnalyticsPage.PRODUCTS_PG_BANKING_COLLAPSE,
                                    AnalyticsPage.PRODUCTS_PG_BANKING_COLLAPSE);
                        } else {
                            TrackingHelper.trackCardPageProp1(
                                    AnalyticsPage.PRODUCTS_PG_LOANS_COLLAPSE,
                                    AnalyticsPage.PRODUCTS_PG_LOANS_COLLAPSE);
                        }

                    } else {
                        System.out.println("--------expanded-------" + item);
                        if (item.contains("Credit Cards")) {
                            TrackingHelper.trackCardPageProp1(
                                    AnalyticsPage.PRODUCTS_PG_CREDIT_CARD_EXPAND,
                                    AnalyticsPage.PRODUCTS_PG_CREDIT_CARD_EXPAND);
                        } else if (item.contains("Banking")) {
                            TrackingHelper.trackCardPageProp1(
                                    AnalyticsPage.PRODUCTS_PG_BANKING_EXPAND,
                                    AnalyticsPage.PRODUCTS_PG_BANKING_EXPAND);
                        } else {
                            TrackingHelper.trackCardPageProp1(
                                    AnalyticsPage.PRODUCTS_PG_LOANS_EXPAND,
                                    AnalyticsPage.PRODUCTS_PG_LOANS_EXPAND);
                        }
                    }

                }


                return false;
            }
        });

        mProductsList.setOnGroupExpandListener(new OnGroupExpandListener() {
            // Keep track of previous expanded parent
            int previousGroup = -1;

            @Override
            public void onGroupExpand(int groupPosition) {

                // Collapse previous parent if expanded.

                if ((previousGroup != -1) && (groupPosition != previousGroup)) {
                    mProductsList.collapseGroup(previousGroup);

                }
                previousGroup = groupPosition;
            }
        });

        mProductsList.setOnChildClickListener(new OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                ProductsLink clickedLink = mProductsContent.getCategories().get(groupPosition).getLinks().get(childPosition);
                if (isCardSelected) {
                    if (clickedLink.getName().contains("Credit Card")) {
                        TrackingHelper.trackCardPageProp1(
                                "PRODUCTS_PG_CREDIT_CARDS_" + clickedLink.getName().toUpperCase() + "_LNK",
                                "PRODUCTS_PG_CREDIT_CARDS_" + clickedLink.getName().toUpperCase() + "_LNK");
                    } else if (clickedLink.getName().contains("Credit Card")) {
                        TrackingHelper.trackCardPageProp1(
                                "PRODUCTS_PG_LOANS_" + clickedLink.getName().toUpperCase() + "_LNK",
                                "PRODUCTS_PG_LOANS_" + clickedLink.getName().toUpperCase() + "_LNK");
                    } else {
                        TrackingHelper.trackCardPageProp1(
                                "PRODUCTS_PG_BANKING_" + clickedLink.getName().toUpperCase() + "_LNK",
                                "PRODUCTS_PG_BANKING_" + clickedLink.getName().toUpperCase() + "_LNK");
                    }
                }

                final Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                browserIntent.setData(Uri.parse(clickedLink.getUrl()));
                startActivity(browserIntent);
                return false;
            }
        });

        mPrivacyText.setOnClickListener(this);
        mProvideFeedbackText.setOnClickListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        // disableMenu();
        setActionBarTitle(R.string.products, false);
        showBackX();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void showBackX() {
        setActionbarBackNavigation(new Runnable() {
            @Override
            public void run() {
                onBackPressed();
            }
        });
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (viewId == R.id.privacy_terms) {
            if (isCardSelected) {
                FacadeFactory.getCardFacade().navToPrivacyTerms(ProductPageActivity.this);
            } else {
                FacadeFactory.getBankLoginFacade().openPrivacyAndTerms();
            }
        } else if (viewId == R.id.provide_feedback_button) {
            if (isCardSelected) {
                FacadeFactory.getCardFacade().navToProvideFeedback(DiscoverActivityManager.getActiveActivity());
            } else {
                FacadeFactory.getBankLoginFacade().navigateToFeedback();
            }
        }
    }

    @Override
    public void onSuccess(Object data) {
        if (data != null) {
            mProductsContent = (ProductsContent) data;
            mProductListAdapter = new ProductListAdapter(this, mProductsContent);
            mProductsList.setAdapter(mProductListAdapter);
            // Show UI depends on update available status
            PortalUtils.hideSpinner(mContext);
        } else {
            onError(data);
        }
    }

    @Override
    public void onError(Object data) {
        if (data == null) {
            PortalUtils.hideSpinner(mContext);
        } else {
            // Product feature is available into prelogin. So no need to check for post/pre for
            // handling error.
            FacadeFactory.getPortalPageFacade().handleErrorScenario(
                    mContext, data);
        }
    }


    /**
     * Handles error if {@link ProductsRequest} called from pre-login and
     * service call gets failed.
     */
    private void handlePreLoginError(Object data) {
        /*commented below lines for using ErrorBean by 471532*/
       /* CardErrorBean cardError = (CardErrorBean) data;*/
        ErrorBean errorBean = (ErrorBean) data;
//        ErrorUtilityImpl errorUtility = ErrorUtilityImpl.getInstance();
//        String errorCode = errorUtility
//                .getHttpAndErrorStatus(errorBean);

        ErrorResponseDetails preAuthErrorBean = (ErrorResponseDetails) ((ErrorBean) errorBean).getErrorResponseHolder();
        String errorCode = preAuthErrorBean.status;

        if (null != errorBean && Integer.parseInt(errorCode) == Error.INTERNET_OFFLINE_ERROR || errorCode.startsWith("503")) {

            if (Integer.parseInt(errorCode) == Error.INTERNET_OFFLINE_ERROR) {
                final EnhancedContentModal modal1 = new EnhancedContentModal(mContext, R.string.E_T_4242, R.string.E_4242, R.string.close_text, null);
                ((DrawerBaseActivity) mContext).showCustomAlert(modal1);

            } else if (errorCode.contains(Error.SCHEDULED_MAINTANANCE_ERROR)) {
                final EnhancedContentModal modal1 = new EnhancedContentModal(mContext, R.string.E_T_5031006, R.string.mop_scheduled_maintainace_text, R.string.close_text, null);
                ((DrawerBaseActivity) mContext).showCustomAlert(modal1);
            } else if (errorCode.contains(Error.UN_SCHEDULED_MAINTANANCE_ERROR)) {
                final EnhancedContentModal modal1 = new EnhancedContentModal(mContext, R.string.E_T_5031007, R.string.mop_un_scheduled_maintainace_text, R.string.close_text, null);
                ((DrawerBaseActivity) mContext).showCustomAlert(modal1);
            } else {
                showSystemErrorMessage();
            }
        } else {
            showSystemErrorMessage();
        }

    }

    /**
     * This method is responsible to show system error message to screen
     */
    private void showSystemErrorMessage() {
        // TODO Set generic error message here.
//        Utils.log(TAG, "got error while requesting for products json");
    }

    @Override
    public TextView getErrorLabel() {
        return null;
    }

    @Override
    public List<EditText> getInputFields() {
        return null;
    }

    @Override
    public void showCustomAlert(AlertDialog alert) {

    }

    @Override
    public void showOneButtonAlert(int title, int content, int buttonText) {

    }

    @Override
    public void showDynamicOneButtonAlert(int title, String content, int buttonText) {

    }

    @Override
    public Context getContext() {
        return null;
    }

    @Override
    public int getLastError() {
        return 0;
    }

    @Override
    public void setLastError(int errorCode) {

    }

    @Override
    public ErrorHandler getErrorHandler() {
        return null;
    }

    /**
     * Constants for error handling.
     *
     * @author pkuma13
     */
    public final class Error {
        public static final int INTERNET_OFFLINE_ERROR = 4242;
        public static final String SCHEDULED_MAINTANANCE_ERROR = "1006";
        public static final String UN_SCHEDULED_MAINTANANCE_ERROR = "1007";
    }
}