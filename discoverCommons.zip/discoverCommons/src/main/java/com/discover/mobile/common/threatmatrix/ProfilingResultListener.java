package com.discover.mobile.common.threatmatrix;

import com.threatmetrix.TrustDefenderMobile.EndNotifier;

public interface ProfilingResultListener extends EndNotifier {
}
