package com.discover.mobile.common.highlightedfeatures.beans;

import com.google.gson.annotations.SerializedName;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;


/**
 * This modal represents a Highlighted feature.
 *
 * @author pkuma13
 */
public class FeatureContent implements Serializable, Parcelable {
    public static final Parcelable.Creator<FeatureContent> CREATOR = new Parcelable.Creator<FeatureContent>() {
        @Override
        public FeatureContent createFromParcel(Parcel in) {
            return new FeatureContent(in);
        }

        @Override
        public FeatureContent[] newArray(int size) {
            return new FeatureContent[size];
        }
    };
    @SerializedName("SupportedDevices")
    private ArrayList<String> supportedDevices;
    @SerializedName("AndroidImageUrls")
    private HFImage androidImageUrls;
    @SerializedName("Description")
    private String description;
    @SerializedName("ExcludedCardTypes")
    private ArrayList<String> nonSupportedCardTypes;
    @SerializedName("ShowDeepLink")
    private boolean showDeepLink;
    @SerializedName("ADAImageText")
    private String adaImageText;
    @SerializedName("DeepLinkCode")
    private String deepLinkCode;
    @SerializedName("DeepLinkText")
    private String deepLinkText;
    @SerializedName("KillSwitchText")
    private String killSwitchText;
    @SerializedName("Content")
    private String content;
    @SerializedName("analytics")
    private Analytics analytics;
    @SerializedName("Title")
    private String title;
    @SerializedName("CardSpecificImages")
    private boolean accountSpecificImages;
    @SerializedName("HeaderLabel")
    private String accountHeaderLabel;
    @SerializedName("ExcludedBankTypes")
    private ArrayList<String> nonSupportedBankTypes;
    @SerializedName("WhatsNewText")
    private String whatsNewText;
    @SerializedName("ApplyToCardSide")
    private boolean applyToCardSide = true;

    // ***********************************************************
    // ******* PARCELABLE Codes starts
    // ***********************************************************
    protected FeatureContent(Parcel in) {
        androidImageUrls = (HFImage) in.readValue(HFImage.class.getClassLoader());
        description = in.readString();
        showDeepLink = in.readByte() != 0x00;
        adaImageText = in.readString();
        deepLinkCode = in.readString();
        deepLinkText = in.readString();
        killSwitchText = in.readString();
        content = in.readString();
        analytics = (Analytics) in.readValue(Analytics.class.getClassLoader());
        title = in.readString();
        accountHeaderLabel = in.readString();
        whatsNewText = in.readString();
        accountSpecificImages = in.readByte() != 0x00;
        applyToCardSide = in.readByte() != 0x00;

        if (in.readByte() == 0x01) {
            supportedDevices = new ArrayList<String>();
            in.readList(supportedDevices, String.class.getClassLoader());
        } else {
            supportedDevices = null;
        }

        if (in.readByte() == 0x01) {
            nonSupportedCardTypes = new ArrayList<String>();
            in.readList(nonSupportedCardTypes, String.class.getClassLoader());
        } else {
            nonSupportedCardTypes = null;
        }

        if (in.readByte() == 0x01) {
            nonSupportedBankTypes = new ArrayList<String>();
            in.readList(nonSupportedBankTypes, String.class.getClassLoader());
        } else {
            nonSupportedBankTypes = null;
        }
    }

    public final ArrayList<String> getSupportedDevices() {
        return supportedDevices;
    }

    public final void setSupportedDevices(ArrayList<String> supportedDevices) {
        this.supportedDevices = supportedDevices;
    }

    public final HFImage getAndroidImageUrls() {
        return androidImageUrls;
    }

    public final void setAndroidImageUrls(HFImage androidImageUrls) {
        this.androidImageUrls = androidImageUrls;
    }

    public final String getDescription() {
        return description;
    }

    public final void setDescription(String description) {
        this.description = description;
    }

    public final ArrayList<String> getNonSupportedCardTypes() {
        return nonSupportedCardTypes;
    }

    public final void setNonSupportedCardTypes(ArrayList<String> NonSupportedCardTypes) {
        this.nonSupportedCardTypes = NonSupportedCardTypes;
    }

    public final boolean getShowDeepLink() {
        return showDeepLink;
    }

    public final String getAdaImageText() {
        return adaImageText;
    }

    public final void setAdaImageText(String adaImageText) {
        this.adaImageText = adaImageText;
    }

    public final String getDeepLinkCode() {
        return deepLinkCode;
    }

    public final void setDeepLinkCode(String deepLinkCode) {
        this.deepLinkCode = deepLinkCode;
    }

    public final String getDeepLinkText() {
        return deepLinkText;
    }

    public final void setDeepLinkText(String deepLinkText) {
        this.deepLinkText = deepLinkText;
    }

    public final String getContent() {
        return content;
    }

    public final void setContent(String content) {
        this.content = content;
    }

    public final Analytics getAnalytics() {
        return analytics;
    }

    public final void setAnalytics(Analytics analytics) {
        this.analytics = analytics;
    }

    public final String getTitle() {
        return title;
    }

    public final void setTitle(String title) {
        this.title = title;
    }

    public boolean isShowDeepLink() {
        return showDeepLink;
    }

    public final void setShowDeepLink(boolean showDeepLink) {
        this.showDeepLink = showDeepLink;
    }

    public boolean isAccountSpecificImages() {
        return accountSpecificImages;
    }

    public void setAccountSpecificImages(boolean accountSpecificImages) {
        this.accountSpecificImages = accountSpecificImages;
    }

    public String getKillSwitchText() {
        return killSwitchText;
    }

    public void setKillSwitchText(String killSwitchText) {
        this.killSwitchText = killSwitchText;
    }

    public final String getAccountHeaderLabel() {
        return accountHeaderLabel;
    }

    public void setAccountHeaderLabel(String accountHeaderLabel) {
        this.accountHeaderLabel = accountHeaderLabel;
    }

    public ArrayList<String> getNonSupportedBankTypes() {
        return nonSupportedBankTypes;
    }

    public String getWhatsNewText() {
        return whatsNewText;
    }

    public boolean isApplyToCardSide() {
        return applyToCardSide;
    }

    public void setApplyToCardSide(boolean applyToCardSide) {
        this.applyToCardSide = applyToCardSide;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(androidImageUrls);
        dest.writeString(description);
        dest.writeByte((byte) (showDeepLink ? 0x01 : 0x00));
        dest.writeString(adaImageText);
        dest.writeString(deepLinkCode);
        dest.writeString(deepLinkText);
        dest.writeString(killSwitchText);
        dest.writeString(content);
        dest.writeValue(analytics);
        dest.writeString(title);
        dest.writeString(accountHeaderLabel);
        dest.writeString(whatsNewText);
        dest.writeByte((byte) (accountSpecificImages ? 0x01 : 0x00));
        dest.writeByte((byte) (applyToCardSide ? 0x01 : 0x00));

        if (supportedDevices == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(supportedDevices);
        }

        if (nonSupportedCardTypes == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(nonSupportedCardTypes);
        }
        if (nonSupportedBankTypes == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(nonSupportedBankTypes);
        }
    }
    // ***********************************************************
    // ******* PARCELABLE Codes end
    // ***********************************************************
}