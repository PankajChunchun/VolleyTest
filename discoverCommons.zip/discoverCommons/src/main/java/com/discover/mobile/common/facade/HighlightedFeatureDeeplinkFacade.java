package com.discover.mobile.common.facade;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

/**
 * An interface to handle deeplinks for Highlighted features or Whatsnew.
 *
 * This interface should be extended by another facade interfaces for BANK, CARD and SSO.
 */

public interface HighlightedFeatureDeeplinkFacade {

    public void handlePreLoginClick(Activity activity, Bundle extras, String deeplinkCode);

    public void handlePostLoginClick(Activity activity, String deeplinkCode);

    public boolean isDeeplinkEnabled(Context context);
}
