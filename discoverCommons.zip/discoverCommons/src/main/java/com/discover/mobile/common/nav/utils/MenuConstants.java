package com.discover.mobile.common.nav.utils;

public class MenuConstants {
    public static final String ALL_DRAWER_ITEMS = "all";
    public static final String UNSUBSCRIBED_DRAWER_ITEMS = "unsubscribed";
    public static final String LOGIN_CARD = "cardlogin";
    public static final String LOGIN_BANK = "banklogin";
    public static final String METHOD = "method";
    public static final String FRAGMENT_METHOD = "Fragment & method";
    public static final String FRAGMENT = "Fragment";
    public static final String ACTIVITY = "Activity";
    public static final String ACTIVITY_METHOD = "Activity & method";
    ;
}
