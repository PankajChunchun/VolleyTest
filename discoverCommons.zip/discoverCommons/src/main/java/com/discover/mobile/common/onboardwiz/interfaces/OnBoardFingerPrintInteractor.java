package com.discover.mobile.common.onboardwiz.interfaces;

/**
 * Created by 436645 on 11/1/2016.
 */
public interface OnBoardFingerPrintInteractor {
    boolean isFingerprintHardwareAvailable();
    boolean isFingerPrintRegisteredOnDevice();
    boolean isPassCodeEnabled();
    void exitSetUp();
    boolean enableFingerPrint();
}
