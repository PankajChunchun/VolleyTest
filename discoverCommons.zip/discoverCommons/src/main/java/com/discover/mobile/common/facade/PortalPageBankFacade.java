package com.discover.mobile.common.facade;

import android.content.Context;

import com.discover.mobile.common.portalpage.utils.PortalAccountType;


/**
 * US29136: A facade to support bank portal page Deeplinks
 *
 * @author CTS
 */
public interface PortalPageBankFacade {

    //Portal page Deep link function to navigate to home screen
    void navToBankHome(Context portalPageContext, String selectedAccountIndex);

    //Portal page Deep link function to navigate to Deposit check
    void navToDepositCheck(Context portalPageContext, String selectedAccountIndex);

    //Portal page Deep link function to navigate to pay bills
    void navToPayBills(Context portalPageContext, String selectedAccountIndex);

    //Portal page Deep link function to navigate to Transfer money
    /* US113743-Android: Portal Enhancements: Quick Links: Transfer Money Analytics -
       Passing account type so that analytics logic can be handled at Bank side code */
    void navToTransferMoney(Context portalPageContext, String selectedAccountIndex, PortalAccountType portalAccountType);

    //Portal page Deep link function to navigate to Tax and Statement activity
    void navToStatements(Context portalPageContext, String selectedAccountIndex);

    //Portal page Deep link function to navigate to view activity
    void navToViewActivity(Context portalPageContext, String selectedAccountIndex, PortalAccountType portalAccountType);

    //Portal page Deep link function to navigate to make a payment
    void navToMakeAPayment(Context portalPageContext, String selectedAccountIndex);

    //Portal page Deep link function to navigate to pay loans added for US27022
    void navToPayLoans(Context portalPageContext, String selectedAccountIndex);

    void finishBankNavigationRootActivity();

    boolean isBankNewCbbFlow();

    void trackLinkTagWithProperties(String property, String prop3, String evar3, String evar35, boolean isSSOUser, String events);

    void trackPageTagsWithProperties(String pagename,String prop5, String evar5, String event, boolean isSSOUser);

}
