package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;

import java.io.Serializable;
import java.util.ArrayList;

public class LoanAccount implements Serializable, PortalBoxInterface {

    private static final long serialVersionUID = -2574126867438364885L;
    private final static String ACC_LOAN = "ACC_LOAN | ";

    @SerializedName("index")
    private Integer index;

    @SerializedName("currentAmountDue")
    private String currentAmountDue;

    @SerializedName("nextPymtDueDate")
    private String nextPymtDueDate;

    @SerializedName("accountTerm")
    private String accountTerm;

    @SerializedName("accessType")
    private String accessType;

    @SerializedName("lastFourAcctNbr")
    private String lastFourAcctNbr;

    @SerializedName("acctNickName")
    private String acctNickName;

    @SerializedName("acctType")
    private String acctType;

    @SerializedName("acctTypeDesc")
    private String acctTypeDesc;

    @SerializedName("acctStatus")
    private String acctStatus;

    @SerializedName("currentBalance")
    private String currentBalance;

    @SerializedName("availableBalance")
    private String availableBalance;

    @SerializedName("interestRate")
    private String interestRate;

    @SerializedName("apy")
    private String apy;

    @SerializedName("interestYearToDate")
    private String interestYearToDate;

    @SerializedName("fraudStatus")
    private String fraudStatus;

    @SerializedName("cashbackBonusBal")
    private String cashbackBonusBal;

    @SerializedName("FreezeReasonCodeList")
    private ArrayList<String> FreezeReasonCodeList = new ArrayList<String>();

    @SerializedName("vruFlag")
    private String vruFlag;

    @SerializedName("lastPymtReceivedAmt")
    private String lastPymtReceivedAmt;

    @SerializedName("lastPymtReceivedDate")
    private String lastPymtReceivedDate;

    /** start newly added field for US48093 changes */

    @SerializedName("isVerified")
    private Boolean isVerified;

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    /** end newly added field for US48093 changes */

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * @return The currentAmountDue
     */
    public String getCurrentAmountDue() {
        return currentAmountDue;
    }

    /**
     * @param currentAmountDue The currentAmountDue
     */
    public void setCurrentAmountDue(String currentAmountDue) {
        this.currentAmountDue = currentAmountDue;
    }

    /**
     * @return The nextPymtDueDate
     */
    public String getNextPymtDueDate() {
        return nextPymtDueDate;
    }

    /**
     * @param nextPymtDueDate The nextPymtDueDate
     */
    public void setNextPymtDueDate(String nextPymtDueDate) {
        this.nextPymtDueDate = nextPymtDueDate;
    }

    /**
     * @return The vruFlag
     */
    public String getVruFlag() {
        return vruFlag;
    }

    /**
     * @param vruFlag The vruFlag
     */
    public void setVruFlag(String vruFlag) {
        this.vruFlag = vruFlag;
    }

    public String getAccountTerm() {
        return accountTerm;
    }

    public void setAccountTerm(String accountTerm) {
        this.accountTerm = accountTerm;
    }

    public String getAccessType() {
        return accessType;
    }

    public void setAccessType(String accessType) {
        this.accessType = accessType;
    }

    public String getLastFourAcctNbr() {
        return lastFourAcctNbr;
    }

    public void setLastFourAcctNbr(String lastFourAcctNbr) {
        this.lastFourAcctNbr = lastFourAcctNbr;
    }

    public String getAcctNickName() {
        return acctNickName;
    }

    public void setAcctNickName(String acctNickName) {
        this.acctNickName = acctNickName;
    }

    public String getAcctType() {
        return acctType;
    }

    public void setAcctType(String acctType) {
        this.acctType = acctType;
    }

    public String getAcctTypeDesc() {
        return acctTypeDesc;
    }

    public void setAcctTypeDesc(String acctTypeDesc) {
        this.acctTypeDesc = acctTypeDesc;
    }

    public String getAcctStatus() {
        return acctStatus;
    }

    public void setAcctStatus(String acctStatus) {
        this.acctStatus = acctStatus;
    }

    public String getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(String currentBalance) {
        this.currentBalance = currentBalance;
    }

    public String getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(String availableBalance) {
        this.availableBalance = availableBalance;
    }

    public String getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(String interestRate) {
        this.interestRate = interestRate;
    }

    public String getApy() {
        return apy;
    }

    public void setApy(String apy) {
        this.apy = apy;
    }

    public String getInterestYearToDate() {
        return interestYearToDate;
    }

    public void setInterestYearToDate(String interestYearToDate) {
        this.interestYearToDate = interestYearToDate;
    }

    public String getFraudStatus() {
        return fraudStatus;
    }

    public void setFraudStatus(String fraudStatus) {
        this.fraudStatus = fraudStatus;
    }

    public String getCashbackBonusBal() {
        return cashbackBonusBal;
    }

    public void setCashbackBonusBal(String cashbackBonusBal) {
        this.cashbackBonusBal = cashbackBonusBal;
    }

    public ArrayList<String> getFreezeReasonCodeList() {
        return FreezeReasonCodeList;
    }

    public void setFreezeReasonCodeList(ArrayList<String> freezeReasonCodeList) {
        FreezeReasonCodeList = freezeReasonCodeList;
    }

    public String getLastPymtReceivedAmt() {
        return lastPymtReceivedAmt;
    }

    public void setLastPymtReceivedAmt(String lastPymtReceivedAmt) {
        this.lastPymtReceivedAmt = lastPymtReceivedAmt;
    }

    public String getLastPymtReceivedDate() {
        return lastPymtReceivedDate;
    }

    public void setLastPymtReceivedDate(String lastPymtReceivedDate) {
        this.lastPymtReceivedDate = lastPymtReceivedDate;
    }

    @Override
    public String getSortId() {
        return this.index != -1 ? this.ACC_LOAN.concat(String.valueOf(this.index)) : null;
    }
}
