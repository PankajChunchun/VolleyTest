package com.discover.mobile.common.login.beans;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by 407898 on 2/2/2016.
 */
public class InfoJsonData implements Serializable {


    @SerializedName("universalData")
    @Expose
    private InfoJsonUniversalData universalData;
    @SerializedName("isUniversalLaunched")
    @Expose
    private boolean isUniversalLaunched;

    public InfoJsonUniversalData getUniversalData() {
        return universalData;
    }

    public void setUniversalData(InfoJsonUniversalData universalData) {
        this.universalData = universalData;
    }

    public boolean getIsUniversalLaunched() {
        return isUniversalLaunched;
    }

    public void setIsUniversalLaunched(boolean isUniversalLaunched) {
        this.isUniversalLaunched = isUniversalLaunched;
    }
}
