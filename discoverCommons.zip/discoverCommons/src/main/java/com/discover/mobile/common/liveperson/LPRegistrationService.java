package com.discover.mobile.common.liveperson;

import android.app.IntentService;
import android.content.Intent;

import com.liveperson.messaging.sdk.api.LivePerson;

/**
 * Created by 436645 on 3/15/2017.
 */
public class LPRegistrationService extends IntentService {
    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */

    /** IDs from Live Persons Portal for Discover App */

    private static String TAG = LPRegistrationService.class.getSimpleName();

    public LPRegistrationService() {
        super(TAG);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        if(intent != null) {
            final String edsKey = intent.getStringExtra(LivePersonConstants.KEY_EDSKEY);
            LivePerson.registerLPPusher(LivePersonConstants.brandID, LivePersonConstants.appID, edsKey);
        }
    }
}
