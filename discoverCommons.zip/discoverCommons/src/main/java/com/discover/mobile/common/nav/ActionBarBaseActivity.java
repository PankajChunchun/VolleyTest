package com.discover.mobile.common.nav;

import com.google.gson.Gson;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.R;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.nav.configuration.CustomActionBarItemConfig;
import com.discover.mobile.common.nav.listener.IMenuEvenListener;
import com.discover.mobile.common.nav.modals.MenuItemBean;
import com.discover.mobile.common.nav.modals.MenuItemList;
import com.discover.mobile.common.shared.Globals;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Base activity which implements the Action bar display and population logic.
 * All the module  which need to have the Action bar should have
 * their container activities derived from this class.
 */
public abstract class ActionBarBaseActivity extends DiscoverBaseActivity {

    private IMenuEvenListener mListener;
    private Runnable mbackAction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //load the menu items in the action bar
        loadActionItems();
        //load the custom items if any
        if (getCustomActionBarItem() != null) {
            for (int i = 0; i < getCustomActionBarItem().size(); i++) {
                CustomActionBarItemConfig config = getCustomActionBarItem().get(i);
                addCustomActionItem(config.getItemDrawable(), config.getPosition(), config.getTitle());
                config.getInitItemAction().run();
            }
        }


        return true;
    }

    /**
     * This methods gets the menu to be loaded into the action bar and overflow
     *
     * @return Configuration Item for the menu,if passed null then menu will not be loaded
     */
    public abstract ActionBarConfiguration loadMenu();


    /**
     * This method will iterate on the menu list & load the menu
     *
     * @return true = menu is loaded ,false = menu is not present and not loaded
     */
    private boolean loadActionItems() {
        boolean isMenuLoaded = true;
        //get the menu JSON from the child implementation
        ActionBarConfiguration config = loadMenu();
        if (config != null) {
            String menuJson = config.getMenuJson();
            if (menuJson != null) {
                //get the menu list from the json
                ArrayList<MenuItemBean> menuList = parseAndLoadMenu(menuJson);

                if (menuList != null)
                    addMenuItems(menuList);
                //return true as we have menu items to be losaded

            }
            mListener = config.getmListener();
            isMenuLoaded = true;
        }

        return isMenuLoaded;

    }

    /**
     * This method will parse the JSON and return the list of the menu items
     *
     * @param menuJson Menu JSON
     * @return Arraylist of the menu items
     */
    private ArrayList<MenuItemBean> parseAndLoadMenu(String menuJson) {

        if (menuJson != null && menuJson.length() > 0) {
            String jsonList = loadJSONFromAsset(menuJson);
            Gson menuParser = new Gson();
            MenuItemList menuList = menuParser.fromJson(jsonList, MenuItemList.class);
            //check if the menu is created and return
            if (menuList != null)
                return menuList.getOverflowMenu();
        }

        return null;
    }

    /**
     * This method will add the menu item one by one to the action bar
     */
    private void addMenuItems(ArrayList<MenuItemBean> menuList) {
        for (Iterator<MenuItemBean> iterator = menuList.iterator(); iterator.hasNext(); ) {
            //iterate over the list and add the menu items
            MenuItemBean itemBean = iterator.next();
            /*Condition added to check whether the icon needs to be shown for every user or for the SSO user*/
            if (itemBean.isNormalUser()) {
                configureMenuItem(itemBean);
            } else if (Globals.isSSOUser) {
                configureMenuItem(itemBean);
            }
        }

    }

    /**
     * This method will configure each items as per the property for the item
     *
     * @param itemBean bean instance of the menu item
     */
    private void configureMenuItem(MenuItemBean itemBean) {
/*The title for the menu is mandatory and menu will not be added if the title is not set in the JSON
 */
        if (itemBean.getmTitle() != null && itemBean.getmTitle().length() > 0) {
            Menu menu = getToolBar().getMenu();
            MenuItem item = menu.add(Menu.NONE, Menu.NONE, itemBean.getmPosition(), itemBean.getmTitle());
            //check if the image is to be set for the menu item
            if (itemBean.getmMenuImage() != null) {
                Drawable menuIcon = getResources().getDrawable(getResources().getIdentifier(itemBean.getmMenuImage(), "drawable", getPackageName()));
                item.setIcon(menuIcon);
            }
            item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

        }

    }

    /**
     * Hides all the visible actionItems available in toolbar.
     */
    public void hideAllActionItems() {
        Toolbar mToolbar = getToolBar();
        int size = mToolbar.getMenu().size();
        Menu menu = mToolbar.getMenu();
        for (int i = 0; i < size; i++) {
            MenuItem item = menu.getItem(i);
            item.setVisible(false);
        }
    }

    /**
     * shows/un-hides all the invisible/hidden actionItems available in toolbar.
     */
    public void showAllActionItems() {
        Toolbar mToolbar = getToolBar();
        if (mToolbar != null && mToolbar.getMenu() != null) {
            int size = mToolbar.getMenu().size();
            Menu menu = mToolbar.getMenu();
            for (int i = 0; i < size; i++) {
                MenuItem item = menu.getItem(i);
                item.setVisible(true);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mListener != null && item.getItemId() != android.R.id.home) {
            //send the title of the item clicked
            mListener.onMenuItemClicked("" + item.getTitle());

        } else if (item.getItemId() == android.R.id.home) {
            handleBackNavigation(null);

        }
        //consume the item click
        return true;
    }

    protected void handleBackNavigation(Runnable backAction) {

        if (backAction != null) {
            //call sent by DrawerBaseActivity
            backAction.run();
        } else {
            //handle back navigation
            if (mbackAction != null) {
                mbackAction.run();
            } else {
                //default implementation when
                super.onBackPressed();
            }
        }
    }

    /* * Set title for the action bar
     * @param title title to be set
     *              @param withLogo true = show title with Discover logo,false = show only title without logo
     */
    public void setActionBarTitle(String title, boolean withLogo) {
        if(null!=getLeftLogo()) {
            getLeftLogo().setVisibility(View.GONE);
        }
        if(null!= getCenterLogo()) {
            getCenterLogo().setVisibility(View.GONE);
        }
        if(null!= getCenterTitle()) {
            getCenterTitle().setVisibility(View.GONE);
        }
        //set the text as Html for features that have special characters
        if(null != getSupportActionBar())
        getSupportActionBar().setTitle(Html.fromHtml(title));
        if (withLogo) {
            if(null != getToolBar())
            getToolBar().setLogo(R.drawable.appbar);
        } else {
            if(null != getToolBar())
            getToolBar().setLogo(null);
        }
    }


    /**
     * Set title for the action bar
     *
     * @param titleResource resource for title to be set
     * @param withLogo      true = show title with Discover logo,false = show only title without
     *                      logo
     */
    public void setActionBarTitle(int titleResource, boolean withLogo) {
        getCenterLogo().setVisibility(View.GONE);
        getCenterTitle().setVisibility(View.GONE);

        String title = "";
        try {
            title = getResources().getString(titleResource).toString();
        } catch (Resources.NotFoundException ex) {
            //No need to handle the exception as the variable is already initialised as empty string
        }
        //set the text as Html for features that have special characters
        getSupportActionBar().setTitle(Html.fromHtml(title));
        if (withLogo) {
            getToolBar().setLogo(R.drawable.appbar);
        } else {
            getToolBar().setLogo(null);
        }
    }

    /**
     * Clears the title from the action bar and sets the Discover Header logo
     */
    public void clearTitle() {
        getToolBar().setLogo(R.drawable.actionbar_logo);
        getSupportActionBar().setTitle("");
        getCenterLogo().setVisibility(View.GONE);
        getCenterTitle().setVisibility(View.GONE);
    }

    /**
     * Remove action bar item from the acion bar
     *
     * @param position position of the menu item to be removed
     * @return true = item was removed, false = item was not removed.Possible reason is that the
     * position is not valid.
     */
    protected boolean removeActionBarItems(int position) {
        boolean isItemRemoved = false;
        try {
            getToolBar().getMenu().getItem(position).setVisible(false);
            isItemRemoved = true;
        } catch (IndexOutOfBoundsException ex) {
            //Do nothing as we have not removed any item
        }
        return isItemRemoved;
    }

    /**
     * This method will add a back navigation in place of the hamburger
     *
     * @param backNavigationAction back navigation action,If passed as Null finish will be called on
     *                             the running activity
     */
    protected void setActionbarBackNavigation(final Runnable backNavigationAction) {
//        getToolBar().setNavigationIcon(R.drawable.header_back);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (backNavigationAction != null) {
            mbackAction = backNavigationAction;
        }
    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        super.setContentView(layoutResID);
        enableActionbar();


    }

    public void setTitleInCenter() {
        getCenterTitle().setText(getToolBar().getTitle());
        getToolBar().setTitle("");
        getCenterTitle().setVisibility(View.VISIBLE);
    }

    public void setLogoInCenter() {
        getSupportActionBar().setTitle(""); // added to clear default Discover Title
        getToolBar().setTitle("");
        getCenterLogo().setVisibility(View.VISIBLE);
    }

    protected void clearBackNavigation() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
    }


    /**
     * This method enabled the child implementation to add a custom menu items to the action bar
     *
     * @param resIcon  icon for the action item
     * @param position position at which it is to be placed.Please ensure that this position does
     *                 not conflict with the JSON passed.
     * @param title    title for the Item which is returned on item click
     */
    private MenuItem addCustomActionItem(int resIcon, int position, int title) {   //we are using title as id
        Menu menu = getToolBar().getMenu();
        MenuItem item = menu.add(Menu.NONE, Menu.NONE, position, title);
        item.setIcon(resIcon);
        item.setShowAsActionFlags(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return item;
    }

    /**
     * Child must override this method to load the custom Action bar items
     *
     * @return List of the Custom action bar item Configurations
     */
    public ArrayList<CustomActionBarItemConfig> getCustomActionBarItem() {

        return null;
    }


    public String loadJSONFromAsset(String JSONFile) {
        String json = null;
        try {
            InputStream is = DiscoverApplication.getGlobalContext().getAssets().open(JSONFile);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mListener = null;
        mbackAction = null;
    }
}
