package com.discover.mobile.common.fico.views;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.fico.bean.FicoCollapsedDetails;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import java.util.ArrayList;
import static android.content.Context.ACCESSIBILITY_SERVICE;
/**
 * Created by 451769 on 5/10/2017.
 */

public class FicoBoxView extends RelativeLayout {

    private Context mContext;
    private FicoUtils.FicoBoxType ficoBoxType = FicoUtils.FicoBoxType.NONE;
    private FicoBoxViewHolder ficoBoxViewHolder;
    private int position;
    private boolean isExapandDisabled;


    public FicoBoxView(Context context, int position) {
        super(context);
        mContext = context;
        this.position = position;
        initUI();
    }

    private void initUI() {
        inflate(mContext, R.layout.fico_collapsed_view_layout, this);
        setUpFicoBoxViewHolder();
    }

    private void setUpFicoBoxViewHolder() {
        ficoBoxViewHolder = new FicoBoxViewHolder();

        ficoBoxViewHolder.collapsedLayout = (RelativeLayout) findViewById(R.id.collapsed_layout);
        ficoBoxViewHolder.expandedLayout = (LinearLayout) findViewById(R.id.fico_expanded_layout);
        ficoBoxViewHolder.collapsedTitle = (TextView) findViewById(R.id.title);
        ficoBoxViewHolder.collapsedValue = (TextView) findViewById(R.id.value);
        ficoBoxViewHolder.expandedViewParaOne = (TextView) findViewById(R.id.fico_expanded_view_details_para_one);
        ficoBoxViewHolder.expandedViewParaTwo = (TextView) findViewById(R.id.fico_expanded_view_details_para_two);
        ficoBoxViewHolder.expandedViewScoreReview = (TextView) findViewById(R.id.expanded_box_score_review);
        ficoBoxViewHolder.expandedViewTableTitle = (TextView) findViewById(R.id.table_title);
        ficoBoxViewHolder.expandedViewValueOne = (TextView) findViewById(R.id.expanded_view_value_one);
        ficoBoxViewHolder.expandedViewValueTwo = (TextView) findViewById(R.id.expanded_view_value_two);
        ficoBoxViewHolder.expandedViewTitle = (TextView) findViewById(R.id.expanded_title);
        ficoBoxViewHolder.expanded_view_title_two = (TextView) findViewById(R.id.expanded_view_title_two);
        ficoBoxViewHolder.expanded_view_title_one = (TextView) findViewById(R.id.expanded_view_title_one);
        ficoBoxViewHolder.ficoBoxTableRowTwo = (LinearLayout) findViewById(R.id.fico_box_table_row_two_detail_two);
        ficoBoxViewHolder.expandedViewParaThree = (RelativeLayout) findViewById(R.id.fico_expanded_view_details_para_three);
        ficoBoxViewHolder.bulletOne = (TextView) findViewById(R.id.bullet_one);
        ficoBoxViewHolder.bulletPtOne = (TextView) findViewById(R.id.bullet_point_one);
        ficoBoxViewHolder.bulletTwo = (TextView) findViewById(R.id.bullet_two);
        ficoBoxViewHolder.bulletPtTwo = (TextView) findViewById(R.id.bullet_point_two);
        ficoBoxViewHolder.bulletThree = (TextView) findViewById(R.id.bullet_three);
        ficoBoxViewHolder.bulletPtThree = (TextView) findViewById(R.id.bullet_point_three);
        ficoBoxViewHolder.verticalColorView = (View) findViewById(R.id.collapsed_vertical_color_view);
        ficoBoxViewHolder.downChevron = (ImageView) findViewById(R.id.up_down_chevron);
        ficoBoxViewHolder.ficoBoxTableRowTwo = (LinearLayout) findViewById(R.id.fico_box_table_row_two_detail_two);
        ficoBoxViewHolder.expandedViewParaThree = (RelativeLayout) findViewById(R.id.fico_expanded_view_details_para_three);
        ficoBoxViewHolder.collapsedVerticalClrView = findViewById(R.id.collapsed_vertical_color_view);
        ficoBoxViewHolder.expandedHorizontalClrView = findViewById(R.id.expanded_box_color_view);

    }


    public void mapViewWithData(FicoUtils.FicoBoxType boxType, int position, ArrayList<FicoCollapsedDetails> ficoCollapsedDetails, boolean isExpandDisabled) {
        boolean isRunningOnHandset = false;
        if (CommonUtils.isRunningOnHandset(mContext)) {
            isRunningOnHandset = true;
        }
        switch (boxType) {
            case ACCOUNT_DETAILS_BOX_COLLAPSED:
                final FicoCollapsedDetails ficoCollapsedDetailsItem = ficoCollapsedDetails.get(position);
                if (ficoCollapsedDetailsItem.getCollapsedBoxTitle().equals(mContext.getResources().getString(R.string.cmn_fico_total_accounts_box_title))) {
                    if (isRunningOnHandset) {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_total_accounts_para_one)));
                        ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_total_accounts_para_two)));
                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_total_accounts_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_total_account_link)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }

                    } else {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_total_accounts_para_one_tablet)));
                        ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_total_accounts_para_two_tablet)));

                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_total_accounts_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_total_account_link_tablet)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }
                    }
                    if (ficoCollapsedDetailsItem.getExpandedViewValueTwo() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueTwo()) >= 0) {
                        ficoBoxViewHolder.expandedViewValueTwo.setText(ficoCollapsedDetailsItem.getExpandedViewValueTwo());
                    } else {
                        ficoBoxViewHolder.expandedViewValueTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    if (ficoCollapsedDetailsItem.getExpandedViewValueThree() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueThree()) >= 0) {
                        ficoBoxViewHolder.expandedViewTableTitle.setText(ficoCollapsedDetailsItem.getExpandedViewValueThree() + " " + ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                    } else {
                        ficoBoxViewHolder.expandedViewTableTitle.setText(ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                    }
                    if (ficoCollapsedDetailsItem.getExpandedViewValueOne() != null) {
                        ficoBoxViewHolder.expandedViewValueOne.setText(ficoCollapsedDetailsItem.getExpandedViewValueOne());
                    } else {
                        ficoBoxViewHolder.expandedViewValueOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.collapsedTitle.setText(ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                    if (ficoCollapsedDetailsItem.getCollapsedBoxValue() != null && Double.parseDouble(ficoCollapsedDetailsItem.getCollapsedBoxValue()) >= 0) {
                        ficoBoxViewHolder.collapsedValue.setText(ficoCollapsedDetailsItem.getCollapsedBoxValue());
                    } else {
                        ficoBoxViewHolder.collapsedValue.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.expanded_view_title_one.setText(mContext.getResources().getString(R.string.cmn_fico_installment_loans_text));
                    ficoBoxViewHolder.expanded_view_title_two.setText(mContext.getResources().getString(R.string.cmn_fico_revolving_credit_text));
                    ficoBoxViewHolder.expandedViewParaThree.setVisibility(View.GONE);
                    if (ficoBoxViewHolder.expandedViewParaTwo.getVisibility() == View.VISIBLE) {
                        ficoBoxViewHolder.expandedLayout.setContentDescription((mContext.getResources().getString(R.string.cmn_fico_total_accounts_expanded_desc)));
                    }

                } else if (ficoCollapsedDetailsItem.getCollapsedBoxTitle().equals(mContext.getResources().getString(R.string.cmn_fico_length_of_credit_box_title))) {
                    if (isRunningOnHandset) {
                        ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_length_credit_para_two)));
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_length_credit_para_one)));

                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_length_credit_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_lenght_of_credit_link)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }

                    } else {
                        ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_length_credit_para_two_tablet)));
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_length_credit_para_one_tablet)));

                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_length_credit_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_lenght_of_credit_link_tablet)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }
                    }
                    ficoBoxViewHolder.expandedViewValueTwo.setVisibility(View.GONE);
                    ficoBoxViewHolder.expanded_view_title_one.setVisibility(View.GONE);
                    ficoBoxViewHolder.expanded_view_title_two.setVisibility(View.GONE);
                    if (ficoCollapsedDetailsItem.getExpandedViewValueOne() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueOne()) >= 0) {
                        ficoBoxViewHolder.expandedViewValueOne.setText(FicoUtils.getLengthOfCreditInMonthsYears(Integer.parseInt(ficoCollapsedDetailsItem.getExpandedViewValueOne())));
                    } else {
                        ficoBoxViewHolder.expandedViewValueOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.expandedViewTableTitle.setText(mContext.getResources().getString(R.string.cmn_fico_length_credit_box_table_title));
                    ficoBoxViewHolder.collapsedTitle.setText(ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                    if (ficoCollapsedDetailsItem.getCollapsedBoxValue() != null && Double.parseDouble(ficoCollapsedDetailsItem.getCollapsedBoxValue()) >= 0) {
                        ficoBoxViewHolder.collapsedValue.setText(FicoUtils.getLengthOfCredit(Integer.parseInt(ficoCollapsedDetailsItem.getCollapsedBoxValue()), mContext));
                    } else {
                        ficoBoxViewHolder.collapsedValue.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.ficoBoxTableRowTwo.setVisibility(View.GONE);
                    ficoBoxViewHolder.bulletPtOne.setText(mContext.getResources().getString(R.string.cmn_fico_length_credit_bullet_point_one));
                    ficoBoxViewHolder.bulletPtTwo.setText(mContext.getResources().getString(R.string.cmn_fico_length_credit_bullet_point_two));
                    ficoBoxViewHolder.bulletPtThree.setText(mContext.getResources().getString(R.string.cmn_fico_length_credit_bullet_point_three));
                    if (ficoBoxViewHolder.expandedViewParaTwo.getVisibility() == View.VISIBLE) {
                        ficoBoxViewHolder.expandedLayout.setContentDescription((mContext.getResources().getString(R.string.cmn_fico_length_credit_expanded_desc)));
                    }
                } else if (ficoCollapsedDetailsItem.getCollapsedBoxTitle().equals(mContext.getResources().getString(R.string.cmn_fico_inquiries_box_title))) {
                    if (isRunningOnHandset) {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_inquiries_para_one)));
                        linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_inquiries_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_inquires_link)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_inquiries_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_inquires_link)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }

                    } else {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_inquiries_para_one_tablet)));

                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_inquiries_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_inquires_link_tablet)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }
                    }
                    ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_inquiries_para_two)));
                    ficoBoxViewHolder.expandedViewValueTwo.setVisibility(View.GONE);
                    ficoBoxViewHolder.expanded_view_title_two.setVisibility(View.GONE);
                    ficoBoxViewHolder.expanded_view_title_one.setVisibility(View.GONE);
                    ficoBoxViewHolder.expandedViewTableTitle.setText(mContext.getResources().getString(R.string.cmn_fico_inquiries_box_table_title));
                    if (ficoCollapsedDetailsItem.getExpandedViewValueOne() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueOne()) >= 0) {
                        ficoBoxViewHolder.expandedViewValueOne.setText(ficoCollapsedDetailsItem.getExpandedViewValueOne());
                    } else {
                        ficoBoxViewHolder.expandedViewValueOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.collapsedTitle.setText(ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                    if (ficoCollapsedDetailsItem.getCollapsedBoxValue() != null && Double.parseDouble(ficoCollapsedDetailsItem.getCollapsedBoxValue()) >= 0) {
                        ficoBoxViewHolder.collapsedValue.setText(ficoCollapsedDetailsItem.getCollapsedBoxValue());
                    } else {
                        ficoBoxViewHolder.collapsedValue.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.ficoBoxTableRowTwo.setVisibility(View.GONE);
                    ficoBoxViewHolder.expandedViewParaThree.setVisibility(View.GONE);
                    if (ficoBoxViewHolder.expandedViewParaTwo.getVisibility() == View.VISIBLE) {
                        ficoBoxViewHolder.expandedLayout.setContentDescription((mContext.getResources().getString(R.string.cmn_fico_inquiries_expanded_desc)));
                    }
                } else if (ficoCollapsedDetailsItem.getCollapsedBoxTitle().equals(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_box_title))) {
                    if (isRunningOnHandset) {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_para_one)));
                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_revolving_utilization_link)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }
                    } else {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_para_one_tablet)));
                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_para_one_tablet)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_revolving_utilization_link_tablet)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }
                    }
                    ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_para_two)));
                    ficoBoxViewHolder.expandedViewTableTitle.setText(mContext.getResources().getString(R.string.cmn_fico_utilization_box_table_title));
                    if (ficoCollapsedDetailsItem.getExpandedViewValueOne() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueOne()) >= 0) {
                        ficoBoxViewHolder.expandedViewValueOne.setText("$" + FicoUtils.getFormattedAmount(ficoCollapsedDetailsItem.getExpandedViewValueOne()));
                    } else {
                        ficoBoxViewHolder.expandedViewValueOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.collapsedTitle.setText(ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                    if (ficoCollapsedDetailsItem.getCollapsedBoxValue() != null && Double.parseDouble(ficoCollapsedDetailsItem.getCollapsedBoxValue()) >= 0) {
                        ficoBoxViewHolder.collapsedValue.setText(ficoCollapsedDetailsItem.getCollapsedBoxValue() + "%");
                    } else {
                        ficoBoxViewHolder.collapsedValue.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
//                        ficoBoxViewHolder.downChevron.setVisibility(View.INVISIBLE);
                    }
                    ficoBoxViewHolder.expanded_view_title_one.setText(mContext.getResources().getString(R.string.cmn_fico_total_balance_owed_text));
                    ficoBoxViewHolder.expanded_view_title_two.setText(mContext.getResources().getString(R.string.cmn_fico_utilization_text));
                    if (ficoCollapsedDetailsItem.getExpandedViewValueTwo() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueTwo()) >= 0) {
                        ficoBoxViewHolder.expandedViewValueTwo.setText(ficoCollapsedDetailsItem.getExpandedViewValueTwo() + "%");
                    } else {
                        ficoBoxViewHolder.expandedViewValueTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.bulletPtOne.setText(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_bullet_point_one));
                    ficoBoxViewHolder.bulletPtTwo.setText(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_bullet_point_two));
                    ficoBoxViewHolder.bulletPtThree.setVisibility(View.GONE);
                    ficoBoxViewHolder.bulletThree.setVisibility(View.GONE);
                    if (ficoBoxViewHolder.expandedViewParaTwo.getVisibility() == View.VISIBLE) {
                        ficoBoxViewHolder.expandedLayout.setContentDescription((mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_expanded_desc)));
                    }
                } else if (ficoCollapsedDetailsItem.getCollapsedBoxTitle().equals(mContext.getResources().getString(R.string.cmn_fico_missed_payments_box_title))) {
                    if (isRunningOnHandset) {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_para_one)));
                        ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_para_two)));
                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_para_one)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_missed_payment_link)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }
                    } else {
                        ficoBoxViewHolder.expandedViewParaOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_para_one_tablet)));
                        ficoBoxViewHolder.expandedViewParaTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_para_two_tablet)));
                        if (FicoUtils.isTalkBackEnabled(mContext)) {
                            setTalkbackPerModel(ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        } else {
                            linkifyMessage(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_para_one_tablet)), CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_per_missed_payment_link_tablet)), ficoBoxViewHolder.expandedViewParaOne, ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                        }
                    }
                    if (ficoCollapsedDetailsItem.getExpandedViewValueOne() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueOne()) >= 0) {
                        ficoBoxViewHolder.expandedViewValueOne.setText(ficoCollapsedDetailsItem.getExpandedViewValueOne());
                    } else {
                        ficoBoxViewHolder.expandedViewValueOne.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.collapsedTitle.setText(ficoCollapsedDetailsItem.getCollapsedBoxTitle());
                    if (ficoCollapsedDetailsItem.getCollapsedBoxValue() != null && Double.parseDouble(ficoCollapsedDetailsItem.getCollapsedBoxValue()) >= 0) {
                        ficoBoxViewHolder.collapsedValue.setText(ficoCollapsedDetailsItem.getCollapsedBoxValue());
                    } else {
                        ficoBoxViewHolder.collapsedValue.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.expanded_view_title_one.setText(mContext.getResources().getString(R.string.cmn_fico_last_year_text));
                    ficoBoxViewHolder.expanded_view_title_two.setText(mContext.getResources().getString(R.string.cmn_fico_last_seven_year_text));
                    ficoBoxViewHolder.expandedViewTableTitle.setText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_box_table_title));
                    if (ficoCollapsedDetailsItem.getExpandedViewValueTwo() != null && Double.parseDouble(ficoCollapsedDetailsItem.getExpandedViewValueTwo()) >= 0) {
                        ficoBoxViewHolder.expandedViewValueTwo.setText(ficoCollapsedDetailsItem.getExpandedViewValueTwo());
                    } else {
                        ficoBoxViewHolder.expandedViewValueTwo.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_attribute_unavailable)));
                    }
                    ficoBoxViewHolder.bulletPtOne.setText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_bullet_point_one));
                    ficoBoxViewHolder.bulletPtTwo.setText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_bullet_point_two));
                    ficoBoxViewHolder.bulletPtThree.setText(mContext.getResources().getString(R.string.cmn_fico_missed_payments_bullet_point_three));
                    if (ficoBoxViewHolder.expandedViewParaTwo.getVisibility() == View.VISIBLE) {
                        ficoBoxViewHolder.expandedLayout.setContentDescription((mContext.getResources().getString(R.string.cmn_fico_missed_payments_expanded_desc)));
                    }
                }
                if (isExpandDisabled || ficoCollapsedDetailsItem.isBoxExpansionDisabled()) {
                    //  ficoBoxViewHolder.verticalColorView.setBackgroundColor(R.color.cmn_fico_score_grey_color);
                    ficoBoxViewHolder.downChevron.setVisibility(View.INVISIBLE);
                }
                if (ficoCollapsedDetailsItem.getBoxRating() != null) {
                    ficoBoxViewHolder.expandedViewScoreReview.setText(ficoCollapsedDetailsItem.getBoxRating());
                } else {
                    ficoBoxViewHolder.expandedViewScoreReview.setText(CommonUtils.getHtmlFormattedText(mContext.getResources().getString(R.string.cmn_fico_rating_attribute_unavailable)));
                }
                ficoBoxViewHolder.expandedViewTitle.setText(ficoCollapsedDetailsItem.getCollapsedBoxTitle());

                int ratingCodeColor = ficoCollapsedDetailsItem.getRatingColorValue();
                if (isExpandDisabled || ficoCollapsedDetailsItem.isBoxExpansionDisabled()) {
                    ficoBoxViewHolder.collapsedVerticalClrView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color));
                }
                /*else if(ficoCollapsedDetailsItem.getCollapsedBoxTitle().equals(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_box_title)) && ficoCollapsedDetailsItem.getCollapsedBoxValue() == null){
                    ficoBoxViewHolder.collapsedVerticalClrView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.cmn_fico_score_grey_color));
                }*/
                else if (ratingCodeColor != 0) {
                    ficoBoxViewHolder.collapsedVerticalClrView.setBackgroundColor(ratingCodeColor);
                    ficoBoxViewHolder.expandedHorizontalClrView.setBackgroundColor(ratingCodeColor);
                }
        }

    }

    /*Start Changes for US116080*/

    /**
     * This method showing percentage Fico Score Model
     *
     * @param title
     * @param desp
     * @param collapsedBoxTitle
     */

    private void showPerFicoScoreModel(String title, String desp, final String collapsedBoxTitle) {
        final DiscoverAlertDialog percentageFicoSccreModel = new DiscoverAlertDialog();
        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View child = layoutInflater.inflate(R.layout.percentage_fico_score_model_layout, null);
        percentageFicoSccreModel.setTitle(CommonUtils.getHtmlFormattedText(title));
        percentageFicoSccreModel.setMessage(CommonUtils.getHtmlFormattedText(desp));
        percentageFicoSccreModel.setCustomContentView(child);
        ImageView precentageFicoScoreImg = (ImageView) child.findViewById(R.id.precentageFicoScoreImg);
        setFicoScorePerImage(collapsedBoxTitle, precentageFicoScoreImg);
        percentageFicoSccreModel.setPositiveButton(mContext.getResources().getString(R.string.cmn_fico_stdes_modal_close_btn_text), new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        percentageFicoSccreModel.setCanceledOnTouchOutside(false).show(DiscoverActivityManager.getActiveAppCompatActivity());

    }

    /**
     * This method set percentage Imagedepending upon Title
     *
     * @param title
     * @param ficoPerImage
     */
    private void setFicoScorePerImage(String title, ImageView ficoPerImage) {
        if (title.equals(mContext.getResources().getString(R.string.cmn_fico_total_accounts_box_title))) {
            ficoPerImage.setBackgroundResource(R.drawable.fico_circle_total_accounts);

        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_length_of_credit_box_title))) {
            ficoPerImage.setBackgroundResource(R.drawable.fico_circle_length_of_credit);

        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_inquiries_box_title))) {
            ficoPerImage.setBackgroundResource(R.drawable.fico_circle_inquiries);

        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_box_title))) {
            ficoPerImage.setBackgroundResource(R.drawable.fico_circle_credit_utilization);

        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_missed_payments_box_title))) {
            ficoPerImage.setBackgroundResource(R.drawable.fico_circle_missed_payments);

        }
    }

    /**
     * This method linkify the text
     *
     * @param completeMessage
     * @param linkifyText
     * @param text
     * @param collapsedBoxTitle
     */

    private void linkifyMessage(Spanned completeMessage, Spanned linkifyText, TextView text, final String collapsedBoxTitle) {
        SpannableString spannableString = new SpannableString(completeMessage);
        String message = completeMessage.toString();
        int startIndex = message.indexOf(linkifyText.toString());
        int lastIndex = startIndex + (linkifyText.length());
        ClickableSpan clickableSpanActivate = new ClickableSpan() {
            @Override
            public void onClick(View textView) {
                showPerFicoModelOnLinkClick(collapsedBoxTitle);
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(false);
            }
        };

        spannableString.setSpan(clickableSpanActivate, startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.setText(spannableString);
        text.setHighlightColor(getResources().getColor(android.R.color.transparent));
        text.setMovementMethod(LinkMovementMethod.getInstance());
    }


    /**
     * This method show model depending on title
     *
     * @param title
     */
    private void showPerFicoModelOnLinkClick(String title) {
        boolean isRunningOnHandset = false;
        if (CommonUtils.isRunningOnHandset(mContext)) {
            isRunningOnHandset = true;
        }
        if (title.equals(mContext.getResources().getString(R.string.cmn_fico_total_accounts_box_title))) {
            if (isRunningOnHandset) {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_total_account_title), mContext.getResources().getString(R.string.cmn_fico_score_per_total_account_desp), title);
            } else {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_total_account_title_tablet), mContext.getResources().getString(R.string.cmn_fico_score_per_total_account_desp_tablet), title);
            }
            FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_TOTAL_ACCOUNTS_IMPACT);
        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_length_of_credit_box_title))) {
            if (isRunningOnHandset) {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_length_of_credit_title), mContext.getResources().getString(R.string.cmn_fico_score_per_length_of_credit_desp), title);
            } else {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_length_of_credit_title_tablet), mContext.getResources().getString(R.string.cmn_fico_score_per_length_of_credit_desp_tablet), title);
            }
            FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_LENGT_OF_CREDIT_IMPACT);
        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_inquiries_box_title))) {
            if (isRunningOnHandset) {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_inquires_title), mContext.getResources().getString(R.string.cmn_fico_score_per_inquires_desp), title);
            } else {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_inquires_title_tablet), mContext.getResources().getString(R.string.cmn_fico_score_per_inquires_desp_tablet), title);
            }
            FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_INQUIRIES_IMPACT);
        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_revolving_utilization_box_title))) {
            if (isRunningOnHandset) {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_revolving_utilize_title), mContext.getResources().getString(R.string.cmn_fico_score_per_revolving_utilize_desp), title);
            } else {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_revolving_utilize_title_tablet), mContext.getResources().getString(R.string.cmn_fico_score_per_revolving_utilize_desp_tablet), title);
            }
            FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_REVOLVING_UTILIZATION_IMPACT);
        } else if (title.equals(mContext.getResources().getString(R.string.cmn_fico_missed_payments_box_title))) {
            if (isRunningOnHandset) {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_missed_payment_title), mContext.getResources().getString(R.string.cmn_fico_score_per_missed_payment_desp), title);
            } else {
                showPerFicoScoreModel(mContext.getResources().getString(R.string.cmn_fico_score_per_missed_payment_title_tablet), mContext.getResources().getString(R.string.cmn_fico_score_per_missed_payment_desp_tablet), title);
            }
            FicoUtils.trackFicoClickEvent(mContext, AnalyticsPage.FICO_CREDITSCORE_MISSED_PAYMENTS_IMPACT);
        }
    }
    /*End Changes for US116080*/

    public static class FicoBoxViewHolder {
        public RelativeLayout collapsedLayout;
        public LinearLayout expandedLayout, ficoBoxTableRowTwo;
        public TextView collapsedTitle, collapsedValue;
        public TextView expandedViewValueOne, expandedViewValueTwo, expandedViewParaOne, expandedViewParaTwo, expandedViewTableTitle, expandedViewScoreReview, expandedViewTitle, expanded_view_title_two, expanded_view_title_one;
        public RelativeLayout expandedViewParaThree;
        public View verticalColorView;
        public ImageView downChevron;
        public TextView bulletPtOne, bulletPtTwo, bulletPtThree, bulletOne, bulletTwo, bulletThree;
        public View collapsedVerticalClrView, expandedHorizontalClrView;
    }

   /* Start Changes for defect 17239*/
    /**
     * This method is called when talkback is ON for setting percentage Model won double clicked
     * @param expandedViewParaOne
     * @param title
     */
    private void setTalkbackPerModel(TextView expandedViewParaOne, final String title) {
        expandedViewParaOne.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showPerFicoModelOnLinkClick(title);
            }
        });
    }
 /* End Changes for defect 17239*/
}

