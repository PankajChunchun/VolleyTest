package com.discover.mobile.common.onboardwiz.fragment.passcode;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.onboardwiz.service.OnBoardServiceClass;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant.PASSCODE_PAGE_STATE;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.onboardwiz.utils.RibbenMessage;
import com.discover.mobile.common.portalpage.beans.User;
import com.discover.mobile.common.portalpage.utils.PortalSharedPreferenceUtil;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.shared.utils.TokenUtil;
import com.discover.mobile.common.ui.widgets.PasscodeCircularEditText;
import com.discover.mobile.common.uiwidget.CmnTextView;
import com.discover.mobile.network.error.bean.ErrorBean;
import com.discover.mobile.network.error.bean.ErrorResponseDetails;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.res.ResourcesCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;

import static com.discover.mobile.common.onboardwiz.utils.OnBoardConstant.PASSCODE_PAGE_STATE.CREATE_PAGE;

/**
 * Created by 494005 on 4/25/2016.
 * This class act as a base class for onboarding related passcode fragment
 * (Passcode already existing & Create passcode and for Verify passcode)
 */
public class OnBoardBasePasscodeFragment extends Fragment implements View.OnClickListener, RibbenMessage.TimeOutListener {
    /* Constants related to completion flow animation */
    private final static long PASSCODE_ZOOM_IN_TIME = 400;
    private final static long PASSCODE_FADE_OUT_TIME = 200;
    private final static long PASSCODE_FADE_IN_TIME = 200;
    private final static float PASSCODE_ZOOM_FACTOR = 1.465346f;
    private final static float PASSCODE_ZOOM_PIVOT = 0.5f;
    private final static float PASSCODE_ZOOM_SIZE = 148f;
    private final static float PASSCODE_TRANSLATE = 70f;
    private final static float PASSCODE_BUBBLE_SLIDE_DISTANCE = 186f;
    private final static long PASSCODE_BUBBLE_EXIT_TIME = 300;
    private final static long PASSCODE_BUBBLE_ENTER_TIME = 400;
    /* Constants related to Image and layout Animation */
    private final static long PASSCODE_IMAGE_ZOOM_IN_TIME = 300;
    private final static long PASSCODE_OFFSET_TIME = 100;
    private final static float PASSCODE_LAYOUT_TRANSLATE = 128f;
    public static boolean isResetFlow = false;
    static PasscodeCircularEditText[] fieldTVs = new PasscodeCircularEditText[4];
    private PASSCODE_PAGE_STATE state;
    private View mView;
    private CmnTextView link, msg;
    private boolean isValid;
    private String deviceToken;
    private OnBoardServiceClass onBoardServiceClass;
    private Context mContext;
    private String strPasscodeValue;
    private ImageView mPasscodeImage;
    private TextView mPasscodeEnableText;
    private LinearLayout mPasscodeEditLayout;
    /* Animation objects declaration related to completion flow animation */
    private Animation mFadeOutCompletionAnimation;
    private Animation mFadeInCompletionAnimation;
    private AnimationSet mCompletionAnimSet;
    private AnimationSet mZoomAnimationSet;
    private static final String PASSCODEIMGTAG="passcodeImage";
    private static final String PASSCODEIMGEXISTINGTAG="passcodeExistingImage";
    private static final String PASSCODEIMGCREATETAG="passcodeCreateImage";
    private static final String PASSCODEIMGVERIFYTAG="passcodeVerifyImage";

    public static TextView deleteLatestInput() {
        for (int i = fieldTVs.length - 1; i >= 0; i--) {
            if (fieldTVs[i].length() > 0) {
                clearField(fieldTVs[i]);
                return fieldTVs[i];
            }
        }
        return fieldTVs[0];
    }

    private static void clearField(final TextView paramTextView) {
        paramTextView.setText("");
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.onboard_create_passcode, null);
        Bundle arg = getArguments();
        OnBoardHelper.hideExitButton(getActivity());
        setUpState((PASSCODE_PAGE_STATE) arg.getSerializable(OnBoardConstant.PASSCODE_STATE_KEY));
        onBoardServiceClass = new OnBoardServiceClass(mContext);
        init(mView);
        if (Globals.isFromCardSide()) {
//US53328-START
            analyticForOnLoad();
            //END
        }

        return mView;
    }

    /**
     * Initializes all UI components based on the current state.
     */
    private void init(View view) {
        msg = (CmnTextView) mView.findViewById(R.id.passcode_msg);
        deviceToken = TokenUtil.genClientBindingToken();
        link = (CmnTextView) mView.findViewById(R.id.passcode_info_link);
        fieldTVs[0] = (PasscodeCircularEditText) view.findViewById(R.id.passcode01);
        fieldTVs[1] = (PasscodeCircularEditText) view.findViewById(R.id.passcode02);
        fieldTVs[2] = (PasscodeCircularEditText) view.findViewById(R.id.passcode03);
        fieldTVs[3] = (PasscodeCircularEditText) view.findViewById(R.id.passcode04);
        mPasscodeImage = (ImageView) view.findViewById(R.id.passcode_image);
        mPasscodeEnableText = (TextView) view.findViewById(R.id.txt_passcode_enable);
        mPasscodeEditLayout = (LinearLayout) view.findViewById(R.id.passcode_edit_layout);
        setUpImageForPasscode();
        /**
         * setting up data to UI elemens
         */
        switch (state) {
            case EXISTING_PAGE:
                mPasscodeImage.setTag(PASSCODEIMGEXISTINGTAG);

                initUIforExisting();
                break;
            case CREATE_PAGE:
                mPasscodeImage.setTag(PASSCODEIMGCREATETAG);

                initUIforCreate();
                break;
            case VERIFY_PAGE:
                mPasscodeImage.setTag(PASSCODEIMGVERIFYTAG);
                //initUIforVerify(); -- this method is now called at the end of slide animation
                bubbleEditBoxSlideInSlideOutAnimation();
                break;
        }

        link.setOnClickListener(this);

        //need to find out proper place and better solution for this it's temp fix.
        OnBoardHelper.showKeyBoardWithDelayOnView(fieldTVs[0]);

        //setting up the passcode entering component.
        setupPasscode();

        //Condition check to verify whether user already set passcode based on this forgot password no animation blocked.
        // if (!((OnBoardPasscodeContainerFragment) getParentFragment()).isPasscodeEnabled())
        //Updated this condition to perform animation for only create page.
        if (!((OnBoardPasscodeContainerFragment) getParentFragment()).isPasscodeEnabled() && !state.equals(PASSCODE_PAGE_STATE.VERIFY_PAGE)) {
            //Function to set animation on image and layout file
            passcodeZoomInAnimation();
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.passcode_info_link) {
            //US53328-STARTS
            if (Globals.isFromCardSide()) {
                if (link.getText().toString().equalsIgnoreCase("Forgot Passcode?")) {
                    analyticsForForgotPasscodeLink();
                } else {
                    analyticsPasscodeGuideline();
                }

            }
            //ENDS
            linkClicked();
        }
    }

    /**
     * controls the click event to the link available in UI.
     * ( this link can only be "Forgot Passcode ?" or "Passcode Guideline")
     */
    private void linkClicked() {
        switch (state) {
            case EXISTING_PAGE:
                changeStateTo(CREATE_PAGE, null);
                isValid = OnBoardHelper.isPasscodeValidLocally(getPasscodeString());
                /*//US53334 Start-OnBoarding analytics
                if (Globals.isBankLoginSelected()) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passoce_step2));
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_13, AnalyticsPage.ONBOARDWIZ_ENTER_PASSCODE_PAGE_NAME);
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                }
                //US53334 End*/
                if (isValid) {
                    validatePasscode();
                }
                break;
            case CREATE_PAGE:
                //US53334 Start-OnBoarding analytics
                if (Globals.isBankLoginSelected()) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passoce_step2));
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_13, AnalyticsPage.ONBOARDWIZ_CREATE_PASSCODE_PAGE_NAME);
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                }
                //US53334 End
                OnBoardHelper.showGuidelines(getActivity());
                break;
        }
    }

    /**
     * inilializes the data to UI elements for VerifyPasscode state.
     */
    private void initUIforVerify() {

        msg.setText(getString(R.string.onboard_passcode_verify_copy));
        msg.setContentDescription(getString(R.string.onboard_passcode_verify_copy));
        link.setVisibility(View.GONE);
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    (R.string.bank_analytics_onboard_passcode_verify));

        }
        //US53334 End

    }

    /**
     * inilializes the data to UI elements for CreatePasscode state.
     */
    private void initUIforCreate() {
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    getString((R.string.bank_analytics_onboard_create_passoce), "Create_Passcode"));

        }
        //US53334 End

        msg.setText(getString(R.string.onboard_create_passcode));
        msg.setContentDescription(getString(R.string.onboard_create_passcode));
        link.setText(getString(R.string.onboard_guidelines_label));
        link.setContentDescription(getString(R.string.onboard_guidelines_label) + " " + getString(R.string.link_content_desc));

        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put(
                    AnalyticsPage.CONTEXT_PROPERTY_1, getResources().getString(R.string.bank_analytics_onboard_passcode_forgot_passcode_link));
            extras.put(
                    AnalyticsPage.CONTEXT_PROPERTY_13, AnalyticsPage.ONBOARDWIZ_ENTER_PASSCODE_PAGE_NAME);
            extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
            TrackingHelper.trackBankPage(null, extras);
        }
        //US53334 End
    }

    /**
     * inilializes the data to UI elements for ExistingPasscode state.
     */
    private void initUIforExisting() {
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    getString((R.string.bank_analytics_onboard_create_passoce), "Enter_Passcode"));

        }
        //US53334 End
        msg.setText(getString(R.string.onboard_existing_pascode_copy_text));
        msg.setContentDescription(getString(R.string.onboard_existing_pascode_copy_text));
        link.setText(getString(R.string.onboard_forgot_passcode_label));
        link.setContentDescription(getString(R.string.onboard_forgot_passcode_label) + " " + getString(R.string.link_content_desc));

    }

    private void setupPasscode() {
        setupPasscodeField(0);
        setupPasscodeField(1);
        setupPasscodeField(2);
        setupSubmit();
    }

    private void setupPasscodeField(final int fieldInt) {
        final PasscodeCircularEditText et = fieldTVs[fieldInt];
        et.setFillColor(R.color.onboard_circular_text_fill_color);
        et.setOnTouchListener(new PasscodeTouchListner(fieldInt));
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(final Editable paramAnonymousEditable) {
                validatePasscodeField(fieldInt);
            }

            @Override
            public void beforeTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }

            @Override
            public void onTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }
        });
    }

    private boolean validatePasscodeField(final int paramInt) {
        advanceInput(paramInt).requestFocus();
        return true;
    }

    private TextView advanceInput(final int currentIndex) {
        if (currentIndex < fieldTVs.length - 1) {
            return fieldTVs[currentIndex + 1];
        } else if (currentIndex < 0) {
            return fieldTVs[0];
        } else {
            return fieldTVs[fieldTVs.length - 1];
        }
    }

    @Override
    public void onTimeOut() {
        //US54329: Feature Transitions code changes start
        //Once Animation is completed, remove the ribben message
        if (Globals.isBankLoginSelected())
            RibbenMessage.destroyRibben();
        //US54329: Feature Transitions code changes end
    }

    private int getNextInput() {
        for (int i = 0; i < fieldTVs.length; i++) {
            if (fieldTVs[i].length() == 0) {
                return i;
            }
        }
        return 0;
    }

    private void setUpImageForPasscode() {
        Drawable passcodeDrawable = ResourcesCompat.getDrawable(getResources(), Globals.isBankLoginSelected() ? R.drawable.onboard_passcode_bank : R.drawable.onboard_landing, null);
        mPasscodeImage.setImageDrawable(passcodeDrawable);
        mPasscodeImage.setTag(PASSCODEIMGTAG);
    }

    private void setupSubmit() {
        final int fieldInt = 3;
        final PasscodeCircularEditText et = fieldTVs[fieldInt];
        et.setFillColor(R.color.onboard_circular_text_fill_color);
        et.setOnTouchListener(new PasscodeTouchListner(fieldInt));
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() != 0) {
                    submitCall();
                    clearAllField();
                }
            }
        });
    }

    private void submitCall() {
        switch (state) {
            case EXISTING_PAGE:
                this.storePasscodeForFingerPrint(); //nk
                if (Globals.isBankLoginSelected()) {
                    isResetFlow = false;
                    verifyPasscodeBank();

                } else
                    matchPasscode();
                //OnBoardHelper.hideKeyboard(getActivity().getApplicationContext(), mView);
                break;
            case CREATE_PAGE:
                isValid = OnBoardHelper.isPasscodeValidLocally(getPasscodeString());
                if (isValid) {
                    this.storePasscodeForFingerPrint(); //nk
                    validatePasscode();

                } else {
                    if (Globals.isFromCardSide()) {
                        analyticForErrors();
                    }
                    showErrorMessage(R.string.create_passcode_ribbon_error);

                }
                break;
            case VERIFY_PAGE:
                isResetFlow = true;
                Bundle bundle = getArguments();
                boolean isMatching = bundle.getString(OnBoardConstant.PASSCODE_VALUE).equalsIgnoreCase(getPasscodeString());

                if (isMatching) {
                    this.storePasscodeForFingerPrint(); //nk
                    if (((OnBoardPasscodeContainerFragment) getParentFragment()).isPasscodeEnabled()) {
                        if (Globals.isBankLoginSelected()) {
                            resetPasscodeBank();
                        } else
                            resetPasscode();
                    } else {
                        if (Globals.isBankLoginSelected()) {
                            createPasscodeBank();
                        } else
                            createPasscodeCard();
                    }

                } else {

                    if (Globals.isFromCardSide()) {
                        analyticForErrors();
                    }
                    showErrorMessage(R.string.verify_passcode_ribbon_message);
                }
                //       OnBoardHelper.hideKeyboard(getActivity().getApplicationContext(), mView);
                break;
        }
    }

    private void storePasscodeForFingerPrint(){
        /**US79241- start*/
        if (FingerPrintUtils.isFingerprintHardwareAvailable(mContext)){
            FingerPrintUtils fingerPrintUtils = new FingerPrintUtils(mContext);
            fingerPrintUtils.storePasscodeForFingerPrint(getPasscodeString());
        }
    }

    private void removePasscodeForFingerPrint(){
        /**US79241- start*/
        final FingerPrintUtils fingerPrintUtils = new FingerPrintUtils(mContext);
        if(!fingerPrintUtils.getFingerPrintStatus())
            fingerPrintUtils.removeFingerprintPasscode();
        /**US79241- end*/
    }

    private void createPasscodeCard() {
        onBoardServiceClass.createPasscodeCard(mContext, OnBoardHelper.getDeviceToken(), getPasscodeString(), this);
    }

    private void matchPasscode() {
        onBoardServiceClass.matchPasscodeCard(mContext, getPasscodeString(), this);
    }

    public void navToPasscodeSuccess() {
        if(PasscodeUtils.ssouser) {
            User.getInstance().setPasscodeToken(getPasscodeString());
            PortalSharedPreferenceUtil.getInstance().saveOrUpdatePasscodeToUserSharedPref();
        }
        if (!Globals.isBankLoginSelected) {
            PasscodeUtils passcodeUtils = new PasscodeUtils(getActivity());
            try {
                passcodeUtils.createPasscodeToken(deviceToken);
            } catch (Exception e) {
                e.printStackTrace();
            }

            FacadeFactory.getCardOnBoardFacadeImpl().enablePasscodeState(mContext);
        }
        OnBoardHelper.hideKeyboard(getActivity(), mView);
        if (this != null && this.isVisible()) {
            passcodeCompletionZoomAnimation();
            PasscodeFadeInFadeOutAnimation();
        }

        //((OnBoardPasscodeContainerFragment) getParentFragment()).pushFragment(new OnBoardPasscodeSuccessFragment(), true);

    }

    public void bindDeviceRequest() {
        if (Globals.isBankLoginSelected()) {
            //US58189:Passcode retro changes start
            onBoardServiceClass.bindRequestBank(mContext, OnBoardHelper.getDeviceToken(), false, this);
            //US58189:Passcode retro changes end
        } else
            onBoardServiceClass.bindRequestCard(mContext, getPasscodeString(), OnBoardHelper.getDeviceToken(), this);

    }

    private void validatePasscode() {
        if (Globals.isBankLoginSelected())
            onBoardServiceClass.validatePasscodeBank(mContext, getPasscodeString(), OnBoardHelper.getDeviceToken(), this);
        else
            onBoardServiceClass.validatePasscodeCard(mContext, getPasscodeString(), this);


    }

    public void resetPasscode() {

        String passcodeTokenClear = null;
        PasscodeUtils passcodeUtils = new PasscodeUtils(getActivity());
        try {
            passcodeTokenClear = passcodeUtils.getClearPasscodeToken();
        } catch (Exception e) {
            // Utils.log(TAG, "onPasscodeSubmitEvent() gets Exception at pUtils.getClearPasscodeToken(): " + e);
            passcodeUtils.deletePasscodeToken();
        }
        // US37182 changes start - pkuma13
        deviceToken = passcodeTokenClear;
        onBoardServiceClass.resetPasscodeCard(mContext, deviceToken, getPasscodeString(), this);
    }

    private void createPasscodeBank() {
        onBoardServiceClass.createPasscodeBank(mContext, getPasscodeString(), OnBoardHelper.getDeviceToken(), this);
    }

    private void verifyPasscodeBank() {
        onBoardServiceClass.verifyPasscodeBank(mContext, getPasscodeString(), this);
    }

    private void resetPasscodeBank() {
        onBoardServiceClass.resetPasscodeBank(mContext, getPasscodeString(), OnBoardHelper.getDeviceToken(), this);
    }

    public void clearAllField() {
        clearField(fieldTVs[3]);
        clearField(fieldTVs[2]);
        clearField(fieldTVs[1]);
        clearField(fieldTVs[0]);
        fieldTVs[0].clearFocus();
        fieldTVs[0].requestFocus();
    }

    /**
     * sets up current state for current passcode fragment it could only be Create/Verify or
     * Existing.
     */
    private void setUpState(PASSCODE_PAGE_STATE state) {
        this.state = state;
        OnBoardPasscodeContainerFragment.updateState(state);
    }

    /**
     * navigate the flow to new provide state.
     */
    public void changeStateTo(PASSCODE_PAGE_STATE newState, String passcode) {
        clearAllField();
        Fragment navTo = new OnBoardBasePasscodeFragment();
        Bundle args = new Bundle();
        args.putSerializable(OnBoardConstant.PASSCODE_STATE_KEY, newState);
        args.putSerializable(OnBoardConstant.PASSCODE_VALUE, passcode);
        navTo.setArguments(args);
        ((OnBoardPasscodeContainerFragment) getParentFragment()).pushFragment(navTo, true);
    }

    /**
     * Generate string for entered passcode chars.
     */
    protected String getPasscodeString() {
        StringBuffer retVal = new StringBuffer();
        for (int i = 0; i < fieldTVs.length; i++) {
            retVal.append(fieldTVs[i].getText().toString());
        }
        return retVal.toString();
    }

    /**
     * Performs the zoom animation on the passcode image view.
     * To be called after the passcode is typed in the fourth edit text
     */
    private void passcodeCompletionZoomAnimation() {

        final int yDelta = OnBoardHelper.dpToPx(mContext, PASSCODE_TRANSLATE - 2);
        mCompletionAnimSet = new AnimationSet(true);
        mCompletionAnimSet.setFillAfter(true);
        mCompletionAnimSet.setDuration(PASSCODE_ZOOM_IN_TIME);
        mCompletionAnimSet.setInterpolator(new LinearInterpolator());
        final TranslateAnimation[] imageTranslate = {new TranslateAnimation(0, 0, 0, yDelta)};
        mCompletionAnimSet.addAnimation(imageTranslate[0]);
        final ScaleAnimation[] imageScale = {new ScaleAnimation(1f, PASSCODE_ZOOM_FACTOR, 1f, PASSCODE_ZOOM_FACTOR, ScaleAnimation.RELATIVE_TO_SELF, PASSCODE_ZOOM_PIVOT, ScaleAnimation.RELATIVE_TO_SELF, PASSCODE_ZOOM_PIVOT)};
        mCompletionAnimSet.addAnimation(imageScale[0]);
        mCompletionAnimSet.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                float yPosition = mPasscodeImage.getY();
                mPasscodeEnableText.setY(yPosition + OnBoardHelper.dpToPx(mContext, PASSCODE_ZOOM_SIZE) + yDelta);
                mPasscodeEnableText.setVisibility(View.VISIBLE);

                /**US79241- end*/
                ((OnBoardPasscodeContainerFragment) getParentFragment()).pushFragment(new OnBoardPasscodeSuccessFragment(), true);
                imageScale[0] = null;
                imageTranslate[0] = null;

            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        mPasscodeImage.startAnimation(mCompletionAnimSet);

    }

    /**
     * Performs the Fade out and Fade in  animation on the passcode success Text View.
     * To be called after the passcode is typed in the fourth edit text
     */
    private void PasscodeFadeInFadeOutAnimation() {
        mFadeOutCompletionAnimation = new AlphaAnimation(1.0f, 0.0f);
        mFadeOutCompletionAnimation.setDuration(PASSCODE_FADE_OUT_TIME);
        mFadeInCompletionAnimation = new AlphaAnimation(0.0f, 1.0f);
        mFadeInCompletionAnimation.setDuration(PASSCODE_FADE_IN_TIME);
        mFadeInCompletionAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mPasscodeEnableText.clearAnimation();
                mPasscodeEnableText.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });

        mFadeOutCompletionAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mPasscodeEditLayout.setVisibility(View.GONE);
                mPasscodeEnableText.startAnimation(mFadeInCompletionAnimation);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });

        mPasscodeEditLayout.startAnimation(mFadeOutCompletionAnimation);
    }

    /**
     * Performs the zoom in animation while opening the screen
     * Zoom in animation effect will be their for image and layout
     */
    private void passcodeZoomInAnimation() {
        //use full to set yaxis dp value
        int yDelta = OnBoardHelper.dpToPx(mContext, PASSCODE_TRANSLATE);
        //Initialize the Animation set object
        mZoomAnimationSet = new AnimationSet(true);
        mZoomAnimationSet.setFillAfter(true);
        //set Animation duration
        mZoomAnimationSet.setDuration(PASSCODE_IMAGE_ZOOM_IN_TIME);
        mZoomAnimationSet.setInterpolator(new LinearInterpolator());

        //Set the image translate Animation
        TranslateAnimation imageTranslateAnimation = new TranslateAnimation(0, 0, yDelta, 0);
        mZoomAnimationSet.addAnimation(imageTranslateAnimation);
        //clear this object
        imageTranslateAnimation = null;

        //update yDelta value for layout animation
        yDelta = OnBoardHelper.dpToPx(mContext, PASSCODE_LAYOUT_TRANSLATE);

        //Set the image Layout Animation
        TranslateAnimation layoutTranslateAnimation = new TranslateAnimation(0, 0, yDelta, 0);
        layoutTranslateAnimation.setDuration(PASSCODE_FADE_OUT_TIME);
        layoutTranslateAnimation.setStartOffset(PASSCODE_OFFSET_TIME);
        //Start the layout animation
        mPasscodeEditLayout.startAnimation(layoutTranslateAnimation);
        //Clear this object
        layoutTranslateAnimation = null;

        //Sset the image animation scale
        ScaleAnimation scaleAnimation = new ScaleAnimation(PASSCODE_ZOOM_FACTOR, 1f, PASSCODE_ZOOM_FACTOR, 1f, ScaleAnimation.RELATIVE_TO_SELF, PASSCODE_ZOOM_PIVOT, ScaleAnimation.RELATIVE_TO_SELF, PASSCODE_ZOOM_PIVOT);
        mZoomAnimationSet.addAnimation(scaleAnimation);
        //Clear this object
        scaleAnimation = null;
        //set the layout animation listener
        mZoomAnimationSet.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                //Clear layout animation
                mPasscodeEditLayout.clearAnimation();
                //clear image animation
                mPasscodeImage.clearAnimation();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        //Start the image animation
        mPasscodeImage.startAnimation(mZoomAnimationSet);

    }

    /**
     * (US54326)
     * Passcode bubble Edit box slide out after create passcode
     * and slide in bubble Edit box for Verify passcode
     */
    private void bubbleEditBoxSlideInSlideOutAnimation() {
        float slideOutDistance = OnBoardHelper.dpToPx(mContext, PASSCODE_BUBBLE_SLIDE_DISTANCE);
        float slideInDistance = OnBoardHelper.dpToPx(mContext, PASSCODE_BUBBLE_SLIDE_DISTANCE);
        final Animation[] mPasscodeBubbleTranslateAnimation = {new TranslateAnimation(0, -slideOutDistance, 0, 0)};
        mPasscodeBubbleTranslateAnimation[0].setDuration(PASSCODE_BUBBLE_EXIT_TIME);
        final Animation[] mPasscodeBubbleTranslateAnimation1 = {new TranslateAnimation(slideInDistance, 0, 0, 0)};
        mPasscodeBubbleTranslateAnimation1[0].setDuration(PASSCODE_BUBBLE_ENTER_TIME);
        mPasscodeBubbleTranslateAnimation[0].setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                initUIforVerify();
                mPasscodeEditLayout.invalidate();
                mPasscodeEditLayout.startAnimation(mPasscodeBubbleTranslateAnimation1[0]);
                mPasscodeBubbleTranslateAnimation[0].setAnimationListener(null);
                mPasscodeBubbleTranslateAnimation[0] = null;
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        mPasscodeBubbleTranslateAnimation1[0].setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mPasscodeBubbleTranslateAnimation1[0].setAnimationListener(null);
                mPasscodeBubbleTranslateAnimation1[0] = null;

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        mPasscodeEditLayout.startAnimation(mPasscodeBubbleTranslateAnimation[0]);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (mCompletionAnimSet != null && mFadeInCompletionAnimation != null && mFadeOutCompletionAnimation != null) {
            mCompletionAnimSet.setAnimationListener(null);
            mFadeInCompletionAnimation.setAnimationListener(null);
            mFadeOutCompletionAnimation.setAnimationListener(null);
        }
        //Clear the Animation objects
        if (mZoomAnimationSet != null) {
            mZoomAnimationSet.setAnimationListener(null);
        }
        mCompletionAnimSet = null;
        mFadeInCompletionAnimation = null;
        mFadeOutCompletionAnimation = null;
        mPasscodeImage = null;
        mZoomAnimationSet = null;
    }

    public void handleError(Object data) {
        //VOC- US123063

        ErrorResponseDetails errorResponseDetails = null;
        if(data instanceof ErrorBean &&  null != ((ErrorBean) data).getErrorResponseHolder()) {
            errorResponseDetails = (ErrorResponseDetails) ((ErrorBean) data).getErrorResponseHolder();
        }
        int errorLocal = -1;
        if (Globals.isFromCardSide()) {
            //US53328-START
            analyticForErrors();
            //END
        }
        switch (state) {
            case EXISTING_PAGE:
                if(errorResponseDetails!=null && errorResponseDetails.status.equalsIgnoreCase(OnBoardConstant.PASSCODE_LAST_ATTEMPT)) {
                    errorLocal = R.string.passcode_attempt_ribbon_message;
                }else if(errorResponseDetails!=null && errorResponseDetails.status.equalsIgnoreCase(OnBoardConstant.PASSCODE_TEMP_LOCKED)){
                    OnBoardHelper.hideKeyboard(getActivity(), mView);
                    OnBoardHelper.showTempPasscodeModal(mContext);
                }else {
                    errorLocal = R.string.verify_passcode_ribbon_message;
                }
                break;
            case CREATE_PAGE:

                errorLocal = R.string.create_passcode_ribbon_error;
                break;
            case VERIFY_PAGE:

                errorLocal = R.string.verify_passcode_ribbon_message;
                break;

            default:
                errorLocal = R.string.create_passcode_ribbon_error;
                break;
        }
        if(errorResponseDetails!=null && !errorResponseDetails.status.equalsIgnoreCase(OnBoardConstant.PASSCODE_TEMP_LOCKED)) {
            showErrorMessage(errorLocal);
        }

    }

    public void showErrorMessage(int errMessage) {
        this.removePasscodeForFingerPrint();
        RibbenMessage.purge();
        FrameLayout layout = (FrameLayout) getActivity().findViewById(R.id.container_view);
        RibbenMessage.make(this, layout, errMessage, RibbenMessage.LENGTH_LONG, RibbenMessage.ERROR, this).show();
    }

    //US53328-START
    public void analyticForOnLoad() {
        switch (state) {
            case EXISTING_PAGE:
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_ENTER_PASSCODE_PAGE_NAME, null);

                break;
            case CREATE_PAGE:
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_CREATE_PASSCODE_PAGE_NAME, null);

                break;

            case VERIFY_PAGE:
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_VERIFY_PASSCODE_PAGE_NAME, null);
                break;

        }
    }

    public void analyticsPasscodeGuideline() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_PASSCODE_GUIDELINES_PROP1);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_PASSCODE_GUIDELINES_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_PASSCODE_GUIDELINES_PEV1);


        switch (state) {
            case EXISTING_PAGE:
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_GUIDELINES_PROP13_ENTER);

                break;
            case CREATE_PAGE:
                extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_GUIDELINES_PROP13_CREATE);

                break;
        }

        TrackingHelper.trackCardPage(null, extras);


    }

    public void analyticsForForgotPasscodeLink() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        extras.put(getActivity().getString(R.string.prop1), AnalyticsPage.ONBOARDWIZ_PASSCODE_FORGOT_LINK_PROP1);
        extras.put(getActivity().getString(R.string.pe), AnalyticsPage.ONBOARDWIZ_PASSCODE_FORGOT_LINK_PE);
        extras.put(getActivity().getString(R.string.pev1), AnalyticsPage.ONBOARDWIZ_PASSCODE_FORGOT_LINK_PEV1);
        extras.put(getActivity().getString(R.string.prop13), AnalyticsPage.ONBOARDWIZ_PASSCODE_FORGOT_LINK_PROP13);
        TrackingHelper.trackCardPage(null, extras);


    }

    public void analyticForErrors() {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        switch (state) {
            case EXISTING_PAGE:
                extras.put("my.prop10", AnalyticsPage.ONBOARDWIZ_PASSCODE_ERROR_EXISTING);
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_ENTER_PASSCODE_PAGE_NAME, extras);


                break;
            case CREATE_PAGE:
                extras.put("my.prop10", AnalyticsPage.ONBOARDWIZ_PASSCODE_ERROR_CREATE_PAGE);
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_CREATE_PASSCODE_PAGE_NAME, extras);

                break;

            case VERIFY_PAGE:
                extras.put("my.prop10", AnalyticsPage.ONBOARDWIZ_PASSCODE_ERROR_VERIFY_PAGE);
                TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_VERIFY_PASSCODE_PAGE_NAME, extras);

                break;
            default:
                extras.put("my.prop10", AnalyticsPage.ONBOARDWIZ_PASSCODE_ERROR_DEFAULT);
                break;


        }


    }

    private class PasscodeTouchListner implements View.OnTouchListener {

        private final int fieldInt;

        public PasscodeTouchListner(final int fieldInt) {
            this.fieldInt = fieldInt;
        }

        @Override
        public boolean onTouch(final View v, final MotionEvent event) {
            final int nextInput = getNextInput();
            if (fieldInt != nextInput) {
                fieldTVs[fieldInt].clearFocus();
                fieldTVs[nextInput].requestFocus();
                OnBoardHelper.showKeyboard(getActivity(), fieldTVs[nextInput]);
                return true;
            }
            return false;
        }
    }


}




