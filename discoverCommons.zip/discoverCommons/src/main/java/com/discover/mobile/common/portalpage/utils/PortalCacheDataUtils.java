package com.discover.mobile.common.portalpage.utils;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.beans.PortalAccountDetails;
import com.discover.mobile.common.portalpage.beans.User;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.liveperson.messaging.sdk.api.callbacks.LogoutLivePersonCallback;

import java.util.ArrayList;

/**
 * Class to do cache related operation on response of "account-V2" service call.
 * It will cache separate "Card" & "Bank" accounts.
 *
 * @author slende
 */
public class PortalCacheDataUtils {

    private static PortalCacheDataUtils mInstance = null;

    private static Object mLock = new Object();
    public ArrayList<String> mBankAccountTypeList = null;
    /**
     * Account detail's in Key - value pair
     */
    AccountV2Details accountV2Details;
    /**
     * Unique identifier for selected account type "Card"
     */
    private String selectedAccKey;
    /**
     * Unique identifier for selected account type "Bank"
     */
    private Integer selectedAccIndex;
    private Boolean showPortalPage = false;
    private Boolean isPortalLaunchedFromSummaryIcon = false;

    public static PortalCacheDataUtils getPortalCacheDataUtilsInstance() {

        synchronized (mLock) {
            if (mInstance == null) {
                mInstance = new PortalCacheDataUtils();
            }
            return mInstance;
        }
    }

    public Boolean getIsPortalLaunchedFromSummaryIcon() {
        return isPortalLaunchedFromSummaryIcon;
    }

    public void setIsPortalLaunchedFromSummaryIcon(Boolean isPortalLaunchedFromSummaryIcon) {
        this.isPortalLaunchedFromSummaryIcon = isPortalLaunchedFromSummaryIcon;
    }

    /**
     * It store whole Card & Bank account's into cache
     */
    public void storePortalAccountDetails(PortalAccountDetails portalAccountDetails) {
        accountV2Details = new AccountV2Details();
        accountV2Details.setBankSummaryStatus(portalAccountDetails.getBankSummaryStatus());
        accountV2Details.setSSOUser(portalAccountDetails.getIsSSOUser());
        accountV2Details.setDynamicProperties(portalAccountDetails.getDynamicProperties());
        accountV2Details.setPartyId(portalAccountDetails.getPartyId());
        accountV2Details.setErrorRetrievingCardData(portalAccountDetails.getErrorRetrievingCardData());
        accountV2Details.setErrorRetrievingBankData(portalAccountDetails.getErrorRetrievingBankData());
        accountV2Details.setUserIdAvailable(portalAccountDetails.getIsUserIdAvailable());
        accountV2Details.setCardAccountsMap(portalAccountDetails.getCardAccounts());
        accountV2Details.setLoanAccountsMap(portalAccountDetails.getLoanAccounts());
        accountV2Details.setDepositAccountsMap(portalAccountDetails.getDepositAccounts());
        accountV2Details.setIraPlansMap(portalAccountDetails.getIraPlans());
        accountV2Details.setCustomerFirstName(portalAccountDetails.getCustomerFirstName());

        /**start newly added field for US48093 changes */
        accountV2Details.setIsEDSFiltered(portalAccountDetails.isEDSFiltered());
        accountV2Details.setIsMergeEligible(portalAccountDetails.isMergeEligible());
        accountV2Details.setJointCardsLastFourDigitList(portalAccountDetails.getJointCardsLastFourDigitList());
        /**end newly added field for US48093 changes */

        /** start Added for US38219 CLA merge intercept page */
        accountV2Details.setIsForceMerge(portalAccountDetails.isForceMerge());
        accountV2Details.setDynamicBannerMessages(portalAccountDetails.getDynamicBannerMessages());
        /** end Added for US38219 CLA merge intercept page */

        /**start Messaging Gateway Auth URL mapping */
        accountV2Details.setGatewayOauthURL(portalAccountDetails.getGatewayOauthURL());
        /**end Messaging Gateway Auth URL mapping */

        // US126324 Changes - start
        accountV2Details.setInitialSkipAttempt(portalAccountDetails.isInitialSkipAttempt());
        // US126324 Changes - end
        accountV2Details.setUserId(portalAccountDetails.getUserId());
        Globals.setSSOUser(portalAccountDetails.getIsSSOUser());
        checkIFNeedToShowPortalPage(portalAccountDetails);

        // Fix for passcode deletion
        PasscodeUtils.ssouser = portalAccountDetails.getIsSSOUser();
        if(Globals.isSSOUser() || PortalUtils.isMulticardUser())
            logOutFromLPSDK();
    }

    /**
     * Retrive AccountV2 details
     */
    public AccountV2Details getAccountV2Details() {
        return accountV2Details;
    }

    /**
     * Nullify account V2 object
     */
    public void nullifyAccountV2Details() {
        accountV2Details = null;
    }

    /**
     * Method to clear cache data on logout or timeout
     */
    public void clearPortalCache() {
        User.getInstance().resetUser();
        nullifyAccountV2Details();
        setIsPortalLaunchedFromSummaryIcon(false);
        setSelectedAccIndex(null);
        setSelectedAccKey(null);
        mInstance = null;
    }

    /**
     * Retrive selected account key.
     */
    public String getSelectedAccKey() {
        return this.selectedAccKey;
    }

    /**
     * Set selected account key.
     */
    public void setSelectedAccKey(String selectedAccKey) {
        this.selectedAccKey = selectedAccKey;
    }

    /**
     * It returns selected Account index for Bank Type of Account
     */
    public Integer getSelectedAccIndex() {
        return selectedAccIndex;
    }

    /**
     * It sets selected Account index for Bank Type of Account
     */
    public void setSelectedAccIndex(Integer selectedAccIndex) {
        this.selectedAccIndex = selectedAccIndex;
    }

    public boolean checkIFNeedToShowPortalPage(PortalAccountDetails portalAccountDetails) {
        int cardAccountCount = portalAccountDetails.getCardAccounts().size();
        int bankAccountCount = portalAccountDetails.getDepositAccounts().size() + portalAccountDetails.getLoanAccounts().size() + portalAccountDetails.getIraPlans().size();
        //if multiple card/bank combination
        if ((cardAccountCount > 1 || bankAccountCount > 1 || (cardAccountCount + bankAccountCount) > 1) || (Globals.isSSOUser)) {
            showPortalPage = true;
            //Globals.setCLAuser(true);// us20958 - nkaza
        }//if single card.
        else {
            //TODO: send account data for normal flow once integrated with services
            showPortalPage = false;
            //Globals.setCLAuser(false);// us20958 - nkaza
        }
        return showPortalPage;
    }

    public Boolean getIfPortalPageShown() {
        return this.showPortalPage;
    }

    /**
     * Added new setter method for show portalpage variable.
     * For 7.0 unified session bankside is going to use this variable to check portpage is shown or
     * not.
     * Accordingly in bankside flow will continue
     * This is used from login screen & bank logout it will set to false.
     */
    public void setPortalPageShown(boolean value) {
        this.showPortalPage = value;
    }

    // US45209 Changes as per Bank team Start
    private AccountV2Details fetchBankAccountDetails() {
        return PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
    }

    public void getBankAccountType() {
        ArrayList<String> bankAccount = new ArrayList<String>();
        AccountV2Details accountV2Details = fetchBankAccountDetails();
        for (int i = 0; i < accountV2Details.getDepositAccountsMap().size(); i++) {

            if (accountV2Details.getDepositAccountsMap().get(i).getAcctType().equalsIgnoreCase("001")) {
                bankAccount.add("SAVINGS");
            } else if (accountV2Details.getDepositAccountsMap().get(i).getAcctType().equalsIgnoreCase("002")) {
                bankAccount.add("CHECKING");
            } else if (accountV2Details.getDepositAccountsMap().get(i).getAcctType().equalsIgnoreCase("003")) {
                bankAccount.add("MMA");
            } else if (accountV2Details.getDepositAccountsMap().get(i).getAcctType().equalsIgnoreCase("004")) {
                bankAccount.add("CD");
            }
        }

        if (accountV2Details.getIraPlansMap().size() > 0) {
            bankAccount.add("IRA");
        }

        if (accountV2Details.getLoanAccountsMap().size() > 0) {
            bankAccount.add("DPL");
        }
        setList(bankAccount);
    }

    public ArrayList<String> getList() {
        return mBankAccountTypeList;
    }

    public void setList(ArrayList<String> list) {
        this.mBankAccountTypeList = list;
    }
    // US45209 Changes as per Bank team end

    /**
     * Method to update card details based on edsKey
     *
     * @param updatedCardData Added for US48093 changes
     */
    public void updateCardDetailsOnEdsKey(String edsKey, CardAccount updatedCardData) {
        if (null != accountV2Details & null != edsKey) {
            accountV2Details.getCardAccountsMap().put(edsKey, updatedCardData);
        }
    }

    private void logOutFromLPSDK(){
        if(PortalUtils.isNewSSOUser()){
            FacadeFactory.getCardFacade().logOutFromLPSDK(DiscoverApplication.getGlobalContext(), new LogoutLivePersonCallback() {
                @Override
                public void onLogoutSucceed() {
//                    System.out.println("sdk log out success");
                }

                @Override
                public void onLogoutFailed() {

//                    System.out.println("sdk log out failed");
                }
            });
        }
    }


}
