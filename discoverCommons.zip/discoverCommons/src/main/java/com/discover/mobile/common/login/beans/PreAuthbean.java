package com.discover.mobile.common.login.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;


public class PreAuthbean implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 5822375073219732659L;

    @SerializedName("hideScreens")
    private ArrayList<String> hideScreens = new ArrayList<String>();

    @SerializedName("dynamicProperties")
    private Map<String, Object> dynamicProperties = new LinkedHashMap<String, Object>(1);

    @SerializedName("VersionInfo")
    private String VersionInfo = null;

    /**
     * @return The hideScreens
     */
    public ArrayList<String> getHideScreens() {
        return hideScreens;
    }

    /**
     * @param hideScreens The hideScreens
     */
    public void setHideScreens(ArrayList<String> hideScreens) {
        this.hideScreens = hideScreens;
    }

    public Map<String, Object> getDynamicPropertiesMap() {
        return dynamicProperties;
    }

    public void setDynamicProperties(Map<String, Object> dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }

    public Object getDynamicProperties(String strKey) {
        return this.dynamicProperties.get(strKey);
    }

    /**
     * @return The VersionInfo
     */
    public String getVersionInfo() {
        return VersionInfo;
    }

    /**
     * @param VersionInfo set VersionInfo
     */
    public void setVersionInfo(String VersionInfo) {
        this.VersionInfo = VersionInfo;
    }
}
