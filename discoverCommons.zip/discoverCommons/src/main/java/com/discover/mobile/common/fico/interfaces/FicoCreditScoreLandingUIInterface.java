package com.discover.mobile.common.fico.interfaces;

import com.discover.mobile.common.fico.bean.FicoCreditScore;
import com.discover.mobile.common.fico.bean.FicoScoreList;
import com.discover.mobile.common.fico.bean.NegativeKeyFactor;
import com.discover.mobile.common.fico.bean.PositiveKeyFactor;

import android.content.Context;

import java.util.List;

/**
 * Created by 526158 on 5/5/2017.
 * Callback Methods for FicoCreditScorecardLandingFragment
 */

public interface FicoCreditScoreLandingUIInterface {

    void showFicoDashboard(FicoCreditScore ficoCreditScore, FicoScoreList validScoreListItem, List<PositiveKeyFactor> positiveKeyFactorList, List<NegativeKeyFactor> negativeKeyFactorList);

    void showNoFicoScoreAvailableScreen();

    void hideSpinner();

    void showSpinner();

    void showFicoCollapseListView(FicoScoreList ficoScoreList);

    void onCreditScoreBoxClick(int boxState);

    void setTabletLandViewData(FicoCreditScore ficoCreditScore);

    void handleCreditScoreHelpEvent(int creditScoreInt);

    void showStrengthDescModal(Context mContext, String titleStr, String descStr, String contentDesc);

    void showScoreUnavailableModal();

    void showKeyFactorDetailModal(FicoScoreList ficoScoreListItem);

    void setListFocus();

}
