package com.discover.mobile.common.nav.utils;

import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.nav.modals.NavigationMenuItem;
import com.discover.mobile.common.nav.modals.NavigationMenuSubItem;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Utility class to handle the population of menu items ,
 * if menu is JSON driven. and filter the items depending upon the POJO
 */
public class MenuPopulationHandler {


    /**
     * Function to apply the filter ie , we will remove the items that needs to be
     * filtered as per killswitch list.
     *
     * @param drawerMenuItemsList - the Menu object
     * @param filteredList        = the list of all items that needds to be filtered
     * @return - the final filtered list.
     */
    public ArrayList<NavigationMenuItem> applyKillSwitchFilter(ArrayList<NavigationMenuItem> drawerMenuItemsList, List<String> filteredList)

    {
        CopyOnWriteArrayList<NavigationMenuItem> copyOnWriteArrayListDrawerMenuItemsList = new CopyOnWriteArrayList<NavigationMenuItem>(
                drawerMenuItemsList);

        for (NavigationMenuItem drawerMenuItem : copyOnWriteArrayListDrawerMenuItemsList) {

            for (String killSwitch : filteredList) {

                if (drawerMenuItem.getKillSwitchConstants().equals(killSwitch)) {
                    drawerMenuItemsList.remove(drawerMenuItem);
                    break;
                }

                List<NavigationMenuSubItem> mNavigationMenuSubItems = drawerMenuItem
                        .getNavigationMenuSubItems();

                CopyOnWriteArrayList<NavigationMenuSubItem> copyOnWriteArrayListNavMenuSubItems = new CopyOnWriteArrayList<NavigationMenuSubItem>(
                        mNavigationMenuSubItems);
                for (NavigationMenuSubItem drawerMenuSubItem : copyOnWriteArrayListNavMenuSubItems) {

                    if (drawerMenuSubItem.getKillSwitchConstants().equals(killSwitch)) {
                        mNavigationMenuSubItems.remove(drawerMenuSubItem);
                    }

                }

            }

        }
        // US116079 Changes Start
        // checking if kill switch for both old and new FICO is off
        if (!(filteredList.contains(FicoUtils.OLD_FICO_KILL_SWITCH_CONSTANT) || filteredList.contains(FicoUtils.NEW_FICO_KILL_SWITCH_CONSTANT))) {
            // if both kill switch are off removing new FICO from LHN
            for (NavigationMenuItem drawerMenuItem : copyOnWriteArrayListDrawerMenuItemsList) {

                if (drawerMenuItem.getKillSwitchConstants().equals(FicoUtils.NEW_FICO_KILL_SWITCH_CONSTANT)) {
                    drawerMenuItemsList.remove(drawerMenuItem);
                    break;
                }
            }
        }
        // US116079 Changes end
        return drawerMenuItemsList;

    }


    /**
     * Function to apply the filter ie , we will remove the items that needs to be
     * filtered as per card type.
     *
     * @param drawerMenuItems - the Menu object
     * @param cardType        = the list of all items that needs to be filtered
     * @return - the final filtered list.
     */
    public ArrayList<NavigationMenuItem> applyCardTypeFilter(ArrayList<NavigationMenuItem> drawerMenuItems, String cardType)

    {
        String[] cardArray;
        cardArray = cardType.split(",");

        CopyOnWriteArrayList<NavigationMenuItem> copyOnWriteArrayListDrawerMenuItems = new CopyOnWriteArrayList<NavigationMenuItem>(
                drawerMenuItems);
        for (NavigationMenuItem drawerMenuItem : copyOnWriteArrayListDrawerMenuItems) {


            if ((null != drawerMenuItem.getExcludedCardType() && drawerMenuItem.getExcludedCardType().contains(cardType))) {
                drawerMenuItems.remove(drawerMenuItem);

            }

            List<NavigationMenuSubItem> mNavigationMenuSubItems = drawerMenuItem
                    .getNavigationMenuSubItems();

            CopyOnWriteArrayList<NavigationMenuSubItem> copyOnWriteArrayListNavMenuSubItems = new CopyOnWriteArrayList<NavigationMenuSubItem>(
                    mNavigationMenuSubItems);
            for (NavigationMenuSubItem drawerMenuSubItem : copyOnWriteArrayListNavMenuSubItems) {

                if ((null != drawerMenuSubItem.getExcludedCardType() && drawerMenuSubItem.getExcludedCardType().contains(cardType))) {
                    mNavigationMenuSubItems.remove(drawerMenuSubItem);
                }

            }


        }
        return drawerMenuItems;

    }

}




