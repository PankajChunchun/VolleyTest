package com.discover.mobile.common.portalpage;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.listener.PortalListItemClickInterface;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;

/**
 * Created by 436645 on 1/27/2017.
 */
public interface PortalPageUIInterface {

    void displayProgressModal();
    void displayZULBErrorModalFromApi(String title, String contentDescription);
    void navigateToCardAccount(PortalListItemClickInterface.PortalPageClickType portalPageClickType, String edsKey);
    void navigateToBankAccount(PortalListItemClickInterface.PortalPageClickType portalPageClickType, int accountIndexKey, PortalAccountType portalAccountType);
    void onClickRightDeepLinkOfPortalBox(PortalBoxInterface dataItem, PortalAccountType accountType, String rightDeepLinkString);
    void onClickLeftDeepLinkOfPortalBox(PortalBoxInterface dataItem, PortalAccountType accountType);
    PortalAccountType getAccountType(PortalBoxInterface dataItem);
    void trackFicoAnalytics();
    boolean isInDraggingState();
    int getDraggingItemPosition();
}
