package com.discover.mobile.common.fingerprint.ui;

import com.discover.mobile.common.fingerprint.interfaces.FingerprintUIInterface;
import com.discover.mobile.common.fingerprint.utils.FingerPrintConstants;
import com.discover.mobile.common.shared.net.NetworkRequestListener;

/**
 * Created by 526158 on 9/23/2016.
 */
public class FingerprintSetupPresenterImpl implements FingerprintSetupPresenter {
    private FingerprintUIInterface mFingerprintSetUIInterface;

    private FingerprintInteractor mFingerprintInteractor;

    public FingerprintSetupPresenterImpl(FingerprintUIInterface fingerprintSetUIInterface, FingerprintInteractor fingerprintInteractor) {
        this.mFingerprintSetUIInterface = fingerprintSetUIInterface;
        this.mFingerprintInteractor = fingerprintInteractor;
    }

    @Override
    public void validatePasscode(final String passcode) {
        mFingerprintInteractor.validatePasscodeAndSubmit(passcode, new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                mFingerprintInteractor.setFingerPrintStatus(passcode, true, true);
                mFingerprintSetUIInterface.updateUI(true, passcode);
                mFingerprintSetUIInterface.showDialog(FingerPrintConstants.DIALOG_ENABLE_FINGERPRINT);

            }

            @Override
            public void onError(Object data) {
                mFingerprintInteractor.setFingerPrintStatus(passcode, false, false);
                mFingerprintSetUIInterface.updateUI(false, null);
                mFingerprintSetUIInterface.showInvalidPasscodeBanner();
            }
        });
    }

    @Override
    public void onToggleStateChange(boolean isChecked) {
        this.mFingerprintSetUIInterface.onToggleStateChanged(isChecked);
        if (!isChecked) {
            //Commented this call for fixing defect# 97 & moved inside above onToggleStateChanged call
//            if (mFingerprintInteractor.getFingerPrintStatus()) {
//                mFingerprintSetUIInterface.showDialog(FingerPrintConstants.DIALOG_DISABLE_FINGERPRINT);
//            }
        } else if (!mFingerprintInteractor.isFingerprintRegisteronDevice()) {
            mFingerprintSetUIInterface.showDialog(FingerPrintConstants.DIALOG_SETUP_FINGERPRINT);
        }
    }

    @Override
    public void onClickPrivacyTerms() {
        mFingerprintSetUIInterface.navigateTo(FingerPrintConstants.TYPE_PRIVACY_AND_TERMS);
    }

    @Override
    public void onClickProvideFeedback() {
        mFingerprintSetUIInterface.navigateTo(FingerPrintConstants.TYPE_PROVIDE_FEEDBACK);
    }

}
