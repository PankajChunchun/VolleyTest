package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Page implements Serializable {
    private static final long serialVersionUID = 4062452566623230671L;

    @SerializedName("achpageId")
    private String achpageId;

    @SerializedName("areas")
    private List<Area> areas = new ArrayList<Area>();

    /**
     * @return The achpageId
     */
    public String getAchpageId() {
        return achpageId;
    }

    /**
     * @param achpageId The achpageId
     */
    public void setAchpageId(String achpageId) {
        this.achpageId = achpageId;
    }

    /**
     * @return The areas
     */
    public List<Area> getAreas() {
        return areas;
    }

    /**
     * @param areas The areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

}
