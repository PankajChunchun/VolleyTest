package com.discover.mobile.common.login;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.Html;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.discover.mobile.common.Constants;
import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.IntentExtraKey;
import com.discover.mobile.common.R;
import com.discover.mobile.common.StandardErrorCodes;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.Utils.Type;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.androidwear.AndroidWearConnectivity;
import com.discover.mobile.common.androidwear.BankAndroidWearUtils;
import com.discover.mobile.common.applynow.ui.ApplyNowBannerFragment;
import com.discover.mobile.common.applynow.ui.ApplyNowDioalog;
import com.discover.mobile.common.appupdate.ui.AppVersionRequest;
import com.discover.mobile.common.auth.InputValidator;
import com.discover.mobile.common.auth.KeepAlive;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.ewallet.AndroidPayConnectivity;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.facade.LoginActivityInterface;
import com.discover.mobile.common.fingerprint.listener.FingerPrintDialogActionListener;
import com.discover.mobile.common.fingerprint.listener.FingerPrintListener;
import com.discover.mobile.common.fingerprint.ui.FingerPrintDialog;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.help.HelpActivity;
import com.discover.mobile.common.highlightedfeatures.utils.HFPref;
import com.discover.mobile.common.highlightedfeatures.utils.HFUtils;
import com.discover.mobile.common.liveperson.LivePersonConstants;
import com.discover.mobile.common.login.beans.InfoJsonData;
import com.discover.mobile.common.login.beans.PreAuthbean;
import com.discover.mobile.common.login.helper.PushServiceHelper;
import com.discover.mobile.common.login.service.LoginServiceClass;
import com.discover.mobile.common.msignia.MsigniaSingleton;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.net.cookie.BankSessionCookieManager;
import com.discover.mobile.common.net.cookie.CookieManagerProxy;
import com.discover.mobile.common.net.cookie.SessionCookieManager;
import com.discover.mobile.common.permission.listener.PermissionListener;
import com.discover.mobile.common.permission.utils.PermissionConstant;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.beans.User;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.productpage.facade.CardProductFacadeImpl;
import com.discover.mobile.common.shared.AccountType;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.callback.GenericCallbackListener.CompletionListener;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.net.NetworkServiceCall;
import com.discover.mobile.common.shared.net.SessionTokenManager;
import com.discover.mobile.common.shared.net.error.RegistrationErrorCodes;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.CryptoMigrationHelper;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.shared.utils.QuickViewUtils;
import com.discover.mobile.common.shared.utils.SecurityUtil;
import com.discover.mobile.common.shared.utils.StringUtility;
import com.discover.mobile.common.shared.utils.TokenUtil;
import com.discover.mobile.common.shared.utils.image.FileCache;
import com.discover.mobile.common.shared.utils.image.FileDownloader;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.threatmatrix.ThreatMatrixSingleton;
import com.discover.mobile.common.ui.InvalidCharacterFilter;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.common.ui.modals.SimpleContentModal;
import com.discover.mobile.common.ui.widgets.FontAwesomeTextView;
import com.discover.mobile.common.ui.widgets.PasscodeCircularEditText;
import com.discover.mobile.network.NetworkServiceHeaders;
import com.discover.mobile.network.error.bean.ErrorBean;
import com.discover.mobile.network.error.bean.PreAuthErrorResponseDetails;
import com.discover.mobile.network.error.bean.PreAuthErrorResponseDetails.PreAuthData;
import com.discover.mobile.network.error.utils.ErrorConstants;
import com.discover.mobile.network.infomessage.InfoMessageUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.xtify.sdk.api.XtifySDK;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.security.Key;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
/*import com.crashlytics.android.Crashlytics;
import io.fabric.sdk.android.Fabric;*/

/**
 * LoginActivity - This is the login screen for the application. It makes three
 * service calls - The first call is pre auth Second is starting xtify services
 * for push notifications And the third is the login call when a user tries to
 * login.
 *
 * @author scottseward, ekaram
 *
 *         Updated by hlin0 May 2013 -- quickview (aka fastcheck) 13.3
 */


public class LoginActivity extends DiscoverBaseActivity implements
        LoginActivityInterface, CompletionListener,
        OnClickListener, PasscodeInfoDialogFragment.PasscodeInfoDialogListener, FingerPrintListener {
    public static final String PROFILE_WEAR_KEY = "profile_androidwear";
    //geofence constants, 7.4, hlin0
    public static final String SHARED_PREF_GEOFENCE = "GEOFENCE_PREF";
    public static final String SHARED_PREF_GEOFENCE_RESP_KEY = "GeofenceResponseStr";
    public static final String SHARED_PREF_ENCRYPT = "ENCRYPTUTIL_PREF";
    public static final String SECUREID_USED = "SECUREID_USED";
    //    public static final String SHARED_PREF_GEOFENCE_RESP_KEY = "GeofenceResponseStr";
    public static final String MANIFEST_METADATA_GEOFENCE_VISUAL_IND = "includeGeofenceVisual";
    public static final String SHARED_PREF_GEOFENCE_VISUAL_IND = "includeGeofenceVisual";
    //private boolean hideToggle; //us20958
    protected static final String PACKAGE_NAME = "com.discoverfinancial.mobile";
    /* TAG used to print logs for the LoginActivity into logcat */
    private static final String TAG = LoginActivity.class.getSimpleName();
    private static final long HALF_SECOND = 500;
    private static final int THREE_FIFTY = 350;
    private static final long THREE_SECONDS = 3000;
    private static final int PASSWORD_MIN_LEN = 1;
    private static final String VALID_USER_ID_MATCHER = ".*[a-zA-Z0-9]+.*";
    /**
     * These are string values used when passing extras to the saved instance
     * state bundle for restoring the state of the screen upon orientation
     * changes.
     */
    private static final String PASS_KEY = "a";
    private static final String ID_KEY = "b";
    private static final String SAVE_ID_KEY = "c";
    private static final String TOGGLE_KEY = "j";
    private static final String IS_USER_ID_LOGIN = "k";
    private static final String IS_FORGOT_PASSCODE = "l";
    private static final String BANK_IS_FORGOT_PASSCODE = "o";
    private static final String BANK_IS_USER_ID_LOGIN = "p";
    private static final String PASSCODE = "q";
    private static final String ID_FIELD_FOCUS = "idFocus";
    private static final String PWD_FIELD_FOCUS = "pwdFocus";
    private static final String IS_ERROR_LINE_DISPLAYED = "errorLineDisplayed";
    private static final int SPLASH_LOGO_SRINK_MOVE_DURATION = 500;
    private static final int FOOTER_DURATION = 500;
    private static final int ID_VIEW_DURATION = 500;
    /**
     * The value of variable restoreToggle when we are not restoring based on
     * orientation change
     */
    private static final int NO_TOGGLE_TO_RESTORE = -1;
    private static final int LOGOUT_TEXT_COLOR = R.color.body_copy;
    private static final int QV_ANIM_DURATION = 900;
    private static final int INITIAL_ANIM_DURATION = 200;
    private static final int LANDSCAPE_LOGO_ANIM_DURATION = 500;
    private static final int LANDSCAPE_PAGE_UP_MARGIN = 20;
    private static final int LANDSCAPE_PAGE_DOWN_MARGIN = 30;
    private static final int TABLET_PAGE_MARGIN = 30;
    private static final String ANIMATION_PROPERTY_KEY = "AnimationDelay";
    private static final String ANIMATION_DELAY_PROPERTY = "androidAnimationLag";
    private static final String UNIVERSAL_INVOCATION_DIALOG = "upgradeModalPref";
    private static final String TIMESTAMP_KEY = "ModalTimeStamp";
    public static boolean isCardFirstLogin = false;
    public static boolean isCardChecked = true;
    public static boolean isErrorModalShown = false;
    public static boolean showDealKillSwitchFlag = true;
    private ApplyNowBannerFragment applyNowBannerFragment;
    private ApplyNowDioalog applyNowDioalog = null;
    public static boolean isShowApplyNowBanner = true;
    private static boolean isForceUpgradeAvailable = false;
    private boolean isForceUpgrade = false;
    private boolean isApplyNowKillSwitch= false;
    /*US135162: Android Forced upgrade bypass
     This boolean holds true when user logged out manually
     When its true then FingerPrint model will not be shown.
     */
    private boolean isUserManualLoggedOut = false;

    //IN7967777 defect fix
    public static PasscodeCircularEditText getFieldTVs() {
        return fieldTVs[0];
    }

    private static PasscodeCircularEditText[] fieldTVs = new PasscodeCircularEditText[4];
    private static boolean firstLaunch = false;
    final AnimationSet animSet = new AnimationSet(true);
    //TODO need to remove below variable as it is not used - Hari
    public Bundle deeplinkBundle;
    // START - Splash Animation views and constants
    DiscoverApplication objApplication;
    long pauseTimeStamp;
    int loginSubDrawingYPosition;
    int loginSubHeight;
    // INPUT FIELDS
    private EditText idField;
    private EditText passField;
    private View userIdLine;
    private View passFieldLine;
    private LinearLayout mLoginButton;
    private LinearLayout footer;
    private RelativeLayout relativeLayoutToggle;
    private Animation loginBtnFadeIn;
    private Animation loginBtnFadeOut;
    private LinearLayout toggleSelection;
    private TextView forgotPaswordLayout;
    private LinearLayout rememberLayout;
    private Animation registerLinkFadeIn;
    private Animation registerLinkFadeOut;
    private Animation remmeberBtnFadeIn;
    private Animation remmemberBtnFadeOut;
    private RelativeLayout loginRootView;
    // BUTTONS
    private LinearLayout loginButton;
    private TextView bank;
    private TextView card;
    private TextView registerLinkLayout;
    private RelativeLayout goToBankButton;
    private RelativeLayout goToCardButton;
    // Fastcheck Buttons
    private Button gotoFastcheckButton;
    // Prelogin Extras Buttons
    private Button gotoMOP1B;
    private FontAwesomeTextView checkMarkBank;
    private FontAwesomeTextView checkMarkCard;
    private FontAwesomeTextView rememberChkbox;
    private FontAwesomeTextView rememberTick;
    // Passcode Fields
    private PasscodeUtils pUtils;
    private PasscodeUtils bankpasscodeUtils;
    //private ImageView splashLogo;
    // US37334 Changes start -- pkuma13
    // private TextView passcodeForgot;
    // US37334 Changes end -- pkuma13
    private TextView passcodeLinkLayout;
    private String enteredUserName;
    private String enteredPassword;
    private boolean isPasscodeLogin = false;
    /**
     * Container for login/password view, handles visibility of all related
     * views to login/password.
     */
    private RelativeLayout vLogin;
    /**
     * Container for passcode view, handles visibility of all related views to
     * passcode.
     */
    private RelativeLayout vPasscode;
    // END - Splash Animation views and constants
    private boolean isUserIDLogin;
    private boolean isBankUserIDLogin;
    private boolean highlightedFeatureAvailable;
    // IMAGES
    private ImageView cardCheckMark;
    private ProgressBar splashProgress;
    private ImageView pwdRedBtn;
    private ImageView uidRedBtn;
    private LinearLayout feedBackButton;
    private LinearLayout atmButton;
    private LinearLayout helpButton;
    private LinearLayout productsButton;
    private RelativeLayout versionAndPrivacyLayout;
    private View mEmptyView;
    private boolean splashScreenStart = true;
    private Animation footerFadeIn;
    private Animation loginFadeIn;
    private Animation passcodeFadeIn;
    private Animation versionFooterFadeIn;
    private String passcode;
    /*
     * Used to specify whether the pre-authenciation call has been made for the
	 * application. Should only be done at application start-up.
	 */
    private boolean isFromOrientaionChange = false;
    /** Set to true when the alu modal is showing */
    private boolean isAluModalShowing = false;
    private boolean saveUserId = false;
    /** Username set when login is clicked and cleared after */
    private String username = StringUtility.EMPTY;
    /**
     * Equal to an Account Type ordinal when we restored a toggle on orientation
     * change (versus. restoring based on last login).
     */
    private int restoreToggle = NO_TOGGLE_TO_RESTORE;
    /** {@code true} when we restored an error on orientation change. */
    private boolean restoreError = false;
    private ViewGroup activityRootView;
    private String passcodeTokenClear;
    private String bankpasscodeTokenClear;
    private TextView versionNumber;
    private String versionName;
    private SpannableString versionString;
    private TextView privacy_and_terms;
    private TextView fdic_disclaimer_view;
    // geofence, 7.4, hlin0
    private TextView vertical_separator2;
    private TextView geofence_link;
    // Quick View Redesign
    //private boolean keyBoardStateVisible = false;
    private boolean doMaintainQVState = false;
    private TextView quickView;
    // private boolean isInQuickViewMode = false;
    private View fastcheckFragView;
    private ImageView discoverLogo;
    private int transDist = 0;
    private boolean showQuickView = false;
    private RelativeLayout scrollContainer;
    private boolean isUserNameHasFocus = false;
    private boolean isPasswordHasFocus = false;
    private boolean isErrorLineDisplayed = false;
    private boolean showErrorLine = false;
    /**
     * A view which contains Forgot-Password, Register, Passcode links.
     */
    private RelativeLayout loginSubOptions;
    // US37431 changes end
    private RelativeLayout passcodeLoginSubOptions; // US71607 Fingerprint login screen option
    private float staticHeightOfPasscodeSubOptions = -1f;
    private float staticHeightOfUIDSubOptions = -1f;
    private boolean forgotPasscodeSelected;
    private FrameLayout idPasswordView;
    private TextView passcodeUserIdLogin;
    // US37431 changes start
    private boolean shouldPasscodeDeeplinkEnable = false;
    //QV Univ Migration Start
    private View fastcheck_frag_tab;
    private FrameLayout layoutQuickViewAnim;
    //	private boolean showQuickView = false;
    private boolean keyBoardStateVisible = false;
    //    private boolean doMaintainQVState = false;
    private int QV_ANIM_UP_DURATION = 700;
    private int QV_ANIM_DOWN_DURATION = 700;
    private int rootViewStartPoint = 0;
    private int qvArcImgStartPoint = 0;
    private boolean istouchStartPointValid = false;
    private int initQVTimeDelay = 100;
    //QV Univ Migration End
    private Upgrade_Type mUpgrade_type;
    private boolean isRestoreInstance = false;
    private CookieManagerProxy cookieManagerProxy;

    /** start US71607 Fingerprint login screen option */
    private TextView fingerPrintLoginLabel;
    private FingerPrintDialog fingerPrintDialog;
    private FingerPrintUtils fingerPrintUtils;
    /**end US71607 Fingerprint login screen option */

    // VOC changes to identify network change
    private Intent networkChangeListenerIntent = null;

    private boolean isFpTouchSensorClick=false;

    private boolean isApplyNowContentShowing;
    private FragmentTransaction ft;
    /**
     * Flag to avoid "java.lang.IllegalStateException: Can not perform this action after
     * onSaveInstanceState" when Login Screen put to back-ground when pre-auth ASynchTask is
     * in progress i.e. to avoid Fragment transaction
     */
    private boolean isActivitysOnSaveInstanceStateCalled = false;

    /**
     * Listener to check if the soft keyboard is hidden or visible and action
     * accordingly
     */
    private OnGlobalLayoutListener layoutListener = new OnGlobalLayoutListener() {

        boolean isViewScrolled = false;


        @Override
        public void onGlobalLayout() {

            // Initialise height of login sub option container
            if (Float.compare(staticHeightOfUIDSubOptions, 0f) <= 0 || Float.compare(staticHeightOfUIDSubOptions, 0f) <= (float) loginSubOptions.getHeight()) {
                staticHeightOfUIDSubOptions = loginSubOptions.getHeight();
            }
            if (Float.compare(staticHeightOfPasscodeSubOptions, 0f) <= 0 || Float.compare(staticHeightOfPasscodeSubOptions, 0f) <= (float) passcodeLoginSubOptions.getHeight()) {
                staticHeightOfPasscodeSubOptions = passcodeLoginSubOptions.getHeight();
            }

			/*
             * Below if condition is added to avoid the execution of block while
			 * changing visibility of quickview from Gone to visible.
			 */
            if (!DiscoverApplication.isInQuickViewMode) {
                /**
                 * Here we will now check if the keyboard is open or closed
                 * so that we can decide if the footer view is to be shown or hidden
                 */
                Rect r = new Rect();
                activityRootView.getWindowVisibleDisplayFrame(r);
                int screenHeight = activityRootView.getRootView().getHeight();
                int keyboardheight = screenHeight - r.bottom;
                /**
                 * We are taking 15% of the screen height as it should be sufficient space
                 * for the keyboard to determine if keyboard is open
                 */
                if (keyboardheight > screenHeight * 0.15) {


                    if (!isViewScrolled) {
                        if (Utils.isRunningOnHandset(LoginActivity.this)) {
                            if (scrollToPosition(-(discoverLogo.getBottom() + LANDSCAPE_PAGE_UP_MARGIN))) {
                                isViewScrolled = true;
                            }
                        } else {
                            if (scrollToPosition(-discoverLogo.getTop() + dpToPx(TABLET_PAGE_MARGIN))) {
                                Log.d("Login activity---- :: ", "isViewScrolled ::  " + isViewScrolled);
                                isViewScrolled = true;
                            }
                        }
                    }
                    relativeLayoutToggle.setVisibility(View.VISIBLE);
                    //start - us20958 - nkaza (if user is SSO user, hide the bank/card toggle)
                    if (pUtils.hideToggle() && !(isUserIDLogin || isBankUserIDLogin)) {
                        toggleSelection.setVisibility(View.INVISIBLE);
                    } else {
                        // show toggle buttons if keyboard is visible
                        relativeLayoutToggle.setVisibility(View.VISIBLE);
                        toggleSelection.setVisibility(View.VISIBLE); //# hotFix 2
                    }
                    //end - us20958 - nkaza
                    versionAndPrivacyLayout.setVisibility(View.INVISIBLE);
                    footer.setVisibility(View.INVISIBLE);
                    idField.setCursorVisible(true);
                    passField.setCursorVisible(true);
                    //QV Univ Migration -Start
                    if (!Utils.isRunningOnHandset(LoginActivity.this)) {
                        keyBoardStateVisible = true;
                    }
                    //QV Univ Migration -End

                    objApplication.setLoginKeyBoardStateVisible(true);
                    handleVisibilityOfLoginSubOptions();
                } else {
                    // hide toggle buttons if keyboard is hidden
                    relativeLayoutToggle.setVisibility(View.GONE);
                    versionAndPrivacyLayout.setVisibility(View.VISIBLE);
                    handleVisibilityOfLoginSubOptions();
                    //ADA
                    idPasswordView.setVisibility(View.VISIBLE);

                    idField.setCursorVisible(false);
                    passField.setCursorVisible(false);

                    footer.setVisibility(View.VISIBLE);
                    //QV Univ Migration -Start
                    if (!Utils.isRunningOnHandset(LoginActivity.this)) {
                        keyBoardStateVisible = false;
                    }
                    //QV Univ Migration -End
                    objApplication.setLoginKeyBoardStateVisible(false);

                    if (isViewScrolled) {
                        if (Utils.isRunningOnHandset(LoginActivity.this)) {
                            if (scrollToPosition(-(discoverLogo.getTop() - LANDSCAPE_PAGE_DOWN_MARGIN)))
                                isViewScrolled = false;
                        } else {
                            if (scrollToPosition(0))
                                isViewScrolled = false;
                        }
                    }

                    if (showQuickView) {
                        DiscoverApplication.isInQuickViewMode = true;
                        showQuickViewPage();
                    }

                }
            } else {
                Log.i("discover", "qv:privacy inv");
                versionAndPrivacyLayout.setVisibility(View.INVISIBLE);
            }

        }
    };
   /**
     * Whenever toggle changes, update UI in android wear
     */
    public static void updateUiInWear(Context context, boolean isCard) {
        BankAndroidWearUtils androidWearUtils = new BankAndroidWearUtils(
                context);
        androidWearUtils.setBankLoginSelected(context, !isCard);
    }

    private static void clearField(final TextView paramTextView) {
        paramTextView.setText("");
    }

    public static TextView deleteLatestInput() {
        for (int i = fieldTVs.length - 1; i >= 0; i--) {
            if (fieldTVs[i].length() > 0) {
                clearField(fieldTVs[i]);
                return fieldTVs[i];
            }
        }
        return fieldTVs[0];
    }

    //TODO needs to remove the below code once all the customers are updated to 7.9 application version.
    /**
     * App data was lost due to encryption method is changed in 7.9 app version.
     * To save app cache after version upgrade we have written below functions to get old value encrypted value and decrypt with old key and encrypt with new key so that app data is preserved after app upgrade from 7.8 to 7.9.
     * below mentioned functions can be removed once all the customers are updated to 7.9 version.
     * 1. readFastcheckToken
     * 2. storeFastcheckToken
     **/
    private static final String DISCOVER_CARD_PREF = "DiscoverCardPref";

    public static String readFastcheckToken(final Context activity,
                                            boolean isForWear) {
        String token = null;
        SharedPreferences sharedPref = activity.getSharedPreferences(
                DISCOVER_CARD_PREF, Context.MODE_PRIVATE);
        if (isForWear) {
            token = sharedPref.getString(
                    activity.getResources().getString(
                            R.string.fast_check_wear_token_key_in_ps), null);

        } else {
            token = sharedPref.getString(
                    activity.getResources().getString(
                            R.string.fast_check_token_key_in_ps), null);
        }
        // Prod issue old key
        if (!isForWear) {
            if (token == null) {
                /*token = sharedPref.getString(
                        activity.getResources().getString(
                                R.string.fast_check_token_key_in_ps_old), null);*/
            }
        }
        return token;
    }

    public static void storeFastcheckToken(final Context activity,
                                           final String token, boolean isForWear) {
        SharedPreferences sharedPref = activity.getSharedPreferences(
                DISCOVER_CARD_PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        if (isForWear) {
            editor.putString(
                    activity.getResources().getString(
                            R.string.fast_check_wear_token_key_in_ps), token);
        } else {
            editor.putString(
                    activity.getResources().getString(
                            R.string.fast_check_token_key_in_ps), token);
        }

        // hlin0, 14.2, stop putting into old location!!
        // Prod issue old key
        // editor.putString(
        // activity.getResources().getString(
        // R.string.fast_check_token_key_in_ps_old), token);

        // hlin0, 14.2, if there is stuff in old location, delete it!!
        if (!isForWear) {
            /*if (sharedPref.getString(
                    activity.getResources().getString(
                            R.string.fast_check_token_key_in_ps_old), null) != null)
                editor.putString(
                        activity.getResources().getString(
                                R.string.fast_check_token_key_in_ps_old), null);*/
        }
        editor.commit();
    }
    //TODO needs to remove the below code once all the customers are updated to 7.9 application version.

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        // added to remove the black background when user toggles from username
        // to password
        Log.d("UniversalUpgradation", "I am in Oncreate");
        /**
         * We will call clearCacheMemory to clear cache , as clearing deals cache value comes from infomessage.json
         */
        DiscoverActivityManager.setActiveActivity(this);

        clearCacheMemory();

        getWindow().setBackgroundDrawableResource(R.drawable.blue_bg);
        //Added below code as application was crashing due to null pointer exception in fast check fragment.
         //Clear Card side cache data; need to call before "account" call
        FacadeFactory.getCardFacade().clearCardCacheData(LoginActivity.this);
           //changes for US65174
        NetworkServiceHeaders.getInstance();

        //gets card LHN menu from server
        CommonUtils.fetchCardMenuFromServer();
        super.onCreate(savedInstanceState);
        //initilaizing the crashlytics
        /*Fabric.with(this, new Crashlytics());*/
        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/

        /**Defect:1268 - End**/
        setContentView(R.layout.login_start_redesign);
        //Below Analytics code modified by senthil
        TrackingHelper.startActivity(this);


        //TODO needs to remove the below code once all the customers are updated to 7.9 application version.
        SharedPreferences encryptionSharedPrefs = getApplicationContext()
                .getSharedPreferences(SHARED_PREF_ENCRYPT, Context.MODE_PRIVATE);
        Boolean SecureIDUsed = encryptionSharedPrefs.getBoolean(SECUREID_USED, false);
        if (!SecureIDUsed && Utils.isAppUpgraded(getContext()) && ContextCompat.checkSelfPermission(getApplicationContext(), PermissionConstant.Permissions.READ_PHONE_STATE.toString()) == PackageManager.PERMISSION_GRANTED) {
            PasscodeUtils pUtils = new PasscodeUtils(getContext());
            try {
                String passcodeEncryptedToken = pUtils.getPasscodeTokenForOldType();
                if (passcodeEncryptedToken != null && passcodeEncryptedToken.length() != 0) {
                    if (pUtils.hideToggle()) {
                        PasscodeUtils.ssouser = true;
                    } else {
                        PasscodeUtils.ssouser = false;
                    }
                    pUtils.deletePasscodeToken();
                    pUtils.createPasscodeToken(passcodeEncryptedToken);
                }
                // Fix added as part of 7.9.0 based on the PlayStore crash
                if (!PasscodeUtils.ssouser) {
                    PasscodeUtils bankPasscodeUtils = new PasscodeUtils(getContext(), false);
                    String bankPasscodeEncryptedToken = bankPasscodeUtils.getPasscodeTokenForOldType();
                    if (bankPasscodeEncryptedToken != null && bankPasscodeEncryptedToken.length() != 0) {
                        if (bankPasscodeUtils.hideToggle()) {
                            PasscodeUtils.ssouser = true;
                        } else {
                            PasscodeUtils.ssouser = false;
                        }
                        bankPasscodeUtils.deletePasscodeToken();
                        bankPasscodeUtils.createPasscodeToken(bankPasscodeEncryptedToken);
                    }
                }

                String encryptedBankToken = null;
                String encryptedCardToken = null;
                String encryptedCardWearToken = null;
                String encryptedBankWearToken = null;
                String cardToken = null;
                String bankToken = null;
                String cardWearToken = null;
                String bankWearToken = null;

                encryptedBankToken = QuickViewUtils
                        .getQuickViewToken(this);
                encryptedCardToken = readFastcheckToken(this, false);
                encryptedCardWearToken = readFastcheckToken(this, true);

                BankAndroidWearUtils bankAndroidWearUtils = new BankAndroidWearUtils(this);
                encryptedBankWearToken = bankAndroidWearUtils.getWearToken(this);

                if (encryptedBankToken != null && encryptedBankToken.length() != 0) {
                    bankToken = TokenUtil.parseAndDecryptTokenSupportClearFromLogin(
                            this,
                            encryptedBankToken);
                    if (bankToken != null && bankToken.length() != 0) {
                        QuickViewUtils quickViewUtils = new QuickViewUtils(this);
                        quickViewUtils.deleteQuickViewToken();
                        QuickViewUtils.createQuickviewToken(this, bankToken);
                    }
                }
                if (encryptedCardToken != null && encryptedCardToken.length() != 0) {
                    cardToken = TokenUtil.parseAndDecryptTokenSupportClearFromLogin(
                            this,
                            encryptedCardToken);
                    if (cardToken != null && cardToken.length() != 0) {
                        storeFastcheckToken(this,
                                TokenUtil.encryptAndJsonifyToken(this,
                                        cardToken),
                                false);
                    }
                }

                if (encryptedCardWearToken != null && encryptedCardWearToken.length() != 0) {
                    cardWearToken = TokenUtil.parseAndDecryptTokenSupportClearFromLogin(
                            this,encryptedCardWearToken
                    );
                    if (cardWearToken != null && cardWearToken.length() != 0) {
                        storeFastcheckToken(this,
                                TokenUtil.encryptAndJsonifyToken(this,cardWearToken),
                                true);
                    }
                }

                if(encryptedBankWearToken != null && encryptedBankWearToken.length() != 0){
                    bankWearToken = TokenUtil.parseAndDecryptTokenSupportClearFromLogin(
                            this,encryptedBankWearToken
                    );
                    if(bankWearToken != null && bankWearToken.length() != 0)  {
                        bankAndroidWearUtils.deleteWearToken();
                        bankAndroidWearUtils.createWearToken(this,bankWearToken );
                    }
                }

                //pUtils.getClearPasscodeToken();
            } catch (Exception e) {
                e.printStackTrace();
            }
            //Added for just tracking howmany users got updated with SEcure ID
            TrackingHelper.trackPageView("ConvertedAndroidSecureIdfromTelephonyID");
        }
        else
        {
            TrackingHelper.trackPageView("UsingStillTelephonyIDforBelowMarshmallow");
        }
        Editor editor = encryptionSharedPrefs.edit();
        editor.putBoolean(SECUREID_USED, true);
        editor.commit();
        //TODO needs to remove the below code once all the customers are updated to 7.9 application version.

        CryptoMigrationHelper.migrateTo256();

        FacadeFactory.getCardFacade().initCookieManager(getContext());

        // condition added to check app upgrade - Onboarding skrish1 - start
        if (Utils.isAppUpgraded(this)) {
            new HFPref(this).setWizardShown(true);
        } else {
            //fresh install
            if (!new HFPref(this).getIsWizardShownAlready()) {
                /**start added for US79254 On-boarding Fingerprint animation */
                String[] mediaFileNames;
                if (FingerPrintUtils.isFingerprintHardwareAvailable(LoginActivity.this)) {
                    mediaFileNames = getResources().getStringArray(R.array.onboard_fp_media_files);
                } else {
                    mediaFileNames = getResources().getStringArray(R.array.onboard_media_files);
                }
                /**end added for US79254 On-boarding Fingerprint animation */
                String[] imageFileNames = getResources().getStringArray(R.array.onboard_image_files);
                FileDownloader.getInstance().downloadFile(mediaFileNames, ImageDir.DIR_ENUM.ONBOARDING, ImageDir.FILE_TYPE.MEDIA);
                FileDownloader.getInstance().downloadFile(imageFileNames, ImageDir.DIR_ENUM.ONBOARDING, ImageDir.FILE_TYPE.IMAGE);
            }
        }
        //till here
        // onboarding skrish1 - end

        if (!(Utils.isRunningOnHandset(getApplicationContext()))) {
            try {
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/discover_logs/dump.txt");
                if (file.exists()) {
                    FileReader fileReader = new FileReader(file);
                    BufferedReader bufferedReader = new BufferedReader(fileReader);
                    StringBuffer stringBuffer = new StringBuffer();
                    String content;
                    while ((content = bufferedReader.readLine()) != null) {
                        stringBuffer.append(content);
                    }
                    fileReader.close();
                    String encryptedString = stringBuffer.toString();

                    //decrypt the contents
                    String key = "d1sC0verBu!ld123";
                    Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.DECRYPT_MODE, aesKey);
                    String decryptedString = new String(cipher.doFinal(Base64.decode(encryptedString.getBytes(), Base64.DEFAULT)));
                    java.lang.reflect.Type type = new TypeToken<Map<String, Object>>() {
                    }.getType();
                    Gson readGson = new GsonBuilder().disableHtmlEscaping().create();
                    Map<String, Object> convertedMap = readGson.fromJson(decryptedString, type);
                    Iterator itr = convertedMap.keySet().iterator();
                    while (itr.hasNext()) {
                        String keyStr = itr.next().toString();
                    }


                    //get the Shared preference for SSO Passcode
                    Map<String, ?> ssoPasscodeJson = (Map<String, ?>) convertedMap.get("SSOPasscodeUtils");
                    Map<String, ?> PasscodeJson = (Map<String, ?>) convertedMap.get("PasscodeUtils");
                    Map<String, ?> quickViewJson = (Map<String, ?>) convertedMap.get("DiscoverCardPref");
                    Map<String, ?> quickViewNonCardJson = (Map<String, ?>) convertedMap.get("QuickViewUtils");
                    Map<String, ?> bankPasscodeUtils = (Map<String, ?>) convertedMap.get("BankPasscodeUtils");

                    if (ssoPasscodeJson != null) {
                        Boolean hideToggle = (Boolean) ssoPasscodeJson.get("clauserhidetoggle");
                        String token = (String) ssoPasscodeJson.get("token");
                        PasscodeUtils pUtils = new PasscodeUtils(this);
                        pUtils.storeSSOPascode(hideToggle, token);
                    }
                    if (PasscodeJson != null) {
                        String nonSSOToggle = (String) PasscodeJson.get("token");
                        Boolean forgotPasscode = (Boolean) PasscodeJson.get("forgot_passcode");
                        String fUserName = (String) PasscodeJson.get("fname");
                        String fUuerId = (String) PasscodeJson.get("fuserid");

                        PasscodeUtils nonSSOPassUtils = new PasscodeUtils(this, true);
                        nonSSOPassUtils.storePascode(nonSSOToggle, forgotPasscode, fUserName, fUuerId);

                    }
                    if (bankPasscodeUtils != null) {
                        String bankToggle = (String) bankPasscodeUtils.get("token");
                        Boolean forgotPasscode = (Boolean) bankPasscodeUtils.get("forgot_passcode");
                        String fUserName = (String) bankPasscodeUtils.get("fname");
                        String fUuerId = (String) bankPasscodeUtils.get("fuserid");

                        PasscodeUtils bankPassUtils = new PasscodeUtils(this, false);
                        bankPassUtils.storePascode(bankToggle, forgotPasscode, fUserName, fUuerId);

                    }

                    if (quickViewNonCardJson != null) {
                        Boolean quickViewFlag = (Boolean) quickViewNonCardJson.get("tokenstaus");
                        String quickViewToken = (String) quickViewNonCardJson.get("token");
                        QuickViewUtils qvUtils = new QuickViewUtils(this);
                        qvUtils.storeQVSet(quickViewFlag, quickViewToken);
                    }
                    if (quickViewJson != null) {
                        Boolean quickViewFlag = (Boolean) quickViewJson.get("tokenstaus");
                        String quickViewToken1 = (String) quickViewJson.get("FastcheckToken1.0");
                        String quickViewToken = (String) quickViewJson.get("FastcheckToken");
                        FacadeFactory.getCardFacade().setupFastCheckFrag(getContext(), quickViewToken1);
//                    qvUtils.storeQVSet(quickViewFlag, quickViewToken1);
                    }
                    file.delete(); // once the settings has been saved to SP need to delete the file
                }
            } catch (Exception e) {
                Log.e("Sundeep", "" + e.getMessage());
            }
        }

        //     CommonUtils.lockOrientation();
        if (!isTaskRoot()) {
            if (getIntent().hasCategory(Intent.CATEGORY_LAUNCHER)
                    && getIntent().getAction() != null
                    && getIntent().getAction().equals(Intent.ACTION_MAIN)) {
                finish();
                return;
            }
        }
        XtifySDK.enableDefaultNotification(this.getApplicationContext(), false);
        preventDuplicateLoginScreens();
        if (Utils.isRunningOnHandset(LoginActivity.this)) {
            isAdaEnabled(true, false);
        }
        if (!(isCardLogin())) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    R.string.app_launchTime);
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    R.string.app_launch);
        }

        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);
        objApplication = (DiscoverApplication) getApplication();

        loadResources();
        setClickListeners();

        initAnimations();


        // START: US 13784
        HashMap<String, Object> extras = new HashMap<String, Object>();
        if (!firstLaunch) {
            firstLaunch = true;
//            Toast.makeText(getApplicationContext(),"I should call only once untill killing the application",Toast.LENGTH_LONG).show();
            if (isCardChecked) {

                extras.put("event11", AnalyticsPage.APP_LAUNCHED_EVENT11);
                TrackingHelper.trackCardPageProp1(AnalyticsPage.APP_LAUNCHED_prop1,
                        AnalyticsPage.APP_LAUNCHED_pev1, extras);

            } else {
                extras.put("my.prop1", AnalyticsPage.APP_LAUNCHED_prop1);
                extras.put("pe", "lnk_o");
                extras.put("pev1", AnalyticsPage.APP_LAUNCHED_pev1);
                TrackingHelper.trackBankPage(null, extras);
            }
        }


        // **Activity manager has to be set before using Track Helper*/
        //DiscoverActivityManager.setActiveActivity(this);


        KeepAlive.setBankAuthenticated(false);
        KeepAlive.setCardAuthenticated(false);

        if (!DiscoverApplication.logoutErrorMessage) {

            DiscoverApplication.logoutErrorMessage = true;
        }

        if (isCardLogin() && isCardPasscodeLogin()) {
            TrackingHelper.trackPageViewLogin(AnalyticsPage.PASSCODE_LOGIN);
        }

        final Bundle bundle = getIntent().getExtras();

        if (bundle != null && bundle.getBoolean("FLAG") == true) {
            FacadeFactory.getBankLoginFacade().setDeepLinkToast(bundle, this);
        }

        //Get QV Visible State
        if (savedInstanceState != null) {
            doMaintainQVState = savedInstanceState.getBoolean("doMaintainQVState");
        }

        activityRootView.post(new Runnable() {

            @Override
            public void run() {
                Fragment frag = getFragmentManager().findFragmentById(
                        R.id.fastcheck_frag);
                if (frag != null) {
                    boolean isQuickViewEnabled = FacadeFactory.getCardFacade()
                            .getQuickViewEnabledState(frag, LoginActivity.this);
                    if (!(FacadeFactory.getCardLoginFacade().getQvAnimationKillSwitch())) {
                        if ((DiscoverApplication.isInQuickViewMode || (!doMaintainQVState && isQuickViewEnabled))) {

                            relativeLayoutToggle.setVisibility(View.GONE);
                            footer.setVisibility(View.VISIBLE);
                            DiscoverApplication.isInQuickViewMode = true;
                            showQuickViewPage();
                        }
                    }


                    if (DiscoverApplication.isInQuickViewMode) {
                        getWindow()
                                .setSoftInputMode(
                                        WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                    } else {
                        if (Utils.isRunningOnHandset(LoginActivity.this)) {
                            hideQuickViewPage(false, false);
                        } else {
                            hideQuickViewPage(false);
                        }
                    }
                }
            }
        });

        // Temp Comment: Commented due to exception
        /*
         * FacadeFactory.getBankLoginFacade().setTMXSessionId(
		 * ThreatMatrixSingleton.Instance().getSessionID());
		 */
        setupButtons();

        getHighlightedFeatureStatus();
        // START - Splash animation changes

        //TODO need to check if we need to start animation from here as we are doing same thing from onresume as well.
        if (objApplication.isShowAnimation()) {
            RelativeLayout layout = (RelativeLayout) findViewById(R.id.login_start_layout);
            ViewTreeObserver vto = layout.getViewTreeObserver();
            vto.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    if (splashScreenStart) {
                        moveLogoToUp(INITIAL_ANIM_DURATION);
                        splashScreenStart = false;
                    }
                }
            });
        } else {
            //  displayActiveLoginMode(false);
            versionAndPrivacyLayout.setVisibility(View.VISIBLE);
            //ADA
            idPasswordView.setVisibility(View.VISIBLE);
            footer.setVisibility(View.VISIBLE);
        }
        // END - Splash animation changes
        //QV Univ Migration Start
        if (!Utils.isRunningOnHandset(LoginActivity.this)) {
            //Get QV Visible State
            if (savedInstanceState != null) {
                doMaintainQVState = savedInstanceState.getBoolean("doMaintainQVState");
            }

            if (!doMaintainQVState) {
                //To Reset deeplink values
                FacadeFactory.getBankLoginFacade().resetDeepLinkValues();
                FacadeFactory.getCardLoginFacade().resetDeepLinkValues();

            }

            //Defect 202571: Initialize quickview page
            initQuickViewPage();
        }

        //QV Univ Migration End
        //Added for the User Story US45678-Removing Landscape Support on Handset
        CommonUtils.lockOrientationInPortrait(DiscoverActivityManager.getActiveActivity());
        //ATM disclosure modal changes - US51185
        DiscoverApplication.getLocationPreference().resetLocationPreferenceCache();

    }

    /*
    It gets the saved timestamp.
    Get the clean up time from infomessage.json.
    If value from infomessage.json is greater than diff(current time- saved time)
        clear all cache
    else
       clear cache except deals cache folder
     */
    private void clearCacheMemory() {
        long lastTimeStamp = FileCache.getTimeStampValue();
        String daysToDelete = InfoMessageUtils.Instance().getErrorMessage(FileCache.DEALS_CLEAN_UP_DAYS);
        if (null == daysToDelete || daysToDelete.equalsIgnoreCase("")) {
            daysToDelete = FileCache.MAX_TOTAL_DAYS_TO_STORE_DEALS_IMAGE;
        }
        if (Utils.getTimeStempDifference(lastTimeStamp) > Integer.parseInt(daysToDelete)) {
            new FileCache(this).clear();
        } else {
            new FileCache(this).clearCachePartial();
        }
    }

    private boolean scrollToPosition(final int position) {
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            scrollContainer = (RelativeLayout) findViewById(R.id.scrollContainer);
            new Handler().post(new Runnable() {
                @Override
                public void run() {
                    try {
                        scrollContainer.animate().translationY(position)
                                .setDuration(LANDSCAPE_LOGO_ANIM_DURATION);
                    } catch (Exception e) {
                        /* hkakadi
                         * In few devices crash reported on animate()
						 */
                        if (null != scrollContainer)
                            scrollContainer.setTop(scrollContainer.getTop() + position);
                    }
                }
            });
            return true;
        } else
            return false;
    }

    private void isAdaEnabled(boolean oncreateFlag, boolean onResumeFlag) {
        Intent screenReaderIntent = new Intent(
                "android.accessibilityservice.AccessibilityService");
        screenReaderIntent
                .addCategory("android.accessibilityservice.category.FEEDBACK_SPOKEN");
        List<ResolveInfo> screenReaders = getPackageManager()
                .queryIntentServices(screenReaderIntent, 0);
        Cursor cursor = null;
        int status = 0;
        ContentResolver cr = getContentResolver();

        List<String> runningServices = new ArrayList<String>();
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (RunningServiceInfo service : manager
                .getRunningServices(Integer.MAX_VALUE)) {
            runningServices.add(service.service.getPackageName());
        }

        for (ResolveInfo screenReader : screenReaders) {
            cursor = cr.query(
                    Uri.parse("content://"
                            + screenReader.serviceInfo.packageName
                            + ".providers.StatusProvider"), null, null, null,
                    null);
            if (oncreateFlag == true) {
                if (cursor != null && cursor.moveToFirst()) { // this part works
                    // for Android
                    // <4.1
                    status = cursor.getInt(0);
                    cursor.close();
                    if (status == 1) {
                        // screen reader active!
                        if (!isCardLogin())

                            FacadeFactory.getBankLoginFacade().forceTrackPage(
                                    R.string.userwith_ada_enabled);

                    }
                } else { // this part works for Android 4.1+
                    if (runningServices
                            .contains(screenReader.serviceInfo.packageName)) {
                        // screen reader active!
                        if (!isCardLogin())

                            FacadeFactory.getBankLoginFacade().forceTrackPage(
                                    R.string.userwith_ada_enabled);

                    }
                }
            }
            if (onResumeFlag == true) {
                if (cursor != null && cursor.moveToFirst()) { // this part works
                    // for Android
                    // <4.1
                    status = cursor.getInt(0);
                    cursor.close();
                    if (status == 1) {
                        // screen reader active!
                        if (!isCardLogin())

                            FacadeFactory.getBankLoginFacade().forceTrackPage(
                                    R.string.userwith_inapp_ada_enabled);

                    } else {
                        if (!isCardLogin())

                            FacadeFactory.getBankLoginFacade().forceTrackPage(
                                    R.string.userwith_inApp_ada_disabled);
                        // screen reader inactive

                    }
                } else { // this part works for Android 4.1+
                    if (runningServices
                            .contains(screenReader.serviceInfo.packageName)) {
                        // screen reader active!
                        if (!isCardLogin())

                            FacadeFactory.getBankLoginFacade().forceTrackPage(
                                    R.string.userwith_inapp_ada_enabled);

                    } else {
                        if (!isCardLogin())

                            FacadeFactory.getBankLoginFacade().forceTrackPage(
                                    R.string.userwith_inApp_ada_disabled);
                        // screen reader inactive

                    }
                }

            }

        }
    }

    /**
     * This method fixes an issue where, in a signed build, when the app is
     * resumed, LoginActivity can be re-created when not needed, and appear
     * above a current non-LoginActivity.
     *
     * This is a workaround for a bug in Android, see link for more info.
     *
     * http://code.google.com/p/android/issues/detail?id=2373#c21
     */
    private void preventDuplicateLoginScreens() {
        if (!isTaskRoot()) {
            final Intent intent = getIntent();
            final String intentAction = intent.getAction();
            if (intent.hasCategory(Intent.CATEGORY_LAUNCHER)
                    && intentAction != null
                    && intentAction.equals(Intent.ACTION_MAIN)) {
                finish();
            }
        }
    }

    /**
     * Assign local references to interface elements that we need to access in
     * some way.
     */
    private void loadResources() {
        final int maxIdLength = 16;
        final int maxPasswordLength = 32;

        final InputFilter[] filters = new InputFilter[1];
        filters[0] = new InvalidCharacterFilter();
        idField = (EditText) findViewById(R.id.username_field);
        idField.setFilters(filters);
        idField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(
                maxIdLength)});

        passField = (EditText) findViewById(R.id.password_field);
        passField.setTypeface(idField.getTypeface());
        passField.setFilters(filters);
        passField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(
                maxPasswordLength)});

        loginButton = (LinearLayout) findViewById(R.id.loginButton);

        userIdLine = (View) findViewById(R.id.horizontal_separator_0);
        passFieldLine = (View) findViewById(R.id.horizontal_separator_1);
        mLoginButton = (LinearLayout) findViewById(R.id.login_btn_container);
        relativeLayoutToggle = (RelativeLayout) findViewById(R.id.relativeLayoutToggle);
        footer = (LinearLayout) findViewById(R.id.toolbar_container);
        footer.setVisibility(View.GONE);
        goToBankButton = (RelativeLayout) findViewById(R.id.bankToggle);
        goToCardButton = (RelativeLayout) findViewById(R.id.cardToggle);
        checkMarkCard = (FontAwesomeTextView) findViewById(R.id.FontAwesomeCheckMarkCard);
        checkMarkBank = (FontAwesomeTextView) findViewById(R.id.FontAwesomeCheckMarkBank);
        bank = (TextView) findViewById(R.id.checkBoxBank);
        card = (TextView) findViewById(R.id.checkBoxCard);
        toggleSelection = (LinearLayout) findViewById(R.id.linearLayoutToggle);
        activityRootView = getContainerView();
        feedBackButton = (LinearLayout) findViewById(R.id.feedbackButton);
        atmButton = (LinearLayout) findViewById(R.id.atmButton);
        helpButton = (LinearLayout) findViewById(R.id.helpButton);
        productsButton = (LinearLayout) findViewById(R.id.productsButton);
        forgotPaswordLayout = (TextView) findViewById(R.id.tv_forgot_password_lable);
        rememberChkbox = (FontAwesomeTextView) findViewById(R.id.cb_remember);
        rememberTick = (FontAwesomeTextView) findViewById(R.id.remember_tick);
        rememberLayout = (LinearLayout) findViewById(R.id.remember_view_container);
        registerLinkLayout = (TextView) findViewById(R.id.tv_register_link_lable);
        registerLinkLayout.setOnClickListener(this);
        passcodeLinkLayout = (TextView) findViewById(R.id.tv_passcode_link_lable);
        versionAndPrivacyLayout = (RelativeLayout) findViewById(R.id.version_and_privacy_layout);
        idPasswordView = (FrameLayout) findViewById(R.id.id_and_passcode_container);
        updateRegisterLinkLayout(this);

        loginRootView = (RelativeLayout) findViewById(R.id.login_main_layout);
        relativeLayoutToggle = (RelativeLayout) findViewById(R.id.relativeLayoutToggle);

        //QV Univ Migration -Start
        if (!Utils.isRunningOnHandset(LoginActivity.this)) {
            fastcheck_frag_tab = findViewById(R.id.fastcheck_frag_tab);
            layoutQuickViewAnim = (FrameLayout) findViewById(R.id.layoutQuickViewAnim);
        }
        //QV Univ Migration -Start
        quickView = (TextView) findViewById(R.id.quickView);
        fastcheckFragView = findViewById(R.id.fastcheck_frag);
        discoverLogo = (ImageView) findViewById(R.id.discover_logo);
        pwdRedBtn = (ImageView) findViewById(R.id.pwd_red_button);
        uidRedBtn = (ImageView) findViewById(R.id.uid_red_button);
        mEmptyView = (View) findViewById(R.id.empty_view_above_logo);
        versionNumber = (TextView) findViewById(R.id.version_number);
        privacy_and_terms = (TextView) findViewById(R.id.privacy_and_terms);
        fdic_disclaimer_view = (TextView) findViewById(R.id.fdic_disclaimer_view);
        Calendar d = Calendar.getInstance();
        fdic_disclaimer_view.setText(getResources().getString(
                R.string.discover_copyright_symbol)
                + d.get(Calendar.YEAR)
                + " "
                + getResources().getString(R.string.discover_copyright_text1));


            try {
                if(!Globals.getAppVersion().isEmpty()&&Globals.getAppVersion()!=null)
                {
                    versionName = Globals.getAppVersion();
                }else
                versionName = getPackageManager().getPackageInfo(getPackageName(),
                        0).versionName;
                versionString = new SpannableString("Version " + versionName);
                versionNumber.setText(versionString);
                versionNumber.setContentDescription(versionString + " " + getResources().getString(R.string.link_text));
            } catch (Exception e) {
                e.printStackTrace();
            }


        /** Start for passcode */
        vLogin = (RelativeLayout) this.findViewById(R.id.regular_login);

        vPasscode = (RelativeLayout) this.findViewById(R.id.passcode_login);
        fieldTVs[0] = (PasscodeCircularEditText) findViewById(R.id.passcode01);
        fieldTVs[1] = (PasscodeCircularEditText) findViewById(R.id.passcode02);
        fieldTVs[2] = (PasscodeCircularEditText) findViewById(R.id.passcode03);
        fieldTVs[3] = (PasscodeCircularEditText) findViewById(R.id.passcode04);
        // US37334 Changes start -- pkuma13
        // passcodeForgot = (TextView) findViewById(R.id.passcode_forgot);
        // US37334 Changes end -- pkuma13
        passcodeUserIdLogin = (TextView) findViewById(R.id.passcode_user_id_login);
        /**start US71607 Fingerprint login screen option */
        fingerPrintLoginLabel = (TextView) findViewById(R.id.tv_fingerprint_link_label);
        /**end US71607 Fingerprint login screen option */
        setupPasscode();
//		hideToggleCLA();//us20958
        /** END for passcode */
        rememberLayout.setTag(Integer.valueOf(0));
        mLoginButton.setTag(Integer.valueOf(0));
        loginSubOptions = (RelativeLayout) findViewById(R.id.login_sub_options_container);
        passcodeLoginSubOptions = (RelativeLayout) findViewById(R.id.passcode_links); // changed for US71607 Fingerprint login screen option
        setFlickerSolverImageDimens();
        // BEGIN, default to turning of geofence visual aid, hlin0, 7.4
        geofence_link = (TextView) findViewById(R.id.geofence_link);
        vertical_separator2 = (TextView) findViewById(R.id.vertical_separator2);
        geofence_link.setVisibility(View.GONE); // default to not show
        vertical_separator2.setVisibility(View.GONE); // default to not show
        if (Utils.isRunningOnHandset(this)) {
            boolean includeGeofenceVisual = false;
            try {
                ApplicationInfo ai = this.getPackageManager().getApplicationInfo(this.getPackageName(), PackageManager.GET_META_DATA);
                includeGeofenceVisual = ((Boolean) ai.metaData.get(MANIFEST_METADATA_GEOFENCE_VISUAL_IND)).booleanValue();
            } catch (PackageManager.NameNotFoundException e) {
                Log.d(TAG, "loadResources()...gets NameNotFoundException!");
            }
            //including kill switch and pilot user check - US82881
            if (includeGeofenceVisual || (Utils.getBatteryHealth(this)== BatteryManager.BATTERY_HEALTH_GOOD && Utils.isGeofenceAvailable(getContext()))) showGeofenceVisual();
        }
        // END, default to turning of geofence visual aid, hlin0, 7.4
    }

    private void showGeofenceVisual() {
        // process geofence visual testing tool, hlin0, 7.4
        SharedPreferences geofenceSharedPrefs = getApplicationContext()
                .getSharedPreferences(SHARED_PREF_GEOFENCE, Context.MODE_PRIVATE);
        String geofenceResponseStr = geofenceSharedPrefs.getString(SHARED_PREF_GEOFENCE_RESP_KEY, null);
        boolean geofenceVisual = geofenceSharedPrefs.getBoolean(SHARED_PREF_GEOFENCE_VISUAL_IND,false);
        Log.d(TAG, "showGeofenceVisual()...geofenceResponseStr: " + geofenceResponseStr);
        if (geofenceVisual && Utils.isRunningOnHandset(this)) {
            privacy_and_terms.setPadding(privacy_and_terms.getPaddingLeft(), privacy_and_terms.getPaddingTop(), 0, privacy_and_terms.getPaddingBottom());
            geofence_link.setVisibility(View.VISIBLE);
            vertical_separator2.setVisibility(View.VISIBLE);
        }
    }

    private void setClickListeners() {
        mLoginButton.setOnClickListener(this);
        goToBankButton.setOnClickListener(this);
        goToCardButton.setOnClickListener(this);
        feedBackButton.setOnClickListener(this);
        atmButton.setOnClickListener(this);
        helpButton.setOnClickListener(this);
        productsButton.setOnClickListener(this);
        forgotPaswordLayout.setOnClickListener(this);
        loginButton.setOnClickListener(this);
        rememberLayout.setOnClickListener(this);
        // US37334 Changes start -- pkuma13
        // passcodeForgot.setOnClickListener(this);
        // US37334 Changes end -- pkuma13
        passcodeLinkLayout.setOnClickListener(this);
        versionNumber.setOnClickListener(this);
        privacy_and_terms.setOnClickListener(this);
        geofence_link.setOnClickListener(this);
        fdic_disclaimer_view.setOnClickListener(this);
        quickView.setOnClickListener(this);
        pwdRedBtn.setOnClickListener(this);
        uidRedBtn.setOnClickListener(this);
        passcodeUserIdLogin.setOnClickListener(this);
        /**start US71607 Fingerprint login screen option */
        fingerPrintLoginLabel.setOnClickListener(this);
        /**end US71607 Fingerprint login screen option */
    }

    //Commented as part of login migration as we didn't observe any issues after commenting as well. Need to check the validity of the below patch after code comment.
    //Changes start

    /**
     * Check to see if the user just logged out, if the user just logged out
     * show the message.
     */
    private void maybeShowUserLoggedOut() {
        final Intent intent = getIntent();
        final Bundle extras = intent.getExtras();
        if (extras != null) {
            if (extras.getBoolean(IntentExtraKey.SHOW_SUCESSFUL_LOGOUT_MESSAGE,
                    false)) {
                showLogoutSuccessful();
                getIntent().putExtra(
                        IntentExtraKey.SHOW_SUCESSFUL_LOGOUT_MESSAGE, false);
                passField.getText().clear();
                clearPasscodeFields();
            } else if (extras.getBoolean(IntentExtraKey.SHOW_USER_ID_AVAILABLE_ERROR_MSG,
                    false)) {
                showLongToast(getResources().getString(
                        R.string.invalid_user_id));
                idField.getText().clear();
                passField.getText().clear();

            }/**start added for US65495; added 401 error message for Merge flow, on selection of "X" button */
            else if (extras.getBoolean(IntentExtraKey.SHOW_CLA_MERGE_SESSION_OUT_ERROR_MSG,
                    false)) {
                String errorMessage = getResources().getString(R.string.session_expired_body);
                errorMessage = Html.fromHtml(errorMessage).toString();
                showLongToast(errorMessage);
                idField.getText().clear();
                passField.getText().clear();
            }
            /**end added for US65495; added 401 error message for Merge flow, on selection of "X" button */

        }
    }

    //Changes ends

    /**
     * Check to see if the user's session expired
     */

    private void maybeShowSessionExpired() {

        final Intent intent = getIntent();
        final Bundle extras = intent.getExtras();
        if (extras != null) {
            if (extras.getBoolean(IntentExtraKey.SESSION_EXPIRED, false)) {
                showSessionExpired();
                getIntent().putExtra(IntentExtraKey.SESSION_EXPIRED, false);
                passField.getText().clear();
                clearPasscodeFields();
            }
        }
    }

    /**
     * Check to see if an error occurred which lead to the navigation to the
     * Login Page
     */
    private void maybeShowErrorMessage() {
        final Intent intent = getIntent();
        final Bundle extras = intent.getExtras();
        if (extras != null) {
            final String errorMessage = extras
                    .getString(IntentExtraKey.SHOW_ERROR_MESSAGE);
            final String errorCode = extras
                    .getString(IntentExtraKey.ERROR_CODE);
            if (!CommonUtils.isNullOrEmpty(errorCode)) {
                showErrorMessage(errorCode, errorMessage);
            } else if (!CommonUtils.isNullOrEmpty(errorMessage)) {
                showErrorMessage(errorMessage);
                getIntent().putExtra(IntentExtraKey.SHOW_ERROR_MESSAGE,
                        StringUtility.EMPTY);

            }
        }
    }

    private void maybeFromConfirmFraudFlow() {
        final Intent intent = getIntent();
        final Bundle extras = intent.getExtras();
        boolean isSSNMatched = false;
        String whereFrom = null;
        if (extras != null) {
            whereFrom = extras.getString("flowName");
            isSSNMatched = extras.getBoolean("isSSNMatched");
            String userid = extras.getString("userid");
            String password = extras.getString("password");
            if ("SSOFraudConfirmBackToBank".equals(whereFrom) && isSSNMatched) {

                FacadeFactory.getBankLoginFacade().initializeBankLoginDetails(
                        userid, password);

            } else if ("SSOFraudConfirmBackToBank".equals(whereFrom)) {

                checkBankToggle();
                displayActiveLoginMode(false);
            }
        }
    }

    /**
     * Display the error message provided in the argument list in red text.
     *
     * @param errorMessage Reference to error message that is to be displayed.
     */
    public void showErrorMessage(final String errorMessage) {
        final Context context = DiscoverActivityManager.getActiveActivity();
        HashMap<String, Object> extras = new HashMap<String, Object>();
        ///changed for Unique visitor count analytic issue. while error login bank suite also got fired before this fix.
        if (!isCardChecked) {

            extras.put(AnalyticsPage.CONTEXT_PROPERTY_10, FacadeFactory
                    .getBankLoginFacade().getBankLoginString() + " " + errorMessage);
            TrackingHelper.trackBankPage(null, extras);
            Log.i("my.prop10", FacadeFactory.getBankLoginFacade()
                    .getBankLoginString() + " " + errorMessage);
        }

        if (isCardLogin() || isCardPasscodeLogin()) {
            showLongToast(errorMessage);
            if (!isCardPasscodeLogin())
                showError();
        } else if (!isCardLogin()) {
            if (isBankPasscodeLogin()) {
                vibrateandShake();
                showShortToast(errorMessage);
                if (!isBankPasscodeLogin())
                    showError();
                final int nextInput = getNextInput();
                fieldTVs[nextInput].requestFocus();
            } else {
                if (!isCardLogin() && !isErrorModalShown) {

                    FacadeFactory.getBankLoginFacade().forceTrackPage(
                            R.string.login_failed);
                    showShortToast(errorMessage);
                    showError();
                } else {
                    isErrorModalShown = false;
                }
            }
        }

        // seconds
        username = StringUtility.EMPTY;
        idField.clearFocus();
        passField.clearFocus();
    }

    public void showErrorMessage(final String errorCode,
                                 final String errorMessage) {
        HashMap<String, Object> extras = new HashMap<String, Object>();

        // Need to show a unique message for invalid login attempt when on
        // passcode, can't determine from CardErrorResponseHandler
        if (errorCode.equalsIgnoreCase("4032116") && isCardPasscodeLogin()) {
            if (isCardLogin()) {
                Globals.setBankLoginSelected(false);
                //  TrackingHelper.trackCardPageProp1(AnalyticsPage.USERIDLOGIN_prop1, AnalyticsPage.USERIDLOGIN_pev1);
                isUserIDLogin = true;
                idField.setHint(R.string.card_user_id_string);
                checkCardToggle();
                displayActiveLoginMode(false);
            } else {
                Globals.setBankLoginSelected(true);
                isBankUserIDLogin = true;
                idField.setHint(R.string.bank_user_id_string);
                checkBankToggle();
                displayActiveLoginMode(false);
            }

            if (toggleSelection.getVisibility() == View.INVISIBLE) {
                relativeLayoutToggle.setVisibility(View.VISIBLE);
                toggleSelection.setVisibility(View.VISIBLE);
                relativeLayoutToggle.invalidate();
            }
            showLongToast(errorMessage);
        } else {
            //removing as per US63033
            /*if (isCardLogin()) {
                extras.putAll(TrackingHelper.getProp10Error(
                        AnalyticsPage.FAILED_LOGIN, errorMessage));
                TrackingHelper.trackCardPage(null, extras);
            }*/
            if (isCardLogin() && !isUserIDLogin && !pUtils.doesDeviceTokenExist()) {
                // if passcode was disabled but userinterface not yet in sync
                if (!isPasscodeLogin)
                    showError();
                displayActiveLoginMode(false);
            }
            if (!isCardLogin() && !isBankUserIDLogin
                    && !bankpasscodeUtils.doesDeviceTokenExist()) {
                // if passcode was disabled but user interface not yet in sync
                if (!isBankPasscodeLogin())
                    showError();
                displayActiveLoginMode(false);
            }

            if (isCardPasscodeLogin()) {

                if ("401".equals(errorCode) || "4011103".equals(errorCode) || "4012109".equals(errorCode)) {
                    // Added for bank side.
                    vibrateandShake();
                    showErrorMessage(errorMessage);

                    extras.put("my.prop34=", "Log In - Passcode");
                    extras.put("my.eVar34 =", "Log In - Passcode");
                    clearPasscodeFields();
                    extras.putAll(TrackingHelper.getProp10Error(
                            AnalyticsPage.INVALID_PASSCODE, errorMessage));
                } else {
                    clearPasscodeFields();
                    // sgoff0 DEFECT 105439
                    // errorTextView.setText("");
                }
                //removing as per US63033
                //   TrackingHelper.trackCardPage(AnalyticsPage.PASSCODE_LOGIN, extras);
            } else {
                extras.put("my.prop34 =", "Log In - Password");
                extras.put("my.eVar34 =", "Log In - Password");
                if ("4011103".equals(errorCode)) {
                    extras.putAll(TrackingHelper.getProp10Error(
                            AnalyticsPage.ACCOUNT_LOCKED_LAST_ATTEMPT, errorMessage));
                    // handle the proper highlighting
                    showErrorMessage(errorMessage);
                    // show error message
                    resetFocus();//adding this fix for 224166
				/*
				 * errorTextView.setMovementMethod(LinkMovementMethod
				 * .getInstance());
				 * errorTextView.setText(Html.fromHtml(errorMessage));
				 */

                } else if (errorMessage != null) {
                    extras.putAll(TrackingHelper.getProp10Error(
                            AnalyticsPage.INCORRECTUSERIDORPASSWORD, errorMessage));
                    showErrorMessage(errorMessage);
                } else {
                    hideKeyboard();
                }
                //removing as per US63033
                // TrackingHelper.trackCardPage(AnalyticsPage.STARTING, extras);
            }
            username = StringUtility.EMPTY;
        }
    }

    /**
     * Display session expired message
     */
    public void showSessionExpired() {
        TrackingHelper.trackPageView(AnalyticsPage.LOG_OFF);
        DiscoverApplication.isInQuickViewMode = false;
        doMaintainQVState = true;
        /**start US79969 Remove / Show FP Modal on Logout from app*/
//        showLongToast(getResources().getString(R.string.session_expired_body));
        final long TOAST_LONG_DURATION_TIMEOUT = 1500;
        showLongToastWithDuration(getResources().getString(R.string.session_expired_body), TOAST_LONG_DURATION_TIMEOUT);
        /**end US79969 Remove / Show FP Modal on Logout from app*/
    }

    /**
     * Display successful logout message at top of the screen
     */
    public void showLogoutSuccessful() {
        DiscoverApplication.isInQuickViewMode = false;
        doMaintainQVState = true;
        Globals.setvisitedWNPage(false);

        // Fix for unnecessary sessionexpiry message showing at manual log out.

        if (!Globals.isFromCardSide()) {

            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    R.string.logout);
            /*Defect:244145-start*/
            isBankUserIDLogin = false;
            displayActiveLoginMode(false);
            /*Defect:244145-end*/
        } else {
            TrackingHelper.trackPageView(AnalyticsPage.LOG_OFF);
        }
        isUserManualLoggedOut = true;
        showLongToast(getString(R.string.logout_sucess));
        showKeyboard();//Defect Id:3665

    }

    /**
     * Called as a result of the activity's being brought to the front when
     * using the Intent flag FLAG_ACTIVITY_REORDER_TO_FRONT.
     */
    @Override
    protected void onNewIntent(final Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        //QV Univ Migration -Start
        if (!Utils.isRunningOnHandset(LoginActivity.this)) {
            //Defect 202571: Initialize quickview page if activity reused
            DiscoverApplication.isInQuickViewMode = false;
            doMaintainQVState = false;
            //Crashlytics fix #1595
            if(layoutQuickViewAnim != null) {
                initQuickViewPage();
            }
        }
        //QV Univ Migration -Start
    }

    /**
     * Resume the activity
     */
    @Override
    public void onResume() {

        super.onResume();

        //nk start
        final Intent receivedIntent = getIntent();
        final Bundle bundle = receivedIntent.getExtras();

        if(bundle != null) {
            String result = bundle.getString(LivePersonConstants.lpNotificationKey);
            if (result != null && result.equalsIgnoreCase(LivePersonConstants.lpNotificationValue)) {
                Toast toast = Toast.makeText(this, R.string.please_login_to_read_our_response, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        }
        //nk end
        isActivitysOnSaveInstanceStateCalled = false;

        SharedPreferences sharedPref = getSharedPreferences(getResources().getString(R.string.post_login_username), Context.MODE_PRIVATE);
        isApplyNowContentShowing = sharedPref.getBoolean(getResources().getString(R.string.isUserLoggedInFirstTime), true);

        // Proper card|bank Account Type removed on orientation change
        // (This is due to the BaseActivity onResume reloading prefs only stored
        // on login)
        // (Must set before setApplicationAccount())

        /**start Added for US83286  - Android Fingerprint - Kill-switch
         * By default disable FP link & Let pre-auth call happen & depending on Kill-switch value from pre-auth call show FP link & modal */
//        Log.d("sach_fp_modal", "onResume: by default disable link");
        enableDisableFPLink(false);
        /**end Added for US83286  - Android Fingerprint - Kill-switch*/

        if (restoreToggle >= 0) {
            Globals.setCurrentAccount(AccountType.values()[restoreToggle]);
            Log.d("UniversalUpgradation", "Onresume 1");
            restoreToggle = NO_TOGGLE_TO_RESTORE;
        }
        activityRootView.getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);
        boolean animationRunning = false;

        // code uncommented due to wrongly commented out earlier
        if (objApplication.isLoginToCardFromRegisterFlow()) {
            isCardChecked = true;
            objApplication.setLoginToCardFromRegisterFlow(false);
        }


        if (!objApplication.isShowAnimation()) {
            animationRunning = false;
            if (!Globals.isBankLoginSelected()) {
                /* Added below line to set onconfig UI - osawant - Start*/
                Globals.loadPreferences(this, AccountType.CARD_ACCOUNT);
                checkCardToggle();
                displayActiveLoginMode(false);
            }
            if (Globals.isBankLoginSelected()) {
                /* Added below line to set onconfig UI - osawant - Start*/
                Globals.loadPreferences(this, AccountType.BANK_ACCOUNT);
                checkBankToggle();
                displayActiveLoginMode(false);
            }
        } else {
            animationRunning = true;
            objApplication.setShowAnimation(false);
        }

        //US50435
		/* android wear connect added */
        AndroidWearConnectivity con = AndroidWearConnectivity
                .getInstance(getApplicationContext());
        con.getConnect(getApplicationContext());
		/* android wear connect added */

        /* androidpay connectivity*/
        AndroidPayConnectivity androidPayConnectivity = AndroidPayConnectivity.getInstance(getApplicationContext());
        androidPayConnectivity.getConnect(getApplicationContext());
         /* androidpay connectivity*/

        if (Utils.isRunningOnHandset(LoginActivity.this)) {
            isAdaEnabled(false, true);
        }
        DiscoverActivityManager.setActiveActivity(this);

        // Check if the login activity was launched because of a logout
        maybeShowUserLoggedOut();

        // Check if the login activity was launched because of a session expire
        maybeShowSessionExpired();

        // Check if the login activity was launched because of an invalid token
        maybeShowErrorMessage();

        //QV Univ Migration Start
        if (!Utils.isRunningOnHandset(LoginActivity.this)) {
            //Quick View Redesign
            layoutQuickViewAnim.setOnTouchListener(new OnTouchListener() {

                @Override
                public boolean onTouch(View arg0, MotionEvent event) {


                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:

                            if ((event.getY() > rootViewStartPoint)
                                    && (event.getY() < qvArcImgStartPoint)) {
                                istouchStartPointValid = true;
                            } else {
                                istouchStartPointValid = false;
                            }

                            break;

                        case MotionEvent.ACTION_MOVE:
                            break;

                        case MotionEvent.ACTION_UP:

                            if ((istouchStartPointValid
                                    && (event.getY() > qvArcImgStartPoint)) || (istouchStartPointValid)) {
                                if (DiscoverApplication.isInQuickViewMode) {
                                    //Fix for defect #203389 - START
                                    removeQuickViewFragmentWithAnimation(StringUtility.EMPTY);
                                    //hideQuickViewPage(true);
                                    //Fix for defect #203389 - END
                                }
                            }

                            break;
                    }

                    return true;
                }
            });
        }
        //QV Univ Migration End
        maybeFromConfirmFraudFlow();

        final int lastError = getLastError();
        saveUserId = Globals.isRememberId();

        // Do not change screen appearance as it was just completed by restoring
        // state
        // due to orientation change. Simply resets flag since we've caught
        // orientation.
        if (restoreError) {
            restoreError = false;
        }
        // Do not load saved credentials if there was a previous login attempt
        // which failed because of a lock out
        else if (StandardErrorCodes.EXCEEDED_LOGIN_ATTEMPTS != lastError
                && RegistrationErrorCodes.LOCKED_OUT_ACCOUNT != lastError) {
			/*
			 * if (idField.length() < 1) { // loadSavedCredentials(); }
			 */
        } else {
            // Clear Text Fields for username and password
            clearInputs();

            // Uncheck remember user id checkbox without remembering change
            // setCheckMark(false, false);
            deleteAndSaveCurrentUserPrefs();
        }
        // The check box got unchecked from loadSavedCredentials
        // but should be checked from a rotation change.
		/*
		 * if (!saveUserId && saveIdWasChecked) { setCheckMark(saveIdWasChecked,
		 * false); }
		 */

        // Show splash screen while completing pre-auth, if pre-auth has not
        // been done and
        // application is be launched for the first time

        if ((getIntent().hasCategory(Intent.CATEGORY_LAUNCHER) || getIntent().getBooleanExtra("fromWidget", false)) &&
                !getIntent().getBooleanExtra("alreadyLaunched", false)) {
            Log.d("UniversalUpgradation", "Onresume 2");
            getIntent().putExtra("alreadyLaunched", true);
            startPreAuth();

            //TODO need to check if we need below mentioned code
            if (pauseTimeStamp != 0) {
                final Calendar resumeCalendarInstance = Calendar.getInstance();
                long currentTimeStamp = resumeCalendarInstance
                        .getTimeInMillis();
                if (DiscoverActivityManager.getActiveActivity() instanceof LoginActivity) {

                    final float durationInSecs = (int) ((currentTimeStamp - pauseTimeStamp) / 1000);
                    if (durationInSecs > FacadeFactory.getBankLoginFacade()
                            .getMaxIdleTime()) {
//						FacadeFactory.getBankLoginFacade()
//								.setTMXSessionId(
//										ThreatMatrixSingleton.Instance()
//												.getSessionID());

                    }
                }
            }
            //TODO till here
            pauseTimeStamp = 0;
        } else {
            // BankUrlManager.setLinks();
            Log.d("UniversalUpgradation", "Onresume 2 else");
            FacadeFactory.getBankLoginFacade().seturlLinksBankURLManager();
//            Log.d("sach_fp_modal", "onResume: calling checkVisibilityOfFPLink");
            /**start Added for US83286  - Android Fingerprint - Kill-switch; */
            checkVisibilityOfFPLink();
            /**end Added for US83286  - Android Fingerprint - Kill-switch */
            // showLoginPane();
            showApplyNowBanner();

        }
        Log.d("UniversalUpgradation", "Onresume Outside if");
        isFromOrientaionChange = false;
        // If previous screen was Strong Auth Page then clear text fields and
        // show text fields in red
        // because that means the user did not login successfully
        if (null != DiscoverActivityManager.getPreviousActiveActivity()
                && DiscoverActivityManager.getPreviousActiveActivity().equals(
                FacadeFactory.getBankLoginFacade()
                        .getEnhancedAccountSecurityActivity())) {

            // getErrorHandler().showErrorsOnScreen(this, null);
            if (!isPasscodeLogin || !isBankPasscodeLogin())
                showError();
            DiscoverActivityManager.clearPreviousActiveActivity();
        }

        FacadeFactory.getCardLoginFacade().firstRunCheck(this);

        handleDeeplinking();


        if (!animationRunning) {
            // US37429 changes start
            passcodeLinkLayout.setVisibility(View.GONE);
            // US37429 changes end

            // US35749 Fix start
            updateRegisterLinkLayout(this);
            // US35749 Fix end

            // code uncommented due to wrongly commented out earlier
            if (objApplication.isLoginKeyBoardStateVisible()) {
                if (!DiscoverApplication.isInQuickViewMode && !isApplyNowContentShowing) {
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                }
            }
            // code uncommented due to wrongly commented out earlier
            if (showErrorLine && !isCardPasscodeLogin())
                showError();
            // Fix for alpha numeric keyboard popping when passcode fields are displayed.
            //if (!isCardPasscodeLogin()) {
            if (!isCardPasscodeLogin() && !isBankPasscodeLogin()) {
                idField.setFocusableInTouchMode(true);
                passField.setFocusableInTouchMode(true);
                int focusedViewWhenLeavingLogin = objApplication.getFocusedView();
                if (TextUtils.isEmpty(idField.getText()) && TextUtils.isEmpty(passField.getText())) {
                    // If id field is empty, then it must have focus
                    idField.setCursorVisible(true);
                    passField.setCursorVisible(true);
                    idField.requestFocus();
                } else {
                    if (focusedViewWhenLeavingLogin == 1) {
                        idField.setCursorVisible(true);
                        passField.setCursorVisible(true);
                        // Set focus on uid
                        idField.requestFocus();
                        idField.setSelection(idField.getText().length());
                        objApplication.resetFocusedView();
                    } else if (focusedViewWhenLeavingLogin == 2) {
                        idField.setCursorVisible(true);
                        passField.setCursorVisible(true);
                        passField.requestFocus();
                        passField.setSelection(passField.getText().length());
                        objApplication.resetFocusedView();
                    }
                }
            }

            if ((!DiscoverApplication.isInQuickViewMode) && !isApplyNowContentShowing && (idField.hasFocus() || passField.hasFocus())) {
                showKeyboard();
            }
            // modified the code for showing up key pad while pass  code enabled at Bank side.
/*
            if ((!DiscoverApplication.isInQuickViewMode) && (isCardPasscodeLogin() || isBankPasscodeLogin() ))
            {
                fieldTVs[0].requestFocus();
                showKeyboard();
            }
*/

        }


        // updated for threat metrix- rsharm9
        ThreatMatrixSingleton.Instance().doProfile();
        FacadeFactory.getBankLoginFacade().setTMXSessionId(ThreatMatrixSingleton.Instance().getSessionID());
        // ThreatMatrixSingleton.Instance().doProfile();

        if (saveUserId)
            rememberLayout.setContentDescription(getString(R.string.tb_login_remember_checkbox_checked));
        else
            rememberLayout.setContentDescription(getString(R.string.tb_login_remember_checkbox_unchecked));

        if (loginSubOptions != null) {
            loginSubDrawingYPosition = loginSubOptions.getTop();
            loginSubHeight = loginSubOptions.getHeight();
        }

        setKeyboardInput();
        //hideToggleCLA();//us20958 - nkaza

        //Added bank team to only to see push key for 6.8 release. start
        //TODO: Need to ensure we are commenting this before release.
//		if(XtifySDK.getXidKey(this.getApplicationContext()) != null){
//			Toast toast = Toast.makeText(this,"Push key is "+ XtifySDK.getXidKey(this.getApplicationContext()) , Toast.LENGTH_LONG);
//			            toast.show();
//		}
        //Added bank team to only to see push key for 6.8 release. end
        //7.0 Unified session.

        //Clearing unified flags and token. Scenario: From OOB/ Step 2 screens, user can click on back button. Later again service calls should not use Authorization bearer.
        if (!Globals.isBankLoginSelected()) {
            PortalUtils.resetUnifiedFlags();
        }

        //asaraf2 change US50831
        if (PortalUtils.isJointCardErrorModelShow) {
            PortalUtils.showJointCardAccountModal(LoginActivity.this);
        }

        // code uncommented due to wrongly commented out earlier
        if (!Globals.isBankLoginSelected()) {
            TrackingHelper.trackPageView(AnalyticsPage.STARTING);
        } else {
            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.STARTING);
        }

        /*Set Permissions as Intact. Flag value to be used to find if app terminates abruptly because
        * of changing permissions manually*/
        Globals.setIsPermissionsIntact();

        // Regression defect fix - #4522
        if (vPasscode.getVisibility() == View.VISIBLE && !DiscoverApplication.isInQuickViewMode) {
            fieldTVs[0].requestFocus();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(getWindow().getCurrentFocus(), 0);
                }
            }, 300);
        }

        //register the network change action receiver VOC-53603
        if (networkChangeListenerIntent == null) {
            registerReceiver(networkChangeReceiver, new IntentFilter(Constants.ACTION_NETWORK_CHANGE));
        }
    }

    /**
     * Method to check if fingerprint sensor available on device or not
     * Added for US71513 - fingerprint login modal
     */
    private void checkFingerprintAndInvokeModal() {

        /**start Added for US71513 - fingerprint login modal; US83286  - Android Fingerprint - Kill-switch */
        if (null == fingerPrintUtils)
            fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
        if (fingerPrintUtils.isFPPreloginKillSwitchEnabled()) {
            // Don't show FP dialog
            if (null != fingerPrintDialog && fingerPrintDialog.isAdded()) {
                fingerPrintDialog.dismiss();
            }
            return;
        }
        /**end Added for US71513 - fingerprint login modal; US83286  - Android Fingerprint - Kill-switch */

        // check for FP Hardware
        if (!FingerPrintUtils.isFingerprintHardwareAvailable(this)) {
            //Toast.makeText(this,"Fingerprint feature is not available on this device",Toast.LENGTH_LONG).show();
            return;
        }

        // check for FP is registered on device
        if (!FingerPrintUtils.isFingerprintRegistered(this)) {
           // Toast.makeText(this,"Go to 'Settings -> Security -> Fingerprint' and register at least one fingerprint",Toast.LENGTH_LONG).show();
            return;
        }

        // check for FP option is enabled on Discover app level
        if (null == fingerPrintUtils)
            fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
        if (fingerPrintUtils.getFingerPrintStatus())
            showFingerprintDialog();
        else
            return;
    }


    /**
     * Fingerprint shake modal, modal that takes user to fingerprint setup screen via deeplink
     * added for US71608
     */
    public void showFingerprintShakeModal() {
        //Start: US72282: FingerPrint Analytics
        if(Globals.isBankLoginSelected)
            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_OVERLAY_PG);
        else
        //End: US72282: FingerPrint Analytics
        /**Start Changes for US71879: Fingerpeint Site Catalyst Tags*/
        TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_OVERLAY_PG);
        /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/

        final DiscoverAlertDialog fingerprintShakeDialog = new DiscoverAlertDialog();
        fingerprintShakeDialog.setTitle(getString(R.string.title_fp_shake_dialog)).
                setPositiveButton(getString(R.string.txt_fp_shake_dialog_positive), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Start: US72282: FingerPrint Analytics
                        if(Globals.isBankLoginSelected) {
                            HashMap<String, Object> extras= FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                            extras.put(AnalyticsPage.PROP1,AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_ENABLE_BTN);
                            TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_ENABLE_BTN ,null, AnalyticsPage.LINK_TYPE_O,extras);
                        }
                        else {
                        //End: US72282: FingerPrint Analytics
                            /**Start Changes for US71879: Fingerpeint Site Catalyst Tags*/

                            HashMap<String, Object> extras = new HashMap<String, Object>();
                            extras.put(LoginActivity.this.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_ENABLE_BTN);
                            TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_ENABLE_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
                        }
                        Toast fpEnableToast = Toast.makeText(LoginActivity.this, getString(R.string.msg_fp_shake_dialog_enable), Toast.LENGTH_SHORT);
                        fpEnableToast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                        fpEnableToast.show();
                        //Start: US72282: FingerPrint Analytics
                        if(Globals.isBankLoginSelected)
                            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_TOAST_MESSAGE_OVERLAY);
                        else
                        //End: US72282: FingerPrint Analytics
                        TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_TOAST_MESSAGE_OVERLAY);
                        /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/

                        //US78893-FingerPrint Login - Shrink Modal enable button handling-Start
                        if(Globals.isBankLoginSelected())
                        {
                            FacadeFactory.getBankLoginFacade().setDeeplinkValue(getContext().getString(R.string.deeplink_value_touchid));
                        }
                        //US78893-FingerPrint Login - Shrink Modal enable button handling-End
                        else
                            // Set a Fingerprint setup deep-link code here
                          FacadeFactory.getCardFacade().setFingerprintSetupDeeplink(LoginActivity.this);

                    }
                }).setNegativeButton(getString(R.string.txt_fp_shake_dialog_negative), new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Start: US72282: FingerPrint Analytics
                if(Globals.isBankLoginSelected) {
                    HashMap<String, Object> extras= FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                    extras.put(AnalyticsPage.PROP1,AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_DONT_ENABLE_LNK);
                    TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_DONT_ENABLE_LNK ,null, AnalyticsPage.LINK_TYPE_O,extras);
                }
                else {
                    //End: US72282: FingerPrint Analytics
                    /**Start Changes for US71879: Fingerpeint Site Catalyst Tags*/
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(LoginActivity.this.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_DONT_ENABLE_LNK);
                    TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_QUICKER_LOGIN_MODAL_DONT_ENABLE_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                    /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/
                }
                fingerprintShakeDialog.dismiss();
            }
        }).setCanCancelable(true).setCanceledOnTouchOutside(false).setCustomContentView(R.layout.fingerprint_shake_modal_content).
                show((AppCompatActivity) getContext());

    }

    /**
     * This method takes care of the deeplinking from pre loginfor WDa and links from
     * Emails(rdLinks).
     */
    private void handleDeeplinking() {
        String rdKey = null;
        // stores wda deeplink to shared prefs
        Intent deepLinkIntent =  getIntent();
        if(deepLinkIntent == null) {
            //Since Intent itself empty just return from here.
            //In real world this(null Intent) won't be happened.
            return;
        }
        Uri deepLinkUri = deepLinkIntent.getData();
        String actionSendExtra = deepLinkIntent.getStringExtra(Intent.EXTRA_TEXT);

        if (null != deepLinkUri
                && null != deepLinkUri.getQueryParameter("deeplink")) {

            /*US102568 - Fraud Scenarios: Disable deeplink for bank accounts - Start*/
            //Get deeplink key word from URL
            String deeplinkKey = deepLinkUri.getQueryParameter("deeplink");
            String deepLURL = String.valueOf(deepLinkUri);
            if(deepLURL.contains("bank-")){
                /*select toggle in bank side*/
                checkBankToggle();
            }

            if(Globals.isBankLoginSelected())
            {
                //Set deeplink in bank side
                FacadeFactory.getBankLoginFacade().setDeeplinkValue(deeplinkKey);
            }
            /*US102568 - Fraud Scenarios: Disable deeplink for bank accounts - End*/

            if (FacadeFactory.getWDAFacade().isSupportedDeeplink(deeplinkKey)) {
                FacadeFactory.getWDAFacade().getWdaActionCode(this, deepLinkUri);
            }
        } else if (null != deepLinkUri && (rdKey = Uri.parse(deepLinkUri.toString().replace("#", "").toString())
                .getQueryParameter("rdlink")) != null) {
            //US51952
            //Handle the Deeplink with rdlink param value here
            String deeplink = null;
            if (rdKey != null && (deeplink = FacadeFactory.getCardFacade().isSupportedRdLink(rdKey)) != null) {
                //save the deeplink and on post login route using this link
                FacadeFactory.getCardFacade().setRdDeeplink(deeplink, LoginActivity.this);
            }
        }else if(actionSendExtra != null){
                FacadeFactory.getCardFacade().setDeeplink(actionSendExtra, LoginActivity.this);
            }
    }

    /**
     * Ran at the start of an activity when an activity is brought to the front.
     * This also will trigger the Xtify SDK to start. Check to see if the user
     * just logged out, if the user just logged out show the message.
     */
    @Override
    public void onStart() {
        super.onStart();
        // commented the below line for code optimization no use
        // applicationWillEnterForeground();
        PushServiceHelper.startXtifySDK(this);
        // Quick View Redesign- comment
        // if (!Globals.ISINFASTCHECK)
        // getSlidingMenu().showContent();
    }

    private void startPreAuth() {
        startPreAuthCheck();
        FacadeFactory.getBankLoginFacade().startBankApiServiceCall();
    }

    @Override
    public void onRestoreInstanceState(final Bundle bundle) {
        isActivitysOnSaveInstanceStateCalled = false;
        isRestoreInstance = true;
        super.onRestoreInstanceState(bundle);
        restoreState(bundle);
        isRestoreInstance = false;
    }


    /*Overriding to fix the model dismiss issue when orientation changes.*/
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    /**
     * Place all necessary information to be restored in a bundle. This info is
     * used when the screen orientation changes.
     */
    @SuppressLint("NewApi")
    @Override
    public void onSaveInstanceState(final Bundle outState) {

        isActivitysOnSaveInstanceStateCalled = true;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1)
            activityRootView.getViewTreeObserver().removeOnGlobalLayoutListener(
                    layoutListener);
        else
            activityRootView.getViewTreeObserver().removeGlobalOnLayoutListener(
                    layoutListener);

        outState.putString(ID_KEY, idField.getText().toString());
        outState.putString(PASS_KEY, passField.getText().toString());
        outState.putBoolean(SAVE_ID_KEY, saveUserId);
        outState.putInt(TOGGLE_KEY, Globals.getCurrentAccount().ordinal());
        outState.putBoolean(BANK_IS_USER_ID_LOGIN, isBankUserIDLogin);
        outState.putBoolean(IS_USER_ID_LOGIN, isUserIDLogin);
        outState.putString(PASSCODE, getPasscodeString());
        outState.putBoolean(ID_FIELD_FOCUS, idField.hasFocus());
        outState.putBoolean(PWD_FIELD_FOCUS, passField.hasFocus());
        outState.putBoolean(IS_ERROR_LINE_DISPLAYED, isErrorLineDisplayed);


        //Quick View visibility state maintenance
        outState.putBoolean("doMaintainQVState", true);
        // commented super call to fix Crashlytics defect -1565
//        super.onSaveInstanceState(outState);
    }

    /**
     * Restore the state of the screen on orientation change.
     *
     * @param savedInstanceState A bundle of state information to be restored to the screen.
     */
    public void restoreState(final Bundle savedInstanceState) {
        if (savedInstanceState != null) {


            enteredUserName = savedInstanceState.getString(ID_KEY);
            enteredPassword = savedInstanceState.getString(PASS_KEY);
            passcode = savedInstanceState.getString(PASSCODE);
            saveUserId = savedInstanceState.getBoolean(SAVE_ID_KEY);
            Globals.setRememberId(saveUserId);

            if (saveUserId) {
                //rememberChkbox.setText(R.string.fa_checkbox);
                rememberTick.setVisibility(View.VISIBLE);
            }

            isUserNameHasFocus = savedInstanceState.getBoolean(ID_FIELD_FOCUS);
            isPasswordHasFocus = savedInstanceState.getBoolean(PWD_FIELD_FOCUS);
            showErrorLine = savedInstanceState.getBoolean(IS_ERROR_LINE_DISPLAYED);

            isUserIDLogin = savedInstanceState.getBoolean(IS_USER_ID_LOGIN);
            isBankUserIDLogin = savedInstanceState
                    .getBoolean(BANK_IS_USER_ID_LOGIN);
            if (pUtils == null) {
                pUtils = new PasscodeUtils(this.getApplicationContext(), true);
            }
            pUtils.setForgotPasscode(savedInstanceState
                    .getBoolean(IS_FORGOT_PASSCODE));

            if (bankpasscodeUtils == null) {
                bankpasscodeUtils = new PasscodeUtils(
                        this.getApplicationContext(), false);
            }
            bankpasscodeUtils.setForgotPasscode(savedInstanceState
                    .getBoolean(BANK_IS_FORGOT_PASSCODE));
            restoreToggle = savedInstanceState.getInt(TOGGLE_KEY,
                    NO_TOGGLE_TO_RESTORE);
        }
    }

    /**
     * Load user credentials from shared preferences. Set user ID field to the
     * saved value, if it was supposed to be saved.
     */
    private void loadSavedCredentials() {
        boolean rememberIdCheckState;

        saveUserId = rememberIdCheckState = Globals.isRememberId();

        final String savedId = Globals.getCurrentUser();

        //TODO Commented as part of log in migration as it is not used.
        //final boolean isCardSelected = checkMarkCard.getVisibility() == View.VISIBLE;

        final boolean isStoredAccountTypeSameAsSelected = ((isCardChecked && Globals
                .getCurrentAccount() == AccountType.CARD_ACCOUNT) || (!isCardChecked && Globals
                .getCurrentAccount() == AccountType.BANK_ACCOUNT));
        if (rememberIdCheckState && isStoredAccountTypeSameAsSelected
                && savedId.length() > 0) {
            idField.setText(savedId);
            // rememberChkbox.setText(R.string.fa_checkbox);
            rememberTick.setVisibility(View.VISIBLE);
            //passField.requestFocus();
            //passField.setSelection(passField.getText().length());
            if (isUserNameHasFocus) {
                idField.requestFocus();
                idField.setSelection(idField.getText().length());
            } else if (isPasswordHasFocus) {
                passField.requestFocus();
                passField.setSelection(passField.getText().length());
            } else {
                passField.requestFocus();
                passField.setSelection(passField.getText().length());
            }
        } else {
            // Remember selection and focus for UID view
            EditText focusedView = null;
            //TODO Commented as part of log in migration as it is not used.
            //int cursorAt = 0;

            // Set values from locals
            idField.setText(enteredUserName);
            passField.setText(enteredPassword);

            if (isUserNameHasFocus)
                idField.requestFocus();

            if (isPasswordHasFocus)
                passField.requestFocus();

            if (idField.hasFocus()) {
                focusedView = idField;
                //TODO Commented as part of log in migration as it is not used.
                //cursorAt = idField.getSelectionStart();
            } else if (passField.hasFocus()) {
                focusedView = passField;
                //TODO Commented as part of log in migration as it is not used.
                //cursorAt = passField.getSelectionStart();
            }

            // Set appropriate cursor position
            if (focusedView != null) {
                focusedView.requestFocus();
                // focusedView.setSelection(cursorAt);
                focusedView.setSelection(focusedView.getText().length());
            } else {
                // In case if user-id or password has not focus. This will not
                // happen here, but handled in case of default
                idField.requestFocus();
                idField.setSelection(idField.getText().length());
            }
        }

        //TODO commented as part of login till here Hari

        /*if (idField.getText().length() == 0) {
            if ((!idField.hasFocus()) && (!passField.hasFocus())) {
                // Request focus only if user-id or password has not focus
                idField.requestFocus();
            }
			*//*
			 * rememberLayout.startAnimation(remmemberBtnFadeOut);
			 * rememberChkbox.setText(R.string.fa_uncheck_);
			 *//*
        } else {
            idField.setSelection(idField.getText().toString().length());
            // passField.setSelection(passField.getText().toString().length());
			*//*
			 * if (!(isCardLogin() && isCardPasscodeLogin()) || (!isCardLogin() &&
			 * isBankPasscodeLogin())) { passField.requestFocus(); }
			 *//*
            // rememberLayout.startAnimation(remmeberBtnFadeIn);
        }*/

        //TODO commented above as part of login
    }

    /*
	 * This function goes through the login process. This function is called by
	 * the Login Button onClick listeners and the OnEditorActionListener of the
	 * password edit text field
	 */
    private void executeLogin(final View v) {

        try {
            final String encryptedUsername = SecurityUtil.encrypt(idField
                    .getText().toString());
            DiscoverApplication.getLocationPreference().setMostRecentUser(
                    encryptedUsername);
        } catch (final Exception e) {
            Log.e(TAG, "Unable to cache last attempted login");
        }

        final InputMethodManager mngr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mngr.hideSoftInputFromWindow(v.getWindowToken(),
                InputMethodManager.HIDE_IMPLICIT_ONLY);
        // Clear the last error that occurred

        //TODO need to remove below statement. - Hari
        setLastError(0);
        //fix for defect #203165 - START
        Globals.setCurrentUser(idField.getText().toString());
        //fix for defect #203165 - END
        login();
    }

    /**
     * setupButtons() Attach onClickListeners to buttons. These buttons will
     * execute the specified functionality in onClick when they are clicked...
     */
    private void setupButtons() {
        /**
         * This method is put in place of the last toggle's on click method.
         * Calls the toggleSaveUserIdSwitch the same way the previous
         * implementation had.
         */
		/*
		 * To check whether the remember check box is checked or not and save
		 * the data in shared preference accordingly
		 */
        rememberLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
				/*if (rememberChkbox.getText().toString()
						.equals(getString((R.string.fa_checkbox))))*/
                if (rememberTick.getVisibility() == View.VISIBLE) {
                    //rememberChkbox.setText(R.string.fa_uncheck_);
                    rememberTick.setVisibility(View.INVISIBLE);
                    rememberLayout.setContentDescription(getString(R.string.tb_login_remember_checkbox_unchecked));
                } else {
                    //rememberChkbox.setText(R.string.fa_checkbox);
                    rememberTick.setVisibility(View.VISIBLE);
                    rememberLayout.setContentDescription(getString(R.string.tb_login_remember_checkbox_checked));
                }
                rememberLayout.sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED);
                toggleSaveUserIdSwitch(v, true);

            }
        });

        idField.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!isPasscodeLogin && isErrorLineDisplayed) {
                    loadSavedCredentials();
                }
                hideError();
                return false;
            }
        });

        idField.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //Added for username fiedl talkback if account numbers / user name available
                if (!TextUtils.isEmpty(idField.getText())) {
                    idField.setContentDescription(Utils.splitIntoCharwithSpace(idField.getText().toString()));
                    idField.sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED);
                }
            }
        });

        idField.setOnFocusChangeListener(new OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    // /getKeyboardEvents();

                    // if (idField.getTag() == null)
                    {

                        // showError();

                        resetHorizontalLinePlace(true);
                    }
                    // else
                    {
                        idField.setTag(null);
                    }

                    // resetHorizontalLinePlace(true);
                }
            }
        });

        passField.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!isPasscodeLogin && isErrorLineDisplayed) {
                    loadSavedCredentials();
                }
                hideError();
                return false;
            }
        });
        passField.setOnFocusChangeListener(new OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    // getKeyboardEvents();
                    // if (idField.getTag() == null)
                    {
                        // showError();
                        // hideError();
                        resetHorizontalLinePlace(false);
                    }
                    // else
                    {
                        idField.setTag(null);
                    }
                }
            }
        });

        idField.addTextChangedListener(new TextWatcher() {
            // Logic to mask input and go to next item
            @Override
            public void afterTextChanged(final Editable paramAnonymousEditable) {
                hideError();
                showLoginOption();
            }

            @Override
            public void beforeTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }

            @Override
            public void onTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }
        });

        passField.addTextChangedListener(new TextWatcher() {
            // Logic to mask input and go to next item
            @Override
            public void afterTextChanged(final Editable paramAnonymousEditable) {
                if (idField.getTag() != null) {
                    idField.setTag(null);
                }

                hideError();
                showLoginOption();
            }

            @Override
            public void beforeTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }

            @Override
            public void onTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }
        });

        // dismiss keyboard when touch outside
        loginRootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyboard();
                return false;
            }
        });
        relativeLayoutToggle.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyboard();
                //QV Univ Migration -Start
                if (!Utils.isRunningOnHandset(LoginActivity.this)) {
                    keyBoardStateVisible = false;
                }
                //QV Univ Migration -End
                //objApplication.setLoginKeyBoardStateVisible(false);
                return false;
            }
        });
    }

    /**
     * Method used to determine whether the user is in the Card Login Page or
     * Bank Login Page.
     *
     * @return True if in the Card login page, false otherwise.
     */
    public boolean isCardLogin() {
        if (checkMarkCard != null)
            return View.VISIBLE == checkMarkCard.getVisibility();
        else
            return true;
    }

    /**
     * If the user id, or password field are effectively blank, do not allow a
     * service call to be made display the error message for id/pass not
     * matching records. If the fields have data - submit it to the server for
     * validation.
     */
    private void login() {
        idField.setContentDescription("\u00A0");
        passField.setContentDescription("\u00A0");
        Globals.setUserName(idField.getText().toString());
        Globals.setPassword(passField.getText().toString());
        //reset the sso flag - Fix for 233571:OOB screen crash issue
        Globals.setSSOUser(false);
        // Globals.isBankLogin(true);
        FacadeFactory.getBankLoginFacade().initialLoginTime();

        // Close Soft Input Keyboard
        final InputMethodManager inputManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        inputManager
                .hideSoftInputFromInputMethod(passField.getWindowToken(), 0);

        Globals.setOldTouchTimeInMillis(0);
        idField.clearFocus();
        passField.clearFocus();
        if (!showErrorWhenAttemptingToSaveAccountNumber()) {
            runAuthWithUsernameAndPassword(idField.getText().toString(),
                    passField.getText().toString());
        }
    }
    //Change end

    /**
     * If a user tries to save their login ID but provides an account number, we
     * need to show an error clear the input fields and un-check the
     * save-user-id box.
     *
     * @return a boolean that represents if an error was displayed or not.
     */
    private boolean showErrorWhenAttemptingToSaveAccountNumber() {
        final String inputId = idField.getText().toString();

        if (saveUserId && InputValidator.isCardAccountNumberValid(inputId)) {
            mLoginButton.setVisibility(View.INVISIBLE);
            showError();
            showLongToast(getString(R.string.cannot_save_account_number));
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method submits the users information to the Card or Bank server for
     * verification depending on what is selected in login page.
     *
     * The AsyncCallback handles the success and failure of the call and is
     * responsible for handling and presenting error messages to the user.
     */
    private void runAuthWithUsernameAndPassword(final String username,
                                                final String password) {
        // Prevent data from restoring after a crash.
        passField.getText().clear();
        clearPasscodeFields();
        this.username = idField.getText().toString();

        Log.i("PasscodeUserID", "PasscodeUserID **" + pUtils.getPasscodeUserID());

        //Fix 213029: Or condition added for bank side passcode deeplink issue
        if (username.equals(pUtils.getPasscodeUserID()) || username.equals(bankpasscodeUtils.getPasscodeUserID())) {
            if (forgotPasscodeSelected) {
                if (isCardLogin()) {
                    pUtils.setForgotPasscode(true);
                } else {
                    bankpasscodeUtils.setForgotPasscode(true);
                }
            }
        }

        /*	Backlog defect 212868 fix Start */
        idField.getText().clear();
		/*	Backlog defect 212868 fix End */
        passField.clearFocus();
        idField.clearFocus();

        // Check if card account has been selected
        if (View.VISIBLE == checkMarkCard.getVisibility()) {
            cardLogin(username, password);
        } else {
            // disable all input fields so that user cannot
            // navigate to another screen once login
            // process has started
            //disableInput();
            // bankLogin(username, password);
            hideKeyboard();
            Globals.setForgotPasswordFlow(false);
            FacadeFactory.getBankLoginFacade().bankLogin(username, password,
                    isBankPasscodeLogin());

        }
    }

    /**
     * This method submits the users information to the Card server for
     * verification.
     *
     * The AsyncCallback handles the success and failure of the call and is
     * responsible for handling and presenting error messages to the user.
     */
    private void cardLogin(final String username, final String password) {
        final boolean is16DigitLogin = InputValidator.isCardAccountNumberValid(username);
        FacadeFactory.getPortalPageFacade().set16DigitLogin(is16DigitLogin);
        //Fixed as part of profile and settings status update regression defect - #209835
        FacadeFactory.getCardLoginFacade().saveUserIdForLocationSettings(username);
        NetworkRequestListener nrl = new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {

                //changed sequence for US38219 CLA merge intercept page
                final AccountV2Details portalAccountDetails = PortalCacheDataUtils
                        .getPortalCacheDataUtilsInstance()
                        .getAccountV2Details();
                if (is16DigitLogin) {
                    if (portalAccountDetails.isUserIdAvailable()) {

                        idField.getText().clear();
                        showError();
                        showLongToast(getResources().getString(R.string.invalid_user_id));

                    } else {
                        FacadeFactory.getCardFacade().navToCreateUserID(LoginActivity.this);
                        PortalUtils.hideSpinner(LoginActivity.this);
                    }
                }
                /** start Added for US38219 CLA merge intercept page */
                else if (portalAccountDetails.isMergeEligible() && !PortalUtils.isDeepLink() && !PortalUtils.isPushDeepLink(LoginActivity.this)) {

                    // US126324 Changes - start
                    PortalUtils.navToPortalMergeInterceptPage(portalAccountDetails.getCustomerFirstName(), portalAccountDetails.isForceMerge(),
                            portalAccountDetails.isInitialSkipAttempt());
                    // US126324 Changes - end
                    /** end Added for US38219 CLA merge intercept page */
                } else {
                    if (PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getIfPortalPageShown()) {
                        //Deep link for a single card and sso user. - US28600
                        SharedPreferences pushSharedPrefs = LoginActivity.this.getSharedPreferences("PUSH_PREF", Context.MODE_PRIVATE);
                        boolean isPushDeepLink = pushSharedPrefs.getBoolean("pushOffline", false);

                        if (Globals.isSSOUser && portalAccountDetails.getCardAccountsMap().size() == 1 && (FacadeFactory.getWDAFacade().isDeepLink(DiscoverActivityManager.getActiveActivity(), null) || isPushDeepLink)) {
                            String key = (String) portalAccountDetails.getCardAccountsMap().keySet().toArray()[0];
                            // Update account detail changes
                            PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setSelectedAccKey(key);
                            FacadeFactory.getPortalPageFacade().navToCardHome(getContext(), key);

                            if (isPushDeepLink) {
                                Editor editor = pushSharedPrefs.edit();
                                editor.putBoolean("pushOffline", false);
                                editor.commit();
                            }

                        }
// else-if block added for the scenario when the user is sso with 1 card account and passcode setup deeplink has been set at log-in scfreen- vpant -start
                        else if (Globals.isSSOUser && portalAccountDetails.getCardAccountsMap().size() == 1 && pUtils.isPasscodeSetupDeepLink()) {
                            String key = (String) portalAccountDetails.getCardAccountsMap().keySet().toArray()[0];
                            // Update account detail changes
                            PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setSelectedAccKey(key);
                            FacadeFactory.getPortalPageFacade().navToCardHome(getContext(), key);
                        }
                        // else-if block added for the scenario when the user is sso with 1 card account and passcode setup deeplink has been set at log-in scfreen- vpant -end

                        else {
                            // US45209 Changes Starts
                            if (HFUtils.shouldShowSSOWhatsNew(LoginActivity.this)) {
                                HFUtils.showSSOWhatsNew(LoginActivity.this);
                            } else {
                                PortalUtils.navToPortalActivity();
                            }
                            // US45209 Changes ends
                        }
                    } else {
                        // changed for onboarding flow - skrish1
                        FacadeFactory.getCardFacade().shouldShowWizard(getContext());
                    }

                }

            }

            @Override
            protected Object clone() throws CloneNotSupportedException {
                return super.clone();
            }

            @Override
            public void onError(Object data) {
                hideKeyboard();
                FacadeFactory.getPortalPageFacade().handleErrorScenario(
                        LoginActivity.this.getContext(), data);
            }
        };

        SessionCookieManager coockieManager = SessionCookieManager.getInstance();
        cookieManagerProxy = (CookieManagerProxy) coockieManager.getCookieManager();
        cookieManagerProxy.clearAllCookies();

        PortalUtils.getPortalAccountDetails(this, username, password, nrl,
                false);
    }

    /**
     * toggleSaveUserIdSwitch - This method handles the state of the save useris
     * id switch on the login screen.
     *
     * It changes the state of the saveUserId value.
     *
     * @param cache Specifies whether to remember the state change
     */
    public void toggleSaveUserIdSwitch(final View view, final boolean cache) {
//        if (View.VISIBLE == checkMarkBank.getVisibility()) {
			/*if (rememberChkbox.getText().toString()
					.equals(getString((R.string.fa_checkbox))))*/
        if (rememberTick.getVisibility() == View.VISIBLE) {
            // START: US13784
            if (!isCardLogin())
                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        R.string.Login_Rememberon);
            else {

                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put("my.prop1",
                        AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_YES_prop1);
                extras.put("pe", AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_YES_pe);
                extras.put("pev1",
                        AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_YES_pev1);
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_YES_prop1,
                        AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_YES_pev1,
                        extras);
            }
        } else {
            if (!isCardLogin())
                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        R.string.login_rememberoff);
            else {

                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put("my.prop1",
                        AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_NO_prop1);
                extras.put("pe", AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_NO_pe);
                extras.put("pev1",
                        AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_NO_pev1);
                TrackingHelper
                        .trackCardPageProp1(
                                AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_NO_prop1,
                                AnalyticsPage.LOGIN_BTN_REMEMBER_USERID_NO_pev1,
                                extras);
            }
        }
//        }
		/*if (rememberChkbox.getText().toString()
				.equals(getString((R.string.fa_checkbox))))*/
        if (rememberTick.getVisibility() == View.VISIBLE) {
            saveUserId = true;
        } else {
            saveUserId = false;
        }

        // Check whether to save change in persistent storage
        if (cache) {
            Globals.setRememberId(saveUserId);
        }
    }

    //Commented the below code as part of log in migration. we are not using sliding menu in current log in screen.
    //Change start
    @Override
    public void hideFastcheck() {

		/*gotoFastcheckButton.setVisibility(View.VISIBLE);
		getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
		alignLogoLeft(false);*/
    }

    private void deleteAndSaveCurrentUserPrefs() {
        Globals.setRememberId(false);
        Globals.setCurrentUser(StringUtility.EMPTY);
        Globals.savePreferences(this);
    }

    /**
     * clearInputs() Removes any text in the login input fields.
     */
    private void clearInputs() {
        idField.getText().clear();
        clearPasscodeFields();
        passField.getText().clear();
        mLoginButton.setVisibility(View.GONE);
        rememberLayout.setVisibility(View.GONE);
    }

    /**
     * Opens ATM Locator screen when user taps the ATM Locator button while in
     * the BANK Login Screen
     */
    public void openAtmLocator() {

        if (isGoogleMapsInstalled()) {
            if (!isCardChecked)

                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        R.string.bank_analytics_atm_start);
            FacadeFactory.getBankLoginFacade().navigateToNativeATM();
        } else {
            if (!isCardChecked)

                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        R.string.bank_analytics_atm_start);
            FacadeFactory.getBankLoginFacade().navigateToHybridATM();
        }
    }

    /**
     * Run the pre-auth call. Check with the server if the version of the
     * application we are running is OK. Also checks to see if the server is
     * available and will allow users to login. Downloads error message file
     */
    public void startPreAuthCheck() {

        NetworkRequestListener preAuthListner = new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                PreAuthbean preAuthbean = (PreAuthbean) data;
                /**
                 * This will add the dynamic properties to the Utils
                 */
                com.discover.mobile.common.shared.utils.image.Utils.setDynamicProperties(preAuthbean);
                Map<String, Object> properties = preAuthbean.getDynamicPropertiesMap();
                if (properties != null) {
                    Iterator<Map.Entry<String, Object>> iterator = properties.entrySet().iterator();

                    while (iterator.hasNext()) {
                        Map.Entry<String, Object> entry = iterator.next();
                        Log.d(TAG, "Key: " + entry.getKey() + "     Value: " + entry.getValue());
                    }

                    if (!properties.isEmpty() && properties.containsKey(ANIMATION_DELAY_PROPERTY)) {
                        com.discover.mobile.common.Utils.saveToPreference(LoginActivity.this, ANIMATION_PROPERTY_KEY, Long.valueOf(preAuthbean.getDynamicProperties(ANIMATION_DELAY_PROPERTY).toString()), com.discover.mobile.common.Utils.Type.LONG, "");
                    }
                }

                //handle the kill switch
                handlePreLoginKillSwitch(preAuthbean);
                handleGeoFenceKillSwitch(preAuthbean);
                handleApplyNowBannerKillSwitch(preAuthbean);
                String description = preAuthbean.getVersionInfo();

                if (!TextUtils.isEmpty(description)) {
                    if (PreAuthCallHelper.shouldPresentOptionalUpdate((LoginActivity.this),
                            description)) {
                        //TODO need to check if we need to read package name from system rather then hardcoding.
                        TrackingHelper.trackPageView(AnalyticsPage.OPTIONAL_UPGRADE);
                        FacadeFactory.getBankLoginFacade().showOptionalUpgradeAlertDialog((LoginActivity.this), description);
                    }
                }

                // clear update prefrence data if available - VOC-53603
                Utils.clearAllPrefrence(LoginActivity.this, Constants.FORCE_UPGRADE_SHARED_PREF);

                // Notify login activity that Pre-Auth call has completed
                preAuthComplete(true);
                if(Globals.isShaketoBugEnabled){
                    String customPermissionMessage = InfoMessageUtils.Instance().getErrorMessage(PermissionConstant.SHAKE_TOBUG_SAVE_PERMISSION);
                    ((DiscoverBaseActivity) DiscoverActivityManager.getActiveActivity()).checkPermission(PermissionConstant.Permissions.EXTERNAL_STORAGE, customPermissionMessage, new PermissionListener() {
                        @Override
                        public void onPermissionGranted(PermissionConstant.Permissions permission) {
                        }
                        @Override
                        public void onPermissionDenied(PermissionConstant.Permissions permission) {
                        }
                    });
                }
                /*As part of Samsung Pay SDK Calls optimization , we have moved all the SDK calls
                to pre-login and after preAuth.*/
                //initiate Wallet Eligibility Call in Background
               initWalletEligibility();
                showApplyNowBanner();
            }

            @Override
            public void onError(Object data) {

                //initiate Wallet Eligibility Call in Background
                initWalletEligibility();

                // Due to casting exception, converting ErrorBean to ErrorResponseDetails instead of PreAuthErrorBean
                ErrorBean errorbean = (ErrorBean) data;
                PreAuthErrorResponseDetails preAuthErrorBean = (PreAuthErrorResponseDetails) ((ErrorBean) data)
                        .getErrorResponseHolder();

                // ErrorResponseDetails preAuthErrorBean = (ErrorResponseDetails) ((ErrorBean) errorbean).getErrorResponseHolder();
//              Data preAuthErrorData = preAuthErrorBean.getPreAuthErrorData();
//                PreAuthErrorResponseDetails preAuthErrorDetails = (PreAuthErrorResponseDetails)preAuthErrorBean;

                List<PreAuthData> errorData = null;
                if (null != preAuthErrorBean) {
                    errorData = (ArrayList) (preAuthErrorBean.getData());
                }
                String status = null;
                String message = null;
                String redirectUrl = null;
                String redirectTitle = null;
                String header = null;


                if (null == preAuthErrorBean) {
                    status = errorbean.getHttpStatus();
                    if (null != status) {
                        //backlog defect Fix 222481 start adeshm2
                        final boolean isUnknownHostExceptionAppeared = status.equalsIgnoreCase(ErrorConstants.ErrorCodes.UNKNOWNHOSTEXCEPTION);
                        if (isUnknownHostExceptionAppeared) {
                            FacadeFactory.getPortalPageFacade().handleErrorScenario(LoginActivity.this, data);
                            return;
                        }
                        //backlog defect Fix 222481 end adeshm2
                    }
                } else {
                    //Data preAuthErrorData = preAuthErrorBean.getPreAuthErrorData();
                    for (int i = 0; i < errorData.size(); i++) {
                        if (null != errorData.get(i).getRedirectURl()) {
                            redirectUrl = errorData.get(i).getRedirectURl();
                        }
                    }
                    for (int i = 0; i < errorData.size(); i++) {
                        if (null != errorData.get(i).getRedirectTitle()) {
                            redirectTitle = errorData.get(i).getRedirectTitle();
                        }
                    }

                    for (int i = 0; i < errorData.size(); i++) {
                        if (null != errorData.get(i).getHeader()) {
                            header = errorData.get(i).getHeader();
                        }
                    }
                    status = preAuthErrorBean.status;
                    message = preAuthErrorBean.message;
                }

                // below code is written to get Data hash map from response

//                    Map<String, Object> properties = preAuthErrorData.data;
//                    Iterator<Map.Entry<String, Object>> iterator = properties.entrySet().iterator();
//
//                    while (iterator.hasNext()) {
//                        Map.Entry<String, Object> entry = iterator.next();
//                        Log.d(TAG, "Key: " + entry.getKey() + "     Value: " + entry.getValue());
//                    }

                if (null != status && Integer.parseInt(status) == StandardErrorCodes.FORCED_UPGRADE_REQUIRED) {
                    isForceUpgrade = true;
                    TrackingHelper.trackPageView(AnalyticsPage.FORCED_UPGRADE);
                    //Do not show the finger print dialog when there is a force upgrade enforced.
                    if(fingerPrintDialog!=null) {
                        if(fingerPrintDialog.isVisible())
                             fingerPrintDialog.dismiss();
                    }
                    //START - VOC-53603
                    Utils.saveToPreference(LoginActivity.this, Constants.FORCE_UPGRADE_HEADER, header, Type.STRING, Constants.FORCE_UPGRADE_SHARED_PREF);
                    Utils.saveToPreference(LoginActivity.this, Constants.FORCE_UPGRADE_MESSAGE, message, Type.STRING, Constants.FORCE_UPGRADE_SHARED_PREF);
                    Utils.saveToPreference(LoginActivity.this, Constants.FORCE_UPGRADE_REDIRECT_TITLE, redirectTitle, Type.STRING, Constants.FORCE_UPGRADE_SHARED_PREF);
                    Utils.saveToPreference(LoginActivity.this, Constants.FORCE_UPGRADE_REDIRECT_URL, redirectUrl, Type.STRING, Constants.FORCE_UPGRADE_SHARED_PREF);
                    Utils.saveToPreference(LoginActivity.this, Constants.IS_FORCE_UPGRADE, true, Type.BOOLEAN, Constants.FORCE_UPGRADE_SHARED_PREF);
                    //END - VOC-53603
               //     showForcedUpgradeAlertDialog(LoginActivity.this, header, message, redirectTitle, redirectUrl);
                    PreAuthCallHelper.updateDateInPrefs(getContext());
                    isForceUpgradeAvailable = true;
                }
                //START - VOC-53603
                else {
                    showApplyNowBanner();
                    if(null != errorbean && !TextUtils.isEmpty(errorbean.getHttpStatus())) {
                        final boolean isUnknownHostExceptionAppeared = errorbean.getHttpStatus().equalsIgnoreCase(ErrorConstants.ErrorCodes.UNKNOWNHOSTEXCEPTION);
                        if (!isUnknownHostExceptionAppeared) {
                            Utils.clearAllPrefrence(LoginActivity.this, Constants.FORCE_UPGRADE_SHARED_PREF);
                        }
                    }
                }
                //END - VOC-53603
                preAuthComplete(false);
            }
        };
        LoginServiceClass preAuthCheckService = new LoginServiceClass(getContext());
        preAuthCheckService.startPreAuthCheck(preAuthListner);
        //TODO ned to check what is happening after the JSON is downloaded.
        // backlog US57795 fix start adeshm2
        preAuthCheckService.getRandomizationJson();
        // backlog US57795 fix end adeshm2
        preAuthCheckService.getErrorListJSON();
        NetworkRequestListener infoMessageListener = new NetworkRequestListener() {
            @Override
            public void onSuccess(Object data) {
                /**
                 * We will call clearCacheMemory to clear cache , as clearing deals cache value comes from infomessage.json
                 */
                clearCacheMemory();
                InfoJsonData infoData = (InfoJsonData) data;
                boolean isUniversalCheckEnabled = infoData.getIsUniversalLaunched();
                if (isUniversalCheckEnabled) {


                    ArrayList<String> softUpgradeVersionList = infoData.getUniversalData().getSoftUpgradeVersion();
                    ArrayList<String> hardUpgradeVersionList = infoData.getUniversalData().getHardUpgradeVersion();


                    if (hardUpgradeVersionList.contains(Utils.getAppVersion(getApplicationContext()))) {


                        mUpgrade_type = Upgrade_Type.HARD_UPGRADE;

                        invokeModalForUniversalConversion(infoData);

                    } else if (softUpgradeVersionList.contains(Utils.getAppVersion(getApplicationContext()))) {


                        mUpgrade_type = Upgrade_Type.SOFT_UPGRADE;
                        // setDialogUIComponents(infoData);
                        int daysSinceModalInvocation = findDiffinDays(getCurrentTimeStamp(), getTimesStampWhenUniversalUpgradeModalWasInvoked());
                        int timeIntervalInJSON = Integer.parseInt(infoData.getUniversalData().getSoftUpgradeNotifyPeriod());
                        if (daysSinceModalInvocation == -1 || daysSinceModalInvocation >= timeIntervalInJSON)
                            invokeModalForUniversalConversion(infoData);


                    }
                }

            }

            @Override
            public void onError(Object data) {
                /**
                 * We will call clearCacheMemory to clear cache , as clearing deals cache value comes from infomessage.json
                 */
                clearCacheMemory();
            }
        };
        preAuthCheckService.getInfoMessageJson(infoMessageListener);
        preAuthCheckService.getHighlightedFeatures(new NetworkRequestListener() {

            @Override
            public void onSuccess(Object data) {
                //added by skrish1
                getHighlightedFeatureStatus();
            }

            @Override
            public void onError(Object data) {
                // do nothing. never be called
            }
        });

    }

    private void handleApplyNowBannerKillSwitch(PreAuthbean mPreAuthBean) {
        if (mPreAuthBean != null && mPreAuthBean.getHideScreens() != null && mPreAuthBean.getHideScreens().contains(Utils.APPLY_NOW)) {
            isApplyNowKillSwitch = true;
        }
    }

    private void initWalletEligibility() {
        //init Wallet eligibilty call as soon as preAuth done.
            LoginServiceClass walletService = new LoginServiceClass(getContext());
            walletService.initWalletEligibilityCheckInBackground();
    }



    //US82881_Geofence
    private void handleGeoFenceKillSwitch(PreAuthbean mPreAuthBean) {
        //Hide geofence link if kill switch is enabled, not using Utils.isOptionAvailable as it is in card project
        if(Utils.isRunningOnHandset(LoginActivity.this) && mPreAuthBean.getHideScreens()!=null && mPreAuthBean.getHideScreens().contains(Utils.GEOFENCE_KILLSWITCH_KEY)){
            FacadeFactory.getCardFacade().callGeofenceServiceToRemove(this.getApplicationContext());
            geofence_link.setVisibility(View.GONE);
            vertical_separator2.setVisibility(View.GONE);
        }
    }

    private boolean isGeoFenceAvailable(){
        boolean isGeofenceUser =false;
        SharedPreferences prefs = getApplicationContext().getSharedPreferences(com.discover.mobile.common.Utils.GEOFENCE_PREF_VALUE, Context.MODE_PRIVATE);
        if(!prefs.getBoolean(com.discover.mobile.common.Utils.GEOFENCE_PREF_VALID_USER,false)){
            isGeofenceUser = true;
        }
        return isGeofenceUser;
    }

    //START - VOC-53603 - force upgrade code
    BroadcastReceiver networkChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            onPreAuthCheck();
        }
    };

    private void onPreAuthCheck() {
        boolean isForceUpGrade = (boolean) Utils.getPreferenceValue(LoginActivity.this,Constants.IS_FORCE_UPGRADE, 0, Utils.Type.BOOLEAN,Constants.FORCE_UPGRADE_SHARED_PREF);
        if (isForceUpGrade) {
            String header = (String) Utils.getPreferenceValue(LoginActivity.this,Constants.FORCE_UPGRADE_HEADER, 0, Utils.Type.STRING,Constants.FORCE_UPGRADE_SHARED_PREF);
            String message = (String) Utils.getPreferenceValue(LoginActivity.this,Constants.FORCE_UPGRADE_MESSAGE, 0, Utils.Type.STRING,Constants.FORCE_UPGRADE_SHARED_PREF);
            String redirectTitle = (String) Utils.getPreferenceValue(LoginActivity.this,Constants.FORCE_UPGRADE_REDIRECT_TITLE, 0, Utils.Type.STRING,Constants.FORCE_UPGRADE_SHARED_PREF);
            String redirectUrl = (String) Utils.getPreferenceValue(LoginActivity.this,Constants.FORCE_UPGRADE_REDIRECT_URL, 0, Utils.Type.STRING,Constants.FORCE_UPGRADE_SHARED_PREF);

            if(TextUtils.isEmpty(redirectTitle)){
                redirectTitle = null;
            }
            if(TextUtils.isEmpty(redirectUrl)){
                redirectUrl = null;
            }

         //   showForcedUpgradeAlertDialog(LoginActivity.this, header, message, redirectTitle, redirectUrl);
        }
        else {
            startPreAuthCheck();
        }
    }
    //END - VOC-53603 - force upgrade code

    /**
     * This method sends call to add the kill-switch to utils
     */
    private void handlePreLoginKillSwitch(PreAuthbean mPreAuthBean) {
        if (mPreAuthBean.getHideScreens() != null) {
            FacadeFactory.getCardLoginFacade().addPreloginKillSwitch(LoginActivity.this, mPreAuthBean.getHideScreens());
        }
    }
    //Changes ends

    /*
	 * (non-Javadoc)
	 *
	 * @see com.discover.mobile.ErrorHandlerUi#getErrorLabel()
	 */
    @Override
    public TextView getErrorLabel() {
        return null;
    }

    /*
	 * (non-Javadoc)
	 *
	 * @see com.discover.mobile.ErrorHandlerUi#getInputFields()
	 */
    @Override
    public List<EditText> getInputFields() {
        return null;
    }

    /**
     * Used to update the globals data stored at login for CARD or BANK and
     * retrieves user information. Should only be called if logged in otherwise
     * will return false.
     *
     * @param account Specify either Globals.CARD_ACCOUNT or Globals.BANK_ACCOUNT
     * @return Returns true if successful, false otherwise.
     */
    @Override
    public boolean updateAccountInformation(final AccountType account) {
        final boolean updated = Globals.updateAccountInformation(account,
                getContext(), username, saveUserId);
        username = StringUtility.EMPTY;
        return updated;
    }

    /**
     * USUS13409, by hkakadi To stop storing account number in shared prefrence
     */
    @Override
    public boolean updateAccountInformation(final AccountType account,
                                            String userId) {
        try {
            Double.parseDouble(username);
        } catch (NumberFormatException e) {
            userId = username;
        }

        final boolean updated = Globals.updateAccountInformation(account,
                getContext(), userId, saveUserId);
        username = StringUtility.EMPTY;
        return updated;
    }

    //Changes done as part of Log in migration. We need to return current context for all getContext call. Super class is returning null so we are overriding the function and returning the current context.
    //Changes start
    @Override
    public Context getContext() {
        return this;
    }

    /**
     * Sets a flag which is used to determine whether Pre-Authentication has
     * been performed by the application already. This flag helps avoid
     * Pre-Authentication being performed more than once by the application. In
     * addition, it hides the splash screen and shows login views in the case
     * the splash screen is being displayed.
     *
     * @param result True if Pre-Authentication has been completed, false
     *               otherwise.
     */
    public void preAuthComplete(final boolean result) {
        FacadeFactory.getWDAFacade().trackAppForeground();

        /**start Added for US83286  - Android Fingerprint - Kill-switch
         * By default disable FP link & Let pre-auth call happen & depending on Kill-switch value from pre-auth call show FP link & modal */
//        Log.d("sach_fp_modal", "preAuthComplete: checking modal result: " + result);
        if (!isForceUpgrade)
        {
            if(!isUserManualLoggedOut) {
                checkFingerprintAndInvokeModal();
//        Log.d("sach_fp_modal", "preAuthComplete: checking FP Link result: " + result);
            }
            checkVisibilityOfFPLink();
            isForceUpgrade = false;
            isUserManualLoggedOut = false;
        }

        MsigniaSingleton.Instance().init(getApplicationContext());
    }

    /**
     * Method to check visiblity of FP - link
     * Added for US71607 Fingerprint login screen option
     */
    private void checkVisibilityOfFPLink() {
        //Added to fix card and bank toggle fingerprint issue
        fingerPrintUtils = null;
        fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);

        int fpScanningFailedCount = fingerPrintUtils.getFPScanningFailedCount();
        //Added Kill-switch condition for US83286  - Android Fingerprint - Kill-switch
        boolean isFPKillSwitchEnabled = fingerPrintUtils.isFPPreloginKillSwitchEnabled();
        if (!isFPKillSwitchEnabled && FingerPrintUtils.isFingerprintHardwareAvailable(LoginActivity.this) && fpScanningFailedCount < FingerPrintUtils.FP_SCANNING_MAX_FAILED_COUNT) {
            enableDisableFPLink(true);
        } else {
            enableDisableFPLink(false);
        }
    }

    /**
     * Returns error handler
     */
    @Override
    public ErrorHandler getErrorHandler() {
        if (Globals.getCurrentAccount() == AccountType.CARD_ACCOUNT) {
            return FacadeFactory.getCardFacade().getCardErrorHandler();
        } else {
            return FacadeFactory.getBankLoginFacade().getBankErrorHandler();
        }
    }

    @Override
    public void onBackPressed() {

        if (DiscoverApplication.isInQuickViewMode) {
            if (Utils.isRunningOnHandset(LoginActivity.this)) {
                hideQuickViewPage(true, true);
            } else {
                hideQuickViewPage(true);
            }
            //INC-9049232- start
            resetPasscodeViews();
            //INC-9049232- end
        } else {
            //Clear Deeplink Value on back press
            FacadeFactory.getBankLoginFacade().resetDeepLinkValues();
            //Clear Deeplink Card Values on back press
            FacadeFactory.getCardLoginFacade().resetDeepLinkValues();

            Globals.getCache().clear();
            //Commented below code as part of log in migration. We need to check if we need to call super.onBackPressed()
            //Change started
            //	navigateBack();
            super.onBackPressed();
            //Change end
        }
    }

    @Override
    public CallbackPriority getCallbackPriority() {

        return CallbackPriority.LAST;
    }

    /*
	 * This method is used in the CreateLoginCall. Once the login service call
	 * is complete, we need to reenable ui elements for clicks
	 */
    @Override
    public void complete(final NetworkServiceCall<?> sender, final Object result) {
        // login is completed (whether or not successfull)
        //enableInput();
    }

    /**
     * Handles back nav for passcode specific scenarios
     */

    @Override
    public boolean onKeyDown(final int keyCode, final KeyEvent event) {
        if (!DiscoverApplication.isInQuickViewMode) {
            if (keyCode == KeyEvent.KEYCODE_BACK && isTaskRoot()) {
                if (pUtils.isForgotPasscode()) {
                    pUtils.setForgotPasscode(false);
                    isUserIDLogin = false;
                    displayActiveLoginMode(false);
                    return true;
                } else if (bankpasscodeUtils.isForgotPasscode()) {
                    bankpasscodeUtils.setForgotPasscode(false);
                    isBankUserIDLogin = false;
                    displayActiveLoginMode(false);
                    return true;
                } else if (isUserIDLogin) {
                    isUserIDLogin = false;
                    displayActiveLoginMode(false);
                    return true;
                } else if (isBankUserIDLogin) {
                    isBankUserIDLogin = false;
                    displayActiveLoginMode(false);
                    return true;
                }
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void togglePreLoginMOP(final boolean isAvailabel) {
        showDealKillSwitchFlag = isAvailabel;
    }

    // check google services are installed for fire phone
    public boolean isGoogleMapsInstalled() {
        try {
            ApplicationInfo info = getPackageManager().getApplicationInfo(
                    "com.google.android.apps.maps", 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }



    @Override
    public void onPause() {
        super.onPause();
        hideApplyNowBanner();
        TrackingHelper.stopActivity();  // To avoid backend crash report to Site cat
        final Calendar pauseCalendarInstance = Calendar.getInstance();
        pauseTimeStamp = pauseCalendarInstance.getTimeInMillis();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getWindow().getCurrentFocus()
                .getWindowToken(), 0);

        ////START - VOC-53603 - force upgrade code unregister the network change action receiver
        if (networkChangeListenerIntent != null) {
            unregisterReceiver(networkChangeReceiver);
            networkChangeListenerIntent = null;
        }
        //END - VOC-53603 - force upgrade code
        isUserManualLoggedOut = false;//reset the flag as soon as app moved to background.
    }

    public boolean isAluModalShowing() {
        return isAluModalShowing;
    }

    public void setAluModalShowing(boolean isAluModalShowing) {
        this.isAluModalShowing = isAluModalShowing;
    }

    /**
     * This method handles current status of focus on user id and password. It
     * moves line which is below of user id and password field.
     *
     * @param focusOnUserId - <code>true</code> will enable line between userid and
     *                      password. If <code>false</code>, it will enable line below
     *                      password field.
     */
    private void resetHorizontalLinePlace(boolean focusOnUserId) {
        if (focusOnUserId) {
            userIdLine.setVisibility(View.VISIBLE);
            passFieldLine.setVisibility(View.INVISIBLE);
        } else {
            userIdLine.setVisibility(View.INVISIBLE);
            passFieldLine.setVisibility(View.VISIBLE);
        }
    }

    private void initAnimations() {
        loginBtnFadeIn = AnimationUtils.loadAnimation(this,
                R.anim.fade_in_animation);
        loginBtnFadeOut = AnimationUtils.loadAnimation(this,
                R.anim.fade_out_animation);

        remmeberBtnFadeIn = AnimationUtils.loadAnimation(this,
                R.anim.fade_in_animation);
        remmemberBtnFadeOut = AnimationUtils.loadAnimation(this,
                R.anim.fade_out_animation);

        footerFadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in_slow);

        footerFadeIn.setDuration(FOOTER_DURATION);

        versionFooterFadeIn = AnimationUtils.loadAnimation(this,
                R.anim.fade_in_slow);

        versionFooterFadeIn.setDuration(FOOTER_DURATION);

        loginFadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in_slow);
        // loginFadeIn.setStartOffset(ID_VIEW_START_AFTER);
        loginFadeIn.setDuration(ID_VIEW_DURATION);

        passcodeFadeIn = AnimationUtils
                .loadAnimation(this, R.anim.fade_in_slow);
        // loginFadeIn.setStartOffset(ID_VIEW_START_AFTER);
        passcodeFadeIn.setDuration(ID_VIEW_DURATION);

        loginBtnFadeIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
                mLoginButton.setTag(Integer.valueOf(1));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mLoginButton.setVisibility(View.VISIBLE);
                mLoginButton.setTag(Integer.valueOf(0));
            }
        });

        loginBtnFadeOut.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mLoginButton.setVisibility(View.GONE);
            }
        });
        remmeberBtnFadeIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
                rememberLayout.setTag(Integer.valueOf(1));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                rememberLayout.setVisibility(View.VISIBLE);
                rememberLayout.setTag(Integer.valueOf(0));
            }
        });

        remmemberBtnFadeOut.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                rememberLayout.setVisibility(View.GONE);
            }
        });
        registerLinkFadeIn = AnimationUtils.loadAnimation(this,
                R.anim.fade_in_animation);
        registerLinkFadeOut = AnimationUtils.loadAnimation(this,
                R.anim.fade_out_animation);

        registerLinkFadeIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
                // US37429 changes start
                passcodeLinkLayout.setVisibility(View.GONE);
                // US37429 changes end
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                // US37429 changes start
                passcodeLinkLayout.setVisibility(View.GONE);
                // US37429 changes end
                registerLinkLayout.setVisibility(View.VISIBLE);
            }
        });

        registerLinkFadeOut.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                registerLinkLayout.setVisibility(View.GONE);
                showPasscodeLoginViewAfterFirstLogin();
            }
        });

        loginFadeIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {

                vLogin.setVisibility(View.VISIBLE);

                //Below if condition is added to avoid keyboard popup if quick view is enabled already
                if (!DiscoverApplication.isInQuickViewMode) {
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                    //QV Univ Migration -Start
                    if (!Utils.isRunningOnHandset(LoginActivity.this)) {
                        keyBoardStateVisible = true;
                    }
                    //QV Univ Migration -End

                    //objApplication.setLoginKeyBoardStateVisible(true);
                    EditText focusedView = null;
                    if (idField.length() > 0) {
                        passField.requestFocus();
                        focusedView = passField;
                    } else {
                        idField.requestFocus();
                        focusedView = idField;
                    }

                    SharedPreferences sharedPref = getSharedPreferences(getResources()
                            .getString(R.string.post_login_username), Context.MODE_PRIVATE);

                    if(!sharedPref.getBoolean(getResources()
                            .getString(R.string.isUserLoggedInFirstTime), true)){
                        final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(focusedView, InputMethodManager.SHOW_IMPLICIT);
                    } else {
                        keyBoardStateVisible = false;
                    }
                }
            }
        });

        passcodeFadeIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {

                vPasscode.setVisibility(View.VISIBLE);
                passcodeLinkLayout.setVisibility(View.VISIBLE);

                //Below if condition is added to avoid keyboard popup if quick view is enabled already
                if (!DiscoverApplication.isInQuickViewMode) {
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

                    fieldTVs[0].requestFocus();
                    final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(getCurrentFocus(),
                            InputMethodManager.SHOW_IMPLICIT);
                }
            }
        });

        footerFadeIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
                footer.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                footer.setVisibility(View.VISIBLE);
            }
        });

        versionFooterFadeIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                versionAndPrivacyLayout.setVisibility(View.VISIBLE);
                idPasswordView.setVisibility(View.VISIBLE);
            }

        });

    }

    /*
	 * show login button if both userId and password is not null
	 */
    private void showLoginOption() {
        boolean isUserIdEmpty = TextUtils.isEmpty(idField.getText());
        boolean isPasswordEmpty = TextUtils.isEmpty(passField.getText());
        if (isUserIdEmpty && (rememberLayout.getVisibility() == View.VISIBLE)) {
            if (Globals.isRememberId() == false) {
                rememberLayout.startAnimation(remmemberBtnFadeOut);
            }
        }
        if ((!isUserIdEmpty)
                && (idField.getText().toString().matches(VALID_USER_ID_MATCHER))) {
            // Restrict multiple animations for this view. If Login in Visible,
            // no use to do animation.
            if (rememberLayout.getVisibility() != View.VISIBLE) {
                if ((Integer) rememberLayout.getTag() == 0) {
                    rememberLayout.startAnimation(remmeberBtnFadeIn);
                }
                //rememberChkbox.setText(R.string.fa_uncheck_);
                rememberTick.setVisibility(View.INVISIBLE);
            }
        }
        if ((!isUserIdEmpty)
                && (passField.getText().toString().trim().length() >= PASSWORD_MIN_LEN)) {
            // Restrict multiple animations for this view. If Login in Visible,
            // no use to do animation.
            if (mLoginButton.getVisibility() != View.VISIBLE) {
                if ((Integer) mLoginButton.getTag() == 0) {
                    mLoginButton.startAnimation(loginBtnFadeIn);
                }
            }
        } else {
            // Restrict multiple animations for this view. If Login in
            // invisible, no use to do animation.
            if (mLoginButton.getVisibility() == View.VISIBLE) {
                // Animate Login to hide
                mLoginButton.startAnimation(loginBtnFadeOut);
            }

        }
    }

    /*
	 * handle all the clicks
	 */
    public void onClick(View v) {
        int currentViewId = v.getId();
        if (currentViewId == R.id.feedbackButton) {
            startFeedbackView();
        } else if (currentViewId == R.id.atmButton) {
            startATMView();
        } else if (currentViewId == R.id.loginButton) {
            if (DiscoverApplication.isInQuickViewMode) {
                if (isCardChecked) {
                    TrackingHelper.trackCardPageProp1(
                            AnalyticsPage.LOGIN_TOOLBAR_LOGIN_BTN_QV_ON,
                            AnalyticsPage.LOGIN_TOOLBAR_LOGIN_BTN_QV_ON);
                }
                if (Utils.isRunningOnHandset(LoginActivity.this)) {
                    hideQuickViewPage(true, true);
                } else {
                    hideQuickViewPage(true);
                }
            } else {
                if (isCardChecked) {
                    TrackingHelper.trackCardPageProp1(
                            AnalyticsPage.LOGIN_TOOLBAR_LOGIN_BTN_QV_OFF,
                            AnalyticsPage.LOGIN_TOOLBAR_LOGIN_BTN_QV_OFF);
                }
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(getCurrentFocus(), 0);
            }

        } else if (currentViewId == R.id.helpButton) {
            startHelpView();
        } else if (currentViewId == R.id.productsButton) {
            startProductsiew();
        } else if (currentViewId == R.id.tv_register_link_lable) {
            if (isCardChecked) {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.REGISTER_LOGIN_PG_LNK,
                        AnalyticsPage.REGISTER_LOGIN_PG_LNK);
                //Changes done as part of Login Migration. We are getting null pointer exception while getting getContext in (GetAppVersionRequest.java:55)
                //Change started
                FacadeFactory.getCardFacade().navToRegister(getContext());
                //Change ends
            }
        } else if (currentViewId == R.id.bankToggle) {
            // Need to add the PM data cookie when user toggles to fix OOB issue
            try {
                BankSessionCookieManager.getInstance(DiscoverActivityManager.getActiveActivity()).clearAllCookie();
            } catch (Exception e) {
                e.printStackTrace();
            }

            checkBankToggle();
            displayActiveLoginMode(false);
        } else if (currentViewId == R.id.cardToggle) {
            // Need to add the PM data cookie when user toggles to fix OOB issue
            SessionCookieManager coockieManager = SessionCookieManager.getInstance();
            cookieManagerProxy = (CookieManagerProxy) coockieManager.getCookieManager();
            cookieManagerProxy.clearAllCookies();

            checkCardToggle();
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put("my.prop1", AnalyticsPage.CARD_LOGIN_TOGGLE_prop1);
            extras.put("pe", AnalyticsPage.CARD_LOGIN_TOGGLE_pe);
            extras.put("pev1", AnalyticsPage.CARD_LOGIN_TOGGLE_pev1);
            TrackingHelper.trackCardPageProp1(
                    AnalyticsPage.CARD_LOGIN_TOGGLE_prop1,
                    AnalyticsPage.CARD_LOGIN_TOGGLE_pev1, extras);
            displayActiveLoginMode(false);
        } else if (currentViewId == R.id.login_btn_container) {
            //To avoid addition of Authorization Bearer with token value during login.
            SessionTokenManager.clearToken();
            executeLogin(v);
        } else if (currentViewId == R.id.tv_forgot_password_lable) {
            rememberFocus();
            if (isCardChecked) {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.FORGOT_PWD_LOGIN_PG_LNK,
                        AnalyticsPage.FORGOT_PWD_LOGIN_PG_LNK);
                FacadeFactory.getCardFacade().navToForgot(this);
            } else {
                FacadeFactory.getBankLoginFacade().navigateToForgotPassword();
            }
        } else if (currentViewId == R.id.tv_passcode_link_lable) {

            Integer tagStatus = (Integer) v.getTag();
            //if (tagStatus == 0) {
            // US37429 changes starts
            if (isPasscodeEnabledOnThisDevice() == false) {
                rememberFocus();
                showPasscodeInfoModal();
                return;
            }

            idField.setText("");
            forgotPasscodeSelected = false;
            hideUIDLogin();
            showPasscodeLogin(false);
            if (!isCardLogin()) {
                isBankUserIDLogin = false;
            } else {
                isUserIDLogin = false;
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.FORGOT_PASSCODE_LNK,
                        AnalyticsPage.FORGOT_PASSCODE_LNK);
            }
        }
        /**start US71607 Fingerprint login screen option */
        else if (currentViewId == R.id.tv_fingerprint_link_label) {
            //Start: US72282: FingerPrint Analytics
            if(Globals.isBankLoginSelected) {
                HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                extras.put(AnalyticsPage.PROP1,AnalyticsPage.FINGER_PRINT_LOGIN_LNK);
                TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_LOGIN_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
            }
            else {
                //End:  US72282: FingerPrint Analytics

                /**Start Changes for US71879: Fingerpeint Site Catalyst Tags*/
                //On the click of Finger Print log in link
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(LoginActivity.this.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_LOGIN_LNK);
                TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_LOGIN_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/
            }
            if (null == fingerPrintUtils)
                fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
            if (fingerPrintUtils.getFingerPrintStatus()) {
                showFingerprintDialog();
            } else {
                showFingerprintShakeModal();
            }
        }/**end US71607 Fingerprint login screen option */

        else if (currentViewId == R.id.tv_forgot_password_lable) {
            rememberFocus();
            if (isCardLogin()) {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.FORGOT_PWD_LNK,
                        AnalyticsPage.FORGOT_PWD_LNK);
                FacadeFactory.getCardFacade().navToForgot(this);
            } else {
                FacadeFactory.getBankLoginFacade().navigateToForgotPassword();
            }
        } else if (currentViewId == R.id.version_number) {
            rememberFocus();
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put("my.prop1",
                    AnalyticsPage.VERSION_CLICKED_LOGIN_SCREEN_prop1);
            extras.put("pe", AnalyticsPage.VERSION_CLICKED_LOGIN_SCREEN_pe);
            extras.put("pev1", AnalyticsPage.VERSION_CLICKED_LOGIN_SCREEN_pev1);
            TrackingHelper.trackCardPageProp1(
                    AnalyticsPage.VERSION_CLICKED_LOGIN_SCREEN_prop1,
                    AnalyticsPage.VERSION_CLICKED_LOGIN_SCREEN_pev1, extras);
            /**Start Change - Commenting below line - US44342 */
//            FacadeFactory.getAppVersionNameFacade().retrieveApplicationVersionName(LoginActivity.this);
            AppVersionRequest versionRequest = new AppVersionRequest(
                    LoginActivity.this, true);
            versionRequest.sendRequest();
            /**End Change - Added above lines AppVersionRequest Moved to Common folder - US44342 */

        } else if (currentViewId == R.id.privacy_and_terms) {
            rememberFocus();
            if (isCardLogin()) {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_PRIVACY_AND_TERMS_LNK,
                        AnalyticsPage.LOGIN_PRIVACY_AND_TERMS_LNK);

                FacadeFactory.getCardFacade().navToPrivacyTerms(
                        LoginActivity.this);
            } else {
                FacadeFactory.getBankLoginFacade().openPrivacyAndTerms();
            }
            /*Intent intent = new Intent(this, HighlightedFeaturePreLoginActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt(HFConstants.Args.PAGER_LOCATION, 0);
            bundle.putBoolean(HFConstants.Args.WHATS_NEW_FLAG, true);
            // Does not matter if we put pre-login flag for Whats-new or not.
            bundle.putBoolean(HFConstants.Args.PRE_LOGIN_FLAG, false);
            bundle.putSerializable(HFConstants.Args.LOGIN_TYPE, HFConstants.LoginType.CARD);
            intent.putExtras(bundle);
            startActivity(intent);*/
        } else if (currentViewId == R.id.geofence_link) {
            rememberFocus();
            FacadeFactory.getCardFacade().navToGeofencePlotter(
                    LoginActivity.this);
        }
        // US37334 Changes start -- pkuma13
        /*else if (currentViewId == R.id.passcode_forgot) {

			forgotPasscodeSelected = true;
			if (isCardLogin()) {
				//TODO check which one to use for Analytics
				//TrackingHelper.trackPageView(AnalyticsPage.FORGOT_PASSCODE);
				TrackingHelper.trackCardPageProp1(
	    				AnalyticsPage.FORGOT_PASSCODE_LNK,
	    				AnalyticsPage.FORGOT_PASSCODE_LNK);
				isUserIDLogin = true;
				idField.setHint(R.string.card_user_id_string);
                toggleBankCardLogin(goToCardButton);
			} else {
				if (!isCardLogin()) {
					FacadeFactory.getBankLoginFacade().forceTrackPage(
							R.string.passcode_forgot_analytics);
				}
				isBankUserIDLogin = true;
				idField.setHint(R.string.bank_user_id_string);
                toggleBankCardLogin(goToBankButton);
			}
			forceSoftKeyboardShown(0);
		}*/
        // US37334 Changes end -- pkuma13
        else if (currentViewId == R.id.passcode_user_id_login) {

            if (isCardLogin()) {
                Globals.setBankLoginSelected(false);
                TrackingHelper.trackCardPageProp1(AnalyticsPage.USERIDLOGIN_prop1, AnalyticsPage.USERIDLOGIN_pev1);
                isUserIDLogin = true;
                idField.setHint(R.string.card_user_id_string);
                checkCardToggle();
                displayActiveLoginMode(false);
            } else {
                Globals.setBankLoginSelected(true);
                isBankUserIDLogin = true;
                idField.setHint(R.string.bank_user_id_string);
                checkBankToggle();
                displayActiveLoginMode(false);
            }

		    /*
			if (isCardLogin()) {
				Globals.setBankLoginSelected(false);
				TrackingHelper.trackCardPageProp1(
	    				AnalyticsPage.USERIDLOGIN_prop1,
	    				AnalyticsPage.USERIDLOGIN_pev1);
				// BankAndroidWearUtils.setBankLoginSelected(DiscoverActivityManager.getActiveActivity().getApplicationContext(),
				// false);
				isUserIDLogin = true;
				displayActiveLoginMode(false);
			} else {
				Globals.setBankLoginSelected(true);
				// BankAndroidWearUtils.setBankLoginSelected(DiscoverActivityManager.getActiveActivity().getApplicationContext(),
				// true);
				isBankUserIDLogin = true;
				displayActiveLoginMode(false);
			}*/
            /**start hotFix 2 7. release*/
            if (toggleSelection.getVisibility() == View.INVISIBLE) {
                relativeLayoutToggle.setVisibility(View.VISIBLE);
                toggleSelection.setVisibility(View.VISIBLE);
                relativeLayoutToggle.invalidate();
            }
            /**end hotFix 2 7. release*/
        } else if (currentViewId == R.id.quickView) {
            // US26058


            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put(
                    getResources().getString(R.string.context_Property_1),
                    getResources().getString(
                            R.string.bank_analytics_quick_view_login_tap));
            extras.put(
                    getResources().getString(R.string.context_Property_pev1),
                    getResources().getString(
                            R.string.bank_analytics_quick_view_login_tap));
            extras.put(
                    getResources().getString(R.string.context_Property_pe),
                    getResources().getString(
                            R.string.bank_analytics_quick_view_lnk_o));

            if (!isCardChecked) {
                TrackingHelper.trackBankPage(null, extras);
            } else {
                TrackingHelper.trackCardPage(null, extras);
            }


            showQuickView = true;
            hideKeyboard();

			/*
			 * isInQuickViewMode = true; showQuickViewPage();
			 */

        } else if (currentViewId == R.id.pwd_red_button) {
            pwdRedBtn.setVisibility(View.INVISIBLE);
            uidRedBtn.setVisibility(View.INVISIBLE);
            passFieldLine.setBackgroundColor(getResources()
                    .getColor(R.color.white));
            //	idField.getText().clear();
			/*if (rememberChkbox.getText().toString()
					.equals(getString((R.string.fa_checkbox))))*/
            if (rememberTick.getVisibility() == View.VISIBLE) {
                //rememberChkbox.setText(R.string.fa_uncheck_);
                rememberTick.setVisibility(View.INVISIBLE);

            } else if (idField.length() > 0) {
                rememberLayout.setVisibility(View.VISIBLE);
            } else {
                rememberLayout.setVisibility(View.INVISIBLE);
            }
            /** Defect Fix 194756 **/
			/*
			 * passFieldLine.setBackgroundColor(getResources().getColor(R.color.
			 * white));
			 */
            /** Defect Fix 194756 **/
            passField.requestFocus();
            passField.setCursorVisible(true);
            resetHorizontalLinePlace(false);
            if (!isPasscodeLogin) {
                loadSavedCredentials();
            }
            showKeyboard();

        } else if (currentViewId == R.id.uid_red_button) {
            uidRedBtn.setVisibility(View.INVISIBLE);
            pwdRedBtn.setVisibility(View.INVISIBLE);
            idField.requestFocus();
            idField.setCursorVisible(true);
            idField.getText().clear();
            userIdLine.setBackgroundColor(getResources()
                    .getColor(R.color.white));
			/*if (rememberChkbox.getText().toString()
					.equals(getString((R.string.fa_checkbox))))*/
            if (rememberTick.getVisibility() == View.VISIBLE) {
                //rememberChkbox.setText(R.string.fa_uncheck_);
                rememberTick.setVisibility(View.INVISIBLE);
            } else if (idField.length() > 0) {
                rememberLayout.setVisibility(View.VISIBLE);
            } else {
                rememberLayout.setVisibility(View.INVISIBLE);
            }

            resetHorizontalLinePlace(true);
            if (!isPasscodeLogin) {
                loadSavedCredentials();
            }
            showKeyboard();
        }
    }

    /*
	 * Method to check Card Toggle
	 */
    private void checkCardToggle() {
        isCardChecked = true;
        toggleSelection.setBackgroundResource(R.drawable.bank_selected);
        card.setTextColor(Color.parseColor("#015185"));
        bank.setTextColor(Color.parseColor("#ffffff"));
        checkMarkBank.setVisibility(View.INVISIBLE);
        idField.setHint(R.string.card_user_id_string);
        checkMarkCard.setVisibility(View.VISIBLE);
        enteredUserName = idField.getText().toString();
        enteredPassword = passField.getText().toString();

        SharedPreferences sharedPref = getSharedPreferences(getResources()
                        .getString(R.string.post_login_username),
                Context.MODE_PRIVATE);
        boolean shouldShowRegister = sharedPref.getBoolean(getResources()
                .getString(R.string.isUserLoggedInFirstTime), true);

        if (shouldShowRegister) {
            // US37429 changes start
            passcodeLinkLayout.setVisibility(View.GONE);
            // US37429 changes end
            registerLinkLayout.startAnimation(registerLinkFadeIn);
        }
        /*if (!isPasscodeLogin) {
            loadSavedCredentials();
        }*/
        if (Utils.isRunningOnHandset(LoginActivity.this)) {
            LoginActivity.updateUiInWear(LoginActivity.this,
                    !Globals.isBankLoginSelected());
        }
        Globals.setBankLoginSelected(false);
        //Added to fix card and bank toggle fingerprint issue
        fingerPrintUtils = null;
        fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
        Globals.loadPreferences(this, AccountType.CARD_ACCOUNT);
        Globals.savePreferences(this);
    }

    /*
	 * Method to check Bank Toggle
	 */
    private void checkBankToggle() {
        isCardChecked = false;
        toggleSelection.setBackgroundResource(R.drawable.card_selected);
        card.setTextColor(Color.parseColor("#ffffff"));
        bank.setTextColor(Color.parseColor("#015185"));
        idField.setHint(R.string.bank_user_id_string);
        checkMarkBank.setVisibility(View.VISIBLE);
        checkMarkCard.setVisibility(View.INVISIBLE);
        pwdRedBtn.setVisibility(View.INVISIBLE);
        uidRedBtn.setVisibility(View.INVISIBLE);
        enteredUserName = idField.getText().toString();
        enteredPassword = passField.getText().toString();

        HashMap<String, Object> extras = new HashMap<String, Object>();
        extras.put("my.prop1", AnalyticsPage.BANK_LOGIN_TOGGLE_prop1);
        extras.put("pe", AnalyticsPage.BANK_LOGIN_TOGGLE_pe);
        extras.put("pev1", AnalyticsPage.BANK_LOGIN_TOGGLE_pev1);
        //Reason for commenting below line on tap of bank toggle it tracking to card suite. Added proper suite
//        TrackingHelper.trackCardPageProp1(
//                AnalyticsPage.BANK_LOGIN_TOGGLE_prop1,
//                AnalyticsPage.BANK_LOGIN_TOGGLE_pev1, extras);

        TrackingHelper.trackBankPage(AnalyticsPage.BANK_LOGIN_TOGGLE_prop1, extras);

        if (registerLinkLayout.getVisibility() == View.VISIBLE) {
            // US37429 changes start
            passcodeLinkLayout.setVisibility(View.GONE);
            // US37429 changes end
            registerLinkLayout.startAnimation(registerLinkFadeOut);
        } else {
            // US37429 changes start
            showPasscodeLoginViewAfterFirstLogin();
            // US37429 changes end
        }
        /*if (!isPasscodeLogin) {
            loadSavedCredentials();
        }*/
        if (Utils.isRunningOnHandset(LoginActivity.this)) {
            LoginActivity.updateUiInWear(LoginActivity.this,
                    !Globals.isBankLoginSelected());
        }
        Globals.setBankLoginSelected(true);
        //Added to fix card and bank toggle fingerprint issue
        fingerPrintUtils = null;
        fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
        Globals.loadPreferences(this, AccountType.BANK_ACCOUNT);
        Globals.savePreferences(this);
    }

    // to open feedback page
    private void startFeedbackView() {
        rememberFocus();
        //Analytics tags added

        if (isCardLogin()) {
            if (!DiscoverApplication.isInQuickViewMode) {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_TOOLBAR_FEEDBACK_BTN_QV_OFF,
                        AnalyticsPage.LOGIN_TOOLBAR_FEEDBACK_BTN_QV_OFF);
            } else {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_TOOLBAR_FEEDBACK_BTN_QV_ON,
                        AnalyticsPage.LOGIN_TOOLBAR_FEEDBACK_BTN_QV_ON);
            }
        }

        clearInputs();
        if (!isPasscodeLogin) {
            idField.requestFocus();
        }

        if (isCardLogin()) {
            FacadeFactory.getCardFacade().navToProvideFeedback(
                    DiscoverActivityManager.getActiveActivity());
        } else {
            FacadeFactory.getBankLoginFacade().navigateToFeedback();
        }
    }

    // to open product page
    private void startProductsiew() {
        if (isCardChecked) {
            if (!DiscoverApplication.isInQuickViewMode) {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_TOOLBAR_PRODUCTS_BTN_QV_OFF,
                        AnalyticsPage.LOGIN_TOOLBAR_PRODUCTS_BTN_QV_OFF);
            } else {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_TOOLBAR_PRODUCTS_BTN_QV_ON,
                        AnalyticsPage.LOGIN_TOOLBAR_PRODUCTS_BTN_QV_ON);
            }
        }
        rememberFocus();
        clearInputs();
        //TODO need to check the below code currently commented to resolve compilation issues in tablet as we don't have same funtion in tablet Hari
        /**Start change -Commenting below line - US45952 */
//        FacadeFactory.getCardProductFacade().showProductsPage(LoginActivity.this, isCardChecked);
        CardProductFacadeImpl cardProductFacadeImpl = new CardProductFacadeImpl();
        cardProductFacadeImpl.showProductsPage(LoginActivity.this, isCardChecked);
        /**End change - added direct call to CardProductFacadeImpl(moved to common folder)- US45952 */
    }

    // to open help view
    private void startHelpView() {
        rememberFocus();
		/* if (isCardSelected) { */
        if (isCardChecked) {
            if (!DiscoverApplication.isInQuickViewMode) {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_OFF,
                        AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_OFF);
            } else {
                TrackingHelper.trackCardPageProp1(
                        AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_ON,
                        AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_ON);
            }
        } else {
            HashMap<String, Object> extras = new HashMap<String, Object>();
            if (!DiscoverApplication.isInQuickViewMode) {
                extras.put("my.prop1", AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_OFF);
                extras.put("pe", "lnk_o");
                extras.put("pev1", AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_OFF);
            } else {
                extras.put("my.prop1", AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_ON);
                extras.put("pe", "lnk_o");
                extras.put("pev1", AnalyticsPage.LOGIN_TOOLBAR_HELP_BTN_QV_ON);

            }

            TrackingHelper.trackBankPage(null, extras);
        }
		/*
		 * FacadeFactory.getBankLoginFacade().navigateToCustomerServiceMenu(
		 * isCardSelected);
		 */
        clearInputs();
        final Intent intent = new Intent(this, HelpActivity.class);
        intent.putExtra("IS_CARD_SELECTED", isCardLogin());
        intent.putExtra("HIGHLIGHTED_FEATURE_AVAILABLE",
                highlightedFeatureAvailable);
        intent.putExtra("SSO_AND_PASSCODE_ENABLED", pUtils.hideToggle() && !(isUserIDLogin || isBankUserIDLogin));
        startActivity(intent);
		/*
		 * } else { FacadeFactory.getBankLoginFacade().navigateToContactUs(
		 * isCardSelected); }
		 */
    }

    // to check if highlighted features are available
    void getHighlightedFeatureStatus() {
        // Removed unwanted Analytics code
        FacadeFactory.getHighlightedFeaturesFacade()
                .checkPreloginHightlightedFeaturesAvailable(this,
                        new NetworkRequestListener() {
                            @Override
                            public void onSuccess(Object data) {
                                highlightedFeatureAvailable = true;
                            }

                            @Override
                            public void onError(Object data) {
                                highlightedFeatureAvailable = false;
                            }
                        });
    }

    // to open ATM view
    private void startATMView() {
        //TODO:: Need to check with bank team whether this tag is correct or not.
        rememberFocus();
        openAtmLocator();
    //    if (!isCardChecked) {
        //    FacadeFactory.getBankLoginFacade().forceTrackPage(
         //           R.string.bank_analytics_atm_public);
       // }

    }

    /***
     * Method for updating register link layout.
     */
    private void updateRegisterLinkLayout(Context context) {
        if (isCardChecked) {
            SharedPreferences sharedPref = getSharedPreferences(getResources()
                            .getString(R.string.post_login_username),
                    Context.MODE_PRIVATE);
            boolean shouldShowRegister = sharedPref.getBoolean(getResources()
                    .getString(R.string.isUserLoggedInFirstTime), true);
            if (shouldShowRegister) {
                registerLinkLayout.setVisibility(View.VISIBLE);
            } else {
                registerLinkLayout.setVisibility(View.GONE);
                showPasscodeLoginViewAfterFirstLogin();
            }
        } else if (!(checkMarkCard.getVisibility() == View.VISIBLE)) {
            registerLinkLayout.setVisibility(View.GONE);
            showPasscodeLoginViewAfterFirstLogin();
        }
    }

    // *************************************************************************************************
    // ********************************* Start PASSCODE calls
    // ******************************************
    private void showUIDLogin(boolean comingFromAnimation) {

        //US27527:- sshar13(to check if the last login user is SSO)
		/*if(Globals.isSSOUser){
			//if SSO set hide bank/card toggle flag ;
			hideToggle = false;
		}*/

        if (comingFromAnimation) {

            SharedPreferences sharedPref = getSharedPreferences(getResources()
                    .getString(R.string.post_login_username), Context.MODE_PRIVATE);
            boolean shouldShowRegister = sharedPref.getBoolean(getResources()
                    .getString(R.string.isUserLoggedInFirstTime), true);
            if (shouldShowRegister == false) {
                showPasscodeLoginViewAfterFirstLogin();
            }

            vLogin.startAnimation(loginFadeIn);
        } else {
            vLogin.setVisibility(View.VISIBLE);

            if (!isCardLogin() && bankpasscodeUtils.doesDeviceTokenExist()) {
                passcodeLinkLayout.setVisibility(View.VISIBLE);
                // US37429 changes start - pkuma13
                passcodeLinkLayout.setTag(Integer.valueOf(1));
                // US37429 changes end - pkuma13
            } else if (isCardLogin() && pUtils.doesDeviceTokenExist()) {
                passcodeLinkLayout.setVisibility(View.VISIBLE);
                // US37429 changes start - pkuma13
                passcodeLinkLayout.setTag(Integer.valueOf(1));
                // US37429 changes end - pkuma13
            } else {
                passcodeLinkLayout.setVisibility(View.VISIBLE);
                // US37429 changes start - pkuma13
                passcodeLinkLayout.setTag(Integer.valueOf(0));
                // US37429 changes end - pkuma13
            }
            if (!isErrorLineDisplayed)
                loadSavedCredentials();
            // Request focus on view if not on uid/password
            if ((!idField.hasFocus()) && (!passField.hasFocus())) {
                if (!TextUtils.isEmpty(idField.getText())) {
                    passField.requestFocus();
                    // Reset cursor position at last entry of passcode field
                    passField.setSelection(passField.getText().length());
                    // focusedView = passField;
                } else {
                    idField.requestFocus();
                    // focusedView = idField;
                }
            }

            EditText focusedView = null;
            //Below if condition is added to avoid keyboard popup if quick view is enabled already
            if (!DiscoverApplication.isInQuickViewMode && !isApplyNowContentShowing) {
                if (!isErrorLineDisplayed) {
                    final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(getCurrentFocus(),
                            InputMethodManager.SHOW_IMPLICIT);
                    //QV Univ Migration -Start
                    if (!Utils.isRunningOnHandset(LoginActivity.this)) {
                        keyBoardStateVisible = true;
                    }
                }
                //QV Univ Migration -End

                //objApplication.setLoginKeyBoardStateVisible(true);
            }
        }
    }

    private void hideUIDLogin() {
        vLogin.setVisibility(View.GONE);
    }

    /**
     * Shows passcode login view.
     *
     * @return Current focused passcode view
     */
    private int showPasscodeLogin(boolean comingFromAnimation) {

        int result = fieldTVs.length - 1;
        isPasscodeLogin = true;
        if (comingFromAnimation) {
            vPasscode.startAnimation(passcodeFadeIn);
        } else {
            passcodeLinkLayout.setVisibility(View.VISIBLE);
            vPasscode.setVisibility(View.VISIBLE);
            result = getNextInput();
            // Set focus on target view
            fieldTVs[result].requestFocus();
            showKeyboard();

            if (!isCardLogin()) {
                // BankTrackingHelper.forceTrackPage(R.string.passcode_login);
                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        R.string.passcode_login);
            }
        }
        return result;
    }

    private void hidePasscodeLogin() {
        isPasscodeLogin = false;
        passcodeLinkLayout.setVisibility(View.INVISIBLE);
        vPasscode.setVisibility(View.INVISIBLE);
        passcodeLinkLayout.setTag(Integer.valueOf(-1));
    }

    /**
     * Shows passcode login hiding regular login when passcode login is active.
     * Shows regular login hiding passcode login when regular login is active.
     */
    private void displayActiveLoginMode(boolean comingFromAnimation) {
        if (isCardLogin() && isCardPasscodeLogin() && !isUserIDLogin) {
            hideUIDLogin();
            int focusedPasscode = showPasscodeLogin(comingFromAnimation);
            try {
                passcodeTokenClear = pUtils.getClearPasscodeToken();
            } catch (Exception e) {
                hidePasscodeLogInShowUserIdLogin(comingFromAnimation);
                // Defect 134258 FIX, move delete out of the below else into
                // this catch
                pUtils.deletePasscodeToken();
            }
        } else if (!isCardLogin() && isBankPasscodeLogin() && !isBankUserIDLogin) {
            hideUIDLogin();
            int focusedPasscode = showPasscodeLogin(comingFromAnimation);
            try {
                bankpasscodeTokenClear = bankpasscodeUtils
                        .getClearPasscodeToken();
            } catch (Exception e) {
                hidePasscodeLogInShowUserIdLogin(comingFromAnimation);
                // Defect 134258 FIX, move delete out of the below else into this catch
                bankpasscodeUtils.deletePasscodeToken();
            }
        } else {
            hidePasscodeLogInShowUserIdLogin(comingFromAnimation);
        }
    }

    private void hidePasscodeLogInShowUserIdLogin(boolean comingFromAnimation) {
        hidePasscodeLogin();
        showUIDLogin(comingFromAnimation);
    }

    private boolean isCardPasscodeLogin() {
		/*
		 * Changes start for Whats new reminder
		 */
        FacadeFactory.getWhatsNewReminderFacade().isAllowPasscodeAccess(
                this,
                isCardLogin() && pUtils.doesDeviceTokenExist()
                        && !isUserIDLogin);
		/*
		 * Changes End for Whats new reminder
		 */
        // hlin0 updated on 20140122 to account for passcode token encryption
        return isCardLogin() && pUtils.canDecryptPasscodeToken()
                && !isUserIDLogin;
    }

    private boolean isBankPasscodeLogin() {
		/*
		 * Changes start for Whats new reminder
		 */
        if (!isCardLogin() && bankpasscodeUtils.doesDeviceTokenExist()
                && !isBankUserIDLogin) {

            return !isCardLogin()
                    && bankpasscodeUtils.canDecryptPasscodeToken()
                    && !isBankUserIDLogin;
        }
        return false;
    }

    private void setupPasscode() {

        if (pUtils == null) {
            pUtils = new PasscodeUtils(this.getApplicationContext(), true);
        }
        pUtils.setForgotPasscode(false);
        if (bankpasscodeUtils == null) {
            bankpasscodeUtils = new PasscodeUtils(this.getApplicationContext(),
                    false);
        }
        bankpasscodeUtils.setForgotPasscode(false);
        setupPasscodeField(0);
        setupPasscodeField(1);
        setupPasscodeField(2);
        setupSubmit();
    }

    public void clearPasscodeFields() {
        for (final PasscodeCircularEditText fieldTV : fieldTVs) {
            if (!TextUtils.isEmpty(fieldTV.getText())) {
                clearField(fieldTV);
            }
        }
        //commented in 7.1 US36317
		/*if (isCardPasscodeLogin() || isBankPasscodeLogin()) {
			fieldTVs[0].requestFocus();
		}*/
    }

    // advances input to next field
    private TextView advanceInput(final int currentIndex) {
        if (currentIndex < fieldTVs.length - 1) {
            return fieldTVs[currentIndex + 1];
        } else if (currentIndex < 0) {
            return fieldTVs[0];
        } else {
            return fieldTVs[fieldTVs.length - 1];
        }
    }

    private boolean validatePasscodeField(final int paramInt) {
        advanceInput(paramInt).requestFocus();
        return true;
    }

    private int getNextInput() {
        for (int i = 0; i < fieldTVs.length; i++) {
            if (fieldTVs[i].length() == 0) {
                return i;
            }
        }
        return 0;
    }

    private void setupPasscodeField(final int fieldInt) {
        final PasscodeCircularEditText et = fieldTVs[fieldInt];
        //et.setOnKeyListener(new MyPasscodeKeyListener());
        et.setOnTouchListener(new PasscodeTouchListner(fieldInt));
        //et.setTransformationMethod(PasswordTransformationMethod.getInstance());
       /* et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (event != null
                        && event.getKeyCode() == KeyEvent.KEYCODE_DEL)
                        {
                   deleteLatestInput();
                }
                return false;
            }
        });*/

        et.addTextChangedListener(new TextWatcher() {
            // Logic to mask input and go to next item
            @Override
            public void afterTextChanged(final Editable paramAnonymousEditable) {
                validatePasscodeField(fieldInt);
            }

            // REQUIRED EVEN THOUGHT LEFT EMPTY
            @Override
            public void beforeTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }

            // REQUIRED EVEN THOUGHT LEFT EMPTY
            @Override
            public void onTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }
        });
    }

    private String getPasscodeString() {
        String retVal = "";
        for (final PasscodeCircularEditText fieldTV : fieldTVs) {
            retVal += fieldTV.getText();
        }
        return retVal;
    }

    private void setPasscodeString(String passcode) {
        if (passcode == null || passcode.length() == 0) {
            return;
        }
        for (int iCount = 0; iCount < passcode.length(); iCount++) {
            fieldTVs[iCount].setText(passcode.charAt(iCount) + "");
        }
    }

    private void setupSubmit() {
        final int fieldInt = 3;
        final PasscodeCircularEditText et = fieldTVs[fieldInt];
        // for hardware keys
        //et.setOnKeyListener(new MyPasscodeKeyListener());
        et.setOnTouchListener(new PasscodeTouchListner(fieldInt));
        //et.setTransformationMethod(PasswordTransformationMethod.getInstance());
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(final Editable paramAnonymousEditable) {
                if (isRestoreInstance) {
                    // DEFECT 110796 - don't fire login request during
                    // onRestoreInstanceState, this will result in duplicate
                    // request often during device rotation
                    return;
                }
                if (!validatePasscodeField(3)) {
                    return;
                }
                //commented in 7.1 US36317
                //fieldTVs[0].requestFocus();
                /**With fingerprint implementation now we are using common method for Pass-code Login & FP Login via Pass-code */
                callAccountServiceCallWithPasscode(false);
            }

            // REQUIRED EVEN THOUGHT LEFT EMPTY
            @Override
            public void beforeTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {
            }

            // REQUIRED EVEN THOUGHT LEFT EMPTY
            @Override
            public void onTextChanged(
                    final CharSequence paramAnonymousCharSequence,
                    final int paramAnonymousInt1, final int paramAnonymousInt2,
                    final int paramAnonymousInt3) {

                Globals.setOldTouchTimeInMillis(0);
            }

        });
    }

    /*
	 * Quick View Redesign Method to remove QuickView fragment with fade
	 * animation
	 * Do toggle based on toggle type from deeplink if require
	 */
    public void removeQuickViewFragmentWithAnimation(final String toggleType) {

        Animation pageDownAnimation = doQuickViewPageDownAnimation();


        pageDownAnimation.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {


            }

            @Override
            public void onAnimationRepeat(Animation animation) {


            }

            @Override
            public void onAnimationEnd(Animation animation) {

                if (Utils.isRunningOnHandset(LoginActivity.this)) {
                    versionAndPrivacyLayout.setVisibility(View.VISIBLE);
                    idPasswordView.setVisibility(View.VISIBLE);
                }
                //toggle bank/card based on deeplink type if required
                if (!toggleType.equals(StringUtility.EMPTY)) {
                    if (!isCardChecked && toggleType.equalsIgnoreCase("card")) {

                        checkCardToggle();
                        displayActiveLoginMode(false);
                    } else if (isCardChecked && toggleType.equalsIgnoreCase("bank")) {

                        checkBankToggle();
                        displayActiveLoginMode(false);
                    }
                }
            }
        });
        //QV Univ Migration -Start
        if (!Utils.isRunningOnHandset(LoginActivity.this)) {
            layoutQuickViewAnim.startAnimation(pageDownAnimation);
            //set focus to passcode field if quick view is enabled
            setFocusToPasscode();
            hideQuickViewPage(!isApplyNowContentShowing);
            //INC-9049232- start
            resetPasscodeViews();
        } else {

            fastcheckFragView.startAnimation(pageDownAnimation);
            hideQuickViewPage(true, true);
            //INC-9049232- start
            resetPasscodeViews();
        }
        //QV Univ Migration -End
    }

    //INC-9049232- start
    private void resetPasscodeViews() {
        if(Globals.isBankLoginSelected)
            for (int i = 0; i < fieldTVs.length; i++) {
                clearField(fieldTVs[i]);
                fieldTVs[i].clearFocus();
            }
    }


    // ********************************* END of PASSCODE calls
    // *****************************************
    // *************************************************************************************************

    /*
	 * Method to show keyboard
	 */
    private void showKeyboard() {
        //QV Univ Migration -Start
        if (Utils.isRunningOnHandset(LoginActivity.this)) {
            if (!objApplication.isLoginKeyBoardStateVisible()) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(getWindow().getCurrentFocus(), 0);
            }
        } else {
            if (!keyBoardStateVisible) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(getWindow().getCurrentFocus(), 0);
            }
        }
        //QV Univ Migration -End
    }

    /*
	 * Method to hide keyboard
	 */
    private void hideKeyboard() {
        //QV Univ Migration -Start
        if (!Utils.isRunningOnHandset(LoginActivity.this)) {
            if (keyBoardStateVisible) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus()
                        .getWindowToken(), 0);
            }
        } else {
            if (objApplication.isLoginKeyBoardStateVisible()) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus()
                        .getWindowToken(), 0);
            }
        }
        //QV Univ Migration -End
    }

    /*
	 * Show Quick View page
	 */
    private void showQuickViewPage() {
        if (DiscoverApplication.isInQuickViewMode) {

            getWindow()
                    .setSoftInputMode(
                            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            idField.setCursorVisible(false);
            if (Utils.isRunningOnHandset(LoginActivity.this)) {
                fastcheckFragView.setVisibility(View.VISIBLE);
                Fragment frag = getFragmentManager().findFragmentById(
                        R.id.fastcheck_frag);
                fastcheckFragView.startAnimation(doQuickViewPageUpAnimation());
                doLogoScaleAndTranslateAnimation(frag);

                versionAndPrivacyLayout.setVisibility(View.INVISIBLE);
                //ADA
                idPasswordView.setVisibility(View.INVISIBLE);
            } else {
                setQuickViewHeigh();
                getViewStartPoint();
                layoutQuickViewAnim.setVisibility(View.VISIBLE);
                Fragment frag = getFragmentManager().findFragmentById(
                        R.id.fastcheck_frag_tab);
                layoutQuickViewAnim.startAnimation(doQuickViewPageUpAnimation(frag));
            }

        } else {
            idField.setCursorVisible(true);
        }
    }

    /*
     * Hide Quick View Page
     */
    private void hideQuickViewPage(boolean isKeyboardRequired) {

        layoutQuickViewAnim.setVisibility(View.GONE);
        showQuickView = false;
        DiscoverApplication.isInQuickViewMode = false;

        if (isKeyboardRequired) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);


            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    showKeyboard();
                }
            }, 750);
        }


    }

    /*
	 * Hide Quick View Page
	 */
    private void hideQuickViewPage(boolean isLogoAnimRequired,
                                   boolean isKeyboardRequired) {

        if (isLogoAnimRequired) {
            doLogoScaleAndTranslateAnimationReverse();
        }
//CrashLytics #1517
        if(null!=fastcheckFragView)
        fastcheckFragView.setVisibility(View.GONE);

        showQuickView = false;
        DiscoverApplication.isInQuickViewMode = false;

        if (isKeyboardRequired) {
            getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    showKeyboard();
                }
            }, (QV_ANIM_DURATION + 50));
        }

        //set focus to password field while coming back from quickview page

//        if(idField.getText().toString().length()>0) {
//            passField.requestFocus();
//        }else{
//            idField.requestFocus();
//        }
    }

    /*
	 * Method to provide Quick view page up animation
	 */
    public Animation doQuickViewPageUpAnimation() {
        TranslateAnimation translateAnimation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, 1.0f,
                Animation.RELATIVE_TO_SELF, 0.0f);
        translateAnimation.setDuration(QV_ANIM_DURATION);

        return translateAnimation;
    }

    /*
     * Method to provide Quick view page up animation
     */
    public Animation doQuickViewPageUpAnimation(final Fragment frag) {
        TranslateAnimation translateAnimation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, 1.0f,
                Animation.RELATIVE_TO_SELF, 0.0f);
        translateAnimation.setDuration(QV_ANIM_UP_DURATION);

        translateAnimation.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation arg0) {
                //Refresh the quick view fragment
                FacadeFactory.getCardFacade().refreshFastcheckFragment(frag, LoginActivity.this);
            }

            @Override
            public void onAnimationRepeat(Animation arg0) {

            }

            @Override
            public void onAnimationEnd(Animation arg0) {

            }
        });

        return translateAnimation;
    }

    /*
	 * Quick View Redesign Method to provide Quick view page down animation
	 */
    public Animation doQuickViewPageDownAnimation() {
        TranslateAnimation translateAnimation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 1.0f);
        //QV Univ Migration -Start
        if (!Utils.isRunningOnHandset(LoginActivity.this)) {
            translateAnimation.setDuration(QV_ANIM_DOWN_DURATION);
        } else {
            translateAnimation.setDuration(QV_ANIM_DURATION);
        }
        //QV Univ Migration -End

        return translateAnimation;
    }

    /*
	 * Method to move up Disc Logo with scale and translate animation
	 */
    public void doLogoScaleAndTranslateAnimation(final Fragment frag) {

        if (DiscoverApplication.isInQuickViewMode) {

            // Transistion point calculation
            int emptyViewPos[] = new int[2];
            mEmptyView.getLocationOnScreen(emptyViewPos);

            // used QuickView top margin 60 dp for centering disc logo
            double logoAlignSpace = dpToPx(60f);

            double logoHeight = discoverLogo.getHeight();

            double finalTopMarginAfterAnim = (logoAlignSpace - logoHeight) / 2;

            transDist = (int) (mEmptyView.getHeight() - finalTopMarginAfterAnim);

            // Animation Starts
            AnimationSet animSet = new AnimationSet(true);

            ScaleAnimation scaleAnimation = new ScaleAnimation(1, (float) 0.65,
                    1, (float) 0.65, ScaleAnimation.RELATIVE_TO_SELF,
                    (float) (0.5), ScaleAnimation.RELATIVE_TO_SELF,
                    (float) (0.5));
            scaleAnimation.setDuration(QV_ANIM_DURATION);

            TranslateAnimation tranAnim = new TranslateAnimation(0, 0, 0,
                    -transDist);
            tranAnim.setDuration(QV_ANIM_DURATION);

            animSet.addAnimation(scaleAnimation);
            animSet.addAnimation(tranAnim);
            animSet.setFillAfter(true);

            animSet.setAnimationListener(new AnimationListener() {

                @Override
                public void onAnimationStart(Animation arg0) {
                    FacadeFactory.getCardFacade()
                            .refreshFastcheckFragment(frag, LoginActivity.this);
                }

                @Override
                public void onAnimationRepeat(Animation arg0) {

                }

                @Override
                public void onAnimationEnd(Animation arg0) {

                }
            });

            discoverLogo.startAnimation(animSet);

        }

    }

    /*
	 * Method to move down Disc Logo with scale and translate animation
	 */
    public void doLogoScaleAndTranslateAnimationReverse() {

        AnimationSet animSet = new AnimationSet(true);

        ScaleAnimation scaleAnimation = new ScaleAnimation((float) 0.65, 1,
                (float) 0.65, 1, ScaleAnimation.RELATIVE_TO_SELF,
                (float) (0.5), ScaleAnimation.RELATIVE_TO_SELF, (float) (0.5));
        scaleAnimation.setDuration(500);

        TranslateAnimation tranAnim = new TranslateAnimation(0, 0, -transDist,
                0);
        tranAnim.setDuration(500);

        animSet.addAnimation(scaleAnimation);
        animSet.addAnimation(tranAnim);
        animSet.setFillAfter(true);

        discoverLogo.startAnimation(animSet);
    }

    /*
	 * Method to convert dp to px
	 */
    private float dpToPx(float dp) {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float logicalDensity = metrics.density;
        return (float) Math.round(dp * logicalDensity);
    }

    /*
	 * Hide Quick View Page from QV Deeplink
	 */
    public void hideQuickView() {
        if (DiscoverApplication.isInQuickViewMode) {
            removeQuickViewFragmentWithAnimation(StringUtility.EMPTY);
        }
    }

    /*
	 * Hide Quick View Page from QV Deeplink based on deeplink type
	 *
	 */
    public void hideQuickViewWithToggleChange(String toggleType) {
        if (DiscoverApplication.isInQuickViewMode) {
            removeQuickViewFragmentWithAnimation(toggleType);
        }
    }

    private void showLongToast(String message) {
        if (message != null) {
            // idField.setTag("invalidAttempt");
            message = message.replace("$quot;", "\"");
            final String str = Html.fromHtml(message).toString();
            DiscoverActivityManager.getActiveActivity().runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(DiscoverActivityManager.getActiveActivity(), str, Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    /**
     * Method added for US79969 Remove / Show FP Modal on Logout from app
     */
    private void showLongToastWithDuration(String message, final long delayInMilliSeconds) {
        if (message != null) {
            message = message.replace("$quot;", "\"");
            final String str = Html.fromHtml(message).toString();
            DiscoverActivityManager.getActiveActivity().runOnUiThread(new Runnable() {
                public void run() {
                    final Toast toast = Toast.makeText(DiscoverActivityManager.getActiveActivity(), str, Toast.LENGTH_LONG);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (null != toast) {
                                toast.cancel();
                            }
//                            Log.d("sach_fp_modal", "showSessionExpired: Session is expired & checking for FP modal");
                            checkFingerprintAndInvokeModal();
                        }
                    }, delayInMilliSeconds);
                }
            });
        }
    }

    private void showShortToast(String message) {
        if (message != null) {
            // idField.setTag("invalidAttempt");
            message = message.replace("$quot;", "\"");
            final String str = Html.fromHtml(message).toString();
            DiscoverActivityManager.getActiveActivity().runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(DiscoverActivityManager.getActiveActivity(), str, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void showError() {
        {
            passField.getText().clear();
            mLoginButton.setVisibility(View.INVISIBLE);
            userIdLine.setBackgroundColor(getResources().getColor(R.color.red));
            userIdLine.setVisibility(View.VISIBLE);
            passFieldLine.setVisibility(View.INVISIBLE);
            clearPasscodeFields();
            /** Defect Fix 194756 **/
			/*
			 * passFieldLine.setBackgroundColor(getResources().getColor(R.color.red
			 * ));
			 */
			/* passFieldLine.setVisibility(View.VISIBLE); */
            /** Defect Fix 194756 **/

            rememberLayout.setVisibility(View.INVISIBLE);
            pwdRedBtn.setVisibility(View.VISIBLE);
            uidRedBtn.setVisibility(View.VISIBLE);
            //Globals.setRememberId(false);
            idField.setTag(null);

            hideKeyboard();

            isErrorLineDisplayed = true;

            // US37429 changes start
            passcodeLinkLayout.setVisibility(View.GONE);
            updateRegisterLinkLayout(this);
            // US37429 changes end
        }
    }

    private void hideError() {
        isErrorLineDisplayed = false;
        pwdRedBtn.setVisibility(View.INVISIBLE);
        uidRedBtn.setVisibility(View.INVISIBLE);
        userIdLine.setBackgroundColor(getResources().getColor(R.color.white));
        if (idField.getText().length() > 0) {
            rememberLayout.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Moves splash logo from center to top with scale down.
     */
    @SuppressLint("NewApi")
    private void moveLogoToUp(long startDelay) {

        long splashAnimDuration = (Long) Utils.getPreferenceValue(LoginActivity.this, "AnimationDelay", SPLASH_LOGO_SRINK_MOVE_DURATION, Type.LONG,"");

        //	Toast.makeText(LoginActivity.this, "Splash Duration::: "+splashAnimDuration, Toast.LENGTH_LONG).show();

        long splashStartAfter = startDelay;
        long contentStartAfter = splashStartAfter
                + splashAnimDuration / 2;

        TypedValue typedValue = new TypedValue();
        getResources().getValue(R.dimen.scale_animation_from_x_float_value, typedValue, true);
        float fromX = typedValue.getFloat();

        getResources().getValue(R.dimen.scale_animation_to_x_float_value, typedValue, true);
        float toX = typedValue.getFloat();

        getResources().getValue(R.dimen.scale_animation_from_y_float_value, typedValue, true);
        float fromY = typedValue.getFloat();

        getResources().getValue(R.dimen.scale_animation_to_7_float_value, typedValue, true);
        float toY = typedValue.getFloat();

        ScaleAnimation scaleAnimation = new ScaleAnimation(fromX, toX, fromY,
                toY, ScaleAnimation.RELATIVE_TO_SELF, (float) (0.5),
                ScaleAnimation.RELATIVE_TO_SELF, (float) (0.5));
        scaleAnimation.setDuration(splashAnimDuration);

        // Calculate height of screen where animation should starts from.
        int logoAnimationStartPosition = (int) getResources().getDimension(R.dimen.splash_logo_start_position);

        float startFrom = dpToPx(logoAnimationStartPosition) - mEmptyView.getHeight();
        TranslateAnimation tranAnim = new TranslateAnimation(0, 0, startFrom, 0);
        tranAnim.setDuration(splashAnimDuration);

        animSet.addAnimation(scaleAnimation);
        animSet.addAnimation(tranAnim);
        // animSet.setFillAfter(true);
        animSet.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }
        });
        animSet.setStartOffset(splashStartAfter);
        footerFadeIn.setStartOffset(contentStartAfter);
        versionFooterFadeIn.setStartOffset(contentStartAfter);
        loginFadeIn.setStartOffset(contentStartAfter);
        passcodeFadeIn.setStartOffset(contentStartAfter);
        discoverLogo.startAnimation(animSet);
        footer.startAnimation(footerFadeIn);
        versionAndPrivacyLayout.startAnimation(versionFooterFadeIn);
        // vLogin.startAnimation(loginFadeIn);
        vPasscode.setVisibility(View.INVISIBLE);
        displayActiveLoginMode(true);
        //fix for defect 203164 - STARt
        if (!isCardPasscodeLogin())
            loadSavedCredentials();
        //fix for defect 203164 - END
    }

    // START - Splash animation

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round((float) dp * density);
    }

    // END - Splash animation

    public void vibrateandShake() {
        Vibrator vibrate = (Vibrator) getApplicationContext().getSystemService(
                Context.VIBRATOR_SERVICE);
        vibrate.vibrate(100);
        clearPasscodeFields();

        Animation shake = AnimationUtils.loadAnimation(LoginActivity.this,
                R.anim.shake);
        for (int i = 0; i < fieldTVs.length; i++) {
            fieldTVs[i].startAnimation(shake);
        }
    }

    private void setFlickerSolverImageDimens() {
        // Set background height and width programatically.
        // Get device height and width and substarct height of status-bar and action bar.
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        // Statusbar height
        int statusBarHeight = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            statusBarHeight = getResources().getDimensionPixelSize(resourceId);
        }
        // Set height and width of image
        FrameLayout.LayoutParams param = new FrameLayout.LayoutParams(displayMetrics.widthPixels, (displayMetrics.heightPixels - statusBarHeight));
        //  ((ImageView) findViewById(R.id.login_flicker_solver_image)).setLayoutParams(param);
    }

    // US24487

    /**
     * Remember focus for UID or passcode fields. It sets 1 if focus on user, 2
     * if focus on password, 3+ on passcode fields. -1 for default that says
     * focus was not on any above views.
     */
    private void rememberFocus() {
        //Below if condition is added to avoid keyboard popup if quick view is enabled already
        if (!DiscoverApplication.isInQuickViewMode && !isApplyNowContentShowing) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        if (idField.hasFocus()) {
            objApplication.setFocusedView(1);
        } else if (passField.hasFocus()) {
            objApplication.setFocusedView(2);
        } else {
            // Dafault should be on user id
            objApplication.setFocusedView(1);
        }
    }

    /**
     * This method handles visiblity of forgot-password, register links etc. Visiblity
     * will depend on the availbale space to show these options. If these options can be partial
     * visible, this method will hide them.
     */
    private void handleVisibilityOfLoginSubOptions() {
        if (isCardPasscodeLogin() || isBankPasscodeLogin()) {
            float currentHeight = passcodeLoginSubOptions.getHeight();
            if (Float.compare(staticHeightOfPasscodeSubOptions, currentHeight) == 0) {
                passcodeLoginSubOptions.setVisibility(View.VISIBLE);

                /**start Added for US71607 Fingerprint login screen option */
//                checkVisibilityOfFPLink(); // Commented her as part of FP-Kill switch; added in other places
                /**end Added for US71607 Fingerprint login screen option */

            } else {
                passcodeLoginSubOptions.setVisibility(View.INVISIBLE);
            }
        } else {
            float currentHeight = loginSubOptions.getHeight();
            if (Float.compare(staticHeightOfUIDSubOptions, currentHeight) == 0) {
                loginSubOptions.setVisibility(View.VISIBLE);
            } else {
                loginSubOptions.setVisibility(View.INVISIBLE);
            }
        }
    }

    /**
     * Set Keyboard Input (Enter Key Login)
     */
    private void setKeyboardInput() {

        passField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null
                        && ((event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE))
                        && mLoginButton.getVisibility() == View.VISIBLE) {
                    //To avoid addition of Authorization Bearer with token value during login.

                    SessionTokenManager.clearToken();
                    executeLogin(mLoginButton);
                }
                return false;
            }
        });

    }

    // US37429 changes start - pkuma13
    private boolean isPasscodeEnabledOnThisDevice() {
        if (!isCardLogin() && bankpasscodeUtils.doesDeviceTokenExist()) {
            // Enabled on bank side
            return true;
        } else if (isCardLogin() && pUtils.doesDeviceTokenExist()) {
            // Enable on card side
            return true;
        }
        return false;
    }

    private void showPasscodeLoginViewAfterFirstLogin() {
        passcodeLinkLayout.setVisibility(View.VISIBLE);
        passcodeLinkLayout.setTag(Integer.valueOf(0));
    }

    private void showPasscodeInfoModal() {
        FragmentManager fm = getFragmentManager();
        PasscodeInfoDialogFragment dialogFragment = new PasscodeInfoDialogFragment();
        //CrashLytics # 1547
        if (!isFinishing()) {
            if (!isActivitysOnSaveInstanceStateCalled) {
                dialogFragment.show(fm, "passcode_info_dialog");
            }
        }
    }

    @Override
    public void doPositiveClick() {
        // US37429 changes start

        boolean isWizardShownAlready = new HFPref(this).getIsWizardShownAlready();
        if (!isWizardShownAlready) {
            new HFPref(this).setWizardShown(true);
        }

        Toast.makeText(this, getString(R.string.card_passcode_prelogin_modal_confirmation_toast), Toast.LENGTH_SHORT).show();
        if (isCardChecked)
            pUtils.setPasscodeSetupDeepLink(true);
            //US41219 changes start
        else
            //Function to set bank passcode deeplink
            setBankPasscodeDeeplink();
        //US41219 changes end
// changes done so that the focus is returned to the corresponding edittext and the keyboard is popped up - vpant -start
        int focusedViewWhenLeavingLogin = objApplication.getFocusedView();
        if (TextUtils.isEmpty(idField.getText()) && TextUtils.isEmpty(passField.getText())) {
            // If id field is empty, then it must have focus
            idField.setCursorVisible(true);
            passField.setCursorVisible(true);
            idField.requestFocus();
        } else {
            if (focusedViewWhenLeavingLogin == 1) {
                idField.setCursorVisible(true);
                passField.setCursorVisible(true);
                // Set focus on uid
                idField.requestFocus();
                idField.setSelection(idField.getText().length());
                objApplication.resetFocusedView();
            } else if (focusedViewWhenLeavingLogin == 2) {
                idField.setCursorVisible(true);
                passField.setCursorVisible(true);
                passField.requestFocus();
                passField.setSelection(passField.getText().length());
                objApplication.resetFocusedView();
            }
        }

        // changes done so that the focus is returned to the corresponding edittext and the keyboard is popped up - vpant -end


        // US37429 changes end
    }

    //US41219 changes start
    //Function to set the bank passcode deeplink when passcode login is enabled
    private void setBankPasscodeDeeplink() {
        Bundle deepLink = new Bundle();
        deepLink.putString("DEEP_LINK", getString(R.string.deeplink_value_passcode));
        deepLink.putBoolean("FLAG", true);

        //set the pass code deeplink values
        FacadeFactory.getBankLoginFacade().setDeepLinkToast(deepLink, this);
    }

    @Override
    public void doNegativeClick() {
        // US37429 changes start
        if (isCardChecked)
            pUtils.setPasscodeSetupDeepLink(false);
// changes done so that the focus is returned to the corresponding edittext and the keyboard is popped up - vpant -start
        int focusedViewWhenLeavingLogin = objApplication.getFocusedView();
        if (TextUtils.isEmpty(idField.getText()) && TextUtils.isEmpty(passField.getText())) {
            // If id field is empty, then it must have focus
            idField.setCursorVisible(true);
            passField.setCursorVisible(true);
            idField.requestFocus();
        } else {
            if (focusedViewWhenLeavingLogin == 1) {
                idField.setCursorVisible(true);
                passField.setCursorVisible(true);
                // Set focus on uid
                idField.requestFocus();
                idField.setSelection(idField.getText().length());
                objApplication.resetFocusedView();
            } else if (focusedViewWhenLeavingLogin == 2) {
                idField.setCursorVisible(true);
                passField.setCursorVisible(true);
                passField.requestFocus();
                passField.setSelection(passField.getText().length());
                objApplication.resetFocusedView();
            }
        }
        // changes done so that the focus is returned to the corresponding edittext and the keyboard is popped up - vpant -end
        // US37429 changes end
        // Toast.makeText(this, "Clicked on CANCEL", Toast.LENGTH_SHORT).show();
    }

    /**
     * Reset Passcode and register link form modals which are being shown from helper classes.
     */
    public void resetRegisterAndPasscodeLink() {
        if ((registerLinkLayout != null) && (passcodeLinkLayout != null)) {
            passcodeLinkLayout.setVisibility(View.GONE);
            updateRegisterLinkLayout(this);
        }
    }
    //US41219 changes end

    //224166- start
    public void resetFocus() {
        fieldTVs[0].requestFocus();
    }
    // US37429 changes end - pkuma13

    public void goBack() {
        // TODO Auto-generated method stub
    }

    //QuickView Migration
     /*
     * Method to calculate Quick view height
     */
    private void setQuickViewHeigh() {


        final int rootViewHeight = activityRootView.getRootView().getHeight();

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        final FrameLayout.LayoutParams qvLayoutParam = (FrameLayout.LayoutParams) fastcheck_frag_tab.getLayoutParams();
        if (dm.heightPixels > dm.widthPixels) {
            qvLayoutParam.height = (int) (rootViewHeight * (0.44));
        } else {
            qvLayoutParam.height = (int) (rootViewHeight * (0.63));
        }

    }
    //224166-end

    /*
   * Method to initialize the quickview page
   * Defect:202571
   */
    private void initQuickViewPage() {

        if (layoutQuickViewAnim != null) {
            layoutQuickViewAnim.post(new Runnable() {

                @Override
                public void run() {

                    //set focus to passcode field if quick view is enabled
                    setFocusToPasscode();

                    Fragment frag = getFragmentManager().findFragmentById(
                            R.id.fastcheck_frag_tab);

                    if (frag != null) {

                        boolean isQuickViewEnabled = FacadeFactory.getCardFacade()
                                .getQuickViewEnabledState(frag, LoginActivity.this);

                        if ((DiscoverApplication.isInQuickViewMode || (!doMaintainQVState && isQuickViewEnabled)) && !(FacadeFactory.getCardLoginFacade().getQvAnimationKillSwitch())) {

                            //check keyboard visibility
                            if (keyBoardStateVisible) {

                                initQVTimeDelay = 700;
                            }

                            DiscoverApplication.isInQuickViewMode = true;


                            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);


                            new Handler().postDelayed(new Runnable() {

                                @Override
                                public void run() {

                                    versionAndPrivacyLayout.setVisibility(View.VISIBLE);

                                    footer.setVisibility(View.VISIBLE);

                                    showQuickViewPage();

                                }
                            }, initQVTimeDelay);
                        } else {
                            if (DiscoverApplication.isInQuickViewMode && doMaintainQVState) {
                                showQuickViewPage();
                            } else {
                                hideQuickView();
                            }
                            //  hideQuickView();
                        }

                        if (!DiscoverApplication.isInQuickViewMode && !isApplyNowContentShowing) {
                            //Below line has been added to fix 229050 issue
                            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

                            hideQuickViewPage(false);
                        }/*else{

                            getWindow()
                                    .setSoftInputMode(
                                            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

                    }*/
                    }
                }
            });
        }
    }

    /*
         * Method to set focus to passcode field if quick view enabled
         * Defect:201487,202952
         */
    private void setFocusToPasscode() {
        if (fieldTVs[0] != null) {
            if (isCardPasscodeLogin() || isBankPasscodeLogin()) {
                int focusInt = getNextInput();
                if (focusInt == 0) {
                    fieldTVs[0].requestFocus();
                }
            }
        }
    }

    /*
     * Quick view Redesign
     * Method to get start Point of rootview and quickview frag
     * for swipe to close function.
     */
    public void getViewStartPoint() {
        activityRootView.post(new Runnable() {

            @Override
            public void run() {

                int[] rootStartPos = new int[2];
                activityRootView.getLocationOnScreen(rootStartPos);

                int[] arcStartPos = new int[2];
                fastcheck_frag_tab.getLocationOnScreen(arcStartPos);


                rootViewStartPoint = rootStartPos[1];
                qvArcImgStartPoint = arcStartPos[1];

//                Log.d("rootViewStartPoint** :: ", rootViewStartPoint + "");
//                Log.d("qvArcImgStartPoint** :: ", qvArcImgStartPoint + "");

            }
        });
    }

    /**
     * Function to invoke the Universal upgrade modal  - for  US43357 vpant
     *
     * @param title     - title of the modal
     * @param message   - message in the modal
     * @param firstBtn  - text of the first button on the modal
     * @param secondBtn - text of the second button, if it exists, in the modal
     */
    public void invokeModalForUniversalConversion(final InfoJsonData infoJsonData) {

        String firstBtnText = null, secondBtnText = null, errorTitle = null, errorMesssage = null;
        Log.d("Universal", "dialog open");
        switch (mUpgrade_type) {
            case HARD_UPGRADE:

                secondBtnText = null;
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);

                errorTitle = infoJsonData.getUniversalData().getHardUpgradeMessage_T();

                if (!doesPackageExists(infoJsonData.getUniversalData().getUniAppPackage())) {
                    firstBtnText = infoJsonData.getUniversalData().getUpgradeBtnLable();
                    errorMesssage = infoJsonData.getUniversalData().getHardUpgradeMessage();

                } else {
                    firstBtnText = infoJsonData.getUniversalData().getUninstallBtnLable();
                    errorMesssage = infoJsonData.getUniversalData().getUninstallMessage();
                }
                break;

            case SOFT_UPGRADE:

                errorTitle = infoJsonData.getUniversalData().getSoftUpgradeMessage_T();

                if (!doesPackageExists(infoJsonData.getUniversalData().getUniAppPackage())) {
                    firstBtnText = infoJsonData.getUniversalData().getUpgradeBtnLable();
                    errorMesssage = infoJsonData.getUniversalData().getSoftUpgradeMessage();
                    secondBtnText = infoJsonData.getUniversalData().getCancelBtnLable();

                } else {
                    firstBtnText = infoJsonData.getUniversalData().getUninstallBtnLable();
                    errorMesssage = infoJsonData.getUniversalData().getUninstallMessage();
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
                    secondBtnText = null;
                }
                setTimesStampWhenUniversalUpgradeModalWasInvoked();
                break;


        }
        android.app.FragmentManager fm = getFragmentManager();
        final UniversalAppUpgradeButtonModal dialogFragment = new UniversalAppUpgradeButtonModal(errorTitle,
                errorMesssage,
                firstBtnText, secondBtnText,
                new UniversalAppUpgradeButtonModal.TwoButtonDialogListener() {
                    @Override
                    public void doPositiveClick() {
                        final String appPackageName = infoJsonData.getUniversalData().getUniAppPackage();
                        copyAllUserPreferenceData(getApplicationContext());
                        handleAppForUniversalConversion(appPackageName);
                    }

                    @Override
                    public void doNegativeClick() {


                    }
                });


        if (null == secondBtnText)
            dialogFragment.setCancelable(false);

        //Crash issue.
        try {
            dialogFragment.show(fm, "dialog");
        } catch (Exception e) {
            Log.e(TAG, "Exception");
        }

    }

    private void copyAllUserPreferenceData(Context context) {
        try {
            File prefsdir = new File(context.getApplicationInfo().dataDir, "shared_prefs");
            //create directory to write the preference file name & Json file - check if the SD card is mounted
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/discover_logs");
            dir.mkdirs();

            String gsonConvertedString = null;

            if (prefsdir.exists() && prefsdir.isDirectory()) {
                //get all the preference from the pref directory.
                String[] list = prefsdir.list();
                Map<String, Object> userPreferncesMap = new HashMap<String, Object>();

                for (String item : list) {
                    //remove .xml from the file name
                    String prefFile = item.substring(0, item.length() - 4);
                    SharedPreferences sp2 = context.getSharedPreferences(prefFile, Context.MODE_PRIVATE);
                    //get all the key-value pairs from the preference file
                    Map<String, ?> prefDataMap = sp2.getAll();
                    userPreferncesMap.put(prefFile, prefDataMap);
                }

                Gson gson = new GsonBuilder().disableHtmlEscaping().create();
                gsonConvertedString = gson.toJson(userPreferncesMap);

            }
            String key = "d1sC0verBu!ld123";
            Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            // encrypt the text
            cipher.init(Cipher.ENCRYPT_MODE, aesKey);

            //write the json content to a txt file
            File file = new File(dir, "dump.txt");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(new String(Base64.encode(cipher.doFinal(gsonConvertedString.getBytes()), Base64.DEFAULT)).getBytes());
            fos.close();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     * function to get what needs to be done for universal upgrade
     * 1. Go to the playstore if the handset build does not exist.
     * 2. Uninstall the tablet build if the required handset build is installed in the device
     * - for  US43357 vpant
     *
     * @param packageName - required paclage name
     */
    public void handleAppForUniversalConversion(String packageName)

    {
        if (doesPackageExists(packageName))

        {
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.discoverfinancial.mobile");
            startActivity(launchIntent);

            finish();
        } else {

            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName)));
            finish();

        }


    }

    /**
     * Function to find whether the package exists in the device  - for  US43357 vpant
     *
     * @param targetPackage - the package to find out
     * @return - boolean value whether the package exists or not
     */
    public boolean doesPackageExists(String targetPackage) {
        List<ApplicationInfo> packages;
        PackageManager pm;

        pm = getPackageManager();
        packages = pm.getInstalledApplications(0);
        for (ApplicationInfo packageInfo : packages) {
            if (packageInfo.packageName.equals(targetPackage))
                return true;
        }
        return false;
    }

    /**
     * Function to set  the recorded timestamp (the time stamp of the last time when the dialog was
     * created.- for  US43357 vpant
     *
     * @return get the stored timestamp
     */
    public void setTimesStampWhenUniversalUpgradeModalWasInvoked() {
        Date date = new Date(System.currentTimeMillis()); //or simply new Date();
        SharedPreferences timeStampSharedPref = getSharedPreferences(UNIVERSAL_INVOCATION_DIALOG, Context.MODE_PRIVATE);
        Editor timeStampSharedPrefEditor = timeStampSharedPref.edit();
        timeStampSharedPrefEditor.putLong(TIMESTAMP_KEY, date.getTime());
    }

    /**
     * Function to get the recorded timestamp (the time stamp of the last time when the dialog was
     * created.- for  US43357 vpant
     *
     * @return get the stored timestamp
     */
    public long getTimesStampWhenUniversalUpgradeModalWasInvoked() {
        SharedPreferences timeStampSharedPref = getSharedPreferences(UNIVERSAL_INVOCATION_DIALOG,
                Context.MODE_PRIVATE);
        Date recordedDate = new Date(timeStampSharedPref.getLong(TIMESTAMP_KEY, -1));

        return timeStampSharedPref.getLong(TIMESTAMP_KEY, -1);

    }

    /**
     * Function to get the the current time to compare with time the last time the dialog
     * appeared.-
     * for  US43357 vpant
     *
     * @return the current timestamp
     */
    public long getCurrentTimeStamp() {

        // Date currDate  = new Date(System.currentTimeMillis());
        return System.currentTimeMillis();
    }
    //US41219 changes end

    /**
     * Function to find the days since the last time dialog appeared  - for  US43357 vpant
     *
     * @return - the no of days.
     */
    public int findDiffinDays(long currentTimeStamp, long recordedTimeStamp) {


        if (recordedTimeStamp < 0)
            return -1;

        Date currentDate = new Date(currentTimeStamp);
        Date recordedDate = new Date(currentTimeStamp);
        int days = currentDate.compareTo(recordedDate);
        return days;
    }
    // changes done so that the focus is returned to the corresponding edittext and the keyboard is popped up - vpant -end
    // US37429 changes end - pkuma13

    /**
     *  * US50938:
     *  * if the user has cancel all the Bank accounts (having only card accounts)
     *  * and try to login with his\her Bank credentials,
     *  * then that user should redirect to card page with auto retry-login
     *  
     */

    public void redirectToCardLogin() {

        checkCardToggle();
        runAuthWithUsernameAndPassword(Globals.getUserName(), Globals.getPassword());

    }

    //Passcode login  merge error scenario
    public void redirectToPasscodeLogin(final String errorMessage) {

        showErrorMessage(errorMessage);
        displayActiveLoginMode(false);
    }

    /**
     * Added for US50152 Prevent Joint Card Toggle login
     * If user has bank accounts & all card accounts are closed & no remaining open card account
     * then redirect user to Bank side (auto login)
     */
    public void redirectToBankLogin(String userName, String password, Boolean isPasscodeLogin) {
        checkBankToggle();
        FacadeFactory.getBankLoginFacade().bankLogin(userName, password,
                isPasscodeLogin);
    }

    /**
     * Sends the user to the Google Play page for the Discover app. Used when a
     * user wants or needs to upgrade their application.
     */
    protected void upgrade(final Context context, final String redirectUrl) {
        final Uri marketUri = redirectUrl == null ? Uri.parse("market://details?id=" + PACKAGE_NAME) : Uri.parse(redirectUrl);
        final Intent androidMarketplaceIntent = new Intent(Intent.ACTION_VIEW,
                marketUri);
        ((LoginActivity) context)
                .startActivity(androidMarketplaceIntent);
    }

    /**
     * showForcedUpgradeAlertDialog() This method, when called, shows an alert
     * dialog with the forced upgrade text. This dialog needs to prevent the
     * user from using the application. If the user chooses upgrade, they are
     * directed to the Google Play store page for the Discover application. If
     * the user cancels the dialog by pressing the back button or otherwise, the
     * application is force quit.
     */

    public void showForcedUpgradeAlertDialog(
            final Context context, final String title, final String message, final String buttonText, final String redirectUrl) {
//        final Context context = errorHandlerUi.getContext();

        SimpleContentModal modal = new SimpleContentModal(context, title, message, buttonText);
//        final SimpleContentModal modal = new SimpleContentModal(LoginActivity.this,title,message,buttonText);
        modal.onBackPressed();
        modal.hideNeedHelpFooter();
        modal.getButton().setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View v) {
                upgrade(context, redirectUrl);
            }
        });
        modal.setButtonText(buttonText);
        if (buttonText == null || buttonText.equals("")) {
            modal.setButtonText(context.getResources().getString(R.string.upgrade_dialog_button_text));
        }
        modal.setTitle(title);
        if (title == null || title.equals("")) {
            modal.setButtonText(context.getResources().getString(R.string.forced_upgrade_dialog_title));
        }
        modal.setContent(message);
        modal.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(final DialogInterface dialog) {
                if (context instanceof Activity && !((Activity) context).isFinishing()) {
                    ((Activity) context)
                            .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
                }
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        });
        modal.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                if (context instanceof Activity && !((Activity) context).isFinishing()) {
                    ((Activity) context)
                            .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
                }
            }
        });
        /**start fix for Defect 247248 - US66796*/
        modal.requestWindowFeature(Window.FEATURE_NO_TITLE);
        modal.show();
        modal.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        /**end fix for Defect 247248 - US66796*/

        if (context instanceof Activity) {
            ((Activity) context).setRequestedOrientation(Utils.getScreenOrientation((Activity) context));
        }
        if(fingerPrintDialog!=null) {

                fingerPrintDialog.dismiss();
        }
    }

    /**
     * Method to enable - disable fingerprint link
     * Added for US71607 Fingerprint login screen option
     */
    private void enableDisableFPLink(boolean isEnable) {
        if (null != fingerPrintLoginLabel) {
            if (isEnable && (fingerPrintLoginLabel.getVisibility() == View.GONE)) { // As we are changing layout parameters, we need this condition to avoid going into infinite loop via handleVisibilityOfLoginSubOptions
                fingerPrintLoginLabel.setVisibility(View.VISIBLE);
                fingerPrintLoginLabel.setOnClickListener(this);
                final RelativeLayout.LayoutParams userIDLayoutParams = (RelativeLayout.LayoutParams) passcodeUserIdLogin.getLayoutParams();
                userIDLayoutParams.addRule(RelativeLayout.CENTER_HORIZONTAL, 0);
                userIDLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
                passcodeUserIdLogin.setLayoutParams(userIDLayoutParams);
            } else {

                RelativeLayout.LayoutParams userIDLayoutParams1 = (RelativeLayout.LayoutParams) passcodeUserIdLogin.getLayoutParams();
                int[] userIDLayoutRules = userIDLayoutParams1.getRules();
                boolean isUserIDViewAlignedParentLeft = false;
                try {
                    if (RelativeLayout.TRUE == userIDLayoutRules[RelativeLayout.ALIGN_PARENT_LEFT]) {
                        isUserIDViewAlignedParentLeft = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    isUserIDViewAlignedParentLeft = false;
                }

                if (!isEnable && isUserIDViewAlignedParentLeft) {

                    fingerPrintLoginLabel.setVisibility(View.GONE);
                    final RelativeLayout.LayoutParams userIDLayoutParams = (RelativeLayout.LayoutParams) passcodeUserIdLogin.getLayoutParams();
                    userIDLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT, 0);
                    userIDLayoutParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
                    passcodeUserIdLogin.setLayoutParams(userIDLayoutParams);
                }
            }
        }
    }

    /**
     * Method to show fingerprint modal
     * Device should have fingerprint sensor to use this modal
     * Added for US71513 - fingerprint login modal
     */
    public void showFingerprintDialog() {
        //Start: US72282: FingerPrint Analytics
        if (Globals.isBankLoginSelected)
            FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_LOGIN_MODAL_PG);
        else
        // End: US72282: FingerPrint Analytics

        /**Start Changes for US71879: Fingerpeint Site Catalyst Tags*/
            //On the page load of Fp model
            TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_LOGIN_MODAL_PG);
        /**End Changes for US71879: Fingerpeint Site Catalyst Tags*/

        initFingerPrintDialog();

        if (!fingerPrintDialog.isAdded()) {
            if (!isActivitysOnSaveInstanceStateCalled) {
                //Fix for crashLytics #1160
                if (!Utils.isActivityFinishingOrDestroyed(DiscoverActivityManager.getActiveActivity())) {
                    try {
                        fingerPrintDialog.show(DiscoverActivityManager.getActiveActivity().getFragmentManager(), FingerPrintDialog.class.getSimpleName());
                    } catch (IllegalStateException e) {
                        e.printStackTrace();
                    }

                }
            }
        }
    }


    /*
        Initializing FingerPrintDialog
     */
    private void initFingerPrintDialog(){
        //crashlytics fix 1524
        fingerPrintDialog = (FingerPrintDialog) getFragmentManager().findFragmentByTag(FingerPrintDialog.class.getSimpleName());
        if (fingerPrintDialog == null) {
            fingerPrintDialog = new FingerPrintDialog();
        }
        fingerPrintDialog.setCancelAction(new FingerPrintDialogActionListener() {
            @Override
            public void handleCancelAction() {
                if(fieldTVs[0] != null)
                    fieldTVs[0].requestFocus();

                /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                int fpScanningFailedCount = fingerPrintUtils.getFPScanningFailedCount();
                if (fpScanningFailedCount != 0 && fpScanningFailedCount <= FingerPrintUtils.FP_SCANNING_MAX_FAILED_COUNT && isFpTouchSensorClick) {
                    //Start: US72282: FingerPrint Analytics
                    if(Globals.isBankLoginSelected){
                        HashMap<String, Object> extras= FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                        extras.put(AnalyticsPage.PROP1,AnalyticsPage.FINGER_PRINT_NOT_RECOGNIZED_MODAL_CANCEL_LNK);
                        TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_NOT_RECOGNIZED_MODAL_CANCEL_LNK ,null, AnalyticsPage.LINK_TYPE_O,extras);
                    }
                    else {
                    //End: US72282: FingerPrint Analytics
                        //On the click of Cancel after the FIRST attempt logging in via Finger print link
                        HashMap<String, Object> extras = new HashMap<String, Object>();
                        extras.put(LoginActivity.this.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_NOT_RECOGNIZED_MODAL_CANCEL_LNK);
                        TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_NOT_RECOGNIZED_MODAL_CANCEL_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                    }
                    isFpTouchSensorClick = false;

                } else {
                    //Start: US72282: FingerPrint Analytics
                    if (Globals.isBankLoginSelected) {
                        HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                        extras.put(AnalyticsPage.PROP1, AnalyticsPage.FINGER_PRINT_MODAL_CANCEL_LNK);
                        TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_MODAL_CANCEL_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                    } else {
                    //End:  US72282: FingerPrint Analytics
                        /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                        //On the click of Cancel link
                        HashMap<String, Object> extras = new HashMap<String, Object>();
                        extras.put(LoginActivity.this.getResources().getString(R.string.prop1), AnalyticsPage.FINGER_PRINT_MODAL_CANCEL_LNK);
                        TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_MODAL_CANCEL_LNK, null, AnalyticsPage.LINK_TYPE_O, extras);
                        /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                    }
                }
                /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                //Added if check - to fix CrashLytics defect 433_441_337
                if (!isFinishing() && null != fingerPrintDialog && fingerPrintDialog.isAdded()) {
                    fingerPrintDialog.dismissAllowingStateLoss();
                }
            }
        });
    }

    @Override
    public void onAuthenticated() {
        //On successful authentication of fingerprint reset fail count for FP scanning
        if (null == fingerPrintUtils)
            fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
        fingerPrintUtils.resetFPScanningFailedCount();
        isFpTouchSensorClick = true;
        callAccountServiceCallWithPasscode(true);
    }

    /**
     * Method to call - Account service call after finger print authentication
     * added for 7.10 finger print release
     */
    private void callAccountServiceCallWithPasscode(final boolean isFingerPrintLogin) {

        //To avoid addition of Authorization Bearer with token value during login.
        SessionTokenManager.clearToken();

        if (isCardLogin()) {
            NetworkRequestListener passcodeNetworkRequestListener = new NetworkRequestListener() {

                @Override
                public void onSuccess(Object data) {
                    /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                    if(isFingerPrintLogin)
                        FingerPrintUtils.trackFpSuccessAnalyticsTag();
                    /**End Changes for US71879: Fingerprint Site Catalyst Tags*/

                    final boolean is16DigitLogin = InputValidator.isCardAccountNumberValid(username);
                    // sequence changed for US38219 CLA merge intercept page
                    final AccountV2Details portalAccountDetails = PortalCacheDataUtils
                            .getPortalCacheDataUtilsInstance()
                            .getAccountV2Details();
                    if (is16DigitLogin) {
                        if (portalAccountDetails.isUserIdAvailable()) {

                            idField.getText().clear();
                            showError();
                            showLongToast(getResources().getString(R.string.invalid_user_id));

                        } else {
                            FacadeFactory.getCardFacade().navToCreateUserID(LoginActivity.this);
                            PortalUtils.hideSpinner(LoginActivity.this);
                        }
                    } /** start Added for US38219 CLA merge intercept page */
                    else if (portalAccountDetails.isMergeEligible() && !PortalUtils.isDeepLink() && !PortalUtils.isPushDeepLink(LoginActivity.this)) {

                        // US126324 Changes - start
                        PortalUtils.navToPortalMergeInterceptPage(portalAccountDetails.getCustomerFirstName(), portalAccountDetails.isForceMerge(),
                                portalAccountDetails.isInitialSkipAttempt());
                        // US126324 Changes - end
                        /** end Added for US38219 CLA merge intercept page */
                    } else {
                        if (PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getIfPortalPageShown()) {
                            //Deep link for a single card and sso user. - US28600
                            SharedPreferences pushSharedPrefs = LoginActivity.this.getSharedPreferences("PUSH_PREF", Context.MODE_PRIVATE);
                            boolean isPushDeepLink = pushSharedPrefs.getBoolean("pushOffline", false);

                            if (Globals.isSSOUser && portalAccountDetails.getCardAccountsMap().size() == 1
                                    && (FacadeFactory.getWDAFacade().isDeepLink(DiscoverActivityManager.getActiveActivity(), null) || isPushDeepLink)) {
                                String key = (String) portalAccountDetails.getCardAccountsMap().keySet().toArray()[0];
                                // Update account detail changes
                                PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setSelectedAccKey(key);
                                FacadeFactory.getPortalPageFacade().navToCardHome(getContext(), key);

                                if (isPushDeepLink) {
                                    Editor editor = pushSharedPrefs.edit();
                                    editor.putBoolean("pushOffline", false);
                                    editor.commit();
                                }

                            } else {
                                // US45209 Changes Starts
                                if (HFUtils.shouldShowSSOWhatsNew(LoginActivity.this)) {
                                    HFUtils.showSSOWhatsNew(LoginActivity.this);
                                } else {
                                    PortalUtils.navToPortalActivity();
                                }
                                // US45209 Changes ends
                            }
                        } else {
                            if(portalAccountDetails
                                    .getCardAccountsMap().keySet().toArray().length>0) {
                                String key = (String) portalAccountDetails
                                        .getCardAccountsMap().keySet().toArray()[0];
                                // Update account detail changes
                                PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setSelectedAccKey(key);
                                FacadeFactory.getPortalPageFacade().navToCardHome(
                                        getContext(), key);
                            }else{
                                try {
                                    final DiscoverAlertDialog discoverAlertDialog = new DiscoverAlertDialog();
                                          discoverAlertDialog.setTitle(getString(R.string.default_outage_header))
                                                .setMessage(getString(R.string.temporary_outage))
                                                .setPositiveButton("Close",
                                                        new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View v) {
                                                                if(discoverAlertDialog!=null && discoverAlertDialog.isVisible())
                                                                    discoverAlertDialog.dismiss();
                                                                FacadeFactory.getCardLogoutFacade().logout(
                                                                        LoginActivity.this, false, false);
                                                            }
                                                        }
                                                )
                                                .setCanceledOnTouchOutside(false)
                                                .setCanCancelable(false)
                                                .show(LoginActivity.this);

                                } catch (Exception e) {
                                        e.printStackTrace();
                                }
                            }
                        }
                    }
                }

                @Override
                public void onError(Object data) {

                    FacadeFactory.getPortalPageFacade().handleErrorScenario(LoginActivity.this, data);
                    //added in 7.1 US36317
                    fieldTVs[0].post(new Runnable() {
                        public void run() {
                            fieldTVs[0].requestFocus();
                        }
                    });
                }
            };

            /**start Added for US71607 Fingerprint login screen option */
            String passcode = "";

            if (isFingerPrintLogin) {
                if (null == fingerPrintUtils)
                    fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
                passcode = fingerPrintUtils.getPasscodeFingerPrint();
            } else {
                passcode = getPasscodeString();
            }
            /**end Added for US71607 Fingerprint login screen option */

            if(Globals.isSSOUser())
                User.getInstance().setPasscodeToken(passcode);


            clearPasscodeFields();
            if (!TextUtils.isEmpty(passcode)) {
                SessionCookieManager coockieManager = SessionCookieManager.getInstance();
                cookieManagerProxy = (CookieManagerProxy) coockieManager.getCookieManager();
                cookieManagerProxy.clearAllCookies();

                //Passcode defect fixing - 16.4
                try {
                    passcodeTokenClear = pUtils.getClearPasscodeToken();
                } catch (Exception e) {
                    hidePasscodeLogInShowUserIdLogin(false);
                    // Defect 134258 FIX, move delete out of the below else into
                    // this catch
                    pUtils.deletePasscodeToken();
                }
                PortalUtils.getPortalAccountDetails(LoginActivity.this, passcodeTokenClear, passcode, passcodeNetworkRequestListener, true, isFingerPrintLogin);
                User.getInstance().setPasscodeToken(passcode);
            }
        } else {

            /**start Added for US71607 Fingerprint login screen option */
            String passcode = "";
            //Start: US72282: FingerPrint Analytics
            Globals.isBankFingerprintLogin=isFingerPrintLogin;
            //End: US72282: FingerPrint Analytics

            if (isFingerPrintLogin) {
                if (null == fingerPrintUtils)
                    fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);
                passcode = fingerPrintUtils.getPasscodeFingerPrint();
            } else {
                passcode = getPasscodeString();
            }
            /**end Added for US71607 Fingerprint login screen option */

            if(Globals.isSSOUser())
                User.getInstance().setPasscodeToken(passcode);

            clearPasscodeFields();
            if (!TextUtils.isEmpty(passcode)) {
                User.getInstance().setPasscodeToken(passcode);
                try {
                            /*Defect Id: 244146*/
                    bankpasscodeTokenClear = bankpasscodeUtils
                            .getClearPasscodeToken();
                    FacadeFactory.getBankLoginFacade().createPasscodeLogin(
                            bankpasscodeTokenClear, passcode);
                } catch (Exception e) {
                    hidePasscodeLogInShowUserIdLogin(false);
                    bankpasscodeUtils.deletePasscodeToken();
                }
            }
        }
    }



    @Override
    public void onAuthenticationHelp(String helpString) {

    }

    @Override
    public void onError(String errMessage) {

        if (null == fingerPrintUtils)
            fingerPrintUtils = new FingerPrintUtils(LoginActivity.this);

        int fpScanningFailedCount = fingerPrintUtils.getFPScanningFailedCount();

        // Increment count & store it
        fpScanningFailedCount += 1;
        fingerPrintUtils.setFPScanningFailedCount(fpScanningFailedCount);
        isFpTouchSensorClick=true;
        // check max failed count & take action
        if (fpScanningFailedCount >= FingerPrintUtils.FP_SCANNING_MAX_FAILED_COUNT) {

            fingerPrintUtils.removeFingerprintPasscode();
            fingerPrintUtils.resetProfileSettingFingerPrintStatus();
            if (null != fingerPrintDialog && fingerPrintDialog.isAdded()) {
                fingerPrintDialog.dismissAllowingStateLoss();
            }
            /**Start changes for US79223*/
            Toast fpScanningFailedToast = Toast.makeText(LoginActivity.this, getString(R.string.fp_scanning_max_failed_attempt_message), Toast.LENGTH_SHORT);
            fpScanningFailedToast.setGravity(Gravity.CENTER, 0, 0);
            fpScanningFailedToast.show();
            /**End changes for US79223*/

            //Start: US72282: FingerPrint Analytics
            if(Globals.isBankLoginSelected) {
                HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
                extras.put(AnalyticsPage.CONTEXT_MY_EVENTS, AnalyticsPage.FINGER_PRINT_EVENT10);
                extras.put(AnalyticsPage.CONTEXT_MY_EVAR34, AnalyticsPage.FINGER_PRINT_LOG_IN);
                extras.put(AnalyticsPage.CONTEXT_MY_PROP34, AnalyticsPage.FINGER_PRINT_LOG_IN);
                extras.put(AnalyticsPage.CONTEXT_PROPERTY_10, AnalyticsPage.INVALID_FINGER_PRINT + " | " + getString(R.string.fp_scanning_max_failed_attempt_message));
                TrackingHelper.trackBankPage(AnalyticsPage.FINGERPRINT_LOGIN_PG, extras);
            }
            else {
                //End: US72282: FingerPrint Analytics
                /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                //When a user incorrectly enters their Finger Print max number of attempts
                HashMap<String, Object> extras = new HashMap<String, Object>();
                extras.put(AnalyticsPage.CONTEXT_MY_EVENTS, AnalyticsPage.FINGER_PRINT_EVENT10);
                extras.put(AnalyticsPage.CONTEXT_MY_EVAR34, AnalyticsPage.FINGER_PRINT_LOG_IN);
                extras.put(AnalyticsPage.CONTEXT_MY_PROP34, AnalyticsPage.FINGER_PRINT_LOG_IN);
                extras.put(AnalyticsPage.CONTEXT_PROPERTY_10, AnalyticsPage.INVALID_FINGER_PRINT + " | " + getString(R.string.fp_scanning_max_failed_attempt_message));
                TrackingHelper.trackCardPage(AnalyticsPage.FINGERPRINT_LOGIN_PG, extras);
                /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
            }
            enableDisableFPLink(false);
            fieldTVs[0].requestFocus();
        }
    }

    public enum Upgrade_Type {
        HARD_UPGRADE, SOFT_UPGRADE
    }

    private class PasscodeTouchListner implements View.OnTouchListener {

        private final int fieldInt;

        public PasscodeTouchListner(final int fieldInt) {
            this.fieldInt = fieldInt;
        }

        @Override
        public boolean onTouch(final View v, final MotionEvent event) {
            final int nextInput = getNextInput();
            // if touched edit text is not next passcode field to recieve focus
            // then overwrite user selection
            if (fieldInt != nextInput) {
                fieldTVs[fieldInt].clearFocus();
                fieldTVs[nextInput].requestFocus();
                showKeyboard();
                return true;
            }
            return false;
        }

    }

    private class MyPasscodeKeyListener implements View.OnKeyListener {
        public static final int KEY_DELETE = 67;

        @Override
        public boolean onKey(final View v, final int keyCode,
                             final KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                return false;
            }
            if (keyCode == KEY_DELETE) {
                deleteLatestInput().requestFocus();
            }
            return onKeyUp(keyCode, event);
        }
    }

    public void showApplyNowBanner() {
        SharedPreferences sharedPref = getSharedPreferences(getResources()
                .getString(R.string.post_login_username), Context.MODE_PRIVATE);
        boolean showApplyNow = sharedPref.getBoolean(getResources()
                .getString(R.string.isUserLoggedInFirstTime), true);

        if (showApplyNow && isShowApplyNowBanner && !isForceUpgradeAvailable && !isApplyNowKillSwitch) {
            final View parentView = findViewById(R.id.login_start_layout);
            parentView.post(new Runnable() {
                @Override
                public void run() {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(parentView.getWindowToken(), 0);
                }
            });

            if (!isActivitysOnSaveInstanceStateCalled) {
                //Crash Fix defect #13263- check in Bank ALM
                if(this!= null && !this.isFinishing()){
                    isShowApplyNowBanner = false;
                    Activity act = com.discover.mobile.common.shared.DiscoverActivityManager.getActiveActivity();
                    ft = act.getFragmentManager().beginTransaction();
                    ft.setCustomAnimations(R.animator.apply_now_slide_in_up, R.animator.apply_now_slide_up_out);
                    applyNowBannerFragment = new ApplyNowBannerFragment();
                    ft.add(R.id.apply_now_view, applyNowBannerFragment, "detailFragment");
                    ft.commit();
                }

            }
        }
    }

    public void showApplyNowDialog() {
        final View parentView = findViewById(R.id.login_start_layout);
        parentView.post(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(parentView.getWindowToken(), 0);
            }
        });

        hideApplyNowBanner();
        applyNowDioalog = null;
        applyNowDioalog = new ApplyNowDioalog();
        applyNowDioalog.show(getSupportFragmentManager(), " ApplyNowDialog");
    }

    private void hideApplyNowBanner(){
        if(!isShowApplyNowBanner){
            isShowApplyNowBanner = true;
            if(ft != null && applyNowBannerFragment != null){
                ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.animator.apply_now_slide_in_up, R.animator.apply_now_slide_up_out);
                ft.remove(applyNowBannerFragment);
                ft.commit();
            }

        }

    }
}