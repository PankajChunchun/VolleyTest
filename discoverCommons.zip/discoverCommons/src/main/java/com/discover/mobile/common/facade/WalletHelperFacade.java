package com.discover.mobile.common.facade;

import android.content.Context;

public interface WalletHelperFacade {

    //public boolean isAllAndroidPayEligibilityApplicable(Context context);

    public boolean isAllSamsungPayEligibilityApplicable(Context context);

    public boolean isAndroidPayEligibleOnSamsungDevice(Context context);

    public boolean isUserAndroidPayEligible(Context context);

    public boolean isDeviceAndroidPayEligibile(Context context);
}
