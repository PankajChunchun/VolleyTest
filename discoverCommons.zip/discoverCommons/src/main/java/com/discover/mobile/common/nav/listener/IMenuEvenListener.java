package com.discover.mobile.common.nav.listener;

/**
 * Created by 468195 on 2/17/2016.
 */
public interface IMenuEvenListener {

    public void onMenuItemClicked(String title);
}
