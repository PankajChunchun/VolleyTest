package com.discover.mobile.common.portalpage;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.discover.mobile.common.R;
import com.discover.mobile.common.SalutationUpdater;
import com.discover.mobile.common.SyncedActivity;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.beans.BankErrorAccount;
import com.discover.mobile.common.portalpage.beans.BankVerifyAccount;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.beans.CardErrorAccount;
import com.discover.mobile.common.portalpage.beans.DepositAccount;
import com.discover.mobile.common.portalpage.beans.IraPlan;
import com.discover.mobile.common.portalpage.beans.LoanAccount;
import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.listener.PortalListAnimationListener;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.ui.modals.DiscoverAlertDialog;
import com.discover.mobile.common.uiwidget.dynamiclist.CmnDraggableListActionListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import static com.discover.mobile.common.portalpage.utils.PortalConstants.Misc.PORTAL_ACCOUNT_CLOSED_KEY;
import static com.discover.mobile.common.portalpage.utils.PortalConstants.Misc.PORTAL_ACCOUNT_LIST_SORTED_KEY;

/**
 * Common Portal page for Card & Bank. It will show list of Card & Bank Boxes
 * depending on "v2/account" service call
 *
 * @author slende
 */
public class PortalPageActivity extends DiscoverBaseActivity implements
        SyncedActivity, ErrorHandlerUi,PortalListAnimationListener, CmnDraggableListActionListener {

    NetworkRequestListener netReqListener = null;
    /** Collection of account list in a Order given as per requirement */
    private ArrayList<PortalBoxInterface> sortedPortalAccounList = null;
    private TextView greetingTxtV;
    //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation- commented the below line- start
    //private TextView terms;
    //private TextView feedback;
    //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation- commented the below line- end
    private int cardtype;

    private ImageView logoutBtn;

    private AccountV2Details accountDetailsFromCache;
    private LinearLayout greetingLayout;
    private View fadeBglayout;
    private CmnDraggableListActionListener mPortalListActionListener;
    private boolean shouldDisableDragAndDrop = false;
    private boolean closedAccount;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        getWindow().setBackgroundDrawableResource(R.drawable.blue_bg);
        super.onCreate(savedInstanceState);

        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if (Utils.checkPermissionTampering(this)) {
            return;
        }

        /*Fix for timeout issue US98125 - vpant - start */
        if (!Globals.isBankLoginSelected()) {
            FacadeFactory.getCardFacade().startPageTimer(this);
        }
        /*Fix for timeout issue US98125 - vpant - end */
        /**Defect:1268 end**/
        /*setBehindContentView(new LinearLayout(this));
        hideSlidingMenuIfVisible();
        disableMenu();*/

        setContentView(R.layout.portal_page_main_activity);

        DiscoverActivityManager.setActiveActivity(this);

        // clear selected edk key, if we move from card to bank then in that case key should be null - Added for US48093 changes
        PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setSelectedAccKey(null);

        // get Data from cache in HashMap form
        accountDetailsFromCache = fetchCacheAccountDetails();

        netReqListener = new NetworkRequestListener() {

            @Override
            public void onSuccess(Object data) {
                if (null != data) {

                    accountDetailsFromCache = fetchCacheAccountDetails();
                    Globals.setSSOUser(accountDetailsFromCache.isSSOUser());
                    sortedPortalAccounList = getPortalDataAsList(accountDetailsFromCache);
                    navigateToPortalAccountList(sortedPortalAccounList);
                }
            }

            @Override
            public void onError(Object data) {
                FacadeFactory.getPortalPageFacade().handleErrorScenario(
                        PortalPageActivity.this.getContext(), data);
            }
        };

        if (null != accountDetailsFromCache) {
            // setup data for list binding
            sortedPortalAccounList = getPortalDataAsList(accountDetailsFromCache);
            navigateToPortalAccountList(sortedPortalAccounList);

        } else {
            fetchFreshAccountDetails();
        }



        fadeBglayout =  findViewById(R.id.fadeBackground);
        //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation- commented the below line- start
        //terms = (TextView) findViewById(R.id.privacy_terms_portal);
        // feedback = (TextView) findViewById(R.id.provide_feedback_button_portal);
        //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation- commented the below line- end
        greetingTxtV = (TextView) findViewById(R.id.portal_greeting_text);
        //Using Greeting layout for Welcome text since layout animation works only for ViewGroup
        greetingLayout = (LinearLayout)findViewById(R.id.greeting_layout);
        logoutBtn = (ImageView) findViewById(R.id.navigation_button);
        logoutBtn.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                /**start Added for defect#11560 */
                savePortalCustomOrder();
                /**end Added for defect#11560 */

                if(closedAccount){

                    FacadeFactory.getPortalPageBankFacade().trackLinkTagWithProperties(AnalyticsPage.PORTAL_CLOSED_ACCT_LOG_OUT_BTN,
                            "","", AnalyticsPage.PORTAL_CLOSED_ACCT_LOG_OUT_BTN, true, AnalyticsPage.PORTAL_LOGOUT_BTN_events);
                }else {
                    HashMap<String, Object> portal_logout = new HashMap<String, Object>();
                    portal_logout.put("my.prop1", AnalyticsPage.PORTAL_LOGOUT_BTN);
                    portal_logout.put("my.eVar35", AnalyticsPage.PORTAL_LOGOUT_BTN);
                    portal_logout.put("pe", AnalyticsPage.PORTAL_LNK_O_PE);
                    portal_logout.put("pev1", AnalyticsPage.PORTAL_LOGOUT_BTN);
                    TrackingHelper.trackCardPage(null, portal_logout);
                }

                FacadeFactory.getCardLogoutFacade().logout(
                        PortalPageActivity.this, false, false);

                //Symlinked file - Fix for the infinite loop on selecting logout on the portal page.
                //if (Utils.isRunningOnHandset(PortalPageActivity.this)) {
                //logout();
                //}
                return false;
            }
        });

        //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation- commented the below line-start
        /*terms.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                cardtype = PortalUtils
                        .countofCardandBankAccounts(accountDetailsFromCache);
                if (cardtype == 1 || cardtype == 2)
                    FacadeFactory.getBankLoginFacade()
                            .openPrivacyAndTermsPortalPage();
                else if (cardtype == 3)
                    FacadeFactory.getCardFacade().navToPrivacyTerms(
                            PortalPageActivity.this);

            }
        });

        feedback.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                FacadeFactory.getCardFacade().navToProvideFeedback(
                        PortalPageActivity.this);

            }
        });*/
        //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation- commented the below line- end


		/*
         * new Thread(new SalutationUpdater(greetingTxtV,
		 * PortalUtils.setUserNickName(accountDetailsFromCache),
		 * PortalPageActivity.this)).start();
		 */
        //CrashLytics # 1374
        if(accountDetailsFromCache!=null)
        new Thread(new SalutationUpdater(greetingTxtV,
                accountDetailsFromCache.getCustomerFirstName(),
                PortalPageActivity.this)).start();
        /*
            Animate Greeting Layout from left to right
         */
        Animation rotateAnim = AnimationUtils.loadAnimation(this, R.anim.slide_from_left);
        final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim,ANIMATE_DURATION);
        greetingLayout.setLayoutAnimation(animController);
        rotateAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                greetingLayout.clearAnimation();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        TrackFraudAccount();

    }

    /**
     * Function to show the Fraud Unusual Activity modal
     */
    private void showFraudmodel() {

        /*boolean to check whether any modal has been shown (in case there are muliple Draud accounts*/
        boolean fraudAccFound = false;
        for (PortalBoxInterface portalBoxInterface : sortedPortalAccounList) {
            if (portalBoxInterface instanceof CardAccount) {
                final CardAccount cAccount = (CardAccount) portalBoxInterface;
                /*Condition that cheacks <br></br>
                * 1.) if the Account is Fraud type <br></br>
                * 2.) if not Unusual account activity modal has been invoked or not <br></br>
                * 3.) if the dialog for he corresponsing fraud account has  been shown or not<br></br><br></br>
                 *
                 * If all the 1st conditions is true and the other two conditions are false,then the If condition is satisfied */
                if ("A".equals(cAccount.getExternalStatus()) && !fraudAccFound && !PortalUtils.isFraudDialogShown(this, cAccount.getLastFourAcctNbr())) {
                    if (cAccount != null) {
                        PortalUtils.setFraudDialogShown(this, Boolean.TRUE, cAccount.getLastFourAcctNbr());
                        fraudAccFound = true;
                        /*Tracking the invocation of the <b>Unusual Account Activity</b> modal*/
                        TrackingHelper.trackCardPage(AnalyticsPage.FRAUDVERIFICATION_UNUSUAL_ACTIVITY_MODAL_SSO_PAGENAME, null);
                        Resources res = this.getResources();
                        String title = String.format(res.getString(R.string.fraud_intercept_ending_accunt_title), cAccount.getLastFourAcctNbr());
                        final DiscoverAlertDialog dialog = new DiscoverAlertDialog()
                                .setTitle(title)
                                .setMessage(res.getString(R.string.fraud_intercept_content))
                                .setPositiveButton(res.getString(R.string.fraud_intercept_review_button_text),
                                        new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                HashMap<String, Object> extras = new HashMap<String, Object>();
                                                extras.put(getContext().getResources().getString(R.string.prop1), AnalyticsPage.FRAUDVERIFICATION_INTERCEPT_MODAL_REVIEW_BUTTON_prop1);
                                                TrackingHelper.trackClickEvents(  AnalyticsPage.FRAUDVERIFICATION_INTERCEPT_MODAL_REVIEW_BUTTON_pev1 ,null, AnalyticsPage.LINK_TYPE_O,extras);
                                                /*PortalUtils.showSpinner(PortalPageActivity.this);*/
                                                PortalUtils.fireSiteTagsFroAccountBoxClick(PortalAccountType.ACCOUNT_CREDIT_CARD);
                                                FacadeFactory.getPortalPageFacade().navToCardHome(PortalPageActivity.this, cAccount.getAcctKey());
                                            }
                                        }
                                )
                                .setIcon(R.drawable.onboard_error)
                                .setCanceledOnTouchOutside(false)
                                .setNegativeButton(res.getString(R.string.fraud_intercept_close_button_text), new View.OnClickListener(

                                ) {
                                    @Override
                                    public void onClick(View v) {

                                        /*Tracking the Close button Scenario*/
                                        HashMap<String, Object> extras = new HashMap<String, Object>();
                                      /*  extras.put("my.prop1",
                                                AnalyticsPage.FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_prop1);
                                        extras.put("pe",
                                                AnalyticsPage.FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_pe);
                                        extras.put("pev1",
                                                AnalyticsPage.FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_pev1);
                                        TrackingHelper.trackCardPage(
                                                null, extras);*/
                                        extras.put(getContext().getResources().getString(R.string.prop1), AnalyticsPage.FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_prop1);
                                        TrackingHelper.trackClickEvents(AnalyticsPage.FRAUDVERIFICATION_INTERCEPT_CLOSE_BUTTON_pev1, null, AnalyticsPage.LINK_TYPE_O, extras);
                                        showFraudmodel();
                                    }
                                });
                        dialog.show((DiscoverBaseActivity) this);

                    }
                }
            }
        }


    }

    private void TrackFraudAccount() {
        int count = 0;
        StringBuilder sb = new StringBuilder();
        //crashlytics defect 440..8.5
        if (sortedPortalAccounList != null) {
            for (PortalBoxInterface portalBoxInterface : sortedPortalAccounList) {
                if (portalBoxInterface instanceof CardAccount) {
                    final CardAccount cAccount = (CardAccount) portalBoxInterface;
                    if ("A".equals(cAccount.getExternalStatus())) {
                        if (count == 0) {
                            sb.append(getResources().getString(R.string.fraud_portal_tile_text));
                        } else {
                            sb.append(":").append(getResources().getString(R.string.fraud_portal_tile_text));
                        }
                        count++;
                    }
                }
            }
        if (sb != null && sb.length() > 0) {
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put("my.list1", sb);
            extras.put("my.prop10", sb);
            TrackingHelper.trackCardPage(null, extras);
        }
    }
    }

    //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation-  added a seprate method- start
    public void navigateToPrivacyTerms() {
        cardtype = PortalUtils
                .countofCardandBankAccounts(accountDetailsFromCache);
        if (cardtype == 1 || cardtype == 2)
            FacadeFactory.getBankLoginFacade()
                    .openPrivacyAndTermsPortalPage();
        else if (cardtype == 3)
            FacadeFactory.getCardFacade().navToPrivacyTerms(
                    PortalPageActivity.this);
    }

    public void navigateToFeedback() {
        FacadeFactory.getCardFacade().navToProvideFeedback(
                PortalPageActivity.this);
    }

    //US54421 Android: Material: Portal Page: Un-Anchor Terms and Conditions Implmentation-  added a seprate method- end
    @Override
    protected void onResume() {
        super.onResume();

        //Added as per bank onsite request
        DiscoverActivityManager.setActiveActivity(this);

        // US83033 - Start
        // Commenting call of showFraudmodel() as per US83033
        // showFraudmodel();
        // US83033 - End

//		hideSlidingMenuIfVisible();
//        disableMenu();
        // US37429 changes start - pkuma13
        SharedPreferences sharedPref = getSharedPreferences(getResources()
                .getString(R.string.post_login_username), Context.MODE_PRIVATE);
        sharedPref.edit().putBoolean(
                getResources().getString(R.string.isUserLoggedInFirstTime), false).commit();
        // US37429 changes end - pkuma13

        if (!Globals.isBankLoginSelected()) {
            Globals.setFromCardSide(true);
        } else {
            Globals.setFromCardSide(false);
        }

        handleAppMessagingDeeplink();

    }

   /* public void disableMenu() {
        getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
    }*/

    /**
     * It returns the list of accounts in order -> 1.Checking -> Savings/MMA ->
     * CD 2.IRA's 3.Credit Card 4.Discover Personal Loans
     */
    private ArrayList<PortalBoxInterface> getPortalDataAsList(
            AccountV2Details accountDetails) {
        ArrayList<PortalBoxInterface> portalAccountAsList = null;
        if (null != accountDetails) {
            portalAccountAsList = new ArrayList<PortalBoxInterface>();
            // nkaza : us28647 - Start
            //If error while retrieving both bank and card data.
            if ((accountDetails.isErrorRetrievingBankData() ||
                    ((!accountDetails.isErrorRetrievingBankData()) && (accountDetails.getBankSummaryStatus().equalsIgnoreCase(getResources().getString(R.string.bank_data_bad_customer_invalid_status))
                            || accountDetails.getBankSummaryStatus().equalsIgnoreCase(getResources().getString(R.string.bank_data_bad_customer_error_status))))) && accountDetails.isErrorRetrievingCardData()) { //Both Bank and Card Error
                addBankErrorAccounts(portalAccountAsList);
                addCardErrorAccounts(portalAccountAsList);
                this.shouldDisableDragAndDrop = true;

            } else if (accountDetails.isErrorRetrievingBankData() ||
                    ((!accountDetails.isErrorRetrievingBankData()) && (accountDetails.getBankSummaryStatus().equalsIgnoreCase(getResources().getString(R.string.bank_data_bad_customer_invalid_status))
                            || accountDetails.getBankSummaryStatus().equalsIgnoreCase(getResources().getString(R.string.bank_data_bad_customer_error_status))))) { //Only Bank data error

                addBankErrorAccounts(portalAccountAsList);
                addCardAccountsUnverified(portalAccountAsList, accountDetails);
                addCardAccounts(portalAccountAsList, accountDetails);

                this.shouldDisableDragAndDrop = true;

            } else if ((accountDetails.getBankSummaryStatus().equalsIgnoreCase(getResources().getString(R.string.bank_data_bad_customer_closed_status)))){
                addDepositAccounts(portalAccountAsList, accountDetails);
                addBankClosedAccounts(portalAccountAsList);
                addCardAccounts(portalAccountAsList, accountDetails);
                addIRA_ccounts(portalAccountAsList, accountDetails);
                addLoansAccounts(portalAccountAsList, accountDetails);
                this.shouldDisableDragAndDrop = true;
            } else if ((accountDetails.getBankSummaryStatus().equalsIgnoreCase(getResources().getString(R.string.bank_data_bad_customer_unverified_status)))) {

                addCardAccountsUnverified(portalAccountAsList, accountDetails);
                addBankVerifyAccount(portalAccountAsList);
                addCardAccounts(portalAccountAsList, accountDetails);
                this.shouldDisableDragAndDrop = true;

            } else if (accountDetails.isErrorRetrievingCardData()) { //Only Card data error
                addCardErrorAccounts(portalAccountAsList);
                addDepositAccounts(portalAccountAsList, accountDetails);
                addIRA_ccounts(portalAccountAsList, accountDetails);
                addLoansAccounts(portalAccountAsList, accountDetails);
                this.shouldDisableDragAndDrop = true;

            } else {                                                //If there are no errors in retrieving both bank and card data.

                boolean isAccountAdded = addCardAccountsUnverified(portalAccountAsList, accountDetails);
                if(isAccountAdded){
                    this.shouldDisableDragAndDrop = true;
                }
                addDepositAccounts(portalAccountAsList, accountDetails);
                addCardAccounts(portalAccountAsList, accountDetails);
                addIRA_ccounts(portalAccountAsList, accountDetails);
                addLoansAccounts(portalAccountAsList, accountDetails);
            }
            // nkaza : us28647 - end
        }
        return portalAccountAsList;

    }


    /**
     * Adding blank Bank object to display error box on portal page.
     */
    private void addBankErrorAccounts(ArrayList<PortalBoxInterface> portalAccounList) {
        portalAccounList.add((PortalBoxInterface) new BankErrorAccount());
    }

    /**
     * Adding blank Bank object to display error box on portal page.
     */
    private void addBankVerifyAccount(ArrayList<PortalBoxInterface> portalAccounList) {
        portalAccounList.add((PortalBoxInterface) new BankVerifyAccount());
    }


    /**
     * Adding blank Card object to display error box on portal page.
     */
    private void addCardErrorAccounts(ArrayList<PortalBoxInterface> portalAccounList) {
        portalAccounList.add((PortalBoxInterface) new CardErrorAccount());
    }

    private AccountV2Details fetchCacheAccountDetails() {
        return PortalCacheDataUtils.getPortalCacheDataUtilsInstance()
                .getAccountV2Details();
    }

    private void fetchFreshAccountDetails() {
        PortalUtils.getPortalAccountDetails(this, null, null, netReqListener,
                false);
    }

    private void navigateToPortalAccountList(
            ArrayList<PortalBoxInterface> sortedPortalAccounList) {
        PortalPageListFragment portalPageListFragment = new PortalPageListFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable(PORTAL_ACCOUNT_LIST_SORTED_KEY,
                sortedPortalAccounList);
        if(accountDetailsFromCache.getBankSummaryStatus().equalsIgnoreCase("closed")){
            bundle.putBoolean(PORTAL_ACCOUNT_CLOSED_KEY, true);
            closedAccount=true;
        }
        else {
            bundle.putBoolean(PORTAL_ACCOUNT_CLOSED_KEY, false);
            closedAccount=false;
        }
        portalPageListFragment.setArguments(bundle);
        showInLeftFrame(portalPageListFragment, true);

        //check condition to show FICO at top of the page
//        showFicoAtTop();
    }


    private void showInLeftFrame(final Fragment frag, boolean addToHistory) {
        pushFragment(frag, R.id.left_frame, addToHistory);
    }

    private void pushFragment(Fragment frag, int iFrameID, boolean addToHistory) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager()
                .beginTransaction().remove(frag)
                .add(iFrameID, frag, frag.getClass().getSimpleName());
        if (addToHistory)
            fragmentTransaction.addToBackStack(frag.getClass().getSimpleName());
        fragmentTransaction.commitAllowingStateLoss();
    }

    /**
     * Save portal custom order before logout ie before cache data getting deleted
     * Added for defect#11560
     */
    private void savePortalCustomOrder() {
        Fragment portalPageListFragment = getSupportFragmentManager().findFragmentByTag(PortalPageListFragment.class.getSimpleName());
        if (portalPageListFragment instanceof PortalPageListFragment) {
            ((PortalPageListFragment) portalPageListFragment).savePortalCustomOrder();
        }
    }

    /**
     * Method to get Checking & Savings accounts from Deposit accounts Map
     */
    private void addDepositAccounts(
            ArrayList<PortalBoxInterface> portalAccounList,
            AccountV2Details accountDetails) {
        //added for US46912
        DepositAccount depositAccountItem = null;
        Iterator<Entry<Integer, DepositAccount>> mapIterator = accountDetails
                .getDepositAccountsMap().entrySet().iterator();

        while (mapIterator.hasNext()) {
            Map.Entry<Integer, DepositAccount> pairs = mapIterator.next();

            /**start added for US46912 */
            depositAccountItem = pairs.getValue();
            // removed IsVerified condition as required for US43080
//            if (null != depositAccountItem.getIsVerified() && depositAccountItem.getIsVerified())
            portalAccounList.add(depositAccountItem);

            /**end added for US46912 */
        }
    }

    private void addBankClosedAccounts(ArrayList<PortalBoxInterface> portalAccounList) {
        DepositAccount depositAccountItem = new DepositAccount();
        depositAccountItem.setIndex(0);
        depositAccountItem.setAcctType("001");
        depositAccountItem.setAcctStatus("Closed");
        depositAccountItem.setAcctNickName("Closed Account");
        portalAccounList.add(depositAccountItem);
    }

    /**
     * Method to get & add sorted IRA accounts
     */
    private void addIRA_ccounts(ArrayList<PortalBoxInterface> portalAccounList,
                                AccountV2Details accountDetails) {

        IraPlan iraPlanItem = null;
        Iterator<Entry<Integer, IraPlan>> mapIterator = accountDetails
                .getIraPlansMap().entrySet().iterator();

        while (mapIterator.hasNext()) {
            Map.Entry<Integer, IraPlan> pairs = mapIterator.next();
            iraPlanItem = pairs.getValue();
            // removed IsVerified condition as required for US43080
//            if (null != iraPlanItem.getIsVerified() && iraPlanItem.getIsVerified())
            portalAccounList.add(pairs.getValue());
        }
    }

    /**
     * Method to get & add Sorted card accounts
     */
    private void addCardAccounts(
            ArrayList<PortalBoxInterface> portalAccounList,
            AccountV2Details accountDetails) {

        //added for US46912
        boolean isCardUnverifiedAccountAdded = false;
        CardAccount cardAccountItem = null;
        Iterator<Entry<String, CardAccount>> mapIterator = accountDetails
                .getCardAccountsMap().entrySet().iterator();

        while (mapIterator.hasNext()) {
            Map.Entry<String, CardAccount> pairs = mapIterator.next();

            /**start added for US46912 */
            cardAccountItem = pairs.getValue();
            // keep this condition as required for US43080
            if (null != cardAccountItem.getIsVerified() && cardAccountItem.getIsVerified())
                portalAccounList.add(cardAccountItem);
            /**end added for US46912 */
        }
    }

    /**
     * Method to add unverified card accounts
     */
    private boolean addCardAccountsUnverified(
            ArrayList<PortalBoxInterface> portalAccounList,
            AccountV2Details accountDetails) {

        //added for US46912
        boolean isCardUnverifiedAccountAdded = false;
        CardAccount cardAccountItem = null;
        Iterator<Entry<String, CardAccount>> mapIterator = accountDetails
                .getCardAccountsMap().entrySet().iterator();

        while (mapIterator.hasNext()) {
            Map.Entry<String, CardAccount> pairs = mapIterator.next();

            /**start added for US46912 */
            cardAccountItem = pairs.getValue();

            // #Defect 317 Add only unverified card accounts to show on top
            if (null != cardAccountItem.getIsVerified() && !cardAccountItem.getIsVerified()) {
                portalAccounList.add(cardAccountItem);
                isCardUnverifiedAccountAdded = true;
            }

        }
        return isCardUnverifiedAccountAdded;
    }

    /**
     * Method to get & add Sorted loan accounts
     */
    private void addLoansAccounts(
            ArrayList<PortalBoxInterface> portalAccounList,
            AccountV2Details accountDetails) {

        //added for US46912
        LoanAccount loanAccountItem = null;
        Iterator<Entry<Integer, LoanAccount>> mapIterator = accountDetails
                .getLoanAccountsMap().entrySet().iterator();

        while (mapIterator.hasNext()) {
            Map.Entry<Integer, LoanAccount> pairs = mapIterator.next();

            /**start added for US46912 */
            loanAccountItem = pairs.getValue();
            // removed IsVerified condition as required for US43080
//            if (null != loanAccountItem.getIsVerified() && loanAccountItem.getIsVerified())
            portalAccounList.add(loanAccountItem);
            /**end added for US46912 */
        }
    }

    // Do nothing If back pressed.
    @Override
    public void onBackPressed() {
        // disable back key
    }

	/*@Override
    public ErrorHandler getErrorHandler() {
		// TODO Auto-generated method stub
		return null;
	}*/

    // US29136 changes start
    @Override
    public boolean isReady() {
        return true;
    }

    @Override
    public boolean waitForResume(int millis) {
        return false;
    }

    // US29136 changes end

    /**
     * Added for Fix for defect# 204404
     */
    public void logout() {
        if (PortalUtils.isDeeplinkClicked) {
            FacadeFactory.getLogoutFacade().logout(this, this,
                    Globals.getCurrentAccount());
            Globals.setLoggedIn(false);
        } /*else
            PortalPageActivity.this.finish();*/
    }

    /**
     * start LHN implementation changes : These are all empty methods, need optimization here for
     * interface ErrorHandlerUi -slende
     */
    @Override
    public TextView getErrorLabel() {
        return null;
    }

    @Override
    public List<EditText> getInputFields() {
        return null;
    }

    @Override
    public void showCustomAlert(AlertDialog alert) {

    }

    @Override
    public void showOneButtonAlert(int title, int content, int buttonText) {

    }

    @Override
    public void showDynamicOneButtonAlert(int title, String content, int buttonText) {

    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public int getLastError() {
        return 0;
    }

    @Override
    public void setLastError(int errorCode) {

    }

    @Override
    public ErrorHandler getErrorHandler() {
        return null;
    }

    /*
    Animate greeting view from right to left
     */
    @Override
    public void animateView(float delay) {
        Animation rotateAnim = AnimationUtils.loadAnimation(this, R.anim.slide_from_right);
        final LayoutAnimationController animController = new LayoutAnimationController(rotateAnim);
        rotateAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                //Hide Layout once animation is completed
                greetingLayout.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        greetingLayout.setLayoutAnimation(animController);
        //Start the animation
        greetingLayout.startLayoutAnimation();
    }


    @Override
    public void onStartDragging(int pos) {

    }

    @Override
    public void onStopDragging() {

    }

    @Override
    public boolean shouldDisableDragAndDrop() {
        return this.shouldDisableDragAndDrop;
    }


    /** end LHN implementation changes : These are all empty methods, need optimization here for interface ErrorHandlerUi -slende */


    private void handleAppMessagingDeeplink(){
        FacadeFactory.getCardFacade().handleAppMessagingDeeplink(this);
    }

}
