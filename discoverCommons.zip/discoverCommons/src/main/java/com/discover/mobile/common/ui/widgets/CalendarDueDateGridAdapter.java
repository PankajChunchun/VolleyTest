package com.discover.mobile.common.ui.widgets;

import com.caldroid.CaldroidFragment;
import com.caldroid.CaldroidGridAdapter;
import com.caldroid.DateParser;
import com.discover.mobile.common.R;
import com.discover.mobile.common.shared.utils.StringUtility;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * The grid adapter that allows us to add a "due date" field to the calendar
 *
 * @author stephenfarr
 */
public class CalendarDueDateGridAdapter extends CaldroidGridAdapter {
    private final String DUE_DATE = "Due";
    private Date date;
    private boolean dueDateBlocked;
    private boolean dueDateIsFinal = false;

    /**
     * Boolean set to true if the last date for payment is due end date
     * Added as part of US56293
     */
    private boolean dueEndDateIsFinal = false;

    private Date endDate;

    public CalendarDueDateGridAdapter(final Context context, final int month, final int year, final ArrayList<Date> disableDates,
                                      final ArrayList<Date> selectedDates, final Date minDateTime, final Date maxDateTime) {
        super(context, month, year, disableDates, selectedDates, minDateTime, maxDateTime);

        date = null;
    }

    @Override
    public View getView(final int position, final View convertView, final ViewGroup parent) {
        final TextView dateView = (TextView) super.getView(position, convertView, parent);
        final Date dateViewDate = datetimeList.get(position);
        setContentDateDesc(dateViewDate, dateView);

        if (date != null && dateViewDate.compareTo(date) == 0) {
            dateView.setText(dateView.getText().toString() + StringUtility.NEW_LINE + DUE_DATE);

            if (deepDateCompare(date)) {
                dateView.setBackgroundResource(R.drawable.common_calendar_due_date_selected);
            } else if (dueDateBlocked) {
                dateView.setBackgroundResource(R.drawable.common_calendar_due_date_blocked);
            } else {
                dateView.setBackgroundResource(R.drawable.black_square_border);
            }

        } else if (date != null && dateViewDate.compareTo(date) > 0 && dueDateIsFinal && !(endDate != null && (deepEndDateCompare(dateViewDate)))) {
            dateView.setBackgroundResource(R.drawable.disable_cell);
            dateView.setTextColor(CaldroidFragment.disabledTextColor);
            dateView.setOnClickListener(null);
        }else if(dueEndDateIsFinal && endDate != null && dateViewDate != null && dateViewDate.compareTo(endDate) > 0){
            /**
             * Start - Added as part of US56293 user story,
             * Above else condition is used to block the date after the given end date
             */
            dateView.setBackgroundResource(R.drawable.disable_cell);
            dateView.setTextColor(CaldroidFragment.disabledTextColor);
            dateView.setOnClickListener(null);
            //End - Added as part of US56293
        }

        return dateView;
    }

    /**
     * Gives us the due date to use/
     */
    public void setDueDateDateTimesList(final Date dueDate) {
//		date = DateParser.newDateTime(dueDate);
        date = dueDate;
    }

    /**
     * Sets the value of dueDateBlocked, indicating whether the current due date is also a blocked
     * date
     *
     * @param isDueDateBlocked - true if the due date is a blocked date, otherwise false
     */
    public void setDueDateBlocked(final boolean isDueDateBlocked) {
        dueDateBlocked = isDueDateBlocked;
    }

    /**
     * Performs a deeper compare between the provided date object and the list of selected dates in
     * order to confirm they are
     * the same based on day, month and year instead of the exact millisecond value.
     *
     * @param date - date to be tested
     * @return whether or not the date appears in the list of selected dates.
     */
    private boolean deepDateCompare(final Date date) {
        boolean isEqual = false;

        for (final Date selectedDate : getSelectedDates()) {
            if (DateParser.getDayOfMonth(selectedDate) == DateParser.getDayOfMonth(date) &&
                    DateParser.getYear(selectedDate) == DateParser.getYear(date) &&
                    DateParser.getMonthOfYear(selectedDate) == DateParser.getMonthOfYear(date)) {
                isEqual = true;
                break;
            }
        }

        return isEqual;
    }

    /**
     * @return the dueDateIsFinal
     */
    public boolean isDueDateIsFinal() {
        return dueDateIsFinal;
    }

    /**
     * @param dueDateIsFinal the dueDateIsFinal to set
     */
    public void setDueDateIsFinal(final boolean dueDateIsFinal) {
        this.dueDateIsFinal = dueDateIsFinal;
    }


    /**
     * Method to set Due end date as final date for payment
     * Added as part of US56293 user story
     * @param dueEndDateIsFinal
     */
    public void setDueEndDateIsFinal(final boolean dueEndDateIsFinal){
        this.dueEndDateIsFinal = dueEndDateIsFinal;
    }

    private boolean deepEndDateCompare(final Date date) {
        boolean isEqual = false;


        if (DateParser.getDayOfMonth(endDate) == DateParser.getDayOfMonth(date) &&
                DateParser.getYear(endDate) == DateParser.getYear(date) &&
                DateParser.getMonthOfYear(endDate) == DateParser.getMonthOfYear(date)) {
            isEqual = true;
        }
        return isEqual;
    }

    /**
     * @param dueDateIsFinal the dueDateIsFinal to set
     */
    public void setEndDate(final Date endDate) {
//		this.endDate = DateParser.newDateTime(endDate);
        this.endDate = endDate;

    }

    private void setContentDateDesc(Date dateViewDate, TextView dateView) {
        if (dateViewDate != null) {
            boolean selected = false;
            try {
                DateFormat df = new SimpleDateFormat("d MMM yyyy");
                String date = df.format(dateViewDate);

                if (DateParser.getYear(dateViewDate) > DateParser
                        .getYear(minDateTime))
                    selected = true;
                else if (DateParser.getYear(dateViewDate) == DateParser
                        .getYear(minDateTime)) {
                    if (DateParser.getMonthOfYear(dateViewDate) > DateParser
                            .getMonthOfYear(minDateTime)) {
                        selected = true;
                    } else if (DateParser.getMonthOfYear(dateViewDate) == DateParser
                            .getMonthOfYear(minDateTime)) {

                        if (DateParser.getDayOfMonth(dateViewDate) >= DateParser
                                .getDayOfMonth(minDateTime))
                            selected = true;
                    }
                }

                dateView.setContentDescription(date + " "
                        + (selected ? " selected" : " disabled"));
            } catch (Exception e) {

            }
        }
    }

}
