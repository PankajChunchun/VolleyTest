package com.discover.mobile.common.fingerprint.utils;

import com.discover.mobile.common.fingerprint.listener.DiscoverFingerPrintManager;
import com.discover.mobile.common.fingerprint.listener.FingerPrintListener;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.support.v4.app.ActivityCompat;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/**
 * Created by mgupta4 on 5/18/2016.
 */

/**
 * Helper class for authentication of fingerprint using Google API
 */
@TargetApi(Build.VERSION_CODES.M)
public class GoogleFingerprintHelper extends FingerprintManager.AuthenticationCallback implements DiscoverFingerPrintManager {


    private static final String KEY_NAME = "my_key";

    private final FingerprintManager mFingerprintManager;
    private final Context mContext;
    private final FingerPrintListener mFingerprintListener;
    private CancellationSignal mCancellationSignal;
    private boolean mSelfCancelled;
    private Cipher mCipher;
    private KeyStore mKeyStore;
    private KeyGenerator mKeyGenerator;


    public GoogleFingerprintHelper(Context context, FingerprintManager fingerprintManager,
                                   FingerPrintListener fingerPrintListener) {
        mFingerprintManager = fingerprintManager;
        mFingerprintListener = fingerPrintListener;

        this.mContext = context;

        createKey();
    }


    /**
     * start identify fingerprint.
     */
    @Override
    public void startListening() {

        //Added null checks - to fix defect 346_308_162
        SecretKey secretKey = createKey();
        if (null != secretKey) {
            Cipher cipher = initCipher(secretKey);
            if (null != cipher) {
                startListening(new FingerprintManager.CryptoObject(cipher));
            }
        }

    }

    /**
     * Use cancellation signal to stop authentication process.
     */
    @Override
    public void stopListening() {
        if (mCancellationSignal != null) {
            mSelfCancelled = true;
            mCancellationSignal.cancel();
            mCancellationSignal = null;
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    public void startListening(FingerprintManager.CryptoObject cryptoObject) {

        mCancellationSignal = new CancellationSignal();
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mFingerprintManager.authenticate(cryptoObject, mCancellationSignal, 0 /* flags */, this, null);


    }


    /**
     * Default Fingerprint callback for error
     * @param errMsgId
     * @param errString
     */
    @Override
    public void onAuthenticationError(int errMsgId, CharSequence errString) {
        if (!mSelfCancelled) {
            mFingerprintListener.onError(errString.toString());
        }
    }

    /**
     * Default Fingerprint callback for help.
     * @param helpMsgId
     * @param helpString
     */
    @Override
    public void onAuthenticationHelp(int helpMsgId, CharSequence helpString) {
        mFingerprintListener.onAuthenticationHelp(helpString.toString());
    }


    /**
     * Default Fail callback.
     */
    @Override
    public void onAuthenticationFailed() {

        mFingerprintListener.onError("Failed to identify. Please try again");

    }

    /**
     * Default Success callback.
     * @param result
     */
    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {


        mFingerprintListener.onAuthenticated();
    }


    /**
     * Initialize cipher text. Use this in Fingerprint Crypto object.
     * @param key
     * @return
     */
    @TargetApi(Build.VERSION_CODES.M)
    public Cipher initCipher(SecretKey key) {
        try {
            mCipher = Cipher.getInstance("AES/GCM/NoPadding");
            mCipher.init(Cipher.ENCRYPT_MODE, key);
            return mCipher;
        } catch (KeyPermanentlyInvalidatedException e) {
            return null;
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
//            throw new RuntimeException("Failed to init Cipher", e);
            e.printStackTrace();
            return null;
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * Creates a symmetric key in the Android Key Store which can only be used after the user has
     * authenticated with fingerprint.
     */
    @TargetApi(Build.VERSION_CODES.M)
    public SecretKey createKey() {
        // The enrolling flow for fingerprint. This is where you ask the user to set up fingerprint
        // for your flow. Use of keys is necessary if you need to know if the set of
        // enrolled fingerprints has changed.
        try {
            mKeyStore = KeyStore.getInstance("AndroidKeyStore");
            mKeyStore.load(null);
            mKeyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            // Set the alias of the entry in Android KeyStore where the key will appear
            // and the constrains (purposes) in the constructor of the Builder
            mKeyGenerator.init(
                    new KeyGenParameterSpec.Builder(KEY_NAME,
                            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                            .setUserAuthenticationRequired(true)
                            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                            .build());
            return mKeyGenerator.generateKey();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException | InvalidAlgorithmParameterException
                | CertificateException | IOException e) {
            e.printStackTrace();
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
            //fix for defect #1199
        } catch (RuntimeException e){
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }


}
