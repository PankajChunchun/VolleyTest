package com.discover.mobile.common.portalpage;

import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.beans.DepositAccount;
import com.discover.mobile.common.portalpage.beans.ExternalStatusMessage;
import com.discover.mobile.common.portalpage.beans.IraPlan;
import com.discover.mobile.common.portalpage.beans.LoanAccount;
import com.discover.mobile.common.portalpage.beans.User;
import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.listener.PortalListAnimationListener;
import com.discover.mobile.common.portalpage.listener.PortalListItemClickInterface;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalSharedPreferenceUtil;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.AccountType;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.shared.utils.SecurityUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.discover.mobile.common.portalpage.utils.PortalAccountType.ACCOUNT_CD;
import static com.discover.mobile.common.portalpage.utils.PortalAccountType.ACCOUNT_IRA;
import static com.discover.mobile.common.portalpage.utils.PortalAccountType.ACCOUNT_LOAN;
import static com.discover.mobile.common.portalpage.utils.PortalAccountType.ACCOUNT_MONEY_MARKET;

/**
 * Presenter Class for PortalPageListFragment
 */
public class PortalPagePresenterImpl implements PortalPagePresenter{

    private final PortalPageUIInterface mPortalPageUIInterface;
    private final PortalListAnimationListener mPortalAnimationListener;

    PortalPagePresenterImpl(PortalPageUIInterface portalPageUIInterface, PortalListAnimationListener portalListAnimationListener){

        mPortalPageUIInterface = portalPageUIInterface;
        mPortalAnimationListener = portalListAnimationListener;
    }

    @Override
    public void handlePortalItemClick(PortalBoxInterface dataItem, PortalAccountType accountType) {

        //Added if condition for fix for defect# 11873
        if (PortalUtils.isAllowPortalAnimation(dataItem)) {
            if (mPortalAnimationListener != null)
                mPortalAnimationListener.animateView(PortalListAnimationListener.DELAY_DURATION);
        }
        switch (accountType) {
            case ACCOUNT_CREDIT_CARD:
                // bank facade call
                onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.CARD_ACCOUNT_SELECTED, ((CardAccount) dataItem).getAcctKey());
                break;

            case ACCOUNT_CHECKING:
            case ACCOUNT_SAVINGS:
            case ACCOUNT_MONEY_MARKET:
                onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_ACCOUNT_SELECTED, ((DepositAccount) dataItem).getIndex(), ACCOUNT_MONEY_MARKET);
                break;
            case ACCOUNT_CD:
                onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_ACCOUNT_SELECTED, ((DepositAccount) dataItem).getIndex(), ACCOUNT_CD);
                break;
            case ACCOUNT_IRA:
                onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_ACCOUNT_SELECTED, ((IraPlan) dataItem).getIndex(), ACCOUNT_IRA);
                break;
            case ACCOUNT_LOAN:
                onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_ACCOUNT_SELECTED, ((LoanAccount) dataItem).getIndex(), ACCOUNT_LOAN);
                break;

            default:
                break;
        }
    }

    @Override
    public void handleBadStatusAccounts(PortalBoxInterface dataItem, PasscodeUtils passcodeUtils, PortalAccountType accountType, boolean isANRKillSwitchDisabled) {

        String externalStatus = ((CardAccount) dataItem).getExternalStatus();
        ExternalStatusMessage externalStatusMessage = ((CardAccount) dataItem).getExternalStatusMessage();
        if (externalStatus.equalsIgnoreCase("Z") || externalStatus.equalsIgnoreCase("B")) {
            passcodeUtils.deletePasscodeToken();
            //Changes for the US47001 by asaraf2
            if(externalStatusMessage !=null ){
                this.mPortalPageUIInterface.displayZULBErrorModalFromApi(externalStatusMessage.getExternalStatusTitle(), externalStatusMessage.getExternalStatusBody());
            }
        } else if (!isANRKillSwitchDisabled && ((externalStatus.equalsIgnoreCase("U") || externalStatus.equalsIgnoreCase("L")))) {
            //Changes for the US47001 by asaraf2
            if(externalStatusMessage !=null ){
                this.mPortalPageUIInterface.displayZULBErrorModalFromApi(externalStatusMessage.getExternalStatusTitle(), externalStatusMessage.getExternalStatusBody());
            }
        } else
            handlePortalItemClick(dataItem, accountType);
    }

    @Override
    public void handleDeeplink(PortalBoxInterface dataItem, PortalAccountType accountType, boolean isLeftDeeplink) {
        switch (accountType) {

            case ACCOUNT_CREDIT_CARD:
                // bank facade call
                if (isLeftDeeplink)
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.CARD_FICO_CREDIT_SCORE_LINK, ((CardAccount) dataItem).getAcctKey());
                else
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.CARD_MAKE_A_PAYMENT_LINK, ((CardAccount) dataItem).getAcctKey());
                break;

            case ACCOUNT_CHECKING:
                // bank facade call
                if (isLeftDeeplink) {
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_DEPOSIT_A_CHECK_LINK, ((DepositAccount) dataItem).getIndex(), ACCOUNT_CD);
                    HashMap<String, Object> checking_account_deposit_a_check = new HashMap<String, Object>();
                    checking_account_deposit_a_check.put("my.prop1", AnalyticsPage.PORTAL_CHECKING_DEPOSIT_A_CHECK_TXT);
                    checking_account_deposit_a_check.put("my.eVar35", AnalyticsPage.PORTAL_CHECKING_DEPOSIT_A_CHECK_TXT);
                    checking_account_deposit_a_check.put("pe", AnalyticsPage.PORTAL_LNK_O_PE);
                    checking_account_deposit_a_check.put("pev1", AnalyticsPage.PORTAL_CHECKING_DEPOSIT_A_CHECK_TXT);
                    TrackingHelper.trackCardPage(null, checking_account_deposit_a_check);
                } else {
                    //US99424 Code start Portal Enhancements :Quicklinks:Add TransferMoney
                    // US113743-Android: Portal Enhancements: Quick Links: Transfer Money Analytics - Passing account type so that analytics logic can be handled at bank side.
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_TRANSFER_LINK, ((DepositAccount) dataItem).getIndex(), PortalAccountType.ACCOUNT_CHECKING);
                    //US99424 Code End Portal Enhancements :Quicklinks:Add TransferMoney

                     /*Removing site cat log from here added in bank side*/
                }
                break;

            case ACCOUNT_SAVINGS:
                // bank facade call
                if (isLeftDeeplink) {
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_DEPOSIT_A_CHECK_LINK, ((DepositAccount) dataItem).getIndex(), ACCOUNT_CD);
                    HashMap<String, Object> savings_account_deposit_a_check = new HashMap<String, Object>();
                    savings_account_deposit_a_check.put("my.prop1", AnalyticsPage.PORTAL_SAVINGS_DEPOSIT_A_CHECK_TXT);
                    savings_account_deposit_a_check.put("my.eVar35", AnalyticsPage.PORTAL_SAVINGS_DEPOSIT_A_CHECK_TXT);
                    savings_account_deposit_a_check.put("pe", AnalyticsPage.PORTAL_LNK_O_PE);
                    savings_account_deposit_a_check.put("pev1", AnalyticsPage.PORTAL_SAVINGS_DEPOSIT_A_CHECK_TXT);
                    TrackingHelper.trackCardPage(null, savings_account_deposit_a_check);
                } else {
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_TRANSFER_LINK, ((DepositAccount) dataItem).getIndex(), ACCOUNT_CD);
                    HashMap<String, Object> savings_bank_transfer_link = new HashMap<String, Object>();
                    savings_bank_transfer_link.put("my.prop1", AnalyticsPage.PORTAL_SAVINGS_TRANSFER_MONEY_TXT);
                    savings_bank_transfer_link.put("my.eVar35", AnalyticsPage.PORTAL_SAVINGS_TRANSFER_MONEY_TXT);
                    savings_bank_transfer_link.put("pe", AnalyticsPage.PORTAL_LNK_O_PE);
                    savings_bank_transfer_link.put("pev1", AnalyticsPage.PORTAL_SAVINGS_TRANSFER_MONEY_TXT);
                    TrackingHelper.trackCardPage(null, savings_bank_transfer_link);
                }

                break;

            case ACCOUNT_IRA:
                // No Deep link
                break;

            case ACCOUNT_MONEY_MARKET:
                if (isLeftDeeplink) {
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_DEPOSIT_A_CHECK_LINK, ((DepositAccount) dataItem).getIndex(), ACCOUNT_MONEY_MARKET);
                } else {
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_TRANSFER_LINK, ((DepositAccount) dataItem).getIndex(), ACCOUNT_MONEY_MARKET);

                }
                break;


            case ACCOUNT_LOAN:
                // bank facade call
                if (isLeftDeeplink) {
                    onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType.BANK_PAY_LOANS_LINK, ((LoanAccount) dataItem).getIndex(), ACCOUNT_CD);
                }
                break;

            default:
                break;
        }
    }


    @Override
    public void encrypt(String data) {
        try {
            SecurityUtil.encrypt(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void decrypt(String data) {
        try {
            SecurityUtil.decrypt(data);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public List<PortalBoxInterface> getSortedPortalList(Map<String, PortalBoxInterface> originalPortaAccountsMap) {
        final User user = PortalSharedPreferenceUtil.getInstance().getUserFromSharedPref();
        if (user != null) {
            return PortalUtils.getSortedPortalList(originalPortaAccountsMap, user.getOrder(), new PortlistUpdateListener() {
                @Override
                public void updateOrder(String newOrder) {
                    User.getInstance().setOrder(newOrder);
                    PortalSharedPreferenceUtil.getInstance().saveOrderToUserSharedPref();
                }
            });
        }
        else
            return null;
    }

    @Override
    public void saveUpdatedPortalListOrder(List<PortalBoxInterface> updatedPortalList) {
        User.getInstance().setOrder(PortalUtils.getOrderInString(updatedPortalList));
        PortalSharedPreferenceUtil.getInstance().saveOrderToUserSharedPref();
    }

    private void onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType itemClickType, String edsKey) {
        // To Handle All Card side Transactions here
        // Update account detail changes
        //Defect Fix 208145- Quick View Widget start
        Globals.setBankLoginSelected(false);
        Globals.setCurrentAccount(AccountType.CARD_ACCOUNT);
        LoginActivity.isCardChecked = true;
        //Defect Fix 208145- Quick View Widget end
        PortalCacheDataUtils.getPortalCacheDataUtilsInstance().setSelectedAccKey(edsKey);

        switch (itemClickType) {
            case CARD_ACCOUNT_SELECTED:
                break;
            case CARD_FICO_CREDIT_SCORE_LINK:
                HashMap<String, Object> fico_credit_score_link = new HashMap<String, Object>();
                fico_credit_score_link.put("my.prop1", AnalyticsPage.PORTAL_CARD_FICO_CREDIT_SCORE_TXT);
                fico_credit_score_link.put("my.eVar35", AnalyticsPage.PORTAL_CARD_FICO_CREDIT_SCORE_TXT);
                fico_credit_score_link.put("pe", AnalyticsPage.PORTAL_LNK_O_PE);
                fico_credit_score_link.put("pev1", AnalyticsPage.PORTAL_CARD_FICO_CREDIT_SCORE_TXT);
                TrackingHelper.trackCardPage(null, fico_credit_score_link);
                break;
            case CARD_MAKE_A_PAYMENT_LINK:
                HashMap<String, Object> make_a_payment_link = new HashMap<String, Object>();
                make_a_payment_link.put("my.prop1", AnalyticsPage.PORTAL_CARD_MAKE_A_PAYMENT_TXT);
                make_a_payment_link.put("my.eVar35", AnalyticsPage.PORTAL_CARD_MAKE_A_PAYMENT_TXT);
                make_a_payment_link.put("pe", AnalyticsPage.PORTAL_LNK_O_PE);
                make_a_payment_link.put("pev1", AnalyticsPage.PORTAL_CARD_MAKE_A_PAYMENT_TXT);
                TrackingHelper.trackCardPage(null, make_a_payment_link);
                break;
            default:
                break;

        }
        this.mPortalPageUIInterface.navigateToCardAccount(itemClickType, edsKey);
    }

    private void onPortalPageItemClick(PortalListItemClickInterface.PortalPageClickType itemClickType, int accountIndexKey, PortalAccountType portalAccountType) {
        // To Handle All Bank side Transactions here

        // Modal is added to fix the modal delay issue on portal page
        this.mPortalPageUIInterface.displayProgressModal();
        // US29136 changes start
        //Defect Fix 208145- Quick View Widget start
        Globals.setBankLoginSelected(true);
        Globals.setCurrentAccount(AccountType.BANK_ACCOUNT);
        LoginActivity.isCardChecked = false;
        //Defect Fix 208145- Quick View Widget end
        mPortalPageUIInterface.navigateToBankAccount(itemClickType, accountIndexKey, portalAccountType);
        // US29136 changes end
    }

    public interface PortlistUpdateListener{
        void updateOrder(String newOrder);

    }


}
