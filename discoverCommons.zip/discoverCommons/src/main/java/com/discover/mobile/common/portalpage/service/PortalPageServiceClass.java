package com.discover.mobile.common.portalpage.service;

import com.discover.mobile.common.msignia.MsigniaSingleton;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import com.discover.mobile.common.R;
import com.discover.mobile.common.facade.CardFacade;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.portalpage.beans.AccountV2ErrorDataBean;
import com.discover.mobile.common.portalpage.beans.BankPayload;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.beans.PortalAccountDetails;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalConstants;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.shared.net.SessionTokenManager;
import com.discover.mobile.common.shared.utils.PasscodeUtils;
import com.discover.mobile.common.threatmatrix.ThreatMatrixSingleton;
import com.discover.mobile.network.AdapterProvider;
import com.discover.mobile.network.CommonAdapterProvider;
import com.discover.mobile.network.CommonRequestInterceptor;
import com.discover.mobile.network.ServiceGenerator;
import com.discover.mobile.network.constants.RequestResponseHeaders;
import com.discover.mobile.network.error.GenericErrorResponseParser;
import com.discover.mobile.network.error.bean.ErrorBean;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.HashMap;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Class for call of services used in Portal Page. 1. "account-v2"
 *
 * @author slende
 */
public class PortalPageServiceClass {
    protected static final String TAG = PortalPageServiceClass.class.getSimpleName();
    private final String sessionKeyId = "X-TMX-SID";
    Context context = null;

    public PortalPageServiceClass(Context context) {
        this.context = context;
    }

    public static Serializable getObjectFromJSONString(String jsonStr, Class<?> modalClass) throws JsonSyntaxException {
        Gson gson = new Gson();
        Serializable pojoObject = (Serializable) gson.fromJson(jsonStr, modalClass);
        return pojoObject;
    }

    /**
     * @param isPasscodeLogin    Set up common login headers
     * @param isFingerPrintLogin : added one more parameter for 7.10 fingerprint release
     */
    private void setUpLoginHeaders(HashMap<String, String> cred, String username, String password, boolean isPasscodeLogin, boolean isFingerPrintLogin) {
        if (username != null) {
            if (SessionTokenManager.getToken() == null) {
                if (isPasscodeLogin || isFingerPrintLogin) { // added one more check for for 7.10 fingerprint release
                    cred.put(RequestResponseHeaders.Authorization, PortalUtils.getPasscodeAuthorizationString(username, password));
                } else {
                    cred.put(RequestResponseHeaders.Authorization, PortalUtils.getAuthorizationString(username, password));
                }
            } else {
                if (Globals.isBankLoginSelected && password != null) {
                    if (isPasscodeLogin || isFingerPrintLogin) { // added one more check for for 7.10 fingerprint release
                        cred.put(RequestResponseHeaders.Authorization, PortalUtils.getPasscodeAuthorizationString(username, password));
                    } else {
                        cred.put(RequestResponseHeaders.Authorization, PortalUtils.getAuthorizationString(username, password));
                    }
                }
            }
        } else {
            cred.put("X-Override-UID", "true");
        }
        /**added if condition for 7.10 finger print release */
        if (isFingerPrintLogin) {
            cred.put(RequestResponseHeaders.XScreenTypeCode, PortalConstants.RequestConstant.FINGER_PRINT_LOGIN_ID);
        }


    }

    private void getPortalAccountsData(Context context, NetworkRequestListener listener) {

        getDummyPortalAccountsJson("PortalAccountDetails.json", listener);

    }

    /**
     * @param fileName : file with json response of account-v2 placed in assets
     */
    public void getDummyPortalAccountsJson(String fileName, NetworkRequestListener listener) {

        String dummyJSONResonse = loadJSONFromAsset(context, fileName);
        PortalAccountDetails portalAccountDetails = (PortalAccountDetails) getDummyResponse(context, new PortalAccountDetails(), dummyJSONResonse);
        if (null != listener) {
            PortalCacheDataUtils.getPortalCacheDataUtilsInstance().storePortalAccountDetails(portalAccountDetails);
            listener.onSuccess(portalAccountDetails);
        }
    }

    /**
     * Function to read json file from asset folder
     */
    private String loadJSONFromAsset(Context context, String fileName) {
        String json;
        try {
            InputStream in = context.getAssets().open(fileName);
            final BufferedReader br = new BufferedReader(new InputStreamReader(in));
            final StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            json = sb.toString();
        } catch (IOException ex) {
            return null;
        }

        return json;
    }

    public Serializable getDummyResponse(Context context, Serializable dataHolder, String dummyJSONResonse) {

        try {
            if (null != dummyJSONResonse) {
                dataHolder = /* Utils. */getObjectFromJSONString(dummyJSONResonse, dataHolder.getClass());
            }
            return dataHolder;
        } catch (Exception e) {
            return dataHolder;
        }
    }

    /**
     * @param authString1     : Username / token / null
     * @param authString2     : Password/ Hasktoken / null
     * @param nrl             : Network listener
     * @param isPasscodeLogin : True if login is done using passcode
     * @param  isFingerPrintLogin : added one more parameter for 7.10 fingerprint release
     *                        Method used to fetch v2 account details .
     */
    public void fetchPortalAccountDetails(final String authString1, final String authString2, final NetworkRequestListener nrl, final boolean isPasscodeLogin, final boolean isFingerPrintLogin) {

        PortalUtils.showSpinner(context);

        HashMap<String, String> cred = new HashMap<String, String>();

        /** added one more parameter for 7.10 fingerprint release */
        setUpLoginHeaders(cred, authString1, authString2, isPasscodeLogin, isFingerPrintLogin);

        CardFacade cardFacade = FacadeFactory.getCardFacade();

        if (cardFacade.isKillSwitchDisabled(context.getString(R.string.anr_kill_switch))) {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
        } else {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
        }

        //AdapterProvider adapterProvider = new CommonAdapterProvider(context, null, new CommonRequestInterceptor(cred, context));

        //Passing an extra boolean paramter to decorate the request with Shape SDK.
        //To Achieve this a Constructor has been Overloaded in CommonAdapterProvider
        AdapterProvider adapterProvider = new CommonAdapterProvider(context, null, new CommonRequestInterceptor(cred, context),true);
        adapterProvider.createRestAdapter();

        PortalPageServiceInterface portalPageServiceProxy = ServiceGenerator.createService(PortalPageServiceInterface.class, adapterProvider);
        FetchAccountDetailsListener fetchAccountDetailsListener = new FetchAccountDetailsListener(authString1, authString2,nrl, isPasscodeLogin,isFingerPrintLogin);


        if (cardFacade.isKillSwitchDisabled(context.getString(R.string.anr_kill_switch))) {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
            portalPageServiceProxy.getPortalAccountV4Details(fetchAccountDetailsListener);
        } else {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
            portalPageServiceProxy.getPortalAccountV3Details(fetchAccountDetailsListener);
        }

//	 getPortalAccountsData(context, nrl); // for dummy service call

    }

    /**
     * Service call to get updated accounts V2 details
     * Update account detail changes
     */
    public void updatePortalAccountDetails(final Context context, final NetworkRequestListener ntwEventListener, final String strTitle, final String strMessage) {
        PortalUtils.showSpinner(context, strTitle, strMessage);

        HashMap<String, String> cred = new HashMap<String, String>();
        cred.put("X-Override-UID", "true");
        CardFacade cardFacade = FacadeFactory.getCardFacade();
        if (cardFacade.isKillSwitchDisabled(context.getString(R.string.anr_kill_switch))) {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
        } else {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
        }


       /* AdapterProvider adapterProvider = new CommonAdapterProvider(context, null, new CommonRequestInterceptor(cred, context));
        adapterProvider.createRestAdapter();*/

        AdapterProvider adapterProvider = new CommonAdapterProvider(context, null, new CommonRequestInterceptor(cred, context),true);
        adapterProvider.createRestAdapter();

        PortalPageServiceInterface portalPageServiceProxy = ServiceGenerator.createService(PortalPageServiceInterface.class, adapterProvider);
        UpdateAccountDetailsListener updateAccountDetailsListener = new UpdateAccountDetailsListener(ntwEventListener);

        if (cardFacade.isKillSwitchDisabled(context.getString(R.string.anr_kill_switch))) {
            portalPageServiceProxy.getPortalAccountV4Details(updateAccountDetailsListener);
        }else{
            portalPageServiceProxy.getPortalAccountV3Details(updateAccountDetailsListener);
        }
    }

    /**
     * Method to refresh selected card account details based on edsKey
     *
     * @param edsKey Added for US48093 changes
     */
    public void refreshCardAccountDetails(final Context context, final NetworkRequestListener ntwEventListener, final String strTitle,
                                          final String strMessage, final String edsKey) {

        PortalUtils.showSpinner(context, strTitle, strMessage);
        HashMap<String, String> cred = new HashMap<String, String>();
        CardFacade cardFacade = FacadeFactory.getCardFacade();
        if (cardFacade.isKillSwitchDisabled(context.getString(R.string.anr_kill_switch))) {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginV4url), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
        } else {
            if (ThreatMatrixSingleton.Instance().getGetSessionIDKillSwitch() == false
                    && ThreatMatrixSingleton.Instance().hasEndPointAvailable(PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl))) {
                String sessionId = ThreatMatrixSingleton.Instance().getSessionID(true, PortalUtils.getBaseUrl() + context.getResources().getString(R.string.loginurl), context);//For session id popup
                cred.put(sessionKeyId, sessionId);
            }
        }


       /* AdapterProvider adapterProvider = new CommonAdapterProvider(context, null, new CommonRequestInterceptor(null, context));
        adapterProvider.createRestAdapter();*/

        AdapterProvider adapterProvider = new CommonAdapterProvider(context, null, new CommonRequestInterceptor(cred, context),true);
        adapterProvider.createRestAdapter();

        PortalPageServiceInterface portalPageServiceProxy = ServiceGenerator.createService(PortalPageServiceInterface.class, adapterProvider);
        RefreshAccountDetailsListerner refreshAccountDetailsListerner =new RefreshAccountDetailsListerner(edsKey, ntwEventListener);


        if (cardFacade.isKillSwitchDisabled(context.getString(R.string.anr_kill_switch))) {
            portalPageServiceProxy.getPortalAccountV4Details(refreshAccountDetailsListerner);
        }else{
            portalPageServiceProxy.getPortalAccountV3Details(refreshAccountDetailsListerner);
        }

    }


    public void getRefreshBankPayload() {

        //Commented below line To Fix Defect 205755
        //PortalUtils.showSpinner(context);
        HashMap<String, String> cred = new HashMap<String, String>();
        // setUpLoginHeaders(cred,authString1,authString2,isPasscodeLogin);
        AdapterProvider adapterProvider = new CommonAdapterProvider(context,
                null, new CommonRequestInterceptor(cred, context));
        adapterProvider.createRestAdapter();
        BankPayloadServiceInterface refreshpayloadServiceProxy = ServiceGenerator
                .createService(BankPayloadServiceInterface.class,
                        adapterProvider);

        refreshpayloadServiceProxy
                .getRefreshPayload(new Callback<BankPayload>() {

                    @Override
                    public void failure(RetrofitError retrofitError) {
                        GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(
                                context, retrofitError, null);
                        ErrorBean errorbean = genericErrorResponseParser
                                .handleCardErrorforResponse();
                        PortalUtils.hideSpinner(context);
                    }


                    @Override
                    public void success(BankPayload arg0, Response arg1) {
                        // TODO Auto-generated method stub
                        FacadeFactory.getBankLoginFacade()
                                .authorizeWithBankPayload(arg0.payload);
                        PortalUtils.hideSpinner(context);
                    }

                });

    }

    /*
      This method calls to skip user authentication for now. #38224
    */
    public void skipMergeIntercept(final NetworkRequestListener ntwEventListener) {

        AdapterProvider adapterProvider = new CommonAdapterProvider(context, null, new CommonRequestInterceptor(null, context));
        adapterProvider.createRestAdapter();

        PortalPageServiceInterface portalPageServiceProxy = ServiceGenerator.createService(PortalPageServiceInterface.class, adapterProvider);
        portalPageServiceProxy.skipMergeIntercept(new Callback<Object>() {
            @Override
            public void failure(RetrofitError retrofitError) {
                GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(context, retrofitError, new AccountV2ErrorDataBean());
                ErrorBean errorbean = genericErrorResponseParser.handleCardErrorforResponse();

                ntwEventListener.onError(errorbean);
            }

            @Override
            public void success(Object successResponseObj, Response arg1) {
                ntwEventListener.onSuccess(successResponseObj);
            }
        });
    }

    class FetchAccountDetailsListener implements Callback<PortalAccountDetails>{
        private String authString1;
        private String authString2;
        private boolean isPasscodeLogin;
        private NetworkRequestListener nrl;
        private boolean isFingerPrintLogin;

        public FetchAccountDetailsListener(String authString1, String authString2, NetworkRequestListener nrl, boolean isPasscodeLogin, boolean isFingerPrintLogin) {
            this.authString1 = authString1;
            this.authString2 = authString2;
            this.isPasscodeLogin = isPasscodeLogin;
            this.nrl = nrl;
            this.isFingerPrintLogin = isFingerPrintLogin;
        }

        @Override
        public void failure(RetrofitError retrofitError) {
            GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(context, retrofitError, new AccountV2ErrorDataBean());
            ErrorBean errorbean = genericErrorResponseParser.handleCardErrorforResponse();
            //Unified session user story US28598 - start
            if (null != retrofitError && retrofitError.getResponse() != null)
                PortalUtils.storeUnifiedTokenHeader(retrofitError.getResponse().getHeaders(), context);
            //Unified session user story US28598 - end

            /**start added for US50152 Prevent Joint Card Toggle login- slende */
            String errorCode = PortalUtils.getHttpAndErrorStatus(errorbean);
            if (context instanceof LoginActivity && ((LoginActivity) context).isCardLogin() && errorCode.equalsIgnoreCase(PortalConstants.Error.JOIN_CARD_ACCOUNT_LOGIN_ATTEMPT2_ERROR)) {

                ((LoginActivity) context).redirectToBankLogin(authString1, authString2,
                        isPasscodeLogin);
                /**US63085 Golden: CLA SSO: Bank-Only: Handle Exit From Flow and Navigate to Home : Start**/
                //CLA Merge intercept flow Bankside error when we press "X" in BB redirect flow
            } else if (errorCode.equalsIgnoreCase(PortalConstants.Error.MERGE_ELIGIBLE_BANK_ERROR_CODE)) {
                //2125  - Represents merge eligible for bank only users.
                // US126324 Changes - start
                // Adding one argument which will take status of initial skip attempt.
                PortalUtils.navToPortalMergeInterceptPage(FacadeFactory.getBankLoginFacade().getFirstName(), false, false);
                // US126324 Changes - end
            } else if (errorCode.equalsIgnoreCase(PortalConstants.Error.FORCE_MERGE_BANK_ERROR_CODE)) {
                //2126  - Represents force merge for bank only users to hide skip now button.
                // US126324 Changes - start
                // In case of force merge, value for initial skip does not matter
                // Action will be taken with the value of force merge only.
                PortalUtils.navToPortalMergeInterceptPage(FacadeFactory.getBankLoginFacade().getFirstName(), true, false);
                // US126324 Changes - end
            } else if (errorCode.equalsIgnoreCase(PortalConstants.Error.NON_MERGE_ELIGIBLE_BANK_ERROR_CODE)) {
                //2129 – Non merge eligible bank only user ( can redirect to bank home if this ever happens edge case)
                FacadeFactory.getBankLoginFacade().navigateToBankHomePage();
                /**US63085 Golden: CLA SSO: Bank-Only: Handle Exit From Flow and Navigate to Home : END**/

            } else {
                nrl.onError(errorbean);
                if (!errorbean.getErrorResponseHeader().containsKey(RequestResponseHeaders.Authentication))
                    MsigniaSingleton.Instance().sendMSigniaDataFail(context);
            }
            /**end added for US50152 - slende */
            PortalUtils.hideSpinner(context);
        }

        @Override
        public void success(PortalAccountDetails successReponseObj, Response arg1) {

            /**start added for US71613 FP maximum failure attempts */
            FingerPrintUtils fpUtils = new FingerPrintUtils(context);
            fpUtils.resetFPScanningFailedCount();
            /**end added for US71613 FP maximum failure attempts */

            PortalCacheDataUtils.getPortalCacheDataUtilsInstance().storePortalAccountDetails((PortalAccountDetails) successReponseObj);
            //Unified session user story US28598 - start
            PortalUtils.storeUnifiedTokenHeader(arg1.getHeaders(), context);
            //Unified session user story US28598 - end

            //Toggle suppression - Start
            String SSO_APP_SHARED_PREFS = "SSOPasscodeUtils";
            Editor _prefsEditorSso = null;
            String PREFS_CLA_USER_HIDE_TOGGLE = "clauserhidetoggle";
            String PREFS_TOKEN = "token";
            String APP_SHARED_PREFS = PasscodeUtils.class.getSimpleName();
            String BANK_APP_SHARED_PREFS = "BankPasscodeUtils";

            SharedPreferences _sharedPrefs_sso = context.getSharedPreferences(SSO_APP_SHARED_PREFS, Activity.MODE_PRIVATE);
            boolean claUserHideToggle = true;
            if (null != _sharedPrefs_sso) {
                claUserHideToggle = _sharedPrefs_sso.getBoolean(PREFS_CLA_USER_HIDE_TOGGLE, false);
                _prefsEditorSso = _sharedPrefs_sso.edit();
            }

            //Initialize previous version shared perferences to get value
            SharedPreferences _sharedPrefs_sso_card = context.getSharedPreferences(APP_SHARED_PREFS, Activity.MODE_PRIVATE);
            SharedPreferences _sharedPrefs_sso_bank = context.getSharedPreferences(BANK_APP_SHARED_PREFS, Activity.MODE_PRIVATE);

            //If sso user, if passcode login and if the CLA toggle is false
            if (Globals.isSSOUser() && (isPasscodeLogin || PortalUtils.isBankPasscodeLogin) && !claUserHideToggle) {
                if (null != _prefsEditorSso) {
                    _prefsEditorSso.putBoolean(PREFS_CLA_USER_HIDE_TOGGLE, true);
                    PortalUtils.isBankPasscodeLogin = false;
                    if (null != _sharedPrefs_sso_card && null != _sharedPrefs_sso_card.getString(PREFS_TOKEN, null)) {

                        //Copy previous version sso shared preference value to current version shared preference.
                        String previousVersionSSOToken = _sharedPrefs_sso_card.getString(PREFS_TOKEN, null);
                        _prefsEditorSso.putString(PREFS_TOKEN, previousVersionSSOToken);

                        //Remove card shared preference.
                        Editor _prefsEditorSsoCard = _sharedPrefs_sso_card.edit();
                        _prefsEditorSsoCard.remove(PREFS_TOKEN);
                        _prefsEditorSsoCard.commit();

                        //Remove bank shared preference.
                        Editor _prefsEditorSsoBank = _sharedPrefs_sso_bank.edit();
                        _prefsEditorSsoBank.remove(PREFS_TOKEN);
                        _prefsEditorSsoBank.commit();
                    }
                    _prefsEditorSso.commit();
                }
            }
            //Toggle suppression - End

            nrl.onSuccess(successReponseObj);
            MsigniaSingleton.Instance().sendMSigniaDataSuccess(context);
            PortalUtils.hideSpinner(context);
        }
    }

    class UpdateAccountDetailsListener implements Callback<PortalAccountDetails> {
        private NetworkRequestListener ntwEventListener;
        public UpdateAccountDetailsListener(NetworkRequestListener ntwEventListener){
            this.ntwEventListener = ntwEventListener;
        }
        @Override
        public void failure(RetrofitError retrofitError) {
            GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(context, retrofitError, new AccountV2ErrorDataBean());
            ErrorBean errorbean = genericErrorResponseParser.handleCardErrorforResponse();
            ntwEventListener.onError(errorbean);
            PortalUtils.hideSpinner(context);
        }
        @Override
        public void success(PortalAccountDetails successReponseObj, Response arg1) {
            PortalCacheDataUtils.getPortalCacheDataUtilsInstance().storePortalAccountDetails((PortalAccountDetails) successReponseObj);
            //Unified session user story US28598 - start
            PortalUtils.storeUnifiedTokenHeader(arg1.getHeaders(), context);
            //Unified session user story US28598 - end
            ntwEventListener.onSuccess(successReponseObj);
            PortalUtils.hideSpinner(context);
        }
    }

    class RefreshAccountDetailsListerner implements Callback<PortalAccountDetails>{
        private NetworkRequestListener ntwEventListener;
        private String edsKey;

        public RefreshAccountDetailsListerner(String edsKey, NetworkRequestListener ntwEventListener){
            this.ntwEventListener = ntwEventListener;
        }
        @Override
        public void failure(RetrofitError retrofitError) {
            GenericErrorResponseParser genericErrorResponseParser = new GenericErrorResponseParser(context, retrofitError, new AccountV2ErrorDataBean());
            ErrorBean errorbean = genericErrorResponseParser.handleCardErrorforResponse();
            ntwEventListener.onError(errorbean);
            PortalUtils.hideSpinner(context);
        }

        @Override
        public void success(PortalAccountDetails successReponseObj, Response arg1) {
            if (null != successReponseObj) {
                PortalAccountDetails portalAccountDetails = (PortalAccountDetails) successReponseObj;
                //Added below check to fix crashlytics defect 1751
                if(null!=portalAccountDetails.getCardAccounts() && portalAccountDetails.getCardAccounts().size()>0) {
                    CardAccount cardAccount = portalAccountDetails.getCardAccounts().get(0);
                    PortalCacheDataUtils.getPortalCacheDataUtilsInstance().updateCardDetailsOnEdsKey(edsKey, cardAccount);
                }
            }
            ntwEventListener.onSuccess(successReponseObj);
            PortalUtils.hideSpinner(context);
        }
    }
}
