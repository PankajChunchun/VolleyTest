/**
 *
 */
package com.discover.mobile.common.facade;

import android.content.Context;

/**
 * @author 328073
 */
public interface WhatsNewReminderFacade {

    public void isAllowPasscodeAccess(Context context, boolean isAllow);

    public void isAllowQuickViewAccess(Context context, boolean isAllow);

    public void isAllowFingerPrintAccess(Context context, boolean isAllow);

    public boolean isDeviceAlreadyLogin(Context context);
}
