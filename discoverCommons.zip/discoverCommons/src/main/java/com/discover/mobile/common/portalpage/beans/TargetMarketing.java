package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by 467649 on 9/1/2016.
 */
public class TargetMarketing implements Serializable {

    private static final long serialVersionUID = 3555231180002697453L;

    @SerializedName("tmLogicalDate")
    private String tmLogicalDate;
    @SerializedName("tmIsMatchOfferAvailable")
    private String tmIsMatchOfferAvailable;
    @SerializedName("tmAcctQualEffectiveDate")
    private String tmAcctQualEffectiveDate;
    @SerializedName("tmAcctQualEndDate")
    private String tmAcctQualEndDate;
    @SerializedName("tmExpectedPayoutCycleDate")
    private String tmExpectedPayoutCycleDate;
    @SerializedName("tmAccumulatedPayout")
    private String tmAccumulatedPayout;
    @SerializedName("tmAcquisitionOffer")
    private String tmAcquisitionOffer;
    @SerializedName("tmReleasedOfferPayoutValue")
    private String tmReleasedOfferPayoutValue;
    @SerializedName("tmLastEarnCycleDate")
    private String tmLastEarnCycleDate;
    @SerializedName("tmLastEarnCycleDatePlusOneMonth")
    private String tmLastEarnCycleDatePlusOneMonth;
    @SerializedName("tmPromoQualFreqCount")
    private String tmPromoQualFreqCount;
    @SerializedName("tmFaq")
    private String tmFaq;
    @SerializedName("tmExpectedPayoutCycleDateFmt")
    private String tmExpectedPayoutCycleDateFmt;

    @SerializedName("tmAccumulatedPayoutFmt")
    private String tmAccumulatedPayoutFmt;

    @SerializedName("tmReleasedOfferPayoutValueFmt")
    private String tmReleasedOfferPayoutValueFmt;

    public String getTmLogicalDate() {
        return tmLogicalDate;
    }

    public void setTmLogicalDate(String tmLogicalDate) {
        this.tmLogicalDate = tmLogicalDate;
    }

    public String getTmIsMatchOfferAvailable() {
        return tmIsMatchOfferAvailable;
    }

    public void setTmIsMatchOfferAvailable(String tmIsMatchOfferAvailable) {
        this.tmIsMatchOfferAvailable = tmIsMatchOfferAvailable;
    }

    public String getTmAcctQualEffectiveDate() {
        return tmAcctQualEffectiveDate;
    }

    public void setTmAcctQualEffectiveDate(String tmAcctQualEffectiveDate) {
        this.tmAcctQualEffectiveDate = tmAcctQualEffectiveDate;
    }

    public String getTmAcctQualEndDate() {
        return tmAcctQualEndDate;
    }

    public void setTmAcctQualEndDate(String tmAcctQualEndDate) {
        this.tmAcctQualEndDate = tmAcctQualEndDate;
    }

    public String getTmExpectedPayoutCycleDate() {
        return tmExpectedPayoutCycleDate;
    }

    public void setTmExpectedPayoutCycleDate(String tmExpectedPayoutCycleDate) {
        this.tmExpectedPayoutCycleDate = tmExpectedPayoutCycleDate;
    }

    public String getTmAccumulatedPayout() {
        return tmAccumulatedPayout;
    }

    public void setTmAccumulatedPayout(String tmAccumulatedPayout) {
        this.tmAccumulatedPayout = tmAccumulatedPayout;
    }

    public String getTmAcquisitionOffer() {
        return tmAcquisitionOffer;
    }

    public void setTmAcquisitionOffer(String tmAcquisitionOffer) {
        this.tmAcquisitionOffer = tmAcquisitionOffer;
    }

    public String getTmReleasedOfferPayoutValue() {
        return tmReleasedOfferPayoutValue;
    }

    public void setTmReleasedOfferPayoutValue(String tmReleasedOfferPayoutValue) {
        this.tmReleasedOfferPayoutValue = tmReleasedOfferPayoutValue;
    }

    public String getTmLastEarnCycleDate() {
        return tmLastEarnCycleDate;
    }

    public void setTmLastEarnCycleDate(String tmLastEarnCycleDate) {
        this.tmLastEarnCycleDate = tmLastEarnCycleDate;
    }

    public String getTmLastEarnCycleDatePlusOneMonth() {
        return tmLastEarnCycleDatePlusOneMonth;
    }

    public void setTmLastEarnCycleDatePlusOneMonth(String tmLastEarnCycleDatePlusOneMonth) {
        this.tmLastEarnCycleDatePlusOneMonth = tmLastEarnCycleDatePlusOneMonth;
    }

    public String getTmPromoQualFreqCount() {
        return tmPromoQualFreqCount;
    }

    public void setTmPromoQualFreqCount(String tmPromoQualFreqCount) {
        this.tmPromoQualFreqCount = tmPromoQualFreqCount;
    }

    public String getTmFaq() {
        return tmFaq;
    }

    public void setTmFaq(String tmFaq) {
        this.tmFaq = tmFaq;
    }

    public String getTmExpectedPayoutCycleDateFmt() {
        return tmExpectedPayoutCycleDateFmt;
    }

    public void setTmExpectedPayoutCycleDateFmt(String tmExpectedPayoutCycleDateFmt) {
        this.tmExpectedPayoutCycleDateFmt = tmExpectedPayoutCycleDateFmt;
    }
    public String getTmAccumulatedPayoutFmt() {
        return tmAccumulatedPayoutFmt;
    }

    public void setTmAccumulatedPayoutFmt(String tmAccumulatedPayoutFmt) {
        this.tmAccumulatedPayoutFmt = tmAccumulatedPayoutFmt;
    }

    public String getTmReleasedOfferPayoutValueFmt() {
        return tmReleasedOfferPayoutValueFmt;
    }

    public void setTmReleasedOfferPayoutValueFmt(String tmReleasedOfferPayoutValueFmt) {
        this.tmReleasedOfferPayoutValueFmt = tmReleasedOfferPayoutValueFmt;
    }



}
