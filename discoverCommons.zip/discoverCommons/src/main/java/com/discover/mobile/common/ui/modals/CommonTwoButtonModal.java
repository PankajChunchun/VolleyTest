package com.discover.mobile.common.ui.modals;

import com.discover.mobile.common.R;

import android.content.Context;
import android.text.Html;
import android.text.Spannable;
import android.text.TextPaint;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.view.View;
import android.widget.TextView;

/**
 * Created by 526158 on 3/30/2016.
 */
public class CommonTwoButtonModal extends SimpleTwoButtonModal {

    private Runnable backAction = null;
    private boolean isCancellable = true;

    public CommonTwoButtonModal(final Context context) {
        super(context);
    }

    public CommonTwoButtonModal(final Context context, final int okButtonText, final int cancelButtonText, final Runnable okButtonAction, final Runnable cancelButtonAction) {
        super(context, okButtonText, cancelButtonText);
        setOkButton(okButtonAction);
        setCancelButton(cancelButtonAction);
    }

    public CommonTwoButtonModal(final Context context, final String title, final String content, final int okButtonText, final int cancelButtonText, final Runnable okButtonAction, final Runnable cancelButtonAction, final Runnable backButtonAction) {
        super(context, title, content, okButtonText, cancelButtonText);
        setOkButton(okButtonAction);
        setCancelButton(cancelButtonAction);
        backAction = backButtonAction;
        setTitle(title);
        setContentHtml(content);
        this.backAction = backButtonAction;
    }

    public void setOkButton(final Runnable okAction) {
        getOkButton().setOnClickListener(new MyClickListener(okAction));
    }

    public void setCancelButton(final Runnable okAction) {
        getCancelButton().setOnClickListener(new MyClickListener(okAction));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (backAction != null) {
            backAction.run();
        }
    }

    public void setContentHtml(final int content) {
        setContentHtml(getContext().getResources().getString(content));
    }

    public void setContentHtml(String content) {
        TextView tv = ((TextView) view.findViewById(R.id.modal_alert_text));
        tv.setText(Html.fromHtml(content));
        Linkify.addLinks(tv, Linkify.PHONE_NUMBERS);
        stripUnderlines(tv);
    }

    public void setContentHtmlWithoutLinkify(String content) {
        TextView tv = ((TextView) view.findViewById(R.id.modal_alert_text));
        tv.setText(Html.fromHtml(content));
    }

    public void setTitle(String content) {
        TextView tv = ((TextView) view.findViewById(R.id.modal_alert_title));
        tv.setText(Html.fromHtml(content));
    }

    private void stripUnderlines(TextView textView) {
        if (!(textView.getText() instanceof Spannable)) {
            return;
        }
        Spannable s = (Spannable) textView.getText();
        URLSpan[] spans = s.getSpans(0, s.length(), URLSpan.class);
        for (URLSpan span : spans) {
            int start = s.getSpanStart(span);
            int end = s.getSpanEnd(span);
            s.removeSpan(span);
            span = new URLSpanNoUnderline(span.getURL());
            s.setSpan(span, start, end, 0);
        }
        textView.setText(s);
    }

    public void setCancellableOnButtonClick(boolean isCancellale) {
        this.isCancellable = isCancellale;
    }

    public void setOrangeTitle() {
        ((TextView) view.findViewById(R.id.modal_alert_title)).setTextColor(getContext().getResources().getColor(R.color.orange));
    }

    // regular button
    private class MyClickListener implements View.OnClickListener {
        private String TAG = "SimpleContentButton";

        private Runnable action;

        public MyClickListener(final Runnable action) {
            this.action = action;
        }

        public Runnable getAction() {
            return action;
        }

        @Override
        public void onClick(final View v) {
            if (getAction() != null) {
                getAction().run();
            }
            if (getAction() == null || isCancellable) {
                dismiss();
                isCancellable = true;
            }
        }
    }

    private class URLSpanNoUnderline extends URLSpan {
        public URLSpanNoUnderline(String url) {
            super(url);
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            super.updateDrawState(ds);
            ds.setUnderlineText(false);
        }
    }
}

