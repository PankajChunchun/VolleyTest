package com.discover.mobile.common;

import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.StringUtility;

/**
 * Created by pdesai2 on 7/8/2016.
 * <p/>
 * Implements the methods of the EditTextStrategy
 */
public class PhoneTypeEditText implements EditTextStrategy {

    private static final int PHONE_LENGTH = 12;
    private static final int PHONE_SMALL = 3;
    private static final int PHONE_LARGE = 6;

    //returns the proper formatted string with hyphen if needed
    @Override
    public String textChange(String currentInput) {
        String formattedInput = "";
        formattedInput = CommonUtils.getDashlessString(currentInput);
        formattedInput = addHyphenAtIndex(formattedInput, PHONE_SMALL, PHONE_LARGE);
        return formattedInput;
    }

    @Override
    public String postTextChange(String currentInput) {
        return currentInput;
    }

    //adds a hyphen after the 3rd and 6th number
    private String addHyphenAtIndex(String formattedInput, int index, int subIndex) {
        if (formattedInput.length() > index && formattedInput.length() <= subIndex) {
            formattedInput = formattedInput.substring(0, index)
                    + StringUtility.DASH + formattedInput.substring(index);
        } else if (formattedInput.length() > subIndex) {
            formattedInput = formattedInput.substring(0, index) + StringUtility.DASH
                    + formattedInput.substring(index, subIndex) + StringUtility.DASH
                    + formattedInput.substring(subIndex);
        }
        return formattedInput;
    }

    //checks if the length of the string is the right amount
    @Override
    public Boolean textCheck(int length, String currentInput) {
        if (length == PHONE_LENGTH) {
            return true;
        } else {
            return false;
        }
    }
}
