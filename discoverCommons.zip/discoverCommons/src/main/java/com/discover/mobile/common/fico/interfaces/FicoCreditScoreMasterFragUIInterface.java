package com.discover.mobile.common.fico.interfaces;

import com.discover.mobile.common.fico.bean.FicoCreditScore;

/**
 * Created by slende on 5/5/2017.
 * UI callbacks for FicoCreditScoreMasterFrag
 */

public interface FicoCreditScoreMasterFragUIInterface {

    void showSpinner();

    void hideSpinner();

    void ficoScoreOnSuccess(Object data);

    void ficoScoreOnError(Object data);

    void launchFicoLandingFragment(FicoCreditScore ficoCreditScore);

    void showFicoLandingFragWithNoScore();

    void showFicoLandingFragWithScore(FicoCreditScore ficoCreditScore);

    void handlePrivacyAndTermsClick();

    void handleProvideFeedbackClick();

    void handleFicoScoreFAQClick();

    void handleNoScoreFicoFAQClick();
}
