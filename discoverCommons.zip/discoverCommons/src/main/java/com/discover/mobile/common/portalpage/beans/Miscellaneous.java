package com.discover.mobile.common.portalpage.beans;

import java.io.Serializable;

/**
 * Bean class for Miscellaneous error messages. Miscellaneous error messages are the ones that may
 * belong to any tier but the information of whether to show them or not will come from some other
 * service
 */
public class Miscellaneous extends  DynamicMessageBean  implements Serializable

{


    public Miscellaneous(DynamicMessageBean dynamicMessageBean) {
        super(dynamicMessageBean);
    }
}
