package com.discover.mobile.common.services;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by 409992 on 10/6/2016.
 */
public class Parameters {

    @SerializedName("recipients")
    private ArrayList<String> recipients;

    public void setRecipients(ArrayList<String> recipients) {
        this.recipients = recipients;
    }

    public ArrayList<String> getRecipients() {
        return this.recipients;
    }
}
