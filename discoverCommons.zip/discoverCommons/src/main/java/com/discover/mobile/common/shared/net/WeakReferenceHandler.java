package com.discover.mobile.common.shared.net;

import com.discover.mobile.common.shared.callback.AsyncCallback;

import java.lang.ref.WeakReference;

// Nothing in this class should happen outside of the UI thread
public final class WeakReferenceHandler<V> extends TypedReferenceHandler<V> {

    private final WeakReference<AsyncCallback<V>> weakRef;

    public WeakReferenceHandler(final AsyncCallback<V> callback) {
        weakRef = new WeakReference<AsyncCallback<V>>(callback);
    }

    @Override
    protected AsyncCallback<V> getCallback() {
        return weakRef.get();
    }

}
