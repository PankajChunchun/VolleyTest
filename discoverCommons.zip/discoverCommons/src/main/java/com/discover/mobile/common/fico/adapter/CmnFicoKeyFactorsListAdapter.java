package com.discover.mobile.common.fico.adapter;

import com.discover.mobile.common.R;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.ui.widgets.FontAwesomeTextView;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

/**
 * Created by slende
 * Adapter class to bind key-factors
 */

public class CmnFicoKeyFactorsListAdapter extends BaseExpandableListAdapter {

    private Context mContext;
    private List<String> mListDataGroup;
    private HashMap<String, List<String>> mListDataChild;
    private int groupSize = 0;

    public CmnFicoKeyFactorsListAdapter(Context context, List<String> listDataHeader,
                                        HashMap<String, List<String>> listChildData) {
        this.mContext = context;
        this.mListDataGroup = listDataHeader;
        this.mListDataChild = listChildData;
        if (null != this.mListDataGroup) {
            groupSize = this.mListDataGroup.size();
        }
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return this.mListDataChild.get(this.mListDataGroup.get(groupPosition))
                .get(childPosititon);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        final String childText = (String) getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.cmn_fico_keyfactors_list_child, null);
        }

        TextView txtListChild = (TextView) convertView.findViewById(R.id.cmnFicoListChildTxt);
        if (!PortalUtils.isStrFieldEmpty(childText)) {
            txtListChild.setText(CommonUtils.getHtmlFormattedText(childText));
        }

        /**start fixes for defect# 15346 */
        View childSep = convertView.findViewById(R.id.cmnFicoListChildSep);
        if ((groupPosition == groupSize - 1) && isLastChild) {
            childSep.setVisibility(View.GONE);
        } else {
            childSep.setVisibility(View.VISIBLE);
        }
        /**end fixes for defect# 15346 */
        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return this.mListDataChild.get(this.mListDataGroup.get(groupPosition))
                .size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this.mListDataGroup.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return this.mListDataGroup.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.cmn_fico_keyfactors_list_group, null);
        }

        TextView lblListHeader = (TextView) convertView.findViewById(R.id.cmnFicoListGroupTxt);
        if (!PortalUtils.isStrFieldEmpty(headerTitle)) {
            lblListHeader.setText(CommonUtils.getHtmlFormattedText(headerTitle));
        }

        FontAwesomeTextView textIndicator = (FontAwesomeTextView) convertView.findViewById(R.id.cmn_fico_indicator);
        if (isExpanded) {
            textIndicator.setText(mContext.getResources().getString(R.string.fa_minus));
        } else {
            textIndicator.setText(mContext.getResources().getString(R.string.fa_plus));
        }
        textIndicator.setTypeface(textIndicator.getTypeface(), Typeface.NORMAL);
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
