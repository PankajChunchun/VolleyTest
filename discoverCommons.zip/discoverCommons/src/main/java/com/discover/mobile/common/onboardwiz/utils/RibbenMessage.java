package com.discover.mobile.common.onboardwiz.utils;

import com.discover.mobile.common.R;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RibbenMessage {
    public static final int LENGTH_SHORT = 0;
    public static final int LENGTH_LONG = 1;
    public static final int LENGTH_EXTRA_LONG = 2;
    public static final int ERROR = 0;
    public static final int SUCCESS = 1;
    //Restart slide to top animation time for ribben message
    public static final long SLIDE_TO_TOP_ANIMATION_TIME = 1000L;
    private static RibbenMessage ribbenMessage = null;
    private static Fragment fragment;
    private final Handler mHandler = new Handler();
    private View ribben;
    private int duration;
    private TimeOutListener listener;
    private Context context = null;
    private int type;
    private String message;
    private TextView messageTextView;
    private Runnable mHide = new Runnable() {

        @Override
        public void run() {

            if (listener != null
                    && ((fragment != null && fragment.isVisible() && fragment
                    .isMenuVisible()) || (fragment == null
                    && context != null && !((Activity) context).isFinishing()))) {
                //Sliding out to top animation for the Ribben message
                android.view.animation.Animation animation = AnimationUtils.loadAnimation(fragment.getActivity(), R.anim.slide_to_top);

                animation.setAnimationListener(new Animation.AnimationListener() {

                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        ribben.setVisibility(View.GONE);
                        listener.onTimeOut();
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });

                getRibben().startAnimation(animation);

            }
        }
    };

    private RibbenMessage(Context context) {
        this.context = context;
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ribben = inflater.inflate(R.layout.messge_ribben, null);
        ribben.requestFocus();
        messageTextView = (TextView) ribben.findViewById(R.id.messsage);
        //Defect-614 Start-Alignment of global error and edit payee success is not proper
        LinearLayout.LayoutParams param1 = (LinearLayout.LayoutParams) messageTextView.getLayoutParams();/*new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)*/;
        messageTextView.setPadding(dpToPx(16),18,0,16);
        messageTextView.setLayoutParams(param1);
        //Defect-614 End
        messageTextView.requestFocus();
    }

    //Defect-614 Start-Alignment of global error and edit payee success is not proper
    private int dpToPx(int dp)
    {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }
    //Defect-614 End

    public static RibbenMessage make(Activity activity, FrameLayout root,
                                     int message, int duration, int type) {

        return make(activity, root, message, duration, type, null);
    }

    public static RibbenMessage make(Fragment fragment, FrameLayout root,
                                     int message, int duration, int type, TimeOutListener listener) {

        ribbenMessage = make(fragment.getActivity(), root, message, duration,
                type, listener);
        ribbenMessage.setFragment(fragment);

        return ribbenMessage;
    }

    //US54329: Feature Transitions code changes start

    private static RibbenMessage make(final Context context, final FrameLayout root,
                                      final int message, final int duration, final int type, final TimeOutListener listener)
            throws RuntimeException {

        if (ribbenMessage == null) {
            ribbenMessage = new RibbenMessage(context);
            ribbenMessage.setDuration(duration);
            ribbenMessage.setTimeOutListener(listener);
            ribbenMessage.setRibbenType(type);
            ribbenMessage.setMessage(context.getString(message));
            ribbenMessage.messageTextView.setContentDescription(context.getString(message));
            if (!(ribbenMessage.getRibben().getParent() == root)) {
                root.addView(ribbenMessage.getRibben());
                //Sliding from top animation for the Ribben message
                android.view.animation.Animation animation = AnimationUtils.loadAnimation(context, R.anim.slide_from_top);
                ribbenMessage.getRibben().startAnimation(animation);

            } else {
                throw new RuntimeException(
                        "root layout isn't part of layout or may be null.");
            }
        }
        return ribbenMessage;

    }

    public static void purge() {
        if (ribbenMessage != null) {
            ribbenMessage.removeHandlerCallback();
            ribbenMessage = null;
        }
    }

    /**
     * Function will helpful to Pause the Animation when user is on mid-swipe of Pager viewer
     */
    public static void pauseAnimation() {
        if (ribbenMessage != null) {
            ribbenMessage.removeHandlerCallback();
        }
    }

    /**
     * Function will helpful to restart slide_to_top Animation when user completes the swipe event
     */
    public static void restartExitAnimation() {

        if (fragment != null && ribbenMessage != null) {
            //Initialize the animation object
            android.view.animation.Animation animation = AnimationUtils.loadAnimation(fragment.getActivity(), R.anim.slide_to_top);
            //set the offset to slide_to_top with some delay
            animation.setStartOffset(SLIDE_TO_TOP_ANIMATION_TIME);
            animation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    //Call the timeout listener of respective fragment to hide the layout
                    try {
                        //Kept on try catch since some cases ribbenMessage coming as null.
                        ribbenMessage.getTimeOutListener().onTimeOut();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            //Start the ribben message animation
            ribbenMessage.getRibben().startAnimation(animation);
        }
    }

    public static void destroyRibben() {
        if (ribbenMessage != null && ribbenMessage.getRibben() != null) {
            ribbenMessage.getRibben().setVisibility(View.GONE);
            ribbenMessage.purge();
        }

    }

    //US54329: Feature Transitions code changes end
    public void setMessage(String message) {
        this.message = message;
        messageTextView.setText(message);
        messageTextView.setContentDescription(message);
        messageTextView.requestFocus();
    }

    private void setFragment(Fragment fragment) {
        this.fragment = fragment;
    }

    public void show() {
        ribbenMessage.setVisibility(View.VISIBLE);

        mHandler.removeCallbacks(mHide);
        mHandler.postDelayed(mHide, getDurationInMillisec());
    }

    public int getRibbenType() {
        return type;
    }

    public void setRibbenType(int type) {
        this.type = type;
        messageTextView.setCompoundDrawablesWithIntrinsicBounds(getDrawable(type), null, null, null);
        messageTextView.setBackgroundColor(messageTextView.getResources().getColor(getColor(type)));
    }

    private int getColor(int type) {
        int rValue;
        switch (type) {
            case SUCCESS:
                rValue = R.color.onboard_bannr_success_color;
                break;
            case ERROR:
                rValue = R.color.onboard_bannr_error_color;
                break;
            default:
                rValue = R.color.onboard_bannr_success_color;
                break;
        }
        return rValue;
    }

    private Drawable getDrawable(int type) {
        Drawable rValue;
        switch (type) {
            case SUCCESS:
                rValue = context.getResources().getDrawable(R.drawable.onboard_success_global);
                break;
            case ERROR:
                rValue = context.getResources().getDrawable(R.drawable.onboard_error);
                break;
            default:
                rValue = context.getResources().getDrawable(R.drawable.onboard_success_global);
                break;
        }
        return rValue;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    private long getDurationInMillisec() {
        long millies;
        switch (duration) {
            case RibbenMessage.LENGTH_SHORT:
                millies = 2000L;
                break;
            case RibbenMessage.LENGTH_LONG:
                millies = 3000L;
                break;
            case RibbenMessage.LENGTH_EXTRA_LONG:
                millies = 5000L;
                break;
            default:
                millies = 3000L;
                break;
        }
        return millies;
    }

    public View getRibben() {
        return ribben;
    }

    public int getVisibility() {
        return ribben.getVisibility();
    }

    public void setVisibility(int visibility) {
        ribben.setVisibility(visibility);
    }

    public void dismiss() {
        ribben.setVisibility(View.GONE);
        purge();
    }

    private void removeHandlerCallback() {
        mHandler.removeCallbacks(mHide);
    }

    //US54329: Feature Transitions code changes start
    //Function to get the ribben message listener
    public TimeOutListener getTimeOutListener() {
        return listener;
    }

    public void setTimeOutListener(TimeOutListener listener) {
        this.listener = listener;
    }
    //US54329: Feature Transitions code changes end

    public interface TimeOutListener {
        public void onTimeOut();
    }

}