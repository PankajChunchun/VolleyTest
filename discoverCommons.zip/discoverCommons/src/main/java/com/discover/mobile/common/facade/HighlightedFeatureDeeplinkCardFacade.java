package com.discover.mobile.common.facade;

import com.discover.mobile.common.portalpage.beans.AccountV2Details;

/**
 * Deeplink facade for Highlighted-features and WhatsNew, which handles CARD deeplinks
 * for prelogin or postlogin.
 *
 * @author pkuma13
 */

public interface HighlightedFeatureDeeplinkCardFacade extends HighlightedFeatureDeeplinkFacade {
    public boolean isKillSwitchDisabled(String killSwitchText);
    public boolean isAnyCardUnderRLorFraudForSSO(AccountV2Details accountV2Details);
}