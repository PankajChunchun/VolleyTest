package com.discover.mobile.common.fingerprint.ui;

import com.discover.mobile.common.shared.net.NetworkRequestListener;

/**
 * Interactor for Fingerprint module.
 */
public interface FingerprintInteractor {
    void validatePasscodeAndSubmit(String passcode, final NetworkRequestListener listener);

    boolean isFingerprintRegisteronDevice();

    void setFingerPrintStatus(String passcode, boolean status, boolean isSuccess);

    boolean getFingerPrintStatus();
}
