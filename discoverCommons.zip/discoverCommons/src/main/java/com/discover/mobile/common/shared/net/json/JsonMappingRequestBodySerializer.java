package com.discover.mobile.common.shared.net.json;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import com.discover.mobile.common.shared.net.RequestBodySerializer;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class JsonMappingRequestBodySerializer implements RequestBodySerializer {

    @Override
    public boolean canSerialize(final Object body) {
        return body != null;
    }

    @Override
    public void serializeBody(final Object body, final OutputStream outputStream) throws IOException {
        if (body == null) {
            throw new AssertionError("cannot handle null bodies");
        }
        Gson gson = new GsonBuilder().enableComplexMapKeySerialization().disableHtmlEscaping().
                create();
        Writer writer = new OutputStreamWriter(outputStream);
        gson.toJson(body, writer);
        writer.close();
        //JacksonObjectMapperHolder.mapper.writeValue(outputStream, body);
    }

    @Override
    public String getContentType() {
        // TODO make named constant in more common location
        return "application/json";
    }

}
