package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Area implements Serializable {

    private static final long serialVersionUID = 425585194383645235L;

    @SerializedName("achAreaId")
    private String achAreaId;

    @SerializedName("reporterAreaId")
    private String reporterAreaId;

    @SerializedName("matchDelimitAreaId")
    private String matchDelimitAreaId;
    @SerializedName("matchAreaId")
    private String matchAreaId;
    @SerializedName("achBannerTierTwoAreaId")
    private String achBannerTierTwoAreaId;

    public String getAchCLIAreaID() {
        return achCLIAreaID;
    }

    @SerializedName("achBannerTierThreeAreaId")

    private String achBannerTierThreeAreaId;
    @SerializedName("achCLIAreaId")
    public String achCLIAreaID;
    /**
     * @return The achAreaId
     */
    public String getAchAreaId() {
        return achAreaId;
    }

    /**
     * @param achAreaId The achAreaId
     */
    public void setAchAreaId(String achAreaId) {
        this.achAreaId = achAreaId;
    }

    /**
     * @return The reporterAreaId
     */
    public String getReporterAreaId() {
        return reporterAreaId;
    }

    /**
     * @param reporterAreaId The reporterAreaId
     */
    public void setReporterAreaId(String reporterAreaId) {
        this.reporterAreaId = reporterAreaId;
    }

    public String getMatchDelimitAreaId() {
        return matchDelimitAreaId;
    }

    public String getMatchAreaId() {
        return matchAreaId;
    }

    public String getAchBannerTierTwoAreaId() {
        return achBannerTierTwoAreaId;
    }

    public String getAchBannerTierThreeAreaId() {
        return achBannerTierThreeAreaId;
    }
}
