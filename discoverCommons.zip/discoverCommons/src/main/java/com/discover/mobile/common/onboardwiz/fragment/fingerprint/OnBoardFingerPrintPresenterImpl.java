package com.discover.mobile.common.onboardwiz.fragment.fingerprint;

import com.discover.mobile.common.onboardwiz.interfaces.OnBoardFingerPrintInteractor;
import com.discover.mobile.common.onboardwiz.interfaces.OnBoardFingerPrintPresenter;
import com.discover.mobile.common.onboardwiz.interfaces.OnBoardFingerPrintUI;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;

/**
 * Created by 436645 on 11/1/2016.
 */
public class OnBoardFingerPrintPresenterImpl implements OnBoardFingerPrintPresenter {

    private OnBoardFingerPrintInteractor mOnBoardFingerPrintInteractor;
    private final OnBoardFingerPrintUI mOnBoardFingerPrintUI;

    public OnBoardFingerPrintPresenterImpl(OnBoardFingerPrintUI onBoardFingerPrintUI, OnBoardFingerPrintInteractor onBoardFingerPrintInteractor){
        mOnBoardFingerPrintInteractor = onBoardFingerPrintInteractor;
        mOnBoardFingerPrintUI = onBoardFingerPrintUI;
    }

    @Override
    public void enableFingerPrint() {
        if(this.mOnBoardFingerPrintInteractor.isFingerprintHardwareAvailable())
        {
            if(this.mOnBoardFingerPrintInteractor.isFingerPrintRegisteredOnDevice()) {
                if (this.mOnBoardFingerPrintInteractor.isPassCodeEnabled()) {
                    final boolean isFingerPrintEnabled = this.mOnBoardFingerPrintInteractor.enableFingerPrint();
                    if(isFingerPrintEnabled) {
                        this.mOnBoardFingerPrintUI.showPage(OnBoardConstant.FingerprintPageState.FINGERPRINT_ENABLED);
                        this.mOnBoardFingerPrintUI.showRibbenMessage();
                    }
                }else{
                    this.mOnBoardFingerPrintUI.showPage(OnBoardConstant.FingerprintPageState.PASSCODE_NOT_ENABLED);
                }
            }else {
                this.mOnBoardFingerPrintUI.showPage(OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_REGISTERED);
            }
       }
    }

    @Override
    public void exitSetUp() {
        this.mOnBoardFingerPrintInteractor.exitSetUp();
    }

    @Override
    public void onPageChanged() {

        final int currentPageState = mOnBoardFingerPrintUI.getCurrentPageState();
        final int previousPageState = mOnBoardFingerPrintUI.getPreviousPageState();

        if(currentPageState != previousPageState){
            if (currentPageState == OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED) {
                mOnBoardFingerPrintUI.showPage(OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED);
            }
            else if(currentPageState == OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_REGISTERED && mOnBoardFingerPrintInteractor.isFingerPrintRegisteredOnDevice()){
                mOnBoardFingerPrintUI.showPage(OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED);
            }
            else if(currentPageState == OnBoardConstant.FingerprintPageState.PASSCODE_NOT_ENABLED && mOnBoardFingerPrintInteractor.isPassCodeEnabled()){
                mOnBoardFingerPrintUI.showPage(OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED);
            }
        }
    }
}
