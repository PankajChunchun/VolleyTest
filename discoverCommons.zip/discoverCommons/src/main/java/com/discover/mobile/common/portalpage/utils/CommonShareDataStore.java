package com.discover.mobile.common.portalpage.utils;

import com.discover.mobile.common.DiscoverApplication;

import android.content.Context;

/**
 * Class to cache "Portal" page related data
 *
 * @author slende
 */
public class CommonShareDataStore {

    private static CommonShareDataStore commonShareDataStore;
    private final DiscoverApplication appCache;
    @SuppressWarnings("unused")
    private Context context;

    /**
     * constructor used for setting Application
     */
    private CommonShareDataStore(final Context context) {
        this.context = context;

        if (null != context)
            appCache = (DiscoverApplication) context.getApplicationContext();
        else
            appCache = null;

    }

    /**
     * This method returns the object of CommonShareDataStore
     *
     * @param context Context
     * @return CommonShareDataStore object
     */

    public static synchronized CommonShareDataStore getInstance(final Context context) {

        if (CommonShareDataStore.commonShareDataStore == null) {
            CommonShareDataStore.commonShareDataStore = new CommonShareDataStore(context);
        }

        return CommonShareDataStore.commonShareDataStore;
    }

    /**
     * This will allow to set shared variable
     */
    public void addToAppCache(final String key, final Object value) {

        appCache.setData(key, value);
    }

    /**
     * This will give the data mapped with particular key
     */
    public Object getValueOfAppCache(final String key) {
        return appCache.getData().get(key);
    }

    /**
     * This function clear whole cache.
     */
    public void clearCache() {
        appCache.clearCache();
    }

    /**
     * This will delete mapped cache object by sending key
     */
    public void deleteCacheObject(final String key) {
        appCache.deleteCacheObject(key);
    }

}
