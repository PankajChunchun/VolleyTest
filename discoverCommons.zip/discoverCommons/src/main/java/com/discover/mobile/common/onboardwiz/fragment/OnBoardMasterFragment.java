package com.discover.mobile.common.onboardwiz.fragment;

import com.discover.mobile.common.BaseMasterFragment;
import com.discover.mobile.common.R;

import android.support.v4.app.Fragment;


public class OnBoardMasterFragment extends BaseMasterFragment {

    @Override
    public int getSectionMenuLocationName() {
        return R.string.empty_message;
    }

    @Override
    public int getGroupMenuLocationName() {
        return R.string.empty_message;
    }

    @Override
    public int getActionBarTitle() {
        return R.string.empty_message;
    }

    @Override
    public void init() {

        showInLeftFrame(new OnBoardLandingFragment());
    }

    @Override
    public boolean onBackPressed() {
        if (handleBackPress())
            return true;
        return super.onBackPressed();
    }

    /*
    Delegates call back to current child fragment
     */
    private boolean handleBackPress() {
        final Fragment fragment = getChildFragmentManager().findFragmentById(R.id.left_frame);
        if (fragment instanceof OnBoardLandingFragment) {
            return true;
        } else if (fragment instanceof OnBoardPagerFragment) {
            return ((OnBoardPagerFragment) fragment).onBackPressed();
        } else if (fragment instanceof OnBoardConfirmationFragment) {
            return true;
        }
        return false;
    }
}
