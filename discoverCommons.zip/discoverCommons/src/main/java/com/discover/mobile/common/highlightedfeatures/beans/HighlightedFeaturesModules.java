package com.discover.mobile.common.highlightedfeatures.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * This modal contains highlighted feature and whats new details. Attributes are
 * common for Bank, card and SSO, so this is a common container for all three.
 *
 * @author pkuma13
 */
public class HighlightedFeaturesModules implements Serializable {

    @SerializedName("whatsnew")
    private ArrayList<String> whatsnew;

    @SerializedName("preLoginHighlightedFeature")
    private ArrayList<String> preLoginHighlightedFeature;

    @SerializedName("postLoginHighlightedFeature")
    private ArrayList<String> postLoginHighlightedFeature;

    public final ArrayList<String> getWhatsnew() {
        return whatsnew;
    }

    public final void setWhatsnew(ArrayList<String> whatsnew) {
        this.whatsnew = whatsnew;
    }

    public final ArrayList<String> getPreLoginHighlightedFeature() {
        return preLoginHighlightedFeature;
    }

    public final void setPreLoginHighlightedFeature(
            ArrayList<String> preLoginHighlightedFeature) {
        this.preLoginHighlightedFeature = preLoginHighlightedFeature;
    }

    public final ArrayList<String> getPostLoginHighlightedFeature() {
        return postLoginHighlightedFeature;
    }

    public final void setPostLoginHighlightedFeature(
            ArrayList<String> postLoginHighlightedFeature) {
        this.postLoginHighlightedFeature = postLoginHighlightedFeature;
    }
}