package com.discover.mobile.common.shared.net.json;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import com.discover.mobile.common.shared.net.NetworkServiceCall;
import com.discover.mobile.common.shared.net.ServiceCallParams;
import com.discover.mobile.common.shared.utils.CommonUtils;

import android.content.Context;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A {@link NetworkServiceCall} that handles mapping of unnamed list JSON requests and responses.
 *
 * @param <M> The <u>m</u>odel type for the JSON result
 * @param <V> The <u>I</u>nner type for the JSON result
 */
public abstract class UnamedListJsonResponseMappingNetworkServiceCall<M, I> extends JsonResponseGsonMappingNetworkServiceCall<M> {

    private static final String TAG = "UnamedListJsonResponseMapping";

    private final Class<I> innerClass;

    /**
     * JSON mapping service call used with the base url defaulted to card.
     */
    protected UnamedListJsonResponseMappingNetworkServiceCall(final Context context, final ServiceCallParams params,
                                                              final Class<M> modelClass, final Class<I> innerClass) {
        super(context, params, modelClass);
        CommonUtils.checkNotNull(modelClass, "modelClass cannot be null");

        this.innerClass = innerClass;
        Log.d(TAG, modelClass.toString());

    }


    @Override
    protected M parseSuccessResponse(final int status, final Map<String, List<String>> headers, final InputStream body)
            throws IOException {
        return super.parseSuccessResponse(status, headers, body);
    }

    /**
     * Parses an unnamed list and returns a list of the model class.
     *
     * @param body  - json body to parse
     * @param model - model class to map the objects to
     * @return a list of model obects
     */
    public List<I> parseUnamedList(final InputStream body)
            throws IOException {

        Gson converter = new GsonBuilder().create();
        Reader reader = new InputStreamReader(body);
        JsonParser jsonParser = new JsonParser();
        JsonArray jArray = jsonParser.parse(reader).getAsJsonArray();
        //JsonArray jsonArray = (JsonArray)jsonParser.parse(reader);

        ArrayList<I> lcs = new ArrayList<I>();

        for (JsonElement obj : jArray) {
            I cse = converter.fromJson(obj, innerClass);
            lcs.add(cse);
        }
        return lcs;
        /*final List<I> object = JacksonObjectMapperHolder.mapper.readValue(body, JacksonObjectMapperHolder.mapper.getTypeFactory().constructCollectionType(List.class, this.innerClass));
		return object;*/
    }
}
