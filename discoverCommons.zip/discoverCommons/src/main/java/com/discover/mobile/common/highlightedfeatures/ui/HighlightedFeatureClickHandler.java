package com.discover.mobile.common.highlightedfeatures.ui;


import com.discover.mobile.common.highlightedfeatures.beans.FeatureContent;

public interface HighlightedFeatureClickHandler {
    public void featureClicked(FeatureContent feature);

    public void featureClosed();
}
