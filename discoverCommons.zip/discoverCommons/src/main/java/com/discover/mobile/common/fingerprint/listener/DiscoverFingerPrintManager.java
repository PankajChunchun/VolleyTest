package com.discover.mobile.common.fingerprint.listener;

/**
 * Created by 548022 on 8/30/2016.
 * Interface to start/stop Identify fingerprint in respective implementation.
 * Each Implementation implements this Interface so creates type compatibility. So we store object of each implementation
 * in this Interface reference.
 */
public interface DiscoverFingerPrintManager {


    /**
     * Starts fingerprint authentication of respective helper i.e. google/samsung
     */
    void startListening();

    /**
     * Stops authentication process.
     */
    void stopListening();

}
