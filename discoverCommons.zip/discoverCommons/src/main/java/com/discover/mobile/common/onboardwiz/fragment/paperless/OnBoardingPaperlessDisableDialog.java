package com.discover.mobile.common.onboardwiz.fragment.paperless;

import com.discover.mobile.common.R;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Resources;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;


public class OnBoardingPaperlessDisableDialog extends AlertDialog {
    /** Declaration **/
    private View mView;
    private TextView mPaperlessEnrollTitle;
    private TextView mPaperlessEnrollBody;
    private WebView mPaperlessWebView;


    public OnBoardingPaperlessDisableDialog(final Context context) {
        super(context);

        mView = getLayoutInflater().inflate(
                R.layout.onboarding_paperless_dialog, null);

        /** Initializing views**/
        mPaperlessEnrollTitle = (TextView) mView.findViewById(R.id.modal_title);
        mPaperlessEnrollBody = (TextView) mView.findViewById(R.id.body_text);
        mPaperlessWebView = (WebView) mView.findViewById(R.id.onboard_paperless_webview);
        Resources resources = context.getResources();
        mPaperlessEnrollTitle.setText(resources.getString(R.string.onboard_paperless_disable_dlg_title));
        mPaperlessEnrollTitle.setContentDescription(resources.getString(R.string.onboard_paperless_disable_dlg_title));
        mPaperlessEnrollBody.setText(resources.getString(R.string.onboard_paperless_disable_dlg_text));
        mPaperlessEnrollBody.setContentDescription(resources.getString(R.string.onboard_paperless_disable_dlg_text));

        mPaperlessEnrollBody.setVisibility(View.VISIBLE);

        mPaperlessWebView.getSettings().setJavaScriptEnabled(true);
        //Loading dummy url, should load correct url once available
        mPaperlessWebView.loadUrl("https://asys-mapi.discoverbank.com/api/static/deposits/terms.html");
        mPaperlessWebView.setWebChromeClient(new WebChromeClient());

        mPaperlessWebView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(final WebView view, final String url) {
                super.onPageFinished(view, url);
                mPaperlessWebView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onReceivedSslError(final WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

        });

    }

   /* private void initView(){

    }*/

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(mView);
    }

    /** Getter method for accept button **/
    public Button getOkButton() {
        return (Button) mView.findViewById(R.id.modal_ok_button);
    }

    /** Getter method for cancel button **/
    public Button getCancelButton() {
        return (Button) mView.findViewById(R.id.modal_alert_cancel);
    }

    public void setOkButtonText(int text) {
        Button ok = (Button) mView.findViewById(R.id.modal_ok_button);
        ok.setText(text);
        ok.setContentDescription(getContext().getResources().getText(
                R.string.onboard_accept));
    }

    public void setCancelButtonText(int text) {
        Button cancel = (Button) mView.findViewById(R.id.modal_alert_cancel);
        cancel.setText(text);
        cancel.setContentDescription(getContext().getResources().getText(
                R.string.cancel_text));
    }

}

