package com.discover.mobile.common.facade;

import com.discover.mobile.common.onboardwiz.utils.BankOnBoardingCallBack;
import com.discover.mobile.common.shared.net.NetworkRequestListener;

import android.content.Context;

/**
 * Created to support the onBoarding wizard service classes
 */
public interface BankOnBoardActivityFacade {

    //Function to call GetPasscodeStatusServiceCallRetro from the common project
    void callGetPasscodeStatusServiceCallRetro(Context context, String deviceToken, BankOnBoardingCallBack callBack, NetworkRequestListener networkRequestListener);

    //Function to call BindDeviceServicecallRetro from the common project
    void callBindDeviceServicecallRetro(Context context, String deviceToken, boolean isUnbind, BankOnBoardingCallBack callBack);

    //Function to call ChangePasscodeServicecallRetro from the common project
    void callChangePasscodeServicecallRetro(Context context, String curretnPasscode, String newPasscode, String deviceToken, BankOnBoardingCallBack callBack);

    //Function to call CreatePasscodeServiceCallRetro from the common project
    void callCreatePasscodeServiceCallRetro(Context context, String passcodeString, String deviceToken, BankOnBoardingCallBack callBack);

    //Function to call ResetPasscodeServicecallRetro from the common project
    void callResetPasscodeServicecallRetro(Context context, String passcodeString, String deviceToken, BankOnBoardingCallBack callBack);

    //Function to call ValidateCandidatePasscodeServicecallRetro from the common project
    void callValidateCandidatePasscodeServicecallRetro(Context context, String passcodeString, String deviceToken, BankOnBoardingCallBack callBack);

    //Function to call VerifyCurrentPasscodeServiceCallRetro from the common project
    void callVerifyCurrentPasscodeServiceCallRetro(Context context, String passcodeString, BankOnBoardingCallBack callBack, NetworkRequestListener networkRequestListener);

    //Function to call QuickViewBindServiceCallRetro from the common project
    void callQuickViewBindServiceCallRetro(Context context, String deviceToken, BankOnBoardingCallBack callBack);

    //Function to call QuickViewAndUnbindServiceCallRetro from the common project
    void callQuickViewUnbindServiceCallRetro(Context context, String deviceToken, BankOnBoardingCallBack callBack);

    //Function to call GetQuickViewStatusServiceCallRetro from the common project
    void callGetQuickViewStatusServiceCallRetro(Context context, String deviceToken, BankOnBoardingCallBack callBack);

    //Function to call GetPaperlessServiceCallRetro from the common project
    void callGetPaperlessServiceCallRetro(Context context, String accountId, boolean paperlessState, BankOnBoardingCallBack callBack);


}
