package com.discover.mobile.common.portalpage.beans;

import java.io.Serializable;

/**
 * Bean class for Tier-1 type of error Messages
 */
public class TierOne extends DynamicMessageBean implements Serializable {


    public TierOne(Miscellaneous tierOneMiscellaneous) {

        this.setMessageActionCode(tierOneMiscellaneous.getMessageActionCode());
        this.setMessageTitle(tierOneMiscellaneous.getMessageTitle());
        this.setMessageContent(tierOneMiscellaneous.getMessageContent());
        this.setMessageDesc(tierOneMiscellaneous.getMessageDesc());
        this.setMessageSeverity(tierOneMiscellaneous.getMessageSeverity());
        this.setMessageKey((tierOneMiscellaneous.getMessageKey()));
        this.setMessageOrder((tierOneMiscellaneous.getMessageOrder()));

    }

    public TierOne() {

    }
}
