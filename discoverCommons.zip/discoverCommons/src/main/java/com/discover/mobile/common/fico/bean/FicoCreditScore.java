package com.discover.mobile.common.fico.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author slende
 */
public class FicoCreditScore implements Serializable {

    private static final long serialVersionUID = 8448505363556180636L;

    @SerializedName("currentScore")
    private int currentScore;
    @SerializedName("scoreDate")
    private String scoreDate;
    @SerializedName("optedIn")
    private boolean optedIn;
    @SerializedName("congratulationMessage")
    private String congratulationMessage;
    @SerializedName("scoreTooOld")
    private boolean scoreTooOld;

    @SerializedName("ficoScoreList")
    private List<FicoScoreList> ficoScoreList = new ArrayList<FicoScoreList>(12);

    public int getCurrentScore() {
        return currentScore;
    }

    public void setCurrentScore(int currentScore) {
        this.currentScore = currentScore;
    }

    public String getScoreDate() {
        return scoreDate;
    }

    public void setScoreDate(String scoreDate) {
        this.scoreDate = scoreDate;
    }

    public boolean isOptedIn() {
        return optedIn;
    }

    public void setOptedIn(boolean optedIn) {
        this.optedIn = optedIn;
    }

    public String getCongratulationMessage() {
        return congratulationMessage;
    }

    public void setCongratulationMessage(String congratulationMessage) {
        this.congratulationMessage = congratulationMessage;
    }

    public boolean isScoreTooOld() {
        return scoreTooOld;
    }

    public void setScoreTooOld(boolean scoreTooOld) {
        this.scoreTooOld = scoreTooOld;
    }

    public List<FicoScoreList> getFicoScoreList() {
        return ficoScoreList;
    }

    public void setFicoScoreList(List<FicoScoreList> ficoScoreList) {
        this.ficoScoreList = ficoScoreList;
    }

}
