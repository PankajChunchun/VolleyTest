package com.discover.mobile.common.onboardwiz.fragment.passcode;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.onboardwiz.fragment.OnBoardNavigationListener;
import com.discover.mobile.common.onboardwiz.fragment.fingerprint.OnBoardFingerprintFragment;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.onboardwiz.utils.RibbenMessage;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.CommonUtils;
import com.discover.mobile.common.shared.utils.image.ImageDir;
import com.discover.mobile.common.uiwidget.CmnTextView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.util.HashMap;

/**
 * Created by 409992 on 4/29/2016.
 */
public class OnBoardPasscodeSuccessFragment extends Fragment implements RibbenMessage.TimeOutListener {

    private final static String mPasscodeEnabledSubHeader1 = "onboard_passcode_confirmation";
    private final static String mPasscodeEnabledSubHeader2 = "onboard_passcode_post_confirmation";
    private View mView;
    private Context mContext;
    private CmnTextView txtPasscodeEnable, txtEnableCopy;
    private boolean isBannerVisible = true;
    private View spacingView;
    private ImageView imgPasscodeSuccess;
    private ImageView imgPasscodeEnableCheckMark;
    private static final String PASSCODEIMGSUCCESSTAG="passcodeSuccessImageEnable";
    private static final String PASSCODEIMGCONFIRMTAG="passcodeConfirmImageEnable";

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        mContext = activity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = LayoutInflater.from(mContext).inflate(R.layout.onboard_passcode_success, null);
        OnBoardPasscodeContainerFragment.updateState(OnBoardConstant.PASSCODE_PAGE_STATE.CONFIRMATION_PAGE);
        initUI(mView);


        if (isBannerVisible) {
            //US53328-START
            if (Globals.isFromCardSide()) {
                analyticsForPageLoad();
            }
            //ENDS
            showRibbenMessage();
        } else {

            //US53334 Start-OnBoarding analytics
            /*if (Globals.isBankLoginSelected()) {
                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        (R.string.bank_analytics_onboard_passcode_success));

                if(OnBoardBasePasscodeFragment.isResetFlow){
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put("my.eVar5","New_Setup_Passcode");
                    TrackingHelper.trackBankPage(null, extras);
                }else{
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put("my.eVar5","Existing_Setup_Passcode");
                    TrackingHelper.trackBankPage(null, extras);
                }
            }*/
            if (!OnBoardFingerprintFragment.isFpIntroPageEnable) {

                HashMap<String, Object> extras = new HashMap<String, Object>();
                {
                    if (((OnBoardPasscodeContainerFragment) getParentFragment()).isPasscodeEnabled()) {
                        extras.put(getActivity().getString(R.string.evar5), AnalyticsPage.ONBOARDWIZ_PASSCODE_SUCCESS_VAR5_EXISTING);
                    } else {
                        extras.put(getActivity().getString(R.string.evar5), AnalyticsPage.ONBOARDWIZ_PASSCODE_SUCCESS_VAR5_NEW);
                    }
                    TrackingHelper.trackBankPage(AnalyticsPage.ONBOARDWIZ_PASSCODE_SUCCESS_PAGE_NAME, extras);
                }
                //US53334 End
            }
            showSuccessViews();
            OnBoardFingerprintFragment.isFpIntroPageEnable = false;
        }
        return mView;
    }

    public void updateSuccessView() {
        isBannerVisible = false;
        RibbenMessage.destroyRibben();


    }

    private void showSuccessViews() {

       /* //US53328
        analyticsForPasscodeStepComplete();
        //END*/
    /*
    The method gets called once the banner is dismissed to user enables the passcode
    */
        OnBoardPasscodeContainerFragment.updateState(OnBoardConstant.PASSCODE_PAGE_STATE.PASSCODE_DONE_PAGE);
        imgPasscodeEnableCheckMark.setVisibility(View.VISIBLE);
        txtEnableCopy.setVisibility(View.VISIBLE);
        spacingView.setVisibility(View.GONE);
        imgPasscodeSuccess.setTag(PASSCODEIMGCONFIRMTAG);
        Log.v("PasscodeConfirmImage",imgPasscodeSuccess.getTag().toString());
        OnBoardHelper.visiblityForExitButton(getActivity(), true);
        CommonUtils.setDisplayText(txtPasscodeEnable, mPasscodeEnabledSubHeader2, getResources().getString(R.string.onboard_passcode_success_immediate_copy));
    }

    private void initUI(View v) {
        imgPasscodeEnableCheckMark = (ImageView) v.findViewById(R.id.check_mark);
        imgPasscodeSuccess = (ImageView) v.findViewById(R.id.imageView2);
        imgPasscodeSuccess.setTag(PASSCODEIMGSUCCESSTAG);
        Log.v("PasscodeSucessImage",imgPasscodeSuccess.getTag().toString());

        txtPasscodeEnable = (CmnTextView) v.findViewById(R.id.txt_passcode_enable);
        CommonUtils.setDisplayText(txtPasscodeEnable, mPasscodeEnabledSubHeader1, getResources().getString(R.string.onboard_passcode_success_view));
        txtEnableCopy = (CmnTextView) v.findViewById(R.id.passcode_enable_text);
        txtEnableCopy.setVisibility(View.INVISIBLE);
        spacingView = mView.findViewById(R.id.passcode_space_view);
        SpannableString spannableString = new SpannableString(
                txtEnableCopy.getText());
        spannableString.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.cmn_orange)), 0,
                8, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        txtEnableCopy.setText(spannableString);
        hideKeyboard();
        setUpImageForPasscode();
    }

    /*
    Displays a ribben message on top of screen with success message
     */
    private void showRibbenMessage() {
        OnBoardHelper.hideExitButton(getActivity());
        //US53334 Start-OnBoarding analytics
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(
                    (R.string.bank_analytics_onboard_passcode_enabled));

        }
        //US53334 End
        FrameLayout layout = (FrameLayout) mView.findViewById(R.id.passcode_success_main_view);
        //US123063, banner message was not getting displayed when user enter the correct passcode after an unsuccessful attempt
        RibbenMessage.purge();
        RibbenMessage.make(this, layout, R.string.onboard_ribben_enable, RibbenMessage.LENGTH_EXTRA_LONG, RibbenMessage.SUCCESS, this).show();
    }

    /*
        This methods gets call when the banner timeout callback is called. It takes the user to next page
     */
    @Override
    public void onTimeOut() {

        Fragment fragment = OnBoardHelper.getCurrentChildFragment(getActivity().getSupportFragmentManager().findFragmentById(R.id.contentView));
        if (fragment instanceof OnBoardNavigationListener) {
            OnBoardHelper.mQuickvieweAnim = true;
            ((OnBoardNavigationListener) fragment).moveToNextPage();
        }
        showSuccessViews();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getActivity().getWindow().getDecorView().getRootView().getWindowToken(), 0);
    }

    /*
    Show different image for Bank and Card
     */
    private void setUpImageForPasscode() {
        Bitmap defaultBitmap = null;
        String imageName = null;
        if (Globals.isBankLoginSelected()) {
            //bank login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_passcode_bank);
            imageName = "onboard_passcode_bank.png";
        } else {
            //card login
            defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.onboard_landing);
            imageName = "onboard_landing.png";
        }
        CommonUtils.setBitmapImage(imgPasscodeSuccess, ImageDir.DIR_ENUM.ONBOARDING, imageName, defaultBitmap);

        // Drawable passcodeDrawable = ResourcesCompat.getDrawable(getResources(), Globals.isBankLoginSelected() ? R.drawable.onboard_passcode_bank : R.drawable.onboard_landing, null);
        //imgPasscodeSuccess.setImageDrawable(passcodeDrawable);
    }


    //US53328-START

    public void analyticsForPageLoad() {


        HashMap<String, Object> extras = new HashMap<String, Object>();

        {
            if (((OnBoardPasscodeContainerFragment) getParentFragment()).isPasscodeEnabled()) {
                extras.put(getActivity().getString(R.string.evar5), AnalyticsPage.ONBOARDWIZ_PASSCODE_SUCCESS_VAR5_EXISTING);
            } else {
                {
                    extras.put(getActivity().getString(R.string.evar5), AnalyticsPage.ONBOARDWIZ_PASSCODE_SUCCESS_VAR5_NEW);
                }
            }


            TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_PASSCODE_SUCCESS_PAGE_NAME, extras);


        }
    }

    public void analyticsForPasscodeStepComplete() {
        TrackingHelper.trackCardPage(AnalyticsPage.ONBOARDWIZ_PASSCODE_SETUP_COMPLETE_PAGE_NAME, null);


    }

    //END
}
