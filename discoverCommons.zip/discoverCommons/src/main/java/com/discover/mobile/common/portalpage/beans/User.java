package com.discover.mobile.common.portalpage.beans;

/**
 * Created by 436645 on 1/31/2017.
 */
public class User {
    private String mAccountListOrder;
    private String mPasscodeToken;
    private String mUserId;
    private static User sUser = new User();

    private User(){}

    public static User getInstance(){
        if(sUser == null)
            sUser = new User();
        return sUser;
    }

    public String getOrder() {
        return mAccountListOrder;
    }

    public void setOrder(String mOrder) {
        this.mAccountListOrder = mOrder;
    }

    public String getPasscodeToken() {
        return mPasscodeToken;
    }

    public void setPasscodeToken(String mPasscodeToken) {
        this.mPasscodeToken = mPasscodeToken;
    }

    public String getUserId() {
        return mUserId;
    }

    public void setUserId(String mUserId) {
        this.mUserId = mUserId;
    }

    public void resetUser(){
        sUser = null;
    }
}
