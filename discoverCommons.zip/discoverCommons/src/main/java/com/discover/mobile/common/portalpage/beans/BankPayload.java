package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Payload received from Card endpoint used to authenticate an SSO user on Bank.
 *
 * @author CTS
 */
public class BankPayload implements Serializable {

    /** generated serial id */
    private static final long serialVersionUID = 1120551241724746805L;

    @SerializedName("payloadText")
    public String payload;
}