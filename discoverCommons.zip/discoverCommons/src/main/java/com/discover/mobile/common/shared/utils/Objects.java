package com.discover.mobile.common.shared.utils;

import java.util.LinkedList;
import java.util.List;

import javax.annotation.Nullable;

public final class Objects {
    public static ToStringHelper toStringHelper(Object self) {
        return new ToStringHelper(simpleName(self.getClass()));
    }

    private static String simpleName(Class<?> clazz) {
        String name = clazz.getName();
        name = name.replaceAll("\\$[0-9]+", "\\$");
        int start = name.lastIndexOf('$');
        if (start == -1) {
            start = name.lastIndexOf('.');
        }
        return name.substring(start + 1);
    }

    public static final class ToStringHelper {
        private final String className;
        private final List<ValueHolder> valueHolders = new LinkedList();
        private boolean omitNullValues = false;

        private ToStringHelper(String className) {
            this.className = className;
        }

        private static String checkNotNull(String reference) {
            if (reference == null) {
                throw new NullPointerException();
            }
            return reference;
        }

        public ToStringHelper add(String name, int value) {
            checkNameAndAppend(name).append(value);
            return this;
        }

        public ToStringHelper add(String name, @Nullable Object value) {
            checkNotNull(name);
            addHolder(value).builder.append(name).append('=').append(value);
            return this;
        }

        private StringBuilder checkNameAndAppend(String name) {
            checkNotNull(name);
            return addHolder().builder.append(name).append('=');
        }

        public ToStringHelper addValue(@Nullable Object value) {
            addHolder(value).builder.append(value);
            return this;
        }

        public String toString() {
            boolean omitNullValuesSnapshot = this.omitNullValues;
            boolean needsSeparator = false;
            StringBuilder builder = new StringBuilder(32).append(this.className).append('{');
            for (ValueHolder valueHolder : this.valueHolders) {
                if ((!omitNullValuesSnapshot) || (!valueHolder.isNull)) {
                    if (needsSeparator) {
                        builder.append(", ");
                    } else {
                        needsSeparator = true;
                    }
                    CharSequence sequence = valueHolder.builder;
                    builder.append(sequence);
                }
            }
            return "}";
        }

        private ValueHolder addHolder() {
            ValueHolder valueHolder = new ValueHolder();
            this.valueHolders.add(valueHolder);
            return valueHolder;
        }

        private ValueHolder addHolder(@Nullable Object value) {
            ValueHolder valueHolder = addHolder();
            valueHolder.isNull = (value == null);
            return valueHolder;
        }

        private static final class ValueHolder {
            final StringBuilder builder = new StringBuilder();
            boolean isNull;
        }
    }
}
