/**
 * Copyright Solstice-Mobile 2013
 */
package com.discover.mobile.common.facade;

import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.shared.net.NetworkRequestListener;
import com.discover.mobile.common.ui.CardInfoForToggle;
import com.liveperson.messaging.sdk.api.callbacks.LogoutLivePersonCallback;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;

/**
 * A facade for assisting with general card activities
 *
 * @author ekaram
 */
public interface CardFacade {

    /**
     * Navigates to the register activity
     */
    public void navToRegister(Context callingActivity);

    /*2. Removed as per US60514 */
    /*public boolean fastcheckTokenExists(Context callingActivity);*/
     /*4. Removed as per US60514 */
/*	public boolean mopTokenExists(Context callingActivity);*/

    // Defect id 97126

    /**
     * Navigates to the provide feedback
     */
    public void navToProvideFeedback(Context callingActivity);

    // Defect id 97126

    /**
     * Navigates to the forgot activity
     */
    public void navToForgot(Context callingActivity);

    /**
     * Launches the card home fragment
     */
    /*1. Removed as per US60514 */
/*	public void navToHomeFragment(Activity callingActivity);*/

    /**
     * Returns the card error handler for use by calling activity classes
     */
    public ErrorHandler getCardErrorHandler();

    /**
     * Returns the url for preauth
     */
    public String getPreAuthUrl();

    /**
     * Returns the card base url for preauth
     */
    public String getPreAuthBaseUrl();


    /**
     * Returns the card information used to populate the Account Toggle widget.
     */
    public CardInfoForToggle getCardInfoForToggle(Context context);

    // 16/Aug/2013---Observation Fixed

    /**
     * Navigates to the privacy terms
     */
    public void navToPrivacyTerms(Context context);

    public void navToGeofencePlotter(Context context);

    /* 14.1 Prelogin MOP1B Start */
    public void navToMop1bActivity(Activity context);

    public void navToMop1dActivity(Activity callingActivity);

	/* 14.1 Prelogin MOP1B End */

    public void setCardBaseUrl(String aCardBaseUrl, String ipAddress);

    /*2. Removed as per US60514 */
    /*public Class getMopImageDownLoaderInstance();*/

    public void refreshFastcheckFragment(Fragment frag, Context context);

    public boolean getQuickViewEnabledState(Fragment frag, Context context);

    /**
     * Method to return Card Base url; Added for 6.7 Portal Release
     */
    public String getCardBaseUrl();

    /**
     * Method to return Card side Prod url; Added for 6.7 Portal Release
     */
    public String getCardProdUrl();

    /**
     * Navigates to the register activity
     */
    public void navToRegisterFromHelp(Context callingActivity);

    public void navToCreateUserID(Context context);

    public String getCardProductGroupCode(Context context);

    public void initCookieManager(Context context);


    public void callGeofenceServiceToAdd(Context context);

    public void callGeofenceServiceToRemove(Context context);

    public void setupFastCheckFrag(Context context, String encryptedToken);

    public void shouldShowWizard(Context context);

    public String getWidgetBaseUrl();

    public void updateReminderCount(Context context, String featureName);

    public void navToRegisterFromJointErrorModel(Context callingActivity);

    public String isSupportedRdLink(String key);

    public void setRdDeeplink(String key, Context ctx);

    public void startPageTimer(Context context);

    /**
     * Added for US38219 & US47049 CLA merge intercept page
     */
    public void invokeBBRedirect(Context baseActivity, String deepLinkCode);

    public void getCardDetails(Context context,final NetworkRequestListener listener);

    /** Start changes for US70151*/
    public void navToHomeFromFingerPrint(Context context);

    public void navToPasscode(Context context);

    public void updateProfileSettingFingerPrintStatus(boolean isSuccess, String userid, Context context);
    /** End changes for US70151*/

    /** start Fingerprint deep-link added for US71608 - Shake modal, whats new & reminder page */
    public void setFingerprintSetupDeeplink(Context context);
    /**end Fingerprint deep-link added for US71608 - Shake modal, whats new & reminder page */

    /** start added for US83286  - Android Fingerprint - Kill-switch */
    public boolean isKillSwitchDisabled(String killSwitchValue);

    /** end added for US83286  - Android Fingerprint - Kill-switch */

    // Added for fixing defect# 125
    public void updatePasscodeSettings(Context context, boolean isPasscodeEnabled);

    /**
     * Method to clear Card side cache data; need to call before "account" call
     */
    public void clearCardCacheData(Activity activity);

    /*US91113 QUICK VIEW retro migration*/
    public void pushDataToBankQVWidgetProvider(String dataHolder,Object obj);

    public void setDeeplink(String key, Context ctx);

    void logOutFromLPSDK(Context context, LogoutLivePersonCallback logoutLivePersonCallback);

    boolean isEDSKeyMatching(String key);

    void handleAppMessagingDeeplink(DiscoverBaseActivity baseActivity);

    void initWalletEligibilityCheck();
}
