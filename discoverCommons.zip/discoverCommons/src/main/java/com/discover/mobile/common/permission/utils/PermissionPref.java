package com.discover.mobile.common.permission.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * <p>
 * Preferences for Permission modal. This class is designed to store permission dialog status.
 * </p>
 *
 * @author pkuma13 on 9/1/2016.
 */
public class PermissionPref {
    private static final String PREFERENCE_NAME = "permission_prefs";
    private final SharedPreferences preferences;
    private static PermissionPref sInstance;

    private PermissionPref(Context context) {
        this.preferences = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized PermissionPref getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new PermissionPref(context);
        }
        return sInstance;
    }

    /**
     * <p>Check if OS permission modal has been blocked by user. If user checks "Never Ask Again"
     * and "Deny" permission dialog, then OS will never show permission dialog for specific
     * permission. This state is BLOCKED state.</p>
     *
     * <p>This API stores {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions}
     * specific flags to indicate that if the permission dialog for that particular {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions}
     * has been blocked by user.</p>
     *
     * <p><b>
     *     OS does not reset its own flags when application is killed by any case, as it does on either clear data or resting permission status from application settings.
     * </b>So this flag will useful to persist Blocked state of OS permission dialog</p>
     * @param permission - {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions}
     * @return <code>true</code> if {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions} is blocked by user,
     *  otherwise returns <code>false</code>.
     */
    public boolean isPermissionDialogBlocked(PermissionConstant.Permissions permission) {

        return this.preferences.getBoolean(permission.toString(), false);
    }

    /**
     * Resets blocked state of OS permission modal.
     * @param permission - {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions}
     * @param blocked - It should be <code>true</code> if {@link com.discover.mobile.common.permission.utils.PermissionConstant.Permissions} is blocked by user,
     *  otherwise <code>false</code>.
     */
    public void resetPermissionDialogBlocked(PermissionConstant.Permissions permission, boolean blocked) {

        this.preferences.edit().putBoolean(permission.toString(), blocked).commit();
    }
}