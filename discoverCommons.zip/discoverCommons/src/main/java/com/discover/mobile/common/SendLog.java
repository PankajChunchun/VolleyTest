package com.discover.mobile.common;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Class for sending crash report through mail
 *
 * @author 388402
 */
public class SendLog extends Activity {

    View mView;
    String value;
    StackTraceElement[] arr;
    String logTxt;
    String[] emailIDArray;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        logTxt = (String) getIntent().getExtras().getSerializable("CrashLogData");
        emailIDArray = getResources().getStringArray(R.array.email_list);
        sendLogFile();
    }


    private void sendLogFile() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("plain/text");
        intent.putExtra(Intent.EXTRA_EMAIL, emailIDArray);
        intent.putExtra(Intent.EXTRA_SUBJECT, "Crash Report");
        intent.putExtra(Intent.EXTRA_TEXT, logTxt);

        startActivity(Intent.createChooser(intent, "Send mail..."));

        finish();
    }

}

