package com.discover.mobile.common.highlightedfeatures.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import com.discover.mobile.common.Utils;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.highlightedfeatures.beans.FeatureContent;
import com.discover.mobile.common.highlightedfeatures.beans.HFImage;
import com.discover.mobile.common.highlightedfeatures.beans.HFImageUrlContent;
import com.discover.mobile.common.highlightedfeatures.beans.HighlightedFeaturesData;
import com.discover.mobile.common.highlightedfeatures.ui.HighlightedFeaturePreLoginActivity;
import com.discover.mobile.common.highlightedfeatures.ui.HighlightedFeaturesLandingFragment;
import com.discover.mobile.common.nav.DiscoverBaseActivity;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.beans.CardAccount;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.image.FileCache;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A Utility class which handles Highlighted-feature and Whats-new features.
 *
 * @author pkuma13
 */
public final class HFUtils {

    public static final String USER_ELIGIBLE_ANDROIDPAY = "isusereligibleforandroidpay";
    public static final String USER_ELIGIBLE_SAMSUNGPAY = "isusereligibleforsamsungpay";
    public static final String IS_CARD_ALREADYADDED_INSAMSUNGPAY = "iscardalreadyaddedsamsungpay"  ;
    private static final String ANDROID_PAY_INDENTIFIER = "AndroidPay";
    private static final String SAMSUNG_PAY_INDENTIFIER = "SamsungPay";
    private static final String FINGERPRINT_INDENTIFIER = "Fingerprint Login";
    private static final String PORTAL_PAGE_DP = "linkToPortalPage";
    public final static String ANDROID_PAY = "com.google.android.apps.walletnfcrel";
    private static final String TAG = HFUtils.class.getSimpleName();
    private static final String FICO_INDENTIFIER = "linktofico";
   // private static final int SPAY_NOT_INSTALLED = 2222;

    private HFUtils() {
        throw new UnsupportedOperationException("Cannot instantiate the type " + HFUtils.class.getSimpleName());
    }

    /**
     * @return File name, which will be postfixed by current version number of application.
     */
    public static String getFileNameOnServer(Context context) {
        String version = null;

        if(!Globals.getAppVersion().isEmpty()&&Globals.getAppVersion()!=null)
        {
            version = Globals.getAppVersion();
        }
        else
        {
            try {
                version = context.getPackageManager().getPackageInfo(context.getApplicationContext().getPackageName(), 0).versionName;

            } catch (PackageManager.NameNotFoundException e) {

            }
        }
        version = version.replace(".", "");


        return HFConstants.FILE_NAME_PREFIX + version + HFConstants.FILE_EXTENSION;
    }

    public static final HighlightedFeaturesData getHFFeatureFromPref(Context context) {
        Gson gson = new Gson();
        HighlightedFeaturesData hfData = null;
        try {
            hfData = gson.fromJson(new HFPref(context).getJsonString(), HighlightedFeaturesData.class);
        } catch (Exception e) {
            Log.d(TAG, "Exception ==>" + e.getMessage());
        }

        return hfData;
    }

    /*public boolean isDeviceAllowed(String device) {
        return listContainsIgnoreCase(this.supportedDevices, device);
    }

    public boolean isCardTypeAllowed(String cardType) {
        return listContainsIgnoreCase(this.supportedCardTypes, cardType);
    }

    public boolean isVersionAllowed(String version) {
        return listContainsIgnoreCase(this.supportedVersions, version);
    }*/


    /**
     * Exclusion based comparison on list of cards and current card type.
     */
    public static boolean isFeatureAvailableForCurrentUserCard(boolean isPrelogin, FeatureContent item, String currentCardType) {
        // Logic for card not supported.
        if (isPrelogin == true) {
            // For prelogin no check for card type. Each HF will be applicable.
            return true;
        }

        ArrayList<String> nonSupportedTypes = item.getNonSupportedCardTypes();
        ;

        if ((nonSupportedTypes == null) || (nonSupportedTypes.isEmpty()) || (currentCardType == null)) {
            // Such cases, feature is enabled for any card type.
            return true;
        }
        for (String supportedType : nonSupportedTypes) {
            if (currentCardType.equalsIgnoreCase(supportedType)) {
                // Card type is into not supported list.
                // This feature should not allowed to current user.
                return false;
            }
        }
        return true;
    }

    /**
     * Exclusion based comparison on list of Bank types
     */
    public static boolean isFeatureAvailableForCurrentUserBank(boolean isPrelogin, FeatureContent item, ArrayList<String> bankTypes) {
        // Logic for card not supported.
        if (isPrelogin == true) {
            // For prelogin no check for card type. Each HF will be applicable.
            return true;
        }

        ArrayList<String> nonSupportedTypes = item.getNonSupportedBankTypes();
        if ((nonSupportedTypes == null) || (nonSupportedTypes.isEmpty()) || (bankTypes == null)) {
            // Such cases, feature is enabled for any card type.
            return true;
        }

        for (String currentBankType : bankTypes) {
            for (String supportedType : nonSupportedTypes) {
                if (currentBankType.equalsIgnoreCase(supportedType)) {
                    // Bank type is into not supported list.
                    // This feature should not allowed to current user.
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Check if current device is allowed to see this feature.
     *
     * @param hfImage {@link com.discover.mobile.common.highlightedfeatures.beans.HFImage}
     */
    public static boolean isDeviceAllowed(Context context, HFImage hfImage) {
        if (Utils.isRunningOnHandset(context) && (hfImage.getHandset() != null)) {
            // Running on handset and JSON has image for handset.
            return true;
        } else if ((Utils.isRunningOnHandset(context) == false) && (hfImage.getTablet() != null)) {
            // Running on Tablet and JSON has image for Tablet.
            return true;
        }
        // In any other case, this device is not allowed to see the feature
        return false;
    }

    public static boolean listContainsIgnoreCase(List<String> list, String value) {
        //since this is based off exclusions and not inclusions, allow null values
        if (value == null) {
            return true;
        }

        for (String item : list) {
            if (value.equalsIgnoreCase(item)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Read json from Asset directory and write it into preferences.
     */
    public static void handleServiceErrorOfHFjson(Context context) {
        HFPref pref = new HFPref(context);
        String jsonFromAsset = loadJSONFromAsset(context);
        pref.setJsonString(jsonFromAsset);
    }

    private static String loadJSONFromAsset(Context context) {
        String json = null;
        try {
            InputStream is = context.getAssets().open("HF_Android.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }

        try {
            JSONObject object = new JSONObject(json);
        } catch (Exception e) {
            Log.e(TAG, "Error while reading JSON FROM ASSETS.");
        }

        return json;
    }

    /**
     * Method to delete old HF & what's new images from SDCARD
     * Ref : Fix for defect # 195068
     */
    public static void deleteOldHFImages(List<FeatureContent> features, Context context) {
        if (null != features) {
            FileCache fileCache = new FileCache(context);
            fileCache.clear();
        }
    }

    /**
     * Account type specific image url. It creates url with account-type, orientation, density.
     *
     * @return - Highlighted-feature or What's-new Image url with account specific base url.
     */
    public static String getImageUrl(Context context, FeatureContent featureContent, String currentOrientation, boolean isCardSelected) {
        if (featureContent == null) {
            return "";
        }

        HFImageUrlContent urlContent = null;
        if (Utils.isRunningOnHandset(context)) {
            urlContent = featureContent.getAndroidImageUrls().getHandset();
        } else {
            urlContent = featureContent.getAndroidImageUrls().getTablet();
        }

        if ((urlContent == null) ||
                (urlContent.getDensities().size() == 0) ||
                (urlContent.getOrientations().size() == 0) ||
                (urlContent.getOrientations().contains(currentOrientation) == false)) {
            return "";
        }

        StringBuilder imageUrl = new StringBuilder();
        // Only one json is applicable for BANK and CARD
        imageUrl.append(FacadeFactory.getCardFacade().getCardBaseUrl());

        String deviceDensity = getDensityName(context.getResources().getDisplayMetrics().density, urlContent.getDensities());
        imageUrl.append(urlContent.getBaseUrl())
                .append("/")
                .append(deviceDensity)
                .append("/")
                .append(currentOrientation)
                .append("/");

        // Append card type if flag is true for account specific images
        if ((featureContent.isAccountSpecificImages() == true) && (isCardSelected == true)) {
            // Get value of card type. In current no HF or Whats new into Bank which needs type into url.
            // In card, only AndroidPay uses card-type specific images.
            String cardGrpCode = FacadeFactory.getCardFacade().getCardProductGroupCode(context);
            imageUrl.append(getCardType(cardGrpCode)).append("/");
        }

        imageUrl.append(urlContent.getName());
        return imageUrl.toString();
    }

    private static boolean isSupportedOnDevice(Context context, FeatureContent featureContent) {
        List<String> supportedDev = featureContent.getSupportedDevices();
        String actualDev = Utils.isRunningOnHandset(context) ? "AndroidHandset" : "AndroidTablet";
        if (supportedDev != null && supportedDev.size() > 0) {
            for (String deviceType : supportedDev) {
                if (deviceType.equals(actualDev)) return true;
            }
        }
        return false;
    }

    public static String getDensityName(double densityVal, List<String> densities) {
        ArrayList<Double> densityList = getSupportedDensitiesOrdered(densities);
        Double usableDensity = getDensityValueToUse(densityVal, densityList);
        return getDensityNameFromValue(usableDensity, densities);
    }

    private static String getDensityNameFromValue(double densityVal, List<String> densities) {
        String density = densities.get(0);
        if (densityVal == 4) {
            density = HFConstants.Density.XXXHDPI;
        } else if (densityVal == 3) {
            density = HFConstants.Density.XXHDPI;
        } else if (densityVal >= 2) {
            density = HFConstants.Density.XHDPI;
        } else if (densityVal == 1.5) {
            density = HFConstants.Density.HDPI;
        } else if (densityVal == 1) {
            density = HFConstants.Density.MDPI;
        } else if (densityVal == 0.75) {
            density = HFConstants.Density.LDPI;
        }
        return density;
    }

    private static ArrayList<Double> getSupportedDensitiesOrdered(List<String> densities) {
        ArrayList<Double> densityList = new ArrayList<Double>();
        for (String density : densities) {
            Double val = HFConstants.DENSITY_MAP.get(density);
            if (val != null) {
                densityList.add(val);
            }
        }
        Collections.sort(densityList);
        return densityList;
    }

    private static double getDensityValueToUse(double densityVal, ArrayList<Double> densityList) {
        for (int i = 0; i < densityList.size(); i++) {
            if (densityVal == densityList.get(i)) {
                return densityVal;
            } else if (densityVal < densityList.get(i)) {
                return densityList.get(i);
            }
        }
        //density must be larger than largest item
        return densityList.get(densityList.size() - 1);
    }

    /*
     * Method to return card type from group code
     * @param String cardProductGroupCode
     * return card type
     */
    private static String getCardType(String cardProductGroupCode) {

        String cardType = null;
        if (HFConstants.CardType.DIT.equals(cardProductGroupCode)
                || HFConstants.CardType.MOR.equals(cardProductGroupCode)
                || HFConstants.CardType.MTV.equals(cardProductGroupCode)
                || HFConstants.CardType.OPR.equals(cardProductGroupCode)
                || HFConstants.CardType.DIG.equals(cardProductGroupCode)) {
            cardType = HFConstants.CardType.GROUP_IT;
        } else if (HFConstants.CardType.DIM.equals(cardProductGroupCode)
                || HFConstants.CardType.MLS.equals(cardProductGroupCode)
                || HFConstants.CardType.ESC.equals(cardProductGroupCode)) {
            cardType = HFConstants.CardType.GROUP_MILES;
        } else if (HFConstants.CardType.ESN.equals(cardProductGroupCode)
                || HFConstants.CardType.ESF.equals(cardProductGroupCode)) {
            cardType = HFConstants.CardType.GROUP_ESSENTIAL;
        }
        return cardType;
    }

    /**
     * Retrieve Highlighted feature content.
     *
     * @param highlightedFeaturesData - {@link com.discover.mobile.common.highlightedfeatures.beans.HighlightedFeaturesData}
     * @param loginType               - {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     * @param isPrelogin              - <code>true</code> if pre-login, <code>false</code> for
     *                                post-login.
     */
    // Note as of version 7.3, this method only returns card highlighted features.
    public static ArrayList<FeatureContent> getHighlightedFeaturesList(Context context, HighlightedFeaturesData highlightedFeaturesData,
                                                                       HFConstants.LoginType loginType, boolean isPrelogin) {
        ArrayList<FeatureContent> result = new ArrayList<FeatureContent>();
        if (highlightedFeaturesData == null) {
            // Return empty array list.
            return result;
        }

        // Retrieve feature keys from CARD/ BANK/ SSO type
        ArrayList<String> featuresKeys = null;
        if (loginType == HFConstants.LoginType.CARD) {
            featuresKeys = isPrelogin ? highlightedFeaturesData.getCard().getPreLoginHighlightedFeature() : highlightedFeaturesData.getCard().getPostLoginHighlightedFeature();
        } else if (loginType == HFConstants.LoginType.BANK) {
            featuresKeys = isPrelogin ? highlightedFeaturesData.getBank().getPreLoginHighlightedFeature() : highlightedFeaturesData.getBank().getPostLoginHighlightedFeature();
        } else if (loginType == HFConstants.LoginType.SSO) {
            featuresKeys = isPrelogin ? highlightedFeaturesData.getSso().getPreLoginHighlightedFeature() : highlightedFeaturesData.getSso().getPostLoginHighlightedFeature();
        } else {
            // Default is CARD. This needs to be updated.
            featuresKeys = isPrelogin ? highlightedFeaturesData.getCard().getPreLoginHighlightedFeature() : highlightedFeaturesData.getCard().getPostLoginHighlightedFeature();
        }

        String cardGrpCode = "";
        if (isPrelogin == false) {
            // Get card type only for Post login
            cardGrpCode = FacadeFactory.getCardFacade().getCardProductGroupCode(context);
        }
        // Retrieve feature list using featureKeys
        for (String key : featuresKeys) {
            FeatureContent featureContent = highlightedFeaturesData.getFeatures().get(key);
            if (featureContent != null) {
                // Check if this applicable feature
                if (isFeatureAllowedInCard(context, featureContent, cardGrpCode, isPrelogin)
                        && isSupportedOnDevice(context, featureContent)) {
                    featureContent.setApplyToCardSide(true);
                    result.add(featureContent);
                }
            }
        }

        return result;
    }

    /**
     * Retrieve Highlighted feature content.
     *
     * @param loginType  - {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     * @param isPrelogin - <code>true</code> if pre-login, <code>false</code> for post-login.
     */
    public static ArrayList<FeatureContent> getHighlightedFeaturesList(Context context, HFConstants.LoginType loginType, boolean isPrelogin) {
        HighlightedFeaturesData featuresData = getHFFeatureFromPref(context);
        return getHighlightedFeaturesList(context, featuresData, loginType, isPrelogin);
    }

    private static boolean isFeatureAllowedInCard(Context context, FeatureContent featureContent,
                                                  String cardGrpCode, boolean isPrelogin) {

        if (isFeatureAvailableForCurrentUserCard(isPrelogin, featureContent, cardGrpCode)
                && isSupportedOnDevice(context, featureContent)
                && FacadeFactory.getCardHFDeeplinkFacade().isKillSwitchDisabled(featureContent.getKillSwitchText())) {

            if ((PORTAL_PAGE_DP.equalsIgnoreCase(featureContent.getDeepLinkCode()))
                    && (Globals.isSSOUser() == false)) {
                // Ignore this feature.
                return false;
            } else {
               /* if ((ANDROID_PAY_INDENTIFIER.equalsIgnoreCase(featureContent.getDescription()))
                        && ((isNFCAvailable == false) || (isAndroidPayAppInstalled(context) == false)|| !isUserEligibleAndroidPay(context) || !isAnyNewOrActiveCardAndAccountActive(context)))  {
                    return false;
                } else if (SAMSUNG_PAY_INDENTIFIER.equalsIgnoreCase(featureContent.getDescription())  && ( isNFCAvailable == false || !isUserEligibleSamsungPay(context) || !isSamsungPayAllowed(context) || !isAnyNewOrActiveCardAndAccountActive(context) || isCardAddedToSamsungPay(context))) {
                    return false;
                }*/

                if ((ANDROID_PAY_INDENTIFIER.equalsIgnoreCase(featureContent.getDescription()))
                        && !FacadeFactory.getWalletHelperFacade().isAndroidPayEligibleOnSamsungDevice(context)
                       ){
                    return false;
                }else if (SAMSUNG_PAY_INDENTIFIER.equalsIgnoreCase(featureContent.getDescription())  &&
                        !FacadeFactory.getWalletHelperFacade().isAllSamsungPayEligibilityApplicable(context)){
                    return false;
                }

                // Check If fingerprint hardware available or not. Allow feature if available only.
                //Added for US71610 and 11
                if (featureContent.getDescription().equalsIgnoreCase(FINGERPRINT_INDENTIFIER)){
                    if (FingerPrintUtils.isFingerprintHardwareAvailable(context)==false){
                        return false;
                    }
                }
                if (featureContent.getDeepLinkText().equalsIgnoreCase(FICO_INDENTIFIER)) {
                    if (FicoUtils.showOldOrNewFico() == FicoUtils.SHOWOLDFICO) {
                        return false;
                    }
                }
                // Feature allowed
                return true;
            }
        } else {
            return false;
        }
    }



    /**
     * Get list of highlightedfeatures on post login.
     */
    public static final boolean showPostLoginHF(final Activity activity,final HFConstants.LoginType loginType) {
        boolean result = false;
        final ArrayList<FeatureContent> features = HFUtils.getHighlightedFeaturesList(activity, loginType, false);
        if ((features == null) || (features.isEmpty())) {
            /*Below Changes for Click issue in customer service*/
            HighlightedFeaturesLandingFragment.isClickHandled = false;
        } else {
            showHighlightedFeature(activity, loginType, features);
            result=true;
        }
        return result;
    }

    private static void showHighlightedFeature(final Activity activity,final HFConstants.LoginType loginType,final ArrayList<FeatureContent> features) {
        HighlightedFeaturesLandingFragment landingFragment = new HighlightedFeaturesLandingFragment();
        Bundle arguments = landingFragment.getHFArguments(0, false, false, loginType);
        arguments.putParcelableArrayList(HFConstants.Args.HF_LIST, features);
        landingFragment.setArguments(arguments);
        DiscoverBaseActivity act = (DiscoverBaseActivity) activity;
        act.makeFragmentVisible(landingFragment, true, false);
    }
    /**
     * Retrieve Whatsnew feature.
     *
     * @param highlightedFeaturesData- {@link com.discover.mobile.common.highlightedfeatures.beans.HighlightedFeaturesData}
     * @param loginType-               {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     * @param accountType              - Account type denotes card-type for Card user and
     *                                 bank-account-type for Bank user.
     */
    public static ArrayList<FeatureContent> getWhatsNewFeaturesList(Context context, HighlightedFeaturesData highlightedFeaturesData,
                                                                    HFConstants.LoginType loginType, String accountType) {
        ArrayList<FeatureContent> result = new ArrayList<FeatureContent>();
        if (highlightedFeaturesData == null) {
            // Return empty array list.
            return result;
        }

        // Retrieve feature keys from CARD/ BANK/ SSO type
        ArrayList<String> featuresKeys = null;
        if (loginType == HFConstants.LoginType.CARD) {
            featuresKeys = highlightedFeaturesData.getCard().getWhatsnew();
        } else if (loginType == HFConstants.LoginType.BANK) {
            featuresKeys = highlightedFeaturesData.getBank().getWhatsnew();
        } else if (loginType == HFConstants.LoginType.SSO) {
            featuresKeys = highlightedFeaturesData.getSso().getWhatsnew();
        } else {
            // Default is CARD. This needs to be updated.
            featuresKeys = highlightedFeaturesData.getCard().getWhatsnew();
        }

        // Retrieve feature list using featureKeys
        for (String key : featuresKeys) {
            FeatureContent featureContent = highlightedFeaturesData.getFeatures().get(key);
            if (featureContent != null) {
                // Check if this applicable feature
                if (isFeatureAllowedInCard(context, featureContent, accountType, false)
                        && isSupportedOnDevice(context, featureContent)) {
                    featureContent.setApplyToCardSide(true);
                    result.add(featureContent);
                }
            }
        }

        return result;
    }


    /**
     * Retrieve Whatsnew feature.
     *
     * @param loginType- {@link com.discover.mobile.common.highlightedfeatures.utils.HFConstants.LoginType}
     */
    public static ArrayList<FeatureContent> getWhatsNewFeaturesList(Context context, HFConstants.LoginType loginType) {

        HighlightedFeaturesData featuresData = getHFFeatureFromPref(context);
        // Retrieve feature list using featureKeys
        String accountType = "";
        if (loginType == HFConstants.LoginType.CARD) {
            accountType = FacadeFactory.getCardFacade().getCardProductGroupCode(context);
            return getWhatsNewFeaturesList(context, featuresData, loginType, accountType);
        } else if (loginType == HFConstants.LoginType.BANK) {
            ArrayList<String> bankAccountList = FacadeFactory.getBankFacade().getNonSSOBankAccounts();
            return getWhatsNewFeaturesBankList(context, bankAccountList);
        } else if (loginType == HFConstants.LoginType.SSO) {
            return getSSOWhatsNewFeatures(featuresData);
        }
        // Return card by default
        return getWhatsNewFeaturesList(context, featuresData, loginType, accountType);
    }

    /**
     * Checks if Highlightedfeatures can be shown from deeplink.
     */
    public static final boolean canRouteToFeature(Activity activity, HFConstants.LoginType loginType, boolean isPrelogin, String deepLinkCode, String cardType) {
        if (deepLinkCode == null) {
            return false;
        }
        ArrayList<FeatureContent> features = HFUtils.getHighlightedFeaturesList(activity, loginType, isPrelogin);
        for (FeatureContent item : features) {
            if (deepLinkCode.equals(item.getDeepLinkCode())) {
                if (isFeatureAvailableForCurrentUserCard(isPrelogin, item, cardType)) {
                    return true;
                } else {
                    return false;
                }
            }
        }

        return false;
    }

    /**
     * Get list of whatsnew featutres for BANK. Applicable for SSO-BANK-USER and NON-SSO-BANK-USER.
     *
     * @return - ArrayList of FeatureContent.
     */
    public static ArrayList<FeatureContent> getWhatsNewFeaturesBankList(Context context, ArrayList<String> accountType) {
        ArrayList<FeatureContent> result = new ArrayList<FeatureContent>();
        if (accountType == null) {
            // Return empty array list.
            return result;
        }
        // Retrieve feature keys BANK type

        HighlightedFeaturesData featuresData = getHFFeatureFromPref(context);

        if (featuresData != null) {
            ArrayList<String> featuresKeys = featuresData.getBank().getWhatsnew();

            // Retrieve feature list using featureKeys
            for (String key : featuresKeys) {
                FeatureContent featureContent = featuresData.getFeatures().get(key);
                if (featureContent != null) {
                    // Check if this applicable feature
                    if (isFeatureAllowedInBank(featureContent, accountType)) {
                        featureContent.setApplyToCardSide(false);
                        result.add(featureContent);
                    }
                }
            }
        }

        return result;
    }

    /**
     * Checks if any feature (or feature list) is available for BANK.
     * This API is applicable for SSO-BANK-USER and NON-SSO-BANK-USER.
     *
     * @param context     - {@link android.content.Context}
     * @param accountType - {@link java.util.ArrayList} of {@link java.lang.String} which contains
     *                    list of accounts
     *                    of logged-in bank user (either SSO-BANK or NON-SSO-BANK)
     * @return - <code>true</code> if highlighted feature is available for BANK, <code>false</code>
     * otherwise.
     */
    public static boolean isFeatureAvailableForCurrentUserBank(Context context, ArrayList<String> accountType) {
        ArrayList<FeatureContent> result = getWhatsNewFeaturesBankList(context, accountType);
        if ((result != null) && (result.isEmpty() == false)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Checks if a {@link com.discover.mobile.common.highlightedfeatures.beans.FeatureContent} is
     * applicable
     * for current user of BANK.
     *
     * @param item      - {@link com.discover.mobile.common.highlightedfeatures.beans.FeatureContent}
     *                  which needs to verify.
     * @param bankTypes - {@link java.util.ArrayList} of {@link java.lang.String} which contains
     *                  list of accounts
     *                  of logged-in bank user (either SSO-BANK or NON-SSO-BANK)
     * @return - <code>true</code> if highlighted feature is applicable to show current user of
     * BANK, <code>false</code> otherwise.
     */
    private static boolean isFeatureAllowedInBank(FeatureContent item, ArrayList<String> bankTypes) {

        ArrayList<String> nonSupportedTypes = item.getNonSupportedBankTypes();
        /*US71823 what new finger print - start*/
        if (item.getDescription().equalsIgnoreCase(FINGERPRINT_INDENTIFIER)) {
            if (FingerPrintUtils.isFingerprintHardwareAvailable(DiscoverActivityManager.getActiveActivity()) == false) {
                return false;
            }
        }
        /*US71823 what new finger print - end*/
        if ((nonSupportedTypes == null) || (nonSupportedTypes.isEmpty()) || (bankTypes == null)) {
            // Such cases, feature is enabled for any card type.
            return true;
        }

        for (String currentBankType : bankTypes) {
            for (String supportedType : nonSupportedTypes) {
                if (currentBankType.equalsIgnoreCase(supportedType)) {
                    // Bank type is into not supported list.
                    // This feature should not allowed to current user.
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * It prepare a list of features for SSO user, depending on the feature-key list available for
     * SSO.
     * This API compare the key list with BANK's and CARD's feature-key list, depending on that
     * list
     * it prepares a feature list like CARD-BANK-CARD-BANK.
     *
     * @param featuresData {@link com.discover.mobile.common.highlightedfeatures.beans.HighlightedFeaturesData}
     *                     which contains the feature.
     * @return ArrayList of FeatureContent.
     */
    private static ArrayList<FeatureContent> getSSOWhatsNewFeatures(HighlightedFeaturesData featuresData) {
        ArrayList<FeatureContent> result = new ArrayList<FeatureContent>();
        ArrayList<String> ssoFeaturesKey = new ArrayList<String>();
        ssoFeaturesKey = featuresData.getSso().getWhatsnew();
        if (isListEmpty(ssoFeaturesKey)) {
            // Return empty array
            return result;
        }
        // Iterate SSO key and find if available into card or Bank
        // In case of Common feature, feature will be treated as Card feature.

        // Below logic is for calculating CARD/BANK features which are into SSO map.
        ArrayList<String> cardWnKeys = featuresData.getCard().getWhatsnew();
        ArrayList<String> bankWnKeys = featuresData.getBank().getWhatsnew();
        ArrayList<FeatureContent> cardFeature = new ArrayList<FeatureContent>();
        ArrayList<FeatureContent> bankFeature = new ArrayList<FeatureContent>();
        // Prepare common arguments needed for Card features
        String groupCode = getSSOCardGroupCodeOfFirstAccount();
        // Prepare account specific lists
        for (String fKey : ssoFeaturesKey) {
            FeatureContent featureContent = featuresData.getFeatures().get(fKey);
            // Look if this feature is into card
            if ((cardWnKeys != null) && (cardWnKeys.contains(fKey))) {
                // Check if this applicable feature
                if (isFeatureAllowedInCard(DiscoverActivityManager.getActiveActivity(),
                        featureContent, groupCode, false)) {
                    featureContent.setApplyToCardSide(true);
                    cardFeature.add(featureContent);
                }
            } else if ((bankWnKeys != null) && (bankWnKeys.contains(fKey))) {

                PortalCacheDataUtils pUtils = PortalCacheDataUtils.getPortalCacheDataUtilsInstance();
                pUtils.getBankAccountType();
                ArrayList<String> accounts = pUtils.getList();

                // Check if this applicable feature
                if (isFeatureAllowedInBank(featureContent, accounts)) {
                    featureContent.setApplyToCardSide(false);
                    bankFeature.add(featureContent);
                }
            } else {
                // This should not happen
            }
        }

        // Now add features in odd-even (CARD/BANK) into final list.
        if (isListEmpty(cardFeature) && isListEmpty(bankFeature)) {
            // Feature is not available for both. Return empty list.
            return result;
        }

        // If Card feature is empty or null and BANK feature available.
        // Return bank features
        if (isListEmpty(cardFeature) && (isListEmpty(bankFeature) == true)) {
            return bankFeature;
        }

        // If Bank feature is empty or null and CARD feature available.
        // Return bank features
        if (isListEmpty(bankFeature) && (isListEmpty(cardFeature) == true)) {
            return cardFeature;
        }

        // Features available for both, prepare list of SSO feature with card/bank/card/bank sequence.
        int i = 0, j = 0;
        int cardSize = cardFeature.size();
        int bankSize = bankFeature.size();

        for (; (i < cardSize && j < bankSize) || (i < cardSize) || (j < bankSize); i++, j++) {
            if (i < cardSize) {
                result.add(cardFeature.get(i));
            }
            if (j < bankSize) {
                result.add(bankFeature.get(j));
            }
        }

        return result;
    }

    /**
     * Checks if a List is null or empty.
     */
    private static boolean isListEmpty(ArrayList<?> arrayList) {
        if ((arrayList == null) || arrayList.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Check if whats-new feature can be shown for SSO.
     *
     * @return - <code>true</code> if deeplinking for CARD or BANK has not been enabled or
     * loginCount is 1,
     * <code>false</code> otherewise.
     */
    public static boolean shouldShowSSOWhatsNew(Context context) {
        HighlightedFeaturesData featuresData = getHFFeatureFromPref(context);

        if(featuresData != null) {
            ArrayList<String> ssofeatureKeys = featuresData.getSso().getWhatsnew();
            final AccountV2Details portalAccountDetails = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();

            //If merge eligible account then what's new should not be displayed - CLA merge changes.
            if (FacadeFactory.getCardHFDeeplinkFacade().isDeeplinkEnabled(context)
                    || FacadeFactory.getBankHFDeeplinkFacade().isDeeplinkEnabled(context)
                    || FacadeFactory.getBankLoginFacade().getDeepLinkValue() != "" || isListEmpty(ssofeatureKeys) || portalAccountDetails.isMergeEligible() || FacadeFactory.getCardHFDeeplinkFacade().isAnyCardUnderRLorFraudForSSO(portalAccountDetails)) {
                return false;
            } else {
                int loginCount = new HFPref(context).incrementSSOLoginCount();
                if (loginCount > 1) {
                    return false;
                } else {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Show Whatsnew for SSO.
     */
    public static void showSSOWhatsNew(Activity activity) {
        Intent intent = new Intent(activity, HighlightedFeaturePreLoginActivity.class);
        Bundle bundle = new Bundle();
        bundle.putInt(HFConstants.Args.PAGER_LOCATION, 0);
        bundle.putBoolean(HFConstants.Args.WHATS_NEW_FLAG, true);
        // Does not matter if we put pre-login flag for Whats-new or not.
        bundle.putBoolean(HFConstants.Args.PRE_LOGIN_FLAG, false);
        bundle.putSerializable(HFConstants.Args.LOGIN_TYPE, HFConstants.LoginType.SSO);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.putExtras(bundle);
        activity.startActivity(intent);
        activity.finish();
    }

    /**
     * Get cardgroupCode for card account in case of SSO.
     */
    private static String getSSOCardGroupCodeOfFirstAccount() {
        AccountV2Details portalAccountDetails = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
        if(portalAccountDetails == null || portalAccountDetails.getCardAccountsMap() ==null || portalAccountDetails.getCardAccountsMap().size()<=0)
            return "";

        String index = (String) portalAccountDetails.getCardAccountsMap().keySet().toArray()[0];
        if (index == null) {
            return "";
        }
        CardAccount cardAccount = portalAccountDetails.getCardAccountsMap().get(index);
        if (cardAccount == null) {
            return "";
        }
        return cardAccount.getCardProductGroupCode();
    }


}
