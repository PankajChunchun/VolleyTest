package com.discover.mobile.common.appupdate.ui;

/**
 * Constants for Update Application module.
 *
 * @author pkuma13
 */
public final class UpdateAppConstants {
    /**
     * Constants for error handling.
     *
     * @author pkuma13
     */
    public final class Error {
        public static final int INTERNET_OFFLINE_ERROR = 4242;
        public static final String SCHEDULED_MAINTANANCE_ERROR = "1006";
        public static final String UN_SCHEDULED_MAINTANANCE_ERROR = "1007";
    }
}
