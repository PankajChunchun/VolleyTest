package com.discover.mobile.common.liveperson;

import android.content.Context;

/**
 * Created by 436645 on 3/16/2017.
 */
public interface LPPushNotification {

    String LINK_TO_MESSAGING = "linktomessaging";

    void registerLPPushNotification(Context context, String edsKey);
    void unRegisterLPPushNotification();
    void handlePush(String title, String contentText, String payload, int notificationId, Context context);
}
