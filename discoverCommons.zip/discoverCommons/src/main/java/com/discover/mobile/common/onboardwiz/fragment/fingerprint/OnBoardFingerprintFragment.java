package com.discover.mobile.common.onboardwiz.fragment.fingerprint;


import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.onboardwiz.activity.OnBoardActivity;
import com.discover.mobile.common.onboardwiz.fragment.IPopFragment;
import com.discover.mobile.common.onboardwiz.fragment.OnBoardNavigationListener;
import com.discover.mobile.common.onboardwiz.interfaces.OnBoardFingerPrintPresenter;
import com.discover.mobile.common.onboardwiz.interfaces.OnBoardFingerPrintUI;
import com.discover.mobile.common.onboardwiz.utils.OnBoardConstant;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.onboardwiz.utils.RibbenMessage;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.uiwidget.CmnTextView;

import java.util.HashMap;

/**
 * Created by 436645 on 10/28/2016.
 */
public class OnBoardFingerprintFragment extends Fragment implements OnBoardFingerPrintUI, View.OnClickListener, RibbenMessage.TimeOutListener, IPopFragment {


    private OnBoardFingerPrintPresenter mOnBoardFingerPrintPresenter;
    private static int mPageState = -1;
    private static int mPreviousPageState = -1;
    public static boolean isFpIntroPageEnable=false;
    private ImageView successImg;
    private static final String SUCCESSIMGTAG="SuccessImgFp";
    private static final String SUCCESSIMGTAG1="SuccessImgFp1";
    private static final String SUCCESSIMGTAG2="SuccessImgFp2";
    private static final String SUCCESSIMGTAG3="SuccessImgFp3";
    private static final String SUCCESSIMGTAG4="SuccessImgFp4";
    private static final String SUCCESSIMGTAG5="SuccessImgFp5";
    private static final String SUCCESSIMGTAG6="SuccessImgFp6";


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean isFringPrintEnabled = (new FingerPrintUtils(this.getActivity())).getFingerPrintStatus();
        if(isFringPrintEnabled)
            setCurrentPageState(OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED);
        else
            setCurrentPageState(OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED);

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mOnBoardFingerPrintPresenter = new OnBoardFingerPrintPresenterImpl(this, new OnBoardFingerPrintInteractorImpl(this.getContext().getApplicationContext()));
        View view;

        if(mPageState == OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED){
            view = inflater.inflate(R.layout.onboard_fingerprint_setup_completed, null);
            successImg = (ImageView) view.findViewById(R.id.imageView2);
            successImg.setTag(SUCCESSIMGTAG);

        }
        else{
            view = inflater.inflate(R.layout.onboard_fingerprint_setup_page, null);
            successImg = (ImageView) view.findViewById(R.id.imageView2);
            successImg.setTag(SUCCESSIMGTAG1);

        }

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        updateUI();
    }

    @Override
    public void showRibbenMessage() {
        final ViewGroup viewGroup = (ViewGroup) getView();
        FrameLayout layout = (FrameLayout) viewGroup.findViewById(R.id.fp_parent_view);
        RibbenMessage.make(this, layout, R.string.msg_fingerprint_enabled, RibbenMessage.LENGTH_EXTRA_LONG, RibbenMessage.SUCCESS, this).show();
    }

    @Override
    public void showPage(int pageType) {

        switch (pageType) {
            case OnBoardConstant.FingerprintPageState.FINGERPRINT_ENABLED:
                replaceLayoutTo(R.layout.onboard_fingerprint_enabled);
                setCurrentPageState(OnBoardConstant.FingerprintPageState.FINGERPRINT_ENABLED);
                //Start: US72282: FingerPrint Analytics
                if(Globals.isBankLoginSelected)
                    FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_SUCCESS_CONFIRMATION_PG);
                else
                //End: US72282: FingerPrint Analytics
                /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                //On the page load OF success confirmation
                TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_SUCCESS_CONFIRMATION_PG);
                OnBoardConstant.isFpSuccessConfirmTagFired = true;
                /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                break;

            case OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_REGISTERED:
                replaceLayoutTo(R.layout.onboard_fingerprint_not_registered);
                setCurrentPageState(OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_REGISTERED);
                //Start: US72282: FingerPrint Analytics
                if(Globals.isBankLoginSelected)
                    FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_SETUP_DEVICE_PG);
                else
                //End: US72282: FingerPrint Analytics
                /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                //When fingerprint is not registered on the device
                TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_SETUP_DEVICE_PG);
                /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                break;

            case OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED:
                replaceLayoutTo(R.layout.onboard_fingerprint_setup_completed);
                setCurrentPageState(OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED);
                if (!OnBoardConstant.isFpSuccessConfirmTagFired) {
                    //Start: US72282: FingerPrint Analytics
                    if(Globals.isBankLoginSelected)
                        TrackingHelper.trackBankPage(AnalyticsPage.FINGERPRINT_ENABLED_PG);
                    else
                    //End: US72282: FingerPrint Analytics
                    /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                    // Onboarding FingerPrint Enabled Page load
                    TrackingHelper.trackPageView(AnalyticsPage.FINGERPRINT_ENABLED_PG);
                    /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                }
                OnBoardConstant.isFpSuccessConfirmTagFired = false;
                break;

            case OnBoardConstant.FingerprintPageState.PASSCODE_NOT_ENABLED:
                replaceLayoutTo(R.layout.onboard_fingerprint_passcode_not_enabled);
                setCurrentPageState(OnBoardConstant.FingerprintPageState.PASSCODE_NOT_ENABLED);
                //Start: US72282: FingerPrint Analytics
                if(Globals.isBankLoginSelected)
                    FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_SETUP_PASSCODE_PG);
                else
                //End: US72282: FingerPrint Analytics
                /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                //When passcode is not enabled in the device
                TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_SETUP_PASSCODE_PG);
                /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
                break;

            case OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED:
                replaceLayoutTo(R.layout.onboard_fingerprint_setup_page);
                setCurrentPageState(OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED);
                //Start: US72282: FingerPrint Analytics
                if(Globals.isBankLoginSelected)
                    FacadeFactory.getBankLoginFacade().forceTrackPage(AnalyticsPage.FINGER_PRINT_INTRO_PG);
                else
                //End: US72282: FingerPrint Analytics
                /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
                //On the page load Onboarding FingerPrint Page
                TrackingHelper.trackPageView(AnalyticsPage.FINGER_PRINT_INTRO_PG);
                OnBoardFingerprintFragment.isFpIntroPageEnable=true;
                /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
            default:
                break;
        }

        updateUI();
    }

    @Override
    public int getCurrentPageState() {
        return this.mPageState;
    }

    @Override
    public int getPreviousPageState() {
        return this.mPreviousPageState;
    }


    private void navToQuickView() {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Fragment fragment = OnBoardHelper.getCurrentChildFragment(getActivity().getSupportFragmentManager().findFragmentById(R.id.contentView));
                if (fragment instanceof OnBoardNavigationListener) {
                    OnBoardHelper.mQuickvieweAnim = true;
                    OnBoardHelper.visiblityForExitButton(getActivity(), true);
                    setCurrentPageState(OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED);
                    ((OnBoardNavigationListener) fragment).moveToNextPage();


                }
            }
        }, 3000);
    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.btn_exit) {
            if (this.getActivity() instanceof OnBoardActivity) {
                this.mOnBoardFingerPrintPresenter.exitSetUp();
            }
        }
        else if( v.getId() == R.id.fp_Enable) {
            //Start: US72282: FingerPrint Analytics
            if(Globals.isBankLoginSelected)
            {
            HashMap<String, Object> extras = FacadeFactory.getBankHFDeeplinkFacade().getHashMap();
            extras.put(AnalyticsPage.PROP1, AnalyticsPage.FINGER_PRINT_INTRO_ENABLE_BTN);
            TrackingHelper.trackBankClickEvents(AnalyticsPage.FINGER_PRINT_INTRO_ENABLE_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
        }else {
            //End: US72282: FingerPrint Analytics
            /**Start Changes for US71879: Fingerprint Site Catalyst Tags*/
            //On the Click of ENABLE button
            HashMap<String, Object> extras = new HashMap<String, Object>();
            extras.put(getContext().getResources().getString(com.discover.mobile.common.R.string.prop1), AnalyticsPage.FINGER_PRINT_INTRO_ENABLE_BTN);
            TrackingHelper.trackClickEvents(AnalyticsPage.FINGER_PRINT_INTRO_ENABLE_BTN, null, AnalyticsPage.LINK_TYPE_O, extras);
            /**End Changes for US71879: Fingerprint Site Catalyst Tags*/
        }
        this.mOnBoardFingerPrintPresenter.enableFingerPrint();
        }
    }

    @Override
    public void onTimeOut() {
        RibbenMessage.destroyRibben();
    }

    private void updateUI(){

        switch (mPageState) {
            case OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_ENABLED:
                successImg = (ImageView)this.getView().findViewById(R.id.imageView2);
                successImg.setTag(SUCCESSIMGTAG6);
                final CmnTextView headerTextView = (CmnTextView) this.getView().findViewById(R.id.setup_fp_text);
                final SpannableString fbNotEnabledString = changeColorOfText(headerTextView.getText().toString(), 36, 48, getResources().getColor(R.color.cmn_orange));
                headerTextView.setText(fbNotEnabledString);
                this.getView().findViewById(R.id.fp_Enable).setOnClickListener(this);
                break;

            case OnBoardConstant.FingerprintPageState.FINGERPRINT_SETUP_COMPLETED:
                successImg = (ImageView)this.getView().findViewById(R.id.imageView2);
                successImg.setTag(SUCCESSIMGTAG4);
                final CmnTextView headerTv = (CmnTextView) this.getView().findViewById(R.id.setup_completed_fp_text);
                final SpannableString fpSetupCmpletedString = changeColorOfText(headerTv.getText().toString(), 0, 11, getResources().getColor(R.color.cmn_orange));
                headerTv.setText(fpSetupCmpletedString);
                break;

            case OnBoardConstant.FingerprintPageState.FINGERPRINT_ENABLED:
                successImg = (ImageView)this.getView().findViewById(R.id.imageView2);
                successImg.setTag(SUCCESSIMGTAG2);
                OnBoardHelper.hideExitButton(getActivity());
                navToQuickView();
                break;

            case OnBoardConstant.FingerprintPageState.FINGERPRINT_NOT_REGISTERED:
                successImg = (ImageView)this.getView().findViewById(R.id.imageView2);
                successImg.setTag(SUCCESSIMGTAG3);
                final CmnTextView headerTvForFpNotRegistered = (CmnTextView) this.getView().findViewById(R.id.fp_not_registered_text);
                final SpannableString fpNotRegString = changeColorOfText(headerTvForFpNotRegistered.getText().toString(), 19, 30, getResources().getColor(R.color.cmn_orange));
                headerTvForFpNotRegistered.setText(fpNotRegString);
                break;

            case OnBoardConstant.FingerprintPageState.PASSCODE_NOT_ENABLED:
                successImg = (ImageView)this.getView().findViewById(R.id.imageView2);
                successImg.setTag(SUCCESSIMGTAG5);
                final CmnTextView headerTvForPasscodeNotEnabled = (CmnTextView) this.getView().findViewById(R.id.passcode_not_enabled_text);
                final SpannableString fpPCNotEnabled = changeColorOfText(headerTvForPasscodeNotEnabled.getText().toString(), 7, 18, getResources().getColor(R.color.cmn_orange));
                headerTvForPasscodeNotEnabled.setText(fpPCNotEnabled);
                break;

            default:
                break;
        }

    }

    private SpannableString changeColorOfText(String text, int start, int end, int color){
        SpannableString spannableString = new SpannableString(text);
        spannableString.setSpan(new ForegroundColorSpan(color), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableString;
    }

    private void replaceLayoutTo(int layout){
        View view = LayoutInflater.from(this.getActivity()).inflate(layout, null);
        ViewGroup viewGroup = (ViewGroup) getView();

        viewGroup.removeAllViews();
        viewGroup.addView(view);
    }

    private void setCurrentPageState(int pageCurrentState){
        mPreviousPageState = mPageState;
        mPageState = pageCurrentState;
    }


    @Override
    public boolean popBackStack() {
        return true;
    }

    @Override
    public void updateCurrentPage() {
        mOnBoardFingerPrintPresenter.onPageChanged();
    }

}
