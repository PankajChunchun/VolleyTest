package com.discover.mobile.common.highlightedfeatures.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.HashMap;

/**
 * Parent modal class for WhatsNew and Highlighted features. This contains
 * {@link HighlightedFeaturesModules} for Bank, Card and SSO, referenced
 * to a Highlighted feature and version of JSON.
 *
 * @author pkuma13
 */
public class HighlightedFeaturesData implements Serializable {

    @SerializedName("version")
    public String version;


    @SerializedName("features")
    public HashMap<String, FeatureContent> features;

    @SerializedName("sso")
    private HighlightedFeaturesModules sso;

    @SerializedName("card")
    private HighlightedFeaturesModules card;

    @SerializedName("bank")
    private HighlightedFeaturesModules bank;

    public final HashMap<String, FeatureContent> getFeatures() {
        return features;
    }

    public final void setFeatures(HashMap<String, FeatureContent> features) {
        this.features = features;
    }

    public final HighlightedFeaturesModules getSso() {
        return sso;
    }

    public final void setSso(HighlightedFeaturesModules sso) {
        this.sso = sso;
    }

    public final HighlightedFeaturesModules getCard() {
        return card;
    }

    public final void setCard(HighlightedFeaturesModules card) {
        this.card = card;
    }

    public final HighlightedFeaturesModules getBank() {
        return bank;
    }

    public final void setBank(HighlightedFeaturesModules bank) {
        this.bank = bank;
    }
}
