/*
package com.discover.mobile.bank.ui.fragments;

import android.app.Activity;
import android.app.Fragment;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.discover.mobile.BankMenuItemLocationIndex;
import com.discover.mobile.bank.R;
import com.discover.mobile.bank.common.uni.BankBaseMasterFragment;
import com.discover.mobile.bank.navigation.ShowModalInterface;
import com.discover.mobile.common.BaseFragment;

import java.io.InputStream;

*/
/**
 * Created by pdesai2 on 6/15/2016.
 *//*

public class BankLevel2Fragment extends BaseFragment {

    private TextView text;
    private Button actionButton;
    private ImageButton closeButton;
    private ImageView image;
    RelativeLayout currentLayout;
    String textReceived, imageReceived, layoutReceived, buttonReceived;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);

    }

    @Override
    public int getActionBarTitle() {
        return R.string.redeem_cash_title;
    }

    @Override
    public int getGroupMenuLocation() {
        return BankMenuItemLocationIndex.CASH_BACK_BONUS;
    }

    @Override
    public int getSectionMenuLocation() {
        return BankMenuItemLocationIndex.CBB_REDEEM_CASH;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        layoutReceived = getArguments().getString("messagingLayout");
        if(layoutReceived.equals("messagingNoButton"))
        {
            textReceived = getArguments().getString("messagingText");
            imageReceived = getArguments().getString("messagingImage");
            image= (ImageView) getActivity().findViewById(R.id.bankMessagingImage);
            new DownloadImageTask(image).execute(imageReceived);
            return inflater.inflate(R.layout.bank_level2messaging_nobutton,
                    container, false);

        }else if(layoutReceived.equals("messagingButton"))
        {
            textReceived = getArguments().getString("messagingText");
            //imageReceived = getArguments().getString("messagingImage");
            //image= (ImageView) getActivity().findViewById(R.id.bankMessagingImage);
            //new DownloadImageTask(image).execute(imageReceived);
            Log.i("here", "pranjal3");
            buttonReceived = getArguments().getString("messagingButton");
            return inflater.inflate(R.layout.bank_level2messaging_button,
                    container, false);
        }else
        {
            textReceived = getArguments().getString("messagingText");
            return inflater.inflate(R.layout.bank_level2messaging_noimagebutton,
                    container, false);
        }

    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        currentLayout = (RelativeLayout) getActivity().findViewById(R.id.bankMessagingLayout);
        Animation slide_up = AnimationUtils.loadAnimation(getActivity(),
                R.anim.bounce_up);
        slide_up.setInterpolator(new OvershootInterpolator(.5f));
        currentLayout.startAnimation(slide_up);
        super.onActivityCreated(savedInstanceState);

        text = (TextView) getActivity().findViewById(R.id.bankMessagingText);
        text.setText(textReceived);
        closeButton= (ImageButton) getActivity().findViewById(R.id.bankMessagingClose);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation slide_down = AnimationUtils.loadAnimation(getActivity(),
                        R.anim.bounce_down);
                currentLayout.startAnimation(slide_down);
                currentLayout.setVisibility(View.GONE);
                //getActivity().getFragmentManager().popBackStack();
            }
        });

       if(layoutReceived.equals("messagingButton")){
            actionButton= (Button) getActivity().findViewById(R.id.bankMessagingNextButton);
            actionButton.setText(buttonReceived);
            Log.i("here", "pranjal4");
            actionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //do something
                }
            });
       }
            //footers.setText("www.google.com");
            //Linkify.addLinks(footers, Linkify.ALL);
            //footers.setLinkTextColor(Color.parseColor("#FF0074B4"));

    }



    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }
}
*/
