/**
 * Copyright Solstice-Mobile 2013
 */
package com.discover.mobile.common.facade;

import com.discover.mobile.common.ScreenType;
import com.discover.mobile.common.login.LoginActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

/**
 * A delegate for login to
 *
 * @author ekaram
 */
public interface LoginActivityFacade {
    /**
     * Navigates to the Login Activity
     */
    public void navToLogin(Context context);


    /**
     * Navigates to the Login Activity and clear other activities
     */
    public void navToLoginAndClear(Context context);

    /**
     * Navigates to the lockout screen
     */
    public void navToLockoutScreen(Context context, ScreenType screenType);

    /**
     * Returns the login activity class for consumption directly
     */
    public Class getLoginActivityClass();

    //Changes made as part of Login migration change as we have changed super class of LoginActivity.
    //changes start

    /**
     * Returns a new login activity for consumption directly
     */
    public LoginActivity getLoginActivity();
    //changes ends

    /**
     * Allows a navigation direct to login, sporting a message in a bundle
     */
    public void navToLoginWithMessage(Activity currentActivity, Bundle bundle);

    public void navToLogin(Activity currentActivity, Bundle bundle);

    public void navToLogin(Activity currentActivity, Bundle bundle, boolean flag);

}
