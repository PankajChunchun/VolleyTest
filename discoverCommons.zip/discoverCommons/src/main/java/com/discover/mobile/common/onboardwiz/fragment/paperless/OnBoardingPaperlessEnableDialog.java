package com.discover.mobile.common.onboardwiz.fragment.paperless;

import com.discover.mobile.common.R;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Resources;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * This dialog class displays dialog with a title, body text followed by a
 * web view and contains two buttons. The dialog will be cetered and will resize
 * based on the dialog content
 **/
public class OnBoardingPaperlessEnableDialog extends AlertDialog {

    /** Declarations**/
    /** Root view that is to be inflated in the dialog **/
    private View mView;
    /** Paperless Dialog Title Text View **/
    private TextView mPaperlessEnrollTitle;
    /** Paperless Dialog Body Text View **/
    private TextView mPaperlessEnrollBody;
    /** Paperless Dialog Web View **/
    private WebView mPaperlessWebView;
    /** To save the context received from the parent of the dialog **/
    private Context mContext;
    /** Resource object to help in fetching resources from res folder **/
    private Resources mResources;
    /** Loading spinner  to web view **/
    private ProgressBar loadingSpinner;

    /** Paperless Dialog constructor. Gets context and url as arguments, **/
    public OnBoardingPaperlessEnableDialog(final Context context) {
        super(context);

        mView = getLayoutInflater().inflate(
                R.layout.onboarding_paperless_dialog, null);
        mContext = context;
        /** Initializing views**/
        mPaperlessEnrollTitle = (TextView) mView.findViewById(R.id.modal_title);
        mPaperlessEnrollBody = (TextView) mView.findViewById(R.id.body_text);
        loadingSpinner = (ProgressBar) mView.findViewById(R.id.onboard_progress_bar_unenroll);

        mResources = mContext.getResources();
       /* mPaperlessEnrollTitle.setText(mResources.getString(R.string.onboard_paperless_enable_dlg_title));
        mPaperlessEnrollBody.setText(mResources.getString(R.string.onboard_paperless_enable_dlg_text));*/
        mPaperlessWebView = (WebView) mView.findViewById(R.id.onboard_paperless_webview);
        mPaperlessEnrollBody.setVisibility(View.VISIBLE);
        mPaperlessWebView.getSettings().setJavaScriptEnabled(true);

        mPaperlessWebView.setWebChromeClient(new WebChromeClient());

        mPaperlessWebView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(final WebView view, final String url) {
                super.onPageFinished(view, url);
                loadingSpinner.setVisibility(View.GONE);
                mPaperlessWebView.setVisibility(View.VISIBLE);
                loadingSpinner.clearAnimation();
            }

            @Override
            public void onReceivedSslError(final WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

        });

    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(mView);
    }

    /** Getter method for accept button **/
    public Button getOkButton() {
        return (Button) mView.findViewById(R.id.modal_ok_button);
    }

    /** Getter method for cancel button **/
    public Button getCancelButton() {
        return (Button) mView.findViewById(R.id.modal_alert_cancel);
    }

    /** Sets Text for Right button **/
    public void setOkButtonText(int text) {
        Button ok = (Button) mView.findViewById(R.id.modal_ok_button);
        ok.setText(text);
        ok.setContentDescription(getContext().getResources().getText(R.string.onboard_accept));
    }

    /** Sets Text for Left button **/
    public void setCancelButtonText(int text) {
        Button cancel = (Button) mView.findViewById(R.id.modal_alert_cancel);
        cancel.setText(text);
        cancel.setContentDescription(getContext().getResources().getText(R.string.onboard_cancel));
    }

    /** Sets Text for Title of the Dialog, when string is passed as parameter **/
    public void setModalTitle(String titleText) {
        mPaperlessEnrollTitle.setText(titleText);
    }

    /** Sets Text for body of the Dialog, when string is passed as parameter **/
    public void setModalBodyText(String bodyText) {
        mPaperlessEnrollBody.setText(bodyText);
        mPaperlessEnrollBody.setContentDescription(bodyText);
    }

    /** Sets Text for Title of the Dialog, when string resourceId is passed **/
    public void setModalTitle(int titleTextResId) {
        mPaperlessEnrollTitle.setText(mResources.getString(titleTextResId));
    }

    /** Sets Text for body of the Dialog, when string resourceId is passed **/
    public void setModalBodyText(int bodyTextResId) {
        mPaperlessEnrollBody.setText(mResources.getString(bodyTextResId));
    }

    /** Sets the url for the web page that should load in the webview of the dialog **/
    public void setUrlToLoad(String url) {
        mPaperlessWebView.loadUrl(url);
    }

    /** Get the Title View*/
    public TextView getmPaperlessEnrollTitle() {
        return mPaperlessEnrollTitle;
    }
}

