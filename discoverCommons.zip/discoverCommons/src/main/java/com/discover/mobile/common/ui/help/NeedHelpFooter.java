package com.discover.mobile.common.ui.help;

import com.discover.mobile.common.R;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.CommonUtils;

import android.content.Context;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Utility class used to wrap the Need Help footer at the bottom of every page or modal. Provides
 * functionals to set the help number dynamically and to show or hide the footer on a page.
 *
 * @author henryoyuela
 */
public class NeedHelpFooter {
    /** View that holds the content text */
    public TextView helpNumberTxtVw;
    /**
     * Default Constructor Not Used
     */
    @SuppressWarnings("unused")
    private NeedHelpFooter() {

    }

    /**
     * @param rootView - View that contains the footer text views.
     */
    public NeedHelpFooter(final ViewGroup rootView) {

        helpNumberTxtVw = (TextView) rootView.findViewById(R.id.help_number_label);
        helpNumberTxtVw.setMovementMethod(LinkMovementMethod.getInstance());
        //US103832- Update Local Copy UI observation
        //Removing links and dial option of help line numbers in Tablet
        if(Globals.isBankLoginSelected  ) {
            if( CommonUtils.isRunningOnHandset(DiscoverActivityManager.getDiscoverApplicationContext())) {
                Linkify.addLinks(helpNumberTxtVw, Linkify.ALL);
            }
            else {
                helpNumberTxtVw.setTextColor(DiscoverActivityManager.getDiscoverApplicationContext().getResources().getColor(R.color.black));
            }
        }
        else{
            Linkify.addLinks(helpNumberTxtVw, Linkify.ALL);
        }
    }

    //Added new constructor to handle the phone number for handset only
    //US50433
    public NeedHelpFooter(final Context context, final ViewGroup rootView) {
        helpNumberTxtVw = (TextView) rootView.findViewById(R.id.help_number_label);
        //helpNumberTxtVw.setMovementMethod(LinkMovementMethod.getInstance());
        //Linkify.addLinks(helpNumberTxtVw, Linkify.ALL);
        if (CommonUtils.isRunningOnHandset(context)) {
//            CommonUtils.linkifyNumber(context, helpNumberTxtVw, true);
            CommonUtils.handlePhoneNumberClick(DiscoverActivityManager.getActiveActivity(),null,helpNumberTxtVw,helpNumberTxtVw.getText().toString());
        }
    }

    /**
     * Used to set the help number displayed in the footer
     *
     * @param helpNumber Resource id of the help number in the resource file
     */
    public void setToDialNumberOnClick(final int helpNumber) {
        //233556- Start-Alex
        helpNumberTxtVw.setText(Html.fromHtml(helpNumberTxtVw.getContext().getResources().getString(helpNumber)));
        //233556- End- Alex
        //US103832- Update Local Copy UI observation
        //Removing links and dial option of help line numbers in Tablet
        if(Globals.isBankLoginSelected  ) {
            if( CommonUtils.isRunningOnHandset(DiscoverActivityManager.getDiscoverApplicationContext())) {
                helpNumberTxtVw.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        CommonUtils.dialNumber(helpNumberTxtVw.getText().toString(), helpNumberTxtVw.getContext());
                    }
                });
            }
        }
        else
        {
            helpNumberTxtVw.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(final View v) {
                    CommonUtils.dialNumber(helpNumberTxtVw.getText().toString(), helpNumberTxtVw.getContext());
                }
            });
        }

    }

    /**
     * Used to set the help number displayed in the footer
     *
     * @param helpNumber String with the help number
     */
    public void setToDialNumberOnClick(final String helpNumber) {

        helpNumberTxtVw.setText(helpNumber);
        //US103832- Update Local Copy UI observation
        //Removing links and dial option of help line numbers in Tablet
        if(Globals.isBankLoginSelected  ) {
            if( CommonUtils.isRunningOnHandset(DiscoverActivityManager.getDiscoverApplicationContext())) {
                helpNumberTxtVw.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        CommonUtils.dialNumber(helpNumber, helpNumberTxtVw.getContext());
                    }
                });
            }
        }
        else{
            helpNumberTxtVw.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(final View v) {
                    CommonUtils.dialNumber(helpNumberTxtVw.getText().toString(), helpNumberTxtVw.getContext());
                }
            });
        }

    }


    /**
     * Used to show or hide the view on the page or modal it is displayed on.
     *
     * @param show True to display the footer, false otherwise.
     */
    public void show(final boolean show) {
        final ViewGroup parentView = (ViewGroup) helpNumberTxtVw.getParent();

        if (show) {
            parentView.setVisibility(View.VISIBLE);
        } else {
            parentView.setVisibility(View.GONE);
        }
    }
}
