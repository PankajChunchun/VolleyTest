package com.discover.mobile.common.fico.presenter;

import com.discover.mobile.common.fico.interactor.FicoCreditScoreInteractor;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreMasterFragUIInterface;
import com.discover.mobile.common.fico.service.FicoCreditScoreServiceClass;
import com.discover.mobile.common.shared.net.NetworkRequestListener;

/**
 * Created by slende on 5/5/2017.
 * Presenter Implementation for FicoCreditScorecardMasterFrag
 */

public class FicoCreditScoreMasterFragPresenterImpl implements FicoCreditScoreMasterFragPresenter {

    private FicoCreditScoreInteractor mFicoCreditScoreInteractor;
    private FicoCreditScoreMasterFragUIInterface ficoCreditScoreMasterFragUIInterface;

    public FicoCreditScoreMasterFragPresenterImpl(FicoCreditScoreMasterFragUIInterface ficoMasterUIInterface, FicoCreditScoreInteractor ficoCreditScoreInteractor) {
        ficoCreditScoreMasterFragUIInterface = ficoMasterUIInterface;
        mFicoCreditScoreInteractor = ficoCreditScoreInteractor;
    }

    @Override
    public void getFicoCreditScoreData() {
        ficoCreditScoreMasterFragUIInterface.showSpinner();
        mFicoCreditScoreInteractor.getFicoCreditScore(new NetworkRequestListener() {

            @Override
            public void onSuccess(Object data) {
                ficoCreditScoreMasterFragUIInterface.ficoScoreOnSuccess(data);
                ficoCreditScoreMasterFragUIInterface.hideSpinner();
            }

            @Override
            public void onError(Object data) {
                ficoCreditScoreMasterFragUIInterface.ficoScoreOnError(data);
                ficoCreditScoreMasterFragUIInterface.hideSpinner();
            }
        });
    }
}
