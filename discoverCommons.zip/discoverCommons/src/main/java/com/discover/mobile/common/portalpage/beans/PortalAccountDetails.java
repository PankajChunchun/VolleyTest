package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * POJO class for "v2/account" service call
 * Added in 6.7 release
 *
 * @author slende
 */
public class PortalAccountDetails implements Serializable {

    private static final long serialVersionUID = 2803421668447076588L;

    @SerializedName("cardAccounts")
    private List<CardAccount> cardAccounts = new ArrayList<CardAccount>();


    @SerializedName("targetMarketing")
    private String targetMarketing;
    @SerializedName("loanAccounts")
    private List<LoanAccount> LoanAccounts = new ArrayList<LoanAccount>();

    @SerializedName("depositAccounts")
    private List<DepositAccount> depositAccounts = new ArrayList<DepositAccount>();

    @SerializedName("iraPlans")
    private List<IraPlan> iraPlans = new ArrayList<IraPlan>();

    @SerializedName("bankSummaryStatus")
    private String bankSummaryStatus;

    @SerializedName("customerFirstName")
    private String customerFirstName;

    @SerializedName("isSSOUser")
    private Boolean isSSOUser;

    @SerializedName("payLoadSSOText")
    private String payLoadSSOText;

    @SerializedName("partyId")
    private String partyId;

    @SerializedName("pages")
    private Page pages;

    @SerializedName("isUserIdAvailable")
    private boolean isUserIdAvailable;

    /** start newly added field for US48093 changes */

    @SerializedName("isMergeEligible")
    private Boolean isMergeEligible;

    // US126324 Changes - start
    @SerializedName("isInitialSkipAttempt")
    private boolean isInitialSkipAttempt;
    // US126324 Changes - end

    @SerializedName("isEDSFiltered")
    private Boolean isEDSFiltered;

    @SerializedName("jointCardsLastFourDigitList")
    private List<String> jointCardsLastFourDigitList = new ArrayList<String>();
    @SerializedName("errorRetrievingCardData")
    private boolean errorRetrievingCardData;
    @SerializedName("errorRetrievingBankData")
    private boolean errorRetrievingBankData;
    @SerializedName("isUserIdLogin")
    private String isUserIdLogin;
    @SerializedName("dynamicProperties")
    private DynamicProperties dynamicProperties;
    @SerializedName("primaryCardmember")
    private PrimaryCardmember primaryCardmember;
    @SerializedName("mailingAddress")
    private MailingAddress mailingAddress;

    @SerializedName("gatewayOauthURL")
    private String gatewayOauthURL;

    public DynamicBannerMessages getDynamicBannerMessages() {
        return dynamicBannerMessages;
    }

    public void setDynamicBannerMessages(DynamicBannerMessages dynamicBannerMessages) {
        this.dynamicBannerMessages = dynamicBannerMessages;
    }

    @SerializedName("dynamicBannerMessages")
    private DynamicBannerMessages dynamicBannerMessages;

    @SerializedName("userId")
    private String userId;

    public Boolean isEDSFiltered() {
        return isEDSFiltered;
    }

    public void setIsEDSFiltered(Boolean isEDSFiltered) {
        this.isEDSFiltered = isEDSFiltered;
    }

    public Boolean isMergeEligible() {
        return isMergeEligible;
    }

    public void setIsMergeEligible(Boolean isMergeEligible) {
        this.isMergeEligible = isMergeEligible;
    }

    public boolean isInitialSkipAttempt() {
        return isInitialSkipAttempt;
    }

    public void setInitialSkipAttempt(boolean initialSkipAttempt) {
        this.isInitialSkipAttempt = initialSkipAttempt;
    }

    public List<String> getJointCardsLastFourDigitList() {
        return jointCardsLastFourDigitList;
    }

    public void setJointCardsLastFourDigitList(List<String> jointCardsLastFourDigitList) {
        this.jointCardsLastFourDigitList = jointCardsLastFourDigitList;
    }

    /** end newly added field for US48093 changes */

    /** start Added for US38219 CLA merge intercept page */
    @SerializedName("isForceMerge")
    private Boolean isForceMerge;

    public Boolean isForceMerge() {
        return isForceMerge;
    }

    public void setIsForceMerge(Boolean forceMerge) {
        isForceMerge = forceMerge;
    }

    /** end Added for US38219 CLA merge intercept page */

    public boolean getErrorRetrievingCardData() {
        return errorRetrievingCardData;
    }

    public void setErrorRetrievingCardData(boolean errorRetrievingCardData) {
        this.errorRetrievingCardData = errorRetrievingCardData;
    }

    public boolean getErrorRetrievingBankData() {
        return errorRetrievingBankData;
    }

    public void setErrorRetrievingBankData(boolean errorRetrievingBankData) {
        this.errorRetrievingBankData = errorRetrievingBankData;
    }

    public String getIsUserIdLogin() {
        return isUserIdLogin;
    }

    public void setIsUserIdLogin(String isUserIdLogin) {
        this.isUserIdLogin = isUserIdLogin;
    }

    /**
     * @return The cardAccounts
     */
    public List<CardAccount> getCardAccounts() {
        if (null != cardAccounts)
            return cardAccounts;
        else {
            return new ArrayList<CardAccount>();
        }
    }

    /**
     * @param cardAccounts The cardAccounts
     */
    public void setCardAccounts(List<CardAccount> cardAccounts) {
        this.cardAccounts = cardAccounts;
    }

    /**
     * @return The LoanAccounts
     */
    public List<LoanAccount> getLoanAccounts() {
        if (null != LoanAccounts)
            return LoanAccounts;
        else {
            return new ArrayList<LoanAccount>();
        }
    }

    /**
     * @param LoanAccounts The loanAccounts
     */
    public void setLoanAccounts(List<LoanAccount> LoanAccounts) {
        this.LoanAccounts = LoanAccounts;
    }

    /**
     * @return The depositAccounts
     */
    public List<DepositAccount> getDepositAccounts() {
        if (null != depositAccounts)
            return depositAccounts;
        else {
            return new ArrayList<DepositAccount>();
        }
    }

    /**
     * @param depositAccounts The depositAccounts
     */
    public void setDepositAccounts(List<DepositAccount> depositAccounts) {
        this.depositAccounts = depositAccounts;
    }

    /**
     * @return The iraPlans
     */
    public List<IraPlan> getIraPlans() {
        if (null != iraPlans)
            return iraPlans;
        else {
            return new ArrayList<IraPlan>();
        }
    }

    /**
     * @param iraPlans The iraPlans
     */
    public void setIraPlans(List<IraPlan> iraPlans) {
        this.iraPlans = iraPlans;
    }

    /**
     * @return The bankSummaryStatus
     */
    public String getBankSummaryStatus() {
        return bankSummaryStatus;
    }

    /**
     * @param bankSummaryStatus The bankSummaryStatus
     */
    public void setBankSummaryStatus(String bankSummaryStatus) {
        this.bankSummaryStatus = bankSummaryStatus;
    }

    /**
     * @return The isSSOUser
     */
    public Boolean getIsSSOUser() {
        return isSSOUser;
    }

    /**
     * @param isSSOUser The isSSOUser
     */
    public void setIsSSOUser(Boolean isSSOUser) {
        this.isSSOUser = isSSOUser;
    }

    /**
     * @return The payLoadSSOText
     */
    public String getPayLoadSSOText() {
        return payLoadSSOText;
    }

    /**
     * @param payLoadSSOText The payLoadSSOText
     */
    public void setPayLoadSSOText(String payLoadSSOText) {
        this.payLoadSSOText = payLoadSSOText;
    }

    /**
     * @return The partyId
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * @param partyId The partyId
     */
    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }


    /**
     * @return The dynamicProperties
     */
    public DynamicProperties getDynamicProperties() {
        return dynamicProperties;
    }

    /**
     * @param dynamicProperties The dynamicProperties
     */
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }

    public PrimaryCardmember getPrimaryCardmember() {
        return primaryCardmember;
    }

    public void setPrimaryCardmember(PrimaryCardmember primaryCardmember) {
        this.primaryCardmember = primaryCardmember;
    }

    public MailingAddress getMailingAddress() {
        return mailingAddress;
    }

    public void setMailingAddress(MailingAddress mailingAddress) {
        this.mailingAddress = mailingAddress;
    }

    public Page getPages() {
        return pages;
    }

    public void setPages(Page pages) {
        this.pages = pages;
    }

    public boolean getIsUserIdAvailable() {
        return isUserIdAvailable;
    }

    public void setIsUserIdAvailable(boolean isUserIdAvailable) {
        this.isUserIdAvailable = isUserIdAvailable;
    }

    public String getCustomerFirstName() {
        return customerFirstName;
    }

    public void setCustomerFirstName(String customerFirstName) {
        this.customerFirstName = customerFirstName;
    }

    public String getGatewayOauthURL() {
        return gatewayOauthURL;
    }

    public void setGatewayOauthURL(String gatewayOauthURL) {
        this.gatewayOauthURL = gatewayOauthURL;
    }

    public String getUserId() {
        return userId;
    }

}
