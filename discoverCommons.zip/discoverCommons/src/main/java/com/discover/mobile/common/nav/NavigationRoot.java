package com.discover.mobile.common.nav;

import android.support.v4.app.Fragment;

interface NavigationRoot {

    void makeFragmentVisible(Fragment fragment);

}
