/**
 *
 */
package com.discover.mobile.common.nav;

import android.view.View.OnClickListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author 328073
 */
public final class OverFlowMenu {
    private ArrayList<OverFlowBeans> listOfOptions = new ArrayList<OverFlowBeans>();

    public void add(String nameOfOption, OnClickListener clickListener) {
        OverFlowBeans beans = new OverFlowBeans();
        beans.setClickListener(clickListener);
        beans.setNameOfMenu(nameOfOption);
        listOfOptions.add(beans);
    }

    public List<OverFlowBeans> getMenuOptions() {
        return Collections.unmodifiableList(listOfOptions);
    }
}
