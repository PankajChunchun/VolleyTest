package com.discover.mobile.common.nav.configuration;

import com.discover.mobile.common.nav.listener.IMenuEvenListener;

/**
 * Configuration class for storing info related to ActionBar/OverFlow items
 */
public class ActionBarConfiguration

{

    private IMenuEvenListener mListener;

    private String menuJson;

    public IMenuEvenListener getmListener() {
        return mListener;
    }

    public void setmListener(IMenuEvenListener mListener) {
        this.mListener = mListener;
    }


    public String getMenuJson() {
        return menuJson;
    }

    public void setMenuJson(String menuJson) {
        this.menuJson = menuJson;
    }
}
