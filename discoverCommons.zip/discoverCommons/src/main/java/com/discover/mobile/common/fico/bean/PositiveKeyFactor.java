package com.discover.mobile.common.fico.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class PositiveKeyFactor implements Serializable {
    private static final long serialVersionUID = 419682317905845456L;

    @SerializedName("key")
    private String key;

    @SerializedName("longDesc")
    private String longDesc;

    @SerializedName("shortDesc")
    private String shortDesc;

    @SerializedName("code")
    private String code;

    @SerializedName("efftDate")
    private String efftDate;

    public String getLongDesc() {
        return this.longDesc;
    }

    public void setLongDesc(String longDesc) {
        this.longDesc = longDesc;
    }

    public String getShortDesc() {
        return this.shortDesc;
    }

    public void setShortDesc(String shortDesc) {
        this.shortDesc = shortDesc;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEfftDate() {
        return this.efftDate;
    }

    public void setEfftDate(String efftDate) {
        this.efftDate = efftDate;
    }

    public String getKey() {
        return this.key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
