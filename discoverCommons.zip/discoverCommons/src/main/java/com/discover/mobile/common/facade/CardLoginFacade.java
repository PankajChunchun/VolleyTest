/**
 * Copyright Solstice-Mobile 2013
 */
package com.discover.mobile.common.facade;


import android.content.Context;

import java.util.ArrayList;

/**
 * A facade to support common shared login code
 */
public interface CardLoginFacade {

    /**
     * Submits login call with payload
     *
     * @param callingActivity
     * @param tokenValue
     * @param hashedTokenValue
     */
    /*1. Removed as per US60514 */
   /* public void loginWithPayload(LoginActivityInterface callingActivity,
                                 String tokenValue, String hashedTokenValue);*/

    /**
     * Submits the login call
     *UNUSED_NEEDS_TO_BE_DELETED_SLENDE
     * @param callingActivity
     */
   /* public void login(LoginActivityInterface callingActivity, String username,
                      String password, NetworkRequestListener nrl);*/


    /**
     * Starts the process of retrieving a Bank payload and authorizing the user
     * against Bank services. The Bank authentication process, upon success,
     * will start the user at their account landing view.
     */
    public void toggleLoginToBank(Context context);

    /**
     * Toggles the user to the Card side of the application which was previous
     * authenticated.
     *
     * @param context a context from the AccountToggleView, if needed.
     */
    public void toggleToCard(Context context);

    /**
     * Authenticates the user using the passcode based authorization scheme and credentials.
     *
     * @param calling  activity - activity calling this method
     * @param passcode UNUSED_NEEDS_TO_BE_DELETED_SLENDE
     */
   /* public void loginWithPasscode(LoginActivityInterface callingActivity, String deviceToken,
            String passcode, NetworkRequestListener nrl);*/
    public void firstRunCheck(Context context);

    /**
     * to reset the deeplink flag and value
     */
    public void resetDeepLinkValues();

     /*2. Removed as per US60514 */
   /* public void loginResponseHandlerOnError(Context context, Object data, Object object);*/

    public boolean getQvAnimationKillSwitch();

    public void setQvAnimationKillSwitch(boolean qvAnimationKilled);

    // Added as part of profile and setttings status update regression defect.
    public void saveUserIdForLocationSettings(String username);

    public void addPreloginKillSwitch(Context context, ArrayList<String> mKillSwitchList);

    public String getBaseUrl();

    /**
     * to call the brodcast receiver of quickview widget while changing orientation
     */
    public Class getWidgetProvider();

    public String getQuickViewToken(Context context) throws Exception;

    /*3. Removed as per US60514 */
    /* public int getApploginCount(Context context);*/

    /*4. Removed as per US60514 */
  /*  public void setWizardVisibility(boolean showOrHide);*/

   /*5. Removed as per US60514 */
   /* public boolean isShouldShowWizard();*/
}
