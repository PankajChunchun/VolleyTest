package com.discover.mobile.common.nav.configuration;

/**
 * Created by 468195 on 3/14/2016.
 */
public class CustomActionBarItemConfig {

    private int itemDrawable;

    private int position;

    private int title;

    private Runnable initItemAction;


    public Runnable getInitItemAction() {
        return initItemAction;
    }

    public void setInitItemAction(Runnable initItemAction) {
        this.initItemAction = initItemAction;
    }


    public int getItemDrawable() {
        return itemDrawable;
    }

    public void setItemDrawable(int itemDrawable) {
        this.itemDrawable = itemDrawable;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getTitle() {
        return title;
    }

    public void setTitle(int title) {
        this.title = title;
    }
}
