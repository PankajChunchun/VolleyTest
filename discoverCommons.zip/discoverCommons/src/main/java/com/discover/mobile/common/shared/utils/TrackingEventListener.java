package com.discover.mobile.common.shared.utils;


/**
 * Created by 482127 on 2/22/2017.
 */
public interface TrackingEventListener {
     void onClickEventTracking();
}
