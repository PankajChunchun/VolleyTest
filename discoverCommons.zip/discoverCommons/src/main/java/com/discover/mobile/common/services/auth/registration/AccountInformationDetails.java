package com.discover.mobile.common.services.auth.registration;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.common.shared.Struct;

import java.io.Serializable;

/**
 * POGO Class for AccountInformationDetails
 *
 * @author CTS
 * @version 1.0
 */
@Struct
public class AccountInformationDetails implements Serializable {

    private static final long serialVersionUID = 8196921305619911757L;

    /**
     * This or {@link #userId} should always be {@code null}, never both or
     * neither.
     */
    public String acctNbr;
    /**
     * This or {@link #acctNbr} should always be {@code null}, never both or
     * neither.
     */
    public String userId;

    // Step One Strings.
    public String expirationMonth;
    public String expirationYear;
    @SerializedName("socialSecrityNumber")
    public String socialSecurityNumber;
    public String dateOfBirthMonth;
    public String dateOfBirthDay;
    public String dateOfBirthYear;

}
