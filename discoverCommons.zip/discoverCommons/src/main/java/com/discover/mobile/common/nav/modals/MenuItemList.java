package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by 468195 on 2/16/2016.
 */
public class MenuItemList {

    @SerializedName("overflowMenu")
    private ArrayList<MenuItemBean> overflowMenu;

    public ArrayList<MenuItemBean> getOverflowMenu() {
        return overflowMenu;
    }

    public void setOverflowMenu(ArrayList<MenuItemBean> overflowMenu) {
        this.overflowMenu = overflowMenu;
    }
}
