package com.discover.mobile.common.appupdate.ui;

import com.discover.mobile.common.BaseFragment;
import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.highlightedfeatures.ui.HighlightedFeaturesLandingFragment;
import com.discover.mobile.common.highlightedfeatures.utils.HFConstants;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

/**
 * Fragment which shows update available or application is updated screen,
 * depending on {@link Boolean} value of given argument
 * {@link UpdateAppFragment#KEY_UPDATE_AVAILABLE}.
 *
 * @author pkuma13
 */
public class UpdateAppFragment extends BaseFragment {
    public static final String KEY_UPDATE_AVAILABLE = "update_available";
    public static final String KEY_ISCARD = "isCard";
    public static final String KEY_ISPRELOGIN = "isPreLogin";
    private static final String TAG = UpdateAppFragment.class.getSimpleName();
    private static final String PLAY_URL_PREFIX = "market://details?id=";
    private static final String PACKAGE_FOR_MOBILE = "com.discoverfinancial.mobile";
    private View mMainView;
    private TextView privacyText;
    private TextView provideFeedbackText;
    private TextView noUpdateAvailableText;
    private boolean isCard;
    private boolean isPreLogin;
    //sshar13:- US24441
    private String hdeepLinkHighlightedFeatureActionCode = "linkToHighlightesFeatures";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Bundle arguments = getArguments();
        boolean isUpdateAvailable = false;
        if (arguments != null) {
            isUpdateAvailable = arguments.getBoolean(KEY_UPDATE_AVAILABLE);
            isCard = arguments.getBoolean(KEY_ISCARD);
            isPreLogin = arguments.getBoolean(KEY_ISPRELOGIN);
        }
        if (isUpdateAvailable) {
            // Update available.
//            Utils.log(TAG, "Update available...");
            mMainView = inflater.inflate(R.layout.app_update_available_layout,
                    container, false);
            // Init listeners for update application screen.
            //US20350 : sshar13 :- version number analytics
            TrackingHelper.trackPageView(AnalyticsPage.VERSION_INFORMATION_UPDATE_AVAILABLE_PAGE);
            initListener();
        } else {
            //US20350 : sshar13 :- version number analytics
            TrackingHelper.trackPageView(AnalyticsPage.VERSION_INFORMATION_NO_UPDATE_AVAILABLE_PAGE);
            // Update not available.
//            Utils.log(TAG, "User has updated version...");
            mMainView = inflater.inflate(
                    R.layout.app_update_not_available_layout, container, false);

            noUpdateAvailableText = (TextView) mMainView
                    .findViewById(R.id.no_update_available_sum);

            if (isCard) {
                noUpdateAvailableText.setVisibility(View.VISIBLE);
            } else {
                noUpdateAvailableText.setVisibility(View.GONE);
            }
            // Clickable highlighted feature
            String textString = noUpdateAvailableText.getText().toString();
            SpannableString builder = new SpannableString(textString);
            ClickableSpan clickableSpan = new ClickableSpan() {

                @Override
                public void onClick(View widget) {
                    //US20350 : sshar13 :- version number analytics
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put("my.prop1", AnalyticsPage.VERSION_NOUPDATE_HIGHLIGHT_FEATURE_CLICKED_prop1);
                    extras.put("pe", AnalyticsPage.VERSION_NOUPDATE_HIGHLIGHT_FEATURE_pe);
                    extras.put("pev1", AnalyticsPage.VERSION_NOUPDATE_HIGHLIGHT_FEATURE_pev1);
                    TrackingHelper.trackCardPageProp1(
                            AnalyticsPage.VERSION_NOUPDATE_HIGHLIGHT_FEATURE_CLICKED_prop1,
                            AnalyticsPage.VERSION_NOUPDATE_HIGHLIGHT_FEATURE_pev1, extras);
                    showHighlightedFeature();
                }

                @Override
                public void updateDrawState(TextPaint ds) {
                    ds.setUnderlineText(false);
                }

            };
            builder.setSpan(clickableSpan, 0, 25,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
//            builder.setSpan(new ForegroundColorSpan(getActivity()
//                            .getResources().getColor(R.color.card_footer_color)), 0,
//                    25, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

            builder.setSpan(new ForegroundColorSpan(Color.parseColor("#267bb1")), 0, 25,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

            noUpdateAvailableText.setText(builder);
            noUpdateAvailableText.setMovementMethod(LinkMovementMethod
                    .getInstance());
        }

        privacyText = (TextView) mMainView.findViewById(R.id.privacy_terms);
        provideFeedbackText = (TextView) mMainView
                .findViewById(R.id.provide_feedback_button);

        privacyText.setClickable(true);
        provideFeedbackText.setClickable(true);

        privacyText.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                FacadeFactory.getCardFacade().navToPrivacyTerms(getActivity());
            }
        });
        provideFeedbackText.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                if (isCard) {
                    FacadeFactory.getCardFacade().navToProvideFeedback(
                            DiscoverActivityManager.getActiveActivity());
                } else {
                    FacadeFactory.getBankLoginFacade().navigateToFeedback();
                }
            }
        });

        return mMainView;
    }

    private void showHighlightedFeature() {
        if (!isPreLogin) {
            final Activity currentActivity = DiscoverActivityManager.getActiveActivity();
            // US45209 Changes starts.
            HighlightedFeaturesLandingFragment fragment = new HighlightedFeaturesLandingFragment();
            // Need to set boolean as false since this is post login updated dialog
            Bundle bundle = fragment.getHFArguments(0, false, false, HFConstants.LoginType.CARD);
            fragment.setArguments(bundle);
            ((ActionBarBaseActivity) currentActivity).makeFragmentVisible(fragment);
            /*FacadeFactory.getHighlightedFeaturesFacade().getPreloginHighlightedFeaturesFragment(currentActivity, null, new NetworkRequestListener() {
                @Override
                public void onSuccess(Object data) {
                    Fragment fragment = (Fragment) data;
                    ((NavigationRootActivity) currentActivity).makeFragmentVisible(fragment);
                }

                @Override
                public void onError(Object data) {
                    // TODO Show an error message here.
                }
            });*/
            // US45209 Changes end.
        } else {/*
            //sshar13:-changes made for  US24441
            DeeplinkHelper.executeActionCodePreLogin(getActivity(), hdeepLinkHighlightedFeatureActionCode);
            FacadeFactory.getHighlightedFeaturesFacade()
                    .getPreloginHighlightedFeaturesFragment(getActivity(),
                            new NetworkRequestListener() {
                                @Override
                                public void onSuccess(Object data) {
                                    Fragment fragment = (Fragment) data;
                                    ((NavigationRootActivity) getActivity())
                                            .makeFragmentVisible(fragment);
                                }

                                @Override
                                public void onError(Object data) {
                                    // TODO Show an error message here.
                                }
                            });
		 */
            final Intent intent = new Intent(getActivity(),
                    ShowHighlightedFeatureActivity.class);

            Bundle bundle = new Bundle();
            bundle.putBoolean(ShowHighlightedFeatureActivity.GO_BACK_TO_LOGIN, false);
            bundle.putInt(HFConstants.Args.PAGER_LOCATION, 0);
            bundle.putBoolean(HFConstants.Args.WHATS_NEW_FLAG, false);
            bundle.putBoolean(HFConstants.Args.PRE_LOGIN_FLAG, isPreLogin);
            bundle.putSerializable(HFConstants.Args.LOGIN_TYPE, HFConstants.LoginType.CARD);
            intent.putExtras(bundle);
            getActivity().startActivity(intent);
        }

    }

    private void initListener() {
        Button updateApp = (Button) mMainView.findViewById(R.id.update_app_btn);
        if (updateApp != null) {
            updateApp.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    //US20350 : sshar13 :- version number analytics
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put("my.prop1", AnalyticsPage.VERSION_UPDATE_CLICKED_prop1);
                    extras.put("pe", AnalyticsPage.VERSION_UPDATE_CLICKED_pe);
                    extras.put("pev1", AnalyticsPage.VERSION_UPDATE_CLICKED_pev1);
                    TrackingHelper.trackCardPageProp1(
                            AnalyticsPage.VERSION_UPDATE_CLICKED_prop1,
                            AnalyticsPage.VERSION_UPDATE_CLICKED_pev1, extras);
                    showAppOnMarket();
                }
            });
        }
    }

    private void showAppOnMarket() {
        try {
            Intent viewIntent = new Intent("android.intent.action.VIEW",
                    Uri.parse(PLAY_URL_PREFIX + PACKAGE_FOR_MOBILE));
            startActivity(viewIntent);
        } catch (Exception e) {
            Toast.makeText(getActivity(), "Unable to Connect Try Again...",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public int getActionBarTitle() {
        return R.string.update_app_actionbar_title;
    }

    @Override
    public int getGroupMenuLocation() {
        return 0;
    }

    @Override
    public int getSectionMenuLocation() {
        return 0;
    }
}