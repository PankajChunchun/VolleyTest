package com.discover.mobile.common.fingerprint.listener;

/**
 * Interface to listen to FingerPrintDialog callbacks.
 */
public interface FingerPrintDialogActionListener {
    void handleCancelAction();
}
