package com.discover.mobile.common.permission.utils;

import android.Manifest;

/**
 * Constant class for marshmallow permission flow.
 *
 * Created by pkuma13 on 8/24/2016.
 */
public final class PermissionConstant {

    private PermissionConstant() {

        throw new UnsupportedOperationException("Cannot instantiate the type " + PermissionConstant.class.getSimpleName());
    }

    /**
     * Id to identify a camera permission request.
     */
    public static final int REQUEST_CAMERA = 0;
    /**
     * Id to identify a external storage permission request.
     */
    public static final int REQUEST_EXTERNAL_STORAGE = 1;
    /**
     * Id to identify a location permission request.
     */
    public static final int REQUEST_LOCATION = 2;

    public static final int REQUEST_READ_CONTACT = 3;
    public static final int REQUEST_READ_PHONE_STATE = 4;

    public static final int REQUEST_READ_CALENDAR_STATE = 5;

    public static final String[] DIALOG_MESSAGE = new String[]{"request_permission_camera_msg", "request_permission_ext_storage_msg", "request_permission_location_msg"};
    public static final String DIALOG_BTN_POSITIVE = "request_permission_btntxt_pos";
    public static final String DIALOG_BTN_NEGATIVE = "request_permission_btntxt_neg";
    public static final String RATIONALE_DIALOG_BTN_POSITIVE = "request_permission_btntxt_rationale_pos";
    public static final String RATIONALE_DIALOG_BTN_NEGATIVE = "request_permission_btntxt_rationale_neg";
    public static final String KEY_REDEMPTION_PERM_DIALOG_MSG = "request_permission_ext_storage_redemption_msg";
    public static final String KEY_DEALS_PERM_DIALOG_MSG = "request_permission_ext_storage_deals_msg";
    public static final String KEY_PAYMENT_PERM_DIALOG_MSG = "request_permission_ext_storage_payment_msg";
    public static final String KEY_STATEMENTS_PERM_DIALOG_MSG = "request_permission_ext_storage_statements_pdf";
    public static final String KEY_GEOFENCE_PERM_DIALOG_MSG = "request_permission_location_geofence_msg";

    //Start - US68889 Custom Permission Message Key
    public static final String BANK_CAMERA_PERMISSION = "bank_CameraPermission_txt";
    //End - US68889 Custom Permission Message Key

    //US68890- Save to Photos Permission Flow- Code change start
    //Custom storage Permission Message Key
    public static final String BANK_STORAGE_SAVE_PHOTO_PERMISSION = "bank_SaveToPhotosPermission_txt";
    public static final String BANK_STORAGE_SAVE_PDF_PERMISSION = "bank_SavePdfsPermission_txt";
    public static final String SHAKE_TOBUG_SAVE_PERMISSION = "shaketobug_Permission_txt";
    //US68890- Save to Photos Permission Flow- Code change end

    //US117184 - Secure Document Upload: Permissions Modals - start
    public static final String BANK_SDU_CAMERA_PERMISSION = "bank_sdu_CameraPermission_txt";
    public static final String BANK_SDU_STORAGE_PERMISSION = "bank_sdu_StoragePermission_txt";
    //US117184 - Secure Document Upload: Permissions Modals - end

    /**
     * Permission enum which have request-code and permission-value.
     */
    public enum Permissions {
        CAMERA {
            @Override
            public String toString() {

                return android.Manifest.permission.CAMERA;
            }

            @Override
            public int getRequestCode() {

                return REQUEST_CAMERA;
            }
        },
        EXTERNAL_STORAGE {
            @Override
            public String toString() {

                return android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
            }

            @Override
            public int getRequestCode() {

                return REQUEST_EXTERNAL_STORAGE;
            }
        },
        LOCATION {
            @Override
            public String toString() {

                return android.Manifest.permission.ACCESS_FINE_LOCATION;
            }

            @Override
            public int getRequestCode() {

                return REQUEST_LOCATION;
            }
        },

        READ_CONTACT {
            @Override
            public String toString() {

                return android.Manifest.permission.READ_CONTACTS;
            }

            @Override
            public int getRequestCode() {

                return REQUEST_READ_CONTACT;
            }
        },
        READ_PHONE_STATE {
            @Override
            public String toString() {

                return android.Manifest.permission.READ_PHONE_STATE;
            }

            @Override
            public int getRequestCode() {

                return REQUEST_READ_PHONE_STATE;
            }
        },
        READ_CALENDAR {
            @Override
            public String toString() {

                return Manifest.permission.READ_CALENDAR;
            }

            @Override
            public int getRequestCode() {

                return REQUEST_READ_CALENDAR_STATE;
            }
        };

        abstract public int getRequestCode();
    }
}
