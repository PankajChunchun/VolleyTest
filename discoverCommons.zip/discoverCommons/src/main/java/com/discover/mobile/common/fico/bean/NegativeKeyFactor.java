package com.discover.mobile.common.fico.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class NegativeKeyFactor implements Serializable {
    private static final long serialVersionUID = 419682317775845456L;

    @SerializedName("longDesc")
    private String longDesc;

    @SerializedName("shortDesc")
    private String shortDesc;

    @SerializedName("code")
    private String code;

    @SerializedName("efftDate")
    private String efftDate;

    @SerializedName("key")
    private String key;

    public String getLongDesc() {
        return longDesc;
    }

    public void setLongDesc(String longDesc) {
        this.longDesc = longDesc;
    }

    public String getShortDesc() {
        return shortDesc;
    }

    public void setShortDesc(String shortDesc) {
        this.shortDesc = shortDesc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEfftDate() {
        return efftDate;
    }

    public void setEfftDate(String efftDate) {
        this.efftDate = efftDate;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
