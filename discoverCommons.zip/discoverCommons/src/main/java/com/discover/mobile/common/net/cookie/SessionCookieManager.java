package com.discover.mobile.common.net.cookie;

import com.discover.mobile.common.facade.FacadeFactory;

import android.content.Context;

import java.io.IOException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

/**
 * Class used to manage the secToken , dfsKey , V1st etc .provided via cookies .
 * After the secToken dfsKey and V1st are extracted from the cookies it is
 * stored in this class which follows a Singleton design pattern. This class can
 * be used to clear the secToken.
 *
 * @author Mayank G
 */

public final class SessionCookieManager {

    private static final String sectoken = "sectoken";
    private static final String vfirst = "v1st";
    private static final String dfsedskey = "dfsedskey";
    private static final String strongauthsvcs = "strongauthsvcs";
    private static final String pmdata = "pmdata";
    private static final String dcsession = "dcsession";
    private static final String dcid = "dcid";
    private static final String TAG = SessionCookieManager.class.getSimpleName();
    private static SessionCookieManager sessionCookieManager;
//    private final Context sessionCookieContext;
    private final CookieManagerProxy cookieManager;
    private URI baseUri;

    /**
     * Follows a singleton design pattern. Therefore this constructor is made
     * private
     */

    private SessionCookieManager() {
//        sessionCookieContext = context;
        cookieManager = new CookieManagerProxy();
    }

    public static synchronized SessionCookieManager getInstance(
            ) {
//        if (context == null) {
//            throw new IllegalArgumentException("Invalid context argument");
//        }

        if (sessionCookieManager == null) {
            sessionCookieManager = new SessionCookieManager();
        }

        CookieManager.setDefault(sessionCookieManager.getCookieManager());

        return sessionCookieManager;
    }

    public static void configureCookieManager() {
        CookieHandler.setDefault(new CookieManagerProxy());
    }

    public String getDcsession() {
        return getCookieValue(getBaseUri(), dcsession);
    }

    public String getSTRONGAUTHSVCS() {
        return getCookieValue(getBaseUri(), strongauthsvcs);
    }

    public String getPmData() {
        return getCookieValue(getBaseUri(), pmdata);
    }

    public String getVone() {
        return getCookieValue(getBaseUri(), vfirst);
    }

    public String getSecToken() {
        String sectoken = getCookieValue(getBaseUri(), SessionCookieManager.sectoken);
//        Utils.log(TAG, "SecToken: " + sectoken);
        return sectoken;
    }

    public String getDfsKey() {
        return getCookieValue(getBaseUri(), dfsedskey);
    }

    public String getDcid() {
        return getCookieValue(getBaseUri(), dcid);
    }

    private String getCookieValue(URI uri, String cookieName) {
        if (uri == null) {
            uri = getBaseUri();
        }

        try {
            Map<String, List<String>> cookies = cookieManager.get(uri, null);

            if (cookies == null || cookies.get("Cookie") == null
                    || cookies.get("Cookie").size() == 0) {
                // No cookies, return null
//                Utils.log(TAG, "getCookieValue: No cookues retrieved for " + uri.toURL());
                return null;
            }

            for (String cookieRaw : cookies.get("Cookie")) {
                for (String cookieSplit : cookieRaw.split(";")) {
                    String[] cookie = cookieSplit.split("=", 2);
//                    Utils.log(TAG, "getCookieValue: Cookie " + cookie[0].trim() + " === "
//                            + cookie[1].trim());
                    if (cookie[0].trim().equalsIgnoreCase(cookieName)) {
                        return cookie[1].trim();
                    }
                }
            }

            return null;
        } catch (IOException e) {
            return null;
        }

    }

    /**
     * This method will provide the current cookiestore used by cookiemanager
     */
    public void clearAllCookie() {
        cookieManager.clearAllCookies();
    }

    public URI getBaseUri() {

        if (null == baseUri) {

            String url = FacadeFactory.getCardFacade().getCardBaseUrl();
            try {
                baseUri = new URI(url);
            } catch (final URISyntaxException e) {
                // This is pretty bad, since the URL should always be parseable.
                throw new IllegalArgumentException("Environment base url not parseable as URI: "
                        + url);
            }
        }
        return baseUri;
    }

    // hkakadi sitedrift issues, need this mathod to be public
    public CookieManager getCookieManager() {
        return cookieManager;
    }

}
