package com.discover.mobile.common.appmessaging.helper;

import com.discover.mobile.common.Constants;
import com.discover.mobile.common.R;
import com.discover.mobile.common.appmessaging.ui.Level3AppMessagingDialog;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.shared.utils.image.ImageLoader2;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.List;
import java.util.Map;

/**
 * Utility Class for Bank App messging features.
 */
public class BankAppMessageUtils {

    /**
     * Display the Level3 (US44079) & Level2 App messaging modal.
     **/
    private static String deepLink;

    private static final String CLOSE_TXT = "Close";

    public static String getDeepLink() {
        return deepLink;
    }

    public static void setDeepLink(String deepLink) {
        BankAppMessageUtils.deepLink = deepLink;
    }
    public static void showAppMessages(final Context context, String messageKey) {

        /*Verify and load target data from customer service call*/
        Map<String, AppMessage> appMsgDataList = FacadeFactory.getBankFacade().getAppMessageList();
        AppMessage appMessage = null;

        if (appMsgDataList != null && appMsgDataList.containsKey(messageKey)) {
            appMessage = appMsgDataList.get(messageKey);
        }

        /*return if there are no level3 messages available for current screen*/
        if (appMessage == null) {
            return;
        }
        /*setting up level3 App Messaging modal*/
        if (!appMessage.isLevelMsgViewed() && appMessage.getMessageType().equals(Constants.APP_MSG_LEVEL_THREE)) {
            showLevel3AppMessage(context, appMessage);
        }
        /*setting up level2 App Messaging modal*/
        else if (!appMessage.isLevelMsgViewed() && appMessage.getMessageType().equals(Constants.APP_MSG_LEVEL_TWO)) {
            showLevel2AppMessage(context, appMessage); // to be implemented
        }
    }

    public static void showLevel2AppMessage(Context mContext, AppMessage appMessage) {
        FacadeFactory.getBankFacade().navigateToLevel2AppMessage(mContext, appMessage);
    }

    /*Show level3 app message, if current feature/screen has level3 message*/

    public static void showLevel3AppMessage(final Context context, AppMessage appMessage) {

        final Level3AppMessagingDialog modal = new Level3AppMessagingDialog(context);
        //245812-start
        modal.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        //245812- end
        if (appMessage.getTitle() != null)
            modal.setMessageTitleText(appMessage.getTitle().toString());

        if (appMessage.getSubTitle() != null)
            modal.setMessageSubTitleText(appMessage.getSubTitle().toString());

        if (appMessage.getMessage() != null)
            modal.setMessageBodyText(appMessage.getMessage().toString());

        if (appMessage.getImgUrl() != null)
            initImageView(context, modal.getMessageImageView(), appMessage.getImgUrl());

        String buttonText = null;
        if (appMessage.getActionList() != null) {
            //Start : US72800 - Level 3 Button Arrangement
            if (appMessage.getActionList().size() == 1) {
                AppMessageAction appMessageAction = appMessage.getActionList().get(0);
                if(appMessageAction!=null) {
                    if(appMessageAction.getTitle().equalsIgnoreCase(CLOSE_TXT)){
                        //Show close primary button
                        showOrangeCLoseButton(context, modal.getDynamicButtonOne(), modal.getCloseButton());
                    }else{
                        //Set text as primary button
                        buttonText = appMessage.getActionList().get(0).getTitle();
                    }
                }
            } else if (appMessage.getActionList().size() == 2) {
                AppMessageAction appMessageActionOne = appMessage.getActionList().get(0);
                AppMessageAction appMessageActionTwo = appMessage.getActionList().get(1);

                if(appMessageActionOne!=null && appMessageActionTwo!=null) {
                    if (!appMessageActionOne.getTitle().equalsIgnoreCase(CLOSE_TXT)) {
                        //Set the first action button as primary button
                        buttonText = appMessageActionOne.getTitle();
                    } else {
                        //Set the second action button as primary button
                        buttonText = appMessageActionTwo.getTitle();
                    }
                }
                //End : US72800 - Level 3 Button Arrangement

            } else if (appMessage.getActionList().size() == 0) {
                showOrangeCLoseButton(context, modal.getDynamicButtonOne(), modal.getCloseButton());
            }

            if (buttonText != null) {
                //US72800 - Level 3 Button Arrangement
                //Set the primary button text and visiblity
                modal.getDynamicButtonOne().setVisibility(View.VISIBLE);
                modal.setDynamicButtonOne(buttonText);
            }
        } else {
            showOrangeCLoseButton(context, modal.getDynamicButtonOne(), modal.getCloseButton());
        }

        final AppMessage finalAppMessage = appMessage;

        modal.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialogInterface, int keyCode, KeyEvent keyEvent) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    initiateFeedbackLoopServiceCall(context, finalAppMessage.getId(), finalAppMessage.isMenu(), Constants.APP_MSG_INTERACTION_VIEW);
                    modal.dismiss();
                }
                return true;
            }
        });

        modal.getCloseButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {

                initiateFeedbackLoopServiceCall(context, finalAppMessage.getId(), finalAppMessage.isMenu(), Constants.APP_MSG_INTERACTION_VIEW);
                modal.dismiss();
            }
        });

        modal.getDynamicButtonOne().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {

                try {
                    if (finalAppMessage.getActionList() != null) {
                        //Start : US72800 - Level 3 Button Arrangement
                        List<AppMessageAction> appMessageActionList = finalAppMessage.getActionList();

                        if (appMessageActionList.size() == 1) {
                            String title = appMessageActionList.get(0).getTitle();

                            if( title != null){
                                //Primary button click event handler
                                if(!title.equalsIgnoreCase(CLOSE_TXT) &&  appMessageActionList.get(0).getLink() != null){
                                    FacadeFactory.getBankFacade().navigateViaDeeplink(appMessageActionList.get(0).getLink());
                                    setDeepLink(appMessageActionList.get(0).getLink());
                                }

                            }

                        }else if(appMessageActionList.size() == 2){

                            String titleOne = appMessageActionList.get(0).getTitle();
                            String titleTwo = appMessageActionList.get(1).getTitle();

                            if(!titleOne.equalsIgnoreCase(CLOSE_TXT) && appMessageActionList.get(0).getLink() != null){
                                //First action item, primary button click event
                                FacadeFactory.getBankFacade().navigateViaDeeplink(appMessageActionList.get(0).getLink());
                                setDeepLink(appMessageActionList.get(0).getLink());
                            }else if(!titleTwo.equalsIgnoreCase(CLOSE_TXT) && appMessageActionList.get(1).getLink() != null){
                                //Second action item, primary button click event
                                FacadeFactory.getBankFacade().navigateViaDeeplink(appMessageActionList.get(1).getLink());
                                setDeepLink(appMessageActionList.get(1).getLink());
                            }
                        }
                        //End : US72800 - Level 3 Button Arrangement
                        initiateFeedbackLoopServiceCall(context, finalAppMessage.getId(), finalAppMessage.isMenu(), Constants.APP_MSG_INTERACTION_TAP);
                        modal.dismiss();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        modal.show();

        /*Update the FeedbackLoop and update the WinkState, if user viewed the Level3 app message.*/
        if (modal.isShowing()) {
            try {
                //Start : US72800: Level 3 button arrangement
                modal.getDynamicButtonOne().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Do button arangement after modal loads
                        modal.setButtonAlignment();
                    }
                },100);
                //End : US72800: Level 3 button arrangement


                FacadeFactory.getBankFacade().getAppMessageList().get(appMessage.getKey()).setIsLevelMsgViewed(true);
                initiateFeedbackLoopServiceCall(context, appMessage.getId(), appMessage.isMenu(), Constants.APP_MSG_INTERACTION_VIEW);
                FacadeFactory.getBankFacade().updateWinkState(appMessage.getKey(), false);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public static void showOrangeCLoseButton(Context context, Button orangeButton, Button blueButton) {
        orangeButton.setText(context.getResources().getString(R.string.app_msg_close_button_text));
        orangeButton.setVisibility(View.VISIBLE);
        blueButton.setVisibility(View.GONE);
    }

    /**
     * Load the imageview with the dynamic image.
     */
    public static void initImageView(Context context, ImageView imageView, String imageUrl) {

        ImageLoader2 loader = new ImageLoader2(context);
        loader.setDefaultImageResourceID(R.drawable.circle_place_holder);

        if (!imageUrl.isEmpty()) {
            loader.DisplayImage(imageUrl, imageView);
        }
        imageView.setMinimumHeight(imageView.getHeight());
    }

    /*To initiate the service call for App messaging Feedback Loop*/

    public static void initiateFeedbackLoopServiceCall(Context context, String messageID, boolean isMenu, String interaction) {
        TrackAppMessage trackAppMessage = new TrackAppMessage();
        trackAppMessage.id = messageID;
        trackAppMessage.menu = isMenu;
        trackAppMessage.interaction = interaction;
        FacadeFactory.getBankFacade().callTrackAppMessageService(context, trackAppMessage);
    }



}
