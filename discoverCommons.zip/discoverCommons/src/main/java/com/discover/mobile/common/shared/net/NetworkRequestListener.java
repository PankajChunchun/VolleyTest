package com.discover.mobile.common.shared.net;

public interface NetworkRequestListener {

    public void onSuccess(Object data);

    public void onError(Object data);

}
