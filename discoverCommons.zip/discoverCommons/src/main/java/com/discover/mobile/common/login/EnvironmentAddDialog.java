package com.discover.mobile.common.login;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;

import com.discover.mobile.common.R;
import com.discover.mobile.common.uiwidget.CmnEditText;
import com.discover.mobile.common.uiwidget.CmnTextInputLayout;
import com.discover.mobile.common.widget.BankUrlChangerPreferences;
import com.discover.mobile.common.widget.BankUrlSite;

/**
 * Created by pdesai4 on 2/1/2017.
 *
 * Dialog with fields to add a new environment.
 *
 */

public class EnvironmentAddDialog extends DialogFragment {
    TextInputLayout inputBankLayout, inputCardLayout, inputTitleLayout;
    EditText editBankText, editCardText, editTitleText;
    private CoordinatorLayout coordinatorLayout;
    BankUrlSite environmentInfo;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.environment_add, container, false);
        //toolbar with Environment title
        Toolbar toolbar = (Toolbar) rootView.findViewById(R.id.toolbar);
        toolbar.setTitle("New Environment");

        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        //Action bar with close button
        ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setHomeAsUpIndicator(android.R.drawable.ic_menu_close_clear_cancel);
        }

        setHasOptionsMenu(true);
        return rootView;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        return dialog;
    }

    //save button as a menu item
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        getActivity().getMenuInflater().inflate(R.menu.custom_menu, menu);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        coordinatorLayout = (CoordinatorLayout) getDialog().findViewById(R.id.environ_add_coordinate);
        editBankText= (EditText) getDialog().findViewById(R.id.bank_edit_text);
        editCardText= (EditText) getDialog().findViewById(R.id.card_edit_text);
        editTitleText= (EditText) getDialog().findViewById(R.id.title_edit_text);

    }

    @Override
    public void onDismiss(final DialogInterface dialog) {
        super.onDismiss(dialog);
        final Activity activity = getActivity();
        if (activity instanceof DialogInterface.OnDismissListener) {
            ((DialogInterface.OnDismissListener) activity).onDismiss(dialog);
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_save) {
            if(checker())                               //checker for empty string
            {
                saveAndAdd();                           //saves the preferences
                dismiss();
            }
            return true;
        } else if (id == android.R.id.home) {
            dismiss();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //checks for empty textfields and alerts user
    public boolean checker()
    {
        Boolean check= true;
        if(editBankText.getText().toString().isEmpty() || editBankText.getText()== null)
        {
            Snackbar snackbar = Snackbar.make(coordinatorLayout, "Please Enter Bank Link!!!", Snackbar.LENGTH_LONG);
            snackbar.show();
            check= false;
        }
        else if(editCardText.getText().toString().isEmpty() || editCardText.getText()== null)
        {
            Snackbar snackbar = Snackbar.make(coordinatorLayout, "Please Enter Card Link!!!", Snackbar.LENGTH_LONG);
            snackbar.show();
            check= false;
        }
        else if(editTitleText.getText().toString().isEmpty() || editTitleText.getText()== null)
        {
            Snackbar snackbar = Snackbar.make(coordinatorLayout, "Please Enter Title!!!", Snackbar.LENGTH_LONG);
            snackbar.show();
            check= false;
        }
        return check;
    }

    //saves the new BankUrlSite to the preferences
    public void saveAndAdd()
    {
        String bankLink = editBankText.getText().toString();
        String cardLink = editCardText.getText().toString();
        String title= editTitleText.getText().toString();

        environmentInfo = new BankUrlSite(bankLink,cardLink,title,-1,false);
        BankUrlChangerPreferences bankUrlChangerPreferences =  new BankUrlChangerPreferences();
        bankUrlChangerPreferences.addSite(getActivity(),environmentInfo);
    }

}
