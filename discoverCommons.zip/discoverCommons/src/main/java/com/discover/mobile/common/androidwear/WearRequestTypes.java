package com.discover.mobile.common.androidwear;

/**
 * Created by vijay on 1/31/15.
 */
public class WearRequestTypes {
    public static final String PATH_WEAR_SETTINGS_REQUEST = "/wearsettingsrequest";
    public static final String PATH_WEAR_SETTINGS_RESPONSE = "/wearsettingsresponse";
    public static final String PATH_WEAR_SETTINGS_TURNON_REQUEST = "/wearsettingsturnonrequest";
    public static final String PATH_CARD_QV_RESPONSE = "/cardqvresponse";
    public static final String PATH_CARD_QV_REQUEST = "/cardqvrequest";
    public static final String PATH_CARD_PAYLOAD = "/cardpayload";
    public static final String SUB_TITLE = "subtitle";
    public static final String PATH_DISMISS = "/dismissnotification";
    public static final String PATH_SERVER_RESPONSE = "/response";
    public static final String PATH_SERVER_REQUEST = "/request";
    public static final String PATH_NOTIFICATION = "/notification";
    public static final String PATH_CUSTOM_NOTIFICATION = "/customnotification";
    public static final String PATH_SUPRESS_NOTIFICATION = "/supressnotification";
    public static final String KEY_TITLE = "title";
    public static final String KEY_IMAGE = "image";
    public static final String KEY_NOTIFICATION_ID = "notification_id";
    public static final String KEY_TIMESTAMP = "timestamp";
    public static final String KEY_ISWEARSETTINGSENABLED = "iswear";
    public static final String OPEN_PHONE = "/openonphone";
    public static final String PATH_QV_UI_UPDATE = "/qvuiupdate";
    public static final String NETWORK_OFF_ERROR_CODE = "4242";
    public static final String WEAR_TURN_OFF_ERROR_CODE = "1111";
    public static final String TOGGLE_UPDATE_ERROR_CODE = "{\"errorCode\":\"1212\"}";
    public static final String KEY_ISTOGGLECARDORBANK = "isTogglingCardOrBank";
    public static final String KEY_IS_CARD_CHECKED = "isCardChecked";
    public static final String PATH_DISMISS_NOTIFICATION_MOBILE = "/dismissnotificationmobile";
    public static final String PATH_DISMISS_NOTIFICATION_WEAR = "/dismissnotificationwear";
    public static final String PATH_NOTIFICATION_CALL_DIALER = "/notificationcalldialer";

    // analytics
    public static final String APP_LAUNCH = "appLaunch";
    public static final String TURN_ON_SETTINGS_PAGE = "turnOnWearSettingsPage";
    public static final String SSO_ACCOUNT_SUMMARY = "ssoAccountSummaryViewed";
    public static final String USER_ACCOUNT_SUMMARY = "normalUserAccountSummaryViewed";

}
