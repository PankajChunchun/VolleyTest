package com.discover.mobile.common.fico;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.discover.mobile.common.DiscoverModalManager;
import com.discover.mobile.common.R;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.fico.fragments.CmnFicoCreditScoreMasterFragment;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreHostInterface;
import com.discover.mobile.common.fico.utils.FicoUtils;
import com.discover.mobile.common.interfaces.CmnEventHandler;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.nav.listener.IFragmentOnBackPressed;
import com.discover.mobile.common.nav.listener.IMenuEvenListener;
import com.discover.mobile.common.portalpage.PortalPageActivity;
import com.discover.mobile.common.portalpage.beans.AccountV2Details;
import com.discover.mobile.common.portalpage.utils.PortalCacheDataUtils;
import com.discover.mobile.common.portalpage.utils.PortalUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.network.error.bean.ErrorBean;

/**
 * Created by 451769 on 6/14/2017.
 */

public class CmnFicoCreditScoreActivity extends ActionBarBaseActivity implements IMenuEvenListener, CmnEventHandler {
    private String edsKey = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DiscoverActivityManager.setActiveActivity(this);
        setContentView(NO_LAYOUT);
        DiscoverModalManager.clearActiveModal();
        launchFicoFragment();
        showBackX();

        /*Defect Fixed:16422 :As we are loading card side feature like FICO Credit Scorecard FAQ Details Page , So we need one Card Data loaded in card Cache*/
        final AccountV2Details portalAccountDetails = PortalCacheDataUtils.getPortalCacheDataUtilsInstance().getAccountV2Details();
        if (portalAccountDetails != null) {
            edsKey = (String) portalAccountDetails.getCardAccountsMap().keySet().toArray()[0];
            if (edsKey != null) {
                FacadeFactory.getPortalPageFacade().updateCardCache(CmnFicoCreditScoreActivity.this, edsKey);
            }
        }

    }


    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }


    @Override
    public void onMenuItemClicked(String title) {

    }

    private void launchFicoFragment() {
        CmnFicoCreditScoreMasterFragment fico_fragment = new CmnFicoCreditScoreMasterFragment();
        makeFragmentVisible(fico_fragment, true);
    }

    @Override
    public void onBackPressed() {
        final FragmentManager fragManager = this.getSupportFragmentManager();
        int stackCount = fragManager.getBackStackEntryCount();
        if (stackCount > 0) {
            String currentFragment = fragManager.getBackStackEntryAt(stackCount - 1).getName();
            Fragment fragmentToPop = fragManager.findFragmentByTag(currentFragment);
            Fragment fragToResumeOnBackKey = null;

            if (fragmentToPop instanceof IFragmentOnBackPressed) {
                boolean keepParentFrag = ((IFragmentOnBackPressed) fragmentToPop).onBackPressed();
                if (!keepParentFrag) {
                    if (fragmentToPop.getClass().getSimpleName().equalsIgnoreCase(CmnFicoCreditScoreMasterFragment.class.getSimpleName())) {
                        PortalUtils.navToPortalActivity();
                    } else {
                        fragManager.popBackStackImmediate();
                    }
                }

            }
        }


    }

    private void showBackX() {
        setActionbarBackNavigation(new Runnable() {
            @Override
            public void run() {
                handleBackAction();
            }

            private void handleBackAction() {
                // PortalUtils.navToPortalActivity();
                /*Defect 16700 fixed*/
                onBackPressed();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.fico_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.portal_icon) {
            PortalUtils.navToPortalActivity();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean handleEvent(CmnEvent strAction, String strParameter) {
        FacadeFactory.getPortalPageFacade().navigateToFicoPrivacyTerms(strAction, this,strParameter);
        return true;
    }
}




