package com.discover.mobile.common.portalpage.service;

import com.discover.mobile.common.portalpage.beans.BankPayload;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Headers;

/**
 * Interface for request type used in Retro-fit for Bank Refresh Payload services.
 *
 * @author CTS
 */
public interface BankPayloadServiceInterface {
    @Headers("Content-Type: application/json")
    @GET("/cardsvcs/acs/acct/v1/refreshpayload")
    void getRefreshPayload(Callback<BankPayload> BankPayload);
}
