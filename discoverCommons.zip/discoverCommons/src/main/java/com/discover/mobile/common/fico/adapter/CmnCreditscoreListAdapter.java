package com.discover.mobile.common.fico.adapter;

import com.discover.mobile.common.fico.bean.CmnFicoListHeaderBean;
import com.discover.mobile.common.fico.bean.CmnFicoListItemBean;
import com.discover.mobile.common.fico.interfaces.CmnFicoListItemInterface;
import com.discover.mobile.common.fico.interfaces.FicoCreditScoreLandingUIInterface;
import com.discover.mobile.common.fico.views.CmnCreditscoreListItemView;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;

import static com.discover.mobile.common.fico.utils.FicoCreditScoreConstants.FicoScoreList.VIEW_TYPE_LIST_HEADER;
import static com.discover.mobile.common.fico.utils.FicoCreditScoreConstants.FicoScoreList.VIEW_TYPE_LIST_ITEM;

/**
 * Created by slende
 * Adapter class to show credit score list
 */

public class CmnCreditscoreListAdapter extends ArrayAdapter {

    private static int TYPE_MAX_COUNT;
    private static List<Integer> viewTypeLIST;
    private ArrayList<CmnFicoListItemInterface> mFicoListData;
    private FicoCreditScoreLandingUIInterface mLandingUIInterface;
    private Context mContext;

    static {
        viewTypeLIST = new ArrayList<>();
        viewTypeLIST.add(VIEW_TYPE_LIST_HEADER);
        viewTypeLIST.add(VIEW_TYPE_LIST_ITEM);
        TYPE_MAX_COUNT = viewTypeLIST.size();
    }

    public CmnCreditscoreListAdapter(Context context, ArrayList<CmnFicoListItemInterface> ficoList, FicoCreditScoreLandingUIInterface uIInterface) {
        super(context, android.R.layout.list_content);
        mContext = context;
        mFicoListData = ficoList;
        mLandingUIInterface = uIInterface;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final CmnFicoListItemInterface dataItem = mFicoListData.get(position);
        int itemViewType = getItemViewType(position);

        if (convertView == null) {
            convertView = new CmnCreditscoreListItemView(mContext);
        }

        switch (viewTypeLIST.get(itemViewType)) {

            case VIEW_TYPE_LIST_HEADER:
                ((CmnCreditscoreListItemView) convertView).mapViewWithData(VIEW_TYPE_LIST_HEADER, dataItem);
                (convertView).setTag(dataItem);
                break;

            case VIEW_TYPE_LIST_ITEM:
                ((CmnCreditscoreListItemView) convertView).mapViewWithData(VIEW_TYPE_LIST_ITEM, dataItem);
                (convertView).setTag(dataItem);

                if (dataItem instanceof CmnFicoListItemBean) {
                    CmnFicoListItemBean FicoListItemBean = (CmnFicoListItemBean) dataItem;
                    if (FicoListItemBean.isHasScore()) {
                        ((CmnCreditscoreListItemView) convertView).getListItemRoot().setClickable(true);
                        ((CmnCreditscoreListItemView) convertView).getListItemRoot().setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View v) {
                                handleListItemClik(dataItem);
                            }
                        });
                    } else {
                        ((CmnCreditscoreListItemView) convertView).getListItemRoot().setClickable(false);
                    }
                }
                break;

            default:
                break;
        }
        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        int itemViewType = 0;
        CmnFicoListItemInterface dataItem = mFicoListData.get(position);
        if (dataItem instanceof CmnFicoListHeaderBean) {
            itemViewType = VIEW_TYPE_LIST_HEADER;
        } else if (dataItem instanceof CmnFicoListItemBean) {
            itemViewType = VIEW_TYPE_LIST_ITEM;
        }
        return viewTypeLIST.indexOf(itemViewType);
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_MAX_COUNT;
    }

    @Override
    public int getCount() {
        return mFicoListData.size();
    }

    /**
     * Method to handle click on list item
     */
    public void handleListItemClik(CmnFicoListItemInterface dataItem) {
        if (null != dataItem && dataItem instanceof CmnFicoListItemInterface) {
            CmnFicoListItemBean listItemBean = (CmnFicoListItemBean) dataItem;
            if (listItemBean.isHasScore() && null != mLandingUIInterface) {
                mLandingUIInterface.showKeyFactorDetailModal(listItemBean.getFicoScoreListItem());
            }
        }
    }

}
