package com.discover.mobile.common.fico.bean;

import com.discover.mobile.common.fico.interfaces.CmnFicoListItemInterface;

/**
 * Class to hold Year label value of FICO list
 *
 * @author slende
 */
public class CmnFicoListYearLabelBean implements CmnFicoListItemInterface {

    private String yearLabel;

    public String getYearLabel() {
        return yearLabel;
    }

    public void setYearLabel(String yearLabel) {
        this.yearLabel = yearLabel;
    }
}
