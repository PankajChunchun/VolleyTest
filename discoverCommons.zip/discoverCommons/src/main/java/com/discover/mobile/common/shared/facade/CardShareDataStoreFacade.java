package com.discover.mobile.common.shared.facade;

import android.content.Context;


public interface CardShareDataStoreFacade {
    /**
     * @param object : error json object
     */
    public void storeToAppCache(Context context, Object object);


    /**
     * @param object : error json object
     */
    public void storeToAppCache(Context context, Object object, String key);


    /**
     * This will give the data mapped with particular key
     */
    public Object getValueOfAppCache(final String key,Context context);
}
