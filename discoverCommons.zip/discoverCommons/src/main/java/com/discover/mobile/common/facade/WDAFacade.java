package com.discover.mobile.common.facade;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.support.v4.app.Fragment;

public interface WDAFacade {

    void setUpWDA(Activity activity);

    void trackAppForeground();

    void getWdaActionCode(Context context, Uri deeplink);

    boolean isSupportedDeeplink(String code);

    //US28600 - Deep link user story
    boolean isDeepLink(Activity activity, Fragment fragment);
}
