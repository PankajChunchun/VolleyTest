package com.discover.mobile.common.ui.chipView;

public interface OnChipClickListener {
    void onChipClick(Chip chip);
    void onChipDelete(Chip chip);
}
