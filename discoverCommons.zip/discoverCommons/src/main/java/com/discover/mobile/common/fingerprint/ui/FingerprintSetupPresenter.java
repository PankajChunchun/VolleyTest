package com.discover.mobile.common.fingerprint.ui;

/**
 * Interface that is implemented by {@link FingerprintSetupPresenterImpl} which used to
 * write helper function and routing the Service calls
 */
public interface FingerprintSetupPresenter {
    void validatePasscode(String passcode);

    void onToggleStateChange(boolean isChecked);

    void onClickPrivacyTerms();

    void onClickProvideFeedback();

}
