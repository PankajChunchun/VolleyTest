package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

/**
 * Created by 407898 on 10/27/2016.
 */
public class DynamicMessageBean {


    @SerializedName("messageTier")
    private String messageTier;

    @SerializedName("messageKey")
    private String messageKey;

    @SerializedName("messageTitle")
    private String messageTitle;

    @SerializedName("messageContent")
    private String messageContent;

    @SerializedName("messageDesc")
    private String messageDesc;

    @SerializedName("messageSeverity")
    private String messageSeverity;

    @SerializedName("messageActionCode")
    private String messageActionCode;

    @SerializedName("messageActionUrl")
    private String messageActionUrl;

    @SerializedName("canBeSuppressed")
    private String canBeSuppressed;

    @SerializedName("messageOrder")
    private String messageOrder;

    @SerializedName("showLabel")
    private String showLabel;

    @SerializedName("contentId")
    private String contentId;


    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }



    public DynamicMessageBean() {
    }

    public String getShowLabel() {
        return showLabel;
    }

    public void setShowLabel(String showLabel) {
        this.showLabel = showLabel;
    }

    public String getMessageTier() {
        return messageTier;
    }

    public void setMessageTier(String messageTier) {
        this.messageTier = messageTier;
    }

    public String getMessageKey() {
        return messageKey;
    }

    public void setMessageKey(String messageKey) {
        this.messageKey = messageKey;
    }

    public String getMessageTitle() {
        return messageTitle;
    }

    public void setMessageTitle(String messageTitle) {
        this.messageTitle = messageTitle;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public String getMessageDesc() {
        return messageDesc;
    }

    public void setMessageDesc(String messageDesc) {
        this.messageDesc = messageDesc;
    }

    public String getMessageSeverity() {
        return messageSeverity;
    }

    public void setMessageSeverity(String messageSeverity) {
        this.messageSeverity = messageSeverity;
    }

    public String getMessageActionCode() {
        return messageActionCode;
    }

    public void setMessageActionCode(String messageActionCode) {
        this.messageActionCode = messageActionCode;
    }

    public String getMessageActionUrl() {
        return messageActionUrl;
    }

    public void setMessageActionUrl(String messageActionUrl) {
        this.messageActionUrl = messageActionUrl;
    }

    public String getCanBeSuppressed() {
        return canBeSuppressed;
    }

    public void setCanBeSuppressed(String canBeSuppressed) {
        this.canBeSuppressed = canBeSuppressed;
    }

    public String getMessageOrder() {
        return messageOrder;
    }

    public void setMessageOrder(String messageOrder) {
        this.messageOrder = messageOrder;
    }


    public DynamicMessageBean(DynamicMessageBean dynamicMessageBean) {
        this.setMessageContent(dynamicMessageBean.getMessageContent());
        this.setMessageDesc(dynamicMessageBean.getMessageDesc());
        this.setMessageTitle(dynamicMessageBean.getMessageTitle());
        this.setMessageSeverity(dynamicMessageBean.getMessageSeverity());
        this.setShowLabel(dynamicMessageBean.getShowLabel());
        this.setMessageActionCode((dynamicMessageBean.getMessageActionCode()));
        this.setMessageKey((dynamicMessageBean.getMessageKey()));
        this.setMessageOrder((dynamicMessageBean.getMessageOrder()));
        this.setContentId((dynamicMessageBean.getContentId()));
        this.setMessageTier(dynamicMessageBean.getMessageTier());
        this.setCanBeSuppressed(dynamicMessageBean.getCanBeSuppressed());
        this.setMessageActionUrl(dynamicMessageBean.getMessageActionUrl());
    }
}
