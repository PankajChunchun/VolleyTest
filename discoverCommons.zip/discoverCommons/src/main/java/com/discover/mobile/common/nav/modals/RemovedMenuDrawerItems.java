package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

public class RemovedMenuDrawerItems {
    @SerializedName("ItemToBeRemoved")
    public String itemToBeRemoved;

    public String getItemToBeRemoved() {
        return itemToBeRemoved;
    }

    public void setItemToBeRemoved(String itemToBeRemoved) {
        this.itemToBeRemoved = itemToBeRemoved;
    }
}
