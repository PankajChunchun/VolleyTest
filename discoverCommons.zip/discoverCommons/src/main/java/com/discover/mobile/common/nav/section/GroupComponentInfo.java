package com.discover.mobile.common.nav.section;

import android.view.View.OnClickListener;

import java.util.ArrayList;

import javax.annotation.concurrent.Immutable;


/**
 * This is the object that creates a group of component infos. This object is what is
 * needed in order to create a main and sub menu options that show and hide.
 *
 * @author ajleeds
 */
@Immutable
public class GroupComponentInfo extends ComponentInfo {

    public static final int NO_SUB_SECTIONS = -1;

    private final ArrayList<ComponentInfo> subSections;

    public GroupComponentInfo(final int titleResource, final ComponentInfo... subSections) {
        super(titleResource);
        this.subSections = new ArrayList<ComponentInfo>();
        for (int i = 0; i < subSections.length; i++) {
            this.subSections.add(subSections[i]);
        }
    }

    public GroupComponentInfo(final int titleResource, final OnClickListener clickListener, final ComponentInfo... subSections) {
        super(titleResource, false, clickListener);
        this.subSections = new ArrayList<ComponentInfo>();
        for (int i = 0; i < subSections.length; i++) {
            this.subSections.add(subSections[i]);
        }
    }

    public final ArrayList<ComponentInfo> getSubSections() {
        return subSections;
    }

}
