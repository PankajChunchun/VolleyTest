package com.discover.mobile.common.shared.net;


import com.discover.mobile.common.shared.callback.AsyncCallback;
import com.discover.mobile.common.shared.utils.CommonUtils;

/**
 * Simple reference handler that can be used on most calls
 *
 * @param <V> - class to map the detial to
 * @author jthornton
 */
public class SimpleReferenceHandler<V> extends TypedReferenceHandler<V> {

    /** Callback associated with this handler */
    private final AsyncCallback<V> callback;

    /**
     * Constructor for the class
     *
     * @param callback - callback associated with this handler
     */
    public SimpleReferenceHandler(final AsyncCallback<V> callback) {
        CommonUtils.checkNotNull(callback, "callback cannot be null");
        this.callback = callback;
    }

    /**
     * Get the callback
     *
     * @return the callback
     */
    @Override
    protected AsyncCallback<V> getCallback() {
        return callback;
    }

}