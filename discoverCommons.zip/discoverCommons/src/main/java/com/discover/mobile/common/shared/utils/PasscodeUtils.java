package com.discover.mobile.common.shared.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.discover.mobile.common.fingerprint.utils.FingerPrintUtils;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;

import java.util.Calendar;

public class PasscodeUtils {

    public static final String PREFS_NAME = "PasscodePrefsFile";
    public static final String PREFS_TOKEN = "token";
    public static final String PREFS_USERS_FIRST_NAME = "fname";
    public static final String PREFS_FORGOT_PASSCODE = "forgot_passcode";
    public static final String PREFS_PASSCODE_USER_ID = "fuserid";
    public static final String PREFS_CLA_USER_HIDE_TOGGLE = "clauserhidetoggle";// us20958 - nkaza // Hide toggle boolean
    public static final String PREFS_SETUP_PASSCODE_DEEPLINK = "setup_passcode_deeplink";
    private static final String TAG = "PasscodeUtils";
    private static final String APP_SHARED_PREFS = PasscodeUtils.class
            .getSimpleName(); // Name of the file -.xml for card
    private static final String BANK_APP_SHARED_PREFS = "BankPasscodeUtils"; // Name of the file -.xml for bank
    private static final String SSO_APP_SHARED_PREFS = "SSOPasscodeUtils"; // us20958 -for SSO nkaza
    public static boolean iscardlogin;
    public static boolean ssouser = false;//Token set for sso user , true for sso user
    Context context = null;
    private SharedPreferences _sharedPrefs; // shared preference used for bank and card
    private SharedPreferences _sharedPrefs_sso; //shared preference used for storing sso token
    private Editor _prefsEditor; // _sharedPrefs preference editor
    private Editor _prefsEditorSso; //_sharedPrefsSSO preference editor
    private String clearToken;

    public PasscodeUtils(Context context) {
        /*
         * this._sharedPrefs = context.getSharedPreferences(APP_SHARED_PREFS,
		 * Activity.MODE_PRIVATE); this._prefsEditor = _sharedPrefs.edit();
		 */
        this(context, true);
    }

    public PasscodeUtils(Context context, boolean iscardlogin) {
        this.context = context;
        if (iscardlogin) {
            this._sharedPrefs = context.getSharedPreferences(APP_SHARED_PREFS,
                    Activity.MODE_PRIVATE);
        } else {
            this._sharedPrefs = context.getSharedPreferences(
                    BANK_APP_SHARED_PREFS, Activity.MODE_PRIVATE);
        }
        this._prefsEditor = _sharedPrefs.edit();
        System.out.println("ssouser" + ssouser);
        //	if (ssouser) {
        this._sharedPrefs_sso = context.getSharedPreferences(
                SSO_APP_SHARED_PREFS, Activity.MODE_PRIVATE);
        this._prefsEditorSso = _sharedPrefs_sso.edit();
        //	}
    }

    public static boolean isPasscodeValidLocally(String passcode) {
        // i.e. 1,2,3,4
        if (isNumberSequential(0, passcode, 1)) {
            return false;
        }
        // i.e. 4,3,2,1
        if (isNumberSequential(0, passcode, -1)) {
            return false;
        }
        // i.e. 2,2,2,2
        if (isNumberSequential(0, passcode, 0)) {
            return false;
        }
        if ("6011".equals(passcode)) {
            return false;
        }
        return true;
    }

    private static boolean isNumberSequential(int position, String s, int step) {
        if (position >= s.length() - 1) {
            return true;
        }
        int n1 = Character.getNumericValue(s.charAt(position));
        int n2 = Character.getNumericValue(s.charAt(position + 1));
        if (n1 + step != n2) {
            return false;
        } else {
            return isNumberSequential(position + 1, s, step);
        }
    }

    public static boolean isCharNumeric(CharSequence paramCharSequence) {
        if (paramCharSequence.length() != 1) {
            return false;
        }
        return new String("1234567890").contains(paramCharSequence);
    }

    //

    public static boolean isCharEmpty(CharSequence paramCharSequence) {
        return (paramCharSequence.length() == 0);
    }

    public String getFirstName() {
        return _sharedPrefs.getString(PREFS_USERS_FIRST_NAME, null);
    }

    // hlin0 updated on 20140122, may need to decrypt, also throw back exception
    public String getClearPasscodeToken() throws Exception {
        //Passcode defect fixing - 16.4
        //if (clearToken == null) {
        // start # hotfix
        String tokenStr = null;
        // = _sharedPrefs.getString(PREFS_TOKEN, null);
        if (Globals.isLoggedIn()) {
            if (ssouser) {
                tokenStr = _sharedPrefs_sso.getString(PREFS_TOKEN, null);
            } else {
                tokenStr = _sharedPrefs.getString(PREFS_TOKEN, null);
            }
        } else if (null != _sharedPrefs_sso.getString(PREFS_TOKEN, null) && hideToggle()) {
            tokenStr = _sharedPrefs_sso.getString(PREFS_TOKEN, null);
        } else {
            tokenStr = _sharedPrefs.getString(PREFS_TOKEN, null);
        }

        // end # hotfix
        if (tokenStr == null) {
            tokenStr = TokenUtil.genClientBindingToken();
        }
        clearToken = TokenUtil.parseAndDecryptTokenSupportClear(context,
                tokenStr);
        if (tokenStr != null && tokenStr.equals(clearToken)) { // tokenStr
            // is NOT
            // encrypted,
            // needs to
            // encrypt
            // write token to shared preference "token"
            _prefsEditor.putString(PREFS_TOKEN,
                    TokenUtil.encryptAndJsonifyToken(context, tokenStr));
            _prefsEditor.commit();
            if (ssouser) {
                _prefsEditorSso
                        .putString(PREFS_TOKEN, TokenUtil
                                .encryptAndJsonifyToken(context, tokenStr));
                _prefsEditorSso.commit();
            }
        }
        //}
        System.out.println("clearToken" + clearToken);
        return clearToken;
    }

    /**
     * us20958 - nkaza
     *
     * @return token : Will pick token from bank or card only if sso preference dont have token
     */
    public String getPasscodeToken() {
        if (Globals.isLoggedIn()) {
            if (ssouser) {
                return _sharedPrefs_sso.getString(PREFS_TOKEN, null);
            } else {
                return _sharedPrefs.getString(PREFS_TOKEN, null);
            }
        } else if (null != _sharedPrefs_sso.getString(PREFS_TOKEN, null) && hideToggle()) {
            return _sharedPrefs_sso.getString(PREFS_TOKEN, null);
        } else {
            return _sharedPrefs.getString(PREFS_TOKEN, null);
        }
    }

    /**
     * us20958 - nkaza
     *
     * @return hide toggle flag
     */
    public boolean hideToggle() {
        if (null != _sharedPrefs_sso) {
            return _sharedPrefs_sso.contains(PREFS_CLA_USER_HIDE_TOGGLE) ? _sharedPrefs_sso
                    .getBoolean(PREFS_CLA_USER_HIDE_TOGGLE, false) : false;
        } else {
            return false;
        }
    }

    public void deletePasscodeToken() {
        try {
            _prefsEditor.remove(PREFS_TOKEN);
            _prefsEditor.commit();
            // start - us20958 - nkaza
            // if (ssouser) {
            _prefsEditorSso.putBoolean(PREFS_CLA_USER_HIDE_TOGGLE, false);
            _prefsEditorSso.remove(PREFS_TOKEN);
            _prefsEditorSso.commit();
            // }
            // end - us20958 - nkaza
            /*Start changes for US71615.Disable the Fingerprint status if passcode token is deleted*/
            FingerPrintUtils fingerPrintUtils = new FingerPrintUtils(context);
            if (fingerPrintUtils.getFingerPrintStatus()) {
                fingerPrintUtils.removeFingerprintPasscode();
                fingerPrintUtils.resetProfileSettingFingerPrintStatus();
            }
            /*End changes for US71615*/
        } catch (Exception e) {

        }

    }

    /**
     * us20958 - nkaza
     * delete bank or card token
     */
    private void deleteBankAndCardToken() {
        try {
            if (null != _prefsEditor && _sharedPrefs.contains(PREFS_TOKEN)) {
                _prefsEditor.remove(PREFS_TOKEN);
                _prefsEditor.commit();
            }

        } catch (Exception e) {

        }
    }

    public boolean isForgotPasscode() {
        return _sharedPrefs.getBoolean(PREFS_FORGOT_PASSCODE, false);
    }

    public void setForgotPasscode(boolean status) {
        /*
		 * if(ssouser){ _prefsEditorSso.putBoolean(PREFS_FORGOT_PASSCODE,
		 * status); _prefsEditorSso.commit(); }
		 */
        _prefsEditor.putBoolean(PREFS_FORGOT_PASSCODE, status);
        _prefsEditor.commit();
        if (ssouser) {
            // _prefsEditorSso is getting null after logout.
            if (_prefsEditorSso == null) {

                this._sharedPrefs_sso = DiscoverActivityManager
                        .getActiveActivity()
                        .getApplicationContext()
                        .getSharedPreferences(SSO_APP_SHARED_PREFS,
                                Activity.MODE_PRIVATE);

                this._prefsEditorSso = _sharedPrefs_sso.edit();
            }

        }
    }

    public boolean doesDeviceTokenExist() {
		/*
		 * if(_sharedPrefs_sso!=null && _sharedPrefs_sso.contains(PREFS_TOKEN)){
		 * return (_sharedPrefs_sso.contains(PREFS_TOKEN)); }else{ return
		 * (_sharedPrefs.contains(PREFS_TOKEN)); }
		 */
        if (Globals.isLoggedIn()) {

            return _sharedPrefs.contains(PREFS_TOKEN) || _sharedPrefs_sso.contains(PREFS_TOKEN);

        } else if (null != _sharedPrefs_sso.getString(PREFS_TOKEN, null) && hideToggle()) {
            return _sharedPrefs_sso.contains(PREFS_TOKEN);
        } else {
            return _sharedPrefs.contains(PREFS_TOKEN);
        }
    }

    public boolean canDecryptPasscodeToken() {
        if (!doesDeviceTokenExist())
            return false;
        try {
            return (getClearPasscodeToken() != null);
        } catch (Exception e) {
            return false;
        }
    }

    // hlin0 updated on 20140122, use encryption before storage, also throw back
    // exception
    public void createPasscodeToken(String token) throws Exception {
        if (ssouser) {
            if (_sharedPrefs_sso.contains(PREFS_TOKEN)) {
                // TODO can't write token when one already exists
                return;
            }
        } else {
            if (_sharedPrefs.contains(PREFS_TOKEN)) {
                // TODO can't write token when one already exists
                return;
            }
        }

        if (ssouser) {
            deletePasscodeToken();
            _prefsEditorSso.putString(PREFS_TOKEN, TokenUtil.encryptAndJsonifyToken(context, token));
            _prefsEditorSso.commit();
            _prefsEditorSso.putBoolean(PREFS_CLA_USER_HIDE_TOGGLE, true);
            _prefsEditorSso.commit();

        } else {
            deletePasscodeToken();
            // write token to shared preference "token"
            _prefsEditor.putString(PREFS_TOKEN, TokenUtil.encryptAndJsonifyToken(context, token));
            _prefsEditor.commit();
            _prefsEditorSso.putBoolean(PREFS_CLA_USER_HIDE_TOGGLE, false);
            _prefsEditorSso.commit();
        }
    }

	/*
	 * public static String genClientBindingToken() { SecureRandom scrRndm = new
	 * SecureRandom(); byte[] random = new byte[64];// 64 byte per INFO SEC
	 * scrRndm.nextBytes(random); return new
	 * String(Base64.encodeToString(random, Base64.NO_WRAP)); }
	 */

    public void storeFirstName(String fname) {
        _prefsEditor.putString(PREFS_USERS_FIRST_NAME, fname);
        _prefsEditor.commit();

    }

    public void deleteFirstName() {
        _prefsEditor.remove(PREFS_USERS_FIRST_NAME);
        _prefsEditor.commit();

    }

    /**
     * nkaza
     * On merge take token from bank/card preferences and store to sso preference. And remove
     * duplicate token .
     */
    public void mergePasscodeToken() {
        if (null != _sharedPrefs && _sharedPrefs.contains(PREFS_TOKEN)) {
            try {
                _prefsEditorSso.putString(PREFS_TOKEN,
                        TokenUtil.encryptAndJsonifyToken(context, _sharedPrefs_sso.getString(PREFS_TOKEN, "")));
                _prefsEditorSso.commit();
            } catch (Exception e) {

            }
            deleteBankAndCardToken();
        }

    }

    public boolean isPasscodeToken() {
        if (_sharedPrefs_sso != null && _sharedPrefs_sso.contains(PREFS_TOKEN)) {
            return (_sharedPrefs_sso.contains(PREFS_TOKEN));
        } else {
            return (_sharedPrefs.contains(PREFS_TOKEN));
        }
    }

    public String getWelcomeMessage() {
        String firstName = getFirstName();
        if (firstName == null || firstName.trim().equals("")
                || firstName.trim().equalsIgnoreCase("null")) {
            return "";
        }
        StringBuffer sb = new StringBuffer("Good ");
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 12)
            sb.append("morning, ").append(getFirstName());
        else if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 18)
            sb.append("afternoon, ").append(getFirstName());
        else
            sb.append("evening, ").append(getFirstName());
        return sb.toString();
    }

    public void storePasscodeUserID(String userId) {

        final String encryptedUser;

        if (!userId.isEmpty()) {
            try {
                encryptedUser = SecurityUtil.encrypt(userId);
            } catch (final Exception e) {
                // Failed to encrypt user. Will not store on device.
                return;
            }
        } else { // No need to encrypt an empty String.
            encryptedUser = userId;
        }

        _prefsEditor.putString(PREFS_PASSCODE_USER_ID, encryptedUser);
        _prefsEditor.commit();
    }

    public String getPasscodeUserID() {
        String user = StringUtility.EMPTY;
        String encryptedUser = _sharedPrefs.getString(PREFS_PASSCODE_USER_ID,
                "");
        if (!encryptedUser.isEmpty()) {
            try {
                user = SecurityUtil.decrypt(encryptedUser);
            } catch (final Exception e) { // Failed to decrypt user.
                return StringUtility.EMPTY;
            }
        }
        return user;
    }

    // US37431 changes start

    /**
     * Get status of deeplink for Passcode Setup page.
     */
    public boolean isPasscodeSetupDeepLink() {
        return _sharedPrefs.getBoolean(PREFS_SETUP_PASSCODE_DEEPLINK, false);
    }

    /**
     * Set deeplink status for Passcode Setup page.
     */
    public void setPasscodeSetupDeepLink(boolean status) {
        _prefsEditor.putBoolean(PREFS_SETUP_PASSCODE_DEEPLINK, status);
        _prefsEditor.commit();
        if (ssouser) {
            // _prefsEditorSso is getting null after logout.
            if (_prefsEditorSso == null) {

                this._sharedPrefs_sso = DiscoverActivityManager
                        .getActiveActivity()
                        .getApplicationContext()
                        .getSharedPreferences(SSO_APP_SHARED_PREFS,
                                Activity.MODE_PRIVATE);

                this._prefsEditorSso = _sharedPrefs_sso.edit();
            }
        }
    }
    // US37431 changes end

    // US37431 changes end

    public void storeSSOPascode(Boolean hideToggle, String token) {
        _prefsEditorSso.putString(PREFS_TOKEN, token);
        _prefsEditorSso.commit();
        _prefsEditorSso.putBoolean(PREFS_CLA_USER_HIDE_TOGGLE, hideToggle);
        _prefsEditorSso.commit();
    }

    public void storePascode(String token, Boolean forgotPasscode, String fUserName, String fUuerId) {
        _prefsEditor.putString(PREFS_TOKEN, token);
        _prefsEditor.commit();
        _prefsEditor.putString(PREFS_USERS_FIRST_NAME, fUserName);
        _prefsEditor.commit();
        _prefsEditor.putString(PREFS_PASSCODE_USER_ID, fUuerId);
        _prefsEditor.commit();
        _prefsEditor.putBoolean(PREFS_FORGOT_PASSCODE, forgotPasscode);
        _prefsEditor.commit();
    }

    /**
     * App data was lost due to encryption method is changed in 7.9 app version.
     * To save app cache after version upgrade we have written below functions to get old value
     * encrypted value and decrypt with old key and encrypt with new key so that app data is
     * preserved after app upgrade from 7.8 to 7.9.
     * below mentioned functions can be removed once all the customers are updated to 7.9 version.
     * 1. getPasscodeTokenForOldType
     **/
    public String getPasscodeTokenForOldType() throws Exception {
        //Passcode defect fixing - 16.4
        //if (clearToken == null) {
        // start # hotfix
        String tokenStr = null;
        // = _sharedPrefs.getString(PREFS_TOKEN, null);
        if (Globals.isLoggedIn()) {
            if (ssouser) {
                tokenStr = _sharedPrefs_sso.getString(PREFS_TOKEN, null);
            } else {
                tokenStr = _sharedPrefs.getString(PREFS_TOKEN, null);
            }
        } else if (null != _sharedPrefs_sso.getString(PREFS_TOKEN, null) && hideToggle()) {
            tokenStr = _sharedPrefs_sso.getString(PREFS_TOKEN, null);
        } else {
            tokenStr = _sharedPrefs.getString(PREFS_TOKEN, null);
        }

        // end # hotfix
        if (tokenStr == null) {
            return null;
        }
        clearToken = TokenUtil.parseAndDecryptTokenSupportClearFromLogin(context,
                tokenStr);
        if (tokenStr != null && tokenStr.equals(clearToken)) { // tokenStr
            // is NOT
            // encrypted,
            // needs to
            // encrypt
            // write token to shared preference "token"
            _prefsEditor.putString(PREFS_TOKEN,
                    TokenUtil.encryptAndJsonifyToken(context, tokenStr));
            _prefsEditor.commit();
            if (ssouser) {
                _prefsEditorSso
                        .putString(PREFS_TOKEN, TokenUtil
                                .encryptAndJsonifyToken(context, tokenStr));
                _prefsEditorSso.commit();
            }
        }
        //}
        return clearToken;
    }
}