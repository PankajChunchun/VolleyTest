package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class IraAccount implements Serializable {

    private static final long serialVersionUID = -6605734956241336825L;

    @SerializedName("accessType")
    private String accessType;

    @SerializedName("fraudStatus")
    private String fraudStatus;

    @SerializedName("currentBalance")
    private String currentBalance;

    @SerializedName("interestYearToDate")
    private String interestYearToDate;

    @SerializedName("lastFourAcctNbr")
    private String lastFourAcctNbr;

    @SerializedName("interestRate")
    private String interestRate;

    @SerializedName("apy")
    private String apy;

    @SerializedName("availableBalance")
    private String availableBalance;

    /** start newly added field for US48093 changes */

    @SerializedName("isVerified")
    private Boolean isVerified;
    /** end newly added field for US48093 changes */

    @SerializedName("FreezeReasonCodeList")
    private List<String> FreezeReasonCodeList = new ArrayList<String>();

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    public String getLastFourAcctNbr() {
        return lastFourAcctNbr;
    }

    public void setLastFourAcctNbr(String lastFourAcctNbr) {
        this.lastFourAcctNbr = lastFourAcctNbr;
    }

    /**
     * @return The accessType
     */
    public String getAccessType() {
        return accessType;
    }

    /**
     * @param accessType The accessType
     */
    public void setAccessType(String accessType) {
        this.accessType = accessType;
    }

    /**
     * @return The fraudStatus
     */
    public String getFraudStatus() {
        return fraudStatus;
    }

    /**
     * @param fraudStatus The fraudStatus
     */
    public void setFraudStatus(String fraudStatus) {
        this.fraudStatus = fraudStatus;
    }

    /**
     * @return The currentBalance
     */
    public String getCurrentBalance() {
        return currentBalance;
    }

    /**
     * @param currentBalance The currentBalance
     */
    public void setCurrentBalance(String currentBalance) {
        this.currentBalance = currentBalance;
    }

    /**
     * @return The interestYearToDate
     */
    public String getInterestYearToDate() {
        return interestYearToDate;
    }

    /**
     * @param interestYearToDate The interestYearToDate
     */
    public void setInterestYearToDate(String interestYearToDate) {
        this.interestYearToDate = interestYearToDate;
    }

    /**
     * @return The FreezeReasonCodeList
     */
    public List<String> getFreezeReasonCodeList() {
        return FreezeReasonCodeList;
    }

    /**
     * @param FreezeReasonCodeList The FreezeReasonCodeList
     */
    public void setFreezeReasonCodeList(List<String> FreezeReasonCodeList) {
        this.FreezeReasonCodeList = FreezeReasonCodeList;
    }

    public String getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(String interestRate) {
        this.interestRate = interestRate;
    }

    public String getApy() {
        return apy;
    }

    public void setApy(String apy) {
        this.apy = apy;
    }

    public String getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(String availableBalance) {
        this.availableBalance = availableBalance;
    }
}
