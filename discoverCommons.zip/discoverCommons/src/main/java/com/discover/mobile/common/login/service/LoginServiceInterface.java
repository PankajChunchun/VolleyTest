package com.discover.mobile.common.login.service;

import com.google.gson.JsonObject;

import com.discover.mobile.common.highlightedfeatures.beans.HighlightedFeaturesData;
import com.discover.mobile.common.login.beans.PreAuthbean;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Headers;
import retrofit.http.Path;

/**
 * Class is used to define service which will be used in pre log in service call.
 * 1. PreAuth
 * 2. Info JSON download
 * 3. Error JSON download
 * 4.
 */
public interface LoginServiceInterface {

    @Headers("Content-Type: application/json")
    @GET("/json/android_handset/error.json")
    public void getErrorListJSON(Callback<JsonObject> jsonObjectCallBack);

    @Headers("Content-Type: application/json")
    @GET("/json/android/infomessage.json")
    public void getInfoMessageJson(Callback<JsonObject> infoMessageCallBack);

    @Headers("Content-Type: application/json")
    @GET("/cardsvcs/acs/session/v2/preauthcheck")
    public void startPreAuthCheck(Callback<PreAuthbean> preAuthbeanCallback);

    // target file is "/json/features/HF_Android_710.json"
    @Headers("Content-Type: application/json")
    @GET("/json/features/{fileName}")
    void getHighlightedFeatures(@Path("fileName") String fileName, Callback<HighlightedFeaturesData> getJsonHelpData);

    // backlog US57795 fix start adeshm2
    @Headers("Content-Type: application/json")
    @GET("/json/android/randomization/randomvalues.json")
    public void getRandomizationJSON(Callback<JsonObject> jsonObjectCallBack);
    // backlog US57795 fix end adeshm2
}
