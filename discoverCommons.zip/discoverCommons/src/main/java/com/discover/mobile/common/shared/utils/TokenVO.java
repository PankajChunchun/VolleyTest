package com.discover.mobile.common.shared.utils;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class TokenVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @SerializedName("value")
    private String value;

    @SerializedName("formatVer")
    private String formatVer;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getFormatVer() {
        return formatVer;
    }

    public void setFormatVer(String formatVer) {
        this.formatVer = formatVer;
    }

}
