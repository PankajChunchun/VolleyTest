package com.discover.mobile.common.applynow.ui;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.applynow.adapter.ApplyNowAdapter;
import com.discover.mobile.common.login.LoginActivity;
import com.discover.mobile.common.ui.widgets.CirclePageIndicator;

/**
 * Created by 467649 on 9/13/2017.
 */

public class ApplyNowDioalog extends DialogFragment {

    private static final String SCALE_X = "scaleX";
    private static final String SCALE_Y = "scaleY";
    private static final int ANIM_DURATION = 400;
    private CirclePageIndicator mDynamicMessagePageIndicator;
    private int mPagerPosition;
    private View view;
    private ViewPager vp;
    private Context mContext;
    private boolean isCloseButtonClicked;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Override
    public void onDestroyView() {
        if (getDialog() != null && getRetainInstance()) {
            getDialog().setDismissMessage(null);
            getDialog().setOnDismissListener(null);
        }
        super.onDestroyView();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.apply_now_dialog_layout, container, false);
        isCloseButtonClicked = false;
        initUi();
        return view;
    }

    private void initUi() {
        mDynamicMessagePageIndicator = (CirclePageIndicator) view.findViewById(R.id.dynamic_message_indicator);
        mDynamicMessagePageIndicator.setFillColor(getResources().getColor(R.color.apply_now_indicator_selected_color));
        mDynamicMessagePageIndicator.setPageColor(getResources().getColor(R.color.apply_now_indicator_default_color));
        ApplyNowAdapter applyNowAdapter = new ApplyNowAdapter(getChildFragmentManager());
        applyNowAdapter.setCloseButtonListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateOnExit();
            }
        });
        vp = (ViewPager) view.findViewById(R.id.apply_now_pager);
        vp.setAdapter(applyNowAdapter);
        mDynamicMessagePageIndicator.setViewPager(vp);
        mDynamicMessagePageIndicator.setCurrentItem(mPagerPosition);
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
//            TrackingHelper.trackCardPage(AnalyticsPage.APPLY_NOW_PAGE_NAMES[0], null);
        }
        setCancelable(false);

        mDynamicMessagePageIndicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
            }

            @Override
            public void onPageSelected(int i) {
                mDynamicMessagePageIndicator.setId(i);
                mPagerPosition = i;
                TrackingHelper.trackCardPage(AnalyticsPage.APPLY_NOW_PAGE_NAMES[mPagerPosition], null);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        TrackingHelper.trackCardPage(AnalyticsPage.APPLY_NOW_PAGE_NAMES[mPagerPosition], null);
        Window window = getDialog().getWindow();
        if(window == null) return;
        WindowManager.LayoutParams params = window.getAttributes();
        params.height = (int) getResources().getDimension(R.dimen.apply_now_dialog_hight);
        window.setAttributes(params);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new Dialog(getActivity(), getTheme()){
            @Override
            public void onBackPressed() {
                animateOnExit();
            }
        };
    }

    @Override
    public void onStart() {
        super.onStart();
        ((LoginActivity)mContext).isShowApplyNowBanner = false;
        Dialog dialog = getDialog();
        if (dialog != null) {
            final View decorView = dialog.getWindow().getDecorView();

            ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(decorView,
                    PropertyValuesHolder.ofFloat(SCALE_X, 0.0f, 1.0f),
                    PropertyValuesHolder.ofFloat(SCALE_Y, 0.0f, 1.0f));
            scaleDown.setInterpolator(new AccelerateInterpolator());
            scaleDown.setDuration(ANIM_DURATION);

            scaleDown.start();
        }
    }

    private void animateOnExit() {
        if(!isCloseButtonClicked){
            isCloseButtonClicked = true;

            Dialog dialog = getDialog();
            if (dialog != null) {
                final View decorView = dialog.getWindow().getDecorView();

                ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(decorView,
                        PropertyValuesHolder.ofFloat(SCALE_X, 1.0f, 0.0f),
                        PropertyValuesHolder.ofFloat(SCALE_Y, 1.0f, 0.0f));
                scaleDown.setDuration(ANIM_DURATION);

                // added handler to solve device specific issue of flickering.
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        dismiss();
                        ((LoginActivity)mContext).isShowApplyNowBanner = true;
                        ((LoginActivity)mContext).showApplyNowBanner();
                    }
                }, ANIM_DURATION);

                scaleDown.start();

            }
        }

    }
}
