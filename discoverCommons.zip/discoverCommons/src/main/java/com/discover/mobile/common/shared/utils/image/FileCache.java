package com.discover.mobile.common.shared.utils.image;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.File;

public class FileCache {

    private File cacheDir;
    private File otherImagesDir;
    private File dealsImagesDir;
    private boolean isRelatedToDeals = false;
    public static SharedPreferences preferencesFileCache;
    private final String FILE_NAME = "DEALS_CACHE";
    private static String DEALS_CACHE_TIME_STAMP = "DealsTimeStemp";
    public static final String DEALS_CLEAN_UP_DAYS = "deals_cleanup_days";
    public static final String MAX_TOTAL_DAYS_TO_STORE_DEALS_IMAGE = "10";
    public FileCache(Context context) {
        preferencesFileCache = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        cacheDir = context.getCacheDir();
        if (!cacheDir.exists())
            cacheDir.mkdirs();
        otherImagesDir = new File(cacheDir.getAbsolutePath(), "otherImagesDir");
        if (!otherImagesDir.exists())
            otherImagesDir.mkdirs();
    }

    public FileCache(Context context, String dirName) {
        this(context);
        File dir = new File(otherImagesDir.getAbsolutePath(), dirName);
        if (!dir.exists())
            dir.mkdirs();
    }

    /*
    If FileCache is used for MOP related stuff, dealsImagesDir is created to store Deals images.
    Also we will store timestamp when deals folder created(to delete it later).
     */
    public void createDealsCacheFolder(boolean relatedToDeals) {
        isRelatedToDeals = relatedToDeals;
        if (isRelatedToDeals) {
            dealsImagesDir = new File(cacheDir.getAbsolutePath(), "dealsImagesDir");
            if (!dealsImagesDir.exists()) {
                dealsImagesDir.mkdirs();
                preferencesFileCache.edit().putLong(DEALS_CACHE_TIME_STAMP, System.currentTimeMillis()).commit();
            }
        }
    }

    public File getFile(String url) {
        File f = null;
        if (isRelatedToDeals) {
            String filename = String.valueOf(url.hashCode());
            f = new File(dealsImagesDir, filename);

        } else {
            String filename = String.valueOf(url.hashCode());
            f = new File(otherImagesDir, filename);
        }
        return f;
    }

    public File getCacheDir() {
        if (isRelatedToDeals) {
            return dealsImagesDir;
        } else {
            return otherImagesDir;
        }
    }


    public void clear() {
        try {
            if (cacheDir != null && cacheDir.isDirectory())
                deleteDir(cacheDir);
        } catch (Exception e) {
            Log.e("clear", "Exception");
        }
    }

    public void clearCachePartial() {
        try {
            if (cacheDir != null && cacheDir.isDirectory() &&
                    otherImagesDir != null && otherImagesDir.isDirectory())
                deleteDir(otherImagesDir);
        } catch (Exception e) {
            Log.e("clearCachePartial", "Exception");
        }
    }

    public void flushDirectory(String dirName) {
        if (!cacheDir.exists())
            return;
        File dir = new File(cacheDir.getAbsolutePath(), dirName);

        File[] files = dir.listFiles();
        if (files == null)
            return;
        for (File f : files)
            f.delete();
        dir.delete();

    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();

            for (int i = 0; i < children.length; i++) {

                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        return dir.delete();
    }
    /*
    The timestamp value when the Deals cache folder created.
     */
    public static long getTimeStampValue() {
        long storeTimeStampValue = -1;
        if (null != preferencesFileCache) {
            storeTimeStampValue = preferencesFileCache.getLong(DEALS_CACHE_TIME_STAMP, System.currentTimeMillis());
            return storeTimeStampValue;
        } else
            return storeTimeStampValue;
    }
}