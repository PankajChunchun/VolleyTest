package com.discover.mobile.common.fico.interfaces;

public interface GraphClickListner {
    void onItemClicked(int iIndex);

}
