package com.discover.mobile.common.facade;

import android.content.Context;

public interface OOBFacade {

    public void submitOOBRequest(Context context);

    public void submitOOBRequest(Context context, String url);

}
