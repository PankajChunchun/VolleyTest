package com.discover.mobile.common.appupdate.ui;

import com.discover.mobile.common.R;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.error.ErrorHandlerUi;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.shared.DiscoverActivityManager;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;


/**
 * Activity which shows current status of application update. If application
 * needs to update, user can update application from here.
 *
 * This activity is designed for pre-login. While calling this activity you must
 * give a boolean extra {@link UpdateAppFragment#KEY_UPDATE_AVAILABLE},
 * <code>true</code> will say that new version of application is available and
 * <code>false</code> if update is not available. Default value for
 * {@link UpdateAppFragment#KEY_UPDATE_AVAILABLE} is <code>false</code>.
 *
 * @author pkuma13
 */
public class UpdateAppActivity extends ActionBarBaseActivity implements ErrorHandlerUi {

    private static final String TAG = UpdateAppActivity.class.getSimpleName();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if(com.discover.mobile.common.Utils.checkPermissionTampering(this)){
            return;
        }

        //  setBehindContentView(getBehindContentView());
        setContentView(R.layout.card_version_fragment);

        // disableMenu();
        showBackX();

        DiscoverActivityManager.setActiveActivity(this);

        showFragment();
    }

    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }

    @Override
    public void onResume() {
        super.onResume();
      /*  disableMenu();*/
        showBackX();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


    public void showBackX() {
        setActionbarBackNavigation(new Runnable() {
            @Override
            public void run() {
                onBackPressed();
            }
        });
    }

    private void showFragment() {
//        Utils.log(TAG, "showFragment.....");
        // Start common fragment to show application update available or not.
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager
                .beginTransaction();
        UpdateAppFragment appFragment = new UpdateAppFragment();
        // Pass intent's extras to fragment to decide which UI needs to be
        // shown.
        appFragment.setArguments(getIntent().getExtras());
        fragmentTransaction.add(R.id.navigation_content, appFragment,
                "updateAppFragment");
        fragmentTransaction.commit();
    }

    @Override
    public TextView getErrorLabel() {
        return null;
    }

    @Override
    public List<EditText> getInputFields() {
        return null;
    }

    @Override
    public void showCustomAlert(AlertDialog alert) {

    }

    @Override
    public void showOneButtonAlert(int title, int content, int buttonText) {

    }

    @Override
    public void showDynamicOneButtonAlert(int title, String content, int buttonText) {

    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public int getLastError() {
        return 0;
    }

    @Override
    public void setLastError(int errorCode) {

    }

    @Override
    public ErrorHandler getErrorHandler() {
        return null;
    }
}