package com.discover.mobile.common.nav.listener;

public interface IFragmentOnBackPressed {

    boolean onBackPressed();
}
