package com.discover.mobile.common.ewallet;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tapandpay.TapAndPay;

public class AndroidPayConnectivity implements
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {
    private static final String TAG = AndroidPayConnectivity.class.getName();
    public static GoogleApiClient apiClient;
    private static AndroidPayConnectivity myObject;
    private static boolean isFirstime = false;
    private final long CONNECTION_TIME_OUT_MS = 1000;
    Context context = null;
    String response = null;
    String payload = null;
    String path = null;
    int notificationId = 0;
    boolean isWear = false;
    boolean isTogglingCardOrBank = false;

    public AndroidPayConnectivity(Context context) {
        this.context = context;
    }

    public static AndroidPayConnectivity getInstance(Context context) {
        if (myObject == null) {
            myObject = new AndroidPayConnectivity(context);
        }
        return myObject;
    }


    @Override
    public void onConnectionFailed(ConnectionResult arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onConnected(Bundle arg0) {
        // TODO Auto-generated method stub
        Log.d("AndroidPayConnectivity", "connected");
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        // TODO Auto-generated method stub

    }

    public void getConnect(Context context) {

            apiClient = new GoogleApiClient.Builder(context)
                    .addApi(TapAndPay.TAP_AND_PAY_API).addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this).build();
            apiClient.connect();

    }
}
