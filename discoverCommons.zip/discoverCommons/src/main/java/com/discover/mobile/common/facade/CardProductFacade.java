package com.discover.mobile.common.facade;

import android.app.Activity;
import android.content.Context;

//import com.actionbarsherlock.app.SherlockFragmentActivity;

/**
 * Facade to show product page.
 *
 * @author pkuma13
 */
public interface CardProductFacade {

    /**
     * Show application leaving modal.
     *
     * @param callingActivity
     *            - Calling activity instance.
     * @param targetUrl
     *            - Url which needs to show from leaving app modal.
     */

    /*1 . Removed as per US60514 */
    /*public void showLeavingAppModal(AppCompatActivity callingActivity, String targetUrl);*/

    /**
     * Show products page.
     */
    public void showProductsPage(Context callingActivity, boolean isCardSelected);

    /**
     * Check if activity is instance of ProductActivity.
     */
    public boolean isInstanceOfProductActivity(Activity currentActivity);

    /*2. Removed as per US60514 */
   /* public void getProductsContent(Context callingActivity, boolean isCardSelected,  final NetworkRequestListener listener);*/

    /*3. Removed as per US60514 */
    /*public void showLeavingAppModal(DrawerBaseActivity callingActivity, String targetUrl);*/


}