package com.discover.mobile.common.portalpage.beans;

import com.google.gson.annotations.SerializedName;

import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DepositAccount implements Serializable, PortalBoxInterface {
    private static final long serialVersionUID = 3205359882844691024L;
    private final static String ACC_DEPOSIT = "ACC_DEPOSIT | ";

    @SerializedName("index")
    private Integer index;

    @SerializedName("cif")
    private String cif;

    @SerializedName("lastFourAcctNbr")
    private String lastFourAcctNbr;

    @SerializedName("acctName")
    private String acctName;

    @SerializedName("acctNickName")
    private String acctNickName;

    @SerializedName("acctType")
    private String acctType;

    @SerializedName("acctTypeDesc")
    private String acctTypeDesc;

    @SerializedName("acctStatus")
    private String acctStatus;

    @SerializedName("accessType")
    private String accessType;

    @SerializedName("currentBalance")
    private String currentBalance;

    @SerializedName("availableBalance")
    private String availableBalance;

    @SerializedName("interestRate")
    private String interestRate;

    @SerializedName("apy")
    private String apy;

    @SerializedName("accountTerm")
    private String accountTerm;

    @SerializedName("interestYearToDate")
    private String interestYearToDate;

    @SerializedName("fraudStatus")
    private String fraudStatus;

    @SerializedName("cashbackBonusBal")
    private String cashbackBonusBal;

    @SerializedName("checkingAccountType")
    private String checkingAccountType;

    /** start newly added field for US48093 changes */

    @SerializedName("isVerified")
    private Boolean isVerified;
    /** end newly added field for US48093 changes */

    @SerializedName("freezeReasonCodeList")
    private List<String> freezeReasonCodeList = new ArrayList<String>();

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    /**
     * @return The index
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * @param index The index
     */
    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * @return The cif
     */
    public String getCif() {
        return cif;
    }

    /**
     * @param cif The cif
     */
    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getLastFourAcctNbr() {
        return lastFourAcctNbr;
    }

    public void setLastFourAcctNbr(String lastFourAcctNbr) {
        this.lastFourAcctNbr = lastFourAcctNbr;
    }

    /**
     * @return The acctName
     */
    public String getAcctName() {
        return acctName;
    }

    /**
     * @param acctName The acctName
     */
    public void setAcctName(String acctName) {
        this.acctName = acctName;
    }

    /**
     * @return The acctNickName
     */
    public String getAcctNickName() {
        return acctNickName;
    }

    /**
     * @param acctNickName The acctNickName
     */
    public void setAcctNickName(String acctNickName) {
        this.acctNickName = acctNickName;
    }

    /**
     * @return The acctType
     */
    public String getAcctType() {
        return acctType;
    }

    /**
     * @param acctType The acctType
     */
    public void setAcctType(String acctType) {
        this.acctType = acctType;
    }

    /**
     * @return The acctTypeDesc
     */
    public String getAcctTypeDesc() {
        return acctTypeDesc;
    }

    /**
     * @param acctTypeDesc The acctTypeDesc
     */
    public void setAcctTypeDesc(String acctTypeDesc) {
        this.acctTypeDesc = acctTypeDesc;
    }

    /**
     * @return The acctStatus
     */
    public String getAcctStatus() {
        return acctStatus;
    }

    /**
     * @param acctStatus The acctStatus
     */
    public void setAcctStatus(String acctStatus) {
        this.acctStatus = acctStatus;
    }

    /**
     * @return The accessType
     */
    public String getAccessType() {
        return accessType;
    }

    /**
     * @param accessType The accessType
     */
    public void setAccessType(String accessType) {
        this.accessType = accessType;
    }

    /**
     * @return The currentBalance
     */
    public String getCurrentBalance() {
        return currentBalance;
    }

    /**
     * @param currentBalance The currentBalance
     */
    public void setCurrentBalance(String currentBalance) {
        this.currentBalance = currentBalance;
    }

    /**
     * @return The availableBalance
     */
    public String getAvailableBalance() {
        return availableBalance;
    }

    /**
     * @param availableBalance The availableBalance
     */
    public void setAvailableBalance(String availableBalance) {
        this.availableBalance = availableBalance;
    }

    /**
     * @return The interestRate
     */
    public String getInterestRate() {
        return interestRate;
    }

    /**
     * @param interestRate The interestRate
     */
    public void setInterestRate(String interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * @return The apy
     */
    public String getApy() {
        return apy;
    }

    /**
     * @param apy The apy
     */
    public void setApy(String apy) {
        this.apy = apy;
    }

    /**
     * @return The accountTerm
     */
    public String getAccountTerm() {
        return accountTerm;
    }

    /**
     * @param accountTerm The accountTerm
     */
    public void setAccountTerm(String accountTerm) {
        this.accountTerm = accountTerm;
    }

    /**
     * @return The interestYearToDate
     */
    public String getInterestYearToDate() {
        return interestYearToDate;
    }

    /**
     * @param interestYearToDate The interestYearToDate
     */
    public void setInterestYearToDate(String interestYearToDate) {
        this.interestYearToDate = interestYearToDate;
    }

    /**
     * @return The fraudStatus
     */
    public String getFraudStatus() {
        return fraudStatus;
    }

    /**
     * @param fraudStatus The fraudStatus
     */
    public void setFraudStatus(String fraudStatus) {
        this.fraudStatus = fraudStatus;
    }

    /**
     * @return The cashbackBonusBal
     */
    public String getCashbackBonusBal() {
        return cashbackBonusBal;
    }

    /**
     * @param cashbackBonusBal The cashbackBonusBal
     */
    public void setCashbackBonusBal(String cashbackBonusBal) {
        this.cashbackBonusBal = cashbackBonusBal;
    }

    /**
     * @return The checkingAccountType
     */
    public String getCheckingAccountType() {
        return checkingAccountType;
    }

    /**
     * @param checkingAccountType The checkingAccountType
     */
    public void setCheckingAccountType(String checkingAccountType) {
        this.checkingAccountType = checkingAccountType;
    }

    /**
     * @return The FreezeReasonCodeList
     */
    public List<String> getFreezeReasonCodeList() {
        return freezeReasonCodeList;
    }

    /**
     * @param FreezeReasonCodeList The FreezeReasonCodeList
     */
    public void setFreezeReasonCodeList(List<String> FreezeReasonCodeList) {
        this.freezeReasonCodeList = FreezeReasonCodeList;
    }

    @Override
    public String getSortId() {
        return this.index != -1 ? this.ACC_DEPOSIT.concat(String.valueOf(this.index)) : null;
    }
}
