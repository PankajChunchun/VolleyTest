package com.discover.mobile.common.shared.utils;

import com.discover.mobile.common.DiscoverApplication;
import com.discover.mobile.common.R;
import com.discover.mobile.common.Utils;
import com.discover.mobile.common.shared.Globals;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import static com.discover.mobile.common.Utils.log;

/**
 * Helper to perform migration operations.
 * Converts all preference values stored at different keys that are the 128 bit AES encrypted values to 256 bit AES encrypted values.
 * As well takes care tose keys as well those are using 128 bit AES
 * by converting these keys to 256 bit AES and stores the same value at newly generated key.
 *
 * Created by 494005 on 7/28/2017.
 */
public class CryptoMigrationHelper {

    /**
     * Writes value to given shredPreference for given key.
     * @param sharedPreferences
     * @param key
     * @param value
     * @return
     */
    private static boolean write(SharedPreferences sharedPreferences, String key, String value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        log(SecurityUtil.class.getSimpleName(), "256 : " + value);
        editor.putString(key, value);
        return editor.commit();
    }

    /**
     * Reads the preference for given key.
     * @param sharedPreferences
     * @param key
     * @return
     */
    private static String read(SharedPreferences sharedPreferences, String key){
        String enc128 = sharedPreferences.getString(key, StringUtility.EMPTY);
        log(SecurityUtil.class.getSimpleName(), "128 : " + enc128);
        return enc128;
    }

    /**
     * Decrypts the plain text to 128 bit AES encrypted value based on the useDyna value.
     * @param enc128
     * @param useDyna if true then with dynamic key else seeded key
     * @return
     * @throws Exception
     */
    private static String decryptWith128(String enc128, boolean useDyna) throws Exception{
        Context mContext = DiscoverApplication.getGlobalContext();
        String plain = null;
        if (!enc128.equalsIgnoreCase(StringUtility.EMPTY)) {
            if (useDyna) {
                plain = LagacyEncryptionUtil.decryptTokenWithDyna(mContext, enc128);
            } else {
                plain = LagacyEncryptionUtil.decrypt(enc128);
            }
        }
        return plain;
    }

    /**
     * Writes to shared prefrence at given preference key after encrypting with 256 bit AES;
     * @param sharedPreferences
     * @param key
     * @param plain
     * @return
     * @throws Exception
     */
    private static boolean writeAfterEncryptingWith256(SharedPreferences sharedPreferences, String key, String plain) throws Exception{
        String enc256 = SecurityUtil.encrypt(plain);
        log(SecurityUtil.class.getSimpleName(), "256 : " + enc256);
        return write(sharedPreferences, key, enc256);
    }

    /**
     * Reads the shared preference value at given key; decrypts it based on useDyna value; returns plain string.
     * @param sharedPreferences
     * @param key
     * @param useDyna if true then with dynamic key else seeded key
     * @return
     * @throws Exception
     */
    private static String readAndDecryptWith128(SharedPreferences sharedPreferences, String key, boolean useDyna) throws Exception{
        String plain = null;
        String enc128 = read(sharedPreferences, key);
        log(SecurityUtil.class.getSimpleName(), "128 : " + enc128);
        plain = decryptWith128(enc128, useDyna);
        log(SecurityUtil.class.getSimpleName(), "Plain : " + plain);
        return plain;
    }

    /**
     * Reads the value from shared preference at key; decrypts with 128 bit AES based on useDyna value;
     * then writes back at same shared preference at same key; using 256 bit AES.
     * @param sharedPreferences
     * @param key
     * @param useDyna if true then with dynamic key else seeded key
     * @return
     */
    private static boolean convert(SharedPreferences sharedPreferences, String key, boolean useDyna) {
        log(SecurityUtil.class.getSimpleName(),"convert: STARTS");
        boolean rValue = false;
        String plain = null;
        if (sharedPreferences != null) {
            try {
                plain = readAndDecryptWith128(sharedPreferences, key, useDyna);
                log(SecurityUtil.class.getSimpleName(), "Plain : " + plain);
            } catch (Exception ex) {
                log(SecurityUtil.class.getSimpleName(),"Read Failed");
                ex.printStackTrace();
            }
            try {
                if (!TextUtils.isEmpty(plain)) {
                    rValue = writeAfterEncryptingWith256(sharedPreferences, key, plain);
                    log(SecurityUtil.class.getSimpleName(), "isSuccessful : " + rValue);
                }
            } catch (Exception ex) {
                log(SecurityUtil.class.getSimpleName(),"Write Failed");
                ex.printStackTrace();
            }
        }
        log(SecurityUtil.class.getSimpleName(),"convert: ENDS");
        return rValue;
    }

    /**
     * Generates the 128 bit AES key for given key then Reads the value from shared preference at generated key;
     * then generates the 256 bit AES key for given key then writes read value back at newly generated key;
     *
     * @param sharedPreferences
     * @param key
     * @return
     */
    private static boolean convertKey(SharedPreferences sharedPreferences, String key) {
        log(SecurityUtil.class.getSimpleName(),"convertKey: STARTS");
        boolean value = sharedPreferences.getBoolean(Globals.getUserLevelKey(key, false), false);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(Globals.getUserLevelKey(key, true), value);
        log(SecurityUtil.class.getSimpleName(),"convertKey: ENDS");
        return editor.commit();
    }

    /**
     * Reads the token value from shared preference at key; decrypts with 128 bit AES based on useDyna value;
     * then writes back at same shared preference at same key; using 256 bit AES.
     * @param sharedPreferences
     * @param key
     * @param useDyna if true then with dynamic key else seeded key
     * @return
     */
    private static boolean convertToken(SharedPreferences sharedPreferences, String key, boolean useDyna){
        log(SecurityUtil.class.getSimpleName(),"convertToken: STARTS");
        boolean rValue = false;
        String plain = null;
        try {
            String enc128 = read(sharedPreferences, key);
            TokenVO tokenVO = (TokenVO) Utils.getObjectFromJSONString(enc128, TokenVO.class);
            if(tokenVO != null && tokenVO.getValue()!=null) {
                plain = decryptWith128(tokenVO.getValue(), useDyna);
            }
        }catch (Exception ex){
            log(SecurityUtil.class.getSimpleName(),"Read Failed");
            ex.printStackTrace();
        }

        try {
            if (!TextUtils.isEmpty(plain)) {
                String enc256 = TokenUtil.encryptAndJsonifyToken(null, plain);
                rValue = write(sharedPreferences, key, enc256);
                log(SecurityUtil.class.getSimpleName(), "isSuccessful : " + rValue);
            }
        }catch (Exception ex){
            log(SecurityUtil.class.getSimpleName(),"Write Failed");
            ex.printStackTrace();
        }
        log(SecurityUtil.class.getSimpleName(),"convertToken: ENDS");
        return rValue;
    }

    /**
     * Migrates all stored preference values from 128 bit AES to 256 bit AES.
     * Also changes the 128 bit AES key to 256 bit AES keys.
     */
    public static void migrateTo256() {
        Context mContext = DiscoverApplication.getGlobalContext();

        SharedPreferences sharedPref = mContext.getSharedPreferences(mContext.getResources().getString(R.string.post_login_username), Context.MODE_PRIVATE);
        boolean isFirstTimeUser = sharedPref.getBoolean(mContext.getResources().getString(R.string.isUserLoggedInFirstTime), false);

        boolean migrationTo256 = mContext.getSharedPreferences("com.discover.mobile.prefs", Context.MODE_PRIVATE).getBoolean("MigrationTo256", false);

        if (!isFirstTimeUser && !migrationTo256) {
            //FILE NAME :AppMessagingSingleton
            boolean isOpSuccess = convert(mContext.getSharedPreferences("app_messaging", Context.MODE_PRIVATE), "eds_key", false);
            log(SecurityUtil.class.getSimpleName(),"app_messaging:eds_key "+isOpSuccess);

            //FILE NAME :BankUrlManager//BANK
            isOpSuccess = convert(mContext.getSharedPreferences("links_prefs", Context.MODE_PRIVATE), "links_prefs", false);
            log(SecurityUtil.class.getSimpleName(),"app_messaging:links_prefs "+isOpSuccess);

            //FILE NAME :FingerPrintUtils
            isOpSuccess = convert(mContext.getSharedPreferences("prefs_fp_card", Activity.MODE_PRIVATE), "fp_pass", false);
            log(SecurityUtil.class.getSimpleName(),"prefs_fp_card:fp_pass "+isOpSuccess);
            isOpSuccess = convert(mContext.getSharedPreferences("prefs_fp_bank", Activity.MODE_PRIVATE), "fp_pass", false);
            log(SecurityUtil.class.getSimpleName(),"prefs_fp_bank:fp_pass "+isOpSuccess);
            isOpSuccess = convert(mContext.getSharedPreferences("prefs_fp_sso", Activity.MODE_PRIVATE), "fp_pass", false);
            log(SecurityUtil.class.getSimpleName(),"prefs_fp_sso:fp_pass "+isOpSuccess);

            //FILE NAME :PortalSharedPreferenceUtil
            isOpSuccess = convert(mContext.getSharedPreferences("portal_list", Context.MODE_PRIVATE), "users", false);
            log(SecurityUtil.class.getSimpleName(),"portal_list:users "+isOpSuccess);

            //FILE NAME :BankAndroidWearUtils//BANK
            isOpSuccess = convertToken(mContext.getSharedPreferences("AndroidWearUtils", Context.MODE_PRIVATE), "token", true);
            log(SecurityUtil.class.getSimpleName(),"AndroidWearUtils:token "+isOpSuccess);

            //FILE NAME :PasscodeUtils
            isOpSuccess = convertToken(mContext.getSharedPreferences(PasscodeUtils.class.getSimpleName(), Activity.MODE_PRIVATE), "token", true);
            log(SecurityUtil.class.getSimpleName(), PasscodeUtils.class.getSimpleName()+":token "+isOpSuccess);
            isOpSuccess = convertToken(mContext.getSharedPreferences("BankPasscodeUtils", Activity.MODE_PRIVATE), "token", true);
            log(SecurityUtil.class.getSimpleName(),"BankPasscodeUtils:token "+isOpSuccess);
            isOpSuccess = convertToken(mContext.getSharedPreferences("SSOPasscodeUtils", Activity.MODE_PRIVATE), "token", true);
            log(SecurityUtil.class.getSimpleName(),"SSOPasscodeUtils:token "+isOpSuccess);
            isOpSuccess = convert(mContext.getSharedPreferences(PasscodeUtils.class.getSimpleName(), Activity.MODE_PRIVATE), "fuserid", false);
            log(SecurityUtil.class.getSimpleName(),PasscodeUtils.class.getSimpleName()+":fuserid "+isOpSuccess);
            isOpSuccess = convert(mContext.getSharedPreferences("BankPasscodeUtils", Activity.MODE_PRIVATE), "fuserid", false);
            log(SecurityUtil.class.getSimpleName(),"BankPasscodeUtils:fuserid "+isOpSuccess);
            isOpSuccess = convert(mContext.getSharedPreferences("SSOPasscodeUtils", Activity.MODE_PRIVATE), "fuserid", false);
            log(SecurityUtil.class.getSimpleName(),"SSOPasscodeUtils:fuserid "+isOpSuccess);

            //FILE NAME :QuickViewUtils
            isOpSuccess = convertToken(mContext.getSharedPreferences("QuickViewUtils", Context.MODE_PRIVATE), "token", true);
            log(SecurityUtil.class.getSimpleName(),"QuickViewUtils:token "+isOpSuccess);

            //FILE NAME :BankPostLoginTestActivity////BANK
            isOpSuccess = convert(mContext.getSharedPreferences("links_prefs", Context.MODE_PRIVATE), "links_prefs", false);
            log(SecurityUtil.class.getSimpleName(),"links_prefs:links_prefs "+isOpSuccess);

            //FILE NAME :Globals
            isOpSuccess = convert(mContext.getSharedPreferences("com.discover.mobile.prefs", Context.MODE_PRIVATE), Globals.getStoredKeyName("userId"), false);
            log(SecurityUtil.class.getSimpleName(),"com.discover.mobile.prefs:userId "+isOpSuccess);
            isOpSuccess = convertKey(mContext.getSharedPreferences("com.discover.mobile.prefs" + ".version", Context.MODE_PRIVATE), "first_login");
            log(SecurityUtil.class.getSimpleName(),"com.discover.mobile.prefs:first_login "+isOpSuccess);
            isOpSuccess = convertKey(mContext.getSharedPreferences("com.discover.mobile.prefs", Context.MODE_PRIVATE), "isDepositFirstVisit=");
            log(SecurityUtil.class.getSimpleName(),"com.discover.mobile.prefs:isDepositFirstVisit= "+isOpSuccess);

            //FILE NAME :LoginActivity
            isOpSuccess = convertToken(mContext.getSharedPreferences("DiscoverCardPref", Context.MODE_PRIVATE), "FastcheckToken", true);
            log(SecurityUtil.class.getSimpleName(),"DiscoverCardPref:FastcheckToken "+isOpSuccess);

            //FILE NAME :FastCheckUtil
            isOpSuccess = convertToken(mContext.getSharedPreferences("DiscoverCardPref", Context.MODE_PRIVATE), "FastcheckToken1.0", true);
            log(SecurityUtil.class.getSimpleName(),"DiscoverCardPref:FastcheckToken1.0 "+isOpSuccess);
            isOpSuccess = convertToken(mContext.getSharedPreferences("DiscoverCardPref", Context.MODE_PRIVATE), "FastcheckWearToken", true);
            log(SecurityUtil.class.getSimpleName(),"DiscoverCardPref:FastcheckWearToken "+isOpSuccess);

            //FILE NAME :MOPKeyUtil
            //TODO some places it's saved with dyna key and for some with seeded key
            isOpSuccess = convert(mContext.getSharedPreferences("DiscoverCardPref", Context.MODE_PRIVATE), "MOPToken1.0", true);
            log(SecurityUtil.class.getSimpleName(),"DiscoverCardPref:MOPToken1.0 "+isOpSuccess);
            isOpSuccess = convert(mContext.getSharedPreferences("DiscoverCardPref", Context.MODE_PRIVATE), "MOPToken", true);
            log(SecurityUtil.class.getSimpleName(),"DiscoverCardPref:MOPToken "+isOpSuccess);

            isOpSuccess = mContext.getSharedPreferences("com.discover.mobile.prefs", Context.MODE_PRIVATE).edit().putBoolean("MigrationTo256", true).commit();
            log(SecurityUtil.class.getSimpleName(),"com.discover.mobile.prefs:MigrationTo256 "+isOpSuccess);
        }
    }
}
