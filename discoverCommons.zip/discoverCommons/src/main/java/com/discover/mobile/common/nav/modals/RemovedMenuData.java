package com.discover.mobile.common.nav.modals;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class RemovedMenuData

{

    @SerializedName("CardType")
    private String cardType;
    @SerializedName("MenuItemToBeRemoved")
    private ArrayList<RemovedMenuDrawerItems> menuItemsToBeRemoved;

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public ArrayList<RemovedMenuDrawerItems> getMenuItemsToBeRemoved() {
        return menuItemsToBeRemoved;
    }

    public void setMenuItemsToBeRemoved(
            ArrayList<RemovedMenuDrawerItems> menuItemsToBeRemoved) {
        this.menuItemsToBeRemoved = menuItemsToBeRemoved;
    }

}
