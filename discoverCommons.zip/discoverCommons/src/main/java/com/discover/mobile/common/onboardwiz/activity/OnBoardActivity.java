package com.discover.mobile.common.onboardwiz.activity;

import com.discover.mobile.common.BaseMasterFragment;
import com.discover.mobile.common.DiscoverModalManager;
import com.discover.mobile.common.R;
import com.discover.mobile.common.auth.KeepAlive;
import com.discover.mobile.common.error.ErrorHandler;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.highlightedfeatures.utils.HFPref;
import com.discover.mobile.common.nav.ActionBarBaseActivity;
import com.discover.mobile.common.nav.StatusBarFragment;
import com.discover.mobile.common.nav.configuration.ActionBarConfiguration;
import com.discover.mobile.common.onboardwiz.fragment.OnBoardMasterFragment;
import com.discover.mobile.common.onboardwiz.fragment.OnBoardPagerFragment;
import com.discover.mobile.common.onboardwiz.fragment.paperless.OnBoardPaperlessFragment;
import com.discover.mobile.common.onboardwiz.fragment.passcode.OnBoardPasscodeContainerFragment;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.onboardwiz.utils.RibbenMessage;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.CommonUtils;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.transition.Slide;
import android.transition.Transition;
import android.transition.Visibility;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import java.util.Calendar;

/**
 * Container Activity for OnBoarding fragments.
 * Created by 494005 on 4/25/2016.
 */
public class OnBoardActivity extends ActionBarBaseActivity {
    // 600 secs = 10 min
    public static final double MAX_IDLE_TIME = 600;
    public ImageView mCenterActionBarLogo;
    Bundle extras;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        DiscoverActivityManager.setActiveActivity(this);
        super.onCreate(savedInstanceState);

        /**Defect:1268 Check if App Permissions are changed manually when app was running,If true Navigate to Login page**/
        /*Removing below code will result in crash while changing permissions manually and opening the app*/
        if(com.discover.mobile.common.Utils.checkPermissionTampering(this)){
            return;
        }
        /**Defect:1268 end**/
        setContentView(NO_LAYOUT);
        new HFPref(this).setWizardShown(true);
        DiscoverModalManager.clearActiveModal();
        mCenterActionBarLogo = (ImageView) getCenterLogo();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mCenterActionBarLogo.setTransitionName("SHARED_LOGO"/*getResources().getString(R.string.onboard_exit_shared_anim_name)*/);
            setupWindowAnimations();
            getLeftLogo().setTransitionName("");
        }

        extras = getIntent().getExtras();
        if (!Globals.isBankLoginSelected()) {
            FacadeFactory.getCardFacade().startPageTimer(this);
        }

        OnBoardMasterFragment onBoardLandingFragment = new OnBoardMasterFragment();
        makeFragmentVisible(onBoardLandingFragment, true);
    }

    @Override
    public ActionBarConfiguration loadMenu() {
        return null;
    }

    @Override
    public ErrorHandler getErrorHandler() {
        return null;
    }

    @Override
    public void onBackPressed() {

        final Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.contentView);
        if (fragment instanceof BaseMasterFragment) {
            ((BaseMasterFragment) fragment).onBackPressed();
        }

    }

    @Override
    public boolean dispatchTouchEvent(final MotionEvent ev) {
        super.dispatchTouchEvent(ev);

        //handle this only for bank login
        if (Globals.isBankLoginSelected()) {
            //US54329: Feature Transitions code changes start
            //Get the currently loaded fragment
            Fragment fragment = OnBoardHelper.getCurrentChildFragment(this.getSupportFragmentManager().findFragmentById(R.id.contentView));
            //currentFragment is the page which currently displayed on page Viewer
            Fragment currentFragment = null;
            if (fragment != null)
                currentFragment = ((OnBoardPagerFragment) fragment).getCurrentFragment();

            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                //Function initiate logout on timeout
                compareLastTouchTimeAndUpdateSession();

                //Pause the slide_to_top animation when page is on mid swipe
                if (currentFragment instanceof OnBoardPasscodeContainerFragment || currentFragment instanceof OnBoardPaperlessFragment) {
                    //Pause the animation
                    RibbenMessage.pauseAnimation();
                }
            }
            if (ev.getAction() == MotionEvent.ACTION_UP) {
                //Restart the slide_to_top animation when page loaded after swipe event
                if (currentFragment instanceof OnBoardPasscodeContainerFragment || currentFragment instanceof OnBoardPaperlessFragment) {
                    //Restart the slide_to_top animation
                    RibbenMessage.restartExitAnimation();
                }
            }
            //Clear fragment and current fragment objects.
            fragment = null;
            currentFragment = null;
            //US54329: Feature Transitions code changes end
        } else {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                CommonUtils.setLastRestCallTime();
            }
        }
        return false;
    }

   /* public void navigateToRoot() {
        if(!Globals.isBankLoginSelected())
        FacadeFactory.getHighlightedFeaturesFacade().navigateToCardHome(OnBoardActivity.this, extras);
        else {
            //Added to clear the BankOnBoardingInfo object
            OnBoardHelper.clearBankOnBoardingInfo();
            FacadeFactory.getBankLoginFacade().navigateToBankHomePage();
        }
        finish();
    }*/

    public void navigateToRoot() {
        // setupWindowAnimations();
        if (!Globals.isBankLoginSelected()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                FacadeFactory.getHighlightedFeaturesFacade().navigateToCardHomeFromOnBoard(OnBoardActivity.this, extras);
            } else {
                FacadeFactory.getHighlightedFeaturesFacade().navigateToCardHome(OnBoardActivity.this, extras);
                finish();
            }

        } else {
            // US59004 start Get the currently loaded fragment
            Fragment fragment = OnBoardHelper.getCurrentChildFragment(this.getSupportFragmentManager().findFragmentById(R.id.contentView));
            // currentFragment is the page which currently displayed on page Viewer
            if (fragment != null) {
                OnBoardPagerFragment currentFragment = ((OnBoardPagerFragment) fragment);
                if (currentFragment.getCurrentFragment() instanceof OnBoardPasscodeContainerFragment) {
                    OnBoardHelper.exitFromPasscodePage = true;
                }
            }
            // US59004 End
            FacadeFactory.getBankLoginFacade().navigateToBankHomePage();
        }
        //finish();

    }

    private void hideStatusBarFragment() {
        StatusBarFragment statusBarFragment = (StatusBarFragment) getSupportFragmentManager().findFragmentById(R.id.status_bar);
        final FragmentTransaction fragmentTransaction = this.getSupportFragmentManager().beginTransaction();
        fragmentTransaction.hide(statusBarFragment);
        fragmentTransaction.commit();
    }

    /**
     * Determines the current time and gets the time stored in globals. Then
     * updates globals with the current time.
     */
    private void compareLastTouchTimeAndUpdateSession() {
        final Calendar mCalendarInstance = Calendar.getInstance();

        final long previousTime = Globals.getOldTouchTimeInMillis();
        final long currentTime = mCalendarInstance.getTimeInMillis();

        if (!setIsUserTimedOut(previousTime, currentTime)) {
            KeepAlive.checkForRequiredSessionRefresh();
        }
        Globals.setOldTouchTimeInMillis(currentTime);
    }

    /**
     * Determines whether or not the user is timed out.
     *
     * @return true if the user is timed-out, false otherwise.
     */
    private boolean setIsUserTimedOut(final long previousTime,
                                      final long currentTime) {
        // Previous value exists
        if (previousTime != 0) {
            final int oneSecond = 1000;
            final long difference = currentTime - previousTime;
            final float secs = (float) difference / oneSecond;

            // User has become inactive and will be set to timed-out.
            if (secs > MAX_IDLE_TIME) {
                //Initiate logout from application
                FacadeFactory.getBankLogoutFacade().logout(this, true, false);
                return true;
            }
        }
        return false;
    }

    /*Setting Up Exit Transitio effect for Onboard Activity*/
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void setupWindowAnimations() {
        Transition transition;
        getWindow().setSharedElementsUseOverlay(true);
        getWindow().setBackgroundDrawable(getResources().getDrawable(android.R.drawable.screen_background_light));
        transition = buildEnterTransition();
        transition.excludeTarget(getToolBar(), true);
        getWindow().setEnterTransition(transition);
        getWindow().setExitTransition(transition);
        getWindow().setReenterTransition(transition);
    }

    /*Creating the Enter tansition Tranistion effect
     *This effect is to decide the Exit Transition for
     * Onboard activity when it exits*/
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private Visibility buildEnterTransition() {
        Slide enterTransition = new Slide();
        enterTransition.setInterpolator(new LinearInterpolator());
        enterTransition.setDuration(600);
        enterTransition.setSlideEdge(Gravity.LEFT);
        enterTransition.setMode(Slide.MODE_OUT);
        return enterTransition;
    }

    public void finishCurrentActivity() {
        finish();
    }

    public void navToCardWithoutLogo() {
        FacadeFactory.getHighlightedFeaturesFacade().navigateToCardHome(OnBoardActivity.this, extras);

    }
}