package com.discover.mobile.common.appmessaging.helper;

/**
 * Created by 476056 on 6/17/2016.
 */
public interface AppLevelMessageTracker {

    public void trackAppLevelMessageForMainItem();

    public void trackAppLevelMessageForSubItem(String key);
}
