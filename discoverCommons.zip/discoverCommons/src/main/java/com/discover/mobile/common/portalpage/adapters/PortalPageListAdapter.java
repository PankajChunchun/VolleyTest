package com.discover.mobile.common.portalpage.adapters;

import com.discover.mobile.common.portalpage.PortalPageUIInterface;
import com.discover.mobile.common.portalpage.listener.PortalBoxInterface;
import com.discover.mobile.common.portalpage.utils.PortalAccountType;
import com.discover.mobile.common.portalpage.view.PortalAccountBox;
import com.discover.mobile.common.uiwidget.dynamiclist.CmnDraggableListAdapter;
import com.discover.mobile.common.uiwidget.dynamiclist.CmnDraggableListAdapterListener;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import java.util.List;

/**
 * Adapter class to map Card & Bank accounts to Portal list
 *
 * @author slende
 */
public class PortalPageListAdapter extends CmnDraggableListAdapter<PortalBoxInterface>{ //implements PortalListItemClickInterface {
    private final String TAG = PortalPageListAdapter.class.getSimpleName();
    private static final String PORTAL_BOX_ROW_PREFIX = "portal_page_row_";

    private List<PortalBoxInterface> msortedPortalAccounList = null;
    private int pos = 0;
    private String LIST_NAME;
    private PortalPageUIInterface mPortalPageUIInterface;

    public PortalPageListAdapter(List<PortalBoxInterface> accounList, String listValue, CmnDraggableListAdapterListener cmnDraggableListAdapterListener, PortalPageUIInterface portalPageUIInterface) {
        super(accounList, cmnDraggableListAdapterListener);
        mPortalPageUIInterface = portalPageUIInterface;
        LIST_NAME = listValue;
        msortedPortalAccounList = accounList;
    }

    @Override
    public int getCount() {
        if (null != msortedPortalAccounList)
            return msortedPortalAccounList.size();
        else
            return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final Context mcontext = parent.getContext();
        final PortalBoxInterface dataItem = msortedPortalAccounList.get(position);

        final PortalAccountType accountType = this.mPortalPageUIInterface.getAccountType(dataItem);

        if (null == convertView) {
            convertView = new PortalAccountBox(mcontext, position);
        }

        if (null != accountType) {
            switch (accountType) {

                case ACCOUNT_CHECKING:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_CHECKING, dataItem, pos, LIST_NAME);
//		Log.d(TAG, "ACCOUNT_CHECKING" + position);

                    break;

                case ACCOUNT_SAVINGS:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_SAVINGS, dataItem, pos, LIST_NAME);
//		Log.d(TAG, "ACCOUNT_SAVING" + position);
                    break;

                case ACCOUNT_MONEY_MARKET:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_MONEY_MARKET, dataItem, pos, LIST_NAME);
//		Log.d(TAG, "ACCOUNT_MONEY_MARKET" + position);
                    break;

                case ACCOUNT_CD:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_CD, dataItem, pos, LIST_NAME);
//		Log.d(TAG, "ACCOUNT_CD" + position);
                    break;

                case ACCOUNT_IRA:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_IRA, dataItem, pos, LIST_NAME);
//		Log.d(TAG, "ACCOUNT_CD_IRA" + position);
                    break;

                case ACCOUNT_CREDIT_CARD:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_CREDIT_CARD, dataItem, pos, "list1");
//		Log.d(TAG, "ACCOUNT_CREDIT_CARD" + position);
                    break;

                case ACCOUNT_LOAN:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_LOAN, dataItem, pos, LIST_NAME);
//		Log.d(TAG, "ACCOUNT_LOAN");
                    break;

                case ACCOUNT_CREDIT_CARD_ERROR:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_CREDIT_CARD_ERROR, dataItem, pos, "list1");

                    break;
                case ACCOUNT_BANK_ERROR:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_BANK_ERROR, dataItem, pos, LIST_NAME);

                    break;
                case ACCOUNT_BANK_VERIFY:

                    ((PortalAccountBox) convertView).mapViewWithData(PortalAccountType.ACCOUNT_BANK_VERIFY, dataItem, pos, LIST_NAME);

                    break;
                default:
                    break;
            }

            if(mPortalPageUIInterface.isInDraggingState()){
                int draggingItemPosition = mPortalPageUIInterface.getDraggingItemPosition();
                if(position != draggingItemPosition) {
                    convertView.setAlpha(0.8f);
                }
            }else{
                convertView.setAlpha(1.0f);
            }

            // Handle left deep link
            if (null != ((PortalAccountBox) convertView).getLeftDeepLink())
                ((PortalAccountBox) convertView).getLeftDeepLink().setOnClickListener(new OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        mPortalPageUIInterface.onClickLeftDeepLinkOfPortalBox(dataItem, accountType);
                    }

                });

            // added this line for US43080 && Defect# 617
            final String rightDeepLinkString = getRightDeepLink(convertView);
            // Handle right deep link
            if (null != ((PortalAccountBox) convertView).getRightDeepLink()) {
                ((PortalAccountBox) convertView).getRightDeepLink().setOnClickListener(new OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        mPortalPageUIInterface.onClickRightDeepLinkOfPortalBox(dataItem, accountType, rightDeepLinkString);
                    }
                });
            }
        }
        convertView.invalidate();

        // US79786 Changes starts
        convertView.setTag(PORTAL_BOX_ROW_PREFIX + position);
        pos++;
        // US79786 Changes end
        return convertView;
    }

    /**
     * Method to get right deeplink text added for 7.8 regression defect fixing - Defect# 617
     */
    private String getRightDeepLink(View convertView) {
        String rightDeepLinkString = "";
        if (null != convertView && null != ((PortalAccountBox) convertView).getRightDeepLink()) {
            // below code is part of US43080
            rightDeepLinkString = ((PortalAccountBox) convertView).getRightDeepLink().getText().toString();
        }
        return rightDeepLinkString;
    }


    @Override
    public Object getItem(int position) {
        return super.getItem(position);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public boolean hasStableIds() {
        return super.hasStableIds();
    }
}
