package com.discover.mobile.common.onboardwiz.fragment.paperless;

import com.discover.mobile.common.R;
import com.discover.mobile.common.analytics.AnalyticsPage;
import com.discover.mobile.common.analytics.TrackingHelper;
import com.discover.mobile.common.facade.FacadeFactory;
import com.discover.mobile.common.onboardwiz.fragment.IPopFragment;
import com.discover.mobile.common.onboardwiz.fragment.OnBoardNavigationListener;
import com.discover.mobile.common.onboardwiz.service.OnBoardServiceClass;
import com.discover.mobile.common.onboardwiz.utils.BankOnBoardingInfo;
import com.discover.mobile.common.onboardwiz.utils.OnBoardHelper;
import com.discover.mobile.common.onboardwiz.utils.RibbenMessage;
import com.discover.mobile.common.shared.DiscoverActivityManager;
import com.discover.mobile.common.shared.Globals;
import com.discover.mobile.common.shared.utils.StringUtility;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;

/**
 * This fragment displays the Page with the valid
 * paperless accounts and provides the option to enable or disable paperless statements
 **/
public class OnBoardPaperlessFragment extends Fragment implements IPopFragment, RibbenMessage.TimeOutListener {

    //This view will be added dynamically based on paperlist list items
    OnBoardingPaperlessAccountRow onBoardingAccountRow = null;
    //BankOnBoardPaperlessHelper object to read paperless contents from the OnBoardHelper class
    BankOnBoardingInfo mBankOnBoardingInfo = null;
    /**
     * Holds Reference to the root view
     **/
    private View mView;
    /**
     * Holds Reference to the context
     **/
    private Context mContext;
    private View spacingView;
    //OnBoardServiceClass object to call service call method
    private OnBoardServiceClass onBoardServiceClass;
    /**
     * Listener class that listens for Enable/Disable action and makes a call
     * to show the corresponding dialogs- should be set for the switch toggle
     **/
    CompoundButton.OnCheckedChangeListener paperlessSwitchChangeListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
            //Added this condition check for content description in oder to support ADA
            /*if (isChecked)
                compoundButton.setContentDescription("Paperless ON");
            else
                compoundButton.setContentDescription("Paperless OFF");*/
            BankOnBoardingInfo.PaperlessDetails paperlessDetails = (BankOnBoardingInfo.PaperlessDetails) compoundButton.getTag();
            if (paperlessDetails.mPaperlessState != isChecked) {
                //Show paperless statements enable/disable modal
                showEnableDisableModal(compoundButton, isChecked);
            }
            paperlessDetails = null;
        }
    };
    private LinearLayout mAccountsContainer;
    private TextView mGoGreenText;
    private TextView mPaperLessText;
    private TextView paperlessBodyText;

    /**
     * The UI for the paperless page is inflated and all the necessary views are initialized
     **/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mView = inflater.inflate(R.layout.onboarding_paperless_statements, null);

        //Initialize all the onBoardPaperless User interfaceF
        return mView;
    }

    @Override
    public void onResume() {
        super.onResume();
        //Initialize all the onBoardPaperless User interface
        initOnBoardPaperlessUI();
    }

    @Override
    public void onPause() {
        super.onPause();

    }

    public void updateUI() {

        if (OnBoardHelper.mPaperlessAnim) {
            OnBoardHelper.mPaperlessAnim = false;

            mAccountsContainer.setVisibility(View.INVISIBLE);
            paperlessBodyText.setVisibility(View.INVISIBLE);
            mGoGreenText.setVisibility(View.INVISIBLE);
            mPaperLessText.setVisibility(View.INVISIBLE);
            //loding view animation
            android.view.animation.Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.possocde_slide_in_right);
            //start view animation
            mView.findViewById(R.id.paperless_image).startAnimation(animation);

            mAccountsContainer.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mAccountsContainer.setVisibility(View.VISIBLE);
                    paperlessBodyText.setVisibility(View.VISIBLE);
                    mGoGreenText.setVisibility(View.VISIBLE);
                    mPaperLessText.setVisibility(View.VISIBLE);

                }
            }, 300);

        }

    }

    /**
     * Initialize the views and populate dynamic views of onboarding paperless view
     **/
    private void initOnBoardPaperlessUI() {
        mContext = this.getActivity();
        paperlessBodyText = (TextView) mView.findViewById(R.id.paperless_body_text);
        spacingView = (View) mView.findViewById(R.id.paperless_space_view);
        onBoardServiceClass = new OnBoardServiceClass(mContext);
        mAccountsContainer = (LinearLayout) mView.findViewById(R.id.accounts_container);
        TextView exitSetup = (TextView) mView.findViewById(R.id.exit_setup);
        spacingView.setVisibility(View.GONE);


        mGoGreenText = (TextView) mView.findViewById(R.id.go_green_text);
        mPaperLessText = (TextView) mView.findViewById(R.id.paperless_text);
        updatePaperlessList();


    }

    /**
     * Populate Paperless List view
     */
    private void updatePaperlessList() {
        // Read paperless data from BankOnBoardPaperlessHelper
        mBankOnBoardingInfo = OnBoardHelper.getsBankOnBoardingInfo();
        //Condition check to verify BankOnBoardPaperlessHelper object value
        if (mBankOnBoardingInfo != null) {
            //Check whether bankOnBoardinfo has email or not
            if (mBankOnBoardingInfo.mEmail != null) {
                //verify bankOnBoardinfo checking account or not. Based on this the different text will display on screen
                if (mBankOnBoardingInfo.mHasCheckingAccounts) {
                    //bankOnBoardinfo has paperless accounts
                    paperlessBodyText.setText(Html.fromHtml(String.format(DiscoverActivityManager
                            .getString(R.string.onboard_cashback_checking_text_1), mBankOnBoardingInfo.mEmail.toLowerCase())));

                    paperlessBodyText.setContentDescription(Html.fromHtml(String.format(DiscoverActivityManager
                            .getString(R.string.onboard_cashback_checking_text_1), mBankOnBoardingInfo.mEmail.toLowerCase())));
                } else {
                    //bankOnBoardinfo has no paperless accounts
                    paperlessBodyText.setText(Html.fromHtml(String.format(DiscoverActivityManager
                            .getString(R.string.onboard_no_cashback_checking_text), mBankOnBoardingInfo.mEmail.toLowerCase())));
                    paperlessBodyText.setContentDescription(Html.fromHtml(String.format(DiscoverActivityManager
                            .getString(R.string.onboard_no_cashback_checking_text), mBankOnBoardingInfo.mEmail.toLowerCase())));
                }
            }
            //get the paperless list items count
            int paperlessCount = mBankOnBoardingInfo.mPaperlessAccountlist.size();
            // mAccountsContainer cleared all the views to avoid duplicate list items while displaying list from onResume() function.
            if (mAccountsContainer != null) {
                //Remove all the views from mAccountsContainer
                mAccountsContainer.removeAllViews();
            }
            //Loop all the values
            for (int pCount = 0; pCount < paperlessCount; pCount++) {
                onBoardingAccountRow = new OnBoardingPaperlessAccountRow(mContext);
                BankOnBoardingInfo.PaperlessDetails paperlessDetails = mBankOnBoardingInfo.mPaperlessAccountlist.get(pCount);
                //set paperless state & account id based on the bundle value
                onBoardingAccountRow.setAccountsAndToggle(paperlessDetails.mAccountNickName, paperlessDetails.mAccEnding, paperlessDetails.mPaperlessState);

                //Set onclick listener
                onBoardingAccountRow.getEnableToggle().setOnCheckedChangeListener(paperlessSwitchChangeListener);
                //Set Tag to read this object on click of each row element
                onBoardingAccountRow.getEnableToggle().setTag(paperlessDetails);

                // Add the view to the container
                mAccountsContainer.addView(onBoardingAccountRow);
                //Added the content description to support ADA
                String state = paperlessDetails.mPaperlessState ? "On" : "Off";
                onBoardingAccountRow.setContentDescription(paperlessDetails.mAccountNickName + paperlessDetails.mAccEnding + state);
                onBoardingAccountRow.getEnableToggle().setContentDescription(paperlessDetails.mAccountNickName + paperlessDetails.mAccEnding);
                //Clear paperlessDetails
                paperlessDetails = null;
            }
        }
    }

    /**
     * Pops up Either Enable Model Or Disable model based on the isToggleChecked
     * parameter for paperless - must be called when any paperless account is
     * disabled
     **/
    public void showEnableDisableModal(final CompoundButton compoundButton, final boolean istoggleChecked) {
        //Loading dummy url, should load correct url once available
        final OnBoardingPaperlessEnableDialog modal = new OnBoardingPaperlessEnableDialog(mContext);
        modal.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(modal.getWindow().getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT;
        modal.setOkButtonText(R.string.onboard_accept);
        modal.setCancelable(false);
        modal.setCancelButtonText(R.string.onboard_cancel);
        //Account ending value displayed as temporary, since tracking of specific row work need to be done
        final BankOnBoardingInfo.PaperlessDetails paperlessDetails = (BankOnBoardingInfo.PaperlessDetails) compoundButton.getTag();

        String state = istoggleChecked ? "On" : "Off";

        //Read the acc end name from the row tag.
        String accountEndValue = null;
        if (paperlessDetails != null) {
            //Added this condition check for content description in oder to support ADA
            compoundButton.setContentDescription(paperlessDetails.mAccountNickName.toString() + paperlessDetails.mAccEnding.toString() + state);
            accountEndValue = paperlessDetails.mAccEnding.toString();
        }

        if (istoggleChecked) {
            //Enable modal display

            // Start: US53564 - Onboarding Wizard: Paperless Enable Site Catalyst Tags
            if (Globals.isBankLoginSelected()) {
                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        (R.string.onboard_paperless_enrollment_modal));
            }
            // End
            compoundButton.setContentDescription(paperlessDetails.mAccountNickName.toString() + paperlessDetails.mAccEnding.toString() + state);
            modal.setModalTitle(R.string.onboard_paperless_enable_dlg_title);
            modal.setModalBodyText(mContext.getResources().getString(R.string.onboard_paperless_enable_dlg_text) + StringUtility.SPACE + accountEndValue + ".");
            // modal.setUrlToLoad("https://asys-mapi.discoverbank.com/api/static/deposits/terms.html");
            modal.setUrlToLoad(mBankOnBoardingInfo.mPaperlessEnableWebview);
        } else {
            //Disable modal display
            //layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;

            modal.setModalTitle(R.string.onboard_paperless_disable_dlg_title);
            modal.setModalBodyText(mContext.getResources().getString(R.string.onboard_paperless_disable_dlg_text) + StringUtility.SPACE + accountEndValue);
            //commented this inorder to match with post login paperless modal and passing empty string
            //modal.setUrlToLoad("https://asys-mapi.discoverbank.com/api/static/deposits/terms.html");
            modal.setUrlToLoad("");
            // Start: US56902 - Onboarding Wizard: Paperless Disable Site Catalyst Tags
            if (Globals.isBankLoginSelected()) {
                FacadeFactory.getBankLoginFacade().forceTrackPage(
                        (R.string.onboard_paperless_disable_mdl));
            }
            //US56902 End
        }
        modal.getOkButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                // Start: US53564 - Onboarding Wizard: Paperless Enable Site Catalyst Tags
                if (Globals.isBankLoginSelected() && istoggleChecked) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, DiscoverActivityManager.getActiveActivity().getResources().getString(R.string.onboard_paperless_enrollment_modal_accept_btn));
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.onboard_paperless_enrollment_modal));
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                }
                // Start: US56902 - Onboarding Wizard: Paperless Disable Site Catalyst Tags
                else if (Globals.isBankLoginSelected() && !(istoggleChecked)) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, DiscoverActivityManager.getActiveActivity().getResources().getString(R.string.onboard_paperless_disable_accept_btn));
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                }
                // End
                modal.dismiss();
                onBoardServiceClass.getPapperlessStatus(OnBoardPaperlessFragment.this, paperlessDetails.mAccountId, istoggleChecked);

            }
        });
        modal.getCancelButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                // Start: US53564 - Onboarding Wizard: Paperless Enable Site Catalyst Tags
                if (Globals.isBankLoginSelected() && istoggleChecked) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, DiscoverActivityManager.getActiveActivity().getResources().getString(R.string.onboard_paperless_enrollment_modal_cancel_btn));
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_13, getResources().getString(R.string.onboard_paperless_enrollment_modal));
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                }
                // End
                // Start: US56902 - Onboarding Wizard: Paperless Disable Site Catalyst Tags
                else if (Globals.isBankLoginSelected() && !(istoggleChecked)) {
                    HashMap<String, Object> extras = new HashMap<String, Object>();
                    extras.put(
                            AnalyticsPage.CONTEXT_PROPERTY_1, DiscoverActivityManager.getActiveActivity().getResources().getString(R.string.onboard_paperless_disable_cancel_btn));
                    extras.put("pe", AnalyticsPage.ANDROID_PAY_LNK_O);
                    TrackingHelper.trackBankPage(null, extras);
                }
                // End
                modal.dismiss();
                compoundButton.setChecked(!compoundButton.isChecked());
            }
        });

        modal.show();
        modal.getWindow().setAttributes(layoutParams);
        modal.getWindow().setBackgroundDrawableResource(R.drawable.transparent_square);
        if (!istoggleChecked) {
            //ViewGroup.LayoutParams modalCntParams=new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
            LinearLayout modalLayout = (LinearLayout) modal.findViewById(R.id.relative_layout);
            modalLayout.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
            //modalLayout.setLayoutParams();
            //modalLayout.getLayoutParams().height= ViewGroup.LayoutParams.WRAP_CONTENT;
            //modalLayout.setLayoutParams(modalCntParams);
        }
    }

    /**
     * Removing listeners and releasing memory of objects
     **/
    @Override
    public void onDetach() {
        super.onDetach();
        onBoardingAccountRow.getEnableToggle().setOnCheckedChangeListener(null);
        onBoardServiceClass = null;
        mView = null;
        mContext = null;
    }

    @Override
    //Function helps to navigate to previous page from fragment manager
    public boolean popBackStack() {
        //Get the curently displayed fragment from back stack
        Fragment fragment = OnBoardHelper.getCurrentChildFragment(getActivity().getSupportFragmentManager().findFragmentById(R.id.contentView));
        if (fragment instanceof OnBoardNavigationListener) {
            ((OnBoardNavigationListener) fragment).moveToPreviousPage();
        }
        //clear this fragment
        fragment = null;
        return true;
    }

    @Override
    //Function helps to display the contents of the paperless page
    public void updateCurrentPage() {
        //This will be helpful while implementing the service call


    }


    /*
    *After service call is failure updating success message
    */
    private void showErrorMessage() {
        FrameLayout layout = (FrameLayout) mView.findViewById(R.id.container_view);
        RibbenMessage.make(this, layout, R.string.onboard_ribben_paperless_enable, RibbenMessage.LENGTH_LONG, RibbenMessage.ERROR, this).show();
    }

    /*
    *After service call is  success updating success message
    */
    public void showRibbenMessage() {
        OnBoardHelper.hideExitButton(getActivity());
        spacingView.setVisibility(View.VISIBLE);


        FrameLayout layout = (FrameLayout) mView.findViewById(R.id.paperless_success_main_view);

        RibbenMessage.make(this, layout, R.string.onboard_ribben_paperless_enable, RibbenMessage.LENGTH_EXTRA_LONG, RibbenMessage.SUCCESS, this).show();
        layout.requestFocus();
        layout.setContentDescription(getString(R.string.onboard_ribben_paperless_enable));
        // Start: US53564 - Onboarding Wizard: Paperless Enable Site Catalyst Tags
        if (Globals.isBankLoginSelected()) {
            FacadeFactory.getBankLoginFacade().forceTrackPage(R.string.onboard_paperless_stmt_success);
        }
        //End
        layout.clearFocus();
    }


    @Override
    public void onTimeOut() {

       /* Fragment fragment = getActivity().getSupportFragmentManager().findFragmentById(R.id.contentView);
        if (fragment instanceof OnBoardPagerFragment) {
            ((OnBoardPagerFragment) fragment).controlVisibilityExitSetupLink(true);
        }*/

        //US54329: Feature Transitions code changes start
        RibbenMessage.destroyRibben();
        //US54329: Feature Transitions code changes end

        spacingView.setVisibility(View.GONE);
        OnBoardHelper.visiblityForExitButton(getActivity(), true);
    }

    /**
     * handle error scenario
     */
    public void handleError() {
        // showErrorMessage();
        initOnBoardPaperlessUI();
    }

    /**
     * Handle succes scenario
     *
     * @param context Holds Reference to the context
     */
    public void handleSuccess(Context context, boolean paperlessState) {

        if (paperlessState) {
            showRibbenMessage();
        }
        updatePaperlessList();
        //initOnBoardPaperlessUI();
    }


    // Hides the Spacing view when user is navigation from quick view after Ribben message.
    public void hideSpacingView() {
        if (spacingView != null) {
            spacingView.setVisibility(View.GONE);
        }
    }

}
